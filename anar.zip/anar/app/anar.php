<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class anar extends Model
{
    //
}
