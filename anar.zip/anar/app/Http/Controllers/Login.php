<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
Use Auth;
use View,
    Response,
    Validator,
    Input,
    Mail,
    Session;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesResources;
use Illuminate\Support\Facades\Redirect;
use DB;

class Login extends Controller
{
	
	public function index()
		{
			return view('login');
		}
	public function login_check(Request $req)
	{
		$v = Validator::make($req->all(), [
        'username' => 'required',
        'password' => 'required|alphaNum|min:3',
		]);
		if ($v->fails())
		{
			Session::flash('message', 'User name or or password information wrong!'); 
			Session::flash('alert-class', 'alert-danger'); 
			return redirect()->route('login');
		}
		else
		{
			$username = $req->input('username');
			$password = $req->input('password');
			$checklogin = DB::table('login')->where(['username'=>$username, 'password'=>md5($password)])->get();
			if(count($checklogin) > 0)
			{	
				Session()->put('username', $username);
				Session()->put('uid','dad795e5-4b33-11e3-8c00-90590c30cc70');				
				Session::flash('message', 'Login successful!'); 
				Session::flash('alert-class', 'alert-success'); 
				return redirect()->route('admin');
				 
			}
			else
			{
				Session::flash('message', 'User name or or password information wrong!'); 
				Session::flash('alert-class', 'alert-danger'); 				
				return redirect()->route('login');
			}	
		}
	}
	
	public function logout()
	{
		Session::flush();
		return redirect()->route('login');
	}
	
}
