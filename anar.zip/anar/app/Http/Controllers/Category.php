<?php
namespace App\Http\Controllers;
//use Request;
Use Auth;
use View,
    Response,
    Validator,   
    Mail,
    Session;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesResources;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use App\model_homeadmin;
use DB;

class Category extends Controller
{
	/***************************start category************************************/
	public function addcategory()
		{
			return view('admin/category/addcategory');
		}	
	public function savecategory(Request $req)
		{
			$webpage_data = array(
				  'name' => Input::get('name'),				 
				  'createddate' => date('Y-m-d H:i:s'),
				  'modifieddate' => date('Y-m-d H:i:s'),
				  'createdby' => Session::get('username'),
				  'modifiedby' => Session::get('username'),
				  'createdip' => $_SERVER['SERVER_ADDR'],
				  'modifiedip' => $_SERVER['SERVER_ADDR']
			  );
			$success = DB::table('category')->insert($webpage_data);  				
			Session::flash('message', 'Category saved successful!'); 
			Session::flash('alert-class', 'alert-success'); 		
			return redirect()->route('admin/viewcategory');
		}
	public function viewcategory()
		{
			$data['allcategory'] = DB::table('category')->where(['status'=> 1])->get();
			return view('admin/category/viewcategory', $data)->with('no', 1);
		}
	
	public function editcategory($id)
		{					
			$category = DB::table('category')->where(['id'=> $id])->first();
			return view('admin/category/editcategory', compact('category'));		
		}
	public function updatecategory(Request $req)
		{			
		    $webpage_data = array(	
				'name' => Input::get('name'),	
				'modifieddate' => date('Y-m-d H:i:s'),
				'modifiedby' => Session::get('username'),
				'modifiedip' => $_SERVER['SERVER_ADDR']	
			);			
			$success = DB::table('category')
				->where('id', Input::get('id'))
				->update($webpage_data);				
			return redirect()->route('admin/viewcategory');		
		}
	public function suspendcategory($id)
		{
			$webpage_data = array(
				'status' => '0',
				'modifieddate' => date('Y-m-d H:i:s'),
				'modifiedby' => Session::get('username'),
				'modifiedip' => $_SERVER['SERVER_ADDR']	
			);
			$result = DB::table('category')
				->where('id', $id)
				->update($webpage_data);	
			Session::flash('message', 'Category deleted successful!'); 
			Session::flash('alert-class', 'alert-success'); 	
			return redirect()->route('admin/viewcategory');		
		}
	public function trashcategory()
		{
			$data['allcategory'] = DB::table('category')->where(['status'=> 0])->get();
			return view('admin/category/trashcategory', $data)->with('no', 1);		
		}
	public function reactivecategory($id)
		{
			$webpage_data = array(
				'status' => '1',
				'modifieddate' => date('Y-m-d H:i:s'),
				'modifiedby' => Session::get('username'),
				'modifiedip' => $_SERVER['SERVER_ADDR']	
		    );
			$result = DB::table('category')
				->where('id', $id)
				->update($webpage_data);
			Session::flash('message', 'Category reactived successfully!');
			Session::flash('alert-class', 'alert-success');
			return redirect()->route('admin/trashcategory');	
		}
	/*******************************end category*************************************/	
	
	/*******************************start subcategory***********************************/
	public function addsubcategory()
		{
			$data['allcategory'] = DB::table('category')->where(['status'=> 1])->get();
			return view('admin/category/addsubcategory', $data);
		}	
	public function savesubcategory(Request $req)
		{
			$webpage_data = array(
				  'name' => Input::get('name'),	
				  'category_id' => Input::get('category_id'),					  
				  'createddate' => date('Y-m-d H:i:s'),
				  'modifieddate' => date('Y-m-d H:i:s'),
				  'createdby' => Session::get('username'),
				  'modifiedby' => Session::get('username'),
				  'createdip' => $_SERVER['SERVER_ADDR'],
				  'modifiedip' => $_SERVER['SERVER_ADDR']
			  );
			$success = DB::table('subcategory')->insert($webpage_data);  				
			Session::flash('message', 'Subcategory saved successful!'); 
			Session::flash('alert-class', 'alert-success'); 		
			return redirect()->route('admin/viewsubcategory');
		}
	public function viewsubcategory()
		{			
			$data['allsubcategory'] = DB::table('subcategory as s')
            ->join('category as c', 's.category_id', '=', 'c.id')            
            ->select('s.*', 'c.name as catname')
			->where(['s.status'=> 1])
            ->get();
			return view('admin/category/viewsubcategory', $data)->with('no', 1);
		}
	
	public function editsubcategory($id)
		{	
			//category
			$data['allcategory'] = DB::table('category')->where(['status'=> 1])->get();
			$subcategory = DB::table('subcategory')->where(['id'=> $id])->first();
			return view('admin/category/editsubcategory', compact('subcategory'), $data);		
		}
	public function updatesubcategory(Request $req)
		{			
		    $webpage_data = array(	
				'name' => Input::get('name'),
				'category_id' => Input::get('category_id'),				
				'modifieddate' => date('Y-m-d H:i:s'),
				'modifiedby' => Session::get('username'),
				'modifiedip' => $_SERVER['SERVER_ADDR']	
			);			
			$success = DB::table('subcategory')
				->where('id', Input::get('id'))
				->update($webpage_data);				
			return redirect()->route('admin/viewsubcategory');		
		}
	public function suspendsubcategory($id)
		{
			$webpage_data = array(
				'status' => '0',
				'modifieddate' => date('Y-m-d H:i:s'),
				'modifiedby' => Session::get('username'),
				'modifiedip' => $_SERVER['SERVER_ADDR']	
			);
			$result = DB::table('subcategory')
				->where('id', $id)
				->update($webpage_data);	
			Session::flash('message', 'Subcategory deleted successful!'); 
			Session::flash('alert-class', 'alert-success'); 	
			return redirect()->route('admin/viewsubcategory');		
		}
	public function trashsubcategory()
		{			
			$data['allsubcategory'] = DB::table('subcategory as s')
            ->join('category as c', 's.category_id', '=', 'c.id')            
            ->select('s.*', 'c.name as catname')
			->where(['s.status'=> 0])
            ->get();
			return view('admin/category/trashsubcategory', $data)->with('no', 1);		
		}
	public function reactivesubcategory($id)
		{
			$webpage_data = array(
				'status' => '1',
				'modifieddate' => date('Y-m-d H:i:s'),
				'modifiedby' => Session::get('username'),
				'modifiedip' => $_SERVER['SERVER_ADDR']	
		    );
			$result = DB::table('subcategory')
				->where('id', $id)
				->update($webpage_data);
			Session::flash('message', 'Subcategory reactived successfully!');
			Session::flash('alert-class', 'alert-success');
			return redirect()->route('admin/trashsubcategory');	
		}
	/*******************************end subcategory*************************************/
}
