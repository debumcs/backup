<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
Use Auth;
use View,
    Response,
    Validator,
    Input,
    Mail,
    Session;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesResources;
use Illuminate\Support\Facades\Redirect;
use App\model_settings;
use DB;

class Settings extends Controller
{
	public function index()
		{
			return view('admin/settings/change_password');
		}
	public function updatepassword(Request $req)
	{
		$v = Validator::make($req->all(), [
        'pre_password' => 'required',
        'new_password' => 'required',
		'con_password' => 'required'
		]);
		$username = '';
		if ($v->fails())
		{
			Session::flash('message', 'Please password entered!'); 
			Session::flash('alert-class', 'alert-danger'); 
			return redirect()->route('changepassword');
		}
		else
		{
			$pre_password = $req->input('pre_password');
			$new_password = $req->input('new_password');
			$con_password = $req->input('con_password');		
			$checklogin = DB::table('login')->where(['username'=>Session::get('username')])->first();			
			if(md5($pre_password) === $checklogin->password){
			if($req->input('new_password') === $req->input('con_password')){
				$website_data = array(
					'password'=>md5($req->input('new_password'))
				);
				$success = DB::table('login')->where('uid', $checklogin->uid)->update($website_data);
				if($success)
				{
					Session::flash('message', 'Password Changed Successfully!'); 
					Session::flash('alert-class', 'alert-success'); 
				}
				else{
					Session::flash('message', 'Error while updating password!'); 
					Session::flash('alert-class', 'alert-danger');								
				}
			}else{
				Session::flash('message', 'Confirm Password does not match!'); 
				Session::flash('alert-class', 'alert-danger');					
			}
		}
		else{
			Session::flash('message', 'Wrong Previous Password entered!'); 
			Session::flash('alert-class', 'alert-danger');	
		}
		return redirect()->route('admin/changepassword');		
		}
	}
	

}
