<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Auth;
use View,
    Response,
    Validator,
    Input,
    Mail,
	Session;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesResources;
use Illuminate\Support\Facades\Redirect;
use DB;

class Admin extends Controller
{
	/*function __construct()
	  {
		parent::__construct($this);	
		if(Session::get('uiid')!=false)
		{
			return redirect()->route('login');
		}
	  }*/
	public function index()
		{
			return view('admin/admin_home');
		}
}
