<?php
namespace App\Http\Controllers;
//use Request;
Use Auth;
use View,
    Response,
    Validator,   
    Mail,
    Session;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesResources;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use DB;

class Groupinfo extends Controller
{
	/***************************start group info************************************/
	public function addgroupinfo()
		{
			//category details
			$data['allcategory'] = DB::table('category')->where(['status'=> 1])->get();
			//subcategory details
			$data['allsubcategory'] = DB::table('subcategory')->where(['status'=> 1])->get();
			return view('admin/groupinfo/addgroupinfo', $data);
		}
	public function getsubcategorydetails()
    {
	   $category_id = Input::get('category_id');
	   echo $category_id;
	   
	   $sub_categories = DB::table('subcategory')->where(['status'=> 1])->get();
	   foreach($sub_categories as $stt)
       {
       $subcategory.='<option value="'.$stt->id.'">'.$stt->name.'</option>';
       }
	   $subcategory.='</select>';
       echo $subcategory;
	   exit;	   
    }		
	public function savegroupinfo(Request $req)
		{
			$image_name = $req->file('image')->getClientOriginalName();
            $image = $req->file('image')->move(base_path().'/public/upload/groupinfo', $image_name);
			$webpage_data = array(
				  'category_id' => Input::get('category_id'),
				  'subcategory_id' => Input::get('subcategory_id'),	
				  'format' => Input::get('format'),	
				  'dimension' => Input::get('dimension'),
				  'content' => Input::get('content'),
				  'url' => Input::get('url'),
				  'include_in' => Input::get('include_in'),	
				  'image' => $image_name,
				  'createddate' => date('Y-m-d H:i:s'),
				  'modifieddate' => date('Y-m-d H:i:s'),
				  'createdby' => Session::get('username'),
				  'modifiedby' => Session::get('username'),
				  'createdip' => $_SERVER['SERVER_ADDR'],
				  'modifiedip' => $_SERVER['SERVER_ADDR']
			  );
			$success = DB::table('groupinfo')->insert($webpage_data);  				
			Session::flash('message', 'Group Info saved successful!'); 
			Session::flash('alert-class', 'alert-success'); 		
			return redirect()->route('admin/viewgroupinfo');
		}
	public function viewgroupinfo()
		{			
			$data['allgroupinfo'] = DB::table('groupinfo as gi')
            ->join('category as c', 'gi.category_id', '=', 'c.id') 
			->join('subcategory as sb', 'gi.subcategory_id', '=', 'sb.id') 	
            ->select('gi.*', 'c.name as catname', 'sb.name as subname')
			->where(['gi.status'=> 1])
            ->get();
			return view('admin/groupinfo/viewgroupinfo', $data)->with('no', 1);
		}
	
	public function editgroupinfo($id)
		{
			//category Details
			$data['allcategory'] = DB::table('category')->where(['status'=> 1])->get();
			//subcategory details
			$data['allsubcategory'] = DB::table('subcategory')->where(['status'=> 1])->get();	
			$groupinfo = DB::table('groupinfo')->where(['id'=> $id])->first();
			return view('admin/groupinfo/editgroupinfo', compact('groupinfo'));		
		}
	public function updategroupinfo(Request $req)
		{
			$image_name = $req->file('image')->getClientOriginalName();
            $image = $req->file('image')->move(base_path().'/public/upload/groupinfo', $image_name);
		    $webpage_data = array(	
				'category_id' => Input::get('category_id'),
				'subcategory_id' => Input::get('subcategory_id'),
				'format' => Input::get('format'),
				'dimension' => Input::get('dimension'),
				'content' => Input::get('content'),	
				'url' => Input::get('url'),	
				'include_in' => Input::get('include_in'),
				'image' => $image_name,	
				'modifieddate' => date('Y-m-d H:i:s'),
				'modifiedby' => Session::get('username'),
				'modifiedip' => $_SERVER['SERVER_ADDR']	
			);			
			$success = DB::table('groupinfo')
				->where('id', Input::get('id'))
				->update($webpage_data);
			unlink(Input::get('previousimage'));		
			return redirect()->route('admin/viewgroupinfo');		
		}
	public function suspendgroupinfo($id)
		{
			$webpage_data = array(
				'status' => '0',
				'modifieddate' => date('Y-m-d H:i:s'),
				'modifiedby' => Session::get('username'),
				'modifiedip' => $_SERVER['SERVER_ADDR']	
			);
			$result = DB::table('groupinfo')
				->where('id', $id)
				->update($webpage_data);	
			Session::flash('message', 'Group Info deleted successful!'); 
			Session::flash('alert-class', 'alert-success'); 	
			return redirect()->route('admin/viewgroupinfo');		
		}
	public function trashgroupinfo()
		{			
			$data['allgroupinfo'] = DB::table('groupinfo as gi')
            ->join('category as c', 'gi.category_id', '=', 'c.id') 
			->join('subcategory as sb', 'gi.subcategory_id', '=', 'sb.id') 	
            ->select('gi.*', 'c.name as catname', 'sb.name as subname')
			->where(['gi.status'=> 0])
            ->get();
			return view('admin/groupinfo/trashgroupinfo', $data)->with('no', 1);		
		}
	public function reactivecategory($id)
		{
			$webpage_data = array(
				'status' => '1',
				'modifieddate' => date('Y-m-d H:i:s'),
				'modifiedby' => Session::get('username'),
				'modifiedip' => $_SERVER['SERVER_ADDR']	
		    );
			$result = DB::table('groupinfo')
				->where('id', $id)
				->update($webpage_data);
			Session::flash('message', 'Group Info reactived successfully!');
			Session::flash('alert-class', 'alert-success');
			return redirect()->route('admin/trashgroupinfo');	
		}
	/*******************************end category*************************************/	
}
