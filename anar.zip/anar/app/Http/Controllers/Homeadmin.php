<?php
namespace App\Http\Controllers;
//use Request;
Use Auth;
use View,
    Response,
    Validator,   
    Mail,
    Session;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesResources;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use App\model_homeadmin;
use DB;

class Homeadmin extends Controller
{
	
	public function addbanner()
		{
			return view('admin/homeadmin/addbanner');
		}	
	public function savebanner(Request $req)
		{				
			$image_name = $req->file('image')->getClientOriginalName();
            $image = $req->file('image')->move(base_path().'/public/upload/banner', $image_name);
			$webpage_data = array(
				  'title' => Input::get('title'),
				  'image' => $image_name,
				  'subtitle' => Input::get('subtitle'),
				  'createddate' => date('Y-m-d H:i:s'),
				  'modifieddate' => date('Y-m-d H:i:s'),
				  'createdby' => Session::get('username'),
				  'modifiedby' => Session::get('username'),
				  'createdip' => $_SERVER['SERVER_ADDR'],
				  'modifiedip' => $_SERVER['SERVER_ADDR']
			  );
			$success = DB::table('banner')->insert($webpage_data);  				
			Session::flash('message', 'Banner saved successful!'); 
			Session::flash('alert-class', 'alert-success'); 		
			return redirect()->route('admin/viewbanner');
		}
	public function viewbanner()
		{
			$data['allbanner'] = DB::table('banner')->where(['status'=> 1])->get();
			return view('admin/homeadmin/viewbanner', $data)->with('no', 1);
		}
	
	public function editbanner($id)
		{
			/*$banner = model_homeadmin::find($id);
			return view('admin/homeadmin/editbanner', compact('banner'));*/			
			$banner = DB::table('banner')->where(['id'=> $id])->first();
			return view('admin/homeadmin/editbanner', compact('banner'));		
		}
	public function updatebanner(Request $req)
		{
			$image_name = $req->file('image')->getClientOriginalName();
            $image = $req->file('image')->move(base_path().'/public/upload/banner', $image_name);
		    $webpage_data = array(	
				'title' => Input::get('title'),	
				'image' => $image_name,
				'subtitle' => Input::get('subtitle'),
				'modifieddate' => date('Y-m-d H:i:s'),
				'modifiedby' => Session::get('username'),
				'modifiedip' => $_SERVER['SERVER_ADDR']	
			);			
			$success = DB::table('banner')
				->where('id', Input::get('id'))
				->update($webpage_data);
			unlink(Input::get('previousimage'));		
			return redirect()->route('admin/viewbanner');		
		}
	public function suspendbanner($id)
		{
			$webpage_data = array(
				'status' => '0',
				'modifieddate' => date('Y-m-d H:i:s'),
				'modifiedby' => Session::get('username'),
				'modifiedip' => $_SERVER['SERVER_ADDR']	
			);
			$result = DB::table('banner')
				->where('id', $id)
				->update($webpage_data);	
			Session::flash('message', 'Banner deleted successful!'); 
			Session::flash('alert-class', 'alert-success'); 	
			return redirect()->route('admin/viewbanner');		
		}
	public function trashbanner()
		{
			$data['allbanner'] = DB::table('banner')->where(['status'=> 0])->get();
			return view('admin/homeadmin/trashbanner', $data)->with('no', 1);		
		}
	public function reactivebanner($id)
		{
			$webpage_data = array(
				'status' => '1',
				'modifieddate' => date('Y-m-d H:i:s'),
				'modifiedby' => Session::get('username'),
				'modifiedip' => $_SERVER['SERVER_ADDR']	
		    );
			$result = DB::table('banner')
				->where('id', $id)
				->update($webpage_data);
			Session::flash('message', 'Banner reactived successfully!');
			Session::flash('alert-class', 'alert-success');
			return redirect()->route('admin/trashbanner');	
		}
}
