<?php

namespace App\Http\Middleware;

use Closure;
//use Illuminate\Session\Storeexits;
use Illuminate\Session\Store;
//use App\Extensions\MongoSessionStore;
class CheckUserSession
{

    public function handle($request, Closure $next)
    {
        //if (!$request->session()->exists('username')) {
			if (!$request->session()->exists('username')) {
            // user value cannot be found in session
            return redirect()->route('login');
        }

        return $next($request);
    }

}