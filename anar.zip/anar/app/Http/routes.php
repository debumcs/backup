<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
/**********start login**************/
Route::get('login','Login@index')->name('login');
Route::post('login_check', 'Login@login_check');
Route::get('admin', 'Admin@index')->name('admin');
Route::get('logout', 'Login@logout');
Route::get('admin/changepassword', 'Settings@index')->name('admin/changepassword');
Route::post('updatepassword', 'Settings@updatepassword');
/********** end login **************/


/************************start banner******************************/
Route::get('admin/addbanner', 'Homeadmin@addbanner')->name('addbanner');
Route::post('savebanner', 'Homeadmin@savebanner');
Route::get('admin/viewbanner', 'Homeadmin@viewbanner')->name('admin/viewbanner');
Route::get('admin/editbanner/{id}', 'Homeadmin@editbanner')->name('admin/editbanner/{id}');
Route::post('updatebanner', 'Homeadmin@updatebanner');
Route::get('admin/suspendbanner/{id}', 'Homeadmin@suspendbanner')->name('admin/suspendbanner/{id}');
Route::get('admin/trashbanner', 'Homeadmin@trashbanner')->name('admin/trashbanner');
Route::get('admin/reactivebanner/{id}', 'Homeadmin@reactivebanner')->name('admin/reactivebanner/{id}');
/************************end banner******************************/

/************************start category******************************/
Route::get('admin/addcategory', 'Category@addcategory')->name('addcategory');
Route::post('savecategory', 'Category@savecategory');
Route::get('admin/viewcategory', 'Category@viewcategory')->name('admin/viewcategory');
Route::get('admin/editcategory/{id}', 'Category@editcategory')->name('admin/editcategory/{id}');
Route::post('updatecategory', 'Category@updatecategory');
Route::get('admin/suspendcategory/{id}', 'Category@suspendcategory')->name('admin/suspendcategory/{id}');
Route::get('admin/trashcategory', 'Category@trashcategory')->name('admin/trashcategory');
Route::get('admin/reactivecategory/{id}', 'Category@reactivecategory')->name('admin/reactivecategory/{id}');
/************************end category******************************/

/************************start subcategory******************************/
Route::get('admin/addsubcategory', 'Category@addsubcategory')->name('addsubcategory');
Route::post('savesubcategory', 'Category@savesubcategory');
Route::get('admin/viewsubcategory', 'Category@viewsubcategory')->name('admin/viewsubcategory');
Route::get('admin/editsubcategory/{id}', 'Category@editsubcategory')->name('admin/editsubcategory/{id}');
Route::post('updatesubcategory', 'Category@updatesubcategory');
Route::get('admin/suspendsubcategory/{id}', 'Category@suspendsubcategory')->name('admin/suspendsubcategory/{id}');
Route::get('admin/trashsubcategory', 'Category@trashsubcategory')->name('admin/trashsubcategory');
Route::get('admin/reactivesubcategory/{id}', 'Category@reactivesubcategory')->name('admin/reactivesubcategory/{id}');
/************************end subcategory******************************/

/************************start groupinfo******************************/
Route::get('admin/addgroupinfo', 'Groupinfo@addgroupinfo')->name('addgroupinfo');
Route::post('admin/getsubcategorydetails', 'Groupinfo@getsubcategorydetails')->name('admin/getsubcategorydetails');
 /*Route::post('/getsubcategorydetails',array('as'=>'getsubcategorydetails',
    'uses'=>'Groupinfo@getsubcategorydetails'));*/
Route::post('savegroupinfo', 'Groupinfo@savegroupinfo');
Route::get('admin/viewgroupinfo', 'Groupinfo@viewgroupinfo')->name('admin/viewgroupinfo');
Route::get('admin/editgroupinfo/{id}', 'Groupinfo@editgroupinfo')->name('admin/editgroupinfo/{id}');
Route::post('updategroupinfo', 'Groupinfo@updategroupinfo');
Route::get('admin/suspendgroupinfo/{id}', 'Groupinfo@suspendgroupinfo')->name('admin/suspendgroupinfo/{id}');
Route::get('admin/trashgroupinfo', 'Groupinfo@trashgroupinfo')->name('admin/trashgroupinfo');
Route::get('admin/reactivegroupinfo/{id}', 'Groupinfo@reactivegroupinfo')->name('admin/reactivegroupinfo/{id}');
/************************end groupinfo******************************/

Route::get('welcome', function () {
    return view('welcome');
});
/*Route::group(['middleware' => 'usersession'], function () {
	Route::get('admin/addbanner', 'Homeadmin@addbanner')->name('addbanner');
});*/
