<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class model_settings extends Model
{
    protected $fillable = ['password'];
}
