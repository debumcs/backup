<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class model_homeadmin extends Model
{
    protected $fillable = ['title', 'subtitle'];
}
