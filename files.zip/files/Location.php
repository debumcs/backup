<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Location extends CI_Controller {
	
	public function __construct() {
        parent::__construct();
		validateToken();
		$this->load->model('LocationModel','LocationModel');
	}
	
	public function create_location()
	{
		$data1 = array();
		$data['body'] = $this->load->view('location/create_location', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function getAllAccounts(){
		validateToken();
		$filters = array(
			array("key"=>"AccountType","value"=>$this->input->post('accountType')),
			array("key"=>"AccountId","value"=>$this->input->post('accountId')),
			array("key"=>"AccountName","value"=>$this->input->post('accountName')),
			array("key"=>"AccountNickName","value"=>$this->input->post('accountNickName')),
			array("key"=>"AccountRef","value"=>$this->input->post('accountRef')),
			array("key"=>"State","value"=>$this->input->post('accountState')),
			array("key"=>"City","value"=>$this->input->post('accountCity')),
			array("key"=>"AccountStatus","value"=>$this->input->post('accountStatus'))
		);
		
		$out = $this->LocationModel->getAccountList($filters);
		echo json_encode($out);
	}
	
}