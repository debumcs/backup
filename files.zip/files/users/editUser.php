<div class="content-wrapper" ng-controller="editUserCtrl">
<section class="content-header">
    <h1>User Management</h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">User Management</a></li>
      <li class="active">Create User</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- SELECT2 EXAMPLE -->
    <div class="box box-primary">
      <div class="box-header with-border">
    <h3 class="box-title"><b>Edit User</b></h3>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
	  <?php //echo '<pre>';print_r($userDetails);echo '</pre>'; ?>
	  
          <form autocomplete="off" novalidate name="userForm" ng-submit="updateUser()">
              <div class="row">
                <div class="col-md-12 col-lg-12 col-sm-12">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Username</label>
						<input type="hidden" name="userNo" id="userNo" value="<?php echo $userDetails["responseObject"]["userId"]; ?>">
                        <input type="text" ng-model="userData.userName" readonly name="userName" id="userName" class="form-control" placeholder="Enter username">
                        <div ng-if="submitted && userForm.userName.$invalid" class="invalid-feedback">
                          <span ng-if="userForm.userName.$error.required">Username required</span>
                          <span ng-if="userForm.userName.$error.pattern">Enter valid characters. </span>
                          
                        </div>
                      </div>
                    </div>
                  <!-- /.form-group -->
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Employee Number</label>
                        <input type="text" ng-model="userData.employeeNumber" name="employeeNumber" id="employeeNumber" class="form-control" placeholder="Enter employee number">
                        <div ng-if="submitted && userForm.employeeNumber.$invalid" class="invalid-feedback">
                          <span ng-if="userForm.employeeNumber.$error.pattern">Enter valid characters. </span>
                        </div>
                      </div>
                    </div>					
                  <!-- /.form-group -->
                  </div>
                  
                  <div class="row">			
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>First Name</label>
                        <input type="text" ng-model="userData.firstName" readonly name="firstName" id="firstName" class="form-control" placeholder="Enter first name">
                        <div ng-if="submitted && userForm.firstName.$invalid" class="invalid-feedback">
                          <span ng-if="userForm.firstName.$error.required">Last Name required. </span>
                          <span ng-if="userForm.firstName.$error.pattern">Enter valid characters. </span>
                          </div>
                      </div>
                    </div>
                  <!-- /.form-group -->
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" ng-model="userData.lastName" readonly name="lastName" id="lastName" class="form-control" placeholder="Enter last name">
                        <div ng-if="submitted && userForm.lastName.$invalid" class="invalid-feedback">
                          <span ng-if="userForm.lastName.$error.required">Last Name required. </span>
                          <span ng-if="userForm.lastName.$error.pattern">Enter valid characters. </span>
                        </div>
                      </div>
                    </div>					
                  <!-- /.form-group -->
                  </div>
                  
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Email Address</label>
                        <input type="text" ng-model="userData.email" readonly name="email" id="email" class="form-control" placeholder="Enter email">
                        <div ng-if="submitted && userForm.email.$invalid" class="invalid-feedback">
                          <div ng-if="userForm.email.$error.required">Email required</div>
                        </div>
                      </div>
                    </div>
                  <!-- /.form-group -->
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Phone Number</label>
                        <!-- <input type="text" name="address" id="address" class="form-control" placeholder="Enter phone number"> -->
                        <div class="input-group">
                          <span class="input-group-addon">+1</span>
                          <input type="text" ng-model="userData.phoneNumber" required name="phoneNumber" id="phoneNumber" class="form-control" placeholder="Enter phone number">
                        </div>
                        <div ng-if="submitted && userForm.phoneNumber.$invalid" class="invalid-feedback">
                          <span ng-if="userForm.phoneNumber.$error.required">Phone Number required. </span>
                          <span ng-if="userForm.phoneNumber.$error.minlength">Enter 10 digit phone number. </span>
                          <span ng-if="userForm.phoneNumber.$error.maxlength">Enter 10 digit phone number. </span>
                          <span ng-if="userForm.phoneNumber.$error.pattern">Enter digits only. </span>
                          </div>
                      </div>
                    </div>					
                  <!-- /.form-group -->
                  </div>
                  
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Role</label>
                        <select ng-model="userData.roleId" required name="roleId" id="roleId" class="form-control">
                          <option value="" selected>Select Role</option>
                          <option ng-repeat='role in roleTypes' ng-selected="userInfo.roleId==role.roleId" value="{{role.roleId}}">{{role.roleDesc}}</option>
                        </select>
                        <div ng-if="submitted && userForm.roleId.$invalid" class="invalid-feedback">
                            <div ng-if="userForm.roleId.$error.required">Role required</div>
                          </div>
                      </div>
                    </div>

                    <div class="col-md-6" ng-if="userForm.userStatus.value !=2">
                      <div class="form-group">
                        <label>Status</label>
                        <select ng-model="userData.userStatus" required name="userStatus" id="userStatus" class="form-control">
                        <option ng-repeat="status in allStatus" value="{{status.id}}" ng-selected="userInfo.userStatus==status.id">{{status.statusDesc}}</option>
                        </select>
                        <div ng-if="submitted && userForm.userStatus.$invalid" class="invalid-feedback">
                            <div ng-if="userForm.userStatus.$error.required">Status required</div>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>
                      <input type="hidden" ng-model="userData.userId" name="userId" id="userId" />
                      <input type="hidden" ng-model="userData.accountId" name="accountId" id="accountId" />
                      <button type="submit" class="btn btn-primary">Update</button>
                      </label>&nbsp;&nbsp;&nbsp;
                      
                    <label><a href="<?php echo base_url(); ?>Users/viewAllUsers" class="btn btn-danger">Cancel</a></label>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="invalid-feedback" ng-if="errorMsg" >
                    {{errorMsg}}
                  </div>
                </div>
              </div>
              
            </form>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  <!-- /.row -->
</section>
</div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/users/editUserCtrl.js"></script>