<?php 
require_once('nuSOAP/lib/nusoap.php');
include "functions.php";

$namespace = "http://10.100.8.37/renewalwebservice/WS1/";
$server = new soap_server();
$server->configureWSDL('BayWalk_WebService');

// Checklist User Data Entry
function checkPromoCode($promocode)
{
	// Start Compose mail message
	$subject="Error checkPromoCode Webservice | Renewal Customer";
	$ErrorMessage= "Hi,<br><br>Following Error occured in Executing Webservice Function checkPromoCode <br><br>";
	$ErrorMessage .= "<br> ErrorMessageDesc <br>";        
	$ErrorMessage .= "<br/>***** Calling checkPromoCode at ".date('d-m-Y H:i:s')." *******<br>";
	$ErrorMessage .= "Parameters are promocode : ".$promocode.".<br/>";

	$result = getfunctionOutput('checkPromoCode', $promocode); 
	return  $result;
	//return array('days'=>$promocode,'msg'=>'Activation key Not Found! '.$promocode);
}

$server->register(
                // method name:
                'checkPromoCode', 	
                // parameter list:
                array('promocode'=>'xsd:string'),
				//array('email'=>'xsd:string'),
				// return value(s):
                array('return'=>'tns:checkPromoCodeOutput'),
				//  array('return'=>'xsd:string'),	
                // namespace:
                $namespace,
                // soapaction: (use default)
                false,
                // style: rpc or document
                'rpc',
                // use: encoded or literal
                'encoded',
                // description: documentation for the method
                'promocode registration only process');

$server->wsdl->addComplexType('checkPromoCodeOutput','complexType','struct','all','',array(
				'days' => array('name' => 'days', 'type' => 'xsd:string'),
				'msg' => array('name' => 'msg', 'type' => 'xsd:string'))	
);

$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
$server->service($HTTP_RAW_POST_DATA);
?>