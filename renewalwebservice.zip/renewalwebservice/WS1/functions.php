<?php
include('config.php');
function webserviceOBJ()
{
	$client = new nusoap_client('http://10.100.8.37/renewalwebservice/WS2/ws_renewalpromocode_final.php?wsdl', true);
	return  $client;
}

function getfunctionOutput($function,$promocode)
{
	switch ($function)
	{
		case 'checkPromoCode':        
			$client=webserviceOBJ();
			$result = $client->call($function,array('promocode'=>$promocode)); 
			if ($client->fault){
				return array('days'=>'-1','msg'=>'Client Not connected');
			}else{
				$err = $client->getError();
				if($err){
					return array('days'=>'-1','msg'=>'Error:'.$err);
				}else{
					return $result;
				}
			}
			break;
		default :
			return array('days'=>'-1','msg'=>'Error : Function not found.');
			break;
	}
}


function Errorinws($ErrorMessage)
{
	$array1=array('errorFlag'=>True,'ErrorFlag'=>True,'errorDescription'=>$ErrorMessage,'errorDesctiption'=>$ErrorMessage,'Desctiption'=>$ErrorMessage,'Description'=>$ErrorMessage);
	return  $array1;
}   

function WriteLogCsv($promocode,$result,$txntype)
{
	$csvheader="CreatedON,TxnType,Result,parent_id";
	$path=csvpath;        
	$filename=$path.date('d-m-Y').".txt";
	
	$data=date('m-d-Y H:i:s').",".$txntype.",".$result['errorDescription'].",".$promocode['parent_id'];
        
	$fp = fopen($filename,"a");
	if($fp){
		if(filesize($filename)>0)
			fwrite($fp,"\n".$data); 
		else
			fwrite($fp,$csvheader."\n".$data); 
		fclose($fp); 
	}

}

function SendMail($subject,$error)
{
    $headers .= "From: checklist@quatrro.com\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
    $x=mail(TO,$subject,$error,$headers);
}

function getUserIpAddr()
{
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) //if from shared
    {
        return $_SERVER['HTTP_CLIENT_IP'];
    }
    else if (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //if from a proxy
    {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
        return $_SERVER['REMOTE_ADDR'];
    }
}

?>