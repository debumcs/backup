<?php
require_once("nuSOAP/lib/nusoap.php");

$namespace = "http://10.100.8.37/renewalwebservice/WS2/";
$server    = new soap_server();
$server->configureWSDL('BayWalk_WebService');

// Checklist User Data Entry
function checkPromoCode($promocode)
{
	include("adminconfig_new.php");
	$query1 = "SELECT DATEDIFF(NOW(), entry_date) AS days FROM renewal_customer_email WHERE activation_key = '".$promocode."' AND mailflag = '0'";
	
	$msg1 = mysql_query($query1);						

	if(mysql_num_rows($msg1) > 0)
	{
		$rowmsg1=mysql_fetch_assoc($msg1);
		
		if(($rowmsg1['days'] >= 0) and ($rowmsg1['days'] <= 15)){
			return array('days'=>$rowmsg1['days'],'msg'=>'Valid Activation key'.$query1);
		}else{
			return array('days'=>'-1','msg'=>'Activation key has been expired !'.$rowmsg1['days']);
		}
	}
	else{
		return array('days'=>'-1','msg'=>'Activation key Not Found! '.$query1);
	}  
}

$server->register(
                // method name:
                'checkPromoCode', 	
                // parameter list:
                array('promocode'=>'xsd:string'),
				// return value(s):
                array('return'=>'tns:checkPromoCodeOutput'),
				// namespace:
                $namespace,
                // soapaction: (use default)
                false,
                // style: rpc or document
                'rpc',
                // use: encoded or literal
                'encoded',
                // description: documentation for the method
                'promocode registration only process');

$server->wsdl->addComplexType('checkPromoCodeOutput','complexType','struct','all','',array(
				'days' => array('name' => 'days', 'type' => 'xsd:string'),
				'msg' => array('name' => 'msg', 'type' => 'xsd:string'))	
);

$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
$server->service($HTTP_RAW_POST_DATA);
?>