<?php

$servername='10.100.4.50';     // Your MySql Server Name or IP address here
$dbusername='root';            // Login user id here
$dbpassword='Saimaa#2010';     // Login password here
$dbname='qresolve';    

// Your database name here
define('servername','10.100.4.50');
define('dbusername','root');
define('dbpassword','Saimaa#2010');
define('dbname','qresolve');

$con = mysql_connect($servername,$dbusername,$dbpassword);
if (!$con)
  {
  //die('Could not connect: ' . mysql_error());
  die('Could not connect... Please Try after Some time.');
  }

mysql_select_db($dbname, $con);
$coni = new MySQLI($servername,$dbusername,$dbpassword,$dbname);

$GLOBALS["df_small"]	= "d-m-Y";
$GLOBALS["df_big"] 	= "d-m-Y H:i:s";



?>
