<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

	if(isset($_POST['submit'])){
			
		$promocode 			= $_POST['promocode'];
		$action_date 		= date('Y-m-d H:i:s');
		
		require_once('nuSOAP/lib/nusoap.php');
		$client = new nusoap_client('http://10.100.8.37/renewalwebservice/WS1/ws_renewalpromocode.php?wsdl', true);
		
		$result = $client->call('checkPromoCode',array('promocode'=>$promocode));
		
		if($client->fault) 
		{ 
			echo $msg = 'Error during Client initialization';
		} 
		else
		{ 
			$err = $client->getError();
			if ($err) 
			{  
				echo $msg = '<h2>Error</h2>'. $err;
			} 
			else 
			{
				$msg = $result;
			}
		}
		
		echo '<pre>';
		print_r($result);
		echo '</pre>';
		exit;
	}
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Renewal Customer</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" href="favicon.ico">

  	<!-- Bootstrap -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Theme Style -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Google Webfont -->
	<link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
	
	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	<script type="text/javascript">
	function submitform(){
		if(document.getElementById('promocode').value == '')
		{
			alert('Please enter promocode.');
			document.getElementById('promocode').value = '';
			document.getElementById('promocode').focus();
			return false;
		}
		else{
			return true;
		}			
	}
	</script>
	<style>
		.black_overlay{
			display: none;
			position: absolute;
			top: 0%;
			left: 0%;
			width: 100%;
			height: 100%;
			background-color: black;
			z-index:1001;
			-moz-opacity: 0.8;
			opacity:.80;
			filter: alpha(opacity=80);
		}
		
		.white_content {
			display: none;
			width: 40%;
			padding: 16px;
			border: 16px solid rgba(216, 69, 72, 0.62);
			background-color: white;
			z-index:1002;
			overflow: auto;
			border-radius: 5px;
			position: fixed;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			transform: -webkit-translate(-50%, -50%);
			transform: -ms-translate(-50%, -50%);
			text-align:center;
		}
	</style>
	</head>
	<body>
	<?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){?>
	<script>
		$('#success').html('<?php echo $_SESSION['msgD']?>');
	</script>
	<?php } unset($_SESSION['msgD']);?>
	
	<header role="banner">
		<img id="logo-main" src="img/QLogo2.gif" alt="">
	</header>

	<section class="heading">
		<div class="container" style="text-align: center;">
			<div class="row">
				<div class="col-md-8 col-md-offset-2">
					&nbsp;
				</div><!-- END col -->
			</div><!-- END row -->
		</div><!-- END container -->
	</section>
	
	<div id="success">
	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="checklist" id="form1">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-sm-12 col-xs-12" style="text-align:right;">
					<p>
					  <label for="test11">Enter Promo Code:</label>
						<input type="text" id="promocode" name="promocode" value="" />						
					 </p>
				</div><!-- END col -->
				 
				<div class="col-md-6 col-sm-12 col-xs-12" style="text-align:left;">
					<input type="submit" id="submit" name="submit" onclick="return submitform();" class="btn btn-outline btn-lg" value="SUBMIT" />
				</div><!-- END col -->
			</div><!-- END row -->
			
		</div><!-- END container -->
	</form>
	</div>
	<footer id="footer">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<p>© 2016 Qresolve All Rights Reserved. </p>
				</div>
			</div><!-- END row -->
		</div><!-- END container -->
	</footer>
<!-- jQuery -->
<script src="js/jquery-1.10.2.min.js"></script>
<!-- Bootstrap -->
<script src="js/bootstrap.js"></script>
<!-- Main JS -->
<script src="js/main.js"></script>
</body>
</html>