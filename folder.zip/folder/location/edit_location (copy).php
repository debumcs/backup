<div class="content-wrapper" ng-controller="editLocationCtrl">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Edit Location</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Location</a></li>
        <li class="active">Edit Location</li>
      </ol>
    </section>
    <section class="content form-page">
		<div class="box">
		<div class="box-body">
			<form autocomplete="off" novalidate name="locationForm" ng-submit="updateLocation()">
			<div class="padleftright20">
				<div class="accordion-option">
					<a href="javascript:void(0)" class="toggle-accordion active" accordion-id="#accordion"></a>
				</div>
				<div class="clearfix"></div>
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
								Location Details
								</a>
							</h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
							<div class="panel-body">
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Location Type</label>
											<input type="hidden" name="locationId" id="locationId" ng-model="locationData.locationId" />
											<select class="form-control" disabled>
											<option value="">Select Location</option>
											<?php 
											foreach($locationTypes as $value){
												if($locationDetails["locationType"] == $value->id){
													echo '<option value="'.$value->id.'" selected="selected">'.$value->locationType.'</option>';
												}else{
													echo '<option value="'.$value->id.'">'.$value->locationType.'</option>';
												}												
											}
											?>
											</select>
											<input type="hidden" id="locationType" name="locationType" class="form-control" value="<?php echo $locationDetails["locationType"];?>">
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label>Ref#</label>
													<input type="text" name="referenceCode" readonly id="referenceCode" class="form-control" value="<?php echo $locationDetails["referenceCode"];?>">
												</div>
											</div>
											
											<div class="col-md-6">
												<div class="form-group">
													<label>Unit Number</label>
													<input type="text" name="unitNumber" id="unitNumber" class="form-control" value="<?php echo $locationDetails["unitNumber"];?>">
												</div>
											</div>
										</div>
									</div>
									
								</div>
								
								<div class="row">					
									<div class="col-md-6">
										<div class="form-group">
											<label>Location Name</label>
											<input type="text" name="locationName" readonly required id="locationName" class="form-control" value="<?php echo $locationDetails["locationName"];?>">
										</div>
									</div>					
								<!-- /.form-group -->
											
									<div class="col-md-6">
										<div class="form-group">
											<label>Location Nickname</label>
											<input type="text" name="nickName" id="nickName" class="form-control" value="<?php echo $locationDetails["nickName"];?>">
										</div>
									</div>	
								</div>
								
								<div class="row">	
									<div class="col-md-6">
										<div class="form-group">
											<label>Address 1</label>
											<input type="text" name="addressLine1" readonly required id="addressLine1" class="form-control" value="<?php echo $locationDetails["addressLine1"];?>">
										</div>
									</div>
								
									<div class="col-md-6">
										<div class="form-group">
											<label>Address 2</label>
											<input type="text" name="addressLine2" id="addressLine2" class="form-control" value="<?php echo $locationDetails["addressLine2"];?>">
										</div>
									</div>	
								</div>
								
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Zip Code</label>
											<input type="text" name="zipCode" readonly required id="zipCode" class="form-control" value="<?php echo $locationDetails["zipCode"];?>">
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="form-group">
											<label>Country</label>
											<select class="form-control" disabled style="width: 100%;" onchange="getStates(this.value)">
											<option value="">Select Country</option>
											<option selected="selected" value="1">USA</option>
											</select>
											<input type="hidden" id="country" name="country" class="form-control" value="1">
										</div>
									</div>
									
								</div>
								
								<div class="row">										
									<div class="col-md-6">
										<div class="form-group">
											<label>State</label>
											<select class="form-control select2" disabled onchange="getCities(this.value)" style="width: 100%;">
											<?php foreach($stateList as $state){
													if($locationDetails["state"] == $state->id){
															echo '<option value="'.$state->id.'" selected="selected">'.$state->stateName.'</option>';
														}else{
															echo '<option value="'.$state->id.'">'.$state->stateName.'</option>';
														}
													}
											?>
											</select>
											<input type="hidden" id="state" name="state" class="form-control" value="<?php echo $locationDetails["state"]; ?>">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>City</label>
											<select class="form-control select2" disabled style="width: 100%;">
											<?php foreach($cityList as $city){
													if($locationDetails["city"] == $city->id){
															echo '<option value="'.$city->id.'" selected="selected">'.$city->cityName.'</option>';
														}else{
															echo '<option value="'.$city->id.'">'.$city->cityName.'</option>';
														}
													}												
											?>
											</select>
											<input type="hidden" id="city" name="city" class="form-control" value="<?php echo $locationDetails["city"]; ?>">
										</div>
									</div>	
								</div>
								
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Business Phone</label>
											<div class="input-group">
												<span class="input-group-addon">+1</span>
												<input type="text" name="businessPhone" id="businessPhone" class="form-control" value="<?php echo $locationDetails["businessPhone"];?>">
											</div>	
										</div>						
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Fax</label>
											<div class="input-group">
												<span class="input-group-addon">+1</span>
												<input type="text" name="fax" id="fax" class="form-control" value="<?php echo $locationDetails["fax"];?>" />
											</div>
										</div>
									</div>	
								<!-- /.form-group -->
								</div>
								
								<div class="row">					
									<div class="col-md-6" id="time-range">
										<div class="row">
											<div class="col-md-3"><label>Days Open</label></div>
											<div class="col-md-9" style="text-align: center;"><label><center>Operational hours</center></label></div>
										</div>
										<div class="row">
											<div class="col-md-3"><label>&nbsp;</label></div>
											<div class="col-md-9">
												<div class="col-md-7"><label>From Time</label></div>
												<div class="col-md-5"><label>To Time</label></div>
											</div>
										</div>
										<div class="row">
											<?php
											$allweekdays = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"];
											$collectedweekdays = [];
											foreach($locationDetails["operationalHours"] as $value){
												$collectedweekdays[] = $value["day"];
											}							
											?>
											<div class="col-md-3">
												<select class="form-control" id="selectday">
													<option value="All">All</option>
													<option value="Monday">Monday</option>
													<option value="Tuesday">Tuesday</option>
													<option value="Wednesday">Wednesday</option>
													<option value="Thursday">Thursday</option>
													<option value="Friday">Friday</option>
													<option value="Saturday">Saturday</option>
													<option value="Sunday">Sunday</option>
												</select>
											</div>
											<div class="col-md-3">
												<div class="input-group">
													<input type="time" id="fromtime" class="form-control" value="" />
												</div>
											</div>												
											<div class="col-md-1">&nbsp;</div>
											<div class="col-md-3">
												<div class="input-group">
													<input type="time" id="totime" class="form-control" value="" />
												</div>
											</div>
											<div class="col-md-2"><button type="button" onclick="append_day()" class="btn btn-info btn-sm"><span class="glyphicon glyphicon-plus"></span></button></div>
										</div>
											
										<div class="row" id="example">											
											<?php foreach($locationDetails["operationalHours"] as $value){?>
											<div class="parent"><div class="col-md-3 weekday"><input type="hidden" class="day" name="weekdays[]" value="<?php echo $value["day"]; ?>" /><?php echo $value["day"]; ?></div><div class="col-md-3"><div class="input-group"><input type="time" name="fromtime_<?php echo $value["day"]; ?>" id="fromtime_<?php echo $value["day"]; ?>" value="<?php echo date("H:i", strtotime($value["startTime"])); ?>" class="form-control"></div></div><div class="col-md-1">&nbsp;</div><div class="col-md-3"><div class="input-group"><input type="time" name="totime_<?php echo $value["day"]; ?>" id="totime_<?php echo $value["day"]; ?>" value="<?php echo date("H:i", strtotime($value["endTime"])); ?>" class="form-control"></div></div><span class="child col-md-2"><button type="button" class="btn btn-danger btn-sm"><i class="glyphicon glyphicon-minus"></i></button></span></div>
											<?php } ?>
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="form-group">
											<label>Contact Email</label>
											<input type="text" name="contactEmail" required id="contactEmail" class="form-control" value="<?php echo $locationDetails["contactEmail"];?>">
										</div>
										
										<div class="form-group">
											<label>Contact Name</label>
											<input type="text" name="contactName" required id="contactName" class="form-control" value="<?php echo $locationDetails["contactName"];?>">
										</div>
									
										<div class="form-group">
											<label>Contact Phone</label>
											<div class="input-group">
												<span class="input-group-addon">+1</span>
												<input type="text" name="contactPhone" required id="contactPhone" class="form-control" value="<?php echo $locationDetails["contactPhone"];?>">
											</div>											
										</div>
										<div class="form-group">
											<label>Status</label>
											<select class="form-control" id="status" name="status">
												<option value="0" <?php if($locationDetails["status"]==0)echo 'selected'; ?>>Inactive</option>
												<option value="1" <?php if($locationDetails["status"]==1)echo 'selected'; ?>>Active</option>
												<option value="2" <?php if($locationDetails["status"]==2)echo 'selected'; ?>>Pending</option>
											</select>
										</div>
									</div>
								</div>								
							</div>
						</div>
					</div>
						
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingTwo">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
								Associations
								</a>
							</h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
							<div class="panel-body">
								<div class="row">
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account Type</label>
											<select class="form-control input-md" id="assoAccounttype" onchange="getAccountAssoc();" width="100%" name="assoAccounttype">
											<option value="" selected>Select Account</option>
											<?php 
											foreach($accountTypes as $value){
												echo '<option value="'.$value->id.'">'.$value->accountType.'</option>';
											}
											?>
											</select>
										</div>
									</div>
									
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account#</label>
											<input type="text" name="assoAccountNo" id="assoAccountNo" onkeyup="getAccountAssoc();" class="form-control input-sm" value="">
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account Name</label>
											<input type="text" name="assoAccountName" id="assoAccountName" onkeyup="getAccountAssoc();" class="form-control input-sm" value="">
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account Ref #</label>
											<input type="text" name="assoAccountRef" id="assoAccountRef" onkeyup="getAccountAssoc();" class="form-control input-sm" value="">
										</div>
									</div>	
									
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account Nickname</label>
											<input type="text" name="assoAccountNickname" id="assoAccountNickname" onkeyup="getAccountAssoc();" class="form-control input-sm" value="">
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>State</label>
											<input type="text" name="assoAccountState" id="assoAccountState" onkeyup="getAccountAssoc();" class="form-control input-sm" value="">
										</div>
									</div>
								</div>
								
								<div class="row" id="showhidetable2">								
									<div class="col-lg-12">
										<table id="example1" class="table table-bordered table-striped ">
											<thead>
												<tr>
													<th>#</th>
													<th>Account #</th>
													<th>Account Name</th>
													<th>Account Nickame</th>
													<th>Account Ref #</th>
													<th>Account Type</th>													
													<th>Address</th>
													<th>City</th>
													<th>State</th>
													<th>Status</th>
												</tr>
											</thead>
											<tbody id="accountAssociation">
												<?php foreach($locationDetails["associatedAccounts"] as $value){ ?>
												<tr>
													<td align="center"><input type="checkbox" checked name="assoAcounts[]" value="<?php echo $value["accountId"]; ?>" /></td>
													<td><?php echo $value["accountId"]; ?></td>
													<td><?php echo $value["companyName"]; ?></td>
													<td><?php echo $value["nickName"]; ?></td>
													<td><?php echo $value["referenceCode"]; ?></td>
													<td><?php echo $value["accountTypeDetails"]["accountType"]; ?></td>
													<td><?php echo $value["addressLine1"]; ?> <?php echo $value["addressLine2"]; ?></td>
													<td><?php echo $value["cityDetails"]["cityName"]; ?></td>
													<td><?php echo $value["stateDetails"]["stateName"]; ?></td>
													<td><?php echo $value["accountStatusDetails"]["statusDesc"]; ?></td>
												</tr>
											<?php } ?>
											</tbody>
										</table>	
									</div>
								</div>								
							</div>
						</div>
					</div>					
				</div>
				
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>
								<input type="hidden" name="locationId" id="locationId" value="<?php echo $locationDetails["locationId"]; ?>" />
								<button type="submit" class="btn btn-primary">Update</button>
							</label>
							<label>
								<button type="reset" class="btn btn-danger">Cancel</button>
							</label>
						</div>
					</div>
				</div>
				
			</div>
			</form>
		</div>
		</div>
    </section>
    <!-- /.content -->
</div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/locations/editLocationCtrl.js"></script>