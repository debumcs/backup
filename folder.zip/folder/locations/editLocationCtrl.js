myApp.controller('editLocationCtrl', function($scope,$http,$filter) {
	
	$scope.pageTitle 	= "Edit Location";
	$scope.locationData = {};
	$scope.locationInfo = {};
	
	$scope.locationNumber = document.getElementById("locationId").value;
	
	$scope.errorMsg = '';
	$scope.accountTypes = [];
	$scope.locationTypes = [];
	$scope.allAccountStatus = [];
	$scope.allCountries = [];
	$scope.allStates = [];
	$scope.allCities = [];
	$scope.operationalHoursArr = [];
	
	$scope.allLocationStatus = [];
	$scope.allAccountList = [];
	
	$scope.submitted = false;
	$scope.shortName = false;
	$scope.showMsgs = false;
	$scope.timeSelect = false;
	//$scope.IsCreateOrder = true;
	$scope.editorEnabled = false;
	
	$scope.accountOptions = { paging:false, searching:false, info:false, scrollY:'200px', scrollX:true };

	$scope.order = { All: 0, Sunday: 1, Monday: 2, Tuesday: 3, Wednesday: 4, Thursday: 5, Friday: 6, Saturday: 7 };
	
	$scope.weekdaysviews = ["All","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

  	$scope.weekdays = [ "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" ];

	$scope.append_dayNg = function(day,startTime,endTime){

		if(day===null){return false;}

		if(day=="Select Day" || startTime==undefined || endTime==undefined){
			$scope.timeSelect = true;
			return false;	
		}else{
			$scope.timeSelect = false;
		}
		
	    if(day == 'All'){
	      for(i=0;i<$scope.weekdays.length;i++) { 
	        $scope.operationalHoursArr.push(
	        	{'dayarray' : $scope.weekdays[i], 'fromtimearray' : startTime, 'totimearray' : endTime}
	        );
	      }
	      $scope.weekdaysviews = [];
	    }else{
	      $scope.operationalHoursArr.push({'dayarray' : day, 'fromtimearray' : startTime, 'totimearray' : endTime});
	      $scope.removeWeekDay("All");
	      $scope.removeWeekDay(day);
	    }
	    console.log($scope.weekdaysviews);
	}

	$scope.removeWeekDay = function(opday){
	    for(var i=0; i < $scope.weekdaysviews.length; i++){
	      if($scope.weekdaysviews[i]==opday){
	        $scope.weekdaysviews.splice(i,1);
	      }
	    }
	}

	$scope.deleteOperationalDayNg = function(index,dayname) {

		$scope.weekdaysviews.push(dayname);

	    if($scope.weekdaysviews.length == 7 ){
	     	$scope.weekdaysviews.push("All");
	    }
	    //var index = $scope.operationalHoursArr.findIndex( record => record.dayarray == dayname );
	    
        $scope.operationalHoursArr.splice(index,1);

        $scope.weekdaysviews.sort(function (a, b){
			return $scope.order[a] - $scope.order[b];
		});
	}
	
	$http.get(appBaseUrl + '/Common/get_location_type').success(function(response){
		$scope.locationTypes = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Common/get_account_type').success(function(response){
		$scope.accountTypes = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Common/get_location_status').success(function(response){
		$scope.allLocationStatus = response.responseObject;
		console.log(response.responseObject);
	});
	

	$http.get(appBaseUrl + '/Common/get_country_list').success(function(response){
		$scope.allCountries = response.responseObject;
	});
	
	$scope.getStates = function(country){
		$http.get(appBaseUrl + '/Common/get_state_list/'+country).success(function(response){
			$scope.allStates = response.responseObject;
		});
	}

	$scope.getCities = function(state){
		$http.get(appBaseUrl + '/Common/get_city_list/'+state).success(function(response){
			$scope.allCities = response.responseObject;
		});
	}

	$scope.getAllAccounts = function(){
		
		$http({
			method : 'POST',
			url : appBaseUrl + '/Location/getAllAccounts',
			data : $.param($scope.locationData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response){	
			console.log(response);
			$scope.allAccountList = response.responseObject;
		});
		
	};
	
	$scope.reset = function() {
		$scope.locationData = {};
		$scope.operationalHoursArr = [];
		$scope.weekdaysviews = ["All","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
		$scope.locationForm.$setPristine();
    }
	
	
	$http.get(appBaseUrl + '/Location2/getLocationById/'+$scope.locationNumber).success(function(response){
		
		console.log(response.responseObject);

		$scope.locationInfo = response.responseObject;
		
		$scope.locationData.locationType 			= $scope.locationInfo.locationType;
		$scope.locationData.locationNumber 			= $scope.locationNumber;
		
		$scope.locationData.accountStatus 			= $scope.locationInfo.accountStatus;
		$scope.locationData.unitNumber 				= $scope.locationInfo.unitNumber;
		$scope.locationData.referenceCode 			= $scope.locationInfo.referenceCode;
		$scope.locationData.locationName			= $scope.locationInfo.locationName;
		$scope.locationData.nickName				= $scope.locationInfo.nickName;
		$scope.locationData.addressLine1			= $scope.locationInfo.addressLine1;
		$scope.locationData.addressLine2			= $scope.locationInfo.addressLine2;
		$scope.locationData.country					= $scope.locationInfo.country;
		
		$http.get(appBaseUrl + '/Common/get_state_list/'+$scope.locationInfo.country).success(function(response){
			$scope.allStates = response.responseObject;
		});
		$scope.locationData.state					= $scope.locationInfo.state;
		
		$http.get(appBaseUrl + '/Common/get_city_list/'+$scope.locationInfo.state).success(function(response){
			$scope.allCities = response.responseObject;
		});
				
		$scope.locationData.city					= $scope.locationInfo.city;

		$scope.locationData.zipCode					= $scope.locationInfo.zipCode;
		$scope.locationData.businessPhone			= $scope.locationInfo.businessPhone;
		$scope.locationData.fax						= $scope.locationInfo.fax;

		$scope.locationData.contactEmail			= $scope.locationInfo.contactEmail;
		$scope.locationData.contactName				= $scope.locationInfo.contactName;
		$scope.locationData.contactPhone			= $scope.locationInfo.contactPhone;
		$scope.locationData.contactPhone			= $scope.locationInfo.contactPhone;
		$scope.allAccountList						= $scope.locationInfo.associatedAccounts;

		$scope.locationData.locationStatus 			= $scope.locationInfo.status;
		
		angular.forEach($scope.locationInfo.operationalHours, function(value, key){
			//if(value.day){
				$scope.operationalHoursArr.push({'dayarray' : value.day, 'fromtimearray' : '2019-02-28 '+ value.startTime, 'totimearray' : '2019-02-28 '+ value.endTime});
				$scope.removeWeekDay("All");
				$scope.removeWeekDay(value.day);
			//}
			console.log('day : ' + value.day+', fromtimearray : ' + '2019-02-28 '+ value.startTime + ', totimearray :' + '2019-02-28 '+ value.endTime);
		});
		console.log(response.responseObject);
	});
	
	$scope.updateLocation = function(){
		//console.log($scope.orderData.orderNumber);
		$http({
			method : 'POST',
			url : appBaseUrl + '/Location2/update_location',
			data : $.param($scope.locationData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response) {	
			console.log(response);
			
			if(response.responseStatusCode == 200){
				window.location = appBaseUrl + '/Location2/confirm_location/' + response.responseObject.locationId;
			}else{
				$scope.errorMsg = response.responseMessage;
			}		
		});
		
	};
	
});