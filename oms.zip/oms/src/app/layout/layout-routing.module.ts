import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component';

const routes: Routes = [
  {
    path:'',
    component:LayoutComponent,
    children:[
      {path:'',loadChildren:'./dashboard/dashboard.module#DashboardModule'},
      {path:'account',loadChildren:'./account-management/account-management.module#AccountManagementModule'},
      {path:'order',loadChildren:'./order-management/order-management.module#OrderManagementModule'},
      {path:'location',loadChildren:'./location-management/location-management.module#LocationManagementModule'},
      {path:'user',loadChildren:'./user-management/user-management.module#UserManagementModule'},
      {path:'inventory',loadChildren:'./inventory-management/inventory-management.module#InventoryManagementModule'},
      {path:'configuration',loadChildren:'./configuration-management/configuration-management.module#ConfigurationManagementModule'}
      
    ]
  }   
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LayoutRoutingModule { }
