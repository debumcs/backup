import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConfigurationManagementRoutingModule } from './configuration-management-routing.module';
import { ConfigurationManagementComponent } from './configuration-management.component';

@NgModule({
  imports: [
    CommonModule,
    ConfigurationManagementRoutingModule
  ],
  declarations: [ConfigurationManagementComponent]
})
export class ConfigurationManagementModule { }
