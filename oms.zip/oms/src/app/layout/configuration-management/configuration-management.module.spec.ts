import { ConfigurationManagementModule } from './configuration-management.module';

describe('ConfigurationManagementModule', () => {
  let configurationManagementModule: ConfigurationManagementModule;

  beforeEach(() => {
    configurationManagementModule = new ConfigurationManagementModule();
  });

  it('should create an instance', () => {
    expect(configurationManagementModule).toBeTruthy();
  });
});
