import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LocationManagementRoutingModule } from './location-management-routing.module';
import { LocationManagementComponent } from './location-management.component';

@NgModule({
  imports: [
    CommonModule,
    LocationManagementRoutingModule
  ],
  declarations: [LocationManagementComponent]
})
export class LocationManagementModule { }
