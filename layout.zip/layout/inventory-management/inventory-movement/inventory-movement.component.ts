import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inventory-movement',
  templateUrl: './inventory-movement.component.html',
  styleUrls: ['./inventory-movement.component.css']
})
export class InventoryMovementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
