import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InventoryManagementRoutingModule } from './inventory-management-routing.module';
import { InventoryMovementComponent } from './inventory-movement/inventory-movement.component';

@NgModule({
  imports: [
    CommonModule,
    InventoryManagementRoutingModule
  ],
  declarations: [InventoryMovementComponent]
})
export class InventoryManagementModule { }
