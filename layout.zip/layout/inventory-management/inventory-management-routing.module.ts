import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InventoryManagementComponent } from './inventory-management.component';
import { InventoryMovementComponent } from './inventory-movement/inventory-movement.component';

const routes: Routes = [
  { path: '', component:InventoryManagementComponent,
		children: [
			{path:'inventory-movement',component:InventoryMovementComponent},
      {path: '', redirectTo: 'inventory-movement', pathMatch: 'full'}
		]
	}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InventoryManagementRoutingModule { }
