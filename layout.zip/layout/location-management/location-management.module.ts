import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LocationManagementRoutingModule } from './location-management-routing.module';
import { ManageLocationComponent } from './manage-location/manage-location.component';
import { CreateLocationComponent } from './create-location/create-location.component';

@NgModule({
  imports: [
    CommonModule,
    LocationManagementRoutingModule
  ],
  declarations: [ManageLocationComponent, CreateLocationComponent]
})
export class LocationManagementModule { }
