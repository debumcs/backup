import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-location',
  templateUrl: './manage-location.component.html',
  styleUrls: ['./manage-location.component.css']
})
export class ManageLocationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
