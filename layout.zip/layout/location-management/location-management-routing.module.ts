import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LocationManagementComponent } from './location-management.component';
import { CreateLocationComponent } from './create-location/create-location.component';
import { ManageLocationComponent } from './manage-location/manage-location.component';

const routes: Routes = [
  { path: '', component:LocationManagementComponent,
		children: [
			{path:'create-location',component:CreateLocationComponent},
      {path:'manage-location',component:ManageLocationComponent},
      {path: '', redirectTo: 'manage-location', pathMatch: 'full'}
		]
	}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LocationManagementRoutingModule { }
