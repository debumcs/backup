import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConfigurationManagementRoutingModule } from './configuration-management-routing.module';
import { AddProductComponent } from './add-product/add-product.component';
import { ViewProductComponent } from './view-product/view-product.component';

@NgModule({
  imports: [
    CommonModule,
    ConfigurationManagementRoutingModule
  ],
  declarations: [AddProductComponent, ViewProductComponent]
})
export class ConfigurationManagementModule { }
