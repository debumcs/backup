import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assign-provider',
  templateUrl: './assign-provider.component.html',
  styleUrls: ['./assign-provider.component.css']
})
export class AssignProviderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
