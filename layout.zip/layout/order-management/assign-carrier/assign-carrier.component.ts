import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assign-carrier',
  templateUrl: './assign-carrier.component.html',
  styleUrls: ['./assign-carrier.component.css']
})
export class AssignCarrierComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
