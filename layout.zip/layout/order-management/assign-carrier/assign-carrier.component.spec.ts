import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignCarrierComponent } from './assign-carrier.component';

describe('AssignCarrierComponent', () => {
  let component: AssignCarrierComponent;
  let fixture: ComponentFixture<AssignCarrierComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignCarrierComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignCarrierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
