import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrderManagementComponent } from './order-management.component';
import { CreateOrderComponent } from './create-order/create-order.component';
import { ViewOrderComponent } from './view-order/view-order.component';
import { AssignCarrierComponent } from './assign-carrier/assign-carrier.component';
import { AssignProviderComponent } from './assign-provider/assign-provider.component';

const routes: Routes = [
  { path: '', component:OrderManagementComponent,
		children: [
			{path:'create-order',component:CreateOrderComponent},
      {path:'view-order',component:ViewOrderComponent},
      {path:'assign-provider',component:AssignProviderComponent},
      {path:'assign-carrier',component:AssignCarrierComponent},
      {path: '', redirectTo: 'view-order', pathMatch: 'full'}
		]
	}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OrderManagementRoutingModule { }
