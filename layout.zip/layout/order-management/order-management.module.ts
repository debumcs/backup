import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OrderManagementRoutingModule } from './order-management-routing.module';
import { CreateOrderComponent } from './create-order/create-order.component';
import { ViewOrderComponent } from './view-order/view-order.component';
import { AssignProviderComponent } from './assign-provider/assign-provider.component';
import { AssignCarrierComponent } from './assign-carrier/assign-carrier.component';

@NgModule({
  imports: [
    CommonModule,
    OrderManagementRoutingModule
  ],
  declarations: [CreateOrderComponent, ViewOrderComponent, AssignProviderComponent, AssignCarrierComponent]
})
export class OrderManagementModule { }
