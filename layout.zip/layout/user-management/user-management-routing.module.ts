import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateUserComponent } from './create-user/create-user.component';
import { ManageUserComponent } from './manage-user/manage-user.component';
import { UserManagementComponent } from './user-management.component';

//const routes: Routes = [];

const routes: Routes = [
  { path: '', component:UserManagementComponent,
		children: [
			{path:'create-user',component:CreateUserComponent},
      {path:'manage-user',component:ManageUserComponent},
      {path: '', redirectTo: 'manage-user', pathMatch: 'full'}
		]
	}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserManagementRoutingModule { }
