export class Dashboard {
    accountId: string;
    androidAuthToken: string;
    createdBy: string;
    createdOn: string;
    email: string;
    firstName: string;
    lastLogin: string;
    lastName: string;
    password: string;
    phoneNumber: number;
    roleId: number;
    updatedOn: string;
    userId: number;
    userName: string;
    userStatus: number;
    webAuthToken: string;
}
