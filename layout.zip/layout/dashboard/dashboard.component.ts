import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute} from '@angular/router';
import { DashboardService } from './dashboard.service';
import { Dashboard } from './dashboard';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(
    private dashboardservice:DashboardService,
    private router : Router
  ) { }

  ngOnInit() {
    document.body.className = 'hold-transition skin-blue sidebar-mini';
    
    /*this.dashboardservice.getUserById().subscribe(
      (data:Dashboard[])=> console.log(data),
      error=> {
        console.log(error);
        if(error == 403){
          this.router.navigate(['/access-denied']);
        }
        
      }
    );*/
    
    /*this.blogservice.getBlogPosts().subscribe(
      (data: Blogpost[]) => this.posts = data,
      error => this.error = error
    );*/
  }

  

}
