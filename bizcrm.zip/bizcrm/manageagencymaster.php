<?php 
	require_once('class/class.agencymaster.php');
	$objagency 		= new Agencymaster();
	$allcountry 	= $objagency->getCountry();
	
	if($_REQUEST['getState']=='ajaxState')
	{
		$id = $_POST['id'];
		$objsta = new Agencymaster();
		$allstate = $objsta->getState($id);
		
		echo '<select class="form-control" id="state" tabindex="6" name="state" style="width:100%;" onchange="getCity(this.value);"><option value="">Select</option>';
		for($si=0; $si<count($allstate); $si++) {
			echo "<option value='".$allstate[$si]['id']."' $selected >".$allstate[$si]['name']."</option>"; 
		}
		echo '</select>';		
		exit;
	}
	//getCity:'ajaxCity'
	if($_REQUEST['getCity']=='ajaxCity')
	{
		$id = $_POST['id'];
		$objcity = new Agencymaster();
		$allcity = $objcity->getCity($id);
		
		echo '<select class="form-control" id="city" tabindex="7" name="city" style="width:100%;"><option value="">Select</option>';
		for($cti=0; $cti<count($allcity); $cti++) {			
			echo "<option value='".$allcity[$cti]['id']."' >".$allcity[$cti]['name']."</option>"; 
		}
		echo '</select>';		
		exit;
	}
	
	
	
	$action = "";
	$action = $_GET["action"];
	$id = $_GET["id"];
	$msgD = '';
	
		
	if($action=="Edit")
	{
	    $btnvalue = "UPDATE";
		$data = $objagency->getById($id);
		
	}elseif($action=="Add")
	{
		$btnvalue = "SAVE";
		
	}else{
		$btnvalue = "";
		$alldata = $objagency->getAll();
	}
	
	if(isset($_POST['submit']))
	{
		$objagency->save();
		exit();
	}

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | Add Category</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Bootstrap time Picker -->
    <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
    <!-- Date Picker -->
    <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<script type="text/javascript" language="javascript">
		function getState(stateid){
			//alert(stateid);
			$.ajax({
				url: "manageagencymaster.php",
				type: 'POST',
				context: this,
				data: {getState:'ajaxState',id:stateid},
				success: function(response){
					$('#ajaxstate').html(response);
				}
			});			
		}
		
		function getCity(cityid){
	
			$.ajax({
				url: "manageagencymaster.php",
				type: 'POST',
				context: this,
				data: {getCity:'ajaxCity',id:cityid},
				success: function(response){
					$('#ajaxcity').html(response);
				}
			});
			
		}
		
		function validateEmail(email) {
			var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			return re.test(email);
		}
		
		function validateagency(){
            
            if(document.getElementById('agency_type').value =='' )
            {
				alert('Please select agecy type!');
				document.getElementById('agency_type').focus();
				return false;
			}else if(document.getElementById('type').value =='' )
            {
				alert('Please select type!');
				document.getElementById('type').focus();
				return false;
			}else if(document.getElementById('agencyname').value =='' )
            {
				alert('Please enter agency name!');
				document.getElementById('agencyname').focus();
				return false;
			}else if(document.getElementById('address').value =='' )
            {
				alert('Please enter address!');
				document.getElementById('address').focus();
				return false;
			}else if(document.getElementById('country').value =='' )
            {
				alert('Please select country!');
				document.getElementById('country').focus();
				return false;
			}else if(document.getElementById('state').value =='' )
            {
				alert('Please select state!');
				document.getElementById('state').focus();
				return false;
			}else if(document.getElementById('city').value =='' )
            {
				alert('Please select city!');
				document.getElementById('city').focus();
				return false;
			}else if(document.getElementById('pincode').value =='' )
            {
				alert('Please enter pincode!');
				document.getElementById('pincode').focus();
				return false;
			}else if(document.getElementById('contactno').value =='' )
            {
				alert('Please enter contact no!');
				document.getElementById('contactno').focus();
				return false;
			}else if(!validateEmail(document.getElementById("email").value))
            {
				alert('Please enter valid email!');
				document.getElementById('email').focus();
				return false;
			}
			else{
				return true;
			}
			
      	}
	
	</script>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
     
   <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objagency->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objagency->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>Agency Master</h1>
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Control Panel</li>
            <li class="active">Agency Master</li><li class="active"><?php echo $action; ?></li>
          </ol>
        </section><!--CONTENT HEADER-->
        <?php if($action == 'Add' || $action == 'Edit'){ ?>
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title"><?php echo $action; ?> Agency Master</h3><span style='float:right'>Fields marked with a asterisk (<font color='red'>*</font>) are mandatory.</span>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <form action="" name="agencymaster" id="agencymaster" method="post" >
							<div class="row">
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Agency name<font color='red'>*</font> </label>
											<input type="text" class="form-control" id="agencyname" tabindex="1" name="agencyname" placeholder="Enter agency name" value="<?php echo $data['agencyname']; ?>">
											<input type="hidden" id="id" name="id" value="<?php echo $data['id']; ?>" />
										</div>										
									</div><!-- /.col -->
									<div class="col-lg-2">
										<div class="form-group">
											<label>Agency Type<font color='red'>*</font></label>
											<select class="form-control" id="type" tabindex="2" name="type" style="width:100%;">
											<option value="" disabled selected>Select Agency Type</option>
											<option value="Dying" <?php if($data['type']=='Dying'){echo "selected";} ?>>Dying</option>
											<option value="Embroidering" <?php if($data['type']=='Embroidering'){echo "selected";} ?>>Embroidering</option>
											<option value="FabricCutting" <?php if($data['type']=='FabricCutting'){echo "selected";} ?>>FabricCutting</option>
											<option value="Marking" <?php if($data['type']=='Marking'){echo "selected";} ?>>Marking</option>
											<option value="MasterCutting" <?php if($data['type']=='MasterCutting'){echo "selected";} ?>>MasterCutting</option>
											<option value="Tailoring" <?php if($data['type']=='Tailoring'){echo "selected";} ?>>Tailoring</option>
                                        </select>
										</div><!-- /.form-group -->
									</div><!-- /.col -->
									
									<div class="col-lg-2">
										<div class="form-group">
											<label>Internal/External<font color='red'>*</font></label>
											<select class="form-control" id="agency_type" tabindex="3" name="agency_type" style="width:100%;">
											<option value="" disabled selected>Select Internal or External</option>
											<option value="Internal" <?php if($data['agency_type']=='Internal'){echo "selected";} ?>>Internal</option>
											<option value="External" <?php if($data['agency_type']=='External'){echo "selected";} ?>>External</option>
                                        </select>
										</div><!-- /.form-group -->
									</div><!-- /.col -->
								  
									<div class="col-lg-4">
										<div class="form-group">
											<label>Address<font color='red'>*</font></label>
											<input type="text" class="form-control" id="address"  tabindex="4" name="address" placeholder="Enter address" value="<?php echo $data['address']; ?>">
										</div><!-- /.form-group -->
									</div><!-- /.col -->
								</div><!-- /.col -->
								
								<div class="col-lg-12">	
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Country</label><?php echo $MANDATORY;?>
											<select class="form-control" id="country" name="country" style="width:100%;" tabindex="5" onchange="getState(this.value);">
											<option value="" selected>Select</option>
											<?php 				
											for($ci=0; $ci<count($allcountry); $ci++) {
												if($data['country']==$allcountry[$ci]['id']){$selected="selected";}else{$selected="";} 				 
												echo "<option value='".$allcountry[$ci]['id']."' $selected >".$allcountry[$ci]['name']."</option>"; 
											}
											?>
											</select>
										</div>
									</div><!-- /.col -->
								  
									<div class="col-lg-4">						
										<div class="form-group">										  
										  <label for="name">State</label><?php echo $MANDATORY;?>
										  <div id="ajaxstate" style="width:100%;">
												<?php
												if(isset($data['country']))
												{
												$allstate = $objagency->getState($data['country']);
												echo '<select class="form-control" tabindex="6" id="state" name="state" style="width:100%;" onchange="getCity(this.value);"><option value="">Select</option>';
												for($si=0; $si<count($allstate); $si++)
												{
													if($data['state']==$allstate[$si]['id']){$selected="selected";}else{$selected="";}
													echo "<option value='".$allstate[$si]['id']."' $selected >".$allstate[$si]['name']."</option>";
												}
												echo '</select>';
												}
												else{
													echo '<select class="form-control" tabindex="6" id="state" name="state" style="width:100%;">
													<option value="" selected>Select</option>
													</select>';
												}
												?>											
											</div>
										</div>				
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">City</label><?php echo $MANDATORY;?>
										  <div id="ajaxcity" style="width:100%;">
                     					<?php 
											if(isset($data['state'])){
												$allcity = $objagency->getCity($data['state']);

												echo '<select class="form-control" id="city" tabindex="7" name="city" style="width:100%;"><option value="">Select</option>';
												for($cti=0; $cti<count($allcity); $cti++) {
													if($data['city']==$allcity[$cti]['id']){$selected="selected";}else{$selected="";}  			
													echo "<option value='".$allcity[$cti]['id']."' $selected >".$allcity[$cti]['name']."</option>"; 
												}
												echo '</select>';	
												}else
												{
												echo '<select class="form-control" tabindex="7" id="city" name="city" style="width:100%;">
												<option value="" selected>Select</option>
												</select>';
											}
										?>				
 
											</div>
										</div>
									</div><!-- /.col -->
									
								</div><!-- /.col -->
								
								<div class="col-lg-12">	
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Pin Code<font color='red'>*</font> </label>
											<input type="text" class="form-control" tabindex="8" id="pincode" name="pincode" placeholder="Enter pincode" value="<?php echo $data['pincode']; ?>">
										</div>		
									</div><!-- /.col -->
								  
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Contact No<font color='red'>*</font> </label>
											<input type="text" class="form-control" tabindex="9" id="contactno" name="contactno" placeholder="Enter contact no" value="<?php echo $data['contactno']; ?>">
										</div>										
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
											<label>Email<font color='red'>*</font></label>
											<input type="text" class="form-control" tabindex="10" id="email"  name="email" placeholder="Enter email" value="<?php echo $data['email']; ?>" <?php if($action=="edit"){echo 'readonly';}else{echo 'onblur="agency_email_id_html(this.value);"';}?> />
											<p id="agency_email_id_html"></p>
										</div><!-- /.form-group -->
									</div><!-- /.col -->
								</div><!-- /.col -->
								
								<div class="col-lg-12">	
									<div class="col-lg-4">
										<div class="form-group">
											<label>Status<font color='red'>*</font></label>
											<div style="width:100%;">
											<input type="radio" id="agencystatus" name="agencystatus" <?php if($action == 'Add'){echo 'checked';} if($data['agencystatus'] == '1'){echo 'checked';} ?> value="1">Active
											<input type="radio" id="agencystatus" name="agencystatus" <?php if($data['agencystatus'] == '0'){echo 'checked';} ?> value="0">In-Active
											</div>
										</div><!-- /.form-group -->
									</div><!-- /.col -->
								</div><!-- /.col -->
								
                           </div><!-- /.row -->
                           
                           <div class="row">
                              <div class="col-lg-12">
                                   <div class="form-group center">
                                      <input type="submit" name="submit" id="submit" tabindex="11" class="btn btn-warning left-10" value="<?php echo $btnvalue; ?>" onclick="return validateagency();" />
									  <a href="manageagencymaster.php" class="btn btn-warning left-10">View All</a>
                                   </div>
                               </div><!-- /.col -->
             				 </div><!-- /.row -->
                           </form>
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
		<?php }else{ ?>
		
		<section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title pull-right"><a href="manageagencymaster.php?action=Add&id=">Add New</a></h3>
                        </div><!-- /.box-header -->
                        <div class='box-body table-responsive'>
                            <table id="example111" class="table table-bordered table-striped">
							<thead>
							  <tr>
								<th>Type</th>
								<th>Agency Name</th>
								<th>Address</th>
								<th>Contact No</th>
								<th>Email</th>
								<th>Action</th>							
							  </tr>
							</thead>
                    <tbody>
					<?php for($i=0; $i<count($alldata); $i++) { ?>	
						<tr>
                            <td><?php print $alldata[$i]['type']; ?></td>
							<td><?php print $alldata[$i]['agencyname']; ?></td>
							<td><?php print $alldata[$i]['address']; ?></td>
							<td><?php print $alldata[$i]['contactno']; ?></td>
							<td><?php print $alldata[$i]['email']; ?></td>
							<td><a href="manageagencymaster.php?action=Edit&id=<?php print $alldata[$i]['id']; ?>">Edit</a></td>							
				        </tr>
                    <?php } ?>						
                    </tbody>
                    
                  </table>
                           
                          </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
            </div><!-- /.row -->
        </section><!--CONTENT-->		
		<?php } ?>
		
      </div><!-- /.content-wrapper -->
      
      
      <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
    
    <!-- daterangepicker -->
    <script src="dist/js/moment.min.js"></script>
    <!-- bootstrap time picker -->
    <script src="plugins/timepicker/bootstrap-timepicker.js"></script>
    <!-- iCheck 1.0.1 -->
    <script src="plugins/iCheck/icheck.min.js"></script>
    <script src="plugins/daterangepicker/daterangepicker.js"></script>
    <!-- datepicker -->
    <script src="plugins/datepicker/bootstrap-datepicker.js"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js"></script>
    
    <script type="text/javascript" src="plugins/datepicker/bootstrap-clockpicker.min.js"></script>
    
    <script type="text/javascript" src="dist/js/date.js"></script>
    
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <script>
		function check_agency_email_id(emailid){
			if(emailid != ''){
				$.ajax({
					url: "ajax_suborder.php",
					type: 'POST',
					context: this,
					data: {AgencyEmailID:'AgencyEmailID',emailid:emailid},
					success: function(response){
						if(response >= 1){
							var check_referel = "<span class='refferal_success'>Valid ID!</span>";
						}else{
							var check_referel = "<span class='refferal_failure'>Email ID '"+emailid+"' is already exist!</span>";
							$('#email').val('');
						}
						$('#agency_email_id_html').html(check_referel);					
					}
				});
			}else{
				$('#agency_email_id_html').html('');
			}
		}
		
		$("#message").fadeIn('slow').delay(1000).fadeOut('slow');
		$(".select2").select2();
		
		//iCheck for checkbox and radio inputs
        $('input[type="radio"].minimal').iCheck({
           radioClass: 'iradio_minimal-orange'
        });
	</script>
  </body>
</html>