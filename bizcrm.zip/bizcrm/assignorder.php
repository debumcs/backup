<?php 
	//require_once('include/auth.php');
	require_once('class/class.orderdetails.php');
	
	$objord = new Orderdetails();
	//action=assign&orderno=ADBD4069
	$action = $_GET["action"];
	$orderno = $_GET["orderno"];
	$msgD = '';
	// :''
		
	if($action=="assign")
	{
		//echo 'hi';die();
		$allagenttype = $objord->getAllAgentType();
		$allagent = $objord->getAllAgent($orderno);
		//echo $allagent[0]['sta'];die();
		$allMappingOrderData = $objord->getMappingOrderInfo($orderno);
		$orderInfo = $objord->getAssignOrderInfo($orderno);
		
		$btnvalue = "Save";
	}
	//data: {getType:'ajaxAgentType',typeid:agenttype},
	if($_REQUEST['getType']=='ajaxAgentType')
	{		
		$typeid = $_POST['typeid'];
		$objAtype = new Orderdetails();
		
		if($typeid == 'All'){
			$allagent2 = $objAtype->getAllAgent();
		}else{
			$allagent2 = $objAtype->getAllAgentByType($typeid);
		}
			
	
		
		for($i=0; $i<count($allagent2); $i++) { ?>
			<tr>
				<td><input type="checkbox" name="id[]" id="id" value="<?php print $allagent2[$i]['psuid']; ?>" />
				<input type="hidden" name="agentid_<?php print $allagent2[$i]['psuid']; ?>" id="agentid_<?php print $allagent2[$i]['psuid']; ?>" value="<?php print $allagent2[$i]['username'];?>" />
				</td>
				<td><?php echo $allagent2[$i]['name']; ?></td>
				<td><?php echo $allagent2[$i]['groupname']; ?></td>
				<td><input type="text" name="task_details_<?php print $allagent2[$i]['psuid']; ?>" id="task_details_<?php print $allagent2[$i]['psuid']; ?>" value="" /></td>
			</tr>
		<?php } 	
		exit;
	}
	
	//data: {getOMS:'statuschange',orderno:ordno,omid:chomid,statusv:statusvalue},
	if($_REQUEST['getOMS']=='statuschange')
	{
		
		$omid 		= $_POST['omid'];
		$statusv 	= $_POST['statusv'];
		$orderno 	= $_POST['orderno'];
		$objMOI 	= new Orderdetails();
		
		$objMOI->updateMappingOrderStatus($orderno,$omid,$statusv);
		$allMappingOrderData2 = $objMOI->getMappingOrderInfo($orderno);
		
		
		for($mi=0; $mi<count($allMappingOrderData2); $mi++) { 
		?>
			<tr>
				<td><?php echo $allMappingOrderData2[$mi]['name']; ?></td>
				<td><?php echo $allMappingOrderData2[$mi]['groupname']; ?></td>
				<td><?php echo $allMappingOrderData2[$mi]['task_details']; ?></td>
				<td>
				<select name="mstatus" id="mstatus" onchange="changestatus(<?php echo $allMappingOrderData2[$mi]['orderno']; ?>,<?php echo $allMappingOrderData2[$mi]['id']; ?>,this.value)">
				<option value="1" <?php if($allMappingOrderData2[$mi]['status'] == '1'){echo 'selected';}else{} ?>>Active</option>
				<option value="0" <?php if($allMappingOrderData2[$mi]['status'] == '0'){echo 'selected';}else{} ?>>In-active</option>
				</select>
				</td>
			</tr>
		<?php } 
		exit;
	}
	
	if(isset($_POST['submit']))
	{
		$objord->getAgentAssign();
		exit;
	}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>BIZCRM | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Bootstrap time Picker -->
    <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
    <!-- Date Picker -->
    <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />
	<link rel="stylesheet" href="date/jquery-ui.css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<script type="text/javascript" language="javascript">
		
		function validateuser(){
            var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            if(document.getElementById('username').value =='' ){
				alert('Please enter userid!');
				document.getElementById('username').focus();
				return false;
			}else if(document.getElementById('name').value =='' ){
				alert('Please enter name!');
				document.getElementById('name').focus();
				return false;
			}else if(!filter.test(document.getElementById('email').value)){
				alert('Please enter valid Employee email id!');
				document.getElementById('email').focus();
				return false;
			}else if(document.getElementById('role').value =='' ){
				alert('Please select role!');
				document.getElementById('role').focus();
				return false;
			}else{
				return true;
			}
      	}
		
		function changestatus(chomid,ordno,statusvalue){
			
			$.ajax({
				url: "assignorder.php",
				type: 'POST',
				context: this,
				data: {getOMS:'statuschange',orderno:ordno,omid:chomid,statusv:statusvalue},
				success: function(response){
					$('#MappingOrderID').html(response);
				}
			});
			getagenttype('All');
		}
		
		function getagenttype(agenttype){
		
			$.ajax({
				url: "assignorder.php",
				type: 'POST',
				context: this,
				data: {getType:'ajaxAgentType',typeid:agenttype},
				success: function(response){
					$('#allagenttype').html(response);
				}
			});
			
		}
		
		
	</script>
	<style>	
	#example111 input[type=checkbox] {
    display: block;}
	</style>
  </head>
  <body class="hold-transition skin-blue sidebar-mini" onload="startTime()">
     
   <div class="wrapper">

		<?php $objord->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objord->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
         <!-- <h1>
            Order Assign
          </h1>
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Control Panel</li>
            <li class="active">Order Assign</li>
          </ol>
        </section>CONTENT HEADER-->
		
        
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
							<div class="col-md-12">
								<h3 class="box-title">Order Assign</h3>
							</div>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <form action="" name="userCreate" id="userCreate" method="post" >
							<div class="row">
								
								<div class="col-lg-12">
									<div class="col-lg-5">
										<div class="form-group">
										  
										  <p>
											Customer ID : <?php echo $orderInfo[0]['customer_id'];?><br>
											Name : <?php echo $orderInfo[0]['salutation'].' '.$orderInfo[0]['name_first'].' '.$orderInfo[0]['name_last'];?><br>
										  </p>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-5">										
										<div class="form-group">
											<p>
											Order No : <?php echo $orderInfo[0]['orderno'];?>
											<input type="hidden" name="orderno" id="orderno" value="<?php echo $orderInfo[0]['orderno'];?>" /><br>
											Order Detail : <?php echo $orderInfo[0]['order_detail'];?><br>
											</p>											
										</div>										  
									</div><!-- /.col -->
									
									<div class="col-lg-2">										
										<div class="form-group">
											<p>
											<a href="payment.php?orderno=<?php echo $orderInfo[0]['orderno'];?>" class="btn btn-warning left-10">Payment</a>
											</p>											
										</div>										  
									</div><!-- /.col -->
								</div>
								<?php if(count($allMappingOrderData)>0){ ?>
								<div class="col-lg-12">
									<div class="col-lg-12">
										<h4 class="box-title">List of Assigned Agents</h4>
										<div class='box-body'>
											<table id="example111" class="table table-bordered table-striped">
												<thead>
													<tr>	
														<th width="20%">Agent </th>
														<th width="20%">Agent Type</th>
														<th width="40%">Task Details</th>
														<th width="10%">Status</th>
													</tr>
												</thead>
												<tbody id="MappingOrderID">
												<?php for($mi=0; $mi<count($allMappingOrderData); $mi++) { 
												//a.psuid, a.username, a.name, a.role, b.groupname, c.orderno, c.remarks, c.status
												?>
													<tr>
														<td><?php echo $allMappingOrderData[$mi]['name']; ?></td>
														<td><?php echo $allMappingOrderData[$mi]['groupname']; ?></td>
														<td><?php echo $allMappingOrderData[$mi]['task_details']; ?></td>
														<td>
														<select name="mstatus" id="mstatus" onchange="changestatus('<?php echo $allMappingOrderData[$mi]['id']; ?>','<?php echo $allMappingOrderData[$mi]['orderno']; ?>', this.value)">
														<option value="1" >Active</option>
														<option value="0" <?php if($allMappingOrderData[$mi]['status'] == '0'){echo 'selected';}else{} ?>>In-active</option>
														</select>
														</td>
													</tr>
												<?php } ?>
												</tbody>
											</table>
										</div><!-- /.box-body--> 
									</div>
								</div>
								<?php } ?>
								
								<div class="col-lg-12">
									<div class="col-lg-12">
										<h4 class="box-title">List of Agents</h4>
										<div class='box-body'>
										
											<table id="example111" class="table table-bordered table-striped">
												<thead>
													<tr>	
														<th width="10%">#</th>
														<th width="20%">Agent </th>
														<th width="20%">
														<select name="agenttype" id="agenttype" onchange="getagenttype(this.value)">
														<option value="All" selected>All</option>
														<?php for($at=0; $at<count($allagenttype); $at++) { ?>
														<option value="<?php echo $allagenttype[$at]['groupid'] ?>"><?php echo $allagenttype[$at]['groupname'] ?></option>
														<?php } ?>
														</select>
														</th>
														<th width="50%">Task Details</th>														
													</tr>
												</thead>
												<tbody id="allagenttype">
												<?php for($i=0; $i<count($allagent); $i++) { ?>
													<tr>
														<td><input type="checkbox" name="id[]" id="id" value="<?php print $allagent[$i]['psuid']; ?>" />
														<input type="hidden" name="agentid_<?php print $allagent[$i]['psuid']; ?>" id="agentid_<?php print $allagent[$i]['psuid']; ?>" value="<?php print $allagent[$i]['username'];?>" />
														</td>
														<td><?php echo $allagent[$i]['name']; ?></td>
														<td><?php echo $allagent[$i]['groupname'];//remark_ ?></td>
														<td><input type="text" name="task_details_<?php print $allagent[$i]['psuid']; ?>" id="task_details_<?php print $allagent[$i]['psuid']; ?>" value="" /></td>
													</tr>
												<?php } ?>
												</tbody>
											</table>
										</div><!-- /.box-body--> 
									</div>
								</div>
								<div class="col-lg-12">
                                   <div class="form-group center">
                                      <input type="submit" name="submit" id="submit" class="btn btn-warning left-10" value="<?php echo $btnvalue; ?>" />
                                   </div>
                               </div><!-- /.col -->
							   
							   
                           </div><!-- /.row -->
                           
                           </form>
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
			</section><!--CONTENT-->
		</section>
      </div><!-- /.content-wrapper -->
      
      
      <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->
	<script src="date/jquery-1.9.1.js"></script>
	<script src="date/jquery-ui.js"></script>
	<script>
	$(function() {
		$( ".datepicker" ).datepicker();
	});
	</script>
    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
    
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js"></script>
    
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <script>
		$("#message").fadeIn('slow').delay(5000).fadeOut('slow');
		$(".select2").select2();
		  //Date range picker
      //  $('#reservation').daterangepicker();
		
		//Date range picker with time picker
        //$('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 1, format: 'MM/DD/YYYY h:mm A'});
		
		//iCheck for checkbox and radio inputs
        $('input[type="radio"].minimal').iCheck({
           radioClass: 'iradio_minimal-orange'
        });
		
		
 
		var input = $('#input-a');
		input.clockpicker({
		autoclose: true
		});
		
		
    });
	
	
</script>


</body>
</html>