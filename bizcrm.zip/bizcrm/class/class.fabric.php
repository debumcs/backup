<?php 
error_reporting(E_ERROR);
ini_set('display_errors', 1);
include_once("database.class.php");
include_once("class.config.php");

class Fabric extends config{
	
	//public $database;
	
	function __construct() {
		if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
		{
			$this->redirect('index.php');
			exit();
		}
	}
	
	function __destruct() {
		//parent::__construct();
		//$database->close;
	}

	// fabric group

	public function getAllgroup() {
		
		$sql = "SELECT * FROM fabric_group order by groupname asc";
		$result = $this->fetchAssoc($sql);
		
		return $result;
	}
	
	public function getgroupById($id){
		$database = new Database();
		
		$id = $this->sanitize($id);
		$sql = "SELECT * FROM fabric_group where id='".$id."'";
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}
	
	public function savegroup(){
		$database 		= new Database();
		
		$admin_name 	= $_SESSION['ADMIN_NAME'];
		$submit 		= $this->sanitize($_POST["submit"]);
		
		$id 			= $this->sanitize($_POST["id"]);
		$groupname 		= $this->sanitize($_POST["groupname"]);
		$fabric_type 	= $this->sanitize($_POST["fabric_type"]);				
		
				
		$createdby 		= $admin_name? $admin_name: '';
		$createdon 		= date('Y-m-d H:i:s');

		$modifiedby		= $admin_name? $admin_name: '';
		$modifiedon		= date('Y-m-d H:i:s');

        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		if($submit == 'SAVE'){
			$sql = "INSERT INTO fabric_group(groupname, fabric_type, createdby, createdon, modifiedby, modifiedon, ipaddress) VALUES ('".$groupname."', '".$fabric_type."', '".$createdby."', '".$createdon."', '".$modifiedby."', '".$modifiedon."', '".$ipaddress."')";
		}
		if($submit == 'UPDATE'){
			$sql_log = "INSERT INTO fabric_group_log SELECT id, groupname, fabric_type, createdby, createdon, '".$modifiedby."', '".$modifiedon."', ipaddress FROM fabric_group WHERE id = '".$id."'";
			$result_log = $database->query($sql_log);
			
			$sql = "UPDATE fabric_group SET groupname='".$groupname."', fabric_type='".$fabric_type."', modifiedby='".$modifiedby."', modifiedon='".$modifiedon."', ipaddress='".$ipaddress."' WHERE id = '".$id."'";
		}
		//echo $sql; die();
		$result = $database->prepare($sql);
		if($result->execute()){
			if($submit == 'SAVE'){
				$_SESSION['msgD'] = 'Fabric Group inserted successfully.';
			}else{
				$_SESSION['msgD'] = 'Fabric Group updated successfully.';
			}			
		}else{
			$_SESSION['msgD'] = 'Error while executing query.';
		}
        
		$result->close();
		$database->close();
		$this->redirect('managefabricgroup.php');
	}
	/* Fabric */
	
	public function getFabricByGroupID($fabrics) {
		
		$sql = "SELECT id,fabricid,fabricname FROM fabric WHERE fabstatus = '1' AND group_id = '".$fabrics."' ORDER BY id ASC";
		$result = $this->fetchAssoc($sql);		
		return $result;
	}
	
	public function getSelectedFabric($fabrics) {
		
		$sql = "SELECT id,fabricname FROM fabric WHERE fabstatus = '1' AND id NOT IN (".$fabrics.") ORDER BY id ASC";
		$result = $this->fetchAssoc($sql);		
		return $result;
	}
	
	public function getAll() {
		
		$sql = "SELECT * FROM fabric order by fabricname asc";
		$result = $this->fetchAssoc($sql);
		
		return $result;
	}
	
	public function getById($id){
		$database = new Database();
		
		$id = $this->sanitize($id);
		$sql = "SELECT * FROM fabric where id='".$id."'";
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}
	
	public function save(){
		$database 		= new Database();
		
		$admin_name 	= $_SESSION['ADMIN_NAME'];
		$submit 		= $this->sanitize($_POST["submit"]);
		
		$id 			= $this->sanitize($_POST["id"]);
		$fabricname 	= $this->sanitize($_POST["fabricname"]);
		$group_id 		= $this->sanitize($_POST["group_id"]);
        $fabricid 		= $this->sanitize($_POST["fabricid"]);
		$preferred_vendor_name = $this->sanitize($_POST["preferred_vendor_name"]);
		$last_price 	= $this->sanitize($_POST["last_price"]);
		$recommended_sale_price 	= $this->sanitize($_POST["recommended_sale_price"]);
		$units 			= $this->sanitize($_POST["units"]);
		
		if(floatval($_FILES['fabric_image']['size'])>0)
		{
			$file 			= $_FILES['fabric_image']['name']; 
			$filesize 		= $_FILES['fabric_image']['size'];  
			$array 			= explode('.', $file);
			$fileName 		= $array[0];
			$fileExt 		= $array[1];
			$fabric_image 	= $fileName."_".time().".".$fileExt;
			$image_tmp      = $_FILES['fabric_image']['tmp_name'];
			$image_location = "febricimage/".$fabric_image;
			move_uploaded_file($image_tmp,$image_location);
		}
		else
		{       
			$image_location = $_POST['fabric_image_hidden'];
		}
		
		$fabstatus 		= $this->sanitize($_POST["fabstatus"]);
		
		
		$createdby 		= $admin_name? $admin_name: '';
		$createdon 		= date('Y-m-d H:i:s');
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		if($submit == 'SAVE'){
			$sql = "INSERT INTO fabric(group_id, fabricname, fabricid, preferred_vendor_name, last_price, recommended_sale_price, fabric_image, units, createdby, createdon, ipaddress) VALUES ('".$group_id."', '".$fabricname."', '".$fabricid."', '".$preferred_vendor_name."', '".$last_price."', '".$recommended_sale_price."', '".$image_location."', '". $units."', '".$createdby."', '".$createdon."', '".$ipaddress."')";
		}
		if($submit == 'UPDATE'){
			$sql_log = "INSERT INTO fabric_log SELECT id, group_id, fabricname, fabricid, preferred_vendor_name, last_price, recommended_sale_price, fabric_image, fabstatus, units,  createdby, createdon, ipaddress FROM fabric WHERE id = '".$id."'";
			$result_log = $database->query($sql_log);
			
			$sql = "UPDATE fabric SET group_id='".$group_id."', fabricname='".$fabricname."', fabricid='".$fabricid."', preferred_vendor_name='".$preferred_vendor_name."', last_price='".$last_price."', recommended_sale_price='".$recommended_sale_price."', fabric_image='".$image_location."', fabstatus='".$fabstatus."', units='".$units."', createdby='".$createdby."', createdon='".$createdon."', ipaddress='".$ipaddress."' WHERE id = '".$id."'";
		}
		//echo $sql; die();
		$result = $database->prepare($sql);
		if($result->execute()){
			if($submit == 'SAVE'){
				$_SESSION['msgD'] = 'Fabric data inserted successfully.';
			}else{
				$_SESSION['msgD'] = 'Fabric data updated successfully.';
			}			
		}else{
			$_SESSION['msgD'] = 'Error while executing query.';
		}
        
		$result->close();
		$database->close();
		$this->redirect('managefabric.php');
	}	
}

?>