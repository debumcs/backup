<?php

Class Database extends mysqli{
	private $hostname;
	private $username;
	private $password;
	private $database;
	
	public function __construct(){
		$this->hostname = '10.100.4.50'; 
		$this->username = 'root';
		$this->password = 'Saimaa#2010';
		$this->database = 'bizcrm_new';
		
		parent::__construct($this->hostname,$this->username,$this->password,$this->database);		
		
	}
	
	public function ConvertTimezoneToAnotherTimezone($time, $currentTimezone) {

		$userTimezone = ''; 
		switch ($currentTimezone) 
		{ 
			case 'PST':  $userTimezone = 'America/Los_Angeles'; break; 
			case 'CST':  $userTimezone = 'America/Chicago'; break; 
			case 'MST':  $userTimezone = 'US/Mountain'; break; 
			case 'EST':  $userTimezone = 'US/Eastern'; break;                 
			case 'IST':  $userTimezone = 'Asia/Kolkata'; break;    
		} 

		$dayLightFlag = false;
		$dayLgtSecCurrent = $dayLgtSecReq = 0;
		$system_timezone = date_default_timezone_get();
		$local_timezone = $userTimezone;
		date_default_timezone_set($local_timezone);
		$local = date("Y-m-d H:i:s");
		date_default_timezone_set("GMT");
		$gmt = date("Y-m-d H:i:s ");

		$require_timezone = 'Asia/Kolkata';
		date_default_timezone_set($require_timezone);
		$required = date("Y-m-d H:i:s ");

		date_default_timezone_set($system_timezone);

		$diff1 = (strtotime($gmt) - strtotime($local));
		$diff2 = (strtotime($required) - strtotime($gmt));

		$date = new DateTime($time);

		$date->modify("+$diff1 seconds");
		$date->modify("+$diff2 seconds");

		if ($dayLightFlag) {
			$final_diff = $dayLgtSecCurrent + $dayLgtSecReq;
			$date->modify("$final_diff seconds");
		}

		$timestamp = $date->format("Y-m-d H:i:s ");

		return $timestamp;
	}

	public function TimeZoneCastNew($time, $currentTimezone) {
    
		$userTimezone = ''; 
		switch ($currentTimezone) 
		{ 
			case 'PST':  $userTimezone = 'America/Los_Angeles'; break; 
			case 'CST':  $userTimezone = 'America/Chicago'; break; 
			case 'MST':  $userTimezone = 'US/Mountain'; break; 
			case 'EST':  $userTimezone = 'US/Eastern'; break;                 
			case 'IST':  $userTimezone = 'Asia/Kolkata'; break;    
		} 
		
		$dayLightFlag = false;
		$dayLgtSecCurrent = $dayLgtSecReq = 0;
		$system_timezone = date_default_timezone_get();
		$local_timezone = $userTimezone;
		date_default_timezone_set($local_timezone);
		$local = date("Y-m-d H:i:s");
		date_default_timezone_set("GMT");
		$gmt = date("Y-m-d H:i:s ");

		$require_timezone = 'Asia/Kolkata';
		date_default_timezone_set($require_timezone);
		$required = date("Y-m-d H:i:s ");

		date_default_timezone_set($system_timezone);

		$diff1 = (strtotime($gmt) - strtotime($local));
		$diff2 = (strtotime($required) - strtotime($gmt));

		$date = new DateTime($time);

		$date->modify("+$diff1 seconds");
		$date->modify("+$diff2 seconds");

		if ($dayLightFlag) {
			$final_diff = $dayLgtSecCurrent + $dayLgtSecReq;
			$date->modify("$final_diff seconds");
		}

		$timestamp = $date->format("Y-m-d H:i:s ");

		return $timestamp;
	}

	public function convertfromdatetodate($datetimerange)
	{  
		$timerange = array();
		$timerange = explode('-',$datetimerange);
	  
		$fromdate =  strtotime($timerange[0]);
		$fromdate =  date('Y-m-d H:i:s',$fromdate);
	  
		$todate = strtotime($timerange[1]);
		$todate = date('Y-m-d H:i:s',$todate);
		
		$date = array('fromdate'=>$fromdate,'todate'=>$todate);

		return $date;
	}

	public function convertcombinddate($fromdate,$todate)
	{  
		$fromdate = date('m/d/Y h:i A',strtotime($fromdate));
		$todate = date('m/d/Y h:i A',strtotime($todate));
		$datetimerange = $fromdate.' - '.$todate;

		return $datetimerange;
	}
	
	public function sanitize($input)
	{  //global $conn;
		$object = new self;
		if (is_array($input)) {
			foreach($input as $var=>$val) {
				$output[$var] = $this->sanitize($val);
			}
		}
		else {
			if (get_magic_quotes_gpc()) {
				$input = stripslashes($input);
			}
			$input  = $this->cleanInput($input);
			$output = $object->real_escape_string($input);
		}
		return $output;
	}
	
    public function cleanInput($input) {  
       
        $input = str_replace("'","&apos;",$input);   // replaces single quotes
        
        $search = array(
            '@<script[^>]*?>.*?</script>@si',   // Strip out javascript
            '@<[\/\!]*?[^<>]*?>@si',            // Strip out HTML tags
            '@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
            '@<![\s\S]*?--[ \t\n\r]*>@'         // Strip multi-line comments
        );
        $output = preg_replace($search, '', $input);
        return $output;
    }
	
	public function redirect($url) {
		if (isset($url)) {
			header("Location: " . $url);
		}
	}

	public function sanitize_output($string) {
		return htmlspecialchars($string);
	}
}
