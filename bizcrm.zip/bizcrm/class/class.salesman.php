<?php 
error_reporting(E_ERROR);
ini_set('display_errors', 1);
include_once("database.class.php");
include_once("class.config.php");

class Salesman extends config{
	
	//public $database;
	
	function __construct() {
		if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
		{
			$this->redirect('index.php');
			exit();
		}
	}
	
	function __destruct() {
		//parent::__construct();
		//$database->close;
	}
	
	public function getAll() {
		
		$sql = "SELECT * FROM salesperson";
		$result = $this->fetchAssoc($sql);
		
		return $result;
	}
	
	public function checkSalePersonCode($person_id){
		$database = new Database();
		
		$person_id = $this->sanitize($person_id);
		
		$sql = "SELECT COUNT(*) AS total FROM (SELECT user_code AS usercode FROM salesperson UNION ALL SELECT username AS usercode FROM adminuser) p WHERE usercode = '".$person_id."'";
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}
	
	public function getById($id){
		$database = new Database();
		
		$id = $this->sanitize($id);
		$sql = "SELECT * FROM salesperson where id='".$id."'";
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}
	
	public function save(){
		$database 		= new Database();
		
		$admin_name 	= $_SESSION['ADMIN_NAME'];
		$submit 		= $this->sanitize($_POST["submit"]);
		
		$id 			= $this->sanitize($_POST["id"]);
		$user_type 		= $this->sanitize($_POST["user_type"]);
		$user_code 		= $this->sanitize($_POST["user_code"]);
		$personname 	= $this->sanitize($_POST["personname"]);
		$address 		= $this->sanitize($_POST["address"]);
        $city 			= $this->sanitize($_POST["city"]);
		$state 			= $this->sanitize($_POST["state"]);
        $country 		= $this->sanitize($_POST["country"]);
		$pincode 		= $this->sanitize($_POST["pincode"]);
        $contactno 		= $this->sanitize($_POST["contactno"]);
		$email 			= $this->sanitize($_POST["email"]);
		
		$createdon 		= date('Y-m-d H:i:s');
		$createdby 		= $admin_name? $admin_name: '';
		$modifiedon 	= date('Y-m-d H:i:s');
		$modifiedby 	= $admin_name? $admin_name: '';
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		if($submit == 'SAVE'){
			$sql = "INSERT INTO salesperson(user_type,user_code,personname, address, city, state, country, pincode, contactno, email, createdby, createdon, modifiedby, modifiedon, ipaddress) VALUES ('$user_type', '$user_code', '$personname', '$address', '$city', '$state', '$country', '$pincode', '$contactno', '$email', '$createdby', '$createdon', '$modifiedby', '$modifiedon', '$ipaddress')";
		}
		if($submit == 'UPDATE'){
			$sql_log = "INSERT INTO salesperson_log SELECT id, user_type, user_code, personname, address, city, state, country, pincode, contactno, email, createdby, createdon, '".$modifiedby."', '".$modifiedon."', '".$ipaddress."' FROM salesperson WHERE id='".$id."'";
			$result_log = $database->query($sql_log);
			
			$sql = "UPDATE salesperson SET user_type='".$user_type."', user_code='".$user_code."', personname='".$personname."', address='".$address."', city='".$city."', state='".$state."', country='".$country."', pincode='".$pincode."', contactno='".$contactno."', email='".$email."', modifiedby='".$modifiedby."', modifiedon='".$modifiedon."', ipaddress='".$ipaddress."' WHERE id='".$id."'";
		}
		
		$result = $database->prepare($sql);
		if($result->execute()){
			if($submit == 'SAVE'){
				$_SESSION['msgD'] = 'Sales person data inserted successfully.';
				
				$sql_user = "INSERT INTO adminuser(username, name, email, role, contact, logintype, ipadd, createddate, createdby, modifiedby, modifiedon) VALUES ('".$user_code."', '".$personname."', '".$email."', '17', '".$contactno."', 'Normal', '".$ipaddress."', '".$createdon."', '".$createdby."', '".$modifiedby."', '".$modifiedon."')";
				$result_user = $database->query($sql_user);
				
			}else{
				$_SESSION['msgD'] = 'Sales person data updated successfully.';
			}			
		}else{
			$_SESSION['msgD'] = 'Error while executing query.';
		}
        
		$result->close();
		$database->close();
		$this->redirect('managesalesman.php');
	}
}

?>
