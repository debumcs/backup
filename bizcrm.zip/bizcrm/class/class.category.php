<?php 
error_reporting(E_ERROR);
ini_set('display_errors', 1);
include_once("database.class.php");
include_once("class.config.php");

class Category extends config{
	
	//public $database;
	
	function __construct() {
		if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
		{
			$this->redirect('index.php');
			exit();
		}
	}
	
	function __destruct() {
		//parent::__construct();
		//$database->close;
	}
	
	public function getAll() {
		$database = new Database();
		
		$sql = "SELECT * FROM discount_advance_category";
		$result = $this->fetchAssoc($sql);
		return $result;
	}
		
	public function getById($id){
		$database = new Database();
	
		$id = $this->sanitize($id);
		$sql = "SELECT * FROM discount_advance_category where id = '".$id."'";
	
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}	
	
	public function save(){
		$database = new Database();
		
		$admin_name = $_SESSION['ADMIN_NAME'];
		$submit = $this->sanitize($_POST["submit"]);
		
		$id 			= $this->sanitize($_POST["id"]);
	    $customer_category 			= $this->sanitize($_POST["customer_category"]);
        $description 	= $this->sanitize($_POST["description"]);
		$advance_percentage 		= $this->sanitize($_POST["advance_percentage"]);
		$discount_percentage 		= $this->sanitize($_POST["discount_percentage"]);
		$cstatus 		= $this->sanitize($_POST["cstatus"]);
		$createdon 		= date('Y-m-d H:i:s');
		$createdby 		= $admin_name? $admin_name: '';
		$modifiedon 	= date('Y-m-d H:i:s');
		$modifiedby 	= $admin_name? $admin_name: '';
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);

		if($submit == 'SAVE'){
			$sql = "INSERT INTO discount_advance_category(customer_category, description, advance_percentage, discount_percentage, createdby, createdon, modifiedby, modifiedon, ipaddress) VALUES ('".$customer_category."', '".$description."', '".$advance_percentage."', '".$discount_percentage."', '".$createdby."', '".$createdon."', '".$modifiedby."', '".$modifiedon."', '".$ipaddress."')";
		}
		if($submit == 'UPDATE'){
			$sql_log = "INSERT INTO discount_advance_category_log SELECT id, customer_category, description, advance_percentage, discount_percentage, cstatus,  createdby, createdon, '".$modifiedby."', '".$modifiedon."', '".$ipaddress."' FROM discount_advance_category WHERE id = '".$id."'";
			$result_log = $database->query($sql_log);
			
			$sql = "UPDATE discount_advance_category SET customer_category='".$customer_category."', description='".$description."', advance_percentage='".$advance_percentage."', discount_percentage='".$discount_percentage."', modifiedby='".$modifiedby."', modifiedon='".$modifiedon."', ipaddress='".$ipaddress."' WHERE id = '".$id."' ";
		}
		
		$result = $database->prepare($sql);
		if($result->execute()){
			if($submit == 'SAVE'){
				$_SESSION['msgD'] = 'Category master data inserted successfully.';
			}else{
				$_SESSION['msgD'] = 'Category master data updated successfully.';
			}			
		}else{
			$_SESSION['msgD'] = 'Error while executing query.';
		}

		$result->close();
		$database->close();
		$this->redirect('manageCategoryMaster.php');
	}	
}

?>
