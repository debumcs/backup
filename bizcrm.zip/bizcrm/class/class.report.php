<?php 
error_reporting(E_ERROR);
ini_set('display_errors', 1);
include_once("database.class.php");
include_once("class.config.php");

class Report extends config{
	
	//public $database;
	
	function __construct() {
		//parent::__construct(); 
		//$database = new Database();
		if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
		{
			$this->redirect('index.php');
			exit();
		}
	}
	
	function __destruct() {
		//parent::__construct();
		//$database->close;
	}
	
	public function getAllCustomer() {
		$database = new Database();
		
		$sql = "SELECT cust_id, salutation, name_first, name_middle, name_last FROM customer ORDER BY name_first ASC";
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getSuborderDetails($orderno) {
		$database = new Database();
	
		$orderno = $this->sanitize($orderno);
		$sql = "SELECT suborderno, orderno, style_ref, sale_amount, trial_date, delivery_due_date, discount_type, (CASE WHEN discount_type = 'Percentage' THEN CONVERT((sale_amount * discount_amount/100), DECIMAL(17,2)) ELSE CONVERT(discount_amount, DECIMAL(17,2)) END) AS discount_amount, substatus, (CASE WHEN discount_type = 'Percentage' THEN CONVERT(sale_amount - (sale_amount * discount_amount/100), DECIMAL(17,2)) ELSE CONVERT((sale_amount - discount_amount), DECIMAL(17,2)) END) AS netamount FROM suborder WHERE orderno = '".$orderno."'";		
		$result = $database->query($sql);
		$alldata = array();
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getSuborderAssignedData($suborderno) {
		$database = new Database();
	
		$orderno = $this->sanitize($orderno);
		$sql = "SELECT s.suborderno, s.original_amount, s.discount_amount, s.sale_amount, func_get_agencyname(dy.dyerid) AS dyername ,dn.dying_notes, dn.dystatus, func_get_agencyname(cu.cutterid) AS cuttername, ct.cutting_notes, ct.custatus, func_get_agencyname(em.embroiderid) AS embroname, en.embroidery_notes, en.emstatus, func_get_agencyname(ta.tailorid) AS tailorname, tn.tailor_notes, tn.tastatus, st.store_in_date,st.store_out_date, sn.store_notes, sn.ststatus FROM suborder s 
		LEFT JOIN dying dy ON dy.suborderno = s.suborderno AND dy.flag = '1'
LEFT JOIN (SELECT * FROM dying_notes dyn WHERE dyn.suborderno = '".$suborderno."' ORDER BY dyn.createdon DESC LIMIT 1) dn ON dn.suborderno = s.suborderno
LEFT JOIN cutting cu ON cu.suborderno = s.suborderno AND cu.flag = '1'
LEFT JOIN (SELECT * FROM cutting_notes ctt WHERE ctt.suborderno = '".$suborderno."' ORDER BY ctt.createdon DESC LIMIT 1) ct ON ct.suborderno = s.suborderno
LEFT JOIN embroidery em ON em.suborderno = s.suborderno AND em.flag = '1'
LEFT JOIN (SELECT * FROM embroidery_notes emn WHERE emn.suborderno = '".$suborderno."' ORDER BY emn.createdon DESC LIMIT 1) en ON en.suborderno = s.suborderno
LEFT JOIN tailor ta ON ta.suborderno = s.suborderno AND ta.flag = '1'
LEFT JOIN (SELECT * FROM tailor_notes tnt WHERE tnt.suborderno = '".$suborderno."' ORDER BY createdon DESC LIMIT 1) tn ON tn.suborderno = s.suborderno
LEFT JOIN store_management st ON st.suborderno = s.suborderno
LEFT JOIN (SELECT * FROM store_notes stm WHERE stm.suborderno = '".$suborderno."' ORDER BY stm.createdon DESC LIMIT 1) sn ON sn.suborderno = s.suborderno
WHERE s.suborderno = '".$suborderno."'";		
		$result = $database->query($sql);
		$field = $result->fetch_assoc();
		$database->close();
		return $field;
	}
	
	public function getAllTrackOrder() {
		$database = new Database();
		
		$order_id 			= $this->sanitize($_POST["order_id"]);
		$customer_id 		= $this->sanitize($_POST["customer_id"]);
		if($order_id != ''){
			$sql = "SELECT CONCAT(c.name_first,' ',c.name_last,'(',c.cust_id,')') AS custname, o.order_type, o.orderno, o.customer_id, o.trial_date, o.delivery_due_date, o.order_date, o.sale_person, o.alt_order_no, o.order_detail, o.orderstatus, s.sale_amount1, s.discount_amount1, s.netamount, p.received_amount FROM orderdetails o INNER JOIN customer c ON o.customer_id = c.cust_id LEFT JOIN (SELECT orderno, CONVERT(SUM(IFNULL(sale_amount,0)), DECIMAL(17,2)) AS sale_amount1, CONVERT(SUM(CASE WHEN discount_type = 'Percentage' THEN (IFNULL(sale_amount,0) * IFNULL(discount_amount,0)/100) ELSE IFNULL(discount_amount,0) END), DECIMAL(17,2)) AS discount_amount1, CONVERT(SUM(CASE WHEN discount_type = 'Percentage' THEN IFNULL(sale_amount,0) - (IFNULL(sale_amount,0) * IFNULL(discount_amount,0)/100) ELSE IFNULL(sale_amount,0) - IFNULL(discount_amount,0) END), DECIMAL(17,2)) AS netamount FROM suborder GROUP BY orderno) s ON s.orderno = o.orderno LEFT JOIN (SELECT SUM(received_amount) AS received_amount, orderno FROM `payment` GROUP BY orderno) p ON p.orderno = o.orderno WHERE o.customer_id = '".$customer_id."' AND o.orderno = '".$order_id."' GROUP BY o.orderno";
		}else{
			$sql = "SELECT CONCAT(c.name_first,' ',c.name_last,'(',c.cust_id,')') AS custname, o.order_type, o.orderno, o.customer_id, o.trial_date, o.delivery_due_date, o.order_date, o.sale_person, o.alt_order_no, o.order_detail, o.orderstatus, s.sale_amount1, s.discount_amount1, s.netamount, p.received_amount FROM orderdetails o INNER JOIN customer c ON o.customer_id = c.cust_id LEFT JOIN (SELECT orderno, CONVERT(SUM(IFNULL(sale_amount,0)), DECIMAL(17,2)) AS sale_amount1, CONVERT(SUM(CASE WHEN discount_type = 'Percentage' THEN (IFNULL(sale_amount,0) * IFNULL(discount_amount,0)/100) ELSE IFNULL(discount_amount,0) END), DECIMAL(17,2)) AS discount_amount1, CONVERT(SUM(CASE WHEN discount_type = 'Percentage' THEN IFNULL(sale_amount,0) - (IFNULL(sale_amount,0) * IFNULL(discount_amount,0)/100) ELSE IFNULL(sale_amount,0) - IFNULL(discount_amount,0) END), DECIMAL(17,2)) AS netamount FROM suborder GROUP BY orderno) s ON s.orderno = o.orderno LEFT JOIN (SELECT SUM(received_amount) AS received_amount, orderno FROM `payment` GROUP BY orderno) p ON p.orderno = o.orderno WHERE o.customer_id = '".$customer_id."'";
		}
		//echo $sql;die();
		$result = $database->query($sql);
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getDelieveriesTrialDue(){
		$database = new Database();
		
		$from_date 			= $this->sanitize($_POST["from_date"]);
		$to_date 			= $this->sanitize($_POST["to_date"]);
		$sql = "SELECT o.orderno, o.customer_id, o.order_date, s.trial_date, s.delivery_due_date, s.original_amount, s.discount_amount, s.sale_amount, p.received_amount FROM orderdetails o LEFT JOIN (SELECT suborderno, orderno, IFNULL(SUM(original_amount),0.00) AS original_amount, IFNULL(SUM(discount_amount),0.00) AS discount_amount, IFNULL(SUM(sale_amount),0.00) AS sale_amount,trial_date,delivery_due_date FROM suborder GROUP BY orderno) s ON o.orderno = s.orderno LEFT JOIN (SELECT orderno, IFNULL(SUM(received_amount),0.00) AS received_amount FROM payment GROUP BY orderno) p ON o.orderno = p.orderno WHERE (s.delivery_due_date BETWEEN '".$from_date."' AND '".$to_date."') OR (s.trial_date BETWEEN '".$from_date."' AND '".$to_date."') GROUP BY o.orderno";
		//echo $sql; die();
		$result = $database->query($sql);
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getPaymentLogs() {
		$database = new Database();
		
		$from_date 			= $this->sanitize($_POST["from_date"]);
		$to_date 			= $this->sanitize($_POST["to_date"]);
		
		$sql = "SELECT customer_id, orderno, payment_date, payment_mode, received_amount FROM payment WHERE (payment_date BETWEEN '".$from_date."' AND '".$to_date."') ";
		
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
}

?>