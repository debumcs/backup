<?php 
	require_once('include/auth.php');
	require_once('class/class.menu.php');
	
	$objmenu = new Menu();  
	
	$alldata = $objmenu->getAll();
	
	$action = $_GET["action"];
	$id = $_GET["id"];
	$msgD = '';
	
	if($action=="edit")
	{
		$data = $objmenu->getById($id);
		$btnvalue = "UPDATE";
	}
	else
	{
		$btnvalue = "SAVE";
	}
	
	if(isset($_POST['submit']))
	{
		$objmenu->save();	
		exit();
	}
              
	
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>BIZCRM | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
   <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <link rel="stylesheet" type="text/css" href="dist/css/jquery.multiselect.css" />

<link rel="stylesheet" type="text/css" href="dist/css/prettify.css" />
<link rel="stylesheet" type="text/css" href="dist/css/jquery-ui1.10.4.css" />

    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    
    <link rel="stylesheet/less" type="text/css" href="side.less" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
    
    <style>
		.ui-multiselect-checkboxes input[type=checkbox]{
			display:inline-block;
		}
	</style>
  <script type="text/javascript" language="javascript">
   function validateMenumaster(){
	if(document.getElementById('header').value =='' ){
	    alert('Please Enter Module Name!');
	    document.getElementById('header').focus();
	    return false;
        }
        
        if(document.getElementById('description').value =='' ){
            alert('Please Enter Description!');
            document.getElementById('description').focus();
            return false;
        }
		
		if(document.getElementById('pagename').value =='' ){
            alert('Please enter Page Name!');
            document.getElementById('pagename').focus();
            return false;
        }
    }
   </script>
  </head>
  <body class="hold-transition skin-blue sidebar-mini" onload="prettyPrint();">
  <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
    <div class="wrapper">

		<?php $objmenu->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objmenu->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
		
          <h1>
            Menu Master
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Control Panel</li>
            <li class="active">Menu Master</li>
          </ol>
        </section><!--CONTENT HEADER-->
        
          <!-- Main content -->
        <section class="content">
		<form name="menumaster" id="menumaster" action="menuMaster.php" method="post">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title">General</h3><label style='float:right'>Fields marked with a asterisk (<font color='red'>*</font>) are mandatory.</span>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <div class="row">
                              <div class="col-lg-6">
                              		<div class="form-group">
                                      <label for="name">Control/Module Name</label>&nbsp;<font color='red'>*</font>
                                      <input type="text" class="form-control" value="<?php echo $data['header'];?>" id="header" name="header" placeholder="Enter Menu Header" />
									  <input type="hidden" value="<?php echo $data['menuid'];?>" id="menuid" name="menuid" />
                                    </div>
                                    
                                    
                                  <div class="form-group">
                                          <label>Description</label></label>&nbsp;<font color='red'>*</font>
                                          <textarea class="form-control" rows="2" name="description" id="description" placeholder="Enter Menu Description"><?php echo $data['description'];?></textarea>
                    			  </div> 
                                    
                              </div><!-- /.col -->
                              
                              <div class="col-lg-6">
                                  <?php if($action=="edit") { ?>	
                              	    <div class="form-group">
                                      	<label>User Visibility</label>
                                          <ul class="columns">
                                            <li>
                                            <input type="checkbox" id="u1" name="status" <?php if($data['mstatus'] == '1'){echo 'checked';}else{echo '';} ?> value="1" />
                                            <label class="toggle <?php if($data['mstatus'] == '1'){echo 'custom-checked';}else{echo '';} ?>" for="u1"></label>
                                            Active
                                            </li>
                                          </ul>
                                       </div>
                                  <?php } ?>
                                    
                                 </div><!-- /.col -->
                              
                           </div><!-- /.row -->
                           
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
              
              <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title">Parent Menu</h3></label>&nbsp;<font color='red'>*</font>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <div class="row">
                              <div class="col-lg-6">
								<div class="form-group">
                              		<select class="form-control" name="parent_menuid" id="parent_menuid">
										 <option value="<?php echo $data['parent_menuid']; ?>" selected><?php echo $data['pheader']; ?></option>
										<?php for($i=0; $i<count($alldata); $i++) { ?>	
										<option value="<?php echo $alldata[$i]['menuid'];?>"><?php echo $alldata[$i]['header']; ?></option>
                                                                                <?php  }  ?>
                                    </select>
								</div>
								
								<div class="form-group">
									<label for="name">Menu Order</label></label>
									<input type="text" class="form-control" value="<?php echo $data['menuorder'];?>" id="menuorder" name="menuorder" placeholder="Enter menu order" />									
								</div>
								
                              </div><!-- /.col -->
                            </div><!-- /.row -->
                           
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row --> 
              
              <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title">Page Name</h3></label>&nbsp;<font color='red'>*</font>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <div class="row">
                              <div class="col-lg-6">
                              		<input type="text" class="form-control" id="pagename" name="pagename" value="<?php echo $data['pagename']; ?>" placeholder="Enter Page Name">
                              </div><!-- /.col -->
                            </div><!-- /.row -->
                           
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row --> 
			  
				<div class="row">
					<div class="col-lg-12">
						<div class="form-group center">
						<input type="submit" name="submit" id="submit" class="btn btn-warning left-10" value="<?php echo $btnvalue; ?>" onclick="return validateMenumaster();" />
						<a href="manageMenuMaster.php" class="btn btn-warning left-10">View All</a>
						</div>
					</div><!-- /.col -->
				</div><!-- /.row -->
              
              
              
                 
              </form>
             <!--CONTENT-->
      </div><!-- /.content-wrapper -->
      
      
      <?php include('footer.php'); ?> 

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!--css tree-->
    <script>
		$(function() {

  $('input[type="checkbox"]').change(checkboxChanged);

  function checkboxChanged() {
    var $this = $(this),
        checked = $this.prop("checked"),
        container = $this.parent(),
        siblings = container.siblings();

    container.find('input[type="checkbox"]')
    .prop({
        indeterminate: false,
        checked: checked
    })
    .siblings('label')
    .removeClass('custom-checked custom-unchecked custom-indeterminate')
    .addClass(checked ? 'custom-checked' : 'custom-unchecked');

    checkSiblings(container, checked);
  }

  function checkSiblings($el, checked) {
    var parent = $el.parent().parent(),
        all = true,
        indeterminate = false;

    $el.siblings().each(function() {
      return all = ($(this).children('input[type="checkbox"]').prop("checked") === checked);
    });

    if (all && checked) {
      parent.children('input[type="checkbox"]')
      .prop({
          indeterminate: false,
          checked: checked
      })
      .siblings('label')
      .removeClass('custom-checked custom-unchecked custom-indeterminate')
      .addClass(checked ? 'custom-checked' : 'custom-unchecked');

      checkSiblings(parent, checked);
    } 
    else if (all && !checked) {
      indeterminate = parent.find('input[type="checkbox"]:checked').length > 0;

      parent.children('input[type="checkbox"]')
      .prop("checked", checked)
      .prop("indeterminate", indeterminate)
      .siblings('label')
      .removeClass('custom-checked custom-unchecked custom-indeterminate')
      .addClass(indeterminate ? 'custom-indeterminate' : (checked ? 'custom-checked' : 'custom-unchecked'));

      checkSiblings(parent, checked);
    } 
    else {
      $el.parents("li").children('input[type="checkbox"]')
      .prop({
          indeterminate: true,
          checked: false
      })
      .siblings('label')
      .removeClass('custom-checked custom-unchecked custom-indeterminate')
      .addClass('custom-indeterminate');
    }
  }
});
	</script>
     
    <script type="text/javascript" src="dist/js/jquery1.11.1.js"></script>
<script type="text/javascript" src="dist/js/jquery-ui.min1.10.4.js"></script>
<script type="text/javascript" src="dist/js/jquery.multiselect.js"></script>
<script type="text/javascript" src="dist/js/prettify.js"></script>
<script type="text/javascript">
$(function(){
	//$("select").multiselect();
	$(".mul").multiselect();
});

$("#message").fadeIn('slow').delay(5000).fadeOut('slow');
</script>
    <script src="plugins/select2/select2.js"></script>
    <!-- iCheck 1.0.1 -->
    <script src="plugins/iCheck/icheck.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    
    <script src="dist/js/pages/dashboard.js"></script>
    
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    
    
  </body>
</html>