<?php 

echo '<h1>Access Denied</h1>';

?>