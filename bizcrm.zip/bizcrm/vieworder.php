<?php 
	require_once('class/class.stylemaster.php');
	$objstyle = new Stylemaster();
	$allstyle = $objstyle->getAll();
	$allCusStyle 	= $objstyle->getAllCustomized();
	
	require_once('class/class.statusmaster.php');
	$objStatus 	= new Statusmaster();
	$allStatus 	= $objStatus->getAll();

	require_once('class/class.orderdetails.php');
	$objord = new Orderdetails();
	
	$orderno = $_GET['orderno'];
	$subdata = array();
	$alldata = $objord->getAllSuborder($orderno);
	
	foreach($alldata as $suborderJSON){
		$subdata[] = $suborderJSON['suborderno'];
	}
	$JSONallsuborder = json_encode($subdata);
	
	$orderData = $objord->getById($orderno);
	$allpayment = $objord->getAllPaymentByOrderno($orderno);
	
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="bootstrap/css/datepicker.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
    <link rel="stylesheet" type="text/css" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css"></link>
	
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />
	
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	
	<style>
	.connecting_preference_checkbox{
		display:block !important; float:left; width:20px;
	}
	.connecting_preference_box{
		display: block;float: left;width: 25%;
	}
	.datepicker{z-index:1151 !important;}
	#modalstyledetails{
		background-color: #FEF6EB;
		border-top: 1px dotted #ddd;
		border-left: 1px dotted #ddd;
		border-right: 1px dotted #ddd;
	}
	#modalstyledetails .row div.col-lg-12 {
		padding-top: 7px;
		border-bottom: 1px dotted #ddd;
	}
	#modalFabricDetails .row div.col-lg-12 {
		padding-top: 7px;
		border-bottom: 1px dotted #ddd;
		border-top: 1px dotted #ddd;
		border-left: 1px dotted #ddd;
		border-right: 1px dotted #ddd;
	}
	.abcd22 {
		display:block;
		height:200px;
		overflow:auto;
	}
	.abcd33, .abcd22 tr {
		display:table;
		width:100%;
		table-layout:fixed;/* even columns width , fix width of table too*/
	}
	.abcd33 {
		width: calc( 100% - 17px );/* scrollbar is average 1em/16px width, remove it from thead width */
	}
	</style>

  </head>
  <body class="hold-transition skin-blue sidebar-mini">
 <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objord->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objord->pssidebar(); ?>

		<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Manage Sub-Order Details
          </h1>
           
            <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Order</li>
            <li class="active">Manage Sub-Order Details</li>
          </ol>
        </section><!--CONTENT HEADER-->
		
        <section class="content">
            <div class="row">
			
            	<div class="col-md-12">
              		<div class="box box-warning">
					<div class='box-body'>
						<div class="row">
							<div class="col-md-12">
								<br/>
								<div class="col-lg-4">
									<div class="form-group">
										<label for="name"><?php echo $orderData['custname']; ?></label>								
									</div>
								</div>
								
								<div class="col-lg-4">
									<div class="form-group">
										<label for="name">Order Number : <?php echo $orderData['orderno']; ?></label>
									</div>
								</div>

								<div class="col-lg-4">
									<div class="form-group">
										<label for="name">Order Date : <?php echo $objord->date_ymd_dmy($orderData['order_date']); ?></label>
									</div>
								</div>									
							</div>
							
							<div class="col-md-12">
								<div class="col-lg-4">
									<div class="form-group">
										<label for="name">Sale Person : <?php echo $orderData['personname']; ?></label>
									</div>
								</div>
								
								<div class="col-lg-4">
									<div class="form-group">
										<label for="name">Trial Date : <?php echo $objord->date_ymd_dmy($orderData['trial_date']); ?></label>
									</div>
								</div>

								<div class="col-lg-4">
									<div class="form-group">
										<label for="name">Delivery Due Date : <?php echo $objord->date_ymd_dmy($orderData['delivery_due_date']); ?></label>
									</div>
								</div>									
							</div>
							
							<div class="col-md-12">
								<div class="col-lg-12">
									<div class="form-group">
										<label for="name">Order Details : <?php echo $orderData['order_detail']; ?></label>
									</div>
								</div>
							</div>
							
						</div><!-- /.row -->
					</div><!-- /.box-body -->
					
					
                 <div class='box-body table-responsive'>
					<div class="row">
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						
							<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
								<div class="form-group">
									<label for="name">Sub-Order Details List: </label>
								</div>
							</div>
							
							<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
								<div class="form-group pull-right">
									<label for="name"><a href="#" class="btn btn-info btn-xs" data-toggle="modal" data-target="#suborder" onclick='getSuborderForm("<?php print $orderData['orderno']; ?>","<?php print $objord->date_ymd_dmy($orderData['trial_date']); ?>","<?php print $objord->date_ymd_dmy($orderData['delivery_due_date']); ?>")'>Add New Suborder</a></label>
								</div>
							</div>
							
						</div>	
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<table class="table table-bordered table-striped">
						<thead>
						<tr>
							<th></th>
							<th><b>Sub Order No</b></th>
							<th><b>Style Ref</b></th>
							<th><b>Trial Date</b></th>
							<th><b>Delivery Date</b></th>
							<th><b>Sale Amount</b></th>
							<th><b>Discount</b></th>
							<th><b>Net Payable</b></th>
							<th><b>Action</b></th>                    
						</tr>
						</thead>
						<tbody>
						<?php if(count($alldata) <= 0){ ?>
						<tr>
							<th colspan="9" style="text-align:center;">No Records Found</th>
						</tr>
						<?php }else{ ?>
						<?php for($i=0; $i<count($alldata); $i++) { ?>	
						<tr id="<?php print $alldata[$i]['orderno']; ?>">
                            <?php if($alldata[$i]['status']=='1'){$status='Active';}else{$status='Inactive';}
							$id= $alldata[$i]['id'];
							?>
							<td style='display: inline-block;position: relative;top: 1px;left: 5px;' class="accordion-toggle" data-toggle="collapse" data-target="#packageDetails<?php print $alldata[$i]['suborderno']; ?>" onclick="getItemBySO('<?php print $alldata[$i]['suborderno']; ?>');"><i class="indicator glyphicon pull-right glyphicon-chevron-down"></i></td>
							<td><?php echo $alldata[$i]['suborderno']; ?></td>
							<td><a href="#" data-toggle="modal" data-target="#styledetails" onclick="getStyleDetials('<?php echo $alldata[$i]['style_ref']; ?>')"><?php echo $alldata[$i]['style_ref']; ?></a></td>
							<td><?php echo $objord->date_ymd_dmy($alldata[$i]['trial_date']); ?></td>
							<td><?php echo $objord->date_ymd_dmy($alldata[$i]['delivery_due_date']); ?></td>
							<td><?php echo $alldata[$i]['sale_amount']; ?></td>
							<td><?php echo $alldata[$i]['discount_amount']; ?></td>
							<td><?php echo $alldata[$i]['netamount']; ?></td>
							<td><a href="#" data-toggle="modal" data-target="#editsuborder" onclick='editsuborder("<?php print $alldata[$i]['suborderno']; ?>")' >Edit</a>&nbsp;|&nbsp;
							<a href="suborderDetails.php?action=editsub&orderno=<?php print $alldata[$i]['orderno'];?>&suborder=<?php echo $alldata[$i]['suborderno']; ?>">View Details | Add Items</a>&nbsp;|&nbsp;
							<a href="#" data-toggle="modal" data-target="#subOrderNotes" onclick='getSubOrderNotes("<?php echo $orderData['orderno']; ?>","<?php print $alldata[$i]['suborderno']; ?>")'>Sub Order Notes</a>
							</td>
						</tr>
						<tr>
							<td colspan="9" style="padding:0!important;background-color: #f1e9de;"><div id="packageDetails<?php print $alldata[$i]['suborderno']; ?>" class="accordian-body collapse" style="width:93%; margin: 1% 4%;background:#ddd;"></div></td>
						</tr>
						<?php } ?>
						<?php } ?>
                    </tbody>
                </table>
					</div>
				</div>
				
				<div class='box-body'>
					<div class="col-md-12">&nbsp;</div>
					<div class="col-md-12">&nbsp;</div>
					<div class="col-md-12">
						<div class="col-md-6">
							<label for="name">Payment Details of Order No. <?php echo $orderData['orderno']; ?></label>
						</div>
						<?php if(floatval($orderData['order_amount'])>0){ ?>
						<div class="col-md-6" style="text-align:right;">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name">Total Amount : </label>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name"><?php print number_format(floatval($orderData['order_amount']),2,".",""); ?></label>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name">Discount : </label>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name"><?php print number_format(floatval($orderData['order_discount']),2,".",""); ?></label>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name">Net Payable : </label>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name"><?php print number_format(floatval($orderData['order_netamount']),2,".",""); ?></label>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name">Received Amount : </label>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name"><?php print number_format(floatval($orderData['received_amount']),2,".",""); ?></label>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name">Balance Amount : </label>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name">
									<?php print number_format(floatval($orderData['order_netamount']) - floatval($orderData['received_amount']),2,".",""); ?></label>
								</div>
							</div>
						</div>
						<?php }else{ ?> 
						<div class="col-md-6" style="text-align:right;">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name">Total Amount : </label>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name"><?php print number_format(floatval($orderData['sale_amount1']),2,".",""); ?></label>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name">Discount : </label>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name"><?php print number_format(floatval($orderData['discount_amount1']),2,".",""); ?></label>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name">Net Payable : </label>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name"><?php print number_format(floatval($orderData['netamount']),2,".",""); ?></label>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name">Received Amount : </label>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name"><?php print number_format(floatval($orderData['received_amount']),2,".",""); ?></label>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name">Balance Amount : </label>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
									<label for="name">
									<?php print number_format(floatval($orderData['netamount']) - floatval($orderData['received_amount']),2,".",""); ?></label>
								</div>
							</div>
						</div>
						<?php } ?>
						
					</div><!-- /.col -->
					<div class="col-md-12">&nbsp;</div>
					<div class="col-md-12">&nbsp;</div>
					
				</div><!-- /.col -->
				<div class='box-body table-responsive'>
					<div class="col-md-12">
						<div class="col-lg-12">
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6"><b>Payment History</b></div>
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6"><a href="#" style="float: right;" data-toggle="modal" data-target="#paymentorder" class="btn btn-info btn-xs left-10">Add Payment</a></div>
						</div>
						<table id="example111" class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>SL. No.</th>
									<th>Sub-order No</th>
									<th>Payment Date</th>
									<th>Payment Mode </th>
									<th>Received Amount</th>
									<th>Remarks</th>
									<th></th>
								</tr>
							</thead>
							<tbody>
							<?php if(count($allpayment) <= 0){ ?>
							<tr>
								<th colspan="7" style="text-align:center;">No Records Found</th>
							</tr>
							<?php }else{ ?>
							<?php for($i=0; $i<count($allpayment); $i++) { ?>
								<tr>
									<td><?php $j= $i+1; echo $j; ?></td>
									<td><?php echo $allpayment[$i]['suborderno']; ?></td>
									<td><?php echo $objord->date_ymd_dmy($allpayment[$i]['payment_date']); ?></td>
									<td><?php echo $allpayment[$i]['payment_mode']; ?></td>
									<td><?php echo $allpayment[$i]['received_amount']; ?></td>
									<td><?php echo $allpayment[$i]['remarks']; ?></td>
									<td><a href="#" data-toggle="modal" data-target="#editpaymentorder" onclick="editPayment('<?php print $allpayment[$i]['id'];?>')">Edit</a>&nbsp;|&nbsp;<a href="#" onclick='deletepayment("<?php print $allpayment[$i]['id'];?>")'>Delete</a></td>
								</tr>
							<?php } } ?>						
							</tbody>
						</table>						
					</div>
						
						
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="text-align:center;">
						<br/><br/><br/><label for="name"><a href="orderManage.php" class="btn btn-info btn-xs" role="button">Back</a></label>
						</div><!-- /.col -->
						
                          </div><!-- /.box-body--> 						  
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
				
              </div><!-- /.row -->
        </section><!--CONTENT-->
		
		
      </div><!-- /.content-wrapper -->
      
      
	  
	  
      <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->

<!-- Start Work History -->	
<div class="modal fade" id="viewhistory" tabindex="-1" role="dialog" aria-labelledby="viewhistoryLabel">
	<div class="modal-dialog" role="document">	
	<div class="modal-content">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Work Status History</h4>
		</div>
		<div class="modal-body">
			<div class="row" id="workstatusdatabyassignedid">
				
			</div>
		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		</div>
	</div>	
	</div>
</div>
<!-- End Work History -->

<!-- Customer Popup Info-->
<div class="modal fade" id="editsuborder" tabindex="-1" role="dialog" aria-labelledby="orderdetailsLabel">
	<div class="modal-dialog modal-lg" role="document">
	<div class="modal-content">
	
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Update Suborder</h4>
		</div>
		<div class="modal-body">
			<div class="row">
				<div class="col-lg-12" id="editNewSuborderMSG"></div>
				
				<div class="col-lg-12" id="editNewSuborder">
					
				</div><!-- /.col -->
			</div><!-- /.row -->
		</div>
		<div class="modal-footer">
			<input type="button" class="btn btn-primary" name="editsuborderbutton" id="editsuborderbutton" onclick="updatesuborder();" value="Update" />
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		</div>
	
	</div>	
	</div>
</div>

<div class="modal fade" id="editpaymentorder" tabindex="-1" role="dialog" aria-labelledby="paymentformLabel">
	<div class="modal-dialog" role="document">	
	<div class="modal-content">
	
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Manage Payment</h4>
		</div>
		<div class="modal-body">
			<div class="row">
				<div class="col-lg-12" id="editpaymentform">
					
				</div><!-- /.col -->
			</div><!-- /.row -->
		</div>
		<div class="modal-footer">
			<input type="button" class="btn btn-primary" name="editpaymentbutton" id="editpaymentbutton" onclick="updatepayment();" value="Update" />
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		</div>
	
	</div>	
	</div>
</div>

<div class="modal fade" id="paymentorder" tabindex="-1" role="dialog" aria-labelledby="orderdetailsLabel">
	<div class="modal-dialog" role="document">	
	<div class="modal-content">
	
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Manage Payment</h4>
		</div>
		<div class="modal-body">
			<div class="row">
				<div class="col-lg-12" id="paymentform">
					<div class="col-lg-12">
						<div class="form-group">
						  <label for="name">Sub-Order</label>
						  <select name="payment_suborder" class="form-control" id="payment_suborder">
						  <option value="" disabled selected>Select Sub-Order</option>
						  <?php foreach($alldata as $paysuborder){ ?>
						  <option value="<?php echo $paysuborder['suborderno']; ?>"><?php echo $paysuborder['suborderno']; ?></option>
						  <?php } ?>
						  </select>
						</div>
						
						<div class="form-group">
							<label for="name">Payment Date</label>
							<input type="text" class="form-control datepicker" id="payment_date" name="payment_date" placeholder="Enter payment date" value="" />
							<input type="hidden" id="payment_orderno" name="payment_orderno" value="<?php echo $orderno; ?>">
							<input type="hidden" id="payment_customer_id" name="payment_customer_id" value="<?php echo $orderData['customer_id']; ?>">
						</div>
						
						<div class="form-group">
						  <label for="name">Payment Mode</label>
						  <select name="payment_mode" class="form-control" id="payment_mode">
						  <option value="">Select Payment Mode</option>
						  <option value="Cash">Cash</option>
						  <option value="CreditCard">CreditCard</option>
						  <option value="Cheque">Cheque</option>
						  <option value="MobileWallet">MobileWallet</option>
						  </select>
						</div>
						
						 <div class="form-group">
						  <label for="name">Received Amount</label>
						  <input type="text" class="form-control" id="received_amount" onKeyPress="return isDecimalNumber(event,this);" name="received_amount" placeholder="Enter received amount">
						</div>
						
						<div class="form-group">
						  <label for="name">Remarks</label>
						  <input type="text" class="form-control" id="remarks" name="remarks" placeholder="Enter remarks">
						</div>
					</div><!-- /.col -->
				</div><!-- /.col -->
			</div><!-- /.row -->
		</div>
		<div class="modal-footer">
			<input type="button" class="btn btn-primary" name="addpayment" id="addpayment" onclick="addpayment();" value="Submit" />
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		</div>
	
	</div>	
	</div>
</div>
	
<div class="modal fade" id="orderdetails" tabindex="-1" role="dialog" aria-labelledby="orderdetailsLabel">
	<div class="modal-dialog" role="document">	
	<div class="modal-content">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Order Details </h4>
		</div>
		<div class="modal-body">
			<div class="row">
				<div class="col-lg-12" id="orderdata">


				</div><!-- /.col -->
			</div><!-- /.row -->
		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		</div>
	</div>	
	</div>
</div>

<div class="modal fade" id="subOrderNotes" tabindex="-1" role="dialog" aria-labelledby="addMySubOrderNotesLabel">
	<div class="modal-dialog modal-lg" role="document">
	
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Sub Order Notes</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-lg-12" id='dsubordernotes'>
					
					</div>
					<div class="col-lg-12" style="padding-top:20px;">
						<div class="col-lg-6">
							<div class="form-group">
								<label for="name">Enter Notes</label>
								<textarea  class="form-control" id="suborder_note" name="suborder_note" placeholder="Enter Notes" required></textarea>
							</div>
						</div>
						<div class="col-lg-3">
							<div class="form-group">
								<label for="name">Status Date</label>
								<input type="text" class="form-control datepicker" id="subordernotestatusdate" name="subordernotestatusdate" placeholder="order note status date" value="">
							</div>
						</div>
						<div class="col-lg-3">
							<div class="form-group">
								<label for="name">Status</label>
								<select name="subordernotestatus" id="subordernotestatus" class="form-control" style="width:100%;">
								<?php foreach($allStatus as $orderstatus){ ?>
								<option value="<?php echo $orderstatus['id']; ?>"><?php echo $orderstatus['statusname']; ?></option>
								<?php } ?>
								</select>
							</div>
						</div>
					</div>
				</div><!-- /.col -->                             

			</div><!-- /.row -->
		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			<input type="hidden" name="suborder_id"  id="suborder_id" value="" />
			<input type="hidden" name="order_id"  id="order_id" value="" />
			<input type="button" class="btn btn-primary" name="saveSuborderNote" id="saveSuborderNote" value="Save" onclick='addsubordernotes();' />
		</div>
	
	</div>
</div>

<div class="modal fade" id="ViewAgency" tabindex="-1" role="dialog" aria-labelledby="addMySubOrderNotesLabel">
	<div class="modal-dialog" role="document">
	
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Sub Order Notes</h4>
			</div>
			<div class="modal-body" id="AgencyDetails">
				                            

			</div><!-- /.row -->
		</div>		
	
	</div>
</div>

<div class="modal fade" id="styledetails" tabindex="-1" role="dialog" aria-labelledby="styledetailsLabel">
	<div class="modal-dialog" role="document">
	
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Style Details</h4>
			</div>
			<div class="modal-body">
				<div id="modalstyledetails">

				</div>
			</div><!-- /.row -->
		</div>		
	
	</div>
</div>

<div class="modal fade" id="viewfabric" tabindex="-1" role="dialog" aria-labelledby="styledetailsLabel">
	<div class="modal-dialog" role="document">
	
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Fabric Details</h4>
			</div>
			<div class="modal-body">
				<div id="modalFabricDetails">

				</div>
			</div><!-- /.row -->
		</div>		
	
	</div>
</div>

<div class="modal fade" id="suborder" tabindex="-1" role="dialog" aria-labelledby="orderdetailsLabel">
	<div class="modal-dialog modal-lg" role="document">
	<div class="modal-content">
	
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Create New Suborder</h4>
		</div>
		<div class="modal-body">
			
					<div class="row"  style="clear: both;">
						<fieldset class="fsStyle">
							<legend class="legendStyle">
								<a href="#">Style Selection</a>
							</legend>
							<input type="hidden" id="sorderno" name="sorderno" value="" />
							<div class="col-lg-4">
								<div class="form-group">
									<label for="name">Style Ref Type</label>
									<div style="width:100%;">
									<input type="radio" id="existing_type" name="style_ref_type" value="1" />Existing
									<input type="radio" id="customized_type" name="style_ref_type" value="0" />Customized
									</div>
								</div>	
							</div><!-- /.col -->
							
							<div style="width:100%;">
								<div class="col-lg-4" id="existing_type_ref" style="display:block;">
									<div class="form-group">
										<label for="name">Style Ref</label>
										<select id="style_ref" tabindex="2" class="form-control" name="style_ref" onchange="getRecomandedPrice(this.value);">
										<option value="" selected="selected">Select Style Ref</option>
										<?php for($si = 0; $si < count($allstyle); $si++){ ?>
										<option value="<?php echo $allstyle[$si]['style_code']; ?>"><?php echo $allstyle[$si]['style_code']; ?></option>
										<?php } ?>
										</select>
									</div>
								</div>
								
								<div class="col-lg-4" id="customized_type_ref" style="display:none;">
									<div class="form-group">
										<label for="name">Customized Style Type</label>
										<div style="width:100%;">
										<input type="radio" id="customized_existing_type" name="customized_style_ref_type" value="1" onclick="customized_ref_type(this.value)" />Existing
										<input type="radio" id="customized_type" name="customized_style_ref_type" value="0" onclick="customized_ref_type(this.value)" />New
										</div>
									</div>	
								</div><!-- /.col -->
								
								<div class="col-lg-4" id="customized_type_ref_list" style="display:none;">
									<div class="form-group">
										<label for="name">Customized Style Ref</label>
										<select id="customized_style_ref" class="form-control" name="customized_style_ref" onchange="getCustomizedRecomandedPrice(this.value);">
										<option value="" selected="selected">Select Style Ref</option>
										<?php for($csi = 0; $csi < count($allCusStyle); $csi++){ ?>
										<option value="<?php echo $allCusStyle[$csi]['style_code']; ?>"><?php echo $allCusStyle[$csi]['style_code']; ?></option>
										<?php } ?>
										</select>
									</div>
								</div>
								
							</div>
							</fieldset>
						</div>
						<div class="row" id="selectedstyle" style="display:none; clear: both;"></div>
						<div class="row" id="newcusomizedstyle" style="display:none; clear:both;">
						<fieldset class="fsStyle">
							<legend class="legendStyle">
								<a href="#">New Customized Style</a>
							</legend>

							<div class="row">
								<div class="col-lg-4">
									<div class="form-group">
										<label for="name">Style Code</label><?php echo $MANDATORY; ?>
										<input type="text" class="form-control" id="style_code" name="style_code" placeholder="Enter Style Code" value="">
									</div>
								</div>
								<div class="col-lg-4">
									<div class="form-group">
										<label for="name">Description</label><?php echo $MANDATORY; ?>
										<input type="text" class="form-control" rows="2" id="description" name="description" placeholder="Enter Description" value="" >
									</div>
								</div>
								<div class="col-lg-4">
									<div class="form-group">
										<label for="name">Style Group Code</label>
										<input type="text" class="form-control" id="style_group_code" name="style_group_code" placeholder="Enter style group code" value="">
									</div>
								</div>
							</div><!-- /.col -->
							
							<div class="row">
								<div class="col-lg-4">
									<div class="form-group">
										<label for="name">Designer Code</label>
										<input type="text" class="form-control" id="designer_code" name="designer_code" placeholder="Enter Designer Code" value="">
									</div>
								</div>
																
								<div class="col-lg-4">
									<div class="form-group">
										<label for="name">Recommended Selling Price</label>
										<input type="text" class="form-control" id="selling_price" name="selling_price" placeholder="Enter Selling Price" onKeyPress="return isDecimalNumber(event,this);" onfocus="if(this.value=='0' || this.value=='0.00') this.value = ''" onblur="if(this.value=='')this.value = '0'" value="0">
									</div>
								</div>
								
							</div><!-- /.col -->
							<div class="row">
								<div class="col-lg-6">
									<div class="form-group">
										<label for="name">Picture</label><?php echo $MANDATORY; ?>&nbsp;<font color='red'>(Allowed image formate : gif, jpeg, jpg, png)</font>
										<input type="file"  name="styleimage" id="styleimage" size="30" >
									</div>
								</div>
								<div class="col-lg-6" id="showstyleimages">
									
								</div>
							</div><!-- /.col -->
							
						</fieldset>
							
					   </div><!-- /.row -->
						
					<div class="row"  style="clear: both;">
						<fieldset class="fsStyle">
							<legend class="legendStyle">
								<a href="#">Sub-Order Details</a>
							</legend>
						<div class="row">
							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Sale Amount</label>
									<input type="text" class="form-control" tabindex="3" id="sale_amount" name="sale_amount" onKeyPress="return isDecimalNumber(event,this);" onfocus="if(this.value=='0' || this.value=='0.00') this.value = ''" onblur="if(this.value=='')this.value = '0'" value="0" >
								</div>			  
							</div><!-- /.col -->
							
							<div class="col-lg-4">
								<div class="form-group">
									<label for="name">Discount Type </label>
									<div style="width:100%;">
									<input type="radio" id="discount_type" tabindex="6" name="discount_type" value="Amount">Amount
									<input type="radio" id="discount_type" tabindex="7" name="discount_type" value="Percentage">Percentage
									</div>
								</div>
							</div><!-- /.col -->
							
							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Discount Value</label>
									<input type="text" class="form-control" tabindex="8" onKeyPress="return isDecimalNumber(event,this);" id="discount_amount" name="discount_amount" placeholder="Enter Discount Amount" onfocus="if(this.value=='0' || this.value=='0.00') this.value = ''" onblur="if(this.value=='')this.value = '0'" value="0">
								</div>			  
							</div><!-- /.col -->
							
						</div>
								
						<div class="row">
							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Trial Date</label>
									<input type="text" class="form-control datepicker" tabindex="4" id="trial_date1" name="trial_date1" placeholder="Enter trial date" value="<?php echo date('d/m/Y'); ?>">
								</div>			  
							</div><!-- /.col -->
							
							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Delivery Due Date</label>
									<input type="text" class="form-control datepicker" tabindex="5" id="delivery_due_date1" name="delivery_due_date1" placeholder="Delivery due date" value="<?php echo date('d/m/Y'); ?>">
								</div>			  
							</div><!-- /.col -->
							
							<div class="col-lg-4">
								<div class="form-group">
									<label for="name">Sub-Order Status</label>
									<select name="substatus" tabindex="7" id="substatus" class="form-control" style="width:100%;">
									<?php foreach($allStatus as $orderstatus){ ?>
									<option value="<?php echo $orderstatus['id']; ?>"><?php echo $orderstatus['statusname']; ?></option>
									<?php } ?>
									</select>
								</div>	
							</div>
						</div>
						
						<div class="row">
							<div class="col-lg-12">										
								<div class="form-group">
									<label for="name">Sub Order Detail</label>
									<textarea tabindex="9" id="details" name="details" class="form-control" placeholder="Sub Order Detail" ></textarea>
								</div>									  
							</div><!-- /.col -->
						</div>
						</fieldset>
							
					  </div><!-- /.row -->
					
		</div>
		<div class="modal-footer">
			<input type="button" class="btn btn-primary" tabindex="10" name="addsuborder" id="addsuborder" onclick="addsuborder();" value="Submit" />
			<button type="button" class="btn btn-default" tabindex="11" data-dismiss="modal">Close</button>
		</div>
	
	</div>	
	</div>
</div>

<!-- jQuery 2.1.4 -->
<script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="dist/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="dist/js/jquery.form.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script src="bootstrap/js/bootstrap-datepicker.js"></script>
<script type="text/javascript">
// When the document is ready
$(document).ready(function (){
	
	$('.datepicker').datepicker({
		format: "dd/mm/yyyy",
		autoclose: true,
		forceParse : false
	});	
	
});	


</script>
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.5 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="plugins/select2/select2.js"></script>

<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>

<script>
function gethistorybyassignedid(assignedid){
	
	var task = 'history_assigned_id';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data:{task:task,assignedid:assignedid},
		success: function(data){
			//console.log(data);
			$("#workstatusdatabyassignedid").html('');
			$("#workstatusdatabyassignedid").html(data);			
			return false;
		}
	});
	return false;
}

function getSuborderForm(orderno,trial_date,delivery_due_date){
	$("#sorderno").val(orderno);
	$("#trial_date1").val(trial_date);
	$("#delivery_due_date1").val(delivery_due_date);
	return false;
}

function viewagency(suborderno){
	
	var task = 'ViewAgency';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data:{task:task,suborderno:suborderno},
		success: function(data){
			console.log(data);
			$("#AgencyDetails").html('');
			$("#AgencyDetails").html(data);			
			return false;
		}
	});
	return false;
}


function updatesuborderrow(suborderno){
	
	var task = 'updatesuborderrow';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data:{task:task,suborderno:suborderno},

		success: function(response){
			console.log(response);
			$("#"+suborderno).html('');
			$("#"+suborderno).html(response);
			return false;
		}
	});
	return false;
}

function updatesuborder(){
	
	var suborderno 					= $("#editsuborderno").val();
	var orderno 					= $("#editorderno").val();
	var style_ref_type 				= $("input[name=edit_style_ref_type]:checked").val();
	var style_ref 					= $("#edit_style_ref").val();
	
	/*var customized_style_ref_type 	= $("input[name=edit_customized_style_ref_type]:checked").val();
	var customized_style_ref 		= $("#edit_customized_style_ref").val();
	var style_code 					= $("#edit_style_code").val();
	var description 				= $("#edit_description").val();
	var style_group_code 			= $("#edit_style_group_code").val();
	var designer_code 				= $("#edit_designer_code").val();
	var cost_price 					= $("#edit_cost_price").val();
	var selling_price 				= $("#edit_selling_price").val();*/
	var sale_amount 				= $("#edit_sale_amount").val();
	var trial_date1 				= $("#edit_trial_date1").val();
	var delivery_due_date1 			= $("#edit_delivery_due_date1").val();
	var discount_type 				= $("input[name=edit_discount_type]:checked").val();
	var discount_amount 			= $("#edit_discount_amount").val();
	var details 					= $("#edit_details").val();
	var substatus 					= $("#edit_substatus").val();
	/*var imagename					= $("#imagename_hidden").val();
	var imagelocation				= $("#imagelocation_hidden").val();*/
	var submit = 'UPDATE';
		
	if ( parseFloat(sale_amount) <= 0) {
		alert('Please enter sale amount!');
		return false;
	}
	
	if ($("#edit_discount_type:checked").length == 0){
		alert('Please check discount type');
		return false;
	}
	
	
	if (($("#edit_discount_type:checked").length > 0) && (discount_type == 'Percentage') && (parseFloat(discount_amount) > 99.99)){
		alert('Discount percentage should be less than 100%!');
		return false;
	}
	
	if (($("#edit_discount_type:checked").length > 0) && (discount_type == 'Amount') && (parseFloat(discount_amount) > parseFloat(sale_amount))){
		alert('Discount amount should be less than sale amount!');
		return false;
	}
	
	if ( details == '' ){
		alert('Please enter order details!');
		return false;
	}
	
	var task = 'UpdateSuborder';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data:{task:task, suborderno:suborderno, orderno:orderno, style_ref_type:style_ref_type, style_ref:style_ref, sale_amount:sale_amount, trial_date:trial_date1, delivery_due_date:delivery_due_date1, discount_type:discount_type, discount_amount:discount_amount, details:details, substatus:substatus, submit:submit},
		
		success: function(data){
			console.log(data);
			if(data == 'OK'){
				alert('Sub-Order Data Updated Successfully.');
			}else{
				alert('Error Message: '+data);
			}
			window.location.reload(true);
			return false;
		}
		
	});
	return false;
}

function editsuborder(suborderno){
	
	var task = 'EditSuborder';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data:{task:task,suborderno:suborderno},
		success: function(data){
			console.log(data);
			$("#editNewSuborder").html('');
			$("#editNewSuborder").html(data);
			$('.datepicker').datepicker({format:"dd/mm/yyyy",autoclose:true,forceParse:false});
			return false;
		}
	});
	return false;
}

function getItemBySO(suborderno){
	
	var task = 'getItemBySO';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data:{task:task,suborderno:suborderno},
		success: function(response){
			console.log(response);
			$("#packageDetails"+suborderno).html('');
			$("#packageDetails"+suborderno).html(response);
			return false;
		}
	});
	return false;
}

function getSuborderrow(orderno){
	
	var task = 'getSuborderrow';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data:{task:task,orderno:orderno},
		success: function(response){
			console.log(response);
			$("#packageDetails"+orderno).html('');
			$("#packageDetails"+orderno).html(response);
			return false;
		}
	});
	return false;
}

function updateorderrow(orderno){
	
	var task = 'updateorderrow';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data:{task:task,orderno:orderno},

		success: function(response){
			console.log(response);
			$("#"+orderno).html('');
			$("#"+orderno).html(response);
			return false;
		}
	});
	return false;
}

$('#styleimage').change(function(e){
	var file = this.files[0];
	var form = new FormData();
	form.append('image', file);
	form.append('task', 'fileupload');
	$.ajax({
		url : "ajax_suborder.php",
		type: "POST",
		cache: false,
		contentType: false,
		processData: false,
		data : form,
		success:function(data){
			$("#showstyleimages").html('');
			$("#showstyleimages").html(data);
			return false;
		}
	});
});

function customized_ref_type(val2){
	if(val2 == '1'){
		$('#customized_style_ref').prop('selectedIndex',0);
		$("#customized_type_ref_list").show();
		$("#newcusomizedstyle").hide();
		$("#selectedstyle").hide();
		$('#sale_amount').val('0');
	}else{
		$('#customized_style_ref').prop('selectedIndex',0);
		$("#customized_type_ref_list").hide();
		$("#newcusomizedstyle").show();
		$("#selectedstyle").hide();
		$('#sale_amount').val('0');
	}
}

function addsuborder(){
	var sorderno = $("#sorderno").val();
	
	var style_ref_type 				= $("input[name='style_ref_type']:checked").val();
	//var customized_style_ref_type 	= $("input[name='customized_style_ref_type']:checked").val();
	
	var style_ref 					= $("#style_ref").val();
	/*var customized_style_ref		= $("#customized_style_ref").val();
	var style_code					= $("#style_code").val();
	var description					= $("#description").val();
	var style_group_code			= $("#style_group_code").val();
	var designer_code				= $("#designer_code").val();
	var cost_price					= $("#cost_price").val();
	var selling_price				= $("#selling_price").val();
	var imagename					= $("#imagename_hidden").val();
	var imagelocation				= $("#imagelocation_hidden").val();*/
	//alert(imagename+' '+imagelocation);
	var details 					= $("#details").val();
	var discount_amount 			= parseFloat($("#discount_amount").val());
	var sale_amount 				= parseFloat($("#sale_amount").val());
	var substatus 					= $("#substatus").val();
	var trial_date 					= $("#trial_date1").val();
	var delivery_due_date 			= $("#delivery_due_date1").val();
	var submit = 'PROCEED';
	
	var discount_type = $("input[name=discount_type]:checked").val();
	
	/*if((style_ref_type == '1') && ( $("#style_ref").val() == '' )){
		alert('Please select style reference!');
		$( "#style_ref" ).focus();
		return false;		
	}
	
	if((customized_style_ref_type == '1') && ( customized_style_ref == '' )){
		alert('Please select style reference!');
		$( "#customized_style_ref" ).focus();
		return false;
	} 
	
	if((customized_style_ref_type == '0') && ( style_code == '' )){
		alert('Please enter style code!');
		$( "#style_code" ).focus();
		return false;
	}

	if((customized_style_ref_type == '0') && ( description == '' )){
		alert('Please enter style description!');
		$( "#description" ).focus();
		return false;
	}*/

	if ( parseFloat(sale_amount) <= 0) {
		alert('Please enter sale amount!');
		$( "#sale_amount" ).focus();
		return false;
	}
	if ($("#discount_type:checked").length == 0){
		alert('Please check discount type');
		return false;
	}
	if (($("#discount_type:checked").length > 0) && (discount_type == 'Percentage') && (discount_amount > 99.99)){
		alert('Discount percentage should be less than 100%!');
		return false;
	}
	if (($("#discount_type:checked").length > 0) && (discount_type == 'Amount') && (discount_amount > sale_amount)){
		alert('Discount amount should be less than sale amount!');
		return false;
	}
	if ( details == '' ){
		alert('Please enter order details!');
		return false;
	}
	
	var task = 'AddSuborder';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		
		data:{task:task,style_ref_type:style_ref_type,orderno:sorderno,details:details,style_ref:style_ref,discount_type:discount_type,discount_amount:discount_amount,sale_amount:sale_amount,substatus:substatus,trial_date:trial_date,delivery_due_date:delivery_due_date,submit:submit},

		success: function(data){
			console.log(data);
			if(data == 'OK'){
				alert('Sub-Order Data Added Successfully.');
			}else{
				alert('Error Message: '+data);
			}
			window.location.reload(true);
			return false;
		}
	});
	return false;
}

function getCustomizedSelectedStyle(stylecode){
	var task = 'getCustomizedSelectedStyle';
	//alert(stylecode);
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data: {task:task,stylecode:stylecode},
		success: function(data){
			//console.log(data);
			$("#selectedstyle").html('');
			$("#selectedstyle").show();
			$("#selectedstyle").html(data);
			return false;
		}
	});
	
	return false;
}

function getCustomizedRecomandedPrice(stylecode){
	var task = 'getCustomizedRecomandedPrice';
	getCustomizedSelectedStyle(stylecode);
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data: {task:task,stylecode:stylecode},
		success: function(data){
			console.log(data);
			$("#sale_amount").val('');
			$("#sale_amount").val(data);
			
			return false;
		}
	});
	
	return false;
}

function getSelectedStyle(stylecode){
	var task = 'getSelectedStyle';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data: {task:task,stylecode:stylecode},
		success: function(data){
			$("#selectedstyle").html('');
			$("#selectedstyle").show();
			$("#selectedstyle").html(data);
			return false;
		}
	});
	
	return false;
}

function getRecomandedPrice(stylecode){
	var task = 'getRecomandedPrice';
	getSelectedStyle(stylecode);
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data: {task:task,stylecode:stylecode},
		success: function(data){
			console.log(data);
			$("#sale_amount").val('');
			$("#sale_amount").val(data);
			
			return false;
		}
	});
	
	return false;
}


function editPayment(id){
	var allsuborder = '<?php echo $JSONallsuborder; ?>';
	var task = 'EditPayment';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data:{task:task,id:id,allsuborder:allsuborder},

		success: function(data){
			console.log(data);
			$("#editpaymentform").html('');
			$("#editpaymentform").html(data);
			$('.datepicker').datepicker({format: "dd/mm/yyyy",autoclose: true,forceParse:false});
			return false;
		}
	});
	return false;
}

function deletepayment(id){
	
	var task = 'DeletePayment';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data:{task:task,id:id},

		success: function(data){
			console.log(data);
			if(data == 'OK'){
				alert('Payment Deleted Successfully.');
			}else{
				alert('Error Message: '+data);
			}
			window.location.reload(true);
			return false;
		}
	});
	return false;
}

function updatepayment(){
	var payment_suborder 	= $("#payment_suborder").val();
	var payment_date 		= $("#payment_date").val();
	var id 					= $("#payment_id").val();
	var payment_mode 		= $("#payment_mode").val();
	var received_amount 	= $("#received_amount").val();
	var remarks 			= $("#remarks").val();
	var task = 'UpdatePayment';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data:{task:task,suborderno:payment_suborder,payment_date:payment_date,id:id,payment_mode:payment_mode,received_amount:received_amount, remarks:remarks},

		success: function(data){
			console.log(data);
			if(data == 'OK'){
				alert('Payment Updated Successfully.');
			}else{
				alert('Error Message: '+data);
			}
			window.location.reload(true);
			return false;
		}
	});
	return false;
}

function addpayment(){
	var payment_date 	= $("#payment_date").val();
	var orderno 		= $("#payment_orderno").val();
	var suborder 		= $("#payment_suborder").val();
	var payment_mode 	= $("#payment_mode").val();
	var received_amount = $("#received_amount").val();
	var remarks 		= $("#remarks").val();
	var customer_id 	= $("#payment_customer_id").val();
	//payment_suborder
	var task = 'AddPayment';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data:{task:task, payment_date:payment_date, customer_id:customer_id, suborder:suborder, orderno:orderno, payment_mode:payment_mode, received_amount:received_amount, remarks:remarks},
		success: function(data){
			console.log(data);
			if(data == 'OK'){
				alert('Payment Added successfully.');
			}else{
				alert('Error Message: '+data);
			}
			window.location.reload(true);
			return false;
		}
	});
	return false;
}

function showpaymentform(){
	$("#paymentdetails").slideUp("slow");
	$("#showpaymentform").fadeOut("slow");
	$("#paymentform").slideDown("slow");
	$("#updatepayment").hide("slow");
	$("#addpayment").fadeIn("slow");
	$("#showdetails").fadeIn("slow");
}

function showpaymentdetails(){
	$("#paymentdetails").slideDown("slow");
	$("#showpaymentform").fadeIn("slow");
	$("#paymentform").slideUp("slow");
	$("#addpayment").fadeOut("slow");
	$("#showdetails").fadeOut("slow");
}

function getPaymentDetails(orderno){
	var  orderno = orderno;
	$("#orderno").val(orderno);
	var task = 'getPaymentDetails';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data: {task:task,orderno:orderno},

		success: function(data){
			console.log(data);
			$("#paymentdetails").html('');
			$("#paymentdetails").html(data);
			return false;
		}
	});
	return false;
}

function addsubordernotes(){
	var order_id				= $("#order_id").val();
	var suborder_id				= $("#suborder_id").val();
	var suborder_note 			= $("#suborder_note").val();
	var subordernotestatusdate	= $("#subordernotestatusdate").val();
	var subordernotestatus		= $("#subordernotestatus").val();

	if(suborder_note == ''){
		alert("Please enter note!");
		$("#suborder_note").focus();
		return false;
	}
	
	if(subordernotestatusdate == ''){
		alert("Please enter note!");
		$("#subordernotestatusdate").focus();
		return false;
	}
	
	if(subordernotestatus == ''){
		alert("Please enter note!");
		$("#subordernotestatus").focus();
		return false;
	}
	//alert(order_id+"+"+suborder_note+"+"+suborder_id+"+"+subordernotestatusdate+"+"+subordernotestatus);return false;
	var task = 'addsubordernotes';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data: {task:task, order_id:order_id, suborder_note:suborder_note, suborder_id:suborder_id, subordernotestatusdate:subordernotestatusdate,subordernotestatus:subordernotestatus},
		success: function(data){
			console.log(data);
			$("#dsubordernotes").html('');
			$("#suborder_note").val('');
			$("#dsubordernotes").html(data);
			return false;
		}
	});
	
	return false;
}

function getSubOrderNotes(order_no,suborder_no){
	$("#order_id").val(order_no);
	$("#suborder_id").val(suborder_no);
	var task = 'getSubOrderNotes';
	$.ajax({
		type: "GET",
		url: "ajax_suborder.php",
		data: {task:task,suborder_id:suborder_no},
		success: function(data){
			console.log(data);
			$("#dsubordernotes").html('');
			$("#dsubordernotes").html(data);
			return false;
		}
	});
	return false;
}

function addOrdernotes(){
	var order_id	= $("#order_id").val();
	var agent_id 	= $("#agent_id").val();
	var ipaddress	= $("#ipaddress").val();
	var note 		= $("#order_note").val();
	if(note == ''){
		alert("Please enter note!");
		return false;
	}
	
	var task = 'addOrdernotes';
	$.ajax({
		type: "GET",
		url: "ajax.php",
		data: {order_note:note,task:task,order_id:order_id,agent_id:agent_id,ipaddress:ipaddress},
		success: function(data){
			console.log(data);
			$("#dordernotes").html('');
			$("#order_note").val('');
			$("#dordernotes").html(data);
			return false;
		}
	});	
	return false;
}

function getnotes(order_no){
	var  order_id = order_no;
	$("#order_id").val(order_id);
	var task = 'getnotes';
	$.ajax({
		type: "GET",
		url: "ajax.php",
		data: {task:task,order_id:order_id},

		success: function(data){
			console.log(data);
			$("#dordernotes").html('');
			$("#order_note").val('');
			$("#dordernotes").html(data);
			return false;
		}
	});
	return false;
}

function getOrderbyno(order_no){
	var  order_id = order_no;
	var task = 'getOrderbyno';
	$.ajax({
		type: "GET",
		url: "ajax_suborder.php",
		data: {task:task,order_id:order_id},

		success: function(data){
			console.log(data);
			$("#orderdata").html('');
			$("#orderdata").html(data);
			return false;
		}
	});

	return false;
}

function getCutomerbyId(cust_id){
	var task = 'getCustomer';
	$.ajax({
		type: "GET",
		url: "ajax.php",
		data: {task:task,cust_id:cust_id},
		success: function(data){
			console.log(data);
			$("#getCustomer").html('');
			$("#getCustomer").html(data);
			return false;
		}
	});
	return false;
}

function getStyleDetials(stylecode){
	var task = 'styledetails';
	$.ajax({
		type: "POST",
		url : "ajax_suborder.php",
		data : {task:task, stylecode:stylecode},
		success:function(data){
			$("#modalstyledetails").html('');
			$("#modalstyledetails").html(data);
			return false;
		}
	});
	return false;
}

function getfabricdetails(fabricid){
	var task = 'getfabricdetails';
	$.ajax({
		type: "POST",
		url : "ajax_suborder.php",
		data : {task:task, fabricid:fabricid},
		success:function(data){
			$("#modalFabricDetails").html('');
			$("#modalFabricDetails").html(data);
			return false;
		}
	});
	return false;
}

//$('#order_detail').wysihtml5();
//$('#delivery_remarks').wysihtml5();
</script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->

<script>
function isDecimalNumber(evt, element) {
	evt = (evt) ? evt : window.event;
	var len = $(element).val().length;

	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode!=46)
	{
		status = "This field accepts numbers only.";
		return false;
	}else {
		var len = $(element).val().length;
		var index = $(element).val().indexOf('.');
		if (index > 0 && charCode == 46) {
			return false;
		}
		if (index > 0) {
			var CharAfterdot = (len + 1) - index;
			if (CharAfterdot > 3) {
				return false;
			}
		}

	}
	return true;
}
</script>
  </body>
</html>