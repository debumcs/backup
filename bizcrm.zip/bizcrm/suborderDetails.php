<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);
$action 	= $_GET["action"];
$orderno 	= $_GET["orderno"];
$suborder 	= $_GET["suborder"];

$msgD = '';

require_once('class/class.orderdetails.php');
$objord = new Orderdetails();

require_once('class/class.fabric.php');
$objfabric 		= new Fabric();
$allfabric = $objfabric->getAll();
$allfabricgroup = $objfabric->getAllgroup();

require_once('class/class.items.php');
$objitem = new item();

$allitems = $objitem->getAll();

$allitemsbysuborderno = $objitem->itemsbysuborderno($suborder);

if($action == "editsub")
{
	$data = $objord->getSuborderById($suborder);
	$subordertitle = 'Update Sub Order';
	$btnvalue = "UPDATE";
	$subreadonly = '';
	$disabled = '';
}
else
{
	$btnvalue = "PROCEED";
	$subordertitle = 'New Sub Order';
}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="bootstrap/css/datepicker.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
    <link rel="stylesheet" type="text/css" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css"></link>
	<link rel="stylesheet/less" type="text/css" href="side.less" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<style>
	.connecting_preference_checkbox{
		display:block !important; float:left; width:20px;
	}
	.connecting_preference_box{
		display: block;float: left;width: 25%;
	}
	.datepicker{z-index:1151 !important;}
	</style>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
     
   <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objord->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objord->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
							<div class="col-md-12">
								<h3 class="box-title"> <?php echo 'Suborder details'; //$subordertitle; ?> </h3>
							</div>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <?php  ?>
							<div class="row">
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Order No : <?php echo $data['orderno']; ?></label>
										</div>
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Customer Name : <?php echo $data['custname']; ?></label>
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Style Ref : <?php echo $data['style_ref']; ?></label>
										</div>	
									</div><!-- /.col -->
								</div>
																
								<div class="col-lg-12">
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Sale Amount : <?php echo $data['sale_amount']; ?></label>
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Discount Type : <?php echo $data['discount_type']; ?></label>
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Discount Value : <?php echo $data['discount_amount']; ?></label>
										</div>			  
									</div><!-- /.col -->
									
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Trial Date : <?php echo $objord->date_ymd_dmy($data['trial_date']); ?></label>
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Delivery Due Date : <?php echo $objord->date_ymd_dmy($data['delivery_due_date']); ?></label>
										</div>			  
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">	
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Details : </label>&nbsp;&nbsp;&nbsp;
											<label><?php echo $data['details']; ?></label>
										</div>			  
									</div><!-- /.col -->									
								</div>
								
								<div class="col-lg-12">&nbsp;</div>
							</div><!-- /.row --><?php  ?>
                        </div>
						
						<div class='box-body table-responsive'>
							<div class="row">
							<form name="saveItemsFabric" id="saveItemsFabric" method="post" action="suborderDetailsPost.php">
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Items</label>
											<select class="form-control select2 form-control-sm" tabindex="4" id="items" name="items" style="width:100%;">
											<option value="" selected>Select</option>
											<?php 				
											for($fbi=0; $fbi<count($allitems); $fbi++) {												
												echo "<option value='".$allitems[$fbi]['id']."'>".$allitems[$fbi]['itemname']."</option>";
											}
											?>
											</select>
											<input type="hidden" id="orderno" name="orderno" class="form-control" value="<?php echo $orderno; ?>" />
											<input type="hidden" id="suborderno" name="suborderno" class="form-control" value="<?php echo $suborder; ?>" />
										</div>	
									</div>
								</div>
								<div class="col-lg-12">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
									<table class="" cellspacing="10" cellpadding="10" id="camptable">
										<thead>
											<tr>
												<th width="15%"><b>Fabric Group</b></th>
												<th width="15%"><b>Fabric ID</b></th>
												<th width="70%">
													<div class="col-lg-12">	
														<div class="col-lg-4"><b>Units</b></div>
														<div class="col-lg-4"><b>Fabric Name</b></div>
														<div class="col-lg-4"><b>Fabric Image</b></div>
													</div>
												</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td valign="top">
												<select class="form-control form-control-sm classfabric" id="fabricgroupid1" name="fabricgroup[]" onchange="get_fabric(1,this.value);">
												<option selected value="">Select fabric group</option>
												<?php 				
												for($fgi=0; $fgi<count($allfabricgroup); $fgi++){
													echo "<option value='".$allfabricgroup[$fgi]['id']."'>".$allfabricgroup[$fgi]['groupname']."</option>";
												}
												?>
												</select>
												</td>
												<td valign="top">
												<select class="form-control form-control-sm classfabric" id="fabricid1" name="fabric[]" onchange="get_fabric_units(1,this.value);"></select>
												</td>
												<td colspan="3" id="unitsin1">
													<div class="col-lg-12">	
														<div class="col-lg-4"><input type="text" class="form-control form-control-sm" onKeyPress="return isDecimalNumber(event,this);" id="unitsvalue1" name="unitsvalue[]" value="" /></div>
														<div class="col-lg-4"></div>
														<div class="col-lg-4"></div>
													</div>
												</td>												
											</tr>
											
											<tr id="lastrow">
												<td width="40%" colspan="4"><p style="width:100%; padding-top:10px;" ><button id="add" class="btn btn-warning btn-sm" type="button">Add New</button></p></td>
											</tr>
											
											<tr>
												<td width="40%" colspan="4"><input type="hidden" id="totalrow" name="totalrow" value="1" />
									<input type="submit" class="btn btn-primary btn-sm" name="saveitems" id="saveitems" tabindex="14" onclick="return saveItem();" value="Save" /></td>
											</tr>
										</tbody>
									</table>
								</div>
								</div>
								<div class="col-lg-12">
									<div class="col-lg-6">
									</div>
								</div>
								</form>
							</div><!-- /.row -->
						
						
							<div class="col-lg-12">
								<div class="col-lg-6"><b>Items of Suborder Number : <?php echo $suborder; ?></b></div>
								<div class="col-lg-6">&nbsp;</div>
							</div>
							<div class="col-lg-12">
                            <table class="table table-bordered table-striped">
								<thead>
								  <tr>
									<th width="40%"><b>Items</b></th>
									<th width="40%"><b>Fabric</b></th>
									<th width="10%"><b>Units</b></th>
									<th width="10%"><b>Status</b></th>
									<th width="10%"><b>Action</b></th>
								  </tr>
								</thead>
								<tbody>
								<?php if(count($allitemsbysuborderno)<=0){ ?>	
									<tr>
										<td colspan="4" align="center">No Records Found</td>
									</tr>
								<?php 								
								}else{
								for($i=0; $i<count($allitemsbysuborderno); $i++) { ?>	
									<tr id="<?php echo $allitemsbysuborderno[$i]['id']; ?>">
										<td><?php echo $allitemsbysuborderno[$i]['itemname']; ?></td>
										<td><?php echo $allitemsbysuborderno[$i]['fabricname']; ?></td>
										<td><?php echo $allitemsbysuborderno[$i]['value'].' ('.$allitemsbysuborderno[$i]['units'].')'; ?></td>
										<td><?php if($allitemsbysuborderno[$i]['status_id'] == '0'){echo 'No work done';}else{echo $allitemsbysuborderno[$i]['statusname'];} ?></td>
										<td><?php if($allitemsbysuborderno[$i]['status_id'] == '0'){ ?><a href="#" data-toggle="modal" data-target="#delete_items" onclick='delete_items("<?php print $allitemsbysuborderno[$i]['id']; ?>");'>Delete</a><?php } ?></td>
									</tr>
								<?php	
								}}
								?>
								</tbody>
							</table>
							</div>
							
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="text-align:center;">
							<br/><br/><br/><label for="name"><a href="vieworder.php?orderno=<?php echo $data['orderno']; ?>" class="btn btn-info btn-xs" role="button">Back</a></label>
							</div><!-- /.col -->
							
						</div><!-- /.box-body--> 
											
						
                     </div><!-- /.box-->                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
      </div><!-- /.content-wrapper -->
      
      
      <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->
	<?php //include('modal_suborder.php'); ?>
		<!-- Add dying -->
	
	<!-- Add dying -->
	<div class="modal fade" id="getItemDetailsModal" tabindex="-1" role="dialog" aria-labelledby="getItemDetailslabel">
		<div class="modal-dialog" role="document">
		<form action="" method="post" name="getItemDetailsForm" id="getItemDetailsForm">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Edit Suborder Items</h4>
				</div>
				<div class="modal-body">
					<div class="row" id="editItemDetails">
						  
					</div><!-- /.row -->
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<input type="submit" class="btn btn-primary" name="saveitems" id="saveitems" tabindex="14" onclick="return editItem();" value="Save" />
				</div>
			</div>
		</form>
		</div>
	</div>
    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
	
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<script src="bootstrap/js/bootstrap-datepicker.js"></script>
	<script type="text/javascript">
function get_fabric(indexid,fabricgroupid){
	
	var task = 'getFabrics';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data:{task:task, indexid:indexid, fabricgroupid:fabricgroupid},
		success: function(data){
			console.log(data);
			$("#fabricid"+indexid).html('');
			$("#fabricid"+indexid).html(data);
			return false;
		}
	});
	return false;
}

function get_fabric_units(indexid,fabricid){
	
	var task 	= 'getFabricUnits';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data:{task:task, indexid:indexid,fabricid:fabricid},
		success: function(data){
			console.log(data);
			$("#unitsin"+indexid).html('');
			$("#unitsin"+indexid).html(data);
			return false;
		}
	});
	return false;
}

function resetItemForm(){
	$('#formadditems')[0].reset();
	return false;
}

$('#camptable').delegate('#remove','click',function(event){
	$(this).parent('tr').remove();
});

$('#add').click(function(){
	//alert('Hi');
	var row = $('#lastrow').closest('tr');
	var prev_row = row.prev();
	var td = prev_row.find("td").html();
	var attr = $(td).attr("id");
	var number = attr.substr(13);
	//alert(number);1
	//return false;
	if($('#'+attr).val() == ''){
		alert('Please select fabric group!');
		$('#'+attr).focus();
		return false;
	}else if($('#fabricid'+number).val() == ''){
		alert('Please select fabric id!');
		$('#fabricid'+number).focus();
		return false;
	}else if($('#unitsvalue'+number).val() == ''){
		alert('Please enter units value!');
		$('#unitsvalue'+number).focus();
		return false;
	}else{		
		number = parseInt(number);
		number = number+1;
		var countc=<?php echo $fbi;?>;
		var co=0;
		var fabrics = '0';
		$(".classfabric").each(function() {
			var nx = $(this).val();
			fabrics = fabrics+','+nx;
			co++;
		});
		
		if(co == countc)
		{
			alert("All "+countc+" fabrics are already selected.");	
			return false;
		}else{
			$('#totalrow').val(number);
			$.ajax({
				type: "POST",
				url: "ajax_suborder.php",
				data:{ Req: 'classfabric',rn:number,fabrics:fabrics }, 
				success: function(data){
					var newrow = data; 
					$('#lastrow').before(newrow);
				}
			});
			return false;
		}
	}

});

function delete_items(id){
	
	var id		= id;
	var task 	= 'deleteItem';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data:{task:task, id:id},
		success: function(data){
			console.log(data);
			if(data == 'OK'){
				alert('Item Deleted successfully.');
			}else{
				alert('Error Message: '+data);
			}
			window.location.reload(true);
			return false;
		}
	});
	return false;
}

function editItem(){
	
	var id 			= $("#ei_id").val();
	var items 		= $("#ei_items").val();
	var orderno 	= $("#ei_orderno").val();
	var suborderno 	= $("#ei_suborderno").val();
	var fabricid 	= $("#ei_fabricid").val();
	var quantity 	= $("#ei_quantity").val();
	if(items == ''){
		alert('Please select item');
		$("#items").focus();
		return false;
	}else if(fabricid == ''){
		alert('Please select fabric');
		$("#fabricid").focus();
		return false;
	}else if(quantity == ''){
		alert('Please enter quantity');
		$("#quantity").focus();
		return false;
	}else{
		var task = 'updateItem';
		$.ajax({
			type: "POST",
			url: "ajax_suborder.php",
			data:{task:task, id:id, orderno:orderno, suborderno:suborderno, items:items, fabricid:fabricid, quantity:quantity},

			success: function(data){
				console.log(data);
				if(data == 'OK'){
					alert('Item Updated successfully.');
				}else{
					alert('Error Message: '+data);
				}
				window.location.reload(true);
				return false;
			}
		});
	}	
	return false;
}

function saveItem(){
	var i;
	var items 		= $("#items").val();
	var orderno 	= $("#orderno").val();
	var suborderno 	= $("#suborderno").val();	
	var totalrow 	= $("#totalrow").val();
	//fabricid1 and unitsvalue1 and fabricgroupid2
	if(items == ''){
		alert('Please select item');
		$("#items").focus();
		return false;
	}
	
	for(var i = 1; i <= totalrow; i++){
		if($("#fabricgroupid"+i).val() == ''){
			alert('Please select fabric group id?');
			$("#fabricgroupid"+i).focus();
			return false;
		}
		if($("#fabricid"+i).val() == ''){
			alert('Please select fabric id?');
			$("#fabricid"+i).focus();
			return false;
		}
		if($("#unitsvalue"+i).val() == ''){
			alert('Please select units value?');
			$("#unitsvalue"+i).focus();
			return false;
		}
	}
	
}

function getItemDetails(id){
	var  id = id;
	var task = 'getItemDetails';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data: {task:task,id:id},

		success: function(data){
			console.log(data);
			$("#editItemDetails").html('');
			$("#editItemDetails").html(data);
			return false;
		}
	});
	return false;
}
		
function isDecimalNumber(evt, element) {
	
	evt = (evt) ? evt : window.event;
	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode!=46)
	{
		status = "This field accepts numbers only.";
		return false;
	}else {
		var len = $(element).val().length;
		var index = $(element).val().indexOf('.');
		if (index > 0 && charCode == 46) {
			return false;
		}
		if (index > 0) {
			var CharAfterdot = (len + 1) - index;
			if (CharAfterdot > 3) {
				return false;
			}
		}

	}
	return true;
}
	
$(document).ready(function (){
	
	$('.datepicker').datepicker({
		format: "yyyy-mm-dd",
		autoclose: true
	});
	
});		

$.widget.bridge('uibutton', $.ui.button);

$("#message").fadeIn('slow').delay(100).fadeOut('slow');
</script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
	
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
	<script>
	//$('#order_detail').wysihtml5();
	//$('#delivery_remarks').wysihtml5();
	</script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
   
    <!-- AdminLTE for demo purposes -->
	
  </body>
</html>