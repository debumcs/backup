<?php 
	require_once('include/auth.php');
	require_once('class/class.items.php');
	$objitem 		= new item();
	
	if(isset($_GET['Search'])){
		$challanno = $_GET['challanno'];
		$allitems = $objitem->getallitemsbychallan($challanno);
	}else{
		$allitems = $objitem->getallitemsbychallan('');
	}
	
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE; ?> | Challan Print</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	
    <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="dist/css/dataTables.bootstrap.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
	<link rel="stylesheet/less" type="text/css" href="side.less" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
         <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<style>
		.datepicker-dropdown{z-index:1151 !important;}
		@media print{
			@page {size: landscape}
			#hideform{
				display:none;
			}
			#challantitle{
				display:block;
			}
		}
	</style>
  </head>

  <body class="hold-transition skin-blue sidebar-mini">
   <div class="wrapper">

		<?php $objitem->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objitem->pssidebar(); ?>

		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
			<h1>Manage Challan Print</h1>
            <ol class="breadcrumb">
				<li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
				<li>Control Panel</li>
				<li class="active">Manage Challan Print</li>
			</ol>
        </section>
        
          <!-- Main content -->
		<?php ?>
        <section class="content printableArea">
            <div class="row">
            	<div class="col-md-12">
					<h3 class="box-title" id="challantitle" style="display:none;">Challan</h3>
              		<div class="box box-warning">
						<div class="col-md-12">
							<div style="height:15px">&nbsp;</div>
							<form class="form-inline" id="hideform">
								<div class="input-group mb-2 mr-sm-2 mb-sm-0">
									<div class="input-group-addon">Challan#</div>
									<input type="text" class="form-control input-sm" id="challanno" tabindex="1" name="challanno" value="<?php if(isset($_GET['challanno'])){echo $_GET['challanno'];} ?>">
								</div>
								
								<div class="input-group mb-2 mr-sm-2 mb-sm-0">
									<input type="submit" class="btn btn-primary btn-sm" id="Search" name="Search" value="Search">
								</div>

							</form>
						</div>
					
                        <div class='box-body table-responsive'>
						<form class="form-inline" method="post">
                            <table id="example111" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Challan No</th>
                        <th>Order No</th>
                        <th>Suborder No</th>
                        <th>Items</th>
						<th>Fabric</th>
						<th>Qty(meters)</th>
						<th>Agency</th>
						<th>Assign Date</th>
						<th>Expected Date</th>
						<th>Return Date</th>
						<th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
					<?php for($i=0; $i<count($allitems); $i++) { ?>	
						<tr>
                            <td><?php print $allitems[$i]['challanno']; ?></td>
							<td><?php print $allitems[$i]['orderno']; ?></td>
							<td><?php print $allitems[$i]['suborderno']; ?></td>
							<td><?php print $allitems[$i]['itemname']; ?></td>
							<td><?php print $allitems[$i]['fabricname']; ?></td>
							<td><?php print $allitems[$i]['meters']; ?></td>
							<td><?php print $allitems[$i]['agencyname']; ?></td>
							<td><?php print $allitems[$i]['assign_date']; ?></td>
							<td><?php print $allitems[$i]['expected_date']; ?></td>
							<td><?php print $allitems[$i]['return_date']; ?></td>
							<td><?php if($allitems[$i]['status_id'] == '0'){echo 'No work done.';}else{print $objitem->getStatusName($allitems[$i]['status_id']);} ?></td>
						</tr>
                    <?php } ?>						
                    </tbody>
                    
                  </table>
							
							<div class="col-lg-12">
								<div class="col-lg-12">
									<label for="name">&nbsp;</label>
								</div>
							</div>
							<div class="col-lg-12">
								<div class="col-lg-12">
									<label for="name">&nbsp;</label>
								</div>
							</div>
							
							<div class="col-md-12">
								<div class="input-group mb-2 mr-sm-2 mb-sm-0">
									<input type="button" class="btn btn-primary btn-sm printdiv-btn" id="print" name="print" value="Print" />
								</div>
							</div>
							
						</form>
						   
						</div><!-- /.box-body--> 
					</div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
		<?php  ?>
      </div><!-- /.content-wrapper -->
      
 <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->
	
<!-- jQuery 2.1.4 -->
<script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="dist/js/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.5 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="dist/js/jquery.dataTables.js"></script>
<script src="dist/js/dataTables.bootstrap.min.js"></script>
      <script>
  $(document).on('click', '.printdiv-btn', function(e) {
		e.preventDefault();
		$("#challantitle").css("display", "block");
		$("#print").css("display", "none");
		var $this = $(this);
		var originalContent = $('body').html();
		var printArea = $this.parents('.printableArea').html();

		$('body').html(printArea);
		window.print();
		$('body').html(originalContent);
		$("#challantitle").css("display", "none");
		$("#print").css("display", "block");
	});
  </script>
    <!-- daterangepicker -->
    <script src="dist/js/moment.min.js"></script>
    <!-- iCheck 1.0.1 -->
    <script src="plugins/iCheck/icheck.min.js"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>

    <script src="dist/js/demo.js"></script>
    
	
</body>
</html>