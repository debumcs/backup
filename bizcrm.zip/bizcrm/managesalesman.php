<?php 
	require_once('class/class.salesman.php');
	
	/*require_once('class/class.group.php');
	$objgroup = new Group();	
	$alldata = $objgroup->getAll();*/
	
	$objsalesman = new Salesman();
	$allcountry 	= $objsalesman->getCountry();
	
	$action = "";
	$action = $_GET["action"];
	$id = $_GET["id"];
	$msgD = '';
	
	if($_REQUEST['getState']=='ajaxState')
	{
		$id = $_POST['id'];
		$objsta = new Salesman();
		$allstate = $objsta->getState($id);
		
		echo '<select class="form-control " id="state" name="state" style="width:100%;" onchange="getCity(this.value);"><option value="">Select</option>';
		for($si=0; $si<count($allstate); $si++) {
                   if($data['state']==$allstate[$si]['id']){$selected="selected";}else{$selected="";} 					
			echo "<option value='".$allstate[$si]['id']."' $selected >".$allstate[$si]['name']."</option>"; 
		}
		echo '</select>';		
		exit;
	}
	//getCity:'ajaxCity'
	if($_REQUEST['getCity']=='ajaxCity')
	{
		$id = $_POST['id'];
		$objcity = new Salesman();
		$allcity = $objcity->getCity($id);
		
		echo '<select class="form-control " id="city" name="city" style="width:100%;"><option value="">Select</option>';
		for($cti=0; $cti<count($allcity); $cti++) {			
			echo "<option value='".$allcity[$cti]['id']."' >".$allcity[$cti]['name']."</option>"; 
		}
		echo '</select>';		
		exit;
	}
	
		
	if($action=="Edit")
	{
	    $btnvalue = "UPDATE";
		$data = $objsalesman->getById($id);
		
	}elseif($action=="Add")
	{
		$btnvalue = "SAVE";
		
	}else{
		$btnvalue = "";
		$alldata = $objsalesman->getAll();
	}
	
	if(isset($_POST['submit']))
	{
		$objsalesman->save();
		exit();
	}

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | Add Category</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Bootstrap time Picker -->
    <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
    <!-- Date Picker -->
    <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<script type="text/javascript" language="javascript">
		
		function getState(stateid){
			//alert(stateid);
			$.ajax({
				url: "managesalesman.php",
				type: 'POST',
				context: this,
				data: {getState:'ajaxState',id:stateid},
				success: function(response){
					$('#ajaxstate').html(response);
				}
			});			
		}
		
		function getCity(cityid){
	
			$.ajax({
				url: "managesalesman.php",
				type: 'POST',
				context: this,
				data: {getCity:'ajaxCity',id:cityid},
				success: function(response){
					$('#ajaxcity').html(response);
				}
			});
			
		}
		
		function validateEmail(email) {
			var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			return re.test(email);
		}
		
		function validatesalesman(){
            if(document.getElementById('user_code').value == ''){
				alert('Please enter user code!');
				document.getElementById('user_code').focus();
				return false;
			}else if(document.getElementById('personname').value.length < 3 ){
				alert('Please enter person name (minimum 3 character)!');
				document.getElementById('personname').focus();
				return false;
			}else if(document.getElementById('address').value =='' ){
				alert('Please enter address!');
				document.getElementById('address').focus();
				return false;
			}else if(document.getElementById('country').value =='' ){
				alert('Please select country!');
				document.getElementById('country').focus();
				return false;
			}else if(document.getElementById('state').value =='' )
            {
				alert('Please select state!');
				document.getElementById('state').focus();
				return false;
			}
			else if(document.getElementById('city').value =='' )
            {
				alert('Please select city!');
				document.getElementById('city').focus();
				return false;
			}else if(document.getElementById('pincode').value =='' )
            {
				alert('Please enter pincode!');
				document.getElementById('pincode').focus();
				return false;
			}else if(document.getElementById('contactno').value =='' )
            {
				alert('Please enter contact no!');
				document.getElementById('contactno').focus();
				return false;
			}else if(!validateEmail(document.getElementById("email").value))
            {
				alert('Please enter email!');
				document.getElementById('email').focus();
				return false;
			}
			else{
				return true;
			}			
      	}
	
	</script>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
     
   <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objsalesman->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objsalesman->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>Salesman Master</h1>
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Control Panel</li>
            <li class="active">Salesman Master</li><li class="active"><?php echo $action; ?></li>
          </ol>
        </section><!--CONTENT HEADER-->
        <?php if($action == 'Add' || $action == 'Edit'){?>
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title"><?php echo $action; ?> Salesman Master</h3><span style='float:right'>Fields marked with a asterisk (<font color='red'>*</font>) are mandatory.</span>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <form action="" name="agencymaster" id="agencymaster" method="post" >
							<div class="row">
								<div class="col-lg-12">
									<div class="col-lg-2">
										<div class="form-group">
											<label for="name">User Type<font color='red'>*</font> </label>
											<select class="form-control" id="user_type" name="user_type" style="width:100%;">
											<option value="" disabled>Select</option>
											<option value="Designer" <?php if($data['user_type']== 'Designer'){echo 'selected';}else{echo '';} ?>>Designer</option>
											<option value="Sales Person" <?php if($data['user_type']== 'Sales Person'){echo 'selected';}else{echo '';} ?>>Sales Person</option>
											</select>
											<input type="hidden" id="id" name="id" value="<?php echo $data['id']; ?>" />
										</div>										
									</div><!-- /.col -->
									
									<div class="col-lg-2">
										<div class="form-group">
											<label for="name">User Code<font color='red'>*</font> </label>
											<input type="text" class="form-control" id="user_code" <?php if($action=="edit"){echo 'readonly';}else{echo 'onblur="check_sales_id(this.value);"';}?> name="user_code" placeholder="Enter user code" value="<?php echo $data['user_code']; ?>">
											<p id="person_id_html"></p>
										</div>										
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Name<font color='red'>*</font> </label>
											<input type="text" class="form-control" id="personname" name="personname" placeholder="Enter name" value="<?php echo $data['personname']; ?>">
										</div>										
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
											<label>Address<font color='red'>*</font></label>
											<input type="text" class="form-control" id="address"  name="address" placeholder="Enter address" value="<?php echo $data['address']; ?>">
										</div><!-- /.form-group -->
									</div><!-- /.col -->
								</div><!-- /.col -->
								
								<div class="col-lg-12">	
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Country</label><?php echo $MANDATORY;?>
											<select class="form-control " id="country" name="country" style="width:100%;" onchange="getState(this.value);">
											<option value="" selected>Select</option>
											<?php 				
											for($ci=0; $ci<count($allcountry); $ci++) {
												if($data['country']==$allcountry[$ci]['id']){$selected="selected";}else{$selected="";} 				 
												echo "<option value='".$allcountry[$ci]['id']."' $selected >".$allcountry[$ci]['name']."</option>"; 
											}
											?>
											</select>
										</div>
									</div><!-- /.col -->
								  
									<div class="col-lg-4">						
										<div class="form-group">
											<div class="row col-lg-12 col-md-12 col-sm-12 col-xs-12">
											<label for="name">State</label><?php echo $MANDATORY;?>
											</div>
											<div id="ajaxstate" class="row col-lg-12 col-md-12 col-sm-12 col-xs-12">
												<?php
												if(isset($data['country']))
												{
												$allstate = $objsalesman->getState($data['country']);
												echo '<select class="form-control " id="state" name="state" style="width:100%;" onchange="getCity(this.value);"><option value="">Select</option>';
												for($si=0; $si<count($allstate); $si++)
												{
													if($data['state']==$allstate[$si]['id']){$selected="selected";}else{$selected="";}
													echo "<option value='".$allstate[$si]['id']."' $selected >".$allstate[$si]['name']."</option>";
												}
												echo '</select>';
												}
												else{
													echo '<select class="form-control " id="state" name="state" style="width:100%;">
													<option value="" selected>Select</option>
													</select>';
												}
												?>
											</select>
											</div>
										</div>				
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
										  
										  <div class="row col-lg-12 col-md-12 col-sm-12 col-xs-12">
										<label for="name">City</label><?php echo $MANDATORY;?>
										</div>
										  <div id="ajaxcity" class="row col-lg-12 col-md-12 col-sm-12 col-xs-12">
                     					<?php 
											if(isset($data['state'])){
												$allcity = $objsalesman->getCity($data['state']);

												echo '<select class="form-control " id="city" name="city" style="width:100%;"><option value="">Select</option>';
												for($cti=0; $cti<count($allcity); $cti++) {
													if($data['city']==$allcity[$cti]['id']){$selected="selected";}else{$selected="";}  			
													echo "<option value='".$allcity[$cti]['id']."' $selected >".$allcity[$cti]['name']."</option>"; 
												}
												echo '</select>';	
												}else
												{
												echo '<select class="form-control " id="city" name="city" style="width:100%;">
												<option value="" selected>Select</option>
												</select>';
											}
										?>				
 
											</div>
										</div>
									</div><!-- /.col -->
									
								</div><!-- /.col -->
								
								<div class="col-lg-12">	
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Pin Code<font color='red'>*</font> </label>
											<input type="text" class="form-control" id="pincode" name="pincode" placeholder="Enter pincode" value="<?php echo $data['pincode']; ?>">
										</div>		
									</div><!-- /.col -->
								  
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Contact No<font color='red'>*</font> </label>
											<input type="text" class="form-control" id="contactno" name="contactno" placeholder="Enter contact no" value="<?php echo $data['contactno']; ?>">
										</div>										
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
											<label>Email<font color='red'>*</font></label>
											<input type="text" class="form-control" id="email"  name="email" placeholder="Enter email" value="<?php echo $data['email']; ?>">
										</div><!-- /.form-group -->
									</div><!-- /.col -->
								</div><!-- /.col -->
								
                           </div><!-- /.row -->
                           
                           <div class="row">
                              <div class="col-lg-12">
                                   <div class="form-group center">
                                      <input type="submit" name="submit" id="submit" class="btn btn-warning left-10" value="<?php echo $btnvalue; ?>" onclick="return validatesalesman();" />
									  <a href="managesalesman.php" class="btn btn-warning left-10">View All</a>
                                   </div>
                               </div><!-- /.col -->
             				 </div><!-- /.row -->
                           </form>
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
		<?php }else{ ?>
		
		<section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title pull-right"><a href="managesalesman.php?action=Add&id=">Add New</a></h3>
                        </div><!-- /.box-header -->
                        <div class='box-body table-responsive'>
                            <table id="example111" class="table table-bordered table-striped">
							<thead>
							  <tr>
								<th>Name</th>
								<th>Address</th>
								<th>Email</th>
								<th>Contact No</th>
								<th>Action</th>							
							  </tr>
							</thead>
                    <tbody>
					<?php for($i=0; $i<count($alldata); $i++) { ?>	
						<tr>
                            <td><?php print $alldata[$i]['personname']; ?></td>
							<td><?php print $alldata[$i]['address'].' '.$alldata[$i]['pincode']; ?></td>
							<td><?php print $alldata[$i]['email']; ?></td>
							<td><?php print $alldata[$i]['contactno']; ?></td>
							<td><a href="managesalesman.php?action=Edit&id=<?php print $alldata[$i]['id']; ?>">Edit</a></td>							
				        </tr>
                    <?php } ?>						
                    </tbody>
                    
                  </table>
                           
                          </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
            </div><!-- /.row -->
        </section><!--CONTENT-->		
		<?php } ?>
		
      </div><!-- /.content-wrapper -->
      
      
      <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <script>
		$("#message").fadeIn('slow').delay(5000).fadeOut('slow');
		$(".select2").select2();
		  //Date range picker
		function check_sales_id(person_id){
			
			if(person_id != ''){
				$.ajax({
					url: "ajax_suborder.php",
					type: 'POST',
					context: this,
					data: {checkSalesPersonID:'checkSalesPersonID',person_id:person_id},
					success: function(response){
						
						if(response == '1'){
							var check_referel = "<span class='refferal_success'>Valid ID!</span>";
						}else{
							var check_referel = "<span class='refferal_failure'>User code '"+person_id+"' is already exist!</span>";
							$('#user_code').val('');
						}
						$('#person_id_html').html(check_referel);					
					}
				});
			}else{
				$('#person_id_html').html('');
			}		
		}
	</script>
  </body>
</html>