<?php 
	require_once('include/auth.php');
	require_once('class/class.orderdetails.php');
	$objord = new Orderdetails();
	$alldata = $objord->getAll();
	
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | Order List Page</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Bootstrap time Picker -->
    <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="dist/css/dataTables.bootstrap.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
   <link rel="stylesheet/less" type="text/css" href="side.less" />
	<link rel="stylesheet" href="date/jquery-ui.css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
         <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<script>
		function payment(customer_id, orderno){
			alert(customer_id);
			alert('Hi');
			document.getElementById("porderno").value = '';
			document.getElementById("pcustomer_id").value = '';
			
			document.getElementById("porderno").value = orderno;
			document.getElementById("pcustomer_id").value = customer_id;
		}
    </script>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
 <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objord->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objord->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Manage Order Details
          </h1>
           
            <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Order</li>
            <li class="active">Manage Order Details</li>
          </ol>
        </section><!--CONTENT HEADER-->
        
        
		
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">                        
                        <div class='box-body  table-responsive'>
                            <table id="example111" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Customer ID</th>
                        <th>Order No</th>
                        <th>Order Date</th>
                        <th>Delivery Due Date</th>                  
                        <th>Action</th>
                    
                      </tr>
                    </thead>
                    <tbody>
					<?php for($i=0; $i<count($alldata); $i++) { ?>	
						<tr>
                            <?php if($alldata[$i]['status']=='1'){$status='Active';}else{$status='Inactive';} ?>
							<td><a href="#" data-toggle="modal" data-target="#getCutomerbyId" onclick='getCutomerbyId("<?php print $alldata[$i]['customer_id']; ?>")'><?php print $alldata[$i]['customer_id']; ?></a></td>
							<td><a href="#" data-toggle="modal" data-target="#orderdetails" onclick='getOrderbyno("<?php print $alldata[$i]['orderno']; ?>")'><?php print $alldata[$i]['orderno']; ?></a></td>
							<td><?php print $alldata[$i]['order_date']; ?></td>
							<td><?php print $alldata[$i]['delivery_due_date']; ?></td>
							<td><a href="order.php?action=edit&orderno=<?php print $alldata[$i]['orderno']; ?>">Edit</a>&nbsp;|&nbsp;
							<a href="assignorder.php?action=assign&orderno=<?php print $alldata[$i]['orderno']; ?>">Assign To</a>&nbsp;|&nbsp;
							<a href="payment.php?orderno=<?php print $alldata[$i]['orderno']; ?>" >Payment</a>
							</td>
							
						</tr>
                    <?php } ?>						
                    </tbody>
                    
                  </table>
                           
                          </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
		
      </div><!-- /.content-wrapper -->
      
      
	  
	  
      <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->

	<!-- Customer Popup Info-->
<div class="modal fade" id="getCutomerbyId" tabindex="-1" role="dialog" aria-labelledby="getCutomerbyIdLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Customer Details </h4>
			</div>
			
			<div class="modal-body">
				<div class="row">
					<div id="getCustomer">

					</div><!-- /.col -->
				</div><!-- /.row -->
			</div>
			
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>		
		</div>
	</div>
</div>

	
<div class="modal fade" id="orderdetails" tabindex="-1" role="dialog" aria-labelledby="orderdetailsLabel">
	<div class="modal-dialog" role="document">	
	<div class="modal-content">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Order Details </h4>
		</div>
		<div class="modal-body">
			<div class="row">
				<div class="col-lg-12" id="orderdata">


				</div><!-- /.col -->
			</div><!-- /.row -->
		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		</div>
	</div>	
	</div>
</div>

<script>
	
function getOrderbyno(order_no){
	var  order_id = order_no;
	var task = 'getOrderbyno';
	$.ajax({
		type: "GET",
		url: "ajax.php",
		data: {task:task,order_id:order_id},

		success: function(data){
			console.log(data);
			$("#orderdata").html('');
			$("#orderdata").html(data);
			return false;
		}
	});

	return false;
}

function getCutomerbyId(cust_id){
	var task = 'getCustomer';
	$.ajax({
		type: "GET",
		url: "ajax.php",
		data: {task:task,cust_id:cust_id},
		success: function(data){
			console.log(data);
			$("#getCustomer").html('');
			$("#getCustomer").html(data);
			return false;
		}
	});
	return false;
}
	</script>
    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
    <!-- DataTables -->
    <script src="dist/js/jquery.dataTables.js"></script>
    <script src="dist/js/dataTables.bootstrap.min.js"></script>
    <script>
	$(function () {
		$('#example111').DataTable({
			"bPaginate": true,
			"bFilter": true,
			"bInfo": true
		});
	});
	
	$("#message").fadeIn('slow').delay(5000).fadeOut('slow');
    </script> 
    
    <!-- daterangepicker -->
    <script src="dist/js/moment.min.js"></script>
    <!-- bootstrap time picker -->
    <script src="plugins/timepicker/bootstrap-timepicker.js"></script>
    <!-- iCheck 1.0.1 -->
    <script src="plugins/iCheck/icheck.min.js"></script>
    <script src="plugins/daterangepicker/daterangepicker.js"></script>
    <!-- datepicker -->
    <script src="plugins/datepicker/bootstrap-datepicker.js"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js"></script>
    
    <script type="text/javascript" src="plugins/datepicker/bootstrap-clockpicker.min.js"></script>
    
    <script type="text/javascript" src="dist/js/date.js"></script>
    
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    
	
  </body>
</html>