<?php 
require_once('class/class.items.php');
$objitem = new item();

if(isset($_POST['saveitems']))
{
	$result = $objitem->saveItemFab();
	if($result == '0'){
		$_SESSION['msgD'] = 'Error found!!!';
	}else{
		$_SESSION['msgD'] = 'Data inserted successfully.';
	}
	$objitem->redirect($_SERVER['HTTP_REFERER']);
	exit();
}

?>