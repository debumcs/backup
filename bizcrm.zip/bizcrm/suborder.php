<?php 

require_once('class/class.fabric.php');
$objfabric 		= new Fabric();
$allfabric = $objfabric->getAll();
require_once('class/class.stylemaster.php');
$objstyle = new Stylemaster();
$allstyle = $objstyle->getAll();
require_once('class/class.agencymaster.php');
require_once('class/class.orderdetails.php');
$objord = new Orderdetails();
$objagency 		= new Agencymaster();
$allagent 		= $objagency->getAll();

$action 	= $_GET["action"];
$orderno 	= $_GET["orderno"];
$suborder 	= $_GET["suborder"];

$msgD = '';

if($action == "editsub")
{
	$data = $objord->getSuborderById($suborder);
	$subordertitle = 'Update Sub Order';
	$btnvalue = "UPDATE";
	$subreadonly = '';
	$disabled = '';
}
else
{
	$btnvalue = "PROCEED";
	$subordertitle = 'New Sub Order';
}

if(isset($_POST['submit']))
{
	$objord->savesuborder();
	exit();
}

if(isset($_POST['savedying']) and $_POST['savedying'] == 'Save')
{
	$objord->savedying();
	exit();
}

if(isset($_POST['saveembroidery']) and $_POST['saveembroidery'] == 'Save')
{
	$objord->saveembroidery();
	exit();
}

if(isset($_POST['savecutting']) and $_POST['savecutting'] == 'Save')
{
	$objord->savecutting();
	exit();
}

if(isset($_POST['savetailor']) and $_POST['savetailor'] == 'Save')
{
	$objord->savetailor();
	exit();
}

if(isset($_POST['saveStore']) and $_POST['saveStore'] == 'Save')
{
	$objord->savestore();
	exit();
}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="bootstrap/css/datepicker.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
    <link rel="stylesheet" type="text/css" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css"></link>
	
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />
	
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<script type="text/javascript" src="js_suborder.js"></script>
	
	<style>
	.connecting_preference_checkbox{
		display:block !important; float:left; width:20px;
	}
	.connecting_preference_box{
		display: block;float: left;width: 25%;
	}
	.datepicker{z-index:1151 !important;}
	</style>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
     
   <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objord->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objord->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <!--h1>
            Add Customer
          </h1>
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Control Panel</li>
            <li class="active">Add Customer</li>
          </ol>
        </section><!--CONTENT HEADER-->
        
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
							<div class="col-md-12">
								<h3 class="box-title"> <?php echo $subordertitle; ?> </h3>
							</div>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <form action="" name="userCreate" id="userCreate" method="post" >
							<div class="row">
							<input type="hidden" id="id" name="id" value="<?php echo $data['id']; ?>" />
							
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Order No</label>
											<input type="text" readonly="true" tabindex="1" id="orderno" name="orderno" class="form-control" value="<?php echo $orderno; ?>" />
										</div>
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Order Detail</label>
											<input type="text"  tabindex="2" id="details" name="details" class="form-control" placeholder="Order Detail" value="<?php echo $data['details']; ?>" />
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Style Ref</label>
											<select id="style_ref" tabindex="3" class="form-control" name="style_ref">
											<option value="" selected="selected">Select Style Ref</option>
											<?php for($si = 0; $si < count($allstyle); $si++){ ?>
											<option value="<?php echo $allstyle[$si]['style_code']; ?>" <?php if($data['style_ref'] == $allstyle[$si]['style_code']){echo 'selected';} ?>><?php echo $allstyle[$si]['style_code']; ?></option>
											<?php } ?>
											</select>
										</div>	
									</div><!-- /.col -->
								</div>
								<div class="col-lg-12">
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Fabric</label>
											<select id="fabric" tabindex="4" class="form-control" name="fabric">
											<option value="" selected="selected">Select Fabric</option>
											<?php for($fi = 0; $fi < count($allfabric); $fi++){ ?>
											<option value="<?php echo $allfabric[$fi]['id']; ?>" <?php if($data['fabric'] == $allfabric[$fi]['id']){echo 'selected';} ?>><?php echo $allfabric[$fi]['fabricname']; ?></option>
											<?php } ?>
											</select>
										</div>
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
										<label for="name">Fabric Quatity</label>
										<input type="text" class="form-control" tabindex="5" id="fabric_quatity" name="fabric_quatity" placeholder="Enter fabric quatity" value="<?php echo $data['fabric_quatity']; ?>">
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-4">
										<div class="form-group">
										<label for="name">Original Amount</label>
										<input type="text" class="form-control" tabindex="6" onKeyUp="calculateSaleAmount();" onKeyPress="return isDecimalNumber(event,this.value,this);" id="original_amount" name="original_amount" placeholder="Enter Original Amount" <?php echo $subreadonly; ?> value="<?php if($action == "editsub"){ echo $data['original_amount'];}else{echo '0';} ?>">
										</div>	
									</div><!-- /.col -->
								</div>	
								
								<div class="col-lg-12">
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Discount Amount</label>
											<input type="text" class="form-control" tabindex="7" onKeyUp="calculateSaleAmount();" onKeyPress="return isDecimalNumber(event,this.value,this);" id="discount_amount" name="discount_amount" placeholder="Enter Discount Amount" value="<?php if($action == "editsub"){echo $data['discount_amount'];}else{echo '0';} ?>">
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Sale Amount</label>
											<input type="text" class="form-control" tabindex="8" readonly id="sale_amount" name="sale_amount" placeholder="Sale Amount" value="<?php echo $data['sale_amount']; ?>">
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Status</label>
											<select class="form-control select2" tabindex="9" id="substatus" name="substatus" style="width:100%;">
											<option value="" selected>Select Status</option>
											<option value="1" <?php if($data['substatus'] == 1){echo 'selected';}?>>Incomplete</option>
											<option value="2" <?php if($data['substatus'] == 2){echo 'selected';}?>>Pending</option>
											<option value="3" <?php if($data['substatus'] == 3){echo 'selected';}?>>Processed</option>
											<option value="4" <?php if($data['substatus'] == 4){echo 'selected';}?>>Partially Shipped</option>
											<option value="5" <?php if($data['substatus'] == 5){echo 'selected';}?>>Shipping</option>
											<option value="6" <?php if($data['substatus'] == 6){echo 'selected';}?>>Shipped</option>
											<option value="7" <?php if($data['substatus'] == 7){echo 'selected';}?>>Partially Returned</option>
											<option value="8" <?php if($data['substatus'] == 8){echo 'selected';}?>>Returned</option>
											<option value="9" <?php if($data['substatus'] == 9){echo 'selected';}?>>Cancelled</option>
											</select>
										</div>
									</div><!-- /.col -->
									
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Trial Date</label>
											<input type="text" class="form-control datepicker" tabindex="10" id="trial_date" name="trial_date" placeholder="Enter trial date" value="<?php if($action == "editsub"){echo $data['trial_date'];}else{echo date('Y-m-d');} ?>">
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Delivery Due Date</label>
											<input type="text" class="form-control datepicker" tabindex="11" id="delivery_due_date" name="delivery_due_date" placeholder="Delivery due date" value="<?php if($action == "editsub"){echo $data['delivery_due_date'];}else{echo date('Y-m-d');} ?>">
										</div>			  
									</div><!-- /.col -->
									
								</div>
								
							</div><!-- /.row -->
							
							<!--<div class="row">
                              <div class="col-lg-12">
                                   <div class="form-group center">
                                      <input type="submit" name="submit" id="submit" onclick="return validatesuborder();" class="btn btn-warning left-10" value="<?php echo $btnvalue; ?>" />
                                   </div>
                               </div>
             				</div>-->
                           </form>
                        </div><!-- /.box-body--> 
						
						
						
						<div class='box-body'>
                            <div class="row">
							<?php if($action == "editsub"){ ?> 
								<div class="col-lg-12">
									<div class="col-lg-2">
										<div class="form-group">
											<?php $dyerinfo = $objord->getdyinginfo($suborder); ?>
											<a href="#" data-toggle="modal" data-target="#adddying" class="btn btn-warning left-10"><?php if(count($dyerinfo) > 0){ echo 'View Dying Agency'; }else{ echo  'Assign to Dying Agency';} ?></a>											
										</div>
									</div><!-- /.col -->

									<div class="col-lg-2">										
										<div class="form-group">
											<?php $embroinfo = $objord->getembroideryinfo($suborder); ?>										  
											<a href="#" data-toggle="modal" data-target="#addEmbroidery" class="btn btn-warning left-10"><?php if(count($embroinfo) > 0){echo 'View Embroidery'; }else{ echo  'Assign to Embroidery';} ?></a>										  
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-2">										
										<div class="form-group">
											<?php $cuttinfo = $objord->getcuttinginfo($suborder); ?>
											<a href="#" data-toggle="modal" data-target="#addCutting" class="btn btn-warning left-10"><?php if(count($cuttinfo) > 0){echo 'View Cutting Agency'; }else{ echo  'Assign to Cutting Agency';} ?></a>
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-2">										
										<div class="form-group">
											<?php $tailorinfo = $objord->gettailorinfo($suborder); ?>
											<a href="#" data-toggle="modal" data-target="#addTailor" class="btn btn-warning left-10"><?php if(count($tailorinfo) > 0){echo 'View Tailor Agency'; }else{ echo  'Assign to Tailor Agency';} ?></a>											
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-2">										
										<div class="form-group">
											<?php $storeinfo = $objord->getstoreinfo($suborder); ?>
											<a href="#" data-toggle="modal" data-target="#addStore" class="btn btn-warning left-10"><?php if(count($storeinfo) > 0){echo 'View Store Management'; }else{ echo  'Assign to Store Management';} ?></a>											
										</div>									  
									</div><!-- /.col -->
								</div>
							<?php } ?>	
							</div><!-- /.row -->							
							
                        </div><!-- /.box-body--> 
						
						
						
                     </div><!-- /.box-->                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
      </div><!-- /.content-wrapper -->
      
      
      <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->
	<?php include('modal_suborder.php'); ?>
    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
	
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<script src="bootstrap/js/bootstrap-datepicker.js"></script>
	<script type="text/javascript">
	
		$(document).ready(function (){
			
			$('.datepicker').datepicker({
				format: "yyyy-mm-dd",
				autoclose: true
			});
			
		});		
		
		$.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
	
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
	<script>
	//$('#order_detail').wysihtml5();
	//$('#delivery_remarks').wysihtml5();
	</script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
   
    <!-- AdminLTE for demo purposes -->
	
  </body>
</html>