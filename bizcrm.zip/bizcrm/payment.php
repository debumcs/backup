<?php 
	require_once('class/class.orderdetails.php');
	$objord = new Orderdetails();
	$orderno = $_GET["orderno"];
	
	$msgD = '';
	
	if(isset($_POST['savePayment'])){
		$objord->savePaymentDetails();
		$objord->redirect('payment.php?orderno='.$_POST['orderno']);
		unset($_POST);
	}
	
	//$data 				= $objord->getById($orderno);
	$allpayment 		= $objord->getAllPaymentByOrderno($orderno);
	$data 				= $objord->get_order_payemt_amount($orderno);

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>BIZCRM | Manage Payment</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="date/jquery-ui.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
    <link rel="stylesheet" type="text/css" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css"></link>
	
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />
	
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<script>
	
	function isDecimalNumber(evt, element) {
		
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode!=46)
		{
			status = "This field accepts numbers only.";
			return false;
		}else {
			var len = $(element).val().length;
			var index = $(element).val().indexOf('.');
			if (index > 0 && charCode == 46) {
				return false;
			}
			if (index > 0) {
				var CharAfterdot = (len + 1) - index;
				if (CharAfterdot > 3) {
					return false;
				}
			}

		}
		return true;
	}
	
	function validatepayment(){
		if(document.getElementById('payment_date').value =='' )
		{
			alert('Please Enter date!');
			document.getElementById('payment_date').focus();
			return false;
		}
		else if(document.getElementById('payment_mode').value =='' )
		{
			alert('Please Select paymentmode !');
			document.getElementById('payment_mode').focus();
			return false;
		}
		else if((document.getElementById('received_amount').value =='') || parseFloat(document.getElementById('received_amount').value == 0))
		{
			alert('Please Enter received amount!');
			document.getElementById('received_amount').focus();
			return false;
		}
		else{
			return true;
		}
	}
	
	</script>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
     
   <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objord->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objord->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Manage Payment
          </h1>
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Control Panel</li>
            <li class="active">Manage Payment</li>
          </ol>
        </section><!--CONTENT HEADER-->
        
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title">List Payments</h3>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            
							<div class="row">							
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Customer ID</label>
										  	
											<a href="#" data-toggle="modal" data-target="#getCutomerbyId" onclick='getCutomerbyId("<?php echo $data['customer_id']; ?>")'><?php echo $data['customer_id']; ?></a>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Order ID</label>
										  <a href="#" data-toggle="modal" data-target="#orderdetails" onclick='getOrderbyno("<?php echo $data['orderno']; ?>")'><?php echo $data['orderno']; ?></a>
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Gross Sale Amount</label>
										  <a href="#"><?php echo $data['original_amount']; ?></a>
										</div>								  
									</div><!-- /.col -->
									
								</div>
								<div class="col-lg-12">									
								
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Discount Amount</label>
										  	
											<a href="#"><?php echo $data['discount_amount']; echo '('.number_format((($data['discount_amount']/$data['sale_amount'])*100), 2, '.', ' ').'%)';?></a>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Net Sale amount</label>
										  <a href="#"><?php echo $data['sale_amount']; ?></a>
										</div>									  
									</div><!-- /.col -->
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Amount received </label>
										  <a href="#"><?php echo $data['received_amount']; ?></a>
										</div>
									</div>
									
								</div>
								
								<div class="col-lg-12">	
									
									<div class="col-lg-6">
										<div class="form-group">
										  <label for="name">Balance amount </label>
										  <a href="#"><?php echo ($data['sale_amount']-$data['received_amount']); ?></a>
										</div>
									</div>
								</div>
								
							</div><!-- /.row -->
						   
							<div class="row">
								<div class="col-lg-12">
										<h4 class="box-title">Payment Details</h4>
										<div class='box-body'>
										
											<table id="example111" class="table table-bordered table-striped">
												<thead>
													<tr>	
														<th>SL. No.</th>
														<th>Payment Date</th>
														<th>Payment Mode </th>
														<th>Received Amount</th>	
														<th>Remark</th>														
													</tr>
												</thead>
												<tbody>
												<?php for($i=0; $i<count($allpayment); $i++) { ?>
													<tr>
														<td><?php $j= $i+1; echo $j; ?></td>
														<td><?php echo $allpayment[$i]['payment_date']; ?></td>
														<td><?php echo $allpayment[$i]['payment_mode']; ?></td>
														<td><?php echo $allpayment[$i]['received_amount']; ?></td>
														<td><?php echo $allpayment[$i]['remarks']; ?></td>
													</tr>
												<?php }  ?>						
												</tbody>
											</table>
										</div><!-- /.box-body--> 
									</div>
             				</div><!-- /.row -->
                           
                           <div class="row">
                              <div class="col-lg-12">
                                   <div class="form-group left-10">
                                      <a href="#" data-toggle="modal" data-target="#addMyPayment" class="btn btn-warning left-10">Add Payment</a>
                                   </div>
                               </div><!-- /.col -->
             				 </div><!-- /.row -->
							 
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
      </div><!-- /.content-wrapper -->
      
	<!-- add payment -->
	<div class="modal fade" id="addMyPayment" tabindex="-1" role="dialog" aria-labelledby="addMyPaymentLabel">
		<div class="modal-dialog" role="document">
		<form action="" method="post" name="payment" id="payment">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel">Add Payment </h4>
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="col-lg-12">
							<div class="form-group">
								<label for="name">Payment Date</label>
								<input type="text" tabindex="1" class="form-control datepicker" id="payment_date" name="payment_date" placeholder="Enter payment date" value="<?php echo date('m/d/Y');?>" />
								<input type="hidden" id="orderno" name="orderno" value="<?php echo $data['orderno']; ?>">
								<input type="hidden" id="customer_id" name="customer_id" value="<?php echo $data['customer_id']; ?>">
							</div>
							
							<div class="form-group">
							  <label for="name">Payment Mode</label>
							  <select name="payment_mode" tabindex="2" class="form-control" id="payment_mode">
							  <option value="">Select Payment Mode</option>
							  <option value="Cash">Cash</option>
							  <option value="CreditCard">CreditCard</option>
							  <option value="Cheque">Cheque</option>
							  <option value="MobileWallet">MobileWallet</option>
							  </select>
							</div>
							
							 <div class="form-group">
							  <label for="name">Received Amount</label>
							  <input type="text" class="form-control" tabindex="3" id="received_amount" onKeyPress="return isDecimalNumber(event,this);" name="received_amount" placeholder="Enter received_amount">
							</div>
							
							<div class="form-group">
							  <label for="name">Remarks</label>
							  <input type="text" class="form-control" tabindex="4" id="remarks" name="remarks" placeholder="Enter remarks">
							</div>								
						</div><!-- /.col -->
						  
					</div><!-- /.row -->
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<input type="submit" class="btn btn-primary" name="savePayment" id="savePayment" onclick="return validatepayment();" value="Save" />
				</div>
			</div>
		</form>
		</div>
	</div>
	<!-- Add Payment -->
	  
      
      <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->
<div class="modal fade" id="getCutomerbyId" tabindex="-1" role="dialog" aria-labelledby="getCutomerbyIdLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Customer Details </h4>
			</div>
			
			<div class="modal-body">
				<div class="row">
					<div id="getCustomer">

					</div><!-- /.col -->
				</div><!-- /.row -->
			</div>
			
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>		
		</div>
	</div>
</div>

	
<div class="modal fade" id="orderdetails" tabindex="-1" role="dialog" aria-labelledby="orderdetailsLabel">
	<div class="modal-dialog" role="document">	
	<div class="modal-content">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Order Details </h4>
		</div>
		<div class="modal-body">
			<div class="row">
				<div class="col-lg-12" id="orderdata">


				</div><!-- /.col -->
			</div><!-- /.row -->
		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		</div>
	</div>	
	</div>
</div>
	<script src="date/jquery-1.9.1.js"></script>
	<script src="date/jquery-ui.js"></script>
	<script>
	$(function() {
		$( ".datepicker" ).datepicker();
	});
	
	function getOrderbyno(order_no){
	var  order_id = order_no;
	var task = 'getOrderbyno';
	$.ajax({
		type: "GET",
		url: "ajax.php",
		data: {task:task,order_id:order_id},

		success: function(data){
			console.log(data);
			$("#orderdata").html('');
			$("#orderdata").html(data);
			return false;
		}
	});

	return false;
}

function getCutomerbyId(cust_id){
	var task = 'getCustomer';
	$.ajax({
		type: "GET",
		url: "ajax.php",
		data: {task:task,cust_id:cust_id},
		success: function(data){
			console.log(data);
			$("#getCustomer").html('');
			$("#getCustomer").html(data);
			return false;
		}
	});
	return false;
}
	</script>
	<script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>

    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
	<script>
	//$('#order_detail').wysihtml5();
	//$('#delivery_remarks').wysihtml5();
	</script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js"></script>
    <!-- AdminLTE for demo purposes -->
	
    <script>
		$("#message").fadeIn('slow').delay(5000).fadeOut('slow');
		$(".select2").select2();
	</script>
  </body>
</html>