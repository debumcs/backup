<?php 

// Construct an HTTP POST request
$clientlogin_url = "https://www.google.com/accounts/ClientLogin";
$clientlogin_post = array(
    "accountType" => "HOSTED_OR_GOOGLE",
    "Email" => "debumcs@gmail.com",
    "Passwd" => "~!Prasad@15",
    "service" => "writely",
    "source" => "BIZcrm"
);

// Initialize the curl object
$curl = curl_init($clientlogin_url);

// Set some options (some for SHTTP)
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $clientlogin_post);
curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

// Execute
$response = curl_exec($curl);
echo $response;
echo '<pre>';
print_r($response);
echo '</pre>';

// Get the Auth string and save it
preg_match("/Auth=([a-z0-9_-]+)/i", $response, $matches);
$auth = $matches[1];

echo "The auth string is: " . $auth;

?>