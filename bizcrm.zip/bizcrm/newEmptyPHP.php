<div class="modal fade" id="ordernotes<?php echo $data['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="ordernotes<?php echo $data['id']; ?>">
										<div class="modal-dialog" role="document">
										<form method="post" name="payment" id="payment">
										<div class="modal-content">
										<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<h4 class="modal-title" id="myModalLabel">Order Notes</h4>
										</div>
										<div class="modal-body">
										<div class="row">
										<div class="col-lg-12">
										<div class='table table-bordered table-striped' >
											<div class="col-lg-12">
												<div id='dordernotes<?php echo $data['id']; ?>' class='orderdiv'></div>
											</div>
										</div>
										<div class="form-group">
										<label for="name">Enter Notes</label>
										<textarea  class="form-control" id="order_note<?php echo $data['id']; ?>" name="order_note" placeholder="Enter Notes"></textarea>
										</div>
										<div class="form-group">
											<label for="name">Delivery Status</label>
											<select class="form-control" id="status<?php echo $data['id']; ?>" name="status" style="width:33%;" tabindex="-1" required >
											<option value="2" selected>Pending</option>
											<option value="1">Incomplete</option>
											<option value="3">Processed</option>
											<option value="4">Partially Shipped</option>
											<option value="5">Shipping</option>
											<option value="6">Shipped</option>
											<option value="7">Partially Returned</option>
											<option value="8">Returned</option>
											<option value="9">Cancelled</option>
											</select>
										</div>
										
										<div class="form-group">
										<label for="name">Agent ID</label>
										<?php echo $data['name'].' ('.$data['agent_id'].')'; ?>
										<input type="hidden" name="agent_id"  id="agent_id<?php echo $data['id']; ?>" class="btn btn-warning left-10" value="<?php echo $data['agent_id']; ?>" />
										</div>

										</div><!-- /.col -->                             
										
										
										
										</div><!-- /.row -->
										</div>
										<div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
										<input type="hidden" name="order_id"  id="order_id<?php echo $data['id']; ?>" class="btn btn-warning left-10" value="<?php echo  $data['orderno']; ?>" />
										
										<input name="ipaddress" type="hidden" id="ipaddress" value="<?php echo $_SERVER['REMOTE_ADDR'];?>" >

										<input type="button" class="btn btn-primary" name="savePayment" id="savePayment" value="Save" onclick='addOrdernotes("<?php echo $data['id']; ?>");'/>
										</div>
										</div>
										</form>
										</div>
									</div>