<?php  
	require_once('class/class.invoice.php');
	$objInv = new invoice();
	
	$html = $html2 ='';


$action	=	$_GET['action'];
$id		=	$_GET['id'];
if($action == 'view'){
	
	$row = $objInv->getById($id);
	
	//$sqlgoods = "SELECT * FROM goods_details where invoice_id = '".$id."'";
	$resultgoods = $objInv->getAllGoodsByInvoiceId($id);
	
	
	$taxinvoice = '';
	$taxinvoice = '<table cellpadding="0" cellspacing="0" border-collapse="collapse" width="916">
	<tr>
		<td class="parent">
			<table cellpadding="1" cellspacing="0" border-collapse="collapse" width="915">
				<tbody>
					<tr bgcolor="#c5d1d7">
						<td ><img alt="" src="header8.png"></td>				
					</tr>
					<tr >
						<td valign="top">
							<table cellpadding="0" cellspacing="0">
							<tr >
								<td width="12" class="innerbody">&nbsp;</td>
								<td width="890" >
									<table cellpadding="0" cellspacing="0">
										<tr>
											<td width="12">&nbsp;</td>
											<td width="866">&nbsp;</td>
											<td width="12">&nbsp;</td>
										</tr>
										<tr >
											<td width="12">&nbsp;</td>
											<td width="866" >
												<table cellpadding="2" class="first" cellspacing="0">
													<tr>
														<td class="second" width="400">GSTIN No.&nbsp;:&nbsp;&nbsp;'.$row['gstin_no'].'</td>
														<td class="second" width="66">&nbsp;</td>
														<td class="second" width="400">Mobile No.&nbsp;:&nbsp;&nbsp;'.$row['mob_no'].'</td>
													</tr>
													<tr >
														<td class="second" width="400">&nbsp;</td>
														<td class="second" width="66" >&nbsp;</td>
														<td class="second" width="400">e-mail id&nbsp;:&nbsp;&nbsp;'.$row['email'].'</td>
													</tr>
													<tr>
														<td width="864" colspan="3" align="center" class="taxinvoicetext">TAX INVOICE</td>
													</tr>
													<tr>
														<td width="864" colspan="3" align="center" class="farmnametext">Name of the Firm &nbsp;:&nbsp;&nbsp;'.$row['firm_name'].' <br />Address of the Firm &nbsp;:&nbsp;&nbsp;'.$row['firm_address'].' <br />Main Products in which dealing &nbsp;:&nbsp;&nbsp;'.$row['products'].' </td>
													</tr>
													<tr>
														<td width="400" class="second">&nbsp;Date of Invoice &nbsp;:&nbsp;&nbsp;'.$row['invoice_date'].' </td>
														<td width="66" class="second">&nbsp;</td>
														<td width="400" class="second">&nbsp;Serial No. of Invoice &nbsp;:&nbsp;&nbsp;'.$row['invoice_serialno'].' </td>
													</tr>
													<tr>
														<td width="864" colspan="3">&nbsp;</td>
													</tr>
													<tr>
														<td width="400" class="third">&nbsp;Details of Receiver(Billed to)<br />&nbsp;Name &nbsp;:&nbsp;&nbsp;'.$row['biller_name'].' <br />&nbsp;Address &nbsp;:&nbsp;&nbsp;'.$row['bill_to_address'].' <br />&nbsp;State &nbsp;:&nbsp;&nbsp;'.$row['bill_to_state'].' <br />&nbsp;State Code &nbsp;:&nbsp;&nbsp;'.$row['bill_to_state_code'].' <br />&nbsp;Mobile No. & E-Mail ID &nbsp;:&nbsp;&nbsp;'.$row['bill_to_mob_no'].' '.$row['bill_to_email'].' <br />&nbsp;GSTIN/Unique ID &nbsp;:&nbsp;&nbsp;'.$row['bill_gstin_id'].'</td>
														<td width="66">&nbsp;</td>
														<td width="400" class="fourth">&nbsp;Details of Consignee (Shipped to )<br />&nbsp;Name &nbsp;:&nbsp;&nbsp;'.$row['ship_name'].' <br />&nbsp;Address &nbsp;:&nbsp;&nbsp;'.$row['ship_to_address'].' <br />&nbsp;State &nbsp;:&nbsp;&nbsp;'.$row['ship_to_state'].' <br />&nbsp;State Code &nbsp;:&nbsp;&nbsp;'.$row['ship_to_state_code'].' <br />&nbsp;Mobile No. & E-Mail ID &nbsp;:&nbsp;&nbsp;'.$row['ship_to_mob_no'].' '.$row['ship_to_email'].'<br />&nbsp;GSTIN/Unique ID &nbsp;:&nbsp;&nbsp;'.$row['ship_gstin_id'].'</td>
													</tr>
													<tr>
														<td width="864" colspan="3">&nbsp;</td>
													</tr>
													<tr>														
														<td width="866"  colspan="3" style="border-top: 1pt solid #8d8d8d;">
															<table cellpadding="0" cellspacing="0">
																<tr>
																	<td class="fifth" rowspan="2" width="30">Sr. No.</td>
																	<td class="fifth" rowspan="2" width="128">Description Of Goods</td>
																	<td class="fifth" rowspan="2" width="47">HSN Code</td>
																	<td class="fifth" rowspan="2" width="40">Qty</td>
																	<td class="fifth" rowspan="2" width="40">Unit</td>
																	<td class="fifth" rowspan="2" width="65">Rate (per Item)</td>
																	<td class="fifth" rowspan="2" width="65">Total</td>
																	<td class="fifth" rowspan="2" width="65">Discount</td>
																	<td class="fifth" rowspan="2" width="65">Taxable Value</td>
																	<td class="fifth" width="105">CGST</td>
																	<td class="fifth" width="105">SGST</td>
																	<td class="second" width="108">IGST</td>
																</tr>
																<tr>
																	<td class="fifth" width="52">Rate</td>
																	<td class="fifth" width="53">Amt.</td>
																	<td class="fifth" width="52">Rate</td>
																	<td class="fifth" width="53">Amt.</td>
																	<td class="fifth" width="52">Rate</td>
																	<td class="second" width="56">Amt.</td>
																</tr>';
													for($i=0;$i<count($resultgoods);$i++ ){
													$taxinvoice.='<tr>
																	<td class="sixth" align="center" width="30">'.$resultgoods[$i]["sr_no"].'</td>
																	<td class="sixth" align="center" width="128">'.$resultgoods[$i]["Description"].'</td>
																	<td class="sixth" align="center" width="47">'.$resultgoods[$i]["hsn_code"].'</td>
																	<td class="sixth" width="40" align="right">'.$resultgoods[$i]["qty"].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="40" align="right">'.$resultgoods[$i]["unit"].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="65" align="right">'.$resultgoods[$i]["rate"].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="65" align="right">'.$resultgoods[$i]["total"].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="65" align="right">'.$resultgoods[$i]["discount"].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="65" align="right">'.$resultgoods[$i]["taxable_value"].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="52" align="right">'.$resultgoods[$i]["cgst_rate"].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="53" align="right">'.$resultgoods[$i]["cgst_amt"].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="52" align="right">'.$resultgoods[$i]["sgst_rate"].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="53" align="right">'.$resultgoods[$i]["sgst_amt"].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="52" align="right">'.$resultgoods[$i]["igst_rate"].'&nbsp;&nbsp;</td>
																	<td class="" width="53" align="right">'.$resultgoods[$i]["igst_amt"].'&nbsp;&nbsp;</td>
																</tr>';
													}
													$taxinvoice.='<tr>
																	<td class="sixth" width="30"></td>
																	<td class="sixth" width="128"></td>
																	<td class="sixth" width="47"></td>
																	<td class="sixth" width="40" align="right"></td>
																	<td class="sixth" width="40" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="" width="53" align="right"></td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td style="border-right:1pt solid #8d8d8d;border-top:1pt solid #8d8d8d;" width="320">&nbsp;Freight</td>
																	<td class="sixth" width="65" align="right">'.$row['freight_total'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="65" align="right">'.$row['freight_discount'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="65" align="right">'.$row['freight_taxable'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="52" align="right">'.$row['freight_cgstRate'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="53" align="right">'.$row['freight_cgstAmt'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="52" align="right">'.$row['freight_sgstRate'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="53" align="right">'.$row['freight_sgstAmt'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="52" align="right">'.$row['freight_igstRate'].'&nbsp;&nbsp;</td>
																	<td class="" width="53" align="right">'.$row['freight_igstAmt'].'&nbsp;&nbsp;</td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="sixth" width="320">&nbsp;Insurance</td>
																	<td class="sixth" width="65" align="right">'.$row['insaurance_total'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="65" align="right">'.$row['insaurance_discount'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="65" align="right">'.$row['insaurance_taxable'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="52" align="right">'.$row['insaurance_cgstRate'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="53" align="right">'.$row['insaurance_cgstAmt'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="52" align="right">'.$row['insaurance_sgstRate'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="53" align="right">'.$row['insaurance_sgstAmt'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="52" align="right">'.$row['insaurance_igstRate'].'&nbsp;&nbsp;</td>
																	<td class="" width="53" align="right">'.$row['insaurance_igstAmt'].'&nbsp;&nbsp;</td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="sixth" width="320">&nbsp;Packing and Forwarding Charges</td>
																	<td class="sixth" width="65" align="right">'.$row['pack_total'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="65" align="right">'.$row['pack_discount'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="65" align="right">'.$row['pack_taxable'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="52" align="right">'.$row['pack_cgstRate'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="53" align="right">'.$row['pack_cgstAmt'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="52" align="right">'.$row['pack_sgstRate'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="53" align="right">'.$row['pack_sgstAmt'].'&nbsp;&nbsp;</td>
																	<td class="sixth" width="52" align="right">'.$row['pack_igstRate'].'&nbsp;&nbsp;</td>
																	<td class="" width="53" align="right">'.$row['pack_igstAmt'].'&nbsp;&nbsp;</td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="seventh" colspan="5" width="320">&nbsp;Total</td>
																	<td class="seventh" width="65" align="right">'.$row['total_total'].'&nbsp;&nbsp;</td>
																	<td class="seventh" width="65" align="right">'.$row['total_discount'].'&nbsp;&nbsp;</td>
																	<td class="seventh" width="65" align="right">'.$row['total_taxable_value'].'&nbsp;&nbsp;</td>
																	<td class="seventh" colspan="2" width="105" align="right">'.$row['total_cgst'].'&nbsp;&nbsp;</td>
																	<td class="seventh" colspan="2" width="105" align="right">'.$row['total_sgst'].'&nbsp;&nbsp;</td>
																	<td class="seventh" colspan="2" width="108" align="right">'.$row['total_igst'].'&nbsp;&nbsp;</td>
																</tr>
																<tr>
																	<td class="sixth" rowspan="3" width="30"></td>
																	<td class="seventh" rowspan="3" colspan="8" width="515">&nbsp;Total Invoice Value (In figure)<br />&nbsp;Total Invoice Value (In Words)<br />&nbsp;Amount of Tax subject to Reverse Charges &nbsp;(Yes/No)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$row['rev_tax_amt'].'</td>
																	<td class="seventh" style="border-left:1pt solid #8d8d8d;" colspan="6" width="318" align="left">&nbsp;'.$row['total_in_figure'].'</td>
																</tr>
																<tr>
																	<td class="seventh" style="border-left:1pt solid #8d8d8d;" colspan="6" width="318" align="left">&nbsp;'.$row['total_in_words'].'</td>
																</tr>													
																<tr>
																	<td class="seventh" style="border-left:1pt solid #8d8d8d;" colspan="2" width="105" align="right">'.$row['tax_reverse_cgst'].'&nbsp;&nbsp;&nbsp;</td>
																	<td class="seventh" style="border-left:1pt solid #8d8d8d;" colspan="2" width="105" align="right">'.$row['tax_reverse_sgst'].'&nbsp;&nbsp;&nbsp;</td>
																	<td class="seventh" style="border-left:1pt solid #8d8d8d;" colspan="2" width="108" align="right">'.$row['tax_reverse_igst'].'&nbsp;&nbsp;&nbsp;</td>
																</tr>
																<tr>
																	<td class="sixth" width="30" ></td>
																	<td class="" colspan="8" width="515">&nbsp;Electronic Reference Number&nbsp;&nbsp;&nbsp;&nbsp;'.$row['electronic_ref_no'].'</td>
																	<td class="" colspan="6" width="318">&nbsp;</td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="" colspan="8" width="515"></td>
																	<td class="" colspan="6" width="315">&nbsp;Signature</td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="" colspan="8" width="515"></td>
																	<td class="" colspan="6" width="315">&nbsp;Name of the Signatory</td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="" colspan="8" width="515"></td>
																	<td class="" colspan="6" width="315">&nbsp;Designation/Status</td>
																</tr>
															</table>
														</td>
													</tr>
												</table>
											</td>
											<td width="12">&nbsp;</td>
										</tr>
										<tr>
											<td width="12">&nbsp;</td>
											<td width="866">&nbsp;</td>
											<td width="12">&nbsp;</td>
										</tr>
									</table>
								</td>
								<td width="12" class="innerbody">&nbsp;</td>
							</tr>
							<tr>
								<td width="12" class="innerbody">&nbsp;</td>
								<td width="890" class="innerbody">&nbsp;</td>
								<td width="12" class="innerbody">&nbsp;</td>
							</tr>
							</table>
						</td>
					</tr>
				</tbody>
			</table>
		</td>
	</tr>
</table>';
	//echo $taxinvoice;
	//die();
	$html = htmlspecialchars($taxinvoice);
}

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	 <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    
	<!-- Select2 -->
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->

  </head>
  <body class="hold-transition skin-blue sidebar-mini" >
     
  <!-- <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?> -->
   <div class="wrapper">
		<?php $objInv->psheader(); ?>
		<?php $objInv->pssidebar(); ?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
           View Invoice
          </h1>
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Invoice</li>
            <li class="active">View Invoice</li>
          </ol>
        </section><!--CONTENT HEADER-->
        
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title">Invoice</h3> 
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <form class="search widget" action="taxgst/generatepdf.php" method="post" >

							<div class="form-group">

								<input type="hidden" value="<?php echo $html; ?>" name="report" id="report" />

								<button type="submit" name="generate" id="generate" class="btn btn-primary" >Generate PDF</button>
								&nbsp;&nbsp;&nbsp;<a href="viewallinvoice.php" class="btn btn-info">View All Invoice</a>					

							</div>

							</form>
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
      </div><!-- /.content-wrapper -->
      
      
 <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->
	<!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
	

    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<script src="bootstrap/js/bootstrap-datepicker.js"></script>
	<script type="text/javascript">
	// When the document is ready
	$(document).ready(function () {		
		$('.datepicker').datepicker({
			format: "dd/mm/yyyy",
			//format: "yyyy-mm-dd",
			autoclose: true
		});
	});			
	</script>
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
   
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
   
</body>
</html>
