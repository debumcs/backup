<?php 
require_once('class/class.agencymaster.php');
require_once('class/class.orderdetails.php');
$objord = new Orderdetails();
$objagency 		= new Agencymaster();
$allagent 		= $objagency->getAll();

$action 	= $_GET["action"];
$orderno 	= $_GET["orderno"];
$suborder 	= $_GET["suborder"];

$msgD = '';

/*
var task = 'updatedyinginfo';
$.ajax({
type: "POST",
url: "assignsuborder.php",
data: {task:task,suborderno:suborderno,orderno:orderno,id:id,dychallanno:dychallanno,dydetails:dydetails,dyerid:dyerid,dyfabricid:dyfabricid,dyquantity:dyquantity,dying_color:dying_color,dyassign_date:dyassign_date,dydue_date:dydue_date,dyreceiving_date:dyreceiving_date},

*/

if(isset($_POST['savedying']) and $_POST['savedying'] == 'Save')
{
	$objord->savedying();
	exit();
}

if(isset($_POST['saveembroidery']) and $_POST['saveembroidery'] == 'Save')
{
	$objord->saveembroidery();
	exit();
}

if(isset($_POST['savecutting']) and $_POST['savecutting'] == 'Save')
{
	$objord->savecutting();
	exit();
}

if(isset($_POST['savetailor']) and $_POST['savetailor'] == 'Save')
{
	$objord->savetailor();
	exit();
}

if(isset($_POST['saveStore']) and $_POST['saveStore'] == 'Save')
{
	$objord->savestore();
	exit();
}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="bootstrap/css/datepicker.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
    <link rel="stylesheet" type="text/css" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css"></link>
	
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />
	
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<script type="text/javascript" src="js_suborder.js"></script>
	<style>
	.connecting_preference_checkbox{
		display:block !important; float:left; width:20px;
	}
	.connecting_preference_box{
		display: block;float: left;width: 25%;
	}
	.datepicker{z-index:1151 !important;}
	</style>

  </head>
  <body class="hold-transition skin-blue sidebar-mini">
     
   <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objord->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objord->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <!--h1>
            Add Customer
          </h1>
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Control Panel</li>
            <li class="active">Add Customer</li>
          </ol>
        </section><!--CONTENT HEADER-->
        
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
							<div class="col-md-12">
								<h3 class="box-title">Assign Sub-Order </h3>
							</div>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <div class="row">
								<div class="col-lg-12">
									<div class="col-lg-12">
										<h4> Order No: <?php echo $orderno; ?>, Sub-order: <?php echo $suborder; ?></h4><br/>
									</div>
								</div>
								<div class="col-lg-12">
									<div class="col-lg-2">
										<div class="form-group">
											
											<?php $dyerinfo = $objord->getdyinginfo($suborder); ?>
											
											<a href="#" data-toggle="modal" data-target="#adddying" class="btn btn-warning left-10"><?php if(count($dyerinfo) > 0){
												echo 'View Dying Agency'; }else{ echo  'Assign to Dying Agency';} ?></a>
											
										</div>
									</div><!-- /.col -->

									<div class="col-lg-2">										
										<div class="form-group">
											<?php $embroinfo = $objord->getembroideryinfo($suborder); ?>										  
											<a href="#" data-toggle="modal" data-target="#addEmbroidery" class="btn btn-warning left-10"><?php if(count($embroinfo) > 0){echo 'View Embroidery'; }else{ echo  'Assign to Embroidery';} ?></a>										  
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-2">										
										<div class="form-group">
										  <!--<label for="name">Cutting</label>-->
											<?php $cuttinfo = $objord->getcuttinginfo($suborder); ?>
											<a href="#" data-toggle="modal" data-target="#addCutting" class="btn btn-warning left-10"><?php if(count($cuttinfo) > 0){echo 'View Cutting Agency'; }else{ echo  'Assign to Cutting Agency';} ?></a>
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-2">										
										<div class="form-group">
										  <!--<label for="name">Tailor</label>-->
										  
											<?php $tailorinfo = $objord->gettailorinfo($suborder); ?>
											<a href="#" data-toggle="modal" data-target="#addTailor" class="btn btn-warning left-10"><?php if(count($tailorinfo) > 0){echo 'View Tailor Agency'; }else{ echo  'Assign to Tailor Agency';} ?></a>
											
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-2">										
										<div class="form-group">
											<?php $storeinfo = $objord->getstoreinfo($suborder); ?>
											<a href="#" data-toggle="modal" data-target="#addStore" class="btn btn-warning left-10"><?php if(count($storeinfo) > 0){echo 'View Store Management'; }else{ echo  'Assign to Store Management';} ?></a>
										</div>									  
									</div><!-- /.col -->
									
								</div>
								
							</div><!-- /.row -->
							
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
      </div><!-- /.content-wrapper -->
      
      
    <?php include('footer.php'); ?>

    <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->
	<?php include('modal_suborder.php'); ?>
	
    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
	
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<script src="bootstrap/js/bootstrap-datepicker.js"></script>
	<script type="text/javascript">
	// When the document is ready
	$(document).ready(function (){
		
		$('.datepicker').datepicker({
			format: "yyyy-mm-dd",
			autoclose: true
		});
	});
	$("#message").fadeIn('slow').delay(5000).fadeOut('slow');
	</script>
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
	
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
	<script>
	//$('#order_detail').wysihtml5();
	//$('#delivery_remarks').wysihtml5();
	</script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
   
    <!-- AdminLTE for demo purposes -->
	
  </body>
</html>