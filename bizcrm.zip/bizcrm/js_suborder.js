function calculateSaleAmount() {		
	var original_amount = parseFloat($("#original_amount").val());
	var discount 		= parseFloat($("#discount_amount").val());
	
	if((original_amount != 0 && discount != 0) && (original_amount < discount )){
		alert('Discounted amount should be less than original amount!');
		document.getElementById('discount_amount').value = 0;
		document.getElementById('sale_amount').value=original_amount;
		document.getElementById('discount_amount').focus();
		return false;
	}else{
		document.getElementById('sale_amount').value = (original_amount - discount).toFixed(2);
	}
}	
		
function validatesuborder(){
	
	if(document.getElementById('orderno').value =='' ){
		alert('Please enter order number!');
		document.getElementById('orderno').focus();
		return false;
	}/* else if(document.getElementById('suborderno').value =='' ){
		alert('Please enter sub order no!');
		document.getElementById('suborderno').focus();
		return false;
	} */else if(document.getElementById('original_amount').value =='' ){
		alert('Please enter original amount!');
		document.getElementById('original_amount').focus();
		return false;
	}else if(document.getElementById('order_detail').value =='' ){
		alert('Please enter order detail!');
		document.getElementById('order_detail').focus();
		return false;
	}else{
		return true;
	}
}




	function isDecimalNumber(evt,value,element) {
	var charCode = (evt.which) ? evt.which : event.keyCode;
	var len = $(element).val().length;
		var index = $(element).val().indexOf('.');
    if((value.indexOf('.')!=-1) && (charCode != 45 && (charCode < 48 || charCode > 57))){
		return false;
    }    
    else if(charCode != 45 && (charCode != 46 || $(this).val().indexOf('.') != -1) && (charCode < 48 || charCode > 57)){
		return false;
    }
	if (index > 0) {
			var CharAfterdot = (len + 1) - index;
			if (CharAfterdot > 3) {
				return false;
			}
		}
    return true;

}

function checkIt(evt)
{
	evt = (evt) ? evt : window.event;
	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57))
	{
		status = "This field accepts numbers only.";
		return false;
	}
	status = "";
	return true ;
}

/* store start */

function validatestore(){
	
	if(document.getElementById('store_in_date').value ==''){
		alert('Please enter store in date!');
		document.getElementById('store_in_date').focus();
		return false;
	}else{
		return true;
	}
}
	
function storereadonly(){
	document.getElementById('store_in_date').readOnly = false;
	document.getElementById('store_out_date').readOnly = false;
	document.getElementById('updatestore').style.display = "block";
	document.getElementById('editstore').style.display = "none";			
}

function storereadonlytrue(){
	document.getElementById('store_in_date').readOnly = true;
	document.getElementById('store_out_date').readOnly = true;
	document.getElementById('updatestore').style.display = "none";
	document.getElementById('editstore').style.display = "block";			
}

function updatestoreInfo(){
	if(document.getElementById('store_in_date').value == ''){
		alert('Please enter store in date!');
		document.getElementById('store_in_date').focus();
		return false;
	}
	if(document.getElementById('store_out_date').value == ''){
		alert('Please enter store out date!');
		document.getElementById('store_out_date').focus();
		return false;
	}
		
	var store_in_date 		= document.getElementById('store_in_date').value;
	var store_out_date		= document.getElementById('store_out_date').value;
	var orderno				= document.getElementById('orderno').value;
	var suborderno			= document.getElementById('suborderno').value;
	
	var task = 'updatestoreinfo';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data: {task:task,store_in_date:store_in_date,store_out_date:store_out_date,orderno:orderno,suborderno:suborderno},

		success: function(data){
			console.log(data);
			$(".response").fadeOut(100);
			$(".response").html(data);
			$(".response").fadeIn(500);
			return false;
		}
	});
	storereadonlytrue();
	return false;
}

function addstorenotes(){
	var suborderno 	= $("#suborderno").val();
	var store_notes = $("#store_notes").val();
	var ststatus	= $("#ststatus").val();
	
	if(store_notes == ''){
		alert('Please enter notes23453245!');
		return false;
	}
	if(ststatus == ''){
		alert('Please select status!');
		return false;
	}
	
	var task = 'store_notes';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data: {task:task,suborderno:suborderno,store_notes:store_notes,ststatus:ststatus},

		success: function(response){
			console.log(response);
			$("#notesstore").html('');
			$("#store_notes").val('');
			$("#notesstore").html(response);
			return false;
		}
	});

	return false;
}

/* store end*/

/* tailor start */
 
function tailorreadonly(){
	document.getElementById('tachallanno').readOnly = false;
	document.getElementById('tadetails').readOnly = false;
	//document.getElementById('tailorid').readOnly = false;
	document.getElementById('taassigndate').readOnly = false;
	document.getElementById('taduedate').readOnly = false;
	document.getElementById('tareceivingdate').readOnly = false;			
	document.getElementById('updatetailor').style.display = "block";
	document.getElementById('edittailor').style.display = "none";	
	$(document).ready(function(){	
		$('#tailorid').prop('disabled',false);	
	});
}

function tailorreadonlytrue(){
	document.getElementById('tachallanno').readOnly = true;
	document.getElementById('tadetails').readOnly = true;
	//document.getElementById('tailorid').readOnly = true;
	document.getElementById('taassigndate').readOnly = true;
	document.getElementById('taduedate').readOnly = true;
	document.getElementById('tareceivingdate').readOnly = true;			
	document.getElementById('updatecutting').style.display = "none";
	document.getElementById('editcutting').style.display = "block";	
	$(document).ready(function(){	
		$('#tailorid').prop('disabled',true);	
	});
}

function updateTailorInfo(){
	if(document.getElementById('tachallanno').value ==''){
		alert('Please enter challan number!');
		document.getElementById('tachallanno').focus();
		return false;
	}
	if(document.getElementById('tadetails').value ==''){
		alert('Please enter details!');
		document.getElementById('tadetails').focus();
		return false;
	}
	if(document.getElementById('tailorid').value ==''){
		alert('Please select embroider name!');
		document.getElementById('tailorid').focus();
		return false;
	}
	
	if(document.getElementById('taassigndate').value ==''){
		alert('Please enter assign date!');
		document.getElementById('taassigndate').focus();
		return false;
	}
	if(document.getElementById('taduedate').value ==''){
		alert('Please enter due date!');
		document.getElementById('taduedate').focus();
		return false;
	}
	
	var tachallanno 		= document.getElementById('tachallanno').value;
	var tadetails 			= document.getElementById('tadetails').value;
	var tailorid			= document.getElementById('tailorid').value;
	var taassigndate		= document.getElementById('taassigndate').value;
	var taduedate			= document.getElementById('taduedate').value;
	var tareceivingdate		= document.getElementById('tareceivingdate').value;
	var id					= document.getElementById('id').value;
	var orderno				= document.getElementById('orderno').value;
	var suborderno			= document.getElementById('suborderno').value;
	
	var task = 'updatetailorinfo';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data: {task:task,suborderno:suborderno,orderno:orderno,id:id,tachallanno:tachallanno,tadetails:tadetails,tailorid:tailorid,taassigndate:taassigndate,taduedate:taduedate,tareceivingdate:tareceivingdate},

		success: function(data){
			console.log(data);
			$(".response").fadeOut(100);
			$(".response").html(data);
			$(".response").fadeIn(500);
			return false;
		}
	});
	tailorreadonlytrue();
	return false;
}

function addtailornotes(){
	var suborderno 	= $("#suborderno").val();
	var tailorid 	= $("#tailorid").val();
	var tailor_notes= $("#tailor_notes").val();
	var tastatus	= $("#tastatus").val();
	
	if(tailor_notes == ''){
		alert('Please enter notes!');
		return false;
	}
	if(tastatus == ''){
		alert('Please select status!');
		return false;
	}
	
	var task = 'tailor_notes';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data: {task:task,suborderno:suborderno,tailorid:tailorid,tailor_notes:tailor_notes,tastatus:tastatus},

		success: function(data){
			console.log(data);
			$("#notestailor").html('');
			$("#tailor_notes").val('');
			$("#notestailor").html(data);
			return false;
		}
	});

	return false;
}

/* tailor end*/

/* cutting start */
 
function cuttingreadonly(){
	document.getElementById('cuchallanno').readOnly = false;
	document.getElementById('cudetails').readOnly = false;
	document.getElementById('cutterid').readOnly = false;
	document.getElementById('cuassign_date').readOnly = false;
	document.getElementById('cudue_date').readOnly = false;
	document.getElementById('cureceiving_date').readOnly = false;			
	document.getElementById('updatecutting').style.display = "block";
	document.getElementById('editcutting').style.display = "none";
	$(document).ready(function(){	
		$('#cutterid').prop('disabled',false);	
	});
	
}

function cuttingreadonlytrue(){
	document.getElementById('cuchallanno').readOnly = true;
	document.getElementById('cudetails').readOnly = true;
	//document.getElementById('cutterid').readOnly = true;
	document.getElementById('cuassign_date').readOnly = true;
	document.getElementById('cudue_date').readOnly = true;
	document.getElementById('cureceiving_date').readOnly = true;			
	document.getElementById('updatecutting').style.display = "none";
	document.getElementById('editcutting').style.display = "block";
	$(document).ready(function(){	
		$('#cutterid').prop('disabled',true);	
	});
}

function updateCuttingInfo(){
	if(document.getElementById('cuchallanno').value ==''){
		alert('Please enter challan number!');
		document.getElementById('cuchallanno').focus();
		return false;
	}
	if(document.getElementById('cudetails').value ==''){
		alert('Please enter details!');
		document.getElementById('cudetails').focus();
		return false;
	}
	if(document.getElementById('cutterid').value ==''){
		alert('Please select embroider name!');
		document.getElementById('cutterid').focus();
		return false;
	}
	
	if(document.getElementById('cuassign_date').value ==''){
		alert('Please enter assign date!');
		document.getElementById('cuassign_date').focus();
		return false;
	}
	if(document.getElementById('cudue_date').value ==''){
		alert('Please enter due date!');
		document.getElementById('cudue_date').focus();
		return false;
	}
	
	var cuchallanno 		= document.getElementById('cuchallanno').value;
	var cudetails 			= document.getElementById('cudetails').value;
	var cutterid			= document.getElementById('cutterid').value;
	var cuassign_date		= document.getElementById('cuassign_date').value;
	var cudue_date			= document.getElementById('cudue_date').value;
	var cureceiving_date	= document.getElementById('cureceiving_date').value;
	var id					= document.getElementById('id').value;
	var orderno				= document.getElementById('orderno').value;
	var suborderno			= document.getElementById('suborderno').value;
	
	var task = 'updatecuttinginfo';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data: {task:task,suborderno:suborderno,orderno:orderno,id:id,cuchallanno:cuchallanno,cudetails:cudetails,cutterid:cutterid,cuassign_date:cuassign_date,cudue_date:cudue_date,cureceiving_date:cureceiving_date},

		success: function(data){
			console.log(data);
			$(".response").fadeOut(100);
			$(".response").html(data);
			$(".response").fadeIn(500);
			return false;
		}
	});
	cuttingreadonlytrue();
	return false;
}

function addcuttingnotes(){
	var suborderno 	= $("#suborderno").val();
	var cutterid = $("#cutterid").val();
	var cutting_notes	= $("#cutting_notes").val();
	var custatus	= $("#custatus").val();
	
	if(cutting_notes == ''){
		alert('Please enter notes!');
		return false;
	}
	if(custatus == ''){
		alert('Please select status!');
		return false;
	}
	
	var task = 'cutting_notes';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data: {task:task,suborderno:suborderno,cutterid:cutterid,cutting_notes:cutting_notes,custatus:custatus},

		success: function(data){
			console.log(data);
			$("#notescutting").html('');
			$("#cutting_notes").val('');
			$("#notescutting").html(data);
			return false;
		}
	});

	return false;
}

/* cutting end*/

/* embro start */
 
function embroreadonly(){
	document.getElementById('emchallanno').readOnly = false;
	document.getElementById('emdetails').readOnly = false;
	//document.getElementById('embroiderid').readOnly = false;
	document.getElementById('emassign_date').readOnly = false;
	document.getElementById('emdue_date').readOnly = false;
	document.getElementById('emreceiving_date').readOnly = false;			
	document.getElementById('updateembro').style.display = "block";
	document.getElementById('editembro').style.display = "none";
	$(document).ready(function(){	
		$('#embroiderid').prop('disabled',false);	
	});
}

function embroreadonlytrue(){
	document.getElementById('emchallanno').readOnly = true;
	document.getElementById('emdetails').readOnly = true;
	//document.getElementById('embroiderid').readOnly = true;
	document.getElementById('emassign_date').readOnly = true;
	document.getElementById('emdue_date').readOnly = true;
	document.getElementById('emreceiving_date').readOnly = true;			
	document.getElementById('updateembro').style.display = "none";
	document.getElementById('editembro').style.display = "block";			
	$(document).ready(function(){	
		$('#embroiderid').prop('disabled',true);	
	});
}

function updateEmbroInfo(){
	if(document.getElementById('emchallanno').value ==''){
		alert('Please enter challan number!');
		document.getElementById('emchallanno').focus();
		return false;
	}
	if(document.getElementById('emdetails').value ==''){
		alert('Please enter details!');
		document.getElementById('emdetails').focus();
		return false;
	}
	if(document.getElementById('embroiderid').value ==''){
		alert('Please select embroider name!');
		document.getElementById('embroiderid').focus();
		return false;
	}
	
	if(document.getElementById('emassign_date').value ==''){
		alert('Please enter assign date!');
		document.getElementById('emassign_date').focus();
		return false;
	}
	if(document.getElementById('emdue_date').value ==''){
		alert('Please enter due date!');
		document.getElementById('emdue_date').focus();
		return false;
	}
	
	var emchallanno 		= document.getElementById('emchallanno').value;
	var emdetails 			= document.getElementById('emdetails').value;
	var embroiderid			= document.getElementById('embroiderid').value;
	var emassign_date		= document.getElementById('emassign_date').value;
	var emdue_date			= document.getElementById('emdue_date').value;
	var emreceiving_date	= document.getElementById('emreceiving_date').value;
	var id					= document.getElementById('id').value;
	var orderno				= document.getElementById('orderno').value;
	var suborderno			= document.getElementById('suborderno').value;
	
	var task = 'updateembroinfo';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data: {task:task,suborderno:suborderno,orderno:orderno,id:id,emchallanno:emchallanno,emdetails:emdetails,embroiderid:embroiderid,emassign_date:emassign_date,emdue_date:emdue_date,emreceiving_date:emreceiving_date},

		success: function(data){
			console.log(data);
			$(".response").fadeOut(100);
			$(".response").html(data);
			$(".response").fadeIn(500);
			return false;
		}
	});
	embroreadonlytrue();
	return false;
}

function addembronotes(){
	var suborderno 			= $("#suborderno").val();
	var embroiderid 		= $("#embroiderid").val();
	var embroidery_notes	= $("#embroidery_notes").val();
	var emstatus			= $("#emstatus").val();
	
	if(embroidery_notes == ''){
		alert('Please enter notes!');
		return false;
	}
	if(emstatus == ''){
		alert('Please select status!');
		return false;
	}
	
	var task = 'embro_notes';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data: {task:task,suborderno:suborderno,embroiderid:embroiderid,embroidery_notes:embroidery_notes,emstatus:emstatus},

		success: function(data){
			console.log(data);
			$("#notesembro").html('');
			$("#embroidery_notes").val('');
			$("#notesembro").html(data);
			return false;
		}
	});

	return false;
}

/* embro end*/


function dyingreadonly(){
	document.getElementById('dychallanno').readOnly = false;
	document.getElementById('dydetails').readOnly = false;
	//document.getElementById('dyerid').disable = false;
	//document.getElementById('dyfabricid').disable = false;
	document.getElementById('dyquantity').readOnly = false;
	document.getElementById('dying_color').readOnly = false;
	document.getElementById('dyassign_date').readOnly = false;
	document.getElementById('dydue_date').readOnly = false;
	document.getElementById('dyreceiving_date').readOnly = false;			
	document.getElementById('updatedying').style.display = "block";
	document.getElementById('editdying').style.display = "none";
	$(document).ready(function(){	
		$('#dyerid,#dyfabricid').prop('disabled',false);	
	});
}

function dyingreadonlytrue(){
	document.getElementById('dychallanno').readOnly = true;
	document.getElementById('dydetails').readOnly = true;
	document.getElementById('dyquantity').readOnly = true;
	document.getElementById('dying_color').readOnly = true;
	document.getElementById('dyassign_date').readOnly = true;
	document.getElementById('dydue_date').readOnly = true;
	document.getElementById('dyreceiving_date').readOnly = true;			
	document.getElementById('updatedying').style.display = "none";
	document.getElementById('editdying').style.display = "block";	

	$(document).ready(function(){
		$('#dyerid,#dyfabricid').prop('disabled',true);
	});
}

function updateDyingInfo(){
	if(document.getElementById('dychallanno').value ==''){
		alert('Please enter challan number!');
		document.getElementById('dychallanno').focus();
		return false;
	}
	if(document.getElementById('dydetails').value ==''){
		alert('Please enter details!');
		document.getElementById('dydetails').focus();
		return false;
	}
	if(document.getElementById('dyerid').value ==''){
		alert('Please select dyer name!');
		document.getElementById('dyerid').focus();
		return false;
	}
	if(document.getElementById('dyfabricid').value ==''){
		alert('Please select dyer fabric id!');
		document.getElementById('dyfabricid').focus();
		return false;
	}
	if(document.getElementById('dyquantity').value ==''){
		alert('Please enter quantity in meter!');
		document.getElementById('dyquantity').focus();
		return false;
	}
	if(document.getElementById('dying_color').value ==''){
		alert('Please enter challan number!');
		document.getElementById('dying_color').focus();
		return false;
	}
	if(document.getElementById('dyassign_date').value ==''){
		alert('Please enter assign date!');
		document.getElementById('dyassign_date').focus();
		return false;
	}
	if(document.getElementById('dydue_date').value ==''){
		alert('Please enter due date!');
		document.getElementById('dydue_date').focus();
		return false;
	}
	
	var dychallanno 		= document.getElementById('dychallanno').value;
	var dydetails 			= document.getElementById('dydetails').value;
	var dyerid				= document.getElementById('dyerid').value;
	var dyfabricid			= document.getElementById('dyfabricid').value;
	var dyquantity			= document.getElementById('dyquantity').value;
	var dying_color			= document.getElementById('dying_color').value;
	var dyassign_date		= document.getElementById('dyassign_date').value;
	var dydue_date			= document.getElementById('dydue_date').value;
	var dyreceiving_date	= document.getElementById('dyreceiving_date').value;
	var id					= document.getElementById('id').value;
	var orderno				= document.getElementById('orderno').value;
	var suborderno			= document.getElementById('suborderno').value;
	
	var task = 'updatedyinginfo';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data: {task:task,suborderno:suborderno,orderno:orderno,id:id,dychallanno:dychallanno,dydetails:dydetails,dyerid:dyerid,dyfabricid:dyfabricid,dyquantity:dyquantity,dying_color:dying_color,dyassign_date:dyassign_date,dydue_date:dydue_date,dyreceiving_date:dyreceiving_date},

		success: function(data){
			console.log(data);
			$(".response").fadeOut(100);
			$(".response").html(data);
			$(".response").fadeIn(500);
			return false;
		}
	});
	dyingreadonlytrue();
	return false;
}

function adddyingnotes(){
	var suborderno 	= $("#suborderno").val();
	var dyerid 		= $("#dyerid").val();
	var dying_notes	= $("#dying_notes").val();
	var dystatus	= $("#dystatus").val();
	
	if(dying_notes == ''){
		alert('Please enter notes!');
		return false;
	}
	if(dystatus == ''){
		alert('Please select status!');
		return false;
	}
	
	var task = 'dying_notes';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data: {task:task,suborderno:suborderno,dyerid:dyerid,dying_notes:dying_notes,dystatus:dystatus},

		success: function(data){
			console.log(data);
			$("#notesdyer").html('');
			$("#dying_notes").val('');
			$("#notesdyer").html(data);
			return false;
		}
	});

	return false;
}

/*function getallnotes(type,suborderno,id){
	
	var task = 'getallnotes';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data: {task:task,suborderno:suborderno,id:id,type:type},

		success: function(data){
			console.log(data);
			$("#notesdyer").html('');
			$("#notesdyer").html(data);
			return false;
		}
	});

	return false;
}*/

function validatedying(){
	
	if(document.getElementById('dychallanno').value ==''){
		alert('Please enter challan number!');
		document.getElementById('dychallanno').focus();
		return false;
	}else if(document.getElementById('dydetails').value ==''){
		alert('Please enter details!');
		document.getElementById('dydetails').focus();
		return false;
	}else if(document.getElementById('dyerid').value ==''){
		alert('Please select dyer name!');
		document.getElementById('dyerid').focus();
		return false;
	}else if(document.getElementById('dyfabricid').value ==''){
		alert('Please select dyer fabric id!');
		document.getElementById('dyfabricid').focus();
		return false;
	}else if(document.getElementById('dyquantity').value ==''){
		alert('Please enter quantity in meter!');
		document.getElementById('dyquantity').focus();
		return false;
	}else if(document.getElementById('dying_color').value ==''){
		alert('Please enter challan number!');
		document.getElementById('dying_color').focus();
		return false;
	}else if(document.getElementById('dyassign_date').value ==''){
		alert('Please enter assign date!');
		document.getElementById('dyassign_date').focus();
		return false;
	}else if(document.getElementById('dydue_date').value ==''){
		alert('Please enter due date!');
		document.getElementById('dydue_date').focus();
		return false;
	}else if(document.getElementById('dyreceiving_date').value ==''){
		alert('Please enter receiving date!');
		document.getElementById('dyreceiving_date').focus();
		return false;
	}else if(document.getElementById('dying_notes').value ==''){
		alert('Please enter notes!');
		document.getElementById('dying_notes').focus();
		return false;
	}else{				
		return true;
	}
}

function validateembroidery(){
	
	if(document.getElementById('emchallanno').value ==''){
		alert('Please enter challan number!');
		document.getElementById('dychallanno').focus();
		return false;
	}else if(document.getElementById('emdetails').value ==''){
		alert('Please enter details!');
		document.getElementById('emdetails').focus();
		return false;
	}else if(document.getElementById('embroiderid').value ==''){
		alert('Please select embroider id!');
		document.getElementById('embroiderid').focus();
		return false;
	}else if(document.getElementById('emassign_date').value ==''){
		alert('Please enter assign date!');
		document.getElementById('emassign_date').focus();
		return false;
	}else if(document.getElementById('emdue_date').value ==''){
		alert('Please enter due date!');
		document.getElementById('emdue_date').focus();
		return false;
	}else if(document.getElementById('emreceiving_date').value ==''){
		alert('Please enter receiving date!');
		document.getElementById('emreceiving_date').focus();
		return false;
	}else if(document.getElementById('embroidery_notes').value ==''){
		alert('Please enter notes!');
		document.getElementById('embroidery_notes').focus();
		return false;
	}else{
		return true;
	}
}

function validatecutting(){
	
	if(document.getElementById('cudetails').value ==''){
		alert('Please enter details!');
		document.getElementById('cudetails').focus();
		return false;
	}else if(document.getElementById('cutterid').value ==''){
		alert('Please enter cutter id!');
		document.getElementById('cutterid').focus();
		return false;
	}else if(document.getElementById('cuassign_date').value ==''){
		alert('Please enter assign date!');
		document.getElementById('cuassign_date').focus();
		return false;
	}else if(document.getElementById('cudue_date').value ==''){
		alert('Please enter due date!');
		document.getElementById('cudue_date').focus();
		return false;
	}else if(document.getElementById('cureceiving_date').value ==''){
		alert('Please enter receiving date!');
		document.getElementById('cureceiving_date').focus();
		return false;
	}else if(document.getElementById('cutting_notes').value ==''){
		alert('Please enter notes!');
		document.getElementById('cutting_notes').focus();
		return false;
	}else{
		return true;
	}
}

function validatetailor(){
	
	if(document.getElementById('tachallanno').value ==''){
		alert('Please enter challan number!');
		document.getElementById('tachallanno').focus();
		return false;
	}else if(document.getElementById('tadetails').value ==''){
		alert('Please enter details!');
		document.getElementById('tadetails').focus();
		return false;
	}else if(document.getElementById('tailorid').value ==''){
		alert('Please enter tailor id!');
		document.getElementById('tailorid').focus();
		return false;
	}else if(document.getElementById('taassigndate').value ==''){
		alert('Please enter assign date!');
		document.getElementById('taassigndate').focus();
		return false;
	}else if(document.getElementById('taduedate').value ==''){
		alert('Please enter due date!');
		document.getElementById('taduedate').focus();
		return false;
	}else if(document.getElementById('tareceivingdate').value ==''){
		alert('Please enter receiving date!');
		document.getElementById('tareceivingdate').focus();
		return false;
	}else if(document.getElementById('tailor_notes').value ==''){
		alert('Please enter tailor notes!');
		document.getElementById('tailor_notes').focus();
		return false;
	}else{
		return true;
	}
}