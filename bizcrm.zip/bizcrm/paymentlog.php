<?php 
	require_once('include/auth.php');
	require_once('class/class.report.php');
	$objrpt = new Report();
	
	$action = "";
	
	$allDueOrder = NULL;
	$from_date 	= $objrpt->sanitize($_POST['from_date']);
	$to_date 	= $objrpt->sanitize($_POST['to_date']);
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | Payment Logs</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Bootstrap time Picker -->
    <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
    <!-- Date Picker -->
    <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<script type="text/javascript" language="javascript">

		function validatereport(){
            
            if(document.getElementById('from_date').value =='' ){
				alert('Please enter from date!');
				document.getElementById('from_date').focus();
				return false;
			}else if(document.getElementById('to_date').value =='' ){
				alert('Please enter to date!');
				document.getElementById('to_date').focus();
				return false;
			}else {
				return true;
			}
			
      	}
	
	</script>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
     
   <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objrpt->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objrpt->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>Report on Payments Logs</h1>
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
            <li>Report</li>
            <li class="active">Report on Payment Logs</li><li class="active"><?php echo $action; ?></li>
          </ol>
        </section><!--CONTENT HEADER-->
        
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title">Search</h3>
                        </div><!-- /.box-header -->
                        <?php  ?><div class='box-body'>
                            <form action="" name="Sourcemaster" id="Sourcemaster" method="post" >
							<div class="row">
								<div class="col-lg-12">	
									<div class="col-lg-4">
										<div class="form-group">
											<input type="text" class="form-control datepicker" id="from_date" name="from_date" placeholder="Enter from date" value="<?php echo $from_date; ?>" />
										</div><!-- /.form-group -->
									</div><!-- /.col -->
								  
									<div class="col-lg-4">
										<div class="form-group">
											<input type="text" class="form-control datepicker" id="to_date" name="to_date" placeholder="Enter to date" value="<?php echo $to_date; ?>" />
										</div>										
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
											<input type="submit" name="submit" id="submit" class="btn btn-warning left-10" onclick="return validatereport();" value="Submit" />
										</div>										
									</div><!-- /.col -->
									
								</div><!-- /.col -->								
								
                           </div><!-- /.row -->
                           </form>
                        </div><!-- /.box-body--> <?php  ?>
						<?php  
							if($_POST['submit'] == 'Submit'){
								$allPaymentlogs = $objrpt->getPaymentLogs();
								if(count($allPaymentlogs)){
						?>
						<div class='box-body table-responsive'>
							<table id="example111" class="table table-bordered table-striped">
								<thead>
									<tr>
										<th>Order No</th>
										<th>Customer ID</th>
										<th>Payment Date</th>
										<th>Payment Mode</th>
										<th>Received Amount</th>
									</tr>
								</thead>
								<tbody>
								<?php for($i=0; $i<count($allPaymentlogs); $i++) { ?>	
									<tr>
										<td><?php print $allPaymentlogs[$i]['orderno']; ?></td>
										<td><?php print $allPaymentlogs[$i]['customer_id']; ?></td>
										<td><?php print $allPaymentlogs[$i]['payment_date']; ?></td>
										<td><?php print $allPaymentlogs[$i]['payment_mode']; ?></td>
										<td><?php print $allPaymentlogs[$i]['received_amount']; ?></td>
									</tr>
								<?php } ?>						
								</tbody>
							</table>                           
						</div><!-- /.box-body--> 
						<?php }else{ echo 'No record found.';}} ?>
						
						
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
		
		
    </div><!-- /.content-wrapper -->
      
    <?php include('footer.php'); ?>

    <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->

	<div class="modal fade" id="orderStatusDetails" tabindex="-1" role="dialog" aria-labelledby="orderdetailsLabel">
		<div class="modal-dialog" role="document">	
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Order Details </h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-lg-12" id="orderStatusData">


					</div><!-- /.col -->
				</div><!-- /.row -->
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>	
		</div>
	</div>
    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
    
    <!-- daterangepicker -->
    <script src="dist/js/moment.min.js"></script>
    <!-- iCheck 1.0.1 -->
    <script src="plugins/iCheck/icheck.min.js"></script>
    <!-- datepicker -->
    <script src="plugins/datepicker/bootstrap-datepicker.js"></script>
	<script type="text/javascript">
	// When the document is ready
	$(document).ready(function () {	
		$('.datepicker').datepicker({
			format: "yyyy-mm-dd",
			autoclose: true
		});
	});		
	</script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js"></script>
    
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <script>
		$("#message").fadeIn('slow').delay(5000).fadeOut('slow');
		$(".select2").select2();
		
		function getStatusByOrderNo(order_no){
		var  order_id = order_no;
		var task = 'getStatusByOrderNo';
		$.ajax({
			type: "GET",
			url: "ajax.php",
			data: {task:task,order_id:order_id},

			success: function(data){
				console.log(data);
				$("#orderStatusData").html('');
				$("#orderStatusData").html(data);
				return false;
			}
		});

		return false;
	}
	
	</script>
  </body>
</html>