<?php 
include_once("class/class.postlogin2.php");
$objpostlogin = new postlogin();
	require_once('include/auth.php');
if(isset($_POST['submit']))
{
	$objpostlogin->changepassword();
}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | Change Password</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Bootstrap time Picker -->
    <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
    <!-- Date Picker -->
    <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<script type="text/javascript" language="javascript">
	
		function validateuser(){                   
			if(document.getElementById('password').value =='' ){
				alert('Please enter current password!');
				document.getElementById('password').focus();
				return false;
			}else if(document.getElementById('newpassword').value =='' ){
				alert('Please enter new password!');
				document.getElementById('newpassword').focus();
				return false;
			}else if(document.getElementById('confirmpassword').value =='' ){
				alert('Please enter confirm password');
				document.getElementById('confirmpassword').focus();
				return false;
			}else if(document.getElementById('confirmpassword').value !=document.getElementById('newpassword').value ){
				alert('New password and confirm password are not same');
				document.getElementById('newpassword').focus();
				return false;
			}else{
				return true;
			}
		}
	
	</script>
  </head>
  <body class="hold-transition skin-blue sidebar-mini" onload="startTime()">
    <div class="wrapper">

		<?php $objpostlogin->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
	
		<?php $objpostlogin->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Change Password
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Change Password</li>
          </ol>
        </section><!--CONTENT HEADER-->
        
          <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title"></h3>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
						
						<?php if(isset($_SESSION['msgCP'])){echo '<div id="message">'.$_SESSION['msgCP'].'</div>';} unset($_SESSION['msgCP']);?>
                            <form action="" name="change_password" id="userCreate" method="post" autocomplete="off">
							<div class="row">
                              <div class="col-lg-12">
                              		
									
                                    <div class="form-group">
                                      <label for="name">Current Password</label>
                                      <input type="password" class="form-control" maxlength="12" id="password" name="password" placeholder="Enter Current Password" value="">
                                    </div>
                                    
                                     <div class="form-group">
                                      <label for="name">New Password</label>
                                      <input type="password" class="form-control" id="newpassword" maxlength="12" name="newpassword" placeholder="Enter New Password (max 12 character.)" value="">
                                    </div>
                                    
                                     <div class="form-group">
                                      <label for="name">Confirm Password</label>
                                      <input type="password" class="form-control" id="confirmpassword" maxlength="12" name="confirmpassword" placeholder="Confirm Password (max 12 character.)" value="">
                                    </div>
                                    
                              </div><!-- /.col -->                              
                           </div><!-- /.row -->
                           
                           <div class="row">
                              <div class="col-lg-12">
                                   <div class="form-group center">
                                      <input type="submit" name="submit" id="submit" class="btn btn-warning left-10" value="Submit" onclick="return validateuser();" />
                                   </div>
                               </div><!-- /.col -->
             				 </div><!-- /.row -->
                           </form>
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
      </div><!-- /.content-wrapper -->
      
      
     <?php include('footer.php'); ?> 

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
	  $("#message").fadeIn('slow').delay(5000).fadeOut('slow');
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
    
    <!-- daterangepicker -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
    <!-- bootstrap time picker -->
    <script src="plugins/timepicker/bootstrap-timepicker.js"></script>
    <!-- iCheck 1.0.1 -->
    <script src="plugins/iCheck/icheck.min.js"></script>
    <script src="plugins/daterangepicker/daterangepicker.js"></script>
    <!-- datepicker -->
    <script src="plugins/datepicker/bootstrap-datepicker.js"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js"></script>
    
    <script type="text/javascript" src="plugins/datepicker/bootstrap-clockpicker.min.js"></script>
    
    <script type="text/javascript" src="dist/js/date.js"></script>
    
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <script>
	
	
	</script>
  </body>
</html>