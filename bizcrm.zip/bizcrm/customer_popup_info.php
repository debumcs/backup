<?php 
	//require_once('include/auth.php');
	require_once('class/class.customer.php');
	$objcus = new Customer();
	
	$customer_id = $_GET["customer_id"];
	
	$data = $objcus->getCustomerInfo($customer_id);
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>BIZCRM | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet/less" type="text/css" href="side.less" />
	<link rel="stylesheet" href="date/jquery-ui.css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
     
   <div class="wrapper">
			<!-- add payment -->
	  
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Customer Information</h4>
			  </div>
			  <div class="modal-body">
							<div class="row">
							
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Customer ID</label>										  										  
										</div>
									</div><!-- /.col -->

									<div class="col-lg-8">										
										<div class="form-group">
											<?php echo $data['cust_id'];?>										  
										</div>										  
									</div><!-- /.col -->
																	
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Name</label>										  
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-8">
										<div class="form-group">
										<?php echo $data['salutation'];?> <?php echo $data['name_first']; ?> <?php echo $data['name_last']; ?>
										</div>
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Address</label>										  
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-8">
										<div class="form-group">
										<?php echo $data['address1'];?>, <?php echo $data['address2']; ?><br>
										<?php echo $data['city']; ?>, <?php echo $data['state']; ?>, <?php echo $data['country']; ?>, <?php echo $data['pin']; ?>
										</div>
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Contact Number</label>										  
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-8">
										<div class="form-group">
										<?php echo $data['contact_no1'];?>, <?php echo $data['contact_no2']; ?>
										</div>
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Email</label>										  
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-8">										
										<div class="form-group">										 
										  <?php echo $data['email_1']; ?>, <?php echo $data['email_2']; ?>
										</div>			  
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Refferal ID</label>										  
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-8">										
										<div class="form-group">										 
										  <?php echo $data['refferal_id']; ?>
										</div>			  
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Date of Birth</label>										  
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-8">										
										<div class="form-group">										 
										  <?php echo $data['dob']; ?>
										</div>			  
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Anniversary Date</label>										  
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-8">										
										<div class="form-group">										 
										  <?php echo $data['anniversary']; ?>
										</div>			  
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Discount category</label>										  
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-8">										
										<div class="form-group">										 
										  <?php echo $data['discount_category']; ?>
										</div>			  
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Average category</label>
										</div>										  
									</div><!-- /.col -->
									
									<div class="col-lg-8">										
										<div class="form-group">
											<?php echo $data['average_category'];?>
										</div>										  
									</div><!-- /.col -->									
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Remarks</label>
										</div>										  
									</div><!-- /.col -->
									
									<div class="col-lg-8">										
										<div class="form-group">
											<?php echo $data['notes'];?>
										</div>										  
									</div><!-- /.col -->									
								</div>
								
                           </div><!-- /.row -->
                           
                           
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
			  </div>			  
			
	<!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    
   
  </body>
</html>