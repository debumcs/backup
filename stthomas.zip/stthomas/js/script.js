$(document).ready(function() {
	
	/*/////////////////////////////
	  Header Fixed
	/////////////////////////////*/
	$(window).scroll(function(){
		if ($(this).scrollTop() > 50) {
			$('.header-mb').addClass('fixed-mb');
		} else {
			$('.header-mb').removeClass('fixed-mb');
		}
	});

	$(".language-link").click(function(){
		$(".social-dd, .search").hide();
	    $(".language-dd").slideToggle();
	    return false;
	});
	$(".social-link").click(function(){
		$(".language-dd, .search").hide();
	    $(".social-dd").slideToggle();
	    return false;
	});
	$(".search-link").click(function(){
		$(".language-dd, .social-dd").hide();
	    $(".search").slideToggle();
	    return false;
	});

	$("body").click(function(){
        $(".social-dd, .language-dd, .search").hide();
    });
    $('.social-dd, .language-dd, .search').click(function(event){
       event.stopPropagation();
    });

    $(".slider-close").click(function(){
        $(".showcase").slideToggle();
        return false;
    });

    $(".menu").click(function(){
        $(".navigation2").slideToggle();
        return false;
    });
    $(".navigation2>ul>li.dd-link>a").click(function(){
    	$(this).closest('.dd-link').find("ul").slideToggle();
        return false;
    });
    
    $(".filter-link").click(function(){
        $(".sub-menu-box").slideToggle();
        return false;
    });

    $(".sub-menu h4").click(function(){
        $(this).closest('.sub-menu').find(".sub-menu-dd").slideToggle();
        return false;
    });

    /*/////////////////////////////
	  Slider
	/////////////////////////////*/
	$('.showcase').flexslider({
		animation: "slide",
		controlNav: false,
		directionNav: true,
		start: function(slider){
			$('body').removeClass('loading');
		}
	});

	$('.about-slider, .about-slider-mb').flexslider({
		animation: "slide",
		controlNav: false,
		directionNav: true,
		start: function(slider){
			$('body').removeClass('loading');
		}
	});

	$('.campus-slider-dk, .campus-slider-mb').flexslider({
		animation: "slide",
		controlNav: false,
		directionNav: true,
		start: function(slider){
			$('body').removeClass('loading');
		}
	});

	$('.multiple-slider-box').flexslider({
		animation: "slide",
		controlNav: false,
		directionNav: true,
		slideshow: false,
		start: function(slider){
			$('body').removeClass('loading');
		}
	});

	$('.img-slider').flexslider({
		selector: ".slides2 > li",
		animation: "slide",
		controlNav: false,
		directionNav: false,
		slideshowSpeed: 2000,
		start: function(slider){
			$('body').removeClass('loading');
		}
	});
	
	$('#example').DataTable( {
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
    } );
	
	
});