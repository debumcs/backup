<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'Home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route["index"] = 'Home/index';
//About us
$route["about"] = 'Home/about';
$route["overview"] = 'Home/overview';
$route["ourlegacy"] = 'Home/ourlegacy';
$route["affiliations"] = 'Home/affiliations';
$route["infrastructure"] = 'Home/infrastructure';
//Rules
$route["disandrules"] = 'Home/disandrules';
$route["concerningabsence"] = 'Home/concerningabsence';
$route["generalrules"] = 'Home/generalrules';
$route["feesrules"] = 'Home/feesrules';
$route["parentsinstructions"] = 'Home/parentsinstructions';
$route["assessmentcriteria"] = 'Home/assessmentcriteria';
//Beyond Classroom
$route["sports"] = 'Home/sports';
$route["artculture"] = 'Home/artculture';
$route["library"] = 'Home/library';
//School Services
$route["schooltiming"] = 'Home/schooltiming';
//contact us
$route["contact"] = 'Home/contact';
//success enquiry
$route["successenquiry"] = 'Home/successenquiry';
//failure enquiry
$route["failureenquiry"] = 'Home/failureenquiry';
$route["signin"] = 'Home/signin';

/* End of file routes.php */
/* Location: ./application/config/routes.php */
