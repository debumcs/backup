<?php
class Model_About extends CI_Model
{	
	
	
	// Aboutus overview
    function get_aboutus()
	{
		$this->db->from('aboutus');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_aboutus()
    {	
        $this->db->from('aboutus');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('aboutus',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
		   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('aboutus',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    }

    //Aboutus our legacy
    function get_ourlegacy()
	{
		$this->db->from('ourlegacy');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_ourlegacy()
    {	
        $this->db->from('ourlegacy');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('ourlegacy',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
		   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('ourlegacy',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    } 

     //Aboutus the founders
    function get_thefounders()
	{
		$this->db->from('thefounders');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_thefounders()
    {	
        $this->db->from('thefounders');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('thefounders',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
	 	   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('thefounders',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    }
    //Aboutus affiliations
    function get_affiliations()
	{
		$this->db->from('affiliations');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_affiliations()
    {	
        $this->db->from('affiliations');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('affiliations',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
	 	   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('affiliations',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    }
    //Aboutus infrastructure
    function get_infrastructure()
	{
		$this->db->from('infrastructure');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_infrastructure()
    {	
        $this->db->from('infrastructure');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('infrastructure',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
	 	   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('infrastructure',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    }
    //Aboutus cbsc guidelines
    function get_cbscguidelines()
	{
		$this->db->from('cbscguidelines');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_cbscguidelines()
    {	
        $this->db->from('cbscguidelines');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('cbscguidelines',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
	 	   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('cbscguidelines',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    } 	
	
}
?>
