<?php
class Model_Home extends CI_Model
{
	//Home Banner
	function getbanner()
	{
		$this->db->from('banner');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getbannerfront()
	{
		$this->db->from('banner');
		$this->db->where('status','1');
		$this->db->order_by("sort_order", "asc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function trashbanner()
	{
		$this->db->from('banner');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getbannerbyid($banner_id)
	{
		$this->db->from('banner');
		$this->db->where('banner_id',$banner_id);		
		$query = $this->db->get();
		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	
	function save($image_data)
	{	
	$webpage_data = array(
	        'image'=>'upload/banner/'.$image_data['image'], 
			'bannertitle'=>$this->input->post('bannertitle'),
			'bannersubtitle'=>$this->input->post('bannersubtitle'),
            'sort_order'=>$this->input->post('sort_order'), 			
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('banner',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function update($image_data)
    {			
		$website_data = array(
			'image'=>'upload/banner/'.$image_data['image'], 
			'bannertitle'=>$this->input->post('bannertitle'),
			'bannersubtitle'=>$this->input->post('bannersubtitle'),
			'sort_order'=>$this->input->post('sort_order'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('banner_id', $this->input->post('banner_id'));
		unlink($this->input->post('previousimage'));
		$success = $this->db->update('banner',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function updatecontent()
    {			
		$website_data = array(			
			'bannertitle'=>$this->input->post('bannertitle'),
			'bannersubtitle'=>$this->input->post('bannersubtitle'),
			'sort_order'=>$this->input->post('sort_order'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('banner_id', $this->input->post('banner_id'));
		$success = $this->db->update('banner',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspend($banner_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('banner_id', $banner_id);
		$success = $this->db->update('banner',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactive($banner_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('banner_id', $banner_id);
		$success = $this->db->update('banner',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	//Home Content
	function get_homecontent()
	{
		$this->db->from('homecontent');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_homecontent()
    {	
        $this->db->from('homecontent');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('homecontent',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
		   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('homecontent',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    }
}