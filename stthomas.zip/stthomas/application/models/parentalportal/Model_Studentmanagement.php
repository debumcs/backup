<?php
class Model_Studentmanagement extends CI_Model
{	
    //Transport route
	function getroute()
	{
		$this->db->from('route');
		$this->db->where('status','1');
		$result = $this->db->get();
		return $result->result_array();		
	}
	/* Student Registration */	
	function getstudentregistration()
	{
	$sql = "SELECT sr.*, r.name as routename, r.amount as routeamount FROM studentregistration sr INNER JOIN route r on sr.route_id = r.route_id  where sr.status = 1 ORDER BY modified_date desc";
	    $result = $this->db->query($sql);
		return $result->result_array();	
	}
	function trashstudentregistration()
	{
		$sql = "SELECT sr.*, r.name as routename, r.amount as routeamount FROM studentregistration sr INNER JOIN route r on sr.route_id = r.route_id  where sr.status = 0 ORDER BY modified_date desc";
	    $result = $this->db->query($sql);
		return $result->result_array();
	}
	function getstudentregistrationbyid($studentregistration_id)
	{		
		$sql = "SELECT sr.*, r.name as routename, r.amount as routeamount FROM studentregistration sr INNER JOIN route r on sr.route_id = r.route_id where sr.studentregistration_id = '$studentregistration_id'";
        $query = $this->db->query($sql);		
        if($query->num_rows()==1)
		{
			return $query->row_array();
		}
		
	}
	
	function savestudentregistration($image_data)
	{	
	$webpage_data = array(
			's_name'=>$this->input->post('s_name'), 
			's_image'=>'upload/studentregistration/'.$image_data['s_image'],	
			's_admissionno'=>$this->input->post('s_admissionno'),
			's_rollno'=>$this->input->post('s_rollno'),
			's_class'=>$this->input->post('s_class'),
			's_dob'=>$this->input->post('s_dob'),
			's_dateofjoining'=>$this->input->post('s_dateofjoining'),
			's_dateofadmission'=>$this->input->post('s_dateofadmission'),
			's_bloodgroup'=>$this->input->post('s_bloodgroup'),
			's_nationality'=>$this->input->post('s_nationality'),
			's_presentaddress'=>$this->input->post('s_presentaddress'),
			's_permanentaddress'=>$this->input->post('s_permanentaddress'),
			'f_name'=>$this->input->post('f_name'),
			'f_image'=>'upload/studentregistration/'.$image_data['f_image'],
			'f_qualification'=>$this->input->post('f_qualification'),
			'f_organisation'=>$this->input->post('f_organisation'),
			'f_occupation'=>$this->input->post('f_occupation'),
			'f_designation'=>$this->input->post('f_designation'),
			'f_mobileno'=>$this->input->post('f_mobileno'),
			'f_email'=>$this->input->post('f_email'),
			'f_address'=>$this->input->post('f_address'),
			'f_city'=>$this->input->post('f_city'),
			'f_state'=>$this->input->post('f_state'),
			'f_country'=>$this->input->post('f_country'),
			'm_name'=>$this->input->post('m_name'),
			'm_image'=>'upload/studentregistration/'.$image_data['m_image'],
			'm_qualification'=>$this->input->post('m_qualification'),
			'm_organisation'=>$this->input->post('m_organisation'),
			'm_occupation'=>$this->input->post('m_occupation'),
			'm_designation'=>$this->input->post('m_designation'),
			'm_mobileno'=>$this->input->post('m_mobileno'),
			'm_email'=>$this->input->post('m_email'),
			'm_address'=>$this->input->post('m_address'),
			'm_city'=>$this->input->post('m_city'),
			'm_state'=>$this->input->post('m_state'),
			'm_country'=>$this->input->post('m_country'),
			'lg_name'=>$this->input->post('lg_name'),
			'lg_image'=>'upload/studentregistration/'.$image_data['lg_image'],
			'lg_mobileno'=>$this->input->post('lg_mobileno'),
			'lg_email'=>$this->input->post('lg_email'),
			'lg_relation'=>$this->input->post('lg_relation'),
			'lg_address'=>$this->input->post('lg_address'),
			'route_id'=>$this->input->post('route_id'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('studentregistration',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	
	function updatestudentregistration($image_data)
    {			
		$website_data = array(            
			's_name'=>$this->input->post('s_name'), 
			's_image'=>'upload/studentregistration/'.$image_data['s_image'],	
			's_admissionno'=>$this->input->post('s_admissionno'),
			's_rollno'=>$this->input->post('s_rollno'),
			's_class'=>$this->input->post('s_class'),
			's_dob'=>$this->input->post('s_dob'),
			's_dateofjoining'=>$this->input->post('s_dateofjoining'),
			's_dateofadmission'=>$this->input->post('s_dateofadmission'),
			's_bloodgroup'=>$this->input->post('s_bloodgroup'),
			's_nationality'=>$this->input->post('s_nationality'),
			's_presentaddress'=>$this->input->post('s_presentaddress'),
			's_permanentaddress'=>$this->input->post('s_permanentaddress'),
			'f_name'=>$this->input->post('f_name'),
			'f_image'=>'upload/studentregistration/'.$image_data['f_image'],
			'f_qualification'=>$this->input->post('f_qualification'),
			'f_organisation'=>$this->input->post('f_organisation'),
			'f_occupation'=>$this->input->post('f_occupation'),
			'f_designation'=>$this->input->post('f_designation'),
			'f_mobileno'=>$this->input->post('f_mobileno'),
			'f_email'=>$this->input->post('f_email'),
			'f_address'=>$this->input->post('f_address'),
			'f_city'=>$this->input->post('f_city'),
			'f_state'=>$this->input->post('f_state'),
			'f_country'=>$this->input->post('f_country'),
			'm_name'=>$this->input->post('m_name'),
			'm_image'=>'upload/studentregistration/'.$image_data['m_image'],
			'm_qualification'=>$this->input->post('m_qualification'),
			'm_organisation'=>$this->input->post('m_organisation'),
			'm_occupation'=>$this->input->post('m_occupation'),
			'm_designation'=>$this->input->post('m_designation'),
			'm_mobileno'=>$this->input->post('m_mobileno'),
			'm_email'=>$this->input->post('m_email'),
			'm_address'=>$this->input->post('m_address'),
			'm_city'=>$this->input->post('m_city'),
			'm_state'=>$this->input->post('m_state'),
			'm_country'=>$this->input->post('m_country'),
			'lg_name'=>$this->input->post('lg_name'),
			'lg_image'=>'upload/studentregistration/'.$image_data['lg_image'],
			'lg_mobileno'=>$this->input->post('lg_mobileno'),
			'lg_email'=>$this->input->post('lg_email'),
			'lg_relation'=>$this->input->post('lg_relation'),
			'lg_address'=>$this->input->post('lg_address'),
			'route_id'=>$this->input->post('route_id'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('studentregistration_id', $this->input->post('studentregistration_id'));
		unlink($this->input->post('previousimagestudent'));
		unlink($this->input->post('previousimagefather'));
		unlink($this->input->post('previousimagemother'));
		unlink($this->input->post('previousimageguardation'));
		$success = $this->db->update('studentregistration',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendstudentregistration($studentregistration_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('studentregistration_id', $studentregistration_id);
		$success = $this->db->update('studentregistration',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivestudentregistration($studentregistration_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('studentregistration_id', $studentregistration_id);
		$success = $this->db->update('studentregistration',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	
	/* Student Subject Details */	
	function getstudentsubject()
	{
	$sql = "SELECT * FROM studentsubject where status = 1 ORDER BY modified_date desc";
	    $result = $this->db->query($sql);
		return $result->result_array();	
	}
	function trashstudentsubject()
	{
		$sql = "SELECT * FROM studentsubject where status = 0 ORDER BY modified_date desc";
	    $result = $this->db->query($sql);
		return $result->result_array();
	}
	function getstudentsubjectbyid($studentsubject_id)
	{
        $sql = "SELECT * FROM studentsubject where studentsubject_id = '$studentsubject_id'";
        $query = $this->db->query($sql);		
        if($query->num_rows()==1)
		{
			return $query->row_array();
		}
		
	}
	
	function savestudentsubject()
	{	
	$webpage_data = array(
			's_class'=>$this->input->post('s_class'),			
			'title'=>$this->input->post('title'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('studentsubject',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	
	function updatestudentsubject()
    {			
		$website_data = array(            
			's_class'=>$this->input->post('s_class'),			
			'title'=>$this->input->post('title'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('studentsubject_id', $this->input->post('studentsubject_id'));
		$success = $this->db->update('studentsubject',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendstudentsubject($studentsubject_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('studentsubject_id', $studentsubject_id);
		$success = $this->db->update('studentsubject',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivestudentsubject($studentsubject_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('studentsubject_id', $studentsubject_id);
		$success = $this->db->update('studentsubject',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	
	
}