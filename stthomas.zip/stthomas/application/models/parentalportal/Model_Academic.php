<?php
class Model_Academic extends CI_Model
{
    /* Assignment */	
    function getassignment()
	{
		$this->db->from('assignment');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function trashassignment()
	{
		$this->db->from('assignment');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getassignmentbyid($assignment_id)
	{
		$this->db->from('assignment');
		$this->db->where('assignment_id',$assignment_id);		
		$query = $this->db->get();
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	function saveassignment()
	{	
	$webpage_data = array(
			'type'=>$this->input->post('type'),			
			'teacher_name'=>$this->input->post('teacher_name'),
			's_class'=>$this->input->post('s_class'),
			'subject'=>$this->input->post('subject'),
			'title'=>$this->input->post('title'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('assignment',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function updateassignment()
    {			
		$website_data = array(            
			'type'=>$this->input->post('type'),			
			'teacher_name'=>$this->input->post('teacher_name'),
			's_class'=>$this->input->post('s_class'),
			'subject'=>$this->input->post('subject'),
			'title'=>$this->input->post('title'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('assignment_id', $this->input->post('assignment_id'));
		$success = $this->db->update('assignment',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendassignment($assignment_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('assignment_id', $assignment_id);
		$success = $this->db->update('assignment',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactiveassignment($assignment_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('assignment_id', $assignment_id);
		$success = $this->db->update('assignment',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	/* Evaluation(Exam Time Table) */	
    function getexamtimetable()
	{
		$this->db->from('examtimetable');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function trashexamtimetable()
	{
		$this->db->from('examtimetable');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getexamtimetablebyid($examtimetable_id)
	{
		$this->db->from('examtimetable');
		$this->db->where('examtimetable_id',$examtimetable_id);		
		$query = $this->db->get();
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	function saveexamtimetable()
	{	
	$webpage_data = array(
			's_class'=>$this->input->post('s_class'),			
			'subject'=>$this->input->post('subject'),
			'teacher_name'=>$this->input->post('teacher_name'),
			'exam_date'=>$this->input->post('exam_date'),
			'exam_time'=>$this->input->post('exam_time'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('examtimetable',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function updateexamtimetable()
    {			
		$website_data = array(            
			's_class'=>$this->input->post('s_class'),			
			'subject'=>$this->input->post('subject'),
			'teacher_name'=>$this->input->post('teacher_name'),
			'exam_date'=>$this->input->post('exam_date'),
			'exam_time'=>$this->input->post('exam_time'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('examtimetable_id', $this->input->post('examtimetable_id'));
		$success = $this->db->update('examtimetable',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendexamtimetable($examtimetable_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('examtimetable_id', $examtimetable_id);
		$success = $this->db->update('examtimetable',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactiveexamtimetable($examtimetable_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('examtimetable_id', $examtimetable_id);
		$success = $this->db->update('examtimetable',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	
	/* Evaluation->class management(Class) */	
    function getclass()
	{
		$this->db->from('class');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function trashclass()
	{
		$this->db->from('class');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getclassbyid($class_id)
	{
		$this->db->from('class');
		$this->db->where('class_id',$class_id);		
		$query = $this->db->get();
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	function saveclass()
	{	
	$webpage_data = array(
			'class_name'=>$this->input->post('class_name'),			
			'class_description'=>$this->input->post('class_description'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('class',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function updateclass()
    {			
		$website_data = array(            
			'class_name'=>$this->input->post('class_name'),			
			'class_description'=>$this->input->post('class_description'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('class_id', $this->input->post('class_id'));
		$success = $this->db->update('class',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendclass($class_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('class_id', $class_id);
		$success = $this->db->update('class',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactiveclass($class_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('class_id', $class_id);
		$success = $this->db->update('class',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	
	/* Evaluation->class management(Section) */	
	function getclasssection()
	{
		$this->db->from('class');
		$this->db->where('status','1');
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getclassteacher()
	{
		$this->db->from('teacherregistration');
		$this->db->where('status','1');
		$result = $this->db->get();
		return $result->result_array();		
	}
    function getsection()
	{
		$sql = "SELECT s.*, c.class_name as classname, t.teacher_name as 
		classteacher FROM section s INNER JOIN class c on s.class_id = c.class_id INNER JOIN teacherregistration t on s.teacherregistration_id = t.teacherregistration_id where s.status = 1 ORDER BY modified_date desc";
	    $result = $this->db->query($sql);
		return $result->result_array();	
	}
	function trashsection()
	{
		$sql = "SELECT s.*, c.class_name as classname, t.teacher_name as 
		classteacher FROM section s INNER JOIN class c on s.class_id = c.class_id INNER JOIN teacherregistration t on s.teacherregistration_id = t.teacherregistration_id where s.status = 0 ORDER BY modified_date desc";
	    $result = $this->db->query($sql);
		return $result->result_array();		
	}
	function getsectionbyid($section_id)
	{
		$sql = "SELECT s.*, c.class_name as classname, t.teacher_name as 
		classteacher FROM section s INNER JOIN class c on s.class_id = c.class_id INNER JOIN teacherregistration t on s.teacherregistration_id = t.teacherregistration_id where s.section_id = '$section_id'";
        $query = $this->db->query($sql);		
        if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	function savesection()
	{	
	$webpage_data = array(
			'class_id'=>$this->input->post('class_id'),			
			'section_name'=>$this->input->post('section_name'),
			'max_no_student'=>$this->input->post('max_no_student'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('section',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function updatesection()
    {			
		$website_data = array(            
			'class_id'=>$this->input->post('class_id'),			
			'section_name'=>$this->input->post('section_name'),
			'max_no_student'=>$this->input->post('max_no_student'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('section_id', $this->input->post('section_id'));
		$success = $this->db->update('section',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendsection($section_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('section_id', $section_id);
		$success = $this->db->update('section',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivesection($section_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('section_id', $section_id);
		$success = $this->db->update('section',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	
	/* Evaluation->class management(Subject) */	
	function getclasssubject()
	{
		$this->db->from('class');
		$this->db->where('status','1');
		$result = $this->db->get();
		return $result->result_array();		
	}
    function getsubject()
	{
		$sql = "SELECT s.*, c.class_name as classname FROM subject s INNER JOIN class c on s.class_id = c.class_id where s.status = 1 ORDER BY modified_date desc";
	    $result = $this->db->query($sql);
		return $result->result_array();	
	}
	function trashsubject()
	{
		$sql = "SELECT s.*, c.class_name as classname FROM subject s INNER JOIN class c on s.class_id = c.class_id where s.status = 0 ORDER BY modified_date desc";
	    $result = $this->db->query($sql);
		return $result->result_array();		
	}
	function getsubjectbyid($subject_id)
	{
		$sql = "SELECT s.*, c.class_name as classname FROM subject s INNER JOIN class c on s.class_id = c.class_id  where s.subject_id = '$subject_id'";
        $query = $this->db->query($sql);		
        if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	function savesubject()
	{	
	$webpage_data = array(
			'class_id'=>$this->input->post('class_id'),			
			'subject_name'=>$this->input->post('subject_name'),
			'subject_code'=>$this->input->post('subject_code'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('subject',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function updatesubject()
    {			
		$website_data = array(            
			'class_id'=>$this->input->post('class_id'),			
			'subject_name'=>$this->input->post('subject_name'),
			'subject_code'=>$this->input->post('subject_code'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('subject_id', $this->input->post('subject_id'));
		$success = $this->db->update('subject',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendsubject($subject_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('subject_id', $subject_id);
		$success = $this->db->update('subject',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivesubject($subject_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('subject_id', $subject_id);
		$success = $this->db->update('subject',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	
	/* Evaluation->class management(Syllabus) */	
	function getclasssyllabus()
	{
		$this->db->from('class');
		$this->db->where('status','1');
		$result = $this->db->get();
		return $result->result_array();		
	}
	/*function getsubjectsyllabus()
	{
		$this->db->from('subject');
		$this->db->where('status','1');
		$result = $this->db->get();
		return $result->result_array();		
	}*/
	
	function getsubcategorydetails($class_id='')
     {
	    $this->db->from('subject');
		$this->db->where('class_id',$class_id);
		$result = $this->db->get();
		return $result->result_array();
    }
    function getsyllabus()
	{
		$sql = "SELECT sb.*, c.class_name as classname, s.subject_name as subjectname FROM syllabus sb INNER JOIN class c on sb.class_id = c.class_id INNER JOIN subject s on sb.subject_id = s.subject_id where sb.status = 1 ORDER BY modified_date desc";
	    $result = $this->db->query($sql);
		return $result->result_array();	
	}
	function trashsyllabus()
	{
		$sql = "SELECT sb.*, c.class_name as classname, s.subject_name as subjectname FROM syllabus sb INNER JOIN class c on sb.class_id = c.class_id INNER JOIN subject s on sb.subject_id = s.subject_id where sb.status = 0 ORDER BY modified_date desc";
	    $result = $this->db->query($sql);
		return $result->result_array();		
	}
	function getsyllabusbyid($syllabus_id)
	{
		$sql = "SELECT sb.*, c.class_name as classname, s.subject_name as subjectname FROM syllabus sb INNER JOIN class c on sb.class_id = c.class_id INNER JOIN subject s on sb.subject_id = s.subject_id where sb.syllabus_id = '$syllabus_id'";
        $query = $this->db->query($sql);		
        if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	function savesyllabus($doc_data)
	{	
	$webpage_data = array(
	        'syllabus_pdf'=>'upload/syllabus/'.$doc_data['syllabus_pdf'], 
			'class_id'=>$this->input->post('class_id'),
			'subject_id'=>$this->input->post('subject_id'),            			
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('syllabus',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function updatesyllabus($doc_data)
    {			
		$website_data = array(
			'syllabus_pdf'=>'upload/syllabus/'.$doc_data['syllabus_pdf'], 
			'class_id'=>$this->input->post('class_id'),
			'subject_id'=>$this->input->post('subject_id'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('syllabus_id', $this->input->post('syllabus_id'));
		unlink($this->input->post('previousdoc'));
		$success = $this->db->update('syllabus',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function updatesyllabuscontent()
    {			
		$website_data = array(			
			'class_id'=>$this->input->post('class_id'),
			'subject_id'=>$this->input->post('subject_id'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('syllabus_id', $this->input->post('syllabus_id'));
		$success = $this->db->update('syllabus',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendsyllabus($syllabus_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('syllabus_id', $syllabus_id);
		$success = $this->db->update('syllabus',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivesyllabus($syllabus_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('syllabus_id', $syllabus_id);
		$success = $this->db->update('syllabus',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	
	/* Evaluation->class management(Test paper) */	
	function getclasstestpaper()
	{
		$this->db->from('class');
		$this->db->where('status','1');
		$result = $this->db->get();
		return $result->result_array();		
	}
	
	function getsubcategorydetailstest($class_id='')
     {
	    $this->db->from('subject');
		$this->db->where('class_id',$class_id);
		$result = $this->db->get();
		return $result->result_array();
    }
    function gettestpaper()
	{
		$sql = "SELECT tp.*, c.class_name as classname, s.subject_name as subjectname FROM testpaper tp INNER JOIN class c on tp.class_id = c.class_id INNER JOIN subject s on tp.subject_id = s.subject_id where tp.status = 1 ORDER BY modified_date desc";
	    $result = $this->db->query($sql);
		return $result->result_array();	
	}
	function trashtestpaper()
	{
		$sql = "SELECT tp.*, c.class_name as classname, s.subject_name as subjectname FROM testpaper tp INNER JOIN class c on tp.class_id = c.class_id INNER JOIN subject s on tp.subject_id = s.subject_id where tp.status = 0 ORDER BY modified_date desc";
	    $result = $this->db->query($sql);
		return $result->result_array();		
	}
	function gettestpaperbyid($testpaper_id)
	{
		$sql = "SELECT tp.*, c.class_name as classname, s.subject_name as subjectname FROM testpaper tp INNER JOIN class c on tp.class_id = c.class_id INNER JOIN subject s on tp.subject_id = s.subject_id where tp.testpaper_id = '$testpaper_id'";
        $query = $this->db->query($sql);		
        if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	function savetestpaper($doc_data)
	{	
	$webpage_data = array(
	        'testpaper_pdf'=>'upload/testpaper/'.$doc_data['testpaper_pdf'], 
			'class_id'=>$this->input->post('class_id'),
			'subject_id'=>$this->input->post('subject_id'), 
			'session'=>$this->input->post('session'), 	
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('testpaper',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function updatetestpaper($doc_data)
    {			
		$website_data = array(
			'testpaper_pdf'=>'upload/testpaper/'.$doc_data['testpaper_pdf'], 
			'class_id'=>$this->input->post('class_id'),
			'subject_id'=>$this->input->post('subject_id'), 
			'session'=>$this->input->post('session'), 
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('testpaper_id', $this->input->post('testpaper_id'));
		unlink($this->input->post('previousdoc'));
		$success = $this->db->update('testpaper',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function updatetestpapercontent()
    {			
		$website_data = array(			
			'class_id'=>$this->input->post('class_id'),
			'subject_id'=>$this->input->post('subject_id'), 
			'session'=>$this->input->post('session'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('testpaper_id', $this->input->post('testpaper_id'));
		$success = $this->db->update('testpaper',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendtestpaper($testpaper_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('testpaper_id', $testpaper_id);
		$success = $this->db->update('testpaper',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivetestpaper($testpaper_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('testpaper_id', $testpaper_id);
		$success = $this->db->update('testpaper',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	
	/* Evaluation->class management(Question paper) */	
	function getclassquestionpaper()
	{
		$this->db->from('class');
		$this->db->where('status','1');
		$result = $this->db->get();
		return $result->result_array();		
	}
	
	function getsubcategorydetailsquestion($class_id='')
     {
	    $this->db->from('subject');
		$this->db->where('class_id',$class_id);
		$result = $this->db->get();
		return $result->result_array();
    }
    function getquestionpaper()
	{
		$sql = "SELECT qp.*, c.class_name as classname, s.subject_name as subjectname FROM questionpaper qp INNER JOIN class c on qp.class_id = c.class_id INNER JOIN subject s on qp.subject_id = s.subject_id where qp.status = 1 ORDER BY modified_date desc";
	    $result = $this->db->query($sql);
		return $result->result_array();	
	}
	function trashquestionpaper()
	{
		$sql = "SELECT qp.*, c.class_name as classname, s.subject_name as subjectname FROM questionpaper qp INNER JOIN class c on qp.class_id = c.class_id INNER JOIN subject s on qp.subject_id = s.subject_id where qp.status = 0 ORDER BY modified_date desc";
	    $result = $this->db->query($sql);
		return $result->result_array();		
	}
	function getquestionpaperbyid($questionpaper_id)
	{
		$sql = "SELECT qp.*, c.class_name as classname, s.subject_name as subjectname FROM questionpaper qp INNER JOIN class c on qp.class_id = c.class_id INNER JOIN subject s on qp.subject_id = s.subject_id where qp.questionpaper_id = '$questionpaper_id'";
        $query = $this->db->query($sql);		
        if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	function savequestionpaper($doc_data)
	{	
	$webpage_data = array(
	        'questionpaper_pdf'=>'upload/questionpaper/'.$doc_data['questionpaper_pdf'], 
			'class_id'=>$this->input->post('class_id'),
			'subject_id'=>$this->input->post('subject_id'), 
			'session'=>$this->input->post('session'), 	
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('questionpaper',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function updatequestionpaper($doc_data)
    {			
		$website_data = array(
			'questionpaper_pdf'=>'upload/questionpaper/'.$doc_data['questionpaper_pdf'], 
			'class_id'=>$this->input->post('class_id'),
			'subject_id'=>$this->input->post('subject_id'), 
			'session'=>$this->input->post('session'), 
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('questionpaper_id', $this->input->post('questionpaper_id'));
		unlink($this->input->post('previousdoc'));
		$success = $this->db->update('questionpaper',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function updatequestionpapercontent()
    {			
		$website_data = array(			
			'class_id'=>$this->input->post('class_id'),
			'subject_id'=>$this->input->post('subject_id'), 
			'session'=>$this->input->post('session'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('questionpaper_id', $this->input->post('questionpaper_id'));
		$success = $this->db->update('questionpaper',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendquestionpaper($questionpaper_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('questionpaper_id', $questionpaper_id);
		$success = $this->db->update('questionpaper',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivequestionpaper($questionpaper_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('questionpaper_id', $questionpaper_id);
		$success = $this->db->update('questionpaper',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	
}