<?php
class Model_Parents extends CI_Model
{	
	/* Fees Summary */
	function getfeessummary()
	{
		$this->db->from('feessummary');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function trashfeessummary()
	{
		$this->db->from('feessummary');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getfeessummarybyid($feessummary_id)
	{
		$this->db->from('feessummary');
		$this->db->where('feessummary_id',$feessummary_id);		
		$query = $this->db->get();
		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	
	function savefeessummary()
	{	
	$webpage_data = array(
			'fee_type'=>$this->input->post('fee_type'),
			'class'=>$this->input->post('class'),
			'tution_fee'=>$this->input->post('tution_fee'),
			'miday_charge'=>$this->input->post('miday_charge'),
            'other_charge'=>$this->input->post('other_charge'),
			'bus_charge'=>$this->input->post('bus_charge'),				
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('feessummary',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	
	function updatefeessummary()
    {			
		$website_data = array(
			'fee_type'=>$this->input->post('fee_type'),
            'class'=>$this->input->post('class'),
			'tution_fee'=>$this->input->post('tution_fee'),
			'miday_charge'=>$this->input->post('miday_charge'),
            'other_charge'=>$this->input->post('other_charge'),
			'bus_charge'=>$this->input->post('bus_charge'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('feessummary_id', $this->input->post('feessummary_id'));
		$success = $this->db->update('feessummary',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendfeessummary($feessummary_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('feessummary_id', $feessummary_id);
		$success = $this->db->update('feessummary',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivefeessummary($feessummary_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('feessummary_id', $feessummary_id);
		$success = $this->db->update('feessummary',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	
	
}