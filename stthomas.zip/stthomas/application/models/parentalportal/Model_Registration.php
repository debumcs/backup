<?php
class Model_Registration extends CI_Model
{	
	/* Parent Registration */
	function getparentregistration()
	{
		$this->db->from('plcredential');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function trashparentregistration()
	{
		$this->db->from('plcredential');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getparentregistrationbyid($username)
	{
		$this->db->from('plcredential');
		$this->db->where('username',$username);		
		$query = $this->db->get();
		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	
	function saveparentregistration()
	{	
	$webpage_data = array(
			'type'=>$this->input->post('type'),
			'username'=>$this->input->post('random'),
			'student_name'=>$this->input->post('student_name'),
			'current_class'=>$this->input->post('current_class'),
            'admission_year'=>$this->input->post('admission_year'),
			'admission_class'=>$this->input->post('admission_class'),
			'parent_name'=>$this->input->post('parent_name'),
			'mother_name'=>$this->input->post('mother_name'),
			'email'=>$this->input->post('email'),
			'phone'=>$this->input->post('phone'),
			'password'=>$this->input->post('password'),	
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('plcredential',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function saveregistration()
	{	
	$webpage_data = array(
			'type'=>$this->input->post('type'),
			'username'=>$this->input->post('random'),
			'password'=>$this->input->post('password'),            
		);       		
		$success = $this->db->insert('portallogin',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	
	function updateparentregistration()
    {			
		$website_data = array(
		    'type'=>$this->input->post('type'),
			'username'=>$this->input->post('username'),
            'student_name'=>$this->input->post('student_name'),
			'current_class'=>$this->input->post('current_class'),
            'admission_year'=>$this->input->post('admission_year'),
			'admission_class'=>$this->input->post('admission_class'),
			'parent_name'=>$this->input->post('parent_name'),
			'mother_name'=>$this->input->post('mother_name'),
			'email'=>$this->input->post('email'),
			'phone'=>$this->input->post('phone'),
			'password'=>$this->input->post('password'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('username', $this->input->post('username'));
		$success = $this->db->update('plcredential',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function updateparentregistrationlogin()
    {			
		$website_data = array(
		    'type'=>$this->input->post('type'),
			'username'=>$this->input->post('username'),
			'password'=>$this->input->post('password')			
		);
		$this->db->where('username', $this->input->post('username'));
		$success = $this->db->update('portallogin',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	
	function suspendparentregistration($username)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('username', $username);
		$success = $this->db->update('plcredential',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function suspendparentregistrationlogin($username)
    {			
		$website_data = array(
			'status'=>'0'			
		);
		$this->db->where('username', $username);
		$success = $this->db->update('portallogin',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactiveparentregistration($username)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('username', $username);
		$success = $this->db->update('plcredential',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactiveparentregistrationlogin($username)
    {			
		$website_data = array(
			'status'=>'1'			
		);
		$this->db->where('username', $username);
		$success = $this->db->update('portallogin',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	/* Teacher Registration */
	function getteacherregistration()
	{
		$this->db->from('teacherregistration');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function trashteacherregistration()
	{
		$this->db->from('teacherregistration');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getteacherregistrationbyid($username)
	{
		$this->db->from('teacherregistration');
		$this->db->where('username',$username);		
		$query = $this->db->get();
		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	
	function saveteacherregistration()
	{	
	$webpage_data = array(
			'type'=>$this->input->post('type'),
			'username'=>$this->input->post('random'),
			'teacher_name'=>$this->input->post('teacher_name'),
			'father_name'=>$this->input->post('father_name'),
            'join_year'=>$this->input->post('join_year'),
			'qualification'=>$this->input->post('qualification'),			
			'email'=>$this->input->post('email'),
			'phone'=>$this->input->post('phone'),
			'password'=>$this->input->post('password'),	
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('teacherregistration',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	
	function updateteacherregistration()
    {			
		$website_data = array(
		    'type'=>$this->input->post('type'),
			'username'=>$this->input->post('username'),
            'teacher_name'=>$this->input->post('teacher_name'),	
			'father_name'=>$this->input->post('father_name'),	
			'join_year'=>$this->input->post('join_year'),
			'qualification'=>$this->input->post('qualification'),	
			'email'=>$this->input->post('email'),
			'phone'=>$this->input->post('phone'),
			'password'=>$this->input->post('password'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('username', $this->input->post('username'));
		$success = $this->db->update('teacherregistration',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function updateteacherregistrationlogin()
    {			
		$website_data = array(
		    'type'=>$this->input->post('type'),
			'username'=>$this->input->post('username'),
			'password'=>$this->input->post('password')
			
		);
		$this->db->where('username', $this->input->post('username'));
		$success = $this->db->update('portallogin',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	
	function suspendteacherregistration($username)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('username', $username);
		$success = $this->db->update('teacherregistration',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function suspendteacherregistrationlogin($username)
    {			
		$website_data = array(
			'status'=>'0'			
		);
		$this->db->where('username', $username);
		$success = $this->db->update('portallogin',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactiveteacherregistration($username)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('username', $username);
		$success = $this->db->update('teacherregistration',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactiveteacherregistrationlogin($username)
    {			
		$website_data = array(
			'status'=>'1',			
		);
		$this->db->where('username', $username);
		$success = $this->db->update('portallogin',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	
}