<?php
class Model_Transport extends CI_Model
{	
    //Route
	function getroute()
	{
		$this->db->from('route');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function trashroute()
	{
		$this->db->from('route');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getroutebyid($route_id)
	{
		$this->db->from('route');
		$this->db->where('route_id',$route_id);		
		$query = $this->db->get();
		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	function saveroute()
	{	
	$webpage_data = array(	         
			'name'=>$this->input->post('name'),
			'description'=>$this->input->post('description'),
			'amount'=>$this->input->post('amount'),			
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('route',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function updateroute()
    {			
		$website_data = array(
            'name'=>$this->input->post('name'),
			'description'=>$this->input->post('description'),
			'amount'=>$this->input->post('amount'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('route_id', $this->input->post('route_id'));
		$success = $this->db->update('route',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendroute($route_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('route_id', $route_id);
		$success = $this->db->update('route',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactiveroute($route_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('route_id', $route_id);
		$success = $this->db->update('route',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	//Transport Driver
	function gettransportdriver()
	{
		$this->db->from('transportdriver');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function gettransportdriverbus()
	{
		$this->db->from('transportdriver');
		$this->db->where('status','1');		
		$result = $this->db->get();
		return $result->result_array();		
	}
	function trashtransportdriver()
	{
		$this->db->from('transportdriver');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function gettransportdriverbyid($transportdriver_id)
	{
		$this->db->from('transportdriver');
		$this->db->where('transportdriver_id',$transportdriver_id);		
		$query = $this->db->get();
		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	function savetransportdriver()
	{	
	$webpage_data = array(	         
			'name'=>$this->input->post('name'),
			'dl_number'=>$this->input->post('dl_number'),
			'dateofjoining'=>$this->input->post('dateofjoining'),	
			'mobileno'=>$this->input->post('mobileno'),	
			'qualification'=>$this->input->post('qualification'),
			'presentaddress'=>$this->input->post('presentaddress'),	
			'permanentaddress'=>$this->input->post('permanentaddress'),			
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('transportdriver',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function updatetransportdriver()
    {			
		$website_data = array(
            'name'=>$this->input->post('name'),
			'dl_number'=>$this->input->post('dl_number'),
			'dateofjoining'=>$this->input->post('dateofjoining'),	
			'mobileno'=>$this->input->post('mobileno'),	
			'qualification'=>$this->input->post('qualification'),
			'presentaddress'=>$this->input->post('presentaddress'),	
			'permanentaddress'=>$this->input->post('permanentaddress'),	
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('transportdriver_id', $this->input->post('transportdriver_id'));
		$success = $this->db->update('transportdriver',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendtransportdriver($transportdriver_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('transportdriver_id', $transportdriver_id);
		$success = $this->db->update('transportdriver',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivetransportdriver($transportdriver_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('transportdriver_id', $transportdriver_id);
		$success = $this->db->update('transportdriver',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	//Transport Conductor
	function gettransportconductor()
	{
		$this->db->from('transportconductor');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function gettransportconductorbus()
	{
		$this->db->from('transportconductor');
		$this->db->where('status','1');
		$result = $this->db->get();
		return $result->result_array();		
	}
	function trashtransportconductor()
	{
		$this->db->from('transportconductor');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function gettransportconductorbyid($transportconductor_id)
	{
		$this->db->from('transportconductor');
		$this->db->where('transportconductor_id',$transportconductor_id);		
		$query = $this->db->get();
		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	function savetransportconductor()
	{	
	$webpage_data = array(	         
			'name'=>$this->input->post('name'),			
			'dateofjoining'=>$this->input->post('dateofjoining'),	
			'mobileno'=>$this->input->post('mobileno'),	
			'qualification'=>$this->input->post('qualification'),
			'presentaddress'=>$this->input->post('presentaddress'),	
			'permanentaddress'=>$this->input->post('permanentaddress'),			
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('transportconductor',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function updatetransportconductor()
    {			
		$website_data = array(
            'name'=>$this->input->post('name'),			
			'dateofjoining'=>$this->input->post('dateofjoining'),	
			'mobileno'=>$this->input->post('mobileno'),	
			'qualification'=>$this->input->post('qualification'),
			'presentaddress'=>$this->input->post('presentaddress'),	
			'permanentaddress'=>$this->input->post('permanentaddress'),	
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('transportconductor_id', $this->input->post('transportconductor_id'));
		$success = $this->db->update('transportconductor',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendtransportconductor($transportconductor_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('transportconductor_id', $transportconductor_id);
		$success = $this->db->update('transportconductor',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivetransportconductor($transportconductor_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('transportconductor_id', $transportconductor_id);
		$success = $this->db->update('transportconductor',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	/* Transport Bus */	
	function getbus()
	{
	$sql = "SELECT b.*, d.name as drivername, c.name as conductorname FROM bus b INNER JOIN transportdriver d on b.driver_id = d.transportdriver_id INNER JOIN transportconductor c on b.conductor_id = c.transportconductor_id  where b.status = 1 ORDER BY modified_date desc";
	    $result = $this->db->query($sql);
		return $result->result_array();	
	}
	function trashbus()
	{
		$sql = "SELECT b.*, d.name as drivername, c.name as conductorname FROM bus b INNER JOIN transportdriver d on b.driver_id = d.transportdriver_id INNER JOIN transportconductor c on b.conductor_id = c.transportconductor_id  where b.status = 0 ORDER BY modified_date desc";
	    $result = $this->db->query($sql);
		return $result->result_array();
	}
	function getbusbyid($bus_id)
	{		
		$sql = "SELECT b.*, d.name as drivername, c.name as conductorname FROM bus b inner join transportdriver d on b.driver_id = d.transportdriver_id inner join transportconductor c on b.conductor_id = c.transportconductor_id  where b.bus_id = '$bus_id'";
        $query = $this->db->query($sql);		
        if($query->num_rows()==1)
		{
			return $query->row_array();
		}
		
	}
	
	function savebus()
	{	
	$webpage_data = array(	        
			
			'bus_number'=>$this->input->post('bus_number'),            
			'driver_id'=>$this->input->post('driver_id'),			
			'conductor_id'=>$this->input->post('conductor_id'),					
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('bus',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	
	function updatebus()
    {			
		$website_data = array(            
			'bus_number'=>$this->input->post('bus_number'),            
			'driver_id'=>$this->input->post('driver_id'),			
			'conductor_id'=>$this->input->post('conductor_id'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('bus_id', $this->input->post('bus_id'));
		$success = $this->db->update('bus',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendbus($bus_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('bus_id', $bus_id);
		$success = $this->db->update('bus',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivebus($bus_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('bus_id', $bus_id);
		$success = $this->db->update('bus',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	
	
}