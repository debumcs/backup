<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modellogin extends CI_Model {
	function __construct()  
      {          
         parent::__construct();  
      }  

	public function getlogin()
	{	        
		$query = $this->db->get('login');
		return $query;
		/*if($query->num_rows > 0)
		{
			return $query->result();
		}
		else
		{
			return false;
		}*/
	}
}
?>