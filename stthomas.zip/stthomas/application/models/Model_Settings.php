<?php
class Model_Settings extends CI_Model
{
	function update_password(){
		$this->db->from('login');
		$this->db->where('password',md5($this->input->post('pre_password')));		
		$query = $this->db->get();
		$username = '';
		if($query->num_rows()==1)
		{
			$pre_password = $query->row();
			$username = $pre_password->username;
		}
		
		if($username === 'admin'){
			if($this->input->post('new_password')===$this->input->post('con_password')){
				$website_data = array(
					'password'=>md5($this->input->post('new_password'))
				);
				$this->db->where('uid', 'dad795e5-4b33-11e3-8c00-90590c30cc70');
				$success = $this->db->update('login',$website_data);
				
				if($success)
				{
					$message =  '<b>Password Changed Successfully!</b>';
					$this->session->set_flashdata('MESSAGE', $message);
				}
				else{
					$message =  '<b>Error while updating password!</b>';
					$this->session->set_flashdata('MESSAGE', $message);
				}
			}else{
				$message =  '<b>Confirm Password does not match!</b>';
				$this->session->set_flashdata('MESSAGE', $message);
			}
		}
		else{
			$message =  '<b>Wrong Previous Password entered!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
		}
	}
}
?>
