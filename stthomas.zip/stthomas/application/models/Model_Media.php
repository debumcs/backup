<?php
class Model_Media extends CI_Model
{
	/* press release */
	function getpressrelease()
	{
		$this->db->from('pressrelease');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getpressreleasefront()
	{
		$this->db->from('pressrelease');
		$this->db->where('status','1');
		$this->db->order_by("sort_order", "asc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function trashpressrelease()
	{
		$this->db->from('pressrelease');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getpressreleasebyid($pressrelease_id)
	{
		$this->db->from('pressrelease');
		$this->db->where('pressrelease_id',$pressrelease_id);		
		$query = $this->db->get();
		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	
	function savepressrelease()
	{	
	$webpage_data = array(	        
			'title'=>$this->input->post('title'),
			'content'=>$this->input->post('content'),
			'sort_order'=>$this->input->post('sort_order'),	
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('pressrelease',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	
	function updatepressrelease()
    {			
		$website_data = array(			
			'title'=>$this->input->post('title'),
			'content'=>$this->input->post('content'),
			'sort_order'=>$this->input->post('sort_order'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('pressrelease_id', $this->input->post('pressrelease_id'));
		$success = $this->db->update('pressrelease',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendpressrelease($pressrelease_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('pressrelease_id', $pressrelease_id);
		$success = $this->db->update('pressrelease',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivepressrelease($pressrelease_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('pressrelease_id', $pressrelease_id);
		$success = $this->db->update('pressrelease',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	/* latest happenings */
	function getlatesthappenings()
	{
		$this->db->from('latesthappenings');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getlatesthappeningsfront()
	{
		$this->db->from('latesthappenings');
		$this->db->where('status','1');
		$this->db->order_by("sort_order", "asc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function trashlatesthappenings()
	{
		$this->db->from('latesthappenings');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getlatesthappeningsbyid($latesthappenings_id)
	{
		$this->db->from('latesthappenings');
		$this->db->where('latesthappenings_id',$latesthappenings_id);		
		$query = $this->db->get();
		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	
	function savelatesthappenings()
	{	
	$webpage_data = array(	        
			'title'=>$this->input->post('title'),
			'content'=>$this->input->post('content'),
			'sort_order'=>$this->input->post('sort_order'),	
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('latesthappenings',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	
	function updatelatesthappenings()
    {			
		$website_data = array(			
			'title'=>$this->input->post('title'),
			'content'=>$this->input->post('content'),
			'sort_order'=>$this->input->post('sort_order'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('latesthappenings_id', $this->input->post('latesthappenings_id'));
		$success = $this->db->update('latesthappenings',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendlatesthappenings($latesthappenings_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('latesthappenings_id', $latesthappenings_id);
		$success = $this->db->update('latesthappenings',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivelatesthappenings($latesthappenings_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('latesthappenings_id', $latesthappenings_id);
		$success = $this->db->update('latesthappenings',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	/* photo gallery */
	function getphotogallery()
	{
		$this->db->from('photogallery');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getphotogalleryfront()
	{
		$this->db->from('photogallery');
		$this->db->where('status','1');
		$this->db->order_by("sort_order", "asc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function trashphotogallery()
	{
		$this->db->from('photogallery');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getphotogallerybyid($photogallery_id)
	{
		$this->db->from('photogallery');
		$this->db->where('photogallery_id',$photogallery_id);		
		$query = $this->db->get();
		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	
	function save($image_data)
	{	
	$webpage_data = array(
	        'image'=>'upload/photogallery/'.$image_data['image'], 
			'title'=>$this->input->post('title'),
			'sort_order'=>$this->input->post('sort_order'),	
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('photogallery',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function update($image_data)
    {			
		$website_data = array(
			'image'=>'upload/photogallery/'.$image_data['image'], 
			'title'=>$this->input->post('title'),
			'sort_order'=>$this->input->post('sort_order'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('photogallery_id', $this->input->post('photogallery_id'));
		unlink($this->input->post('previousimage'));
		$success = $this->db->update('photogallery',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function updatecontent()
    {			
		$website_data = array(			
			'title'=>$this->input->post('title'),
			'sort_order'=>$this->input->post('sort_order'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('photogallery_id', $this->input->post('photogallery_id'));
		$success = $this->db->update('photogallery',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspend($photogallery_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('photogallery_id', $photogallery_id);
		$success = $this->db->update('photogallery',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactive($photogallery_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('photogallery_id', $photogallery_id);
		$success = $this->db->update('photogallery',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	/* video gallery */
	function getvideogallery()
	{
		$this->db->from('videogallery');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getvideogalleryfront()
	{
		$this->db->from('videogallery');
		$this->db->where('status','1');
		$this->db->order_by("sort_order", "asc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function trashvideogallery()
	{
		$this->db->from('videogallery');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getvideogallerybyid($videogallery_id)
	{
		$this->db->from('videogallery');
		$this->db->where('videogallery_id',$videogallery_id);		
		$query = $this->db->get();
		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	
	function savevideogallery()
	{	
	$webpage_data = array(	        
			'url'=>$this->input->post('url'),
			'sort_order'=>$this->input->post('sort_order'),	
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('videogallery',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	
	function updatevideogallery()
    {			
		$website_data = array(			
			'url'=>$this->input->post('url'),
			'sort_order'=>$this->input->post('sort_order'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('videogallery_id', $this->input->post('videogallery_id'));
		$success = $this->db->update('videogallery',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendvideogallery($videogallery_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('videogallery_id', $videogallery_id);
		$success = $this->db->update('videogallery',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivevideogallery($videogallery_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('videogallery_id', $videogallery_id);
		$success = $this->db->update('videogallery',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
}