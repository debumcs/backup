<?php
class Model_Beyondclassroom extends CI_Model
{	
	/* Sports */
	function get_sports()
	{
		$this->db->from('sports');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_sports()
    {	
        $this->db->from('sports');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('sports',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
		   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('sports',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    }
	/* Arts & Culture */
	function get_artculture()
	{
		$this->db->from('artculture');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_artculture()
    {	
        $this->db->from('artculture');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('artculture',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
		   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('artculture',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    }
	/* Library */
	function get_library()
	{
		$this->db->from('library');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_library()
    {	
        $this->db->from('library');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('library',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
		   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('library',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    }
	
	
}