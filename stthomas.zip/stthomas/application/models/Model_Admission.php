<?php
class Model_Admission extends CI_Model
{		
	// Admission Criteria
    function get_admissioncriteria()
	{
		$this->db->from('admissioncriteria');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_admissioncriteria()
    {	
        $this->db->from('admissioncriteria');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('admissioncriteria',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
		   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('admissioncriteria',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    }
	// Admission Fees
    function get_admissionfees()
	{
		$this->db->from('admissionfees');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_admissionfees()
    {	
        $this->db->from('admissionfees');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('admissionfees',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
		   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('admissionfees',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    }	
    
   
}
?>
