<?php
class Model_Learning extends CI_Model
{	
	/* Learning */
	function getlearning()
	{
		$this->db->from('learning');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getlearningfront()
	{
		$this->db->from('learning');
		$this->db->where('status','1');
		$this->db->order_by("sort_order", "asc");
		$result = $this->db->get();
		return $result->result_array();		
	}	
	function trashlearning()
	{
		$this->db->from('learning');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getlearningbyid($learning_id)
	{
		$this->db->from('learning');
		$this->db->where('learning_id',$learning_id);		
		$query = $this->db->get();
		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	
	function savelearning($image_data)
	{	
	$webpage_data = array(
	        'image'=>'upload/learning/'.$image_data['image'], 
			'category'=>$this->input->post('category'),
			'title'=>$this->input->post('title'),
            'content'=>$this->input->post('content'),
            'sort_order'=>$this->input->post('sort_order'),			
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('learning',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function updatelearning($image_data)
    {			
		$website_data = array(
			'image'=>'upload/learning/'.$image_data['image'],
			'category'=>$this->input->post('category'),	
			'title'=>$this->input->post('title'),
			'content'=>$this->input->post('content'),
			'sort_order'=>$this->input->post('sort_order'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('learning_id', $this->input->post('learning_id'));
		unlink($this->input->post('previousimage'));
		$success = $this->db->update('learning',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function updatecontentlearning()
    {			
		$website_data = array(
            'category'=>$this->input->post('category'),		
			'title'=>$this->input->post('title'),
			'content'=>$this->input->post('content'),
			'sort_order'=>$this->input->post('sort_order'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('learning_id', $this->input->post('learning_id'));
		$success = $this->db->update('learning',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendlearning($learning_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('learning_id', $learning_id);
		$success = $this->db->update('learning',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivelearning($learning_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('learning_id', $learning_id);
		$success = $this->db->update('learning',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	
	
}