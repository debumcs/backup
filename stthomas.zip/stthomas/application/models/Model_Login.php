<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Model_Login extends CI_Model {
	/*
	Attempts to login employee and set session. Returns boolean based on outcome.
	*/
	function login($username, $password)
	{
		$query = $this->db->get_where('login', array('username' => $username,'password'=>md5($password)), 1);
		if ($query->num_rows() ==1)
		{
			$row=$query->row();
			$this->session->set_userdata('uid', $row->uid);
			$this->session->set_userdata('username', $row->username);
			return true;
		}
		return false;
	}
	/*
	Logs out a user by destorying all session data and redirect to login
	*/
	function logout()
	{
		$this->session->sess_destroy();
		redirect('login');
	}
	/*
	Determins if a employee is logged in
	*/
	function is_logged_in()
	{
		return $this->session->userdata('uid')!=false;
	}
	
}
?>