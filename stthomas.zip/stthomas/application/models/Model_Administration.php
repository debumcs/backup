<?php
class Model_Administration extends CI_Model
{	
	/* Current Administration */
	function getcurrentadministration()
	{
		$this->db->from('currentadministration');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getcurrentadministrationfrontend()
	{
		$this->db->from('currentadministration');
		$this->db->where('status','1');
		$this->db->order_by("sort_order", "asc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function trashcurrentadministration()
	{
		$this->db->from('currentadministration');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getcurrentadministrationbyid($currentadministration_id)
	{
		$this->db->from('currentadministration');
		$this->db->where('currentadministration_id',$currentadministration_id);		
		$query = $this->db->get();
		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	
	function savecurrentadministration($image_data)
	{	
	$webpage_data = array(
	        'image'=>'upload/currentadministration/'.$image_data['image'], 
			'title'=>$this->input->post('title'),
			'content'=>$this->input->post('content'),
            'sort_order'=>$this->input->post('sort_order'),			
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('currentadministration',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function updatecurrentadministration($image_data)
    {			
		$website_data = array(
			'image'=>'upload/currentadministration/'.$image_data['image'], 
			'title'=>$this->input->post('title'),
			'content'=>$this->input->post('content'),
			'sort_order'=>$this->input->post('sort_order'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('currentadministration_id', $this->input->post('currentadministration_id'));
		unlink($this->input->post('previousimage'));
		$success = $this->db->update('currentadministration',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function updatecontentcurrentadministration()
    {			
		$website_data = array(			
			'title'=>$this->input->post('title'),
			'content'=>$this->input->post('content'),
			'sort_order'=>$this->input->post('sort_order'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('currentadministration_id', $this->input->post('currentadministration_id'));
		$success = $this->db->update('currentadministration',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendcurrentadministration($currentadministration_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('currentadministration_id', $currentadministration_id);
		$success = $this->db->update('currentadministration',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivecurrentadministration($currentadministration_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('currentadministration_id', $currentadministration_id);
		$success = $this->db->update('currentadministration',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
    /* Current Staff */
	function getcurrentstaff()
	{
		$this->db->from('currentstaff');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getcurrentstafffront()
	{
		$this->db->from('currentstaff');
		$this->db->where('status','1');
		$this->db->order_by("sort_order", "asc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function trashcurrentstaff()
	{
		$this->db->from('currentstaff');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getcurrentstaffbyid($currentstaff_id)
	{
		$this->db->from('currentstaff');
		$this->db->where('currentstaff_id',$currentstaff_id);		
		$query = $this->db->get();
		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	
	function savecurrentstaff($image_data)
	{	
	$webpage_data = array(
	        'image'=>'upload/currentstaff/'.$image_data['image'], 
			'title'=>$this->input->post('title'),
			'content'=>$this->input->post('content'),
            'sort_order'=>$this->input->post('sort_order'),			
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('currentstaff',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function updatecurrentstaff($image_data)
    {			
		$website_data = array(
			'image'=>'upload/currentstaff/'.$image_data['image'], 
			'title'=>$this->input->post('title'),
			'content'=>$this->input->post('content'),
			'sort_order'=>$this->input->post('sort_order'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('currentstaff_id', $this->input->post('currentstaff_id'));
		unlink($this->input->post('previousimage'));
		$success = $this->db->update('currentstaff',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function updatecontentcurrentstaff()
    {			
		$website_data = array(			
			'title'=>$this->input->post('title'),
			'content'=>$this->input->post('content'),
			'sort_order'=>$this->input->post('sort_order'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('currentstaff_id', $this->input->post('currentstaff_id'));
		$success = $this->db->update('currentstaff',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendcurrentstaff($currentstaff_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('currentstaff_id', $currentstaff_id);
		$success = $this->db->update('currentstaff',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivecurrentstaff($currentstaff_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('currentstaff_id', $currentstaff_id);
		$success = $this->db->update('currentstaff',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
    /* Student Council */
	function getstudentcouncil()
	{
		$this->db->from('studentcouncil');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getstudentcouncilfront()
	{
		$this->db->from('studentcouncil');
		$this->db->where('status','1');
		$this->db->order_by("sort_order", "asc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function trashstudentcouncil()
	{
		$this->db->from('studentcouncil');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getstudentcouncilbyid($studentcouncil_id)
	{
		$this->db->from('studentcouncil');
		$this->db->where('studentcouncil_id',$studentcouncil_id);		
		$query = $this->db->get();
		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	
	function savestudentcouncil($image_data)
	{	
	$webpage_data = array(
	        'image'=>'upload/studentcouncil/'.$image_data['image'], 
			'title'=>$this->input->post('title'),
			'content'=>$this->input->post('content'),
			'sort_order'=>$this->input->post('sort_order'),	
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('studentcouncil',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function updatestudentcouncil($image_data)
    {			
		$website_data = array(
			'image'=>'upload/studentcouncil/'.$image_data['image'], 
			'title'=>$this->input->post('title'),
			'content'=>$this->input->post('content'),
			'sort_order'=>$this->input->post('sort_order'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('studentcouncil_id', $this->input->post('studentcouncil_id'));
		unlink($this->input->post('previousimage'));
		$success = $this->db->update('studentcouncil',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function updatecontentstudentcouncil()
    {			
		$website_data = array(			
			'title'=>$this->input->post('title'),
			'content'=>$this->input->post('content'),
			'sort_order'=>$this->input->post('sort_order'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('studentcouncil_id', $this->input->post('studentcouncil_id'));
		$success = $this->db->update('studentcouncil',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendstudentcouncil($studentcouncil_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('studentcouncil_id', $studentcouncil_id);
		$success = $this->db->update('studentcouncil',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivestudentcouncil($studentcouncil_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('studentcouncil_id', $studentcouncil_id);
		$success = $this->db->update('studentcouncil',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
     /* Collaborators */
	function getcollaborators()
	{
		$this->db->from('collaborators');
		$this->db->where('status','1');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getcollaboratorsfront()
	{
		$this->db->from('collaborators');
		$this->db->where('status','1');
		$this->db->order_by("sort_order", "asc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function trashcollaborators()
	{
		$this->db->from('collaborators');
		$this->db->where('status','0');
		$this->db->order_by("modified_date", "desc");
		$result = $this->db->get();
		return $result->result_array();		
	}
	function getcollaboratorsbyid($collaborators_id)
	{
		$this->db->from('collaborators');
		$this->db->where('collaborators_id',$collaborators_id);		
		$query = $this->db->get();
		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}		
	}
	
	function savecollaborators($image_data)
	{	
	$webpage_data = array(
	        'image'=>'upload/collaborators/'.$image_data['image'], 
			'title'=>$this->input->post('title'),
			'content'=>$this->input->post('content'),
			'sort_order'=>$this->input->post('sort_order'),	
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);       		
		$success = $this->db->insert('collaborators',$webpage_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
	}
	function updatecollaborators($image_data)
    {			
		$website_data = array(
			'image'=>'upload/collaborators/'.$image_data['image'], 
			'title'=>$this->input->post('title'),
			'content'=>$this->input->post('content'),
			'sort_order'=>$this->input->post('sort_order'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('collaborators_id', $this->input->post('collaborators_id'));
		unlink($this->input->post('previousimage'));
		$success = $this->db->update('collaborators',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function updatecontentcollaborators()
    {			
		$website_data = array(			
			'title'=>$this->input->post('title'),
			'content'=>$this->input->post('content'),
			'sort_order'=>$this->input->post('sort_order'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('collaborators_id', $this->input->post('collaborators_id'));
		$success = $this->db->update('collaborators',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}		
    }
	function suspendcollaborators($collaborators_id)
    {			
		$website_data = array(
			'status'=>'0',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('collaborators_id', $collaborators_id);
		$success = $this->db->update('collaborators',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }
	function reactivecollaborators($collaborators_id)
    {			
		$website_data = array(
			'status'=>'1',
			'modified_date'=>date('Y-m-d H:i:s')
		);
		$this->db->where('collaborators_id', $collaborators_id);
		$success = $this->db->update('collaborators',$website_data);		
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
    }	
}