<?php
class Model_Rules extends CI_Model
{		
	// Dis and rules
    function get_disandrules()
	{
		$this->db->from('disandrules');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_disandrules()
    {	
        $this->db->from('disandrules');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('disandrules',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
		   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('disandrules',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    }
    //  Rules Concerning
    function get_rulesconcerning()
	{
		$this->db->from('rulesconcerning');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_rulesconcerning()
    {	
        $this->db->from('rulesconcerning');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('rulesconcerning',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
		   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('rulesconcerning',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    }
     //  General Rules
    function get_generalrules()
	{
		$this->db->from('generalrules');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_generalrules()
    {	
        $this->db->from('generalrules');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('generalrules',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
		   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('generalrules',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    } 
    //  Library Rules
    function get_libraryrules()
	{
		$this->db->from('libraryrules');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_libraryrules()
    {	
        $this->db->from('libraryrules');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('libraryrules',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
		   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('libraryrules',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    } 
     //  Payment of fees Rules
    function get_feesrules()
	{
		$this->db->from('feesrules');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_feesrules()
    {	
        $this->db->from('feesrules');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('feesrules',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
		   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('feesrules',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    } 
     //  Parents Instructions
    function get_parentsinstructions()
	{
		$this->db->from('parentsinstructions');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_parentsinstructions()
    {	
        $this->db->from('parentsinstructions');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('parentsinstructions',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
		   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('parentsinstructions',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    } 
     //  Assessment & Promotion Criteria
    function get_assessmentcriteria()
	{
		$this->db->from('assessmentcriteria');		
        $this->db->where('status','1');		
		$query = $this->db->get();		
		if($query->num_rows()==1)
		{
			return $query->row_array();
		}        		
	}	
	function update_assessmentcriteria()
    {	
        $this->db->from('assessmentcriteria');		
		$this->db->where('status','1');		
		$query = $this->db->get();
		$rowcount = $query->num_rows();		
        if($rowcount<=0)
		{ 	 	
		$website_data = array(		    
			'content'=>$this->input->post('content'),
			'entry_date'=>date('Y-m-d H:i:s'),
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);		
		$success = $this->db->insert('assessmentcriteria',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
		}
       else{
		   $website_data = array(		    
			'content'=>$this->input->post('content'),			
			'modified_date'=>date('Y-m-d H:i:s'),
			'ip_address' => $this->input->ip_address()
		);
		$this->db->where('status', '1' );
		$success = $this->db->update('assessmentcriteria',$website_data);
		if($success)
		{
		  	return true;
		}
		else{
			return false;
		}
       }		   
    } 	
	
}
?>
