<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter/Excise Application
 *
 * Special helper functions excise application
 *
 * @package		Excise Application
 * @author		Pinak Pani Nath
 * @copyright	        Copyright (c) 2012 - 2015, NIC Itanagar
 
 * @filesource
 */

// ------------------------------------------------------------------------


/*



if(!function_exists('session_check')){
 function session_check(){
    $ci = &get_instance();
    $current_time = time();
    $session_time = $ci->session->userdata('TIMER');
    $intervalTime = intval($current_time) - intval($session_time);
	
		if($intervalTime > 3000){
			 redirect('users/logout');
		} else {
		     $ci->session->set_userdata('TIMER', time() );
		} 
 }	
}



if(!function_exists('WordLimiter')){
 function WordLimiter( $text,$limit ){
   $totalWords =  str_word_count($text, 1);
   $string = "";
   $dots = ".....";
   if(count($totalWords) > $limit) {
         
         for($i=0; $i<$limit; $i++) {
          
            $string = $string . $totalWords[$i]." ";
          
         }
       
        return $string;
   } else {
    
       return $text.= $dots;
   }

   

 }
}


if(!function_exists('changeDateFormat')){
 function changeDateFormat( $date ) {
  
   if($date != "") {
   $dateArray = explode("/", trim($date));
   $newDate = $dateArray[2]."-".$dateArray[1]."-".$dateArray[0];
   return $newDate;
   }
  
 }
}






if(!function_exists('checkbrowser')){
 function checkbrowser() {
    $ci = &get_instance();
    $iFlag = 1;
    
    if ( $ci->agent->is_browser()) 
    {
      $browser =  $ci->agent->browser();
      $version =  $ci->agent->version();
         
       if((strtoupper($browser) == 'FIREFOX') && (intval($version)>3))
       {
         $iFlag = 0;  
       } 
            
    }
    elseif ( $ci->agent->is_robot())
    {
        $browser =  $ci->agent->robot();
    }
    elseif ( $ci->agent->is_mobile())
    {
        $browser =  $ci->agent->mobile();
    }
    else
    {
        $browser = 'Unidentified User Agent';
    }
    
    return $iFlag;
 }
}

*/

if(!function_exists('limit_words')){
	function limit_words($string, $word_limit)
	{
		$words = explode(" ",$string);
		return implode(" ",array_splice($words,0,$word_limit));
	}
}



if(!function_exists('get_program_name')){
 function get_program_name($id) {
    $ci = &get_instance();
    $ci->load->model('Model_Works');
    return $ci->Model_Works->get_program_name($id);  
 } 
}

if(!function_exists('get_category_name')){
 function get_category_name($id) {
    $ci = &get_instance();
    $ci->load->model('Model_Posts');
    return $ci->Model_Posts->get_category_name($id);  
 } 
}

/* End of file excise_helper.php */
/* Location: ./application/helpers/excise_helper.php */
?>