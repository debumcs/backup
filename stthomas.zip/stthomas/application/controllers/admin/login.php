<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class login extends CI_Controller {
	/*function __construct()
	  {
		parent::__construct();
		$this->load->model('getlogin', 'm');
	  }*/
	

	public function index()
	{	        
		$this->load->helper('url');
		//load the database 
        $this->load->database();  
        //load the model  
        $this->load->model('modellogin');  
        //load the method of model  
        $data['h']=$this->modellogin->getlogin();  
        //return the data in view  
        $this->load->view('admin/viewindex', $data);  		
		//$data = $this->m->getlogin();
		//print_r($data);
		//$this->load->view('admin/viewindex');
	}
}
?>