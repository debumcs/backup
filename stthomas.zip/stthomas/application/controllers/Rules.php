<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Rules extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
		$this->load->model('Model_Login');
		$this->load->model('Model_Rules');
		if(!$this->Model_Login->is_logged_in())
		{
			redirect('Login');
		}
    }	
	
	// Dis and rules 	
	public function disandrules()
	{
		$data['discontent'] = $this->Model_Rules->get_disandrules();
		$this->load->vars($data);
		$this->load->view('admin/rules/disandrules');
	}	
	
	public function updatedisandrules() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_Rules->update_disandrules();
			$message =  '<b>Dis and Rules text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Rules/disandrules');
		} 
	}
	// Rules Concerning 	
	public function rulesconcerning()
	{
		$data['rulesconcerning'] = $this->Model_Rules->get_rulesconcerning();
		$this->load->vars($data);
		$this->load->view('admin/rules/rulesconcerning');
	}	
	
	public function updaterulesconcerning() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_Rules->update_rulesconcerning();
			$message =  '<b>Rules Concerning text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Rules/rulesconcerning');
		} 
	}
	// General Rules 	
	public function generalrules()
	{
		$data['generalrules'] = $this->Model_Rules->get_generalrules();
		$this->load->vars($data);
		$this->load->view('admin/rules/generalrules');
	}	
	
	public function updategeneralrules() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_Rules->update_generalrules();
			$message =  '<b>Genetal Rules text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Rules/generalrules');
		} 
	}
	// Library Rules 	
	public function libraryrules()
	{
		$data['libraryrules'] = $this->Model_Rules->get_libraryrules();
		$this->load->vars($data);
		$this->load->view('admin/rules/libraryrules');
	}	
	
	public function updatelibraryrules() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_Rules->update_libraryrules();
			$message =  '<b>Library Rules text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Rules/libraryrules');
		} 
	}
	// Payment of Fees Rules 	
	public function feesrules()
	{
		$data['feesrules'] = $this->Model_Rules->get_feesrules();
		$this->load->vars($data);
		$this->load->view('admin/rules/feesrules');
	}	
	
	public function updatefeesrules() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_Rules->update_feesrules();
			$message =  '<b>Fees Rules text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Rules/feesrules');
		} 
	}
	// Parents Instructions 	
	public function parentsinstructions()
	{
		$data['parentsinstructions'] = $this->Model_Rules->get_parentsinstructions();
		$this->load->vars($data);
		$this->load->view('admin/rules/parentsinstructions');
	}	
	
	public function updateparentsinstructions() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_Rules->update_parentsinstructions();
			$message =  '<b>Parents Instructions text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Rules/parentsinstructions');
		} 
	}
	// Assessment & Promotion Criteria 	
	public function assessmentcriteria()
	{
		$data['assessmentcriteria'] = $this->Model_Rules->get_assessmentcriteria();
		$this->load->vars($data);
		$this->load->view('admin/rules/assessmentcriteria');
	}	
	
	public function updateassessmentcriteria() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_Rules->update_assessmentcriteria();
			$message =  '<b>Assessment & Promotion text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Rules/assessmentcriteria');
		} 
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */