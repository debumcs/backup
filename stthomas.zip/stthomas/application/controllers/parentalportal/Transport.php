<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
 class Transport extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
		$this->load->model('Model_Login');
		$this->load->model('parentalportal/Model_Transport');
		if(!$this->Model_Login->is_logged_in())
		{
			redirect('Login');
		}
    }
	/* Route */
	public function viewroute() 
	{
         $data['allroute'] = $this->Model_Transport->getroute();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/transport/viewroute');
	}
	public function trashroute() 
	{
         $data['allroute'] = $this->Model_Transport->trashroute();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/transport/trashroute');            
	}
	
	public function addroute() {
		$this->load->view('parentalportal/transport/addroute');	 
	}
	public function saveroute() {            
			$this->Model_Transport->saveroute();
			$message =  '<b>Route Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Transport/viewroute');      	
	}
	
	public function editroute($route_id)
	{
	    $data['route'] = $this->Model_Transport->getroutebyid($route_id);
		$this->load->view('parentalportal/transport/editroute',$data);		
	}
	public function updateroute() {	           
			$this->Model_Transport->updateroute();
			$message =  '<b>Route Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Transport/viewroute');
       
	}
	public function suspendroute($route_id)
	{
	    $this->Model_Transport->suspendroute($route_id);
		$message =  '<b>Route item suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Transport/viewroute');
	}
	public function reactiveroute($route_id)
	{
	    $this->Model_Transport->reactiveroute($route_id);
		$message =  '<b>Route item reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Transport/trashroute');
	}
	/* Transport Driver */
	public function viewtransportdriver() 
	{
         $data['alltransportdriver'] = $this->Model_Transport->gettransportdriver();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/transport/viewtransportdriver');
	}
	public function trashtransportdriver() 
	{
         $data['alltransportdriver'] = $this->Model_Transport->trashtransportdriver();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/transport/trashtransportdriver');            
	}
	public function addtransportdriver() {
		$this->load->view('parentalportal/transport/addtransportdriver');	 
	}
	public function savetransportdriver() {            
			$this->Model_Transport->savetransportdriver();
			$message =  '<b>Transport Driver Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Transport/viewtransportdriver');      	
	}
	public function edittransportdriver($transportdriver_id)
	{
	    $data['transportdriver'] = $this->Model_Transport->gettransportdriverbyid($transportdriver_id);
		$this->load->view('parentalportal/transport/edittransportdriver',$data);		
	}
	public function updatetransportdriver() {	           
			$this->Model_Transport->updatetransportdriver();
			$message =  '<b>Transport Driver Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Transport/viewtransportdriver');
       
	}
	public function suspendtransportdriver($transportdriver_id)
	{
	    $this->Model_Transport->suspendtransportdriver($transportdriver_id);
		$message =  '<b>Transport Driver item suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Transport/viewtransportdriver');
	}
	public function reactivetransportdriver($transportdriver_id)
	{
	    $this->Model_Transport->reactivetransportdriver($transportdriver_id);
		$message =  '<b>Transport Driver item reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Transport/trashtransportdriver');
	}
	/* Transport Conductor */
	public function viewtransportconductor() 
	{
         $data['alltransportconductor'] = $this->Model_Transport->gettransportconductor();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/transport/viewtransportconductor');
	}
	public function trashtransportconductor() 
	{
         $data['alltransportconductor'] = $this->Model_Transport->trashtransportconductor();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/transport/trashtransportconductor');            
	}
	public function addtransportconductor() {
		$this->load->view('parentalportal/transport/addtransportconductor');	 
	}
	public function savetransportconductor() {            
			$this->Model_Transport->savetransportconductor();
			$message =  '<b>Transport Conductor Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Transport/viewtransportconductor');      	
	}
	public function edittransportconductor($transportconductor_id)
	{
	    $data['transportconductor'] = $this->Model_Transport->gettransportconductorbyid($transportconductor_id);
		$this->load->view('parentalportal/transport/edittransportconductor',$data);		
	}
	public function updatetransportconductor() {	           
			$this->Model_Transport->updatetransportconductor();
			$message =  '<b>Transport Conductor Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Transport/viewtransportconductor');
       
	}
	public function suspendtransportconductor($transportconductor_id)
	{
	    $this->Model_Transport->suspendtransportconductor($transportconductor_id);
		$message =  '<b>Transport Conductor item suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Transport/viewtransportconductor');
	}
	public function reactivetransportconductor($transportconductor_id)
	{
	    $this->Model_Transport->reactivetransportconductor($transportconductor_id);
		$message =  '<b>Transport Conductor item reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Transport/trashtransportconductor');
	}
	
	/* Bus Details */
	public function viewbus() 
	{
         $data['allbus'] = $this->Model_Transport->getbus();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/transport/viewbus');            
	}
	public function trashbus() 
	{
         $data['allbus'] = $this->Model_Transport->trashbus();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/transport/trashbus');            
	}
	
	public function addbus() {
		//driver
		$data['drivercat'] = $this->Model_Transport->gettransportdriverbus();
		$this->load->vars($data);
		//conductor
		$data['coductorcat'] = $this->Model_Transport->gettransportconductorbus();
		$this->load->vars($data);
		$this->load->view('parentalportal/transport/addbus');	 
	}
	public function savebus() {            
			$this->Model_Transport->savebus();
			$message =  '<b>Bus Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Transport/viewbus');      	
	}
	
	public function editbus($bus_id)
	{
		//driver
		$data['drivercat'] = $this->Model_Transport->gettransportdriverbus();
		$this->load->vars($data);
		//conductor
		$data['coductorcat'] = $this->Model_Transport->gettransportconductorbus();
	    $data['bus'] = $this->Model_Transport->getbusbyid($bus_id);
		$this->load->view('parentalportal/transport/editbus',$data);		
	}
	public function updatebus() {	           
			$this->Model_Transport->updatebus();
			$message =  '<b>Bus Details Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Transport/viewbus');
       
	}
	public function suspendbus($bus_id)
	{
	    $this->Model_Transport->suspendbus($bus_id);
		$message =  '<b>Bus Details suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Transport/viewbus');
	}
	public function reactivebus($bus_id)
	{
	    $this->Model_Transport->reactivebus($bus_id);
		$message =  '<b>Bus Details reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Transport/trashbus');
	}
    
 }