<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
 class Registration extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
		$this->load->model('Model_Login');
		$this->load->model('parentalportal/Model_Registration');
		if(!$this->Model_Login->is_logged_in())
		{
			redirect('Login');
		}
    }
	
	/* parent Registration */
	public function viewparentregistration() 
	{
         $data['allparentregistration'] = $this->Model_Registration->getparentregistration();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/registration/viewparentregistration');            
	}
	public function trashparentregistration() 
	{
         $data['allparentregistration'] = $this->Model_Registration->trashparentregistration();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/registration/trashparentregistration');            
	}	
	public function addparentregistration() {
		$this->load->view('parentalportal/registration/addparentregistration');	 
	}
	public function saveparentregistration() {            
			$this->Model_Registration->saveparentregistration();
			$this->Model_Registration->saveregistration();
			$message = '<b>Parent Registration Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Registration/viewparentregistration');      	
	}	
	public function editparentregistration($username)
	{
	    $data['parentregistration'] = $this->Model_Registration->getparentregistrationbyid($username);
		$this->load->view('parentalportal/registration/editparentregistration',$data);		
	}
	public function updateparentregistration() {	           
			$this->Model_Registration->updateparentregistration();
			$this->Model_Registration->updateparentregistrationlogin();
			$message =  '<b>Parent Registration Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Registration/viewparentregistration');
       
	}	
	public function suspendparentregistration($username)
	{
	    $this->Model_Registration->suspendparentregistration($username);
		$this->Model_Registration->suspendparentregistrationlogin($username);
		$message =  '<b>Parent Registration item suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Registration/viewparentregistration');
	}
	public function reactiveparentregistration($username)
	{
	    $this->Model_Registration->reactiveparentregistration($username);
		$this->Model_Registration->reactiveparentregistrationlogin($username);
		$message =  '<b>Parent Registration item reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Registration/trashparentregistration');
	}
	/* Teacher Registration */
	public function viewteacherregistration() 
	{
         $data['allteacherregistration'] = $this->Model_Registration->getteacherregistration();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/registration/viewteacherregistration');            
	}
	public function trashteacherregistration() 
	{
         $data['allteacherregistration'] = $this->Model_Registration->trashteacherregistration();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/registration/trashteacherregistration');            
	}	
	public function addteacherregistration() {
		$this->load->view('parentalportal/registration/addteacherregistration');	 
	}
	public function saveteacherregistration() {            
			$this->Model_Registration->saveteacherregistration();
			$this->Model_Registration->saveregistration();
			$message = '<b>Teacher Registration Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Registration/viewteacherregistration');      	
	}	
	public function editteacherregistration($username)
	{
	    $data['teacherregistration'] = $this->Model_Registration->getteacherregistrationbyid($username);
		$this->load->view('parentalportal/registration/editteacherregistration',$data);		
	}
	public function updateteacherregistration() {	           
			$this->Model_Registration->updateteacherregistration();
			$this->Model_Registration->updateteacherregistrationlogin();
			$message =  '<b>Teacher Registration Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Registration/viewteacherregistration');
       
	}	
	public function suspendteacherregistration($username)
	{
	    $this->Model_Registration->suspendteacherregistration($username);
		$this->Model_Registration->suspendteacherregistrationlogin($username);
		$message =  '<b>Teacher Registration item suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Registration/viewteacherregistration');
	}
	public function reactiveteacherregistration($username)
	{
	    $this->Model_Registration->reactiveteacherregistration($username);
		$this->Model_Registration->reactiveteacherregistrationlogin($username);
		$message =  '<b>Teacher Registration item reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Registration/trashteacherregistration');
	}
	
 }