<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 class Academic extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
		$this->load->model('Model_Login');
		$this->load->model('parentalportal/Model_Academic');
		if(!$this->Model_Login->is_logged_in())
		{
			redirect('Login');
		}
    }
	
	/* Assignment */
	public function viewassignment() 
	{
         $data['allassignment'] = $this->Model_Academic->getassignment();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/academic/viewassignment');            
	}
	public function trashassignment() 
	{
         $data['allassignment'] = $this->Model_Academic->trashassignment();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/academic/trashassignment');            
	}
	public function addassignment() {				
		$this->load->view('parentalportal/academic/addassignment');	 
	}
	public function saveassignment() { 				
			$this->Model_Academic->saveassignment();
			$message =  '<b>Assignment Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewassignment');      	
	}
	public function editassignment($assignment_id)
	{		
	    $data['assignment'] = $this->Model_Academic->getassignmentbyid($assignment_id);
		$this->load->view('parentalportal/academic/editassignment',$data);		
	}
	public function updateassignment() {		
			$this->Model_Academic->updateassignment();
			$message =  '<b>Assignment Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewassignment');
       
	}
	public function suspendassignment($assignment_id)
	{
	    $this->Model_Academic->suspendassignment($assignment_id);
		$message =  '<b>Assignment suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Academic/viewassignment');
	}
	public function reactiveassignment($assignment_id)
	{
	    $this->Model_Academic->reactiveassignment($assignment_id);
		$message =  '<b>Assignment reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Academic/trashassignment');
	}
	
	
	/* Evaluation(Exam Time Table) */
	public function viewexamtimetable() 
	{
         $data['allexamtimetable'] = $this->Model_Academic->getexamtimetable();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/academic/viewexamtimetable');            
	}
	public function trashexamtimetable() 
	{
         $data['allexamtimetable'] = $this->Model_Academic->trashexamtimetable();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/academic/trashexamtimetable');            
	}
	public function addexamtimetable() {				
		$this->load->view('parentalportal/academic/addexamtimetable');	 
	}
	public function saveexamtimetable() { 				
			$this->Model_Academic->saveexamtimetable();
			$message =  '<b>Exam Time Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewexamtimetable');      	
	}
	public function editexamtimetable($examtimetable_id)
	{		
	    $data['examtimetable'] = $this->Model_Academic->getexamtimetablebyid($assignment_id);
		$this->load->view('parentalportal/academic/editexamtimetable',$data);		
	}
	public function updateexamtimetable() {		
			$this->Model_Academic->updateexamtimetable();
			$message =  '<b>Exam Time Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewexamtimetable');
       
	}
	public function suspendexamtimetable($examtimetable_id)
	{
	    $this->Model_Academic->suspendexamtimetable($examtimetable_id);
		$message =  '<b>Exam Time suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Academic/viewexamtimetable');
	}
	public function reactiveexamtimetable($examtimetable_id)
	{
	    $this->Model_Academic->reactiveexamtimetable($examtimetable_id);
		$message =  '<b>Exam Time reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Academic/trashexamtimetable');
	}
	
	/* Evaluation ->class management(class) */
	public function viewclass() 
	{
         $data['allclass'] = $this->Model_Academic->getclass();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/academic/viewclass');            
	}
	public function trashclass() 
	{
         $data['allclass'] = $this->Model_Academic->trashclass();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/academic/trashclass');            
	}
	public function addclass() {				
		$this->load->view('parentalportal/academic/addclass');	 
	}
	public function saveclass() { 				
			$this->Model_Academic->saveclass();
			$message =  '<b>Class Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewclass');      	
	}
	public function editclass($class_id)
	{		
	    $data['class'] = $this->Model_Academic->getclassbyid($class_id);
		$this->load->view('parentalportal/academic/editclass',$data);		
	}
	public function updateclass() {		
			$this->Model_Academic->updateclass();
			$message =  '<b>Class Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewclass');
       
	}
	public function suspendclass($class_id)
	{
	    $this->Model_Academic->suspendclass($class_id);
		$message =  '<b>Class suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Academic/viewclass');
	}
	public function reactiveclass($class_id)
	{
	    $this->Model_Academic->reactiveclass($class_id);
		$message =  '<b>Class reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Academic/trashclass');
	}
	
	/* Evaluation ->class management(section) */
	public function viewsection() 
	{
         $data['allsection'] = $this->Model_Academic->getsection();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/academic/viewsection');            
	}
	public function trashsection() 
	{
         $data['allsection'] = $this->Model_Academic->trashsection();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/academic/trashsection');            
	}
	public function addsection() {
        //class		
        $data['classcat'] = $this->Model_Academic->getclasssection();		 
		$this->load->vars($data);
		//section
		$data['teachercat'] = $this->Model_Academic->getclassteacher();		 
		$this->load->vars($data);	
		$this->load->view('parentalportal/academic/addsection');	 
	}
	public function savesection() { 				
			$this->Model_Academic->savesection();
			$message =  '<b>Section Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewsection');      	
	}
	public function editsection($section_id)
	{
		//class
		$data['classcat'] = $this->Model_Academic->getclasssection();		 
		$this->load->vars($data);
		//section
        $data['teachercat'] = $this->Model_Academic->getclassteacher();		 
		$this->load->vars($data);		
	    $data['section'] = $this->Model_Academic->getsectionbyid($section_id);
		$this->load->view('parentalportal/academic/editsection',$data);		
	}
	public function updatesection() {		
			$this->Model_Academic->updatesection();
			$message =  '<b>Section Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewsection');
       
	}
	public function suspendsection($section_id)
	{
	    $this->Model_Academic->suspendsection($section_id);
		$message =  '<b>Section suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Academic/viewsection');
	}
	public function reactivesection($section_id)
	{
	    $this->Model_Academic->reactivesection($section_id);
		$message =  '<b>Section reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Academic/trashsection');
	}
	
	/* Evaluation ->class management(Subject) */
	public function viewsubject() 
	{
         $data['allsubject'] = $this->Model_Academic->getsubject();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/academic/viewsubject');            
	}
	public function trashsubject() 
	{
         $data['allsubject'] = $this->Model_Academic->trashsubject();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/academic/trashsubject');            
	}
	public function addsubject() {
        //class		
        $data['classcat'] = $this->Model_Academic->getclasssubject();		 
		$this->load->vars($data);
		$this->load->view('parentalportal/academic/addsubject');	 
	}
	public function savesubject() { 				
			$this->Model_Academic->savesubject();
			$message =  '<b>Subject Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewsubject');      	
	}
	public function editsubject($subject_id)
	{
		//class
		$data['classcat'] = $this->Model_Academic->getclasssubject();		 
		$this->load->vars($data);				
	    $data['subject'] = $this->Model_Academic->getsubjectbyid($subject_id);
		$this->load->view('parentalportal/academic/editsubject',$data);		
	}
	public function updatesubject() {		
			$this->Model_Academic->updatesubject();
			$message =  '<b>Subject Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewsubject');
       
	}
	public function suspendsubject($subject_id)
	{
	    $this->Model_Academic->suspendsubject($subject_id);
		$message =  '<b>Subject suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Academic/viewsubject');
	}
	public function reactivesubject($subject_id)
	{
	    $this->Model_Academic->reactivesubject($subject_id);
		$message =  '<b>Subject reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Academic/trashsubject');
	}
	
	/* Evaluation ->class management(Syllabus) */
	
	public function getsubcategorydetails()
    {
       $class_id = $this->input->post('class_id');
       $sub_categories = $this->Model_Academic->getsubcategorydetails($class_id);
	   
       $subcategory='<select name="subject_id" id="sub_cat_id" class="form-control"><option value="" >--Select Subject--</option>';
       foreach($sub_categories as $stt)
       {
       $subcategory.='<option value="'.$stt["subject_id"].'">'.$stt["subject_name"].'</option>';
       }
	   $subcategory.='</select>';
       echo $subcategory;
	   exit;
    }
	public function viewsyllabus() 
	{
         $data['allsyllabus'] = $this->Model_Academic->getsyllabus();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/academic/viewsyllabus');            
	}
	public function trashsyllabus() 
	{
         $data['allsyllabus'] = $this->Model_Academic->trashsyllabus();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/academic/trashsyllabus');            
	}
	public function addsyllabus() {
        //class		
        $data['classcat'] = $this->Model_Academic->getclasssyllabus();		 
		$this->load->vars($data);
		$this->load->view('parentalportal/academic/addsyllabus');
	}
	public function savesyllabus() { 
			$upload_conf = array(
            'upload_path'   => realpath('upload/syllabus'),
            'allowed_types' => 'pdf',
			'max_size'      => '30000',
            );
		$upload_data = '';
		$doc_data = '';
		$this->upload->initialize( $upload_conf );		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("syllabus_pdf"))
        {
            // if upload fail, grab error 
            $error['upload'][] = $this->upload->display_errors();
			$message =  '<b>Please upload document!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);			
			redirect('parentalportal/Academic/addsyllabus');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$doc_data['syllabus_pdf'] = $upload_data['file_name'];
			$this->Model_Academic->savesyllabus($doc_data);
			$message =  '<b>Syllabus Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewsyllabus');  
        }
			     	
	}
	public function editsyllabus($syllabus_id)
	{
		//class		
        $data['classcat'] = $this->Model_Academic->getclasssyllabus();		 
		$this->load->vars($data);
		//subject
		//$data['subjectcat'] = $this->Model_Academic->getsubjectsyllabus();		 
		//$this->load->vars($data);				
	    $data['syllabus'] = $this->Model_Academic->getsyllabusbyid($syllabus_id);
		$this->load->view('parentalportal/academic/editsyllabus',$data);		
	}
	public function updatesyllabus() {
			 $upload_conf = array(
            'upload_path'   => realpath('upload/syllabus'),
            'allowed_types' => 'pdf',
			'max_size'      => '30000',
			'overwrite'     =>  FALSE
            );
		$upload_data = '';
		$doc_data = '';
		$this->upload->initialize( $upload_conf );
		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("syllabus_pdf"))
        {
            // if upload fail, grab error            
			$this->Model_Academic->updatesyllabuscontent();
			$message =  '<b>Syllabus Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewsyllabus');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$doc_data['syllabus_pdf'] = $upload_data['file_name'];
			$this->Model_Academic->updatesyllabus($doc_data);
			$message =  '<b>Syllabus Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewsyllabus');
        }
       
	}
	public function suspendsyllabus($syllabus_id)
	{
	    $this->Model_Academic->suspendsyllabus($syllabus_id);
		$message =  '<b>Syllabus suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Academic/viewsyllabus');
	}
	public function reactivesyllabus($syllabus_id)
	{
	    $this->Model_Academic->reactivesyllabus($syllabus_id);
		$message =  '<b>Syllabus reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Academic/trashsyllabus');
	}
	
	/* Evaluation ->class management(Test Paper) */
	public function getsubcategorydetailstest()
    {
       $class_id = $this->input->post('class_id');
       $sub_categories = $this->Model_Academic->getsubcategorydetailstest($class_id);
	   
       $subcategory='<select name="subject_id" id="sub_cat_id" class="form-control"><option value="" >--Select Subject--</option>';
       foreach($sub_categories as $stt)
       {
       $subcategory.='<option value="'.$stt["subject_id"].'">'.$stt["subject_name"].'</option>';
       }
	   $subcategory.='</select>';
       echo $subcategory;
	   exit;
    }
	public function viewtestpaper() 
	{
         $data['alltestpaper'] = $this->Model_Academic->gettestpaper();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/academic/viewtestpaper');            
	}
	public function trashtestpaper() 
	{
         $data['alltestpaper'] = $this->Model_Academic->trashtestpaper();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/academic/trashtestpaper');            
	}
	public function addtestpaper() {
        //class		
        $data['classcat'] = $this->Model_Academic->getclasstestpaper();		 
		$this->load->vars($data);
		$this->load->view('parentalportal/academic/addtestpaper');
	}
	public function savetestpaper() { 
			$upload_conf = array(
            'upload_path'   => realpath('upload/testpaper'),
            'allowed_types' => 'pdf',
			'max_size'      => '30000',
            );
		$upload_data = '';
		$doc_data = '';
		$this->upload->initialize( $upload_conf );		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("testpaper_pdf"))
        {
            // if upload fail, grab error 
            $error['upload'][] = $this->upload->display_errors();
			$message =  '<b>Please upload document!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);			
			redirect('parentalportal/Academic/addtestpaper');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$doc_data['testpaper_pdf'] = $upload_data['file_name'];
			$this->Model_Academic->savetestpaper($doc_data);
			$message =  '<b>Test Paper Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewtestpaper');  
        }
			     	
	}
	public function edittestpaper($testpaper_id)
	{
		//class		
        $data['classcat'] = $this->Model_Academic->getclasstestpaper();		 
		$this->load->vars($data);
	    $data['testpaper'] = $this->Model_Academic->gettestpaperbyid($testpaper_id);
		$this->load->view('parentalportal/academic/edittestpaper',$data);		
	}
	public function updatetestpaper() {
			 $upload_conf = array(
            'upload_path'   => realpath('upload/testpaper'),
            'allowed_types' => 'pdf',
			'max_size'      => '30000',
			'overwrite'     =>  FALSE
            );
		$upload_data = '';
		$doc_data = '';
		$this->upload->initialize( $upload_conf );
		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("testpaper_pdf"))
        {
            // if upload fail, grab error            
			$this->Model_Academic->updatetestpapercontent();
			$message =  '<b>Test paper Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewtestpaper');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$doc_data['testpaper_pdf'] = $upload_data['file_name'];
			$this->Model_Academic->updatetestpaper($doc_data);
			$message =  '<b>Test Paper Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewtestpaper');
        }
       
	}
	public function suspendtestpaper($testpaper_id)
	{
	    $this->Model_Academic->suspendtestpaper($testpaper_id);
		$message =  '<b>Test paper suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Academic/viewtestpaper');
	}
	public function reactivetestpaper($testpaper_id)
	{
	    $this->Model_Academic->reactivetestpaper($testpaper_id);
		$message =  '<b>Test paper reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Academic/trashtestpaper');
	}
	
	/* Evaluation ->class management(Question Paper) */
	public function getsubcategorydetailsquestion()
    {
       $class_id = $this->input->post('class_id');
       $sub_categories = $this->Model_Academic->getsubcategorydetailsquestion($class_id);
	   
       $subcategory='<select name="subject_id" id="sub_cat_id" class="form-control"><option value="" >--Select Subject--</option>';
       foreach($sub_categories as $stt)
       {
       $subcategory.='<option value="'.$stt["subject_id"].'">'.$stt["subject_name"].'</option>';
       }
	   $subcategory.='</select>';
       echo $subcategory;
	   exit;
    }
	public function viewquestionpaper() 
	{
         $data['allquestionpaper'] = $this->Model_Academic->getquestionpaper();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/academic/viewquestionpaper');       
	}
	public function trashquestionpaper() 
	{
         $data['allquestionpaper'] = $this->Model_Academic->trashquestionpaper();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/academic/trashquestionpaper');
	}
	public function addquestionpaper() {
        //class		
        $data['classcat'] = $this->Model_Academic->getclassquestionpaper();		 
		$this->load->vars($data);
		$this->load->view('parentalportal/academic/addquestionpaper');
	}
	public function savequestionpaper() { 
			$upload_conf = array(
            'upload_path'   => realpath('upload/questionpaper'),
            'allowed_types' => 'pdf',
			'max_size'      => '30000',
            );
		$upload_data = '';
		$doc_data = '';
		$this->upload->initialize( $upload_conf );		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("questionpaper_pdf"))
        {
            // if upload fail, grab error 
            $error['upload'][] = $this->upload->display_errors();
			$message =  '<b>Please upload document!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);			
			redirect('parentalportal/Academic/addquestionpaper');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$doc_data['questionpaper_pdf'] = $upload_data['file_name'];
			$this->Model_Academic->savequestionpaper($doc_data);
			$message =  '<b>Question Paper Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewquestionpaper');  
        }
			     	
	}
	public function editquestionpaper($questionpaper_id)
	{
		//class		
        $data['classcat'] = $this->Model_Academic->getclassquestionpaper();		 
		$this->load->vars($data);
	    $data['questionpaper'] = $this->Model_Academic->getquestionpaperbyid($questionpaper_id);
		$this->load->view('parentalportal/academic/editquestionpaper',$data);	
	}
	public function updatequestionpaper() {
			 $upload_conf = array(
            'upload_path'   => realpath('upload/questionpaper'),
            'allowed_types' => 'pdf',
			'max_size'      => '30000',
			'overwrite'     =>  FALSE
            );
		$upload_data = '';
		$doc_data = '';
		$this->upload->initialize( $upload_conf );
		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("questionpaper_pdf"))
        {
            // if upload fail, grab error            
			$this->Model_Academic->updatequestionpapercontent();
			$message =  '<b>Question paper Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewquestionpaper');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$doc_data['questionpaper_pdf'] = $upload_data['file_name'];
			$this->Model_Academic->updatequestionpaper($doc_data);
			$message =  '<b>Question Paper Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Academic/viewquestionpaper');
        }
       
	}
	public function suspendquestionpaper($questionpaper_id)
	{
	    $this->Model_Academic->suspendquestionpaper($questionpaper_id);
		$message =  '<b>Question paper suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Academic/viewquestionpaper');
	}
	public function reactivequestionpaper($questionpaper_id)
	{
	    $this->Model_Academic->reactivequestionpaper($questionpaper_id);
		$message =  '<b>Question paper reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Academic/trashquestionpaper');
	}
	
    
 }