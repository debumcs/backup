<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 class Studentmanagement extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
		$this->load->model('Model_Login');
		$this->load->model('parentalportal/Model_Studentmanagement');
		if(!$this->Model_Login->is_logged_in())
		{
			redirect('Login');
		}
    }
	
	/* Student Registration */
	public function viewstudentregistration() 
	{
         $data['allstudentregistration'] = $this->Model_Studentmanagement->getstudentregistration();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/studentmanagement/viewstudentregistration');            
	}
	public function trashstudentregistration() 
	{
         $data['allstudentregistration'] = $this->Model_Studentmanagement->trashstudentregistration();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/studentmanagement/trashstudentregistration');            
	}
	public function addstudentregistration() {
		//Route
		$data['routecat'] = $this->Model_Studentmanagement->getroute();
		$this->load->vars($data);		
		$this->load->view('parentalportal/studentmanagement/addstudentregistration');	 
	}
	public function savestudentregistration() { 
			$upload_conf = array(
            'upload_path'   => realpath('upload/studentregistration'),
            'allowed_types' => 'png|jpg|jepg|gif|bmp',
			'max_size'      => '30000',
            );
		$upload_data = array();
		$image_data = array();
		$this->upload->initialize( $upload_conf );		
        $error = array();
        $success = array();
		$m1 = $_FILES['s_image']['name'];      
		$m2 = $_FILES['f_image']['name']; 
		$m3 = $_FILES['m_image']['name'];
		$m4 = $_FILES['lg_image']['name'];
		if($m1 == ""){
			$error['upload'][] = $this->upload->display_errors();
			$message =  '<b>Please upload image!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Studentmanagement/addstudentregistration');
		}
		if($m2 == ""){
			$error['upload'][] = $this->upload->display_errors();
			$message =  '<b>Please upload image!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Studentmanagement/addstudentregistration');
		}
		if($m3 == ""){
			$error['upload'][] = $this->upload->display_errors();
			$message =  '<b>Please upload image!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Studentmanagement/addstudentregistration');
		}
		if($m4 == ""){
			$error['upload'][] = $this->upload->display_errors();
			$message =  '<b>Please upload image!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Studentmanagement/addstudentregistration');
		}
		if ($m1 !== "")
		{			
			 $this->upload->do_upload('s_image');
			 $upload_data = $this->upload->data();
			 $image_data['s_image'] = $upload_data['file_name'];
		}		
		if ($m2 !== "")
		{
			$this->upload->do_upload('f_image');
			$upload_data = $this->upload->data();
			$image_data['f_image'] = $upload_data['file_name']; 
		}
		if ($m3 !== "")
		{
			$this->upload->do_upload('m_image');
			$upload_data = $this->upload->data();
			$image_data['m_image'] = $upload_data['file_name']; 
		}
		if ($m4 !== "")
		{
			$this->upload->do_upload('lg_image');
			$upload_data = $this->upload->data();
			$image_data['lg_image'] = $upload_data['file_name']; 
		}		
			$this->Model_Studentmanagement->savestudentregistration($image_data);
			$message =  '<b>Student Registration Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Studentmanagement/viewstudentregistration');      	
	}
	public function editstudentregistration($studentregistration_id)
	{
		//Route
		$data['routecat'] = $this->Model_Studentmanagement->getroute();
		$this->load->vars($data);
	    $data['studentregistration'] = $this->Model_Studentmanagement->getstudentregistrationbyid($studentregistration_id);
		$this->load->view('parentalportal/studentmanagement/editstudentregistration',$data);		
	}
	public function updatestudentregistration() {
			$upload_conf = array(
            'upload_path'   => realpath('upload/studentregistration'),
            'allowed_types' => 'png|jpg|jepg|gif|bmp',
			'max_size'      => '30000',
			'overwrite'     =>  FALSE
            );
		$upload_data = array();
		$image_data = array();
		$this->upload->initialize( $upload_conf );
        $error = array();
        $success = array();
		$m1 = $_FILES['s_image']['name'];      
		$m2 = $_FILES['f_image']['name']; 
		$m3 = $_FILES['m_image']['name'];
		$m4 = $_FILES['lg_image']['name'];
		if ($m1 !== "")
		{			
			 $this->upload->do_upload('s_image');
			 $upload_data = $this->upload->data();
			 $image_data['s_image'] = $upload_data['file_name'];
		}
		else{
			$image_data['s_image'] = $this->input->post('previousimagestudent');
		}
 		
		if ($m2 !== "")
		{
			$this->upload->do_upload('f_image');
			$upload_data = $this->upload->data();
			$image_data['f_image'] = $upload_data['file_name']; 
		}
		else{
			$image_data['f_image'] = $this->input->post('previousimagefather');
		}
			
		if ($m3 !== "")
		{
			$this->upload->do_upload('m_image');
			$upload_data = $this->upload->data();
			$image_data['m_image'] = $upload_data['file_name']; 
		}
		else{
			$image_data['m_image'] = $this->input->post('previousimagemother');
		}

		if ($m4 !== "")
		{
			$this->upload->do_upload('lg_image');
			$upload_data = $this->upload->data();
			$image_data['lg_image'] = $upload_data['file_name']; 
		}
		else{
			$image_data['lg_image'] = $this->input->post('previousimageguardation');
		}		
			
			$this->Model_Studentmanagement->updatestudentregistration($image_data);
			$message =  '<b>Student Registration Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Studentmanagement/viewstudentregistration');
       
	}
	public function suspendstudentregistration($studentregistration_id)
	{
	    $this->Model_Studentmanagement->suspendstudentregistration($studentregistration_id);
		$message =  '<b>Student Registration suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Studentmanagement/viewstudentregistration');
	}
	public function reactivestudentregistration($studentregistration_id)
	{
	    $this->Model_Studentmanagement->reactivestudentregistration($studentregistration_id);
		$message =  '<b>Student Registration reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Studentmanagement/trashstudentregistration');
	}
	
	/* Student Subject Details */
	public function viewstudentsubject() 
	{
         $data['allstudentsubject'] = $this->Model_Studentmanagement->getstudentsubject();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/studentmanagement/viewstudentsubject');            
	}
	public function trashstudentsubject() 
	{
         $data['allstudentsubject'] = $this->Model_Studentmanagement->trashstudentsubject();		 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/studentmanagement/trashstudentsubject');            
	}
	public function addstudentsubject() {				
		$this->load->view('parentalportal/studentmanagement/addstudentsubject');	 
	}
	public function savestudentsubject() { 				
			$this->Model_Studentmanagement->savestudentsubject();
			$message =  '<b>Subject Details Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Studentmanagement/viewstudentsubject');      	
	}
	public function editstudentsubject($studentsubject_id)
	{		
	    $data['studentsubject'] = $this->Model_Studentmanagement->getstudentsubjectbyid($studentsubject_id);
		$this->load->view('parentalportal/studentmanagement/editstudentsubject',$data);		
	}
	public function updatestudentsubject() {		
			$this->Model_Studentmanagement->updatestudentsubject();
			$message =  '<b>Student Registration Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Studentmanagement/viewstudentsubject');
       
	}
	public function suspendstudentsubject($studentsubject_id)
	{
	    $this->Model_Studentmanagement->suspendstudentsubject($studentsubject_id);
		$message =  '<b>Subject Details suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Studentmanagement/viewstudentsubject');
	}
	public function reactivestudentsubject($studentsubject_id)
	{
	    $this->Model_Studentmanagement->reactivestudentsubject($studentsubject_id);
		$message =  '<b>Subject Details reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Studentmanagement/trashstudentsubject');
	}
    
 }