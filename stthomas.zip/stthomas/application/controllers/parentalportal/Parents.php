<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
 class Parents extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
		$this->load->model('Model_Login');
		$this->load->model('parentalportal/Model_Parents');
		if(!$this->Model_Login->is_logged_in())
		{
			redirect('Login');
		}
    }	
	
    /* Fees Summary */
	public function viewfeessummary() 
	{
         $data['allfeessummary'] = $this->Model_Parents->getfeessummary();
		 $this->load->vars($data);
		 $this->load->view('parentalportal/parents/viewfeessummary');            
	}
	public function trashfeessummary() 
	{
         $data['allfeessummary'] = $this->Model_Parents->trashfeessummary(); 
		 $this->load->vars($data);
		 $this->load->view('parentalportal/parents/trashfeessummary');            
	}
	
	public function addfeessummary() {
		$this->load->view('parentalportal/parents/addfeessummary');	 
	}
	public function savefeessummary() {            
			$this->Model_Parents->savefeessummary();
			$message =  '<b>Fees Summary Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Parents/viewfeessummary');      	
	}
	
	public function editfeessummary($feessummary_id)
	{
	    $data['feessummary'] = $this->Model_Parents->getfeessummarybyid($feessummary_id);
		$this->load->view('parentalportal/parents/editfeessummary',$data);		
	}
	public function updatefeessummary() {	           
			$this->Model_Parents->updatefeessummary();
			$message =  '<b>Fees Summary Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('parentalportal/Parents/viewfeessummary');
       
	}
	public function suspendfeessummary($feessummary_id)
	{
	    $this->Model_Parents->suspendfeessummary($feessummary_id);
		$message =  '<b>Fees Summary item suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Parents/viewfeessummary');
	}
	public function reactivefeessummary($feessummary_id)
	{
	    $this->Model_Parents->reactivefeessummary($feessummary_id);
		$message =  '<b>Fees Summary item reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('parentalportal/Parents/trashfeessummary');
	}		
	
 }