<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
 class Media extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
		$this->load->model('Model_Login');
		$this->load->model('Model_Media');
		if(!$this->Model_Login->is_logged_in())
		{
			redirect('Login');
		}
    }
	/* press release */
	public function viewpressrelease() 
	{
         $data['allpressrelease'] = $this->Model_Media->getpressrelease();		 
		 $this->load->vars($data);
		 $this->load->view('admin/media/viewpressrelease');            
	}
	public function trashpressrelease() 
	{
         $data['allpressrelease'] = $this->Model_Media->trashpressrelease();		 
		 $this->load->vars($data);
		 $this->load->view('admin/media/trashpressrelease');            
	}
	
	public function addpressrelease() {
		$this->load->view('admin/media/addpressrelease');	 
	}
	public function savepressrelease() {            
			$this->Model_Media->savepressrelease();
			$message =  '<b>Press Release Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Media/viewpressrelease');        	
	}
	
	public function editpressrelease($pressrelease_id)
	{
	    $data['pressrelease'] = $this->Model_Media->getpressreleasebyid($pressrelease_id);
		$this->load->view('admin/media/editpressrelease',$data);		
	}
	public function updatepressrelease() {	
			$this->Model_Media->updatepressrelease();
			$message =  '<b>Press Release Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Media/viewpressrelease');        
	}
	public function suspendpressrelease($pressrelease_id)
	{
	    $this->Model_Media->suspendpressrelease($pressrelease_id);
		$message =  '<b>Press Release item suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Media/viewpressrelease');
	}
	public function reactivepressrelease($pressrelease_id)
	{
	    $this->Model_Media->reactivepressrelease($pressrelease_id);
		$message =  '<b>Press Release item reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Media/trashpressrelease');
	}
	/* latest happenings */
	public function viewlatesthappenings() 
	{
         $data['alllatesthappenings'] = $this->Model_Media->getlatesthappenings();		 
		 $this->load->vars($data);
		 $this->load->view('admin/media/viewlatesthappenings');            
	}
	public function trashlatesthappenings() 
	{
         $data['alllatesthappenings'] = $this->Model_Media->trashlatesthappenings();		 
		 $this->load->vars($data);
		 $this->load->view('admin/media/trashlatesthappenings');            
	}
	
	public function addlatesthappenings() {
		$this->load->view('admin/media/addlatesthappenings');	 
	}
	public function savelatesthappenings() {            
			$this->Model_Media->savelatesthappenings();
			$message =  '<b>Latest Happenings Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Media/viewlatesthappenings');        	
	}
	
	public function editlatesthappenings($latesthappenings_id)
	{
	    $data['latesthappenings'] = $this->Model_Media->getlatesthappeningsbyid($latesthappenings_id);
		$this->load->view('admin/media/editlatesthappenings',$data);		
	}
	public function updatelatesthappenings() {	
			$this->Model_Media->updatelatesthappenings();
			$message =  '<b>Latest Happenings Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Media/viewlatesthappenings');        
	}
	public function suspendlatesthappenings($latesthappenings_id)
	{
	    $this->Model_Media->suspendlatesthappenings($latesthappenings_id);
		$message =  '<b>Latest Happenings item suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Media/viewlatesthappenings');
	}
	public function reactivelatesthappenings($latesthappenings_id)
	{
	    $this->Model_Media->reactivelatesthappenings($latesthappenings_id);
		$message =  '<b>Latest Happenings item reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Media/trashlatesthappenings');
	}
	/* photo gallery */
	public function viewphotogallery() 
	{
         $data['allphotogallery'] = $this->Model_Media->getphotogallery();		 
		 $this->load->vars($data);
		 $this->load->view('admin/media/viewphotogallery');            
	}
	public function trashphotogallery() 
	{
         $data['allphotogallery'] = $this->Model_Media->trashphotogallery();		 
		 $this->load->vars($data);
		 $this->load->view('admin/media/trashphotogallery');            
	}
	
	public function addphotogallery() {
		$this->load->view('admin/media/addphotogallery');	 
	}
	public function save() {
		$upload_conf = array(
            'upload_path'   => realpath('upload/photogallery'),
            'allowed_types' => 'png|jpg|jepg|gif|bmp',
			'max_size'      => '30000',
            );
		$upload_data = '';
		$image_data = '';
		$this->upload->initialize( $upload_conf );		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("image"))
        {
            // if upload fail, grab error 
            $error['upload'][] = $this->upload->display_errors();
			$message =  '<b>Please upload image!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Media/addphotogallery');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$image_data['image'] = $upload_data['file_name'];
			$this->Model_Media->save($image_data);
			$message =  '<b>Photo Gallery Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Media/viewphotogallery');
        }		
	}
	
	public function editphotogallery($photogallery_id)
	{
	    $data['photogallery'] = $this->Model_Media->getphotogallerybyid($photogallery_id);
		$this->load->view('admin/media/editphotogallery',$data);		
	}
	public function update() {
	    $upload_conf = array(
            'upload_path'   => realpath('upload/photogallery'),
            'allowed_types' => 'png|jpg|jepg|gif|bmp',
			'max_size'      => '30000',
			'overwrite'     =>  FALSE
            );
		$upload_data = '';
		$image_data = '';
		$this->upload->initialize( $upload_conf );
		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("image"))
        {
            // if upload fail, grab error            
			$this->Model_Media->updatecontent();
			$message =  '<b>Photo Gallery Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Media/viewphotogallery');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$image_data['image'] = $upload_data['file_name'];
			$this->Model_Media->update($image_data);
			$message =  '<b>Photo Gallery Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Media/viewphotogallery');
        }
	}
	public function suspend($photogallery_id)
	{
	    $this->Model_Media->suspend($photogallery_id);
		$message =  '<b>Photo Gallery item suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Media/viewphotogallery');
	}
	public function reactive($photogallery_id)
	{
	    $this->Model_Media->reactive($photogallery_id);
		$message =  '<b>Photo Gallery item reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Media/trashphotogallery');
	}
	
	/* video gallery */
	public function viewvideogallery() 
	{
         $data['allvideogallery'] = $this->Model_Media->getvideogallery();		 
		 $this->load->vars($data);
		 $this->load->view('admin/media/viewvideogallery');            
	}
	public function trashvideogallery() 
	{
         $data['allvideogallery'] = $this->Model_Media->trashvideogallery();		 
		 $this->load->vars($data);
		 $this->load->view('admin/media/trashvideogallery');            
	}
	
	public function addvideogallery() {
		$this->load->view('admin/media/addvideogallery');	 
	}
	public function savevideogallery() {            
			$this->Model_Media->savevideogallery();
			$message =  '<b>Video Gallery Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Media/viewvideogallery');        	
	}
	
	public function editvideogallery($videogallery_id)
	{
	    $data['videogallery'] = $this->Model_Media->getvideogallerybyid($videogallery_id);
		$this->load->view('admin/media/editvideogallery',$data);		
	}
	public function updatevideogallery() {	
			$this->Model_Media->updatevideogallery();
			$message =  '<b>Video Gallery Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Media/viewvideogallery');        
	}
	public function suspendvideogallery($videogallery_id)
	{
	    $this->Model_Media->suspendvideogallery($videogallery_id);
		$message =  '<b>Video Gallery item suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Media/viewvideogallery');
	}
	public function reactivevideogallery($videogallery_id)
	{
	    $this->Model_Media->reactivevideogallery($videogallery_id);
		$message =  '<b>Video Gallery item reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Media/trashvideogallery');
	}
 }