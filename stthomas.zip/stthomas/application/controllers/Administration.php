<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
 class Administration extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
		$this->load->model('Model_Login');
		$this->load->model('Model_Administration');
		if(!$this->Model_Login->is_logged_in())
		{
			redirect('Login');
		}
    }	
	
	/* current administration */
	public function viewcurrentadministration() 
	{
         $data['allcurrentadministration'] = $this->Model_Administration->getcurrentadministration();		 
		 $this->load->vars($data);
		 $this->load->view('admin/administration/viewcurrentadministration');            
	}
	public function trashcurrentadministration() 
	{
         $data['allcurrentadministration'] = $this->Model_Administration->trashcurrentadministration();		 
		 $this->load->vars($data);
		 $this->load->view('admin/administration/trashcurrentadministration');            
	}
	
	public function addcurrentadministration() {
		$this->load->view('admin/administration/addcurrentadministration');	 
	}
	public function savecurrentadministration() {
		$upload_conf = array(
            'upload_path'   => realpath('upload/currentadministration'),
            'allowed_types' => 'png|jpg|jepg|gif|bmp',
			'max_size'      => '30000',
            );
		$upload_data = '';
		$image_data = '';
		$this->upload->initialize( $upload_conf );		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("image"))
        {
            // if upload fail, grab error 
            $error['upload'][] = $this->upload->display_errors();
			$message =  '<b>Please upload image!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Administration/addcurrentadministration');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$image_data['image'] = $upload_data['file_name'];
			$this->Model_Administration->savecurrentadministration($image_data);
			$message =  '<b>Current Administration Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Administration/viewcurrentadministration');
        }		
	}
	
	public function editcurrentadministration($currentadministration_id)
	{
	    $data['currentadministration'] = $this->Model_Administration->getcurrentadministrationbyid($currentadministration_id);
		$this->load->view('admin/administration/editcurrentadministration',$data);		
	}
	public function updatecurrentadministration() {
	    $upload_conf = array(
            'upload_path'   => realpath('upload/currentadministration'),
            'allowed_types' => 'png|jpg|jepg|gif|bmp',
			'max_size'      => '30000',
			'overwrite'     =>  FALSE
            );
		$upload_data = '';
		$image_data = '';
		$this->upload->initialize( $upload_conf );
		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("image"))
        {
            // if upload fail, grab error            
			$this->Model_Administration->updatecontentcurrentadministration();
			$message =  '<b>Current Administration Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Administration/viewcurrentadministration');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$image_data['image'] = $upload_data['file_name'];
			$this->Model_Administration->updatecurrentadministration($image_data);
			$message =  '<b>Current Administration Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Administration/viewcurrentadministration');
        }
	}
	public function suspendcurrentadministration($currentadministration_id)
	{
	    $this->Model_Administration->suspendcurrentadministration($currentadministration_id);
		$message =  '<b>Current Administration item suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Administration/viewcurrentadministration');
	}
	public function reactivecurrentadministration($currentadministration_id)
	{
	    $this->Model_Administration->reactivecurrentadministration($currentadministration_id);
		$message =  '<b>Current Administration item reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Administration/trashcurrentadministration');
	}
   /* current Staff */
	public function viewcurrentstaff() 
	{
         $data['allcurrentstaff'] = $this->Model_Administration->getcurrentstaff();		 
		 $this->load->vars($data);
		 $this->load->view('admin/administration/viewcurrentstaff');            
	}
	public function trashcurrentstaff() 
	{
         $data['allcurrentstaff'] = $this->Model_Administration->trashcurrentstaff();		 
		 $this->load->vars($data);
		 $this->load->view('admin/administration/trashcurrentstaff');            
	}
	
	public function addcurrentstaff() {
		$this->load->view('admin/administration/addcurrentstaff');	 
	}
	public function savecurrentstaff() {
		$upload_conf = array(
            'upload_path'   => realpath('upload/currentstaff'),
            'allowed_types' => 'png|jpg|jepg|gif|bmp',
			'max_size'      => '30000',
            );
		$upload_data = '';
		$image_data = '';
		$this->upload->initialize( $upload_conf );		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("image"))
        {
            // if upload fail, grab error 
            $error['upload'][] = $this->upload->display_errors();
			$message =  '<b>Please upload image!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Administration/addcurrentstaff');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$image_data['image'] = $upload_data['file_name'];
			$this->Model_Administration->savecurrentstaff($image_data);
			$message =  '<b>Current Staff Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Administration/viewcurrentstaff');
        }		
	}
	
	public function editcurrentstaff($currentstaff_id)
	{
	    $data['currentstaff'] = $this->Model_Administration->getcurrentstaffbyid($currentstaff_id);
		$this->load->view('admin/administration/editcurrentstaff',$data);		
	}
	public function updatecurrentstaff() {
	    $upload_conf = array(
            'upload_path'   => realpath('upload/currentstaff'),
            'allowed_types' => 'png|jpg|jepg|gif|bmp',
			'max_size'      => '30000',
			'overwrite'     =>  FALSE
            );
		$upload_data = '';
		$image_data = '';
		$this->upload->initialize( $upload_conf );
		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("image"))
        {
            // if upload fail, grab error            
			$this->Model_Administration->updatecontentcurrentstaff();
			$message =  '<b>Current Staff Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Administration/viewcurrentstaff');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$image_data['image'] = $upload_data['file_name'];
			$this->Model_Administration->updatecurrentstaff($image_data);
			$message =  '<b>Current Staff Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Administration/viewcurrentstaff');
        }
	}
	public function suspendcurrentstaff($currentstaff_id)
	{
	    $this->Model_Administration->suspendcurrentstaff($currentstaff_id);
		$message =  '<b>Current Staff item suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Administration/viewcurrentstaff');
	}
	public function reactivecurrentstaff($currentstaff_id)
	{
	    $this->Model_Administration->reactivecurrentstaff($currentstaff_id);
		$message =  '<b>Current Administration item reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Administration/trashcurrentstaff');
	}
	/* Student Council */
    public function viewstudentcouncil() 
	{
         $data['allstudentcouncil'] = $this->Model_Administration->getstudentcouncil();		 
		 $this->load->vars($data);
		 $this->load->view('admin/administration/viewstudentcouncil');            
	}
	public function trashstudentcouncil() 
	{
         $data['allstudentcouncil'] = $this->Model_Administration->trashstudentcouncil();		 
		 $this->load->vars($data);
		 $this->load->view('admin/administration/trashstudentcouncil');            
	}
	
	public function addstudentcouncil() {
		$this->load->view('admin/administration/addstudentcouncil');	 
	}
	public function savestudentcouncil() {
		$upload_conf = array(
            'upload_path'   => realpath('upload/studentcouncil'),
            'allowed_types' => 'png|jpg|jepg|gif|bmp',
			'max_size'      => '30000',
            );
		$upload_data = '';
		$image_data = '';
		$this->upload->initialize( $upload_conf );		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("image"))
        {
            // if upload fail, grab error 
            $error['upload'][] = $this->upload->display_errors();
			$message =  '<b>Please upload image!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Administration/addstudentcouncil');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$image_data['image'] = $upload_data['file_name'];
			$this->Model_Administration->savestudentcouncil($image_data);
			$message =  '<b>Student Council Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Administration/viewstudentcouncil');
        }		
	}
	
	public function editstudentcouncil($studentcouncil_id)
	{
	    $data['studentcouncil'] = $this->Model_Administration->getstudentcouncilbyid($studentcouncil_id);
		$this->load->view('admin/administration/editstudentcouncil',$data);		
	}
	public function updatestudentcouncil() {
	    $upload_conf = array(
            'upload_path'   => realpath('upload/studentcouncil'),
            'allowed_types' => 'png|jpg|jepg|gif|bmp',
			'max_size'      => '30000',
			'overwrite'     =>  FALSE
            );
		$upload_data = '';
		$image_data = '';
		$this->upload->initialize( $upload_conf );
		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("image"))
        {
            // if upload fail, grab error            
			$this->Model_Administration->updatecontentstudentcouncil();
			$message =  '<b>Student Council Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Administration/viewstudentcouncil');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$image_data['image'] = $upload_data['file_name'];
			$this->Model_Administration->updatestudentcouncil($image_data);
			$message =  '<b>Student Council Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Administration/viewstudentcouncil');
        }
	}
	public function suspendstudentcouncil($studentcouncil_id)
	{
	    $this->Model_Administration->suspendstudentcouncil($studentcouncil_id);
		$message =  '<b>Student Council item suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Administration/viewstudentcouncil');
	}
	public function reactivestudentcouncil($studentcouncil_id)
	{
	    $this->Model_Administration->reactivestudentcouncil($studentcouncil_id);
		$message =  '<b>Student Council item reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Administration/trashstudentcouncil');
	}
    /* Collaborators */
    public function viewcollaborators() 
	{
         $data['allcollaborators'] = $this->Model_Administration->getcollaborators();		 
		 $this->load->vars($data);
		 $this->load->view('admin/administration/viewcollaborators');            
	}
	public function trashcollaborators() 
	{
         $data['allcollaborators'] = $this->Model_Administration->trashcollaborators();		 
		 $this->load->vars($data);
		 $this->load->view('admin/administration/trashcollaborators');            
	}
	
	public function addcollaborators() {
		$this->load->view('admin/administration/addcollaborators');	 
	}
	public function savecollaborators() {
		$upload_conf = array(
            'upload_path'   => realpath('upload/collaborators'),
            'allowed_types' => 'png|jpg|jepg|gif|bmp',
			'max_size'      => '30000',
            );
		$upload_data = '';
		$image_data = '';
		$this->upload->initialize( $upload_conf );		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("image"))
        {
            // if upload fail, grab error 
            $error['upload'][] = $this->upload->display_errors();
			$message =  '<b>Please upload image!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Administration/addcollaborators');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$image_data['image'] = $upload_data['file_name'];
			$this->Model_Administration->savecollaborators($image_data);
			$message =  '<b>Collaborators Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Administration/viewcollaborators');
        }		
	}
	
	public function editcollaborators($collaborators_id)
	{
	    $data['collaborators'] = $this->Model_Administration->getcollaboratorsbyid($collaborators_id);
		$this->load->view('admin/administration/editcollaborators',$data);		
	}
	public function updatecollaborators() {
	    $upload_conf = array(
            'upload_path'   => realpath('upload/collaborators'),
            'allowed_types' => 'png|jpg|jepg|gif|bmp',
			'max_size'      => '30000',
			'overwrite'     =>  FALSE
            );
		$upload_data = '';
		$image_data = '';
		$this->upload->initialize( $upload_conf );
		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("image"))
        {
            // if upload fail, grab error            
			$this->Model_Administration->updatecontentcollaborators();
			$message =  '<b>Student Council Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Administration/viewcollaborators');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$image_data['image'] = $upload_data['file_name'];
			$this->Model_Administration->updatecollaborators($image_data);
			$message =  '<b>Collaborators Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Administration/viewcollaborators');
        }
	}
	public function suspendcollaborators($collaborators_id)
	{
	    $this->Model_Administration->suspendcollaborators($collaborators_id);
		$message =  '<b>Collaborators item suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Administration/viewcollaborators');
	}
	public function reactivecollaborators($collaborators_id)
	{
	    $this->Model_Administration->reactivecollaborators($collaborators_id);
		$message =  '<b>Collaborators item reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Administration/trashcollaborators');
	} 	
	
 }