<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends CI_Controller {
	function __construct()
	  {
		parent::__construct();
        $this->load->model('Model_Login');
		//$this->load->model('model_admin');
		if(!$this->Model_Login->is_logged_in())
		{
			redirect('Login');
		} 		
	  }
   public function index()
	{      	
        $this->load->view('admin/admin_home');
	}
}
?>