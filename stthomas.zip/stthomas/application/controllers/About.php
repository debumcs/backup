<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class About extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
		$this->load->model('Model_Login');
		$this->load->model('Model_About');
		if(!$this->Model_Login->is_logged_in())
		{
			redirect('Login');
		}
    }	
	
	// Aboutus overview 
	
	public function aboutus()
	{
		$data['aboutcontent'] = $this->Model_About->get_aboutus();
		$this->load->vars($data);
		$this->load->view('admin/aboutus/aboutus');
	}	
	
	public function updateaboutus() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_About->update_aboutus();
			$message =  '<b>Aboutus text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('About/aboutus');
		} 
	}

   // Aboutus our legacy 
	
	public function ourlegacy()
	{
		$data['aboutcontent'] = $this->Model_About->get_ourlegacy();
		$this->load->vars($data);
		$this->load->view('admin/aboutus/ourlegacy');
	}	
	
	public function updateourlegacy() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_About->update_ourlegacy();
			$message =  '<b>Aboutus text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('About/ourlegacy');
		} 
	}	
	// Aboutus the founders 
	
	public function thefounders()
	{
		$data['aboutcontent'] = $this->Model_About->get_thefounders();
		$this->load->vars($data);
		$this->load->view('admin/aboutus/thefounders');
	}	
	
	public function updatethefounders() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_About->update_thefounders();
			$message =  '<b>Aboutus text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('About/thefounders');
		} 
	}
	// Aboutus affiliations 
	
	public function affiliations()
	{
		$data['aboutcontent'] = $this->Model_About->get_affiliations();
		$this->load->vars($data);
		$this->load->view('admin/aboutus/affiliations');
	}	
	
	public function updateaffiliations() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_About->update_affiliations();
			$message =  '<b>Aboutus text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('About/affiliations');
		} 
	}
	// Aboutus infrastructure
	
	public function infrastructure()
	{
		$data['aboutcontent'] = $this->Model_About->get_infrastructure();
		$this->load->vars($data);
		$this->load->view('admin/aboutus/infrastructure');
	}	
	
	public function updateinfrastructure() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_About->update_infrastructure();
			$message =  '<b>Aboutus text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('About/infrastructure');
		} 
	}
	// Aboutus cbsc guidelines
	
	public function cbscguidelines()
	{
		$data['aboutcontent'] = $this->Model_About->get_cbscguidelines();
		$this->load->vars($data);
		$this->load->view('admin/aboutus/cbscguidelines');
	}	
	
	public function updatecbscguidelines() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_About->update_cbscguidelines();
			$message =  '<b>Aboutus text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('About/cbscguidelines');
		} 
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */