<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
 class Learning extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
		$this->load->model('Model_Login');
		$this->load->model('Model_Learning');
		if(!$this->Model_Login->is_logged_in())
		{
			redirect('Login');
		}
    }
	
	/* Learning */
	public function viewlearning() 
	{
         $data['alllearning'] = $this->Model_Learning->getlearning();		 
		 $this->load->vars($data);
		 $this->load->view('admin/learning/viewlearning');            
	}
	public function trashlearning() 
	{
         $data['alllearning'] = $this->Model_Learning->trashlearning();		 
		 $this->load->vars($data);
		 $this->load->view('admin/learning/trashlearning');            
	}
	
	public function addlearning() {
		$this->load->view('admin/learning/addlearning');	 
	}
	public function savelearning() {
		$upload_conf = array(
            'upload_path'   => realpath('upload/learning'),
            'allowed_types' => 'png|jpg|jepg|gif|bmp',
			'max_size'      => '30000',
            );
		$upload_data = '';
		$image_data = '';
		$this->upload->initialize( $upload_conf );		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("image"))
        {
            // if upload fail, grab error 
            $error['upload'][] = $this->upload->display_errors();
			$message =  '<b>Please upload image!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Learning/addlearning');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$image_data['image'] = $upload_data['file_name'];
			$this->Model_Learning->savelearning($image_data);
			$message =  '<b>Learning Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Learning/viewlearning');
        }		
	}
	
	public function editlearning($learning_id)
	{
	    $data['learning'] = $this->Model_Learning->getlearningbyid($learning_id);
		$this->load->view('admin/learning/editlearning',$data);		
	}
	public function updatelearning() {
	    $upload_conf = array(
            'upload_path'   => realpath('upload/learning'),
            'allowed_types' => 'png|jpg|jepg|gif|bmp',
			'max_size'      => '30000',
			'overwrite'     =>  FALSE
            );
		$upload_data = '';
		$image_data = '';
		$this->upload->initialize( $upload_conf );
		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("image"))
        {
            // if upload fail, grab error            
			$this->Model_Learning->updatecontentlearning();
			$message =  '<b>Learning Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Learning/viewlearning');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$image_data['image'] = $upload_data['file_name'];
			$this->Model_Learning->updatelearning($image_data);
			$message =  '<b>Learning Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Learning/viewlearning');
        }
	}
	public function suspendlearning($learning_id)
	{
	    $this->Model_Learning->suspendlearning($learning_id);
		$message =  '<b>Learning item suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Learning/viewlearning');
	}
	public function reactivelearning($learning_id)
	{
	    $this->Model_Learning->reactivelearning($learning_id);
		$message =  '<b>Learning item reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Learning/trashlearning');
	}	
	
 }