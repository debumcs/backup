<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Settings extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
		$this->load->model('Model_Login');
		$this->load->model('Model_Settings');
		if(!$this->Model_Login->is_logged_in())
		{
			redirect('Login');
		}
    }
		
	public function changepassword() {
		$this->load->view('admin/settings/change_password');	 
	}
	
	public function updatepassword() {
		$this->form_validation->set_rules('pre_password', 'Previous Password', 'required');
		$this->form_validation->set_rules('new_password', 'New Password', 'required');
		$this->form_validation->set_rules('con_password', 'Confirm Password', 'required');
		
		if ($this->form_validation->run() == FALSE)
		{
			return false;
		}
		else
		{
			$this->Model_Settings->update_password();
			redirect('Settings/changepassword/');
		} 
	}
	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */