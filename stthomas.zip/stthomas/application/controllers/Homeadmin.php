<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
 class Homeadmin extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
		$this->load->model('Model_Login');
		$this->load->model('Model_Home');
		if(!$this->Model_Login->is_logged_in())
		{
			redirect('Login');
		}
    }
	//Home Banner
	public function viewbanner() 
	{
         $data['allbanner'] = $this->Model_Home->getbanner();		 
		 $this->load->vars($data);
		 $this->load->view('admin/home/viewbanner');            
	}
	public function trashbanner() 
	{
         $data['allbanner'] = $this->Model_Home->trashbanner();		 
		 $this->load->vars($data);
		 $this->load->view('admin/home/trashbanner');            
	}
	public function addbanner() {
		$this->load->view('admin/home/addbanner');	 
	}
	public function save() {
		$upload_conf = array(
            'upload_path'   => realpath('upload/banner'),
            'allowed_types' => 'png|jpg|jepg|gif|bmp',
			'max_size'      => '30000',
            );
		$upload_data = '';
		$image_data = '';
		$this->upload->initialize( $upload_conf );		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("image"))
        {
            // if upload fail, grab error 
            $error['upload'][] = $this->upload->display_errors();
			$message =  '<b>Please upload image!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Homeadmin/addbanner');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$image_data['image'] = $upload_data['file_name'];
			$this->Model_Home->save($image_data);
			$message =  '<b>Banner Data Saved Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Homeadmin/viewbanner');
        }		
	}
	public function editbanner($banner_id)
	{
	    $data['banner'] = $this->Model_Home->getbannerbyid($banner_id);
		$this->load->view('admin/home/editbanner',$data);		
	}
	public function update() {
	    $upload_conf = array(
            'upload_path'   => realpath('upload/banner'),
            'allowed_types' => 'png|jpg|jepg|gif|bmp',
			'max_size'      => '30000',
			'overwrite'     =>  FALSE
            );
		$upload_data = '';
		$image_data = '';
		$this->upload->initialize( $upload_conf );
		
        $error = array();
        $success = array();
		if ( ! $this->upload->do_upload("image"))
        {
            // if upload fail, grab error            
			$this->Model_Home->updatecontent();
			$message =  '<b>Banner Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Homeadmin/viewbanner');
        }
        else
        {
            $upload_data = $this->upload->data();               
			$image_data['image'] = $upload_data['file_name'];
			$this->Model_Home->update($image_data);
			$message =  '<b>Banner Updated Successfully!</b>';
			$this->session->set_flashdata('MESSAGE', $message);
			redirect('Homeadmin/viewbanner');
        }
	}
	public function suspend($banner_id)
	{
	    $this->Model_Home->suspend($banner_id);
		$message =  '<b>Banner item suspended!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Homeadmin/viewbanner');
	}
	public function reactive($banner_id)
	{
	    $this->Model_Home->reactive($banner_id);
		$message =  '<b>Banner item reactived!</b>';
		$this->session->set_flashdata('MESSAGE', $message);
		redirect('Homeadmin/trashbanner');
	}
	//Home Content
	public function homecontent()
	{
		$data['homecontent'] = $this->Model_Home->get_homecontent();
		$this->load->vars($data);
		$this->load->view('admin/home/homecontent');
	}
	public function updatehomecontent() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_Home->update_homecontent();
			$message =  '<b>Home Content text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Homeadmin/homecontent');
		} 
	}
 }