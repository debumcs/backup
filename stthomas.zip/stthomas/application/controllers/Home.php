<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
       //banner image 		
		$this->load->model('Model_Home');
		$data['allbanner'] = $this->Model_Home->getbannerfront();
		$this->load->vars($data);
		//Home Content 
		$data['allhomecontent'] = $this->Model_Home->get_homecontent();
		$this->load->vars($data);
		$this->load->view('index');
		
	}
	//About Us
	public function about()
	{
		$this->load->view('about');
	}
	public function overview()
	{
		$this->load->model('Model_About');
		$data['alloverview'] = $this->Model_About->get_aboutus();
		$this->load->vars($data);
		$this->load->view('overview');
	}
	public function ourlegacy()
	{
		$this->load->model('Model_About');
		$data['alllegacy'] = $this->Model_About->get_ourlegacy();
		$this->load->vars($data);
		$this->load->view('ourlegacy');
	}
	public function affiliations()
	{
		$this->load->model('Model_About');
		$data['allaffiliations'] = $this->Model_About->get_affiliations();
		$this->load->vars($data);
		$this->load->view('affiliations');
	}
	public function infrastructure()
	{
		$this->load->model('Model_About');
		$data['allinfrastructure'] = $this->Model_About->get_infrastructure();
		$this->load->vars($data);
		$this->load->view('infrastructure');
	}
	//Rules
	public function disandrules()
	{
		$this->load->model('Model_Rules');
		$data['alldisandrules'] = $this->Model_Rules->get_disandrules();
		$this->load->vars($data);
		$this->load->view('disandrules');
	}
	public function concerningabsence()
	{
		$this->load->model('Model_Rules');
		$data['allconcerningabsence'] = $this->Model_Rules->get_rulesconcerning();
		$this->load->vars($data);
		$this->load->view('concerningabsence');
	}
	public function generalrules()
	{
		$this->load->model('Model_Rules');
		$data['allgeneralrules'] = $this->Model_Rules->get_generalrules();
		$this->load->vars($data);
		$this->load->view('generalrules');
	}
	public function feesrules()
	{
		$this->load->model('Model_Rules');
		$data['allfeesrules'] = $this->Model_Rules->get_feesrules();
		$this->load->vars($data);
		$this->load->view('feesrules');
	}
	public function parentsinstructions()
	{ 
	    $this->load->model('Model_Rules');
		$data['allparentsinstructions'] = $this->Model_Rules->get_parentsinstructions();
		$this->load->vars($data);
		$this->load->view('parentsinstructions');
	}
	public function assessmentcriteria()
	{
		$this->load->model('Model_Rules');
		$data['allassessmentcriteria'] = $this->Model_Rules->get_assessmentcriteria();
		$this->load->vars($data);
		$this->load->view('assessmentcriteria');
	}
	// Beyond Classroom
	public function sports()
	{
		$this->load->model('Model_Beyondclassroom');
		$data['allsports'] = $this->Model_Beyondclassroom->get_sports();
		$this->load->vars($data);
		$this->load->view('sports');
	}
	public function artculture()
	{
		$this->load->model('Model_Beyondclassroom');
		$data['allartculture'] = $this->Model_Beyondclassroom->get_artculture();
		$this->load->vars($data);
		$this->load->view('artculture');
	}
	public function library()
	{
		$this->load->model('Model_Beyondclassroom');
		$data['alllibrary'] = $this->Model_Beyondclassroom->get_library();
		$this->load->vars($data);
		$this->load->view('library');
	}
	// School Services
	public function schooltiming()
	{
		$this->load->model('Model_Schoolservices');
		$data['allschooltiming'] = $this->Model_Schoolservices->get_schooltiming();
		$this->load->vars($data);
		$this->load->view('schooltiming');
	}
	
	public function contact()
	{	
		$this->load->view('contact');
	}
	public function sendmailfooter() { 
         $from_email = "vikrant@designdot.co.in"; 
         $to_email = $this->input->post('email'); 
		 $from_name = $this->input->post('name');
         $phone = $this->input->post('phone'); 		
		 $message = $this->input->post('message'); 
         $msg = '<html>
			<body>
			<table width="500" border="0" align="center" bgcolor="#000000" cellspacing="0" cellpadding="0">
			  <tr>
				<td width="25">&nbsp;</td>
				<td width="25">&nbsp;</td>
				<td width="700"  align="center"></td>
				<td width="25">&nbsp;</td>
				<td width="25">&nbsp;</td>
			  </tr>
			  <tr>
				<td>&nbsp;</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td bgcolor="#CCCCCC" height = "50">&nbsp;</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>
			  
			  <tr>
				<td>&nbsp;</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td bgcolor="#CCCCCC" align="left" width="700">
			
					<table width="100%" border="0">
					  <tr>
						<td width="20%" height="40">Name</td>
						<td width="80%"><font color="#3333FF">'.$from_name.'</font></td>						
					  </tr>
					  	  
					</table>
				
				</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>
			  <tr>
				<td>&nbsp;</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td bgcolor="#CCCCCC" align="left" width="700">
			
					<table width="100%" border="0">
					  <tr>						
						<td width="20%">Email</td>
						<td width="80%"><font color="#3333FF">'.$to_email.'</font></td>
					  </tr>
					  	  
					</table>
				
				</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>
			  
			  <tr>
				<td>&nbsp;</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td bgcolor="#CCCCCC" align="left" width="700">
			
					<table width="100%" border="0">
					  <tr>
						<td width="20%" height="40">Phone No.</td>
						<td width="80%"><font color="#3333FF">'.$phone.'</font></td>
						
					  </tr>
					  	  
					</table>
				
				</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>	

              <tr>
				<td>&nbsp;</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td bgcolor="#CCCCCC" align="left" width="700">
			
					<table width="100%" border="0">
					  <tr>						
						<td width="20%">Message</td>
						<td width="80%"><font color="#3333FF">'.$message.'</font></td>
					  </tr>					  	  
					</table>
				
				</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>			  
			  			  		  
			  <tr>
				<td>&nbsp;</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td bgcolor="#CCCCCC" align="left" height="39" width="700"></td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>
			  			  
			  <tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td width="755"  align="center">&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>
			</table>';			
   
         //Load email library 
         $this->load->library('email'); 
   
         $this->email->from($from_email, $from_name); 
         $this->email->to($to_email);
         $this->email->subject('Request a quote from St Thomas School'); 
         $this->email->message($msg);         
         //Send mail 
         if($this->email->send()) {			 
			redirect('successenquiry');
		 }
         else {
			redirect('failuresenquiry');
		 }
      } 
	  public function sendmailcontact() { 
         $from_email = "vikrant@designdot.co.in"; 
         $to_email = $this->input->post('email'); 
		 $from_name = $this->input->post('name');
         $phone = $this->input->post('phone'); 	
		 $subject = $this->input->post('subject'); 	
		 $category = $this->input->post('category'); 
		 $message = $this->input->post('message'); 
         $msg = '<html>
			<body>
			<table width="800" border="0" align="center" bgcolor="#000000" cellspacing="0" cellpadding="0">
			  <tr>
				<td width="25">&nbsp;</td>
				<td width="25">&nbsp;</td>
				<td width="700"  align="center"></td>
				<td width="25">&nbsp;</td>
				<td width="25">&nbsp;</td>
			  </tr>
			  <tr>
				<td>&nbsp;</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td bgcolor="#CCCCCC" height = "50">&nbsp;</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>
			  
			  <tr>
				<td>&nbsp;</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td bgcolor="#CCCCCC" align="left" width="700">
			
					<table width="100%" border="0">
					  <tr>
						<td width="15%" height="40">Name</td>
						<td width="35%"><font color="#3333FF">'.$from_name.'</font></td>
						<td width="15%" height="40">Email</td>
						<td width="35%"><font color="#3333FF">'.$to_email.'</font></td>	
					  </tr>
					  	  
					</table>
				
				</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>
			  <tr>
				<td>&nbsp;</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td bgcolor="#CCCCCC" align="left" width="700">
			
					<table width="100%" border="0">
					  <tr>						
						<td width="15%">Phone No.</td>
						<td width="35%"><font color="#3333FF">'.$phone.'</font></td>
						<td width="15%">Subject.</td>
						<td width="35%"><font color="#3333FF">'.$subject.'</font></td>
					  </tr>
					  	  
					</table>
				
				</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>
			  
			  <tr>
				<td>&nbsp;</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td bgcolor="#CCCCCC" align="left" width="700">
			
					<table width="100%" border="0">
					  <tr>
						<td width="15%" height="40">Category</td>
						<td width="85%"><font color="#3333FF">'.$category.'</font></td>
						
					  </tr>
					  	  
					</table>
				
				</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>	

              <tr>
				<td>&nbsp;</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td bgcolor="#CCCCCC" align="left" width="700">
			
					<table width="100%" border="0">
					  <tr>						
						<td width="15%">Message</td>
						<td width="85%"><font color="#3333FF">'.$message.'</font></td>
					  </tr>					  	  
					</table>
				
				</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>			  
			  			  		  
			  <tr>
				<td>&nbsp;</td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td bgcolor="#CCCCCC" align="left" height="39" width="700"></td>
				<td bgcolor="#CCCCCC" >&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>
			  			  
			  <tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td width="755"  align="center">&nbsp;</td>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
			  </tr>
			</table>';			
   
         //Load email library 
         $this->load->library('email'); 
   
         $this->email->from($from_email, $from_name); 
         $this->email->to($to_email);
         $this->email->subject('Request a quote from St Thomas School'); 
         $this->email->message($msg);         
         //Send mail 
         if($this->email->send()) {			 
			redirect('successenquiry');
		 }
         else {
			redirect('failuresenquiry');
		 }
      } 
	 
	public function successenquiry()
	{	
		$this->load->view('successenquiry');
	}
	public function failureenquiry()
	{	
		$this->load->view('failureenquiry');
	}
	public function signin()
	{	
		$this->load->view('signin');
	}
}