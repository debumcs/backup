<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Schoolservices extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
		$this->load->model('Model_Login');
		$this->load->model('Model_Schoolservices');
		if(!$this->Model_Login->is_logged_in())
		{
			redirect('Login');
		}
    }	
	
	// School Timing	
	public function schooltiming()
	{
		$data['schooltiming'] = $this->Model_Schoolservices->get_schooltiming();
		$this->load->vars($data);
		$this->load->view('admin/schoolservices/schooltiming');
	}	
	
	public function updateschooltiming() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_Schoolservices->update_schooltiming();
			$message =  '<b>School Timing text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Schoolservices/schooltiming');
		} 
	}	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */