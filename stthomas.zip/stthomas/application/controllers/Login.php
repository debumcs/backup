<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {
	function __construct()
	  {
		parent::__construct();
		$this->load->model('Model_Login');		
	  }
	public function index()
	{	        
	      		
        $this->load->view('login');
	}
	public function login_check() {
		/*echo $this->input->post('username'); 
		echo $this->input->post("password");
		die();*/		
		$this->form_validation->set_rules('username', 'Username', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');

		if ($this->form_validation->run() == FALSE)
		{
			$message =  '<b>User name or password information wrong!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Login/index');
		}
		else
		{
			if($this->Model_Login->login($this->input->post('username'), $this->input->post("password"))){
				$message =  '<b>Login successful!</b>';
		  		$this->session->set_flashdata('MESSAGE', $message);
				redirect('Admin');
			}
			else{
				$message =  '<b>User name or or password information wrong!</b>';
		  		$this->session->set_flashdata('MESSAGE', $message);
				redirect('Login/index');
			}
			
			
		}
	}
	function logout()
	{
		$this->session->sess_destroy();
		redirect('Login');
	}	
   
}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */