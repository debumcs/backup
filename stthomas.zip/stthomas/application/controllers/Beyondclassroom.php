<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
 class Beyondclassroom extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
		$this->load->model('Model_Login');
		$this->load->model('Model_Beyondclassroom');
		if(!$this->Model_Login->is_logged_in())
		{
			redirect('Login');
		}
    }
	
	/* Sports */
	public function sports()
	{
		$data['sports'] = $this->Model_Beyondclassroom->get_sports();
		$this->load->vars($data);
		$this->load->view('admin/beyondclassroom/sports');
	}	
	
	public function updatesports() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_Beyondclassroom->update_sports();
			$message =  '<b>Sports text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Beyondclassroom/sports');
		} 
	}
	/* Art & Culture */
	public function artculture()
	{
		$data['artculture'] = $this->Model_Beyondclassroom->get_artculture();
		$this->load->vars($data);
		$this->load->view('admin/beyondclassroom/artculture');
	}	
	
	public function updateartculture() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_Beyondclassroom->update_artculture();
			$message =  '<b>Art & Culture text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Beyondclassroom/artculture');
		} 
	}
	/* Library */
	public function library()
	{
		$data['library'] = $this->Model_Beyondclassroom->get_library();
		$this->load->vars($data);
		$this->load->view('admin/beyondclassroom/library');
	}	
	
	public function updatelibrary() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_Beyondclassroom->update_library();
			$message =  '<b>Library text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Beyondclassroom/library');
		} 
	}
 }