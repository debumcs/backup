<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Admission extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
		$this->load->model('Model_Login');
		$this->load->model('Model_Admission');
		if(!$this->Model_Login->is_logged_in())
		{
			redirect('Login');
		}
    }	
	
	// Admission Criteria 	
	public function admissioncriteria()
	{
		$data['admissioncriteria'] = $this->Model_Admission->get_admissioncriteria();
		$this->load->vars($data);
		$this->load->view('admin/admission/admissioncriteria');
	}	
	
	public function updateadmissioncriteria() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_Admission->update_admissioncriteria();
			$message =  '<b>Admission Criteria text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Admission/admissioncriteria');
		} 
	}	
    // Admission Fees 
    public function admissionfees()
	{
		$data['admissionfees'] = $this->Model_Admission->get_admissionfees();
		$this->load->vars($data);
		$this->load->view('admin/admission/admissionfees');
	}	
	
	public function updateadmissionfees() {
	    $this->form_validation->set_rules('content', 'Content', 'trim|required|xss_clean');
		if ($this->form_validation->run() == FALSE)
		{
			return false;			
		}
		else
		{
			$this->Model_Admission->update_admissionfees();
			$message =  '<b>Admission Fees text updated successfully!</b>';
		  	$this->session->set_flashdata('MESSAGE', $message);
			redirect('Admission/admissionfees');
		} 
	}		
	
			
	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */