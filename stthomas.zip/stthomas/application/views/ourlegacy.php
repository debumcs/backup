<?php $this->load->view('header1'); ?>
<!-- start banner -->
<div class="banner">
	<img src="images/img_about.jpg" width="1366" height="717" alt="about">
</div>
<!-- end banner -->
<!-- start main-container -->
<div class="main-container">
	<div class="container-box">
		<!-- start content -->
		<div class="content">
			<h1>Our Legacy</h1>
			<?php echo $alllegacy['content']; ?>			
		</div>
		<!-- end content -->
	</div>
</div>
<!-- end main-container -->
<?php $this->load->view('footer'); ?>