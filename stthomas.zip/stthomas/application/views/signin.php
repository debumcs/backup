<?php $this->load->view('header1'); ?>
<!-- start main-container -->

<div class="main-container">
	<div class="container-box">
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<!-- start signin -->
				<div class="signin">
					<div class="form">
						<form action="#">
							<div class="heading">
								<h3>Sign In</h3>
								<p>Already Registered ? Sign In below :</p>
							</div>
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Username">
							</div>
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Password">
							</div>
							<div class="checkbox">
		                       <label><input type="checkbox" value="">Keep me signed in</label>
		                    </div>
							<a href="my-account.html" title="SIGN IN" class="btn btn-primary">SIGN IN</a>
						</form>
					</div>
				</div>
				<!-- end signin -->
			</div>
		</div>
	</div>
</div>
<!-- end main-container -->
<?php $this->load->view('footer'); ?>