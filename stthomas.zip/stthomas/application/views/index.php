<?php $this->load->view('header'); ?>
<!-- start showcase -->
<div class="showcase">
	<ul class="slides">
	    <?php foreach($allbanner as $bannerdetails){ static $i = 0;?>
		<li>
			<img src="<?php echo base_url().$bannerdetails['image']; ?>" width="1366" height="685" alt="slide">
			<div class="slide-caption">
				<img src="images/img_main_slider_caption.png" width="94" height="94" alt="caption">
				<h4><?php echo $bannerdetails['bannertitle']; ?></h4>
				<p><?php echo $bannerdetails['bannersubtitle']; ?></p>
			</div>
		</li>
		<?php $i++; } ?>
	</ul>
	<!-- start caption -->
	<div class="caption">
		<!-- start logo -->
		<div class="logo">
			<a href="<?php echo base_url(); ?>index" title="St Thomas"><img src="images/logo.png" width="121" height="120" alt="St Thomas"></a>
		</div>
		<!-- end logo -->
		<!-- start navigation3 -->
		<div class="navigation3">
			<ul>
				<li><a href="#">Learning <i class="fa fa-plus" aria-hidden="true"></i></a></li>
				<li><a href="#">BEYOND THE CLASSROOM <i class="fa fa-plus" aria-hidden="true"></i></a></li>
				<li><a href="#">ENROLMENTS <i class="fa fa-plus" aria-hidden="true"></i></a></li>
				<li><a href="#">SCHOOL SERVICES <i class="fa fa-plus" aria-hidden="true"></i></a></li>
			</ul>
		</div>
		<!-- end navigation3 -->
		<!-- start social -->
		<div class="social">
			<ul>
				<li><a href="#" title="Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
				<li><a href="#" title="Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
				<li><a href="#" title="Linkedin"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
				<li><a href="#" title="Youtube"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
			</ul>
		</div>
		<!-- end social -->
	</div>
	<!-- end caption -->
</div>

<!-- end showcase -->
<!-- start about-text -->
<div class="about-text">
	<div class="container-box">
		<div class="row">
			<div class="col-md-10 col-md-offset-1 col-lg-6 col-lg-offset-3">
				<h3>Today our school boasts of an enrollment of <span>nearly 2000 students.</span></h3>
				<?php echo $allhomecontent['content']; ?>
			</div>
		</div>
	</div>
</div>
<!-- end about-text -->
<!-- start about-img-slider -->
<div class="about-img-slider">
	<div class="container-box">
		<div class="row">
			<div class="col-md-10 col-md-offset-1 position-static">
				<div class="about-slider hidden-xs">
					<ul class="slides">
						<li>
							<div class="row">
								<div class="col-sm-6">
									<div class="imgb">
										<img src="images/img_slider_about1.jpg" width="498" height="237" alt="about">
									</div>
								</div>
								<div class="col-sm-6">
									<div class="imgb">
										<img src="images/img_slider_about2.jpg" width="498" height="237" alt="about">
									</div>
								</div>
							</div>
						</li>
						<li>
							<div class="row">
								<div class="col-sm-6">
									<div class="imgb">
										<img src="images/img_slider_about1.jpg" width="498" height="237" alt="about">
									</div>
								</div>
								<div class="col-sm-6">
									<div class="imgb">
										<img src="images/img_slider_about2.jpg" width="498" height="237" alt="about">
									</div>
								</div>
							</div>
						</li>
					</ul>
				</div>
				<div class="about-slider-mb visible-xs">
					<ul class="slides">
						<li>
							<div class="row">
								<div class="col-md-12">
									<div class="imgb">
										<img src="images/img_slider_about1.jpg" width="498" height="237" alt="about">
									</div>
								</div>
							</div>
						</li>
						<li>
							<div class="row">
								<div class="col-md-12">
									<div class="imgb">
										<img src="images/img_slider_about2.jpg" width="498" height="237" alt="about">
									</div>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- end about-img-slider -->
<!-- start multiple-slider -->
<div class="multiple-slider">
	<div class="container-box">
		<div class="row">
			<div class="col-md-10 col-md-offset-1 position-static">
				<div class="multiple-slider-box">
					<ul class="slides">
						<li>
							<div class="row">
								<div class="col-sm-5">
									<div class="txtb">
										<h3>Early Learning</h3>
										<h4>Playgroup to 4 Year olds</h4>
										<p>The dynamic Early Learning Centre, St Thomas School programs aim to create confident, independent learners who can also work well in a group. Children are encouraged to think independently, to embrace new challenges, to work collaboratively, to build new friendships and to celebrate their successes.</p>
										<a href="#" title="Read More" class="btn">Read More</a>
									</div>
								</div>
								<div class="col-sm-7">
									<div class="pull-right">
										<div class="row">
											<div class="col-sm-6">
												<div class="column gap-none">
													<div class="img-slider">
														<ul class="slides2">
															<li><img src="images/img_mult_slide1.jpg" width="265" height="265" alt="slider"></li>
															<li><img src="images/img_mult_slide1.jpg" width="265" height="265" alt="slider"></li>
														</ul>
													</div>
												</div>
											</div>
											<div class="col-sm-6">
												<div class="column">
													<div class="column-in">
														<h5>Play Group</h5>
														<p>St Stomas Playgroup invites girls & boys aged 0-3 yrs to meet weekly with thier parents during the school terms.</p>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-sm-6">
												<div class="column">
													<div class="column-in">
														<h5>Learning Framework</h5>
														<p>Who we determines how we learn. At St Thomas we encourage your child to wander to wonder, to be stimulated by thier surroundings, by new ideas and friendships.</p>
													</div>
												</div>
											</div>
											<div class="col-sm-6">
												<div class="column">
													<div class="column-in">
														<h5>Enrolments</h5>
														<p>We all pleased that you are considering enroling your daughter at St Thomas, and hope that it will be the begining of a long and happy friendship.</p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</li>
						<li>
							<div class="row">
								<div class="col-sm-5">
									<h3>Early Learning</h3>
									<h4>Playgroup to 4 Year olds</h4>
									<p>The dynamic Early Learning Centre, St Thomas School programs aim to create confident, independent learners who can also work well in a group. Children are encouraged to think independently, to embrace new challenges, to work collaboratively, to build new friendships and to celebrate their successes.</p>
									<a href="#" title="Read More" class="btn">Read More</a>
								</div>
								<div class="col-sm-7">
									<div class="pull-right">
										<div class="row">
											<div class="col-sm-6">
												<div class="column gap-none">
													<div class="img-slider">
														<ul class="slides2">
															<li><img src="images/img_mult_slide1.jpg" width="265" height="265" alt="slider"></li>
															<li><img src="images/img_mult_slide1.jpg" width="265" height="265" alt="slider"></li>
														</ul>
													</div>
												</div>
											</div>
											<div class="col-sm-6">
												<div class="column">
													<div class="column-in">
														<h5>Play Group</h5>
														<p>St Stomas Playgroup invites girls & boys aged 0-3 yrs to meet weekly with thier parents during the school terms.</p>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-sm-6">
												<div class="column">
													<div class="column-in">
														<h5>Learning Framework</h5>
														<p>Who we determines how we learn. At St Thomas we encourage your child to wander to wonder, to be stimulated by thier surroundings, by new ideas and friendships.</p>
													</div>
												</div>
											</div>
											<div class="col-sm-6">
												<div class="column">
													<div class="column-in">
														<h5>Enrolments</h5>
														<p>We all pleased that you are considering enroling your daughter at St Thomas, and hope that it will be the begining of a long and happy friendship.</p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- end multiple-slider -->
<!-- start campus-slider -->
<div class="campus-slider">
	<div class="campus-slider-dk hidden-xs">
		<ul class="slides">
			<li>
				<div class="container-fluid">
					<div class="row">
						<div class="col-ms-12 padding-left-none padding-right-none">
							<div class="imgb">
								<img src="images/img_campus1.jpg" width="447" height="450" alt="campus">
							</div>
							<div class="imgb">
								<img src="images/img_campus2.jpg" width="447" height="450" alt="campus">
							</div>
							<div class="imgb">
								<img src="images/img_campus3.jpg" width="447" height="450" alt="campus">
							</div>
						</div>
					</div>
				</div>
			</li>
			<li>
				<div class="container-fluid">
					<div class="row">
						<div class="col-ms-12 padding-left-none padding-right-none">
							<div class="imgb">
								<img src="images/img_campus1.jpg" width="447" height="450" alt="campus">
							</div>
							<div class="imgb">
								<img src="images/img_campus2.jpg" width="447" height="450" alt="campus">
							</div>
							<div class="imgb">
								<img src="images/img_campus3.jpg" width="447" height="450" alt="campus">
							</div>
						</div>
					</div>
				</div>
			</li>
		</ul>
	</div>
	<div class="campus-slider-mb visible-xs">
		<ul class="slides">
			<li>
				<div class="container-fluid">
					<div class="row">
						<div class="col-ms-12 padding-left-none padding-right-none">
							<div class="imgb">
								<img src="images/img_campus1.jpg" width="447" height="450" alt="campus">
							</div>
						</div>
					</div>
				</div>
			</li>
			<li>
				<div class="container-fluid">
					<div class="row">
						<div class="col-ms-12 padding-left-none padding-right-none">
							<div class="imgb">
								<img src="images/img_campus2.jpg" width="447" height="450" alt="campus">
							</div>
						</div>
					</div>
				</div>
			</li>
			<li>
				<div class="container-fluid">
					<div class="row">
						<div class="col-ms-12 padding-left-none padding-right-none">
							<div class="imgb">
								<img src="images/img_campus3.jpg" width="447" height="450" alt="campus">
							</div>
						</div>
					</div>
				</div>
			</li>
		</ul>
	</div>
</div>
<!-- end campus-slider -->
<!-- start campus-txtb -->
<div class="campus-txtb">
	<div class="container-box">
		<div class="row">
			<div class="col-sm-4">
				<div class="column">
					<h4>Our Campus</h4>
					<p>St. Thomas School is an ideal setting for learning: a diverse community knit together by its physical environment as well as by its commitment to the highest standards of excellence, integrity, free expression and inquiry.</p>
					<p>The school sprawls over a two-acre campus nestled on the outskirts of Bahadurgarh. a peaceful town which is growing very fast. The town’s uniqueness lies in the fact that it retains its small town charm even though it’s just a stone's throw away from New Delhi.</p>
				</div>
			</div>
			<div class="col-sm-4">
				<div class="column">
					<h4>Our Staff</h4>
					<p>STS has a well-qualified, diligent, dedicated and experienced staff.</p>
					<p>The administrative team provides leadership toward the achievement of the school’s strategic initiatives and vision. The school’s dedicated staff help ensure professional management of resources and facilities. Together, we form a team that focuses on the care and education of our students, in partnership with parents.</p>
				</div>
			</div>
			<div class="col-sm-4">
				<div class="column">
					<h4>Our Transport</h4>
					<p>The school has its own fleet of buses, which cover most parts of the town. To avail these services please contact the Administrative team.</p>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- end campus-txtb -->
<?php $this->load->view('footer'); ?>