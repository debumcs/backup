<html>
<head>
<meta charset="UTF-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, , initial-scale=1.0" name="viewport">
<title>St Thomas</title>
<link href="<?php print base_url();?>css/style.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="<?php print base_url();?>js/jquery.flexslider.js"></script>
<script src="<?php print base_url();?>js/script.js"></script>
<script>
$(document).ready(function() {
	/*/////////////////////////////
	  Header Fixed
	/////////////////////////////*/
	$(window).scroll(function(){
		if ($(this).scrollTop() > 590) {
			$('.header').addClass('fixed');
		} else {
			$('.header').removeClass('fixed');
		}
	});
});
</script>
</head>
<body>
<!-- start navigation -->
<div class="navigation">
	<div class="container-box">
		<ul>
			<li class="panel-link"><a href="<?php print base_url();?>signin" title="MY PANEL">MY PANEL</a></li>
			<li class="hidden-xs">
				<a href="<?php print base_url();?>about" title="ABOUT">ABOUT</a>
				<div class="dd">
					<ul>
						<li><a href="<?php print base_url();?>overview" title="Overview">Overview</a></li>
						<li><a href="<?php print base_url();?>ourlegacy" title="Our Legacy">Our Legacy</a></li>
						<li><a href="#" title="The Founders">The Founders</a></li>
						<li><a href="<?php print base_url();?>affiliations" title="Affiliations">Affiliations</a></li>
						<li><a href="<?php print base_url();?>infrastructure" title="Infrastructure">Infrastructure</a></li>
						<li><a href="#" title="CBSC Guidelines">CBSC Guidelines</a></li>
					</ul>
				</div>
			</li>
			<li class="hidden-xs">
				<a href="#" title="Administration">Administration</a>
				<div class="dd">
					<ul>
						<li><a href="#" title="Current administration">Current administration</a></li>
						<li><a href="#" title="Current staff">Current staff</a></li>
						<li><a href="#" title="Student council">Student council</a></li>
						<li><a href="#" title="Collaborators">Collaborators</a></li>
					</ul>
				</div>
			</li>
			<li class="hidden-xs">
				<a href="#" title="Rules">Rules</a>
				<div class="dd">
					<ul>
						<li><a href="<?php print base_url();?>disandrules" title="Discipline and rules">Discipline and rules</a></li>
						<li><a href="<?php print base_url();?>concerningabsence" title="Rules concerning absence">Rules concerning absence</a></li>
						<li><a href="<?php print base_url();?>generalrules" title="General Rules">General Rules</a></li>
						<li><a href="#" title="Library Rules">Library Rules</a></li>
						<li><a href="<?php print base_url();?>feesrules" title="Rules Payment Of Fees">Rules Payment Of Fees</a></li>
						<li><a href="<?php print base_url();?>parentsinstructions" title="Important instructions for parents">Important instructions for parents</a></li>
						<li><a href="<?php print base_url();?>assessmentcriteria" title="Assessment and promotion criteria">Assessment and promotion criteria</a></li>
					</ul>
				</div>
			</li>
			<li class="hidden-xs">
				<a href="#" title="Admission">Admission</a>
				<div class="dd">
					<ul>
						<li><a href="#" title="Admission Criteria">Admission Criteria</a></li>
						<li><a href="#" title="Fees">Fees</a></li>
						<li><a href="#" title="Online Payment">Online Payment</a></li>
						<li><a href="#" title="View your registration">View your registration</a></li>
					</ul>
				</div>
			</li>
			<li class="hidden-xs">
				<a href="#" title="Media">Media</a>
				<div class="dd">
					<ul>
						<li><a href="#" title="Press Release">Press Release</a></li>
						<li><a href="#" title="Latest Happenings">Latest Happenings</a></li>
						<li><a href="#" title="Photo Gallery">Photo Gallery</a></li>
						<li><a href="#" title="Video Gallery">Video Gallery</a></li>
					</ul>
				</div>
			</li>
			<li class="hidden-xs"><a href="<?php print base_url();?>contact" title="Contact Us">Contact Us</a></li>
		</ul>
		<!-- start social -->
		<div class="social visible-xs">
			<ul>
				<li><a href="#" title="Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
				<li><a href="#" title="Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
				<li><a href="#" title="Linkedin"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
				<li><a href="#" title="Youtube"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
			</ul>
		</div>
		<!-- end social -->
	</div>
</div>
<!-- end navigation -->
<!-- start header -->
<header class="header header-mb">
	<div class="container-box">
        <div class="row">
        	<div class="col-sm-2 col-xs-9">
        		<!-- start logo -->
        		<div class="logo">
        			<a href="<?php print base_url();?>index" title="St Thomas"><img src="<?php print base_url();?>images/logo2.png" width="291" height="81" alt="St Thomas"></a>
        		</div>
        		<!-- end logo -->
        	</div>
        	<div class="col-sm-10 col-xs-3 position-static">
        		<a href="#" class="menu visible-xs"><i class="fa fa-bars" aria-hidden="true"></i></a>
        		<!-- start navigation2 -->
				<div class="navigation2">
					<ul>
						<li class="visible-xs dd-link">
							<a href="#" title="ABOUT">ABOUT <i class="fa fa-caret-down" aria-hidden="true"></i></a>
							<div class="dd">
								<ul>
									<li><a href="<?php print base_url();?>overview" title="Overview">Overview</a></li>
									<li><a href="<?php print base_url();?>ourlegacy" title="Our Legacy">Our Legacy</a></li>
									<li><a href="#" title="The Founders">The Founders</a></li>
									<li><a href="<?php print base_url();?>affiliations" title="Affiliations">Affiliations</a></li>
									<li><a href="<?php print base_url();?>infrastructure" title="Infrastructure">Infrastructure</a></li>
									<li><a href="#" title="CBSC Guidelines">CBSC Guidelines</a></li>
								</ul>
							</div>
						</li>
						<li class="visible-xs dd-link">
							<a href="#" title="Administration">Administration <i class="fa fa-caret-down" aria-hidden="true"></i></a>
							<div class="dd">
								<ul>
									<li><a href="#" title="Current administration">Current administration</a></li>
									<li><a href="#" title="Current staff">Current staff</a></li>
									<li><a href="#" title="Student council">Student council</a></li>
									<li><a href="#" title="Collaborators">Collaborators</a></li>
								</ul>
							</div>
						</li>
						<li class="visible-xs dd-link">
							<a href="#" title="Rules">Rules <i class="fa fa-caret-down" aria-hidden="true"></i></a>
							<div class="dd">
								<ul>
									<li><a href="<?php print base_url();?>disandrules" title="Discipline and rules">Discipline and rules</a></li>
									<li><a href="<?php print base_url();?>concerningabsence" title="Rules concerning absence">Rules concerning absence</a></li>
									<li><a href="<?php print base_url();?>generalrules" title="General Rules">General Rules</a></li>
									<li><a href="#" title="Library Rules">Library Rules</a></li>
									<li><a href="<?php print base_url();?>feesrules" title="Rules Payment Of Fees">Rules Payment Of Fees</a></li>
									<li><a href="<?php print base_url();?>parentsinstructions" title="Important instructions for parents">Important instructions for parents</a></li>
									<li><a href="<?php print base_url();?>assessmentcriteria" title="Assessment and promotion criteria">Assessment and promotion criteria</a></li>
								</ul>
							</div>
						</li>
						<li class="visible-xs dd-link">
							<a href="#" title="Admission">Admission <i class="fa fa-caret-down" aria-hidden="true"></i></a>
							<div class="dd">
								<ul>
									<li><a href="#" title="Admission Criteria">Admission Criteria</a></li>
									<li><a href="#" title="Fees">Fees</a></li>
									<li><a href="#" title="Online Payment">Online Payment</a></li>
									<li><a href="#" title="View your registration">View your registration</a></li>
								</ul>
							</div>
						</li>
						<li class="visible-xs dd-link">
							<a href="#" title="Media">Media <i class="fa fa-caret-down" aria-hidden="true"></i></a>
							<div class="dd">
								<ul>
									<li><a href="#" title="Press Release">Press Release</a></li>
									<li><a href="#" title="Latest Happenings">Latest Happenings</a></li>
									<li><a href="#" title="Photo Gallery">Photo Gallery</a></li>
									<li><a href="#" title="Video Gallery">Video Gallery</a></li>
								</ul>
							</div>
						</li>
						<li class="dd-link">
							<a href="#" title="Learning">Learning <i class="fa fa-caret-down" aria-hidden="true"></i></a>
							<ul>
								<li><a href="#" title="Primary School">Primary School</a></li>
								<li><a href="#" title="Middle School">Middle School</a></li>
								<li><a href="#" title="Secondary School">Secondary School</a></li>
								<li><a href="#" title="Senior Secondary School">Senior Secondary School</a></li>
							</ul>
						</li>
						<li class="dd-link">
							<a href="#" title="Beyond The Classroom">Beyond The Classroom <i class="fa fa-caret-down" aria-hidden="true"></i></a>
							<ul>
								<li><a href="<?php print base_url();?>sports" title="Sports">Sports</a></li>
								<li><a href="<?php print base_url();?>artculture" title="Arts & Culture">Arts & Culture</a></li>
								<li><a href="<?php print base_url();?>library" title="Library">Library</a></li>
								<li><a href="#" title="Etc.">Etc.</a></li>
							</ul>
						</li>
						<li class="dd-link">
							<a href="#" title="Enrolments">Enrolments <i class="fa fa-caret-down" aria-hidden="true"></i></a>
							<ul>
								<li><a href="#" title="Merit Board">Merit Board</a></li>
								<li><a href="#" title="Prospectus">Prospectus</a></li>
								<li><a href="#" title="Parents">Parents</a></li>
								<li><a href="#" title="Alumni">Alumni</a></li>
								<li><a href="#" title="Souvenir">Souvenir</a></li>
								<li><a href="#" title="Achievements">Achievements</a></li>
								<li><a href="#" title="Meals">Meals</a></li>
								<li><a href="#" title="FAQs">FAQs</a></li>
							</ul>
						</li>
						<li class="dd-link">
							<a href="#" title="School Services">School Services <i class="fa fa-caret-down" aria-hidden="true"></i></a>
							<ul>
								<li><a href="#" title="Bus Services">Bus Services</a></li>
								<li><a href="<?php print base_url();?>schooltiming" title="School Timings">School Timings</a></li>
								<li><a href="#" title="School Calendar">School Calendar</a></li>
							</ul>
						</li>
						<li class="visible-xs"><a href="<?php print base_url();?>contact" title="Contact Us">Contact Us</a></li>
					</ul>
				</div>
				<!-- end navigation2 -->
        	</div>
        </div>
    </div>
</header>
<!-- end header -->