<?php $this->load->view('header1'); ?>
<!-- start banner -->
<div class="banner">
	<img src="images/img_about.jpg" width="1366" height="717" alt="about">
</div>
<!-- end banner -->
<!-- start main-container -->
<div class="main-container">
	<div class="container-box">
		<!-- start content -->
		<div class="content">
			<h1>About Us</h1>
			<p>STS was a dream venture for a young Keralite settled in a North Indian industrial town of Bahadurgarh. Borne by the limitations of working under managements and torn between providing opportunities to the privileged rather than the deserving, Mr. N. Thomaskutty, the eldest son of teachers proud of their profession decided to start a school based on his Christian ideals. Though the decision to start STS seemed to be an impulsive reaction, over time it was proved to be God’s will at work.</p>
			<p>The school had a very humble beginning on April 6, 1995 in the home of Prof. D.B. Malik. The estimated strength of 150 turned out to be a gross miscalculation. 423 students needed to be accommodated in the very first year, and in the absence of space, Mr. Prem Singh Parashar, a neighbor, vacated himself to a rented space and provided his house for the school. God’s providence and the timely help of all these people have enabled STS to be the success story it is today.</p>
			<p>In 1996 the school was able to purchase land and the construction work commenced on August 24th that year. After a dedication ceremony on September 18, 1997 the school moved to its new premises.</p>
			<p>The school was recognized by the State of Haryana in the year 1999. It was later affiliated to the Central Board of Secondary education in 2001. The first batch of X passed out in the year 2003. Each year brings more successful results and St. Thomas has even gone on to achieve both 3rd and 6th rank in the All India Secondary School Examination in the same year.</p>
			<p>Since 2007 based on the demand of parents and students of Bahadurgarh, St. Thomas School has started batches for XII graders who find it difficult to travel all the way to Delhi for basic school education.</p>
			<p>Today our school boasts of an enrollment of nearly 2000 students. Our school has aimed at and successfully so bridged the urban-rural divide that is very much a part of our Indian society. Our campus, despite its limited resources, today hosts learning spaces such as science labs, a dedicated language classroom, library, multi-media center, music and art room among others. The success rate of the students of STS in the AISSE and AISSCE each year is a public statement about the school's commitment to education.</p>
		</div>
		<!-- end content -->
	</div>
</div>
<!-- end main-container -->
<?php $this->load->view('footer'); ?>