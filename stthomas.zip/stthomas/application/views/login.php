<!DOCTYPE html>
<html itemscope itemtype="#" class="no-js" lang="fr">
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, , initial-scale=1.0" name="viewport">
<title>Dashboard</title>
<link href="<?=base_url()?>master/css/style.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="<?=base_url()?>master/js/jquery.flexslider.js"></script>
<script src="<?=base_url()?>master/js/jquery.bxslider.min.js"></script>
<script src="<?=base_url()?>master/js/script.js"></script>
</head>

<body>
<!-- start main-container -->
<div class="main-container">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <!-- start login -->
                <div class="login">
                    <div class="logo">
                        <img src="<?=base_url()?>master/images/logo.png" width="498" height="150px" alt="designdot">
                    </div>
					<?php print form_open('login/login_check/',array('id'=>'loginpage','name'=>'loginpage')); ?>
					<?php if($this->session->flashdata('MESSAGE')) { ?>
					<div class="alert alert-danger" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
					<?php } ?>
                    <form action="#">
                        <div class="form-group">
                            <label>Your Username or Email</label>
                            <input type="text" name="username" placeholder="User Name" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" placeholder="Password" class="form-control">
                        </div>
                        <button class="btn btn-primary btn-block" type="submit" name="submit">LOGIN</button>
                    </form>
                </div>
                <!-- end login -->
            </div>  
        </div>
    </div>
</div>
<!-- end main-container -->
</body>
</html>