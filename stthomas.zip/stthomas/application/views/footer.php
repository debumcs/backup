<!-- start footer -->
<footer class="footer">
	<div class="container-box">
		<div class="footer-top">
			<div class="row">
				<div class="col-lg-5 hidden-md hidden-sm hidden-xs">
					<h6>QUICK ENQUIRY</h6>
					<div class="row">
						<div class="col-md-12">
							<div class="form-box">
								<form method="POST" action="home/sendmailfooter" enctype="multipart/form-data">
									<div class="form-row">
										<div class="column">
											<div class="form-group">
												<input type="text" class="form-control" placeholder="Name" name="name" id="name">
											</div>
										</div>
										<div class="column">
											<div class="form-group">
												<input type="text" class="form-control" placeholder="Email" name="email" id="email">
											</div>
										</div>
									</div>
									<div class="form-row">
										<div class="column column1">
											<div class="form-group">
												<textarea class="form-control" placeholder="Message" name="message" id="message"></textarea>
											</div>
										</div>
										<div class="column column2">
											<div class="form-group">
												<input type="text" class="form-control" placeholder="Phone" name="phone" id="phone">
											</div>
											<button type="submit" class="btn btn-default">Submit</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-7">
					<div class="row">
						<div class="col-sm-4">
							<div class="text-col">
								<ul>
									<li><a href="#" title="About Us">About Us</a></li>
									<li><a href="#" title="Adminstration">Adminstration</a></li>
									<li><a href="#" title="Rules">Rules</a></li>
									<li><a href="#" title="Learning">Learning</a></li>
									<li><a href="#" title="School Services">School Services</a></li>
									<li><a href="#" title="Beyond the Classroom">Beyond the Classroom</a></li>
									<li><a href="#" title="Admission">Admission</a></li>
									<li><a href="#" title="Enrollments">Enrollments</a></li>
									<li><a href="#" title="Media">Media</a></li>
								</ul>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="text-col">
								<h6>Contact Address</h6>
								<p>
									<strong>St. Thomas School</strong><br>
									Behind Sector - 6, <br>
									Bahadurgarh - 124507. <br>
									Haryana, INDIA.
								</p>
								<p>
									<img src="<?php print base_url();?>images/icon_phone.png" width="17" height="17" alt="phone">
									+91 - 1276 - 243555<br>
									+91 - 1276 - 243556<br>
								</p>
								<p>
									<img src="<?php print base_url();?>images/icon_mail.png" width="19" height="12" alt="mail">
									<a href="mailto:mail@stthomasschool.in">mail@stthomasschool.in</a>
								</p>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="text-col">
								<div class="text-right">
									<h5>© 2017, St Thomas School</h5>
									<span>all rights reserved</span>
									<div class="txtb">
							            <span class="pull-left">Branding by</span> <a href="http://www.designdot.co.in" class="designdot" target="_blank"></a>
							        </div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer>
<!-- end footer -->
</body>
</html>