<?php $this->load->view('header1'); ?>
<!-- start map -->
<div class="map">
	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d27997.88238910167!2d76.87303305163842!3d28.697563791877077!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d0bf19716dc77%3A0xeff3852a7eabaf43!2sSt.+Thomas+School!5e0!3m2!1sen!2sin!4v1496126057135" width="100%" height="420" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>
<!-- end map -->
<!-- start main-container -->
<div class="main-container">
	<div class="container-box">
		<!-- start contact -->
		<div class="contact">
			<div class="row">
				<div class="col-sm-7 col-md-5 col-md-offset-1">
					<div class="form">
						<form method="POST" action="home/sendmailcontact" enctype="multipart/form-data" id="registrationForm">
							<div class="heading">
								<h3>Contact Us</h3>
							</div>
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Name" name="name" id="name">
							</div>
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Email" name="email" id="email">
							</div>
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Phone Number" name="phone" id="phone">
							</div>
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Subject" name="subject" id="subject">
							</div>
							<div class="form-group">
								<select class="form-control" name="category" id="category">
									<option>Please Choose Category</option>
								</select>
							</div>
							<div class="form-group">
								<textarea class="form-control" placeholder="Message" name="message" id="message"></textarea>
							</div>
							<input type="submit" class="btn btn-primary" value="SEND" id="formsubmit">
						</form>
					</div>
				</div>
				<div class="col-sm-5 col-md-4 col-md-offset-1">
					<!-- start address -->
					<div class="address">
						<p><strong>St. Thomas School</strong><br>
						Behind Sector - 6, <br>
						Bahadurgarh - 124507. <br>
						Haryana, INDIA.</p>
						<p>
						+91 - 1276 - 243555<br>
						+91 - 1276 - 243556<br>
						<a href="mailto:mail@stthomasschool.in">mail@stthomasschool.in</a>
						</p>
					</div>
					<!-- end address -->
				</div>
			</div>
		</div>
		<!-- end contact -->
	</div>
</div>
<!-- end main-container -->
<?php $this->load->view('footer'); ?>
<script src="<?php print base_url();?>js/jquery-3.1.1.min.js"></script>
<script src="<?php print base_url();?>js/jquery.validate.min.js"></script>
<script>
$(document).ready(function() {
	$("#registrationForm").validate({
		rules:
		{
			email:
			{
				required: true,
				email: true,				
			},
			name:
			{
				required: true,
				minlength: 3
			},
           phone:
			{
				required: true,
				number: true,
				maxlength: 13
			},		
            subject:
			{
				required: true,
				maxlength: 160
			},
            message:
			{
				required: true,
				maxlength: 500
			}	
			
		},
		messages:
		{
			email:
			{
				required: '<div style="color:red;">Please enter your email address.</div>',
				email: '<div style="color:red;">Please enter a valid email address.</div>',				
			},
			name: '<div style="color:red;">Please enter minimum 3 characters</div>',	
            phone: '<div style="color:red;">Please enter maximum 13 characters</div>',	
            subject: '<div style="color:red;">Please enter maximum 160 characters</div>',	
            message: '<div style="color:red;">Please enter maximum 500 characters</div>'
		},
		submitHandler: function(form)
		{
			form.submit();
		}
	});
});
</script> 