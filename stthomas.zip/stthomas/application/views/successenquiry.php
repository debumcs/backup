<?php $this->load->view('header1'); ?>
<!-- start banner -->
<div class="banner">
	<img src="images/img_about.jpg" width="1366" height="717" alt="about">
</div>
<!-- end banner -->
<!-- start main-container -->
<div class="main-container">
	<div class="container-box">
		<!-- start content -->
		<div class="content" style="text-align:center;">
			<h1>THANK YOU !</h1>
			<p>Your Enquiry has Sent Successfully.</p>
		</div>
		<!-- end content -->
	</div>
</div>
<!-- end main-container -->
<?php $this->load->view('footer'); ?>