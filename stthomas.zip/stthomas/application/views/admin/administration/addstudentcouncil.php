<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Administration">Administration</a></li>
                    <li class="active"><a href="#" title="Student Council">Student Council</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Add Student Council</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Add Student Council</h3>-->
                            <!-- start form -->
							<form  action="<?php echo base_url('Administration/savestudentcouncil'); ?>" method="POST" enctype="multipart/form-data">
                            <div class="form">                                
                                <div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Title:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Title" id="title" name="title" class="form-control">
                                        </div>
                                    </div>
                                </div>                                
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Image:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="file" placeholder="Image" class="form-control" id="image" name="image">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Content:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <textarea  name="content" id="contents" cols="10" rows="3" class="editor form-control"></textarea>
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Sort Order:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Sort Order" id="sort_order" name="sort_order" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>