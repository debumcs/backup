<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
            <!-- start breadcrumbs -->
            <div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li class="active"><a href="index.html" title="Dashboard">Dashboard</a></li>
                </ul>
                <ul class="alt-buttons">
                    <li><a href="#" title=""><i class="fa fa-signal" aria-hidden="true"></i><span>Stats</span></a></li>
                    <li><a href="#" title=""><i class="fa fa-comments" aria-hidden="true"></i><span>Messages</span></a></li>
                    <li class="dropdown">
                        <a href="#" title="" data-toggle="dropdown"><i class="fa fa-tasks" aria-hidden="true"></i><span>Tasks</span> <strong>(+16)</strong></a>
                        <ul class="dropdown-menu pull-right">
                            <li><a href="#" title=""><i class="fa fa-plus" aria-hidden="true"></i>Add new task</a></li>
                            <li><a href="#" title=""><i class="fa fa-reorder" aria-hidden="true"></i>Statement</a></li>
                            <li><a href="#" title=""><i class="fa fa-cog" aria-hidden="true"></i>Settings</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- end breadcrumbs -->
            <!-- start page-header -->
            <div class="page-header clearfix">
                <div class="page-title">
                    <h5>Dashboard</h5>
                    <span>
					<?php
						date_default_timezone_set('Asia/Calcutta');
						$Hour = date('G');
						if ( $Hour < 12) {
							echo "Good Morning, Admin";
						} else if ( $Hour >= 12 && $Hour < 17 ) {
							echo "Good Afternoon, Admin";
						} else if ( $Hour >= 17 || $Hour < 19 ) {
							echo "Good Evening, Admin";
						}
						else if ( $Hour >= 19 ) {
							echo "Good Evening, Admin";
						}
					?>
					</span>
                </div>
                <ul class="page-stats">
                    <li>
                        <div class="showcase">
                            <span>New visits</span>
                            <h2>22.504</h2>
                        </div>
                        <div id="total-visits" class="chart">
                            <img src="<?=base_url()?>master/images/img_top_graph1.png" width="96" height="35" alt="graph">
                        </div>
                    </li>
                    <li>
                        <div class="showcase">
                            <span>My balance</span>
                            <h2>$16.290</h2>
                        </div>
                        <div id="balance" class="chart">
                            <img src="<?=base_url()?>master/images/img_top_graph2.png" width="96" height="35" alt="graph">
                        </div>
                    </li>
                </ul>
            </div>
            <!-- end page-header -->
            <div class="actions-wrapper">
                <div class="actions">
                    <div class="tab-content">
                        <div id="user-stats" class="tab-pane active">
                            <ul class="round-buttons">
                                <li>
                                    <div class="depth">
                                        <a href="#" title="Add new post" class="tip" data-original-title="Add new post"><i class="fa fa-plus" aria-hidden="true"></i></a>
                                    </div>
                                </li>
                                <li><div class="depth"><a href="#" title="View statement" class="tip" data-original-title="View statement"><i class="fa fa-signal" aria-hidden="true"></i></a></div></li>
                                <li><div class="depth"><a href="#" title="Media posts" class="tip" data-original-title="Media posts"><i class="fa fa-reorder" aria-hidden="true"></i></a></div></li>
                                <li><div class="depth"><a href="#" title="RSS feed" class="tip" data-original-title="RSS feed"><i class="fa fa-rss" aria-hidden="true"></i></a></div></li>
                                <li><div class="depth"><a href="#" title="Create new task" class="tip" data-original-title="Create new task"><i class="fa fa-tasks" aria-hidden="true"></i></a></div></li>
                                <li><div class="depth"><a href="#" title="Layout settings" class="tip" data-original-title="Layout settings"><i class="fa fa-cogs" aria-hidden="true"></i></a></div></li>
                            </ul>
                        </div>
                        <div id="quick-actions" class="tab-pane">
                            <ul class="statistics">
                                <li>
                                    <div class="top-info">
                                        <a href="#" title="" class="blue-square"><i class="fa fa-plus" aria-hidden="true"></i></a>
                                        <strong>12,476</strong>
                                    </div>
                                    <div class="progress progress-micro"><div class="bar" style="width: 60%;"></div></div>
                                    <span>User registrations</span>
                                </li>
                                <li>
                                    <div class="top-info">
                                        <a href="#" title="" class="red-square"><i class="fa fa-hand-o-up" aria-hidden="true"></i></a>
                                        <strong>621,873</strong>
                                    </div>
                                    <div class="progress progress-micro"><div class="bar" style="width: 20%;"></div></div>
                                    <span>Total clicks</span>
                                </li>
                                <li>
                                    <div class="top-info">
                                        <a href="#" title="" class="purple-square"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                                        <strong>562</strong>
                                    </div>
                                    <div class="progress progress-micro"><div class="bar" style="width: 90%;"></div></div>
                                    <span>New orders</span>
                                </li>
                                <li>
                                    <div class="top-info">
                                        <a href="#" title="" class="green-square"><i class="fa fa-check" aria-hidden="true"></i></a>
                                        <strong>$45,360</strong>
                                    </div>
                                    <div class="progress progress-micro"><div class="bar" style="width: 70%;"></div></div>
                                    <span>General balance</span>
                                </li>
                                <li>
                                    <div class="top-info">
                                        <a href="#" title="" class="sea-square"><i class="fa fa-group" aria-hidden="true"></i></a>
                                        <strong>562K+</strong>
                                    </div>
                                    <div class="progress progress-micro"><div class="bar" style="width: 50%;"></div></div>
                                    <span>Total users</span>
                                </li>
                                <li>
                                    <div class="top-info">
                                        <a href="#" title="" class="dark-blue-square"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                        <strong>36,290</strong>
                                    </div>
                                    <div class="progress progress-micro"><div class="bar" style="width: 93%;"></div></div>
                                    <span>Facebook fans</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <ul class="action-tabs">
                        <li class="active"><a href="#user-stats"  role="tab" data-toggle="tab" class="current">Quick actions</a></li>
                        <li><a href="#quick-actions"  role="tab" data-toggle="tab" class="">Website statistics</a></li>
                    </ul>
                </div>
            </div>
            <!-- start content-box -->
            <div class="content-box">
                <!-- start search -->
                <form class="search" action="#">
                    <div class="autocomplete-append">
                        <ul class="search-options">
                            <li><a href="#" title="" class="go-option tip" data-original-title="Go to search page"></a></li>
                            <li><a href="#" title="" class="advanced-option tip" data-original-title="Advanced search"></a></li>
                            <li><a href="#" title="" class="settings-option tip" data-original-title="Settings"></a></li>
                        </ul>
                        <input type="text" placeholder="search website..." id="autocomplete" class="ui-autocomplete-input" autocomplete="off"><span role="status" aria-live="polite" class="ui-helper-hidden-accessible"></span>
                        <input type="submit" class="btn btn-info" value="Search">
                    <ul class="ui-autocomplete ui-menu ui-widget ui-widget-content ui-corner-all" id="ui-id-1" tabindex="0" style="z-index: 1; display: none;"></ul></div>
                </form>
                <!-- end search -->
                <div class="row">
                    <div class="col-sm-4">
                        <div class="widget-box">
                            <h3>Earnings statistic</h3>
                            <div class="text-box">
                                <div class="graph-box">
                                    <img src="<?=base_url()?>master/images/img_graph1.jpg" width="310" height="101" alt="graph">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="widget-box">
                            <h3>Visitor statistics</h3>
                            <div class="text-box">
                                <div class="graph-box">
                                    <img src="<?=base_url()?>master/images/img_graph2.jpg" width="310" height="101" alt="graph">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="widget-box">
                            <h3>Click statistics</h3>
                            <div class="text-box">
                                <div class="graph-box">
                                    <img src="<?=base_url()?>master/images/img_graph3.jpg" width="310" height="101" alt="graph">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="widget-box">
                            <h3>Simple chart</h3>
                            <div class="text-box">
                                <div class="graph-box">
                                    <img src="<?=base_url()?>master/images/img_graph4.jpg" width="492" height="252" alt="graph">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="widget-box">
                            <h3>Calendar</h3>
                            <div class="text-box">
                                <div id="calendar"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>