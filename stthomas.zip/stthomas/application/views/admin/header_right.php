<!-- start breadcrumbs -->            
                <ul class="alt-buttons">
                    <li><a href="#" title=""><i class="fa fa-signal" aria-hidden="true"></i><span>Stats</span></a></li>
					<li class="dropdown">
                        <a href="#" title="" data-toggle="dropdown"><i class="fa fa-commenting" aria-hidden="true"></i><span>Alert</span></a>
                        <ul class="dropdown-menu pull-right">
                            <li><a href="#" title=""><i class="fa fa-reorder" aria-hidden="true"></i>Payment</a></li>
                            <li><a href="#" title=""><i class="fa fa-reorder" aria-hidden="true"></i>Project</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" title="" data-toggle="dropdown"><i class="fa fa-tasks" aria-hidden="true"></i><span>Tasks</span> <strong>(+16)</strong></a>
                        <ul class="dropdown-menu pull-right">
                            <li><a href="#" title=""><i class="fa fa-plus" aria-hidden="true"></i>Add new task</a></li>
                            <li><a href="#" title=""><i class="fa fa-reorder" aria-hidden="true"></i>Statement</a></li>
                            <li><a href="#" title=""><i class="fa fa-cog" aria-hidden="true"></i>Settings</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- end breadcrumbs -->
            <!-- start page-header -->
            <div class="page-header clearfix">
                <div class="page-title">
                    <h5>Form components</h5>
                    <span>Basic and advanced elements</span>
                </div>
                <ul class="page-stats">
                    <li>
                        <div class="showcase">
                            <span>Projects</span>
                            <h2>22.504</h2>
                        </div>
                        <div id="total-visits" class="chart">
                            <img src="<?=base_url()?>master/images/img_top_graph1.png" width="96" height="35" alt="graph">
                        </div>
                    </li>
                    <li>
                        <div class="showcase">
                            <span>Payments</span>
                            <h2>$16.290</h2>
                        </div>
                        <div id="balance" class="chart">
                            <img src="<?=base_url()?>master/images/img_top_graph2.png" width="96" height="35" alt="graph">
                        </div>
                    </li>
                </ul>
            </div>
            <!-- end page-header -->
            <div class="actions-wrapper">
                <div class="actions">
                    <div class="tab-content">
                        <div id="user-stats" class="tab-pane active">
                            <ul class="round-buttons">
                                <li>
                                    <div class="depth">
                                        <a href="#" title="Add New clients" class="tip" data-original-title="Add new post"><i class="fa fa-plus" aria-hidden="true"></i></a>
                                    </div>
                                </li>
								<li>
                                    <div class="depth">
                                        <a href="#" title="Add New Projects" class="tip" data-original-title="Add new post"><i class="fa fa-plus" aria-hidden="true"></i></a>
                                    </div>
                                </li>
                                <li><div class="depth"><a href="#" title="View Projects" class="tip" data-original-title="View statement"><i class="fa fa-signal" aria-hidden="true"></i></a></div></li>
                                <li><div class="depth"><a href="#" title="Payment" class="tip" data-original-title="Media posts"><i class="fa fa-reorder" aria-hidden="true"></i></a></div></li>
                                <li><div class="depth"><a href="#" title="Forms" class="tip" data-original-title="Create new task"><i class="fa fa-tasks" aria-hidden="true"></i></a></div></li>
                                <li><div class="depth"><a href="#" title="Template" class="tip" data-original-title="Layout settings"><i class="fa fa-cogs" aria-hidden="true"></i></a></div></li>
                            </ul>
                        </div>
                        <div id="quick-actions" class="tab-pane">
                           <ul class="statistics">
                                <li>
                                    <div class="top-info">
                                        <a href="#" title="" class="blue-square"><i class="fa fa-plus" aria-hidden="true"></i></a>
                                        <strong>12,476</strong>
                                    </div>
                                    <div class="progress progress-micro"><div class="bar" style="width: 60%;"></div></div>
                                    <span>User registrations</span>
                                </li>
                                <li>
                                    <div class="top-info">
                                        <a href="#" title="" class="red-square"><i class="fa fa-hand-o-up" aria-hidden="true"></i></a>
                                        <strong>621,873</strong>
                                    </div>
                                    <div class="progress progress-micro"><div class="bar" style="width: 20%;"></div></div>
                                    <span>Total Orders</span>
                                </li>
                                <li>
                                    <div class="top-info">
                                        <a href="#" title="" class="purple-square"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                                        <strong>562</strong>
                                    </div>
                                    <div class="progress progress-micro"><div class="bar" style="width: 90%;"></div></div>
                                    <span>New Orders</span>
                                </li>
                                <li>
                                    <div class="top-info">
                                        <a href="#" title="" class="green-square"><i class="fa fa-check" aria-hidden="true"></i></a>
                                        <strong>$45,360</strong>
                                    </div>
                                    <div class="progress progress-micro"><div class="bar" style="width: 70%;"></div></div>
                                    <span>Balance</span>
                                </li>
                                <li>
                                    <div class="top-info">
                                        <a href="#" title="" class="sea-square"><i class="fa fa-group" aria-hidden="true"></i></a>
                                        <strong>562</strong>
                                    </div>
                                    <div class="progress progress-micro"><div class="bar" style="width: 50%;"></div></div>
                                    <span>Onprocess</span>
                                </li>
                                <li>
                                    <div class="top-info">
                                        <a href="#" title="" class="dark-blue-square"><i class="fa fa-user" aria-hidden="true"></i></a>
                                        <strong>36,290</strong>
                                    </div>
                                    <div class="progress progress-micro"><div class="bar" style="width: 93%;"></div></div>
                                    <span>Staff</span>
                                </li>
                            </ul> </div>
                    </div>
                    <ul class="action-tabs">
                        <li class="active"><a href="#user-stats"  role="tab" data-toggle="tab" class="current">Quick actions</a></li>
                        <li><a href="#quick-actions"  role="tab" data-toggle="tab" class="">Website statistics</a></li>
                    </ul>
                </div>
            </div>
            