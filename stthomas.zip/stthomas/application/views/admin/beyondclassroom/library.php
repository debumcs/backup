<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Beyond Classroom">Beyond Classroom</a></li>
                    <li class="active"><a href="#" title="Library">Library</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Library</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Add/Edit/View Library</h3>-->
                            <!-- start form -->
							<form  action="<?php print base_url('Beyondclassroom/updatelibrary'); ?>" method="POST" enctype="multipart/form-data">
                            <div class="form">                                
                                <div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Content:</label>
                                        </div>
                                        <div class="col-md-9">					
											<textarea id="content" name="content" cols="10" rows="3" class="editor form-control"><?php echo $library['content']; ?></textarea>
                                        </div>
                                    </div>
                                </div> 								
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>