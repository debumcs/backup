</div>
<!-- end main-container -->
<!-- start footer -->
<div class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <div class="txtb">
                    <p><span class="pull-left">Developed by</span> <a href="http://www.designdot.co.in" class="designdot" target="_blank"></a></p>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="pull-right">
                    <p><a href="#" title="Contact Admin"><i class="fa fa-cogs" aria-hidden="true"></i> Contact Admin</a> | <a href="#" title="Report bug"><i class="fa fa-screenshot" aria-hidden="true"></i> Report bug</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end footer -->
</body>
</html>
<script src="<?php echo base_url('master/ckeditor/ckeditor.js'); ?>"></script>
<script>
var dd=1;
$(".editor").each(function(){
$(this).attr("id","editor"+dd);
CKEDITOR.replace( 'editor'+dd , {height: 140,uiColor: '#eeeeee'});
dd=dd+1;
});
</script>