<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html itemscope itemtype="#" class="no-js" lang="fr">
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, , initial-scale=1.0" name="viewport">
<title>STTHOMAS</title>
<link href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="<?=base_url()?>master/css/style.css" rel="stylesheet">
<script src='<?=base_url()?>master/js/moment.min.js'></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js"></script>
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
<script src="<?=base_url()?>master/js/jquery.selectric.min.js"></script>
<link rel="stylesheet" href="<?=base_url()?>master/css/selectric.css">
<script src="<?=base_url()?>master/js/script.js"></script>
</head>

<body>
<!-- start header -->
<div class="header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-3 hidden-xs">
                <!-- start logo -->
                <div class="logo">
                    <a href="index.php" title="designdot"><img src="<?=base_url()?>master/images/logo.png" width="498" height="150" alt="designdot"></a>
                </div>
                <!-- end logo -->
            </div>
            <div class="col-sm-9">
                <!-- start top-nav -->
                <div class="top-nav">
                    <ul>
                        <li><a href="#" class="fullview"></a></li>
                        <li><a href="#" class="showmenu"></a></li>
                        <li><a href="#" class="messages"></a></li>
                        <li class="user-menu">
                            <a href="#" title="User"><img src="<?=base_url()?>master/images/userpic.png" alt=""><span class="hidden-xs">Howdy, Eugene! <b class="caret"></b></span></a>
                            <ul>
                                <!--<li><a href="#" title="Profile"><i class="fa fa-user" aria-hidden="true"></i>Profile</a></li>
                                <li><a href="#" title="Messages"><i class="fa fa-inbox" aria-hidden="true"></i>Messages<span class="badge badge-info">9</span></a></li>-->
                                <li><a href="<?php echo base_url('Settings/changepassword');?>" title="Settings"><i class="fa fa-cog" aria-hidden="true"></i>Settings</a></li>
                                <li><a href="<?php echo base_url('Login/logout');?>" title="Logout"><i class="fa fa-remove" aria-hidden="trye"></i>Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <!-- end top-nav -->
            </div>
        </div>
    </div>
</div>
<!-- end header -->
<!-- start main-container -->
<div class="main-container clearfix">