<!-- start leftcol -->
<?php 
$uri1 = $this->uri->segment(1);
$uri2 = $this->uri->segment(2);
$uri3 = $this->uri->segment(3);
?>
<div class="leftcol">
    <ul class="tabs-nav two-items">
        <li class="<?php if($uri1 == 'Admin' || $uri2 == 'changepassword' || $uri2 == 'addbanner' || $uri2 == 'viewbanner' || $uri2 == 'editbanner' || $uri2 == 'trashbanner' || $uri2 == 'homecontent' || $uri2 == 'aboutus' || $uri2 == 'ourlegacy' || $uri2 == 'thefounders' || $uri2 == 'affiliations' || $uri2 == 'infrastructure' || $uri2 == 'cbscguidelines' || $uri2 == 'addcurrentadministration' || $uri2 == 'viewcurrentadministration' || $uri2 == 'editcurrentadministration' || $uri2 == 'trashcurrentadministration' || $uri2 == 'addcurrentstaff' || $uri2 == 'viewcurrentstaff' || $uri2 == 'editcurrentstaff' || $uri2 == 'trashcurrentstaff' || $uri2 == 'addstudentcouncil' || $uri2 == 'viewstudentcouncil' || $uri2 == 'editstudentcouncil' || $uri2 == 'trashstudentcouncil' || $uri2 == 'addcollaborators' || $uri2 == 'viewcollaborators' || $uri2 == 'editcollaborators' || $uri2 == 'trashcollaborators' || $uri2 == 'disandrules' || $uri2 == 'rulesconcerning' || $uri2 == 'generalrules' || $uri2 == 'libraryrules' || $uri2 == 'feesrules' || $uri2 == 'parentsinstructions' || $uri2 == 'assessmentcriteria' || $uri2 == 'admissioncriteria' || $uri2 == 'admissionfees' || $uri2 == 'addpressrelease' || $uri2 == 'viewpressrelease' || $uri2 == 'editpressrelease' || $uri2 == 'trashpressrelease' || $uri2 == 'addlatesthappenings' || $uri2 == 'viewlatesthappenings' || $uri2 == 'editlatesthappenings' || $uri2 == 'trashlatesthappenings' || $uri2 == 'addphotogallery' || $uri2 == 'viewphotogallery' || $uri2 == 'editphotogallery' || $uri2 == 'trashphotogallery' || $uri2 == 'addvideogallery' || $uri2 == 'viewvideogallery' || $uri2 == 'editvideogallery' || $uri2 == 'trashvideogallery' || $uri2 == 'addlearning' || $uri2 == 'viewlearning' || $uri2 == 'editlearning' || $uri2 == 'trashlearning' || $uri2 == 'sports' || $uri2 == 'artculture' || $uri2 == 'library' || $uri2 == 'schooltiming' ) { echo 'active'; } ?>"><a href="#general" role="tab" data-toggle="tab"><i class="fa fa-reorder" aria-hidden="true"></i></a></li>
        
		<li class="<?php if($uri3 == 'addparentregistration' || $uri3 == 'viewparentregistration' || $uri3 == 'editparentregistration' || $uri3 == 'trashparentregistration' || $uri3 == 'addteacherregistration' || $uri3 == 'viewteacherregistration' || $uri3 == 'editteacherregistration' || $uri3 == 'trashteacherregistration' || $uri3 == 'addfeessummary' || $uri3 == 'viewfeessummary' || $uri3 == 'editfeessummary' || $uri3 == 'trashfeessummary' || $uri3 == 'addroute' || $uri3 == 'viewroute' || $uri3 == 'editroute' || $uri3 == 'trashroute' || $uri3 == 'addtransportdriver' || $uri3 == 'viewtransportdriver' || $uri3 == 'edittransportdriver' || $uri3 == 'trashtransportdriver' || $uri3 == 'addtransportconductor' || $uri3 == 'viewtransportconductor' || $uri3 == 'edittransportconductor' || $uri3 == 'trashtransportconductor' || $uri3 == 'addbus' || $uri3 == 'viewbus' || $uri3 == 'editbus' || $uri3 == 'trashbus' || $uri3 == 'addstudentregistration' || $uri3 == 'viewstudentregistration' || $uri3 == 'editstudentregistration' || $uri3 == 'trashstudentregistration' || $uri3 == 'addstudentsubject' || $uri3 == 'viewstudentsubject' || $uri3 == 'editstudentsubject' || $uri3 == 'trashstudentsubject' || $uri3 == 'addassignment' || $uri3 == 'viewassignment' || $uri3 == 'editassignment' || $uri3 == 'trashassignment' || $uri3 == 'addexamtimetable' || $uri3 == 'viewexamtimetable' || $uri3 == 'editexamtimetable' || $uri3 == 'trashexamtimetable' || $uri3 == 'addclass' || $uri3 == 'viewclass' || $uri3 == 'editclass' || $uri3 == 'trashclass' || $uri3 == 'addsection' || $uri3 == 'viewsection' || $uri3 == 'editsection' || $uri3 == 'trashsection' || $uri3 == 'addsubject' || $uri3 == 'viewsubject' || $uri3 == 'editsubject' || $uri3 == 'trashsubject' || $uri3 == 'addsyllabus' || $uri3 == 'viewsyllabus' || $uri3 == 'editsyllabus' || $uri3 == 'trashsyllabus' || $uri3 == 'addtestpaper' || $uri3 == 'viewtestpaper' || $uri3 == 'edittestpaper' || $uri3 == 'trashtestpaper' || $uri3 == 'addquestionpaper' || $uri3 == 'viewquestionpaper' || $uri3 == 'editquestionpaper' || $uri3 == 'trashquestionpaper'){ echo 'active'; } ?>"><a href="#stuff" role="tab" data-toggle="tab"><i class="fa fa-cogs" aria-hidden="true"></i></a></li>
    </ul>
    <div class="tab-content">
        <div id="general" class="tab-pane <?php if($uri1 == 'Admin' || $uri2 == 'changepassword' || $uri2 == 'addbanner' || $uri2 == 'viewbanner' || $uri2 == 'editbanner' || $uri2 == 'trashbanner' || $uri2 == 'homecontent' || $uri2 == 'aboutus' || $uri2 == 'ourlegacy' || $uri2 == 'thefounders' || $uri2 == 'affiliations' || $uri2 == 'infrastructure' || $uri2 == 'cbscguidelines' || $uri2 == 'addcurrentadministration' || $uri2 == 'viewcurrentadministration' || $uri2 == 'editcurrentadministration' || $uri2 == 'trashcurrentadministration' || $uri2 == 'addcurrentstaff' || $uri2 == 'viewcurrentstaff' || $uri2 == 'editcurrentstaff' || $uri2 == 'trashcurrentstaff' || $uri2 == 'addstudentcouncil' || $uri2 == 'viewstudentcouncil' || $uri2 == 'editstudentcouncil' || $uri2 == 'trashstudentcouncil' || $uri2 == 'addcollaborators' || $uri2 == 'viewcollaborators' || $uri2 == 'editcollaborators' || $uri2 == 'trashcollaborators' || $uri2 == 'disandrules' || $uri2 == 'rulesconcerning' || $uri2 == 'generalrules' || $uri2 == 'libraryrules' || $uri2 == 'feesrules' || $uri2 == 'parentsinstructions' || $uri2 == 'assessmentcriteria' || $uri2 == 'admissioncriteria' || $uri2 == 'admissionfees' || $uri2 == 'addpressrelease' || $uri2 == 'viewpressrelease' || $uri2 == 'editpressrelease' || $uri2 == 'trashpressrelease' || $uri2 == 'addlatesthappenings' || $uri2 == 'viewlatesthappenings' || $uri2 == 'editlatesthappenings' || $uri2 == 'trashlatesthappenings' || $uri2 == 'addphotogallery' || $uri2 == 'viewphotogallery' || $uri2 == 'editphotogallery' || $uri2 == 'trashphotogallery' || $uri2 == 'addvideogallery' || $uri2 == 'viewvideogallery' || $uri2 == 'editvideogallery' || $uri2 == 'trashvideogallery' || $uri2 == 'addlearning' || $uri2 == 'viewlearning' || $uri2 == 'editlearning' || $uri2 == 'trashlearning' || $uri2 == 'sports' || $uri2 == 'artculture' || $uri2 == 'library' || $uri2 == 'schooltiming' ) { echo 'active'; } ?>">
            <div class="leftcol-content">
                <!-- start sidebar-user -->
                <div class="sidebar-user">
                    <div class="navbar"><div class="navbar-inner"><h6>Wazzup, Eugene!</h6></div></div>
                    <a href="#" title="" class="user"><img src="<?=base_url()?>master/images/sidebar_user_big.png" alt=""></a>
                    <ul class="user-links">
                        <li><a href="#" title="">New users<strong>+12</strong></a></li>
                        <li><a href="#" title="">New orders<strong>+156</strong></a></li>
                        <li><a href="#" title="">New messages<strong>+45</strong></a></li>
                    </ul>
                </div>
                <!-- end sidebar-user -->
                <!-- start general-stats -->
                <div class="general-stats">
                    <div class="row">
                        <div class="col-md-12">
                            <ul class="head">
                                <li><span>Users</span></li>
                                <li><span>Orders</span></li>
                                <li><span>Visits</span></li>
                            </ul>
                            <ul class="body">
                                <li><strong>116k+</strong></li>
                                <li><strong>1290</strong></li>
                                <li><strong>554</strong></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- end general-stats -->
                <!-- start navigation -->
                <div class="navigation">
                    <ul>
                        <li class="open"><a href="<?php echo base_url('Admin'); ?>" title="Dashboard" class="active"><i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard</a></li>
                       <li class="<?php if($uri2 == 'addbanner' || $uri2 == 'viewbanner' || $uri2 == 'editbanner' || $uri2 == 'trashbanner' || $uri2 == 'homecontent') { echo 'open'; } ?>">
                            <a href="#" title="Home" class="dd"><i class="fa fa-home" aria-hidden="true"></i> HOME<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                            <ul>                                
                                <li class="<?php if($uri2 == 'addbanner' || $uri2 == 'viewbanner' || $uri2 == 'editbanner' || $uri2 == 'trashbanner') { echo 'open'; } ?>"><a href="#" title="Manage Banner" class="dd2">MANAGE BANNER<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Homeadmin/addbanner'); ?>" title="Add Banner">Add </a></li>
                                        <li><a href="<?php echo base_url('Homeadmin/viewbanner'); ?>" title="Edit/View Banner">Edit/View</a></li>
										<li><a href="<?php echo base_url('Homeadmin/trashbanner'); ?>" title="Trash Banner">Trash</a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'homecontent') { echo 'open'; } ?>"><a href="#" title="Home Content" class="dd2">HOME CONTENT<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Homeadmin/homecontent'); ?>" title="Add/Edit/View Sports">Add/Edit/View </a></li>            
                                    </ul>
                                </li>
								</ul>
                        </li>
						<li class="<?php if($uri2 == 'aboutus' || $uri2 == 'ourlegacy' || $uri2 == 'thefounders' || $uri2 == 'affiliations' || $uri2 == 'infrastructure' || $uri2 == 'cbscguidelines') { echo 'open'; } ?>">
                            <a href="#" title="About Us" class="dd"><i class="fa fa-building" aria-hidden="true"></i> ABOUT-US<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                            <ul>                                
                                <li class="<?php if($uri2 == 'aboutus') { echo 'open'; } ?>"><a href="#" title="Overview" class="dd2">OVERVIEW<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('About/aboutus'); ?>" title="Add/Edit/View Overview">Add/Edit/View </a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'ourlegacy') { echo 'open'; } ?>"><a href="#" title="Our Legacy" class="dd2">OUR LEGACY<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('About/ourlegacy'); ?>" title="Add/Edit/View Our Legacy">Add/Edit/View </a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'thefounders') { echo 'open'; } ?>"><a href="#" title="The Founders" class="dd2">THE FOUNDERS<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('About/thefounders'); ?>" title="Add/Edit/View The Founders">Add/Edit/View </a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'affiliations') { echo 'open'; } ?>"><a href="#" title="Affiliations" class="dd2">AFFILIATIONS<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('About/affiliations'); ?>" title="Add/Edit/View Affiliations">Add/Edit/View </a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'infrastructure') { echo 'open'; } ?>"><a href="#" title="Infrastructure" class="dd2">INFRASTRUCTURE<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('About/infrastructure'); ?>" title="Add/Edit/View Infrastructure">Add/Edit/View </a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'cbscguidelines') { echo 'open'; } ?>"><a href="#" title="Cbsc Guidelines" class="dd2">CBSC GUIDELINES<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('About/cbscguidelines'); ?>" title="Add/Edit/View Cbsc Guidelines">Add/Edit/View</a></li>
                                    </ul>
                                </li>
								</ul>
                        </li>
						<li class="<?php if($uri2 == 'addcurrentadministration' || $uri2 == 'viewcurrentadministration' || $uri2 == 'editcurrentadministration' || $uri2 == 'trashcurrentadministration' || $uri2 == 'addcurrentstaff' || $uri2 == 'viewcurrentstaff' || $uri2 == 'editcurrentstaff' || $uri2 == 'trashcurrentstaff' || $uri2 == 'addstudentcouncil' || $uri2 == 'viewstudentcouncil' || $uri2 == 'editstudentcouncil' || $uri2 == 'trashstudentcouncil' || $uri2 == 'addcollaborators' || $uri2 == 'viewcollaborators' || $uri2 == 'editcollaborators' || $uri2 == 'trashcollaborators') { echo 'open'; } ?>">
                            <a href="#" title="Administration" class="dd"><i class="fa fa-tasks" aria-hidden="true"></i> ADMINISTRATION<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                            <ul>                                
                                <li class="<?php if($uri2 == 'addcurrentadministration' || $uri2 == 'viewcurrentadministration' || $uri2 == 'editcurrentadministration' || $uri2 == 'trashcurrentadministration') { echo 'open'; } ?>"><a href="#" title="Cur. Administration" class="dd2">CUR. ADMINISTRATION<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Administration/addcurrentadministration'); ?>" title="Add Cur. Administration">Add </a></li>
                                        <li><a href="<?php echo base_url('Administration/viewcurrentadministration'); ?>" title="Edit/View Cur. Administration">Edit/View</a></li>
										<li><a href="<?php echo base_url('Administration/trashcurrentadministration'); ?>" title="Trash Cur. Administration">Trash</a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'addcurrentstaff' || $uri2 == 'viewcurrentstaff' || $uri2 == 'editcurrentstaff' || $uri2 == 'trashcurrentstaff') { echo 'open'; } ?>"><a href="#" title="Cur. Staff" class="dd2">CUR. STAFF<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Administration/addcurrentstaff'); ?>" title="Add Cur. Staff">Add </a></li>
                                        <li><a href="<?php echo base_url('Administration/viewcurrentstaff'); ?>" title="Edit/View Cur. Staff">Edit/View</a></li>
										<li><a href="<?php echo base_url('Administration/trashcurrentstaff'); ?>" title="Trash Cur. Staff">Trash</a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'addstudentcouncil' || $uri2 == 'viewstudentcouncil' || $uri2 == 'editstudentcouncil' || $uri2 == 'trashstudentcouncil') { echo 'open'; } ?>"><a href="#" title="Student Council" class="dd2">STUDENT COUNCIL<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Administration/addstudentcouncil'); ?>" title="Add Student Council">Add </a></li>
                                        <li><a href="<?php echo base_url('Administration/viewstudentcouncil'); ?>" title="Edit/View Student Council">Edit/View</a></li>
										<li><a href="<?php echo base_url('Administration/trashstudentcouncil'); ?>" title="Trash Student Council">Trash</a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'addcollaborators' || $uri2 == 'viewcollaborators' || $uri2 == 'editcollaborators' || $uri2 == 'trashcollaborators') { echo 'open'; } ?>"><a href="#" title="Collaborators" class="dd2">COLLABORATORS<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Administration/addcollaborators'); ?>" title="Add Collaborators">Add </a></li>
                                        <li><a href="<?php echo base_url('Administration/viewcollaborators'); ?>" title="Edit/View Collaborators">Edit/View</a></li>
										<li><a href="<?php echo base_url('Administration/trashcollaborators'); ?>" title="Trash Collaborators">Trash</a></li>
                                    </ul>
                                </li>
								</ul>
                        </li>
						<li class="<?php if($uri2 == 'disandrules' || $uri2 == 'rulesconcerning' || $uri2 == 'generalrules' || $uri2 == 'libraryrules' || $uri2 == 'feesrules' || $uri2 == 'parentsinstructions' || $uri2 == 'assessmentcriteria') { echo 'open'; } ?>">
                            <a href="#" title="Rules" class="dd"><i class="fa fa-tasks" aria-hidden="true"></i> RULES<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                            <ul>                                
                                <li class="<?php if($uri2 == 'disandrules') { echo 'open'; } ?>"><a href="#" title="Discipline & Rules" class="dd2">DISCIPLINE & RULES<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Rules/disandrules'); ?>" title="Add/Edit/View Discipline & Rules">Add/Edit/View </a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'rulesconcerning') { echo 'open'; } ?>"><a href="#" title="Rules Concerning" class="dd2">RULES CONCERNING<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Rules/rulesconcerning'); ?>" title="Add/Edit/View Rules Concerning">Add/Edit/View </a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'generalrules') { echo 'open'; } ?>"><a href="#" title="General Rules" class="dd2">GENERAL RULES<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Rules/generalrules'); ?>" title="Add/Edit/View General Rules">Add/Edit/View </a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'libraryrules') { echo 'open'; } ?>"><a href="#" title="Library Rules" class="dd2">LIBRARY RULES<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Rules/libraryrules'); ?>" title="Add/Edit/View Library Rules">Add/Edit/View </a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'feesrules') { echo 'open'; } ?>"><a href="#" title="Fees Rules" class="dd2">FEES RULES<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Rules/feesrules'); ?>" title="Add/Edit/View Fees Rules">Add/Edit/View </a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'parentsinstructions') { echo 'open'; } ?>"><a href="#" title="Parents Instructions" class="dd2">PARENTS INSTRUCTIONS<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Rules/parentsinstructions'); ?>" title="Add/Edit/View Parents Instructions">Add/Edit/View </a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'assessmentcriteria') { echo 'open'; } ?>"><a href="#" title="Assessment Criteria" class="dd2">ASSESSMENT CRITERIA<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Rules/assessmentcriteria'); ?>" title="Add/Edit/View Assessment Criteria">Add/Edit/View </a></li>
                                    </ul>
                                </li>
								</ul>
                        </li>
						<li class="<?php if($uri2 == 'admissioncriteria' || $uri2 == 'admissionfees') { echo 'open'; } ?>">
                            <a href="#" title="Admission" class="dd"><i class="fa fa-tasks" aria-hidden="true"></i> ADMISSION<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                            <ul>                                
                                <li class="<?php if($uri2 == 'admissioncriteria') { echo 'open'; } ?>"><a href="#" title="Admission Criteria" class="dd2">ADMISSION CRITERIA<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Admission/admissioncriteria'); ?>" title="Add/Edit/View Admission Criteria">Add/Edit/View </a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'admissionfees') { echo 'open'; } ?>"><a href="#" title="Admission Fees" class="dd2">ADMISSION FEES<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Admission/admissionfees'); ?>" title="Add/Edit/View Admission Fees">Add/Edit/View </a></li>
                                    </ul>
                                </li>
								</ul>
                        </li>
						<li class="<?php if($uri2 == 'addpressrelease' || $uri2 == 'viewpressrelease' || $uri2 == 'editpressrelease' || $uri2 == 'trashpressrelease' || $uri2 == 'addlatesthappenings' || $uri2 == 'viewlatesthappenings' || $uri2 == 'editlatesthappenings' || $uri2 == 'trashlatesthappenings' || $uri2 == 'addphotogallery' || $uri2 == 'viewphotogallery' || $uri2 == 'editphotogallery' || $uri2 == 'trashphotogallery' || $uri2 == 'addvideogallery' || $uri2 == 'viewvideogallery' || $uri2 == 'editvideogallery' || $uri2 == 'trashvideogallery') { echo 'open'; } ?>">
                            <a href="#" title="Media" class="dd"><i class="fa fa-tasks" aria-hidden="true"></i> MEDIA<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                            <ul>                                
                                <li class="<?php if($uri2 == 'addpressrelease' || $uri2 == 'viewpressrelease' || $uri2 == 'editpressrelease' || $uri2 == 'trashpressrelease' ) { echo 'open'; } ?>"><a href="#" title="Press Release" class="dd2">PRESS RELEASE<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Media/addpressrelease'); ?>" title="Add Press Release">Add </a></li>
                                        <li><a href="<?php echo base_url('Media/viewpressrelease'); ?>" title="Edit/View Press Release">Edit/View</a></li>
										<li><a href="<?php echo base_url('Media/trashpressrelease'); ?>" title="Trash Press Release">Trash</a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'addlatesthappenings' || $uri2 == 'viewlatesthappenings' || $uri2 == 'editlatesthappenings' || $uri2 == 'trashlatesthappenings') { echo 'open'; } ?>"><a href="#" title="Latest Happenings" class="dd2">LATEST HAPPENINGS<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Media/addlatesthappenings'); ?>" title="Add Latest Happenings">Add </a></li>
                                        <li><a href="<?php echo base_url('Media/viewlatesthappenings'); ?>" title="Edit/View Latest Happenings">Edit/View</a></li>
										<li><a href="<?php echo base_url('Media/trashlatesthappenings'); ?>" title="Trash Latest Happenings">Trash</a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'addphotogallery' || $uri2 == 'viewphotogallery' || $uri2 == 'editphotogallery' || $uri2 == 'trashphotogallery' ) { echo 'open'; } ?>"><a href="#" title="Photo Gallery" class="dd2">PHOTO GALLERY<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Media/addphotogallery'); ?>" title="Add Photo Gallery">Add </a></li>
                                        <li><a href="<?php echo base_url('Media/viewphotogallery'); ?>" title="Edit/View Photo Gallery">Edit/View</a></li>
										<li><a href="<?php echo base_url('Media/trashphotogallery'); ?>" title="Trash Photo Gallery">Trash</a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'addvideogallery' || $uri2 == 'viewvideogallery' || $uri2 == 'editvideogallery' || $uri2 == 'trashvideogallery') { echo 'open'; } ?>"><a href="#" title="Video Gallery" class="dd2">VIDEO GALLERY<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Media/addvideogallery'); ?>" title="Add Video Gallery">Add </a></li>
                                        <li><a href="<?php echo base_url('Media/viewvideogallery'); ?>" title="Edit/View Video Gallery">Edit/View</a></li>
										<li><a href="<?php echo base_url('Media/trashvideogallery'); ?>" title="Trash Video Gallery">Trash</a></li>
                                    </ul>
                                </li>
								</ul>
                        </li>
						 <li class="<?php if($uri2 == 'addlearning' || $uri2 == 'viewlearning' || $uri2 == 'editlearning' || $uri2 == 'trashlearning') { echo 'open'; } ?>">
                            <a href="#" title="Learning" class="dd"><i class="fa fa-tasks" aria-hidden="true"></i> LEARNING<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                            <ul>
                                <li><a href="<?php echo base_url('Learning/addlearning'); ?>" title="Add Learning">Add</a></li>
                                <li><a href="<?php echo base_url('Learning/viewlearning'); ?>" title="Edit/View Learning">Edit/View</a></li>
								<li><a href="<?php echo base_url('Learning/trashlearning'); ?>" title="Trash Learning">Trash</a></li>
                            </ul>
                        </li>
						<li class="<?php if($uri2 == 'sports' || $uri2 == 'artculture' || $uri2 == 'library') { echo 'open'; } ?>">
                            <a href="#" title="Beyond Classroom" class="dd"><i class="fa fa-tasks" aria-hidden="true"></i> BEYOND CLASSROOM<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                            <ul>                                
                                <li class="<?php if($uri2 == 'sports') { echo 'open'; } ?>"><a href="#" title="Sports" class="dd2">SPORTS<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Beyondclassroom/sports'); ?>" title="Add/Edit/View Sports">Add/Edit/View </a></li>            
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'artculture') { echo 'open'; } ?>"><a href="#" title="Art & Culture" class="dd2">ART & CULTURE<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Beyondclassroom/artculture'); ?>" title="Add/Edit/View Art & Culture">Add/Edit/View </a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri2 == 'library') { echo 'open'; } ?>"><a href="#" title="Library" class="dd2">LIBRARY<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Beyondclassroom/library'); ?>" title="Add/Edit/View Library">Add/Edit/View </a></li>
                                    </ul>
                                </li>
								</ul>
                        </li>
						<li class="<?php if($uri2 == 'schooltiming') { echo 'open'; } ?>">
                            <a href="#" title="School Services" class="dd"><i class="fa fa-tasks" aria-hidden="true"></i> SCHOOL SERVICES<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                            <ul>                                
                                <li class="<?php if($uri2 == 'schooltiming') { echo 'open'; } ?>"><a href="#" title="School Timing" class="dd2">SCHOOL TIMING<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('Schoolservices/schooltiming'); ?>" title="Add/Edit/View Sports">Add/Edit/View </a></li>            
                                    </ul>
                                </li>								
								</ul>
                        </li>
						
						
						
                        <!--<li><a href="#" title="Components"><i class="fa fa-tasks" aria-hidden="true"></i>Components</a></li>
                        <li><a href="#" title="Media"><i class="fa fa-tasks" aria-hidden="true"></i>Media</a></li>
                        <li><a href="#" title="Charts & graphs"><i class="fa fa-signal" aria-hidden="true"></i>Charts & graphs</a></li>
                        <li><a href="#" title="Invoice"><i class="fa fa-copy" aria-hidden="true"></i>Invoice</a></li>
                        <li><a href="tables.php" title="Tables"><i class="fa fa-table" aria-hidden="true"></i>Tables</a></li>
                        <li><a href="#" title="Typography"><i class="fa fa-text-height" aria-hidden="true"></i>Typography</a></li>
                        <li><a href="#" title="Calendar"><i class="fa fa-calendar" aria-hidden="true"></i>Calendar</a></li>-->
                    </ul>
                </div>
                <!-- end navigation -->
            </div>
        </div>
		<!-- parental portal -->
		<div id="stuff" class="tab-pane <?php if($uri3 == 'addparentregistration' || $uri3 == 'viewparentregistration' || $uri3 == 'editparentregistration' || $uri3 == 'trashparentregistration' || $uri3 == 'addteacherregistration' || $uri3 == 'viewteacherregistration' || $uri3 == 'editteacherregistration' || $uri3 == 'trashteacherregistration' || $uri3 == 'addfeessummary' || $uri3 == 'viewfeessummary' || $uri3 == 'editfeessummary' || $uri3 == 'trashfeessummary' || $uri3 == 'addroute' || $uri3 == 'viewroute' || $uri3 == 'editroute' || $uri3 == 'trashroute' || $uri3 == 'addtransportdriver' || $uri3 == 'viewtransportdriver' || $uri3 == 'edittransportdriver' || $uri3 == 'trashtransportdriver' || $uri3 == 'addtransportconductor' || $uri3 == 'viewtransportconductor' || $uri3 == 'edittransportconductor' || $uri3 == 'trashtransportconductor' || $uri3 == 'addbus' || $uri3 == 'viewbus' || $uri3 == 'editbus' || $uri3 == 'trashbus' || $uri3 == 'addstudentregistration' || $uri3 == 'viewstudentregistration' || $uri3 == 'editstudentregistration' || $uri3 == 'trashstudentregistration' || $uri3 == 'addstudentsubject' || $uri3 == 'viewstudentsubject' || $uri3 == 'editstudentsubject' || $uri3 == 'trashstudentsubject' || $uri3 == 'addassignment' || $uri3 == 'viewassignment' || $uri3 == 'editassignment' || $uri3 == 'trashassignment' || $uri3 == 'addexamtimetable' || $uri3 == 'viewexamtimetable' || $uri3 == 'editexamtimetable' || $uri3 == 'trashexamtimetable' || $uri3 == 'addclass' || $uri3 == 'viewclass' || $uri3 == 'editclass' || $uri3 == 'trashclass' || $uri3 == 'addsection' || $uri3 == 'viewsection' || $uri3 == 'editsection' || $uri3 == 'trashsection' || $uri3 == 'addsubject' || $uri3 == 'viewsubject' || $uri3 == 'editsubject' || $uri3 == 'trashsubject' || $uri3 == 'addsyllabus' || $uri3 == 'viewsyllabus' || $uri3 == 'editsyllabus' || $uri3 == 'trashsyllabus' || $uri3 == 'addtestpaper' || $uri3 == 'viewtestpaper' || $uri3 == 'edittestpaper' || $uri3 == 'trashtestpaper' || $uri3 == 'addquestionpaper' || $uri3 == 'viewquestionpaper' || $uri3 == 'editquestionpaper' || $uri3 == 'trashquestionpaper'){ echo 'active'; } ?>">
		<div class="leftcol-content">
                <!-- start sidebar-user -->
                <div class="sidebar-user">
                    <div class="navbar"><div class="navbar-inner"><h6>Wazzup, Eugene!</h6></div></div>
                    <a href="#" title="" class="user"><img src="<?=base_url()?>master/images/sidebar_user_big.png" alt=""></a>
                    <ul class="user-links">
                        <li><a href="#" title="">New users<strong>+12</strong></a></li>
                        <li><a href="#" title="">New orders<strong>+156</strong></a></li>
                        <li><a href="#" title="">New messages<strong>+45</strong></a></li>
                    </ul>
                </div>
                <!-- end sidebar-user -->
                <!-- start general-stats -->
                <div class="general-stats">
                    <div class="row">
                        <div class="col-md-12">
                            <ul class="head">
                                <li><span>Users</span></li>
                                <li><span>Orders</span></li>
                                <li><span>Visits</span></li>
                            </ul>
                            <ul class="body">
                                <li><strong>116k+</strong></li>
                                <li><strong>1290</strong></li>
                                <li><strong>554</strong></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- end general-stats -->
                <!-- start navigation -->
                <div class="navigation">
                    <ul>
                        <li class="<?php if($uri1 == 'Admin') { echo 'open'; } ?>"><a href="<?php echo base_url('Admin'); ?>" title="Dashboard" class="active"><i class="fa fa-home" aria-hidden="true"></i> Dashboard</a></li>
                       <li class="<?php if($uri3 == 'addparentregistration' || $uri3 == 'viewparentregistration' || $uri3 == 'editparentregistration' || $uri3 == 'trashparentregistration' || $uri3 == 'addteacherregistration' || $uri3 == 'viewteacherregistration' || $uri3 == 'editteacherregistration' || $uri3 == 'trashteacherregistration'){ echo 'open'; } ?>">
                            <a href="#" title="Home" class="dd"><i class="fa fa-tasks" aria-hidden="true"></i> HOME<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                            <ul>                                
                                <li class="<?php if($uri3 == 'addparentregistration' || $uri3 == 'viewparentregistration' || $uri3 == 'editparentregistration' || $uri3 == 'trashparentregistration'){ echo 'open'; } ?>"><a href="#" title="Parent Registration" class="dd2">Parent Registration<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('parentalportal/Registration/addparentregistration'); ?>" title="Add Parent Registration">Add </a></li>
                                        <li><a href="<?php echo base_url('parentalportal/Registration/viewparentregistration'); ?>" title="Edit/View Parent Registration">Edit/View</a></li>
										<li><a href="<?php echo base_url('parentalportal/Registration/trashparentregistration'); ?>" title="Trash parent Registration">Trash</a></li>
                                    </ul>
                                </li>
								 <li class="<?php if($uri3 == 'addteacherregistration' || $uri3 == 'viewteacherregistration' || $uri3 == 'editteacherregistration' || $uri3 == 'trashteacherregistration'){ echo 'open'; } ?>"><a href="#" title="Teacher Registration" class="dd2">Teacher Registration<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('parentalportal/Registration/addteacherregistration'); ?>" title="Add Teacher Registration">Add </a></li>
                                        <li><a href="<?php echo base_url('parentalportal/Registration/viewteacherregistration'); ?>" title="Edit/View Teacher Registration">Edit/View</a></li>
										<li><a href="<?php echo base_url('parentalportal/Registration/trashteacherregistration'); ?>" title="Trash Teacher Registration">Trash</a></li>
                                    </ul>
                                </li>
								</ul>
                        </li>
						<li class="<?php if($uri3 == 'addfeessummary' || $uri3 == 'viewfeessummary' || $uri3 == 'editfeessummary' || $uri3 == 'trashfeessummary'){ echo 'open'; } ?>">
                            <a href="#" title="Parents Management" class="dd"><i class="fa fa-tasks" aria-hidden="true"></i> Parents Management<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                            <ul>                                
                                <!--<li><a href="#" title="Parent Registration" class="dd2">Parent Registration<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('parentalportal/Registration/addparentregistration'); ?>" title="Add Parent Registration">Add </a></li>
                                        <li><a href="<?php echo base_url('parentalportal/Registration/viewparentregistration'); ?>" title="Edit/View Parent Registration">Edit/View</a></li>
										<li><a href="<?php echo base_url('parentalportal/Registration/trashparentregistration'); ?>" title="Trash parent Registration">Trash</a></li>
                                    </ul>
                                </li>-->
								 <li class="<?php if($uri3 == 'addfeessummary' || $uri3 == 'viewfeessummary' || $uri3 == 'editfeessummary' || $uri3 == 'trashfeessummary'){ echo 'open'; } ?>"><a href="#" title="Fees Summary" class="dd2">Fees Summary<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('parentalportal/Parents/addfeessummary'); ?>" title="Add Fees Summary">Add </a></li>
                                        <li><a href="<?php echo base_url('parentalportal/Parents/viewfeessummary'); ?>" title="Edit/View Fees Summary">Edit/View</a></li>
										<li><a href="<?php echo base_url('parentalportal/Parents/trashfeessummary'); ?>" title="Trash Fees Summary">Trash</a></li>
                                    </ul>
                                </li>
								</ul>
                        </li>
							<li class="<?php if($uri3 == 'addroute' || $uri3 == 'viewroute' || $uri3 == 'editroute' || $uri3 == 'trashroute' || $uri3 == 'addtransportdriver' || $uri3 == 'viewtransportdriver' || $uri3 == 'edittransportdriver' || $uri3 == 'trashtransportdriver' || $uri3 == 'addtransportconductor' || $uri3 == 'viewtransportconductor' || $uri3 == 'edittransportconductor' || $uri3 == 'trashtransportconductor' || $uri3 == 'addbus' || $uri3 == 'viewbus' || $uri3 == 'editbus' || $uri3 == 'trashbus'){ echo 'open'; } ?>">
                            <a href="#" title="Transport Management" class="dd"><i class="fa fa-tasks" aria-hidden="true"></i> Transport Management<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                            <ul>                                
                                <li class="<?php if($uri3 == 'addroute' || $uri3 == 'viewroute' || $uri3 == 'editroute' || $uri3 == 'trashroute'){ echo 'open'; } ?>"><a href="#" title="Route" class="dd2">Route<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('parentalportal/Transport/addroute'); ?>" title="Add Route">Add </a></li>
                                        <li><a href="<?php echo base_url('parentalportal/Transport/viewroute'); ?>" title="Edit/View Route">Edit/View</a></li>
										<li><a href="<?php echo base_url('parentalportal/Transport/trashroute'); ?>" title="Trash Route">Trash</a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri3 == 'addtransportdriver' || $uri3 == 'viewtransportdriver' || $uri3 == 'edittransportdriver' || $uri3 == 'trashtransportdriver'){ echo 'open'; } ?>"><a href="#" title="Driver" class="dd2">Driver<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('parentalportal/Transport/addtransportdriver'); ?>" title="Add Driver">Add </a></li>
                                        <li><a href="<?php echo base_url('parentalportal/Transport/viewtransportdriver'); ?>" title="Edit/View Driver">Edit/View</a></li>
										<li><a href="<?php echo base_url('parentalportal/Transport/trashtransportdriver'); ?>" title="Trash Driver">Trash</a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri3 == 'addtransportconductor' || $uri3 == 'viewtransportconductor' || $uri3 == 'edittransportconductor' || $uri3 == 'trashtransportconductor'){ echo 'open'; } ?>"><a href="#" title="Conductor" class="dd2">Conductor<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('parentalportal/Transport/addtransportconductor'); ?>" title="Add Conductor">Add </a></li>
                                        <li><a href="<?php echo base_url('parentalportal/Transport/viewtransportconductor'); ?>" title="Edit/View Conductor">Edit/View</a></li>
										<li><a href="<?php echo base_url('parentalportal/Transport/trashtransportconductor'); ?>" title="Trash Conductor">Trash</a></li>
                                    </ul>
                                </li>
								<li class="<?php if($uri3 == 'addbus' || $uri3 == 'viewbus' || $uri3 == 'editbus' || $uri3 == 'trashbus'){ echo 'open'; } ?>"><a href="#" title="Bus Details" class="dd2">Bus Details<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
                                    <ul>
                                        <li><a href="<?php echo base_url('parentalportal/Transport/addbus'); ?>" title="Add Bus Details">Add </a></li>
                                        <li><a href="<?php echo base_url('parentalportal/Transport/viewbus'); ?>" title="Edit/View Bus Details">Edit/View</a></li>
										<li><a href="<?php echo base_url('parentalportal/Transport/trashbus'); ?>" title="Trash Bus Details">Trash</a></li>
                                    </ul>
                                </li>
								</ul>
                        </li>
						<li class="<?php if($uri3 == 'addstudentregistration' || $uri3 == 'viewstudentregistration' || $uri3 == 'editstudentregistration' || $uri3 == 'trashstudentregistration' || $uri3 == 'addstudentsubject' || $uri3 == 'viewstudentsubject' || $uri3 == 'editstudentsubject' || $uri3 == 'trashstudentsubject'){ echo 'open'; } ?>">
                            <a href="#" title="Student Management" class="dd"><i class="fa fa-tasks" aria-hidden="true"></i> Student Management<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
							<ul>                                
                                <li class="<?php if($uri3 == 'addstudentregistration' || $uri3 == 'viewstudentregistration' || $uri3 == 'editstudentregistration' || $uri3 == 'trashstudentregistration'){ echo 'open'; } ?>"><a href="#" title="Student Registration" class="dd2">Student Registration<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
									<ul> 
                                        <li><a href="<?php echo base_url('parentalportal/Studentmanagement/addstudentregistration'); ?>" title="Add Student Registration">Add </a></li>
                                        <li><a href="<?php echo base_url('parentalportal/Studentmanagement/viewstudentregistration'); ?>" title="Edit/View Student Registration">Edit/View</a></li>
										<li><a href="<?php echo base_url('parentalportal/Studentmanagement/trashstudentregistration'); ?>" title="Trash Student Registration">Trash</a></li>
								</ul>
								</li>
								<li class="<?php if($uri3 == 'addstudentsubject' || $uri3 == 'viewstudentsubject' || $uri3 == 'editstudentsubject' || $uri3 == 'trashstudentsubject'){ echo 'open'; } ?>"><a href="#" title="Subject Details" class="dd2">Subject Details<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
									<ul> 
                                        <li><a href="<?php echo base_url('parentalportal/Studentmanagement/addstudentsubject'); ?>" title="Add Subject Details">Add </a></li>
                                        <li><a href="<?php echo base_url('parentalportal/Studentmanagement/viewstudentsubject'); ?>" title="Edit/View Student Registration">Edit/View</a></li>
										<li><a href="<?php echo base_url('parentalportal/Studentmanagement/trashstudentsubject'); ?>" title="Trash Student Registration">Trash</a></li>
								</ul>
								</li>
							</ul>	
                        </li>
						<li class="<?php if($uri3 == 'addassignment' || $uri3 == 'viewassignment' || $uri3 == 'editassignment' || $uri3 == 'trashassignment' || $uri3 == 'addexamtimetable' || $uri3 == 'viewexamtimetable' || $uri3 == 'editexamtimetable' || $uri3 == 'trashexamtimetable' || $uri3 == 'addclass' || $uri3 == 'viewclass' || $uri3 == 'editclass' || $uri3 == 'trashclass' || $uri3 == 'addsection' || $uri3 == 'viewsection' || $uri3 == 'editsection' || $uri3 == 'trashsection' || $uri3 == 'addsubject' || $uri3 == 'viewsubject' || $uri3 == 'editsubject' || $uri3 == 'trashsubject' || $uri3 == 'addsyllabus' || $uri3 == 'viewsyllabus' || $uri3 == 'editsyllabus' || $uri3 == 'trashsyllabus' || $uri3 == 'addtestpaper' || $uri3 == 'viewtestpaper' || $uri3 == 'edittestpaper' || $uri3 == 'trashtestpaper' || $uri3 == 'addquestionpaper' || $uri3 == 'viewquestionpaper' || $uri3 == 'editquestionpaper' || $uri3 == 'trashquestionpaper'){ echo 'open'; } ?>">
                            <a href="#" title="Academic" class="dd"><i class="fa fa-tasks" aria-hidden="true"></i> Academic<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
							<ul>                                
                                <li class="<?php if($uri3 == 'addassignment' || $uri3 == 'viewassignment' || $uri3 == 'editassignment' || $uri3 == 'trashassignment'){ echo 'open'; } ?>"><a href="#" title="Assignment Details" class="dd2">Assignment Details<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
									<ul> 
                                        <li><a href="<?php echo base_url('parentalportal/Academic/addassignment'); ?>" title="Add Assignment Details">Add </a></li>
                                        <li><a href="<?php echo base_url('parentalportal/Academic/viewassignment'); ?>" title="Edit/View Assignment Details">Edit/View</a></li>
										<li><a href="<?php echo base_url('parentalportal/Academic/trashassignment'); ?>" title="Trash Student Registration">Trash</a></li>
								</ul>
								</li>
								 <li class="<?php if($uri3 == 'addexamtimetable' || $uri3 == 'viewexamtimetable' || $uri3 == 'editexamtimetable' || $uri3 == 'trashexamtimetable'){ echo 'open'; } ?>"><a href="#" title="Exam Time Table" class="dd2">Exam Time Table<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
									<ul> 
                                        <li><a href="<?php echo base_url('parentalportal/Academic/addexamtimetable'); ?>" title="Add Exam Time Table">Add </a></li>
                                        <li><a href="<?php echo base_url('parentalportal/Academic/viewexamtimetable'); ?>" title="Edit/View Exam Time Table">Edit/View</a></li>
										<li><a href="<?php echo base_url('parentalportal/Academic/trashexamtimetable'); ?>" title="Trash Exam Time Table">Trash</a></li>
								</ul>
								</li>
								 <li class="<?php if($uri3 == 'addclass' || $uri3 == 'viewclass' || $uri3 == 'editclass' || $uri3 == 'trashclass'){ echo 'open'; } ?>"><a href="#" title="Exam Class" class="dd2">Class<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
									<ul> 
                                        <li><a href="<?php echo base_url('parentalportal/Academic/addclass'); ?>" title="Add Class">Add </a></li>
                                        <li><a href="<?php echo base_url('parentalportal/Academic/viewclass'); ?>" title="Edit/View Class">Edit/View</a></li>
										<li><a href="<?php echo base_url('parentalportal/Academic/trashclass'); ?>" title="Trash Class">Trash</a></li>
								</ul>
								</li>
								<li class="<?php if($uri3 == 'addsection' || $uri3 == 'viewsection' || $uri3 == 'editsection' || $uri3 == 'trashsection'){ echo 'open'; } ?>"><a href="#" title="Section" class="dd2">Section<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
									<ul> 
                                        <li><a href="<?php echo base_url('parentalportal/Academic/addsection'); ?>" title="Add Section">Add </a></li>
                                        <li><a href="<?php echo base_url('parentalportal/Academic/viewsection'); ?>" title="Edit/View Section">Edit/View</a></li>
										<li><a href="<?php echo base_url('parentalportal/Academic/trashsection'); ?>" title="Trash Section">Trash</a></li>
								</ul>
								</li>
								<li class="<?php if($uri3 == 'addsubject' || $uri3 == 'viewsubject' || $uri3 == 'editsubject' || $uri3 == 'trashsubject'){ echo 'open'; } ?>"><a href="#" title="Subject" class="dd2">Subject<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
									<ul> 
                                        <li><a href="<?php echo base_url('parentalportal/Academic/addsubject'); ?>" title="Add subject">Add </a></li>
                                        <li><a href="<?php echo base_url('parentalportal/Academic/viewsubject'); ?>" title="Edit/View Subject">Edit/View</a></li>
										<li><a href="<?php echo base_url('parentalportal/Academic/trashsubject'); ?>" title="Trash Subject">Trash</a></li>
								</ul>
								</li>
								<li class="<?php if($uri3 == 'addsyllabus' || $uri3 == 'viewsyllabus' || $uri3 == 'editsyllabus' || $uri3 == 'trashsyllabus'){ echo 'open'; } ?>"><a href="#" title="Syllabus" class="dd2">Syllabus<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
									<ul> 
                                        <li><a href="<?php echo base_url('parentalportal/Academic/addsyllabus'); ?>" title="Add Syllabus">Add </a></li>
                                        <li><a href="<?php echo base_url('parentalportal/Academic/viewsyllabus'); ?>" title="Edit/View Syllabus">Edit/View</a></li>
										<li><a href="<?php echo base_url('parentalportal/Academic/trashsyllabus'); ?>" title="Trash Syllabus">Trash</a></li>
								</ul>
								</li>
								<li class="<?php if($uri3 == 'addtestpaper' || $uri3 == 'viewtestpaper' || $uri3 == 'edittestpaper' || $uri3 == 'trashtestpaper'){ echo 'open'; } ?>"><a href="#" title="Test Paper" class="dd2">Test Paper<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
									<ul> 
                                        <li><a href="<?php echo base_url('parentalportal/Academic/addtestpaper'); ?>" title="Add Test Paper">Add </a></li>
                                        <li><a href="<?php echo base_url('parentalportal/Academic/viewtestpaper'); ?>" title="Edit/View Test Paper">Edit/View</a></li>
										<li><a href="<?php echo base_url('parentalportal/Academic/trashtestpaper'); ?>" title="Trash Test Paper">Trash</a></li>
								</ul>
								</li>
								<li class="<?php if($uri3 == 'addquestionpaper' || $uri3 == 'viewquestionpaper' || $uri3 == 'editquestionpaper' || $uri3 == 'trashquestionpaper'){ echo 'open'; } ?>"><a href="#" title="Question Paper" class="dd2">Question Paper<i class="fa fa-angle-down dd-icon" aria-hidden="true"></i></a>
									<ul> 
                                        <li><a href="<?php echo base_url('parentalportal/Academic/addquestionpaper'); ?>" title="Add Question Paper">Add </a></li>
                                        <li><a href="<?php echo base_url('parentalportal/Academic/viewquestionpaper'); ?>" title="Edit/View Question Paper">Edit/View</a></li>
										<li><a href="<?php echo base_url('parentalportal/Academic/trashquestionpaper'); ?>" title="Trash Question Paper">Trash</a></li>
								</ul>
								</li>
							</ul>	
                        </li>
					
					</ul>
                </div>
                <!-- end navigation -->
            </div>
        </div>
		<!-- parental portal -->
       <!--<div id="stuff" class="tab-pane">
            <div class="leftcol-content">
                <div class="heading1">
                    <h4><i class="fa fa-twitter" aria-hidden="true"></i> Social</h4>
                </div>
                <ul class="social-stats">
                    <li>
                        <a href="#" title="" class="orange-square"><i class="fa fa-rss" aria-hidden="true"></i></a>
                        <div>
                            <h4>1,286</h4>
                            <span>total feed subscribers</span>
                        </div>
                    </li>
                    <li>
                        <a href="#" title="" class="blue-square"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                        <div>
                            <h4>12,683</h4>
                            <span>total twitter followers</span>
                        </div>
                    </li>
                    <li>
                        <a href="#" title="" class="dark-blue-square"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                        <div>
                            <h4>530,893</h4>
                            <span>total facebook likes</span>
                        </div>
                    </li>
                </ul>
            </div>
        </div>-->
    </div>
</div>
<!-- end leftcol -->