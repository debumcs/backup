<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
            <div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Media">Media</a></li>
                    <li class="active"><a href="#" title="Photo Gallery">Photo Gallery</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> View Photo Gallery</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>View Photo Gallery</h3>-->
                            <!-- start table -->
				
						<div class="table-box">
						<div class="table-responsive">
                        <table class="table table-striped table-bordered table-checks media-table dataTable" id="example">
                            <thead>
                                <tr>
								    <th>S.No.</th> 
                                    <th>Image</th>
                                    <th>Title</th>					
									<th>Sort Order</th>
									<th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
								<?php $y = 1;
									if(count($allphotogallery) > 0){
									foreach ($allphotogallery as $x) {  ?>
                                <tr class="odd">
								    <td><?php echo $y; ?></td>				
									<td><img src="<?php echo base_url().$x['image'];?>" width="50px" /></td>			
									<td><?php echo $x['title']; ?></td>
									<td><?php echo $x['sort_order']; ?></td>
									<td><?php echo $x['status']; ?></td>     
                                    <td>
                                        <ul class="navbar-icons">
                                            <li><a href="<?php echo base_url().'Media/editphotogallery/'.$x['photogallery_id']; ?>" class="tip" title="Edit Photo Gallery" data-original-title="Parameters"><i class="fa fa-edit" aria-hidden="true"></i></a></li>
											<li><a href="<?php echo base_url().'Media/suspend/'.$x['photogallery_id']; ?>" class="tip" title="Trash Photo Gallery" data-original-title="Parameters"><i class="fa fa-remove" aria-hidden="true"></i></a></li>
                                        </ul>
                                    </td>
                                </tr>
								<?php $y++;} } else{ ?>
									<tr><td colspan="12" align="center">No Data Available</td></tr>
									<?php } ?>
                                </tbody>
                        </table>
                    </div>
                </div>
                <!-- end table -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>