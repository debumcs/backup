<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
            <div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Media">Media</a></li>
                    <li class="active"><a href="#" title="Latest Happenings">Latest Happenings</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> View Latest Happenings</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>View Latest Happenings</h3>-->
                            <!-- start table -->
				
						<div class="table-box">
						<div class="table-responsive">
                        <table class="table table-striped table-bordered table-checks media-table dataTable" id="example">
                            <thead>
                                <tr>
								    <th>S.No.</th>                      
                                    <th>Title</th>					
									<th>Sort Order</th>
									<th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
								<?php $y = 1;
									if(count($alllatesthappenings) > 0){
									foreach ($alllatesthappenings as $x) {  ?>
                                <tr class="odd">
								    <td><?php echo $y; ?></td>
									<td><?php echo $x['title']; ?></td>
									<td><?php echo $x['sort_order']; ?></td>
									<td><?php echo $x['status']; ?></td>     
                                    <td>
                                        <ul class="navbar-icons">
                                            <li><a href="<?php echo base_url().'Media/editlatesthappenings/'.$x['latesthappenings_id']; ?>" class="tip" title="Edit Latest Happenings" data-original-title="Parameters"><i class="fa fa-edit" aria-hidden="true"></i></a></li>
											<li><a href="<?php echo base_url().'Media/suspendlatesthappenings/'.$x['latesthappenings_id']; ?>" class="tip" title="Trash Latest Happenings" data-original-title="Parameters"><i class="fa fa-remove" aria-hidden="true"></i></a></li>
                                        </ul>
                                    </td>
                                </tr>
								<?php $y++;} } else{ ?>
									<tr><td colspan="12" align="center">No Data Available</td></tr>
									<?php } ?>
                                </tbody>
                        </table>
                    </div>
                </div>
                <!-- end table -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>