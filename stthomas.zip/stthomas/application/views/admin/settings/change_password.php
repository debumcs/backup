<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Setting">Settings</a></li>
                    <li class="active"><a href="<?php echo base_url('Settings/changepassword');?>" title="Change Password">Change Password</a></li>
                </ul>
		<?php $this->load->view('admin/header_right'); ?>
            <!-- start content-box -->
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Change Password</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Change Password</h3>-->
                            <!-- start form -->
							<form id="changepassword" name="changepassword" action="<?=base_url('Settings/updatepassword')?>" method="POST" enctype="multipart/form-data">
                            <div class="form">                                
                                <div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Previous Password:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="password" placeholder="Password" id="pre_password" name="pre_password" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>New Password:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="password" placeholder="New Password" id="new_password" name="new_password" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>New Confirm Password:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="password" placeholder="New Confirm Password" id="con_password" name="con_password" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>