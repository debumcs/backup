<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li class="active"><a href="#" title="Learning">Learning</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <!-- start content-box -->
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Edit Learning</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Edit Learning</h3>-->
                            <!-- start form -->
							<form  action="<?php print base_url('Learning/updatelearning'); ?>" method="POST" enctype="multipart/form-data">
                            <div class="form"> 
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Category:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <select name="category" id="category" class="form-control">                         
										<option value="primaryschool"<?php if ($learning['category'] == 'primaryschool') echo ' selected="selected"'; ?>>Primary School</option>
										<option value="middleschool"<?php if ($learning['category'] == 'middleschool') echo ' selected="selected"'; ?>>Middle School</option>
										<option value="secondaryschool"<?php if ($learning['category'] == 'secondaryschool') echo ' selected="selected"'; ?>>Secondary School</option>
										<option value="seniorsecondaryschool"<?php if ($learning['category'] == 'seniorsecondaryschool') echo ' selected="selected"'; ?>>Senior Secondary School</option>
										</select>
                                        </div>
                                    </div>
                                </div>
                                <div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Title:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Title" id="title" name="title" value="<?php echo $learning['title']?>" class="form-control">
											 <input type="hidden" name="learning_id" value="<?php echo $learning['learning_id']; ?>">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Image:</label>
                                        </div>
                                        <div class="col-md-3">
										    <img src="<?php echo base_url().$learning['image'];?>" style="width:150px; height:100px;" class="img-responsive" />
                                        </div>
										<div class="col-md-3">
                                            <input type="file" placeholder="Image" class="form-control" id="image" name="image">
											<input type="hidden" name="previousimage" value="<?php echo $learning['image'];?>">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Content:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <textarea  name="content" id="contents" cols="10" rows="3" class="editor form-control"><?php echo $learning['content']; ?></textarea>
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Sort Order:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Sort Order" id="sort_order" value="<?php echo $learning['sort_order']?>" name="sort_order" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>