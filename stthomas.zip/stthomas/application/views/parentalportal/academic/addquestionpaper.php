<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Academic">Academic</a></li>
                    <li class="active"><a href="#" title="Question Paper">Question paper</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Add Question paper</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Add Bus Details</h3>-->
                            <!-- start form -->
							<form  action="<?php echo base_url('parentalportal/Academic/savequestionpaper'); ?>" method="POST" enctype="multipart/form-data">
                            <div class="form">
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Class Name:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <select name="class_id" class="form-control" onChange="getSubCat(this.value)">
												<option selected disabled>Select Class</option>
												<?php foreach ($classcat as $x) { ?>
												<option value="<?php echo $x['class_id']; ?>"><?php echo $x['class_name']; ?></option>
												<?php } ?>
										</select>
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Subject Name:</label>
                                        </div>
                                        <div class="col-md-9" id="getsub">
                                            <select name="subject_id" id="sub_cat_id" class="form-control">
												<option value="">Select Subject</option>
										</select>
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Question Paper File:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="file" placeholder="Test Paper" class="form-control" id="questionpaper_pdf" name="questionpaper_pdf">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Session:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Session" class="form-control" id="session" name="session">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>
<script type="text/javascript">
				function getSubCat(class_id)
				{	
					$.ajax({
						type:'POST',
						url : "<?php echo base_url(); ?>parentalportal/Academic/getsubcategorydetailsquestion",
						data:{class_id:class_id},	
						success:function(response){
							console.log(response);
							$("#getsub").html('');
							$("#getsub").html(response);
							return false;
						}
					});					
					return false;					
				}	
				</script>
