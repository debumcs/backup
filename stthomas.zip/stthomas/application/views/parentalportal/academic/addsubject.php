<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Academic">Academic</a></li>
                    <li class="active"><a href="#" title="Subject">Subject</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Add Subject</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Add Bus Details</h3>-->
                            <!-- start form -->
							<form  action="<?php echo base_url('parentalportal/Academic/savesubject'); ?>" method="POST" enctype="multipart/form-data">
                            <div class="form">
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Class Name:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <select name="class_id" id="" class="form-control">
												<option selected disabled>Select Class</option>
												<?php foreach ($classcat as $x) { ?>
												<option value="<?php echo $x['class_id']; ?>"><?php echo $x['class_name']; ?></option>
												<?php } ?>
										</select>
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Subject Name:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Subject Name" id="subject_name" name="subject_name" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>	Subject Code:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Subject Code" id="subject_code" name="subject_code" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>