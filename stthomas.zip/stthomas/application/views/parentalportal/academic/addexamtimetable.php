<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Academic">Academic</a></li>
                    <li class="active"><a href="#" title="Exam Time Table">Exam Time Table</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Add Exam Time Table</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Add Assignment Details</h3>-->
                            <!-- start form -->
							<form  action="<?php echo base_url('parentalportal/Academic/saveexamtimetable'); ?>" method="POST" enctype="multipart/form-data">
                            <div class="form">
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Class:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <select name="s_class" class="form-control">
												<option selected disabled>Select Class</option>
												<option value="Nursery">Nursery</option>
												<option value="KG">KG</option>
												<option value="First">First</option>
												<option value="Second">Second</option>
												<option value="Third">Third</option>
												<option value="Fourth">Fourth</option>
												<option value="Fifth">Fifth</option>
										    </select>
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Subject:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Subject" id="subject" name="subject" class="form-control">
                                        </div>
                                    </div>
                                </div>
								 <div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Teacher Name:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Teacher Name" id="teacher_name" name="teacher_name" class="form-control">
                                        </div>
                                    </div>
                                </div>
								 <div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Exam Date:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="date" placeholder="Exam Date" id="exam_date" name="exam_date" class="form-control">
                                        </div>
                                    </div>
                                </div>
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Exam Time:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="time" placeholder="Exam Time" id="exam_time" name="exam_time" class="form-control">
                                        </div>
                                    </div>
                                </div>									
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>