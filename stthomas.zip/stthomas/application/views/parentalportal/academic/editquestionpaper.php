<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Academic">Academic</a></li>
                    <li class="active"><a href="#" title="Question paper">Question paper</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <!-- start content-box -->
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Edit Question Paper</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Edit Bus Details</h3>-->
                            <!-- start form -->
							<form  action="<?php print base_url('parentalportal/Academic/updatequestionpaper'); ?>" method="POST" enctype="multipart/form-data">
                            <div class="form"> 
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Class Name:</label>
                                        </div>
                                        <div class="col-md-9">
											<select name="class_id" class="form-control">
												<?php foreach ($classcat as $x) { ?>
												<option value="<?php echo $x['class_id']; ?>" <?php if($x['class_id'] == $questionpaper['class_id']){echo "selected";}else{}?>><?php echo $x['class_name']; ?></option>
												<?php } ?>
											</select>
											<input type="hidden" id="questionpaper_id" name="questionpaper_id" value="<?php echo $questionpaper['questionpaper_id']; ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Subject Name:</label>
                                        </div>
                                        <div class="col-md-9">
											<select name="subject_id" class="form-control">
												<option value="<?php echo $questionpaper['subject_id']; ?>"><?php echo $questionpaper['subjectname']; ?></option>
											</select>
                                        </div>
                                    </div>
                                </div>
								
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Test Paper File:</label>
                                        </div>
                                        <div class="col-md-3">
                                            <?php echo $questionpaper['questionpaper_pdf'];?>
                                        </div>
										<div class="col-md-3">
                                            <input type="file" placeholder="Question paper File" class="form-control" id="questionpaper_pdf" name="questionpaper_pdf">
											<input type="hidden" name="previousdoc" value="<?php echo $questionpaper['questionpaper_pdf'];?>">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Session:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Session" class="form-control" id="session" name="session" value="<?php echo $questionpaper['session'];?>">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>
