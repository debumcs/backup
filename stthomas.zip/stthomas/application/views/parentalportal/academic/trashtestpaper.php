<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Academic">Academic</a></li>
                    <li class="active"><a href="#" title="Test Paper">Test Paper</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <!-- start content-box -->
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Trash Test Paper</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Trash Bus Details</h3>-->
                            <!-- start table -->
				
						<div class="table-box">
						<div class="table-responsive">
                        <table class="table table-striped table-bordered table-checks media-table dataTable" id="example">
                            <thead>
                                <tr>
									<th>S.No.</th>
								    <th>Class Name</th>
									<th>Subject Name</th>
									<th>Test paper</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
								<?php $y = 1;
									if(count($alltestpaper) > 0){
									foreach ($alltestpaper as $x) {  ?>
                                   <tr class="odd">
								    <td><?php echo $y; ?></td>		
									<<td><?php echo $x['classname']; ?></td>
									<td><?php echo $x['subjectname']; ?></td>
									<td><?php echo $x['testpaper_pdf']; ?></td>
                                    <td>
                                        <ul>
                                            <li><a href="<?php echo base_url().'parentalportal/Academic/reactivetestpaper/'.$x['testpaper_id']; ?>" class="btn btn-danger btn-sm" title="Reactive">Reactive</a></li>
                                        </ul>
                                    </td>
                                </tr>
								<?php $y++;} } else{ ?>
									<tr><td colspan="12" align="center">No Data Available</td></tr>
									<?php } ?>
                                </tbody>
                        </table>
                    </div>
                </div>
                <!-- end table -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>