<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
            <div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Academic">Academic</a></li>
                    <li class="active"><a href="#" title="Exam Time Table">Exam Time Table</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> View Exam Time Table</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>View Assignment Details</h3>-->
                            <!-- start table -->
				
						<div class="table-box">
						<div class="table-responsive">
                        <table class="table table-striped table-bordered table-checks media-table dataTable" id="example">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
									<th>Class</th>	
									<th>Subject</th>
									<th>Teacher name</th>
									<th>Exam Date</th>
									<th>Exam Time</th>				
									<th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
								<?php $y = 1;
									if(count($allexamtimetable) > 0){
									foreach ($allexamtimetable as $x) {  ?>
                                <tr class="odd">
								    <td><?php echo $y; ?></td>
									<td><?php echo $x['s_class']; ?></td>
									<td><?php echo $x['subject']; ?></td>
									<td><?php echo $x['teacher_name']; ?></td>
									<td><?php echo $x['exam_date']; ?></td>
									<td><?php echo $x['exam_time']; ?></td>
									<td><?php echo $x['status']; ?></td>     
                                    <td>
                                        <ul class="navbar-icons">
                                           <li><a href="<?php echo base_url().'parentalportal/Academic/editexamtimetable/'.$x['examtimetable_id']; ?>" class="tip" title="Edit Exam Time Table" data-original-title="Parameters"><i class="fa fa-edit" aria-hidden="true"></i></a></li>
											<li><a href="<?php echo base_url().'parentalportal/Academic/suspendexamtimetable/'.$x['examtimetable_id']; ?>" class="tip" title="Trash Exam Time Table" data-original-title="Parameters"><i class="fa fa-remove" aria-hidden="true"></i></a></li>
                                        </ul>
                                    </td>
                                </tr>
								<?php $y++;} } else{ ?>
									<tr><td colspan="12" align="center">No Data Available</td></tr>
									<?php } ?>
                                </tbody>
                        </table>
                    </div>
                </div>
                <!-- end table -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>