<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
            <div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Academic">Academic</a></li>
                    <li class="active"><a href="#" title="Test Paper">Test Paper </a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> View Test Paper</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>View Bus Details</h3>-->
                            <!-- start table -->
				
						<div class="table-box">
						<div class="table-responsive">
                        <table class="table table-striped table-bordered table-checks media-table dataTable" id="example">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
									<th>Class Name</th>
									<th>Subject Name</th>
									<th>Test Paper </th>
									<th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
								<?php $y = 1;
									if(count($alltestpaper) > 0){
									foreach ($alltestpaper as $x) {  ?>
                                <tr class="odd">
								    <td><?php echo $y; ?></td>
									<td><?php echo $x['classname']; ?></td>
									<td><?php echo $x['subjectname']; ?></td>
									<td><?php echo $x['testpaper_pdf']; ?></td>
									<td><?php echo $x['status']; ?></td>     
                                    <td>
                                        <ul class="navbar-icons">
                                           <li><a href="<?php echo base_url().'parentalportal/Academic/edittestpaper/'.$x['testpaper_id']; ?>" class="tip" title="Edit Test Paper" data-original-title="Parameters"><i class="fa fa-edit" aria-hidden="true"></i></a></li>
											<li><a href="<?php echo base_url().'parentalportal/Academic/suspendtestpaper/'.$x['testpaper_id']; ?>" class="tip" title="Trash Test Paper" data-original-title="Parameters"><i class="fa fa-remove" aria-hidden="true"></i></a></li>
                                        </ul>
                                    </td>
                                </tr>
								<?php $y++;} } else{ ?>
									<tr><td colspan="12" align="center">No Data Available</td></tr>
									<?php } ?>
                                </tbody>
                        </table>
                    </div>
                </div>
                <!-- end table -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>