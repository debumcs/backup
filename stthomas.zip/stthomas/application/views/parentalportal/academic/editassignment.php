<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Academic">Academic</a></li>
                    <li class="active"><a href="#" title="Assignment Details">Assignment Details</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <!-- start content-box -->
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Edit Assignment Details</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Edit Assignment Details</h3>-->
                            <!-- start form -->
							<form  action="<?php print base_url('parentalportal/Academic/updateassignment'); ?>" method="POST" enctype="multipart/form-data">
                            <div class="form">
								<div class="control-group">
                                    <div class="row">
										<div class="col-md-3">
                                           <label>Type:</label>
                                        </div>
										<div class="col-md-9">
											<select name="type" class="form-control">
												<option selected disabled>Select Type</option>
												<option value="Home Work" <?php if($assignment['type'] == 'Home Work') { echo 'selected'; } ?>>Home Work</option>
												<option value="Activity" <?php if($assignment['type'] == 'Activity') { echo 'selected'; } ?>>Activity</option>
												<option value="Project" <?php if($assignment['type'] == 'Project') {echo 'selected'; } ?>>Project</option>
										    </select>
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Teacher Name:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" id="teacher_name" name="teacher_name" class="form-control" value="<?php echo $assignment['teacher_name']; ?>">
											<input type="hidden" id="assignment_id" name="assignment_id" value="<?php echo $assignment['assignment_id']; ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
										<div class="col-md-3">
                                           <label>Class:</label>
                                        </div>
										<div class="col-md-9">
											<select name="s_class" class="form-control">
												<option selected disabled>Select Class</option>
												<option value="Nursery" <?php if($assignment['s_class'] == 'Nursery') { echo 'selected'; } ?>>Nursery</option>
												<option value="KG" <?php if($assignment['s_class'] == 'KG') { echo 'selected'; } ?>>KG</option>
												<option value="First" <?php if($assignment['s_class'] == 'First') {echo 'selected'; } ?>>First</option>
												<option value="Second" <?php if($assignment['s_class'] == 'Second') { echo 'selected'; } ?>>Second</option>
												<option value="Third" <?php if($assignment['s_class'] == 'Third') { echo 'selected'; } ?>>Third</option>
												<option value="Fourth" <?php if($assignment['s_class'] == 'Fourth') { echo 'selected'; } ?>>Fourth</option>
												<option value="Fifth" <?php if($assignment['s_class'] == 'Fifth') { echo 'selected'; } ?>>Fifth</option>
										    </select>
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Subject:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" id="subject" name="subject" class="form-control" value="<?php echo $assignment['subject']; ?>">
                                        </div>
                                    </div>
                                </div>
								
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Title:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Title" id="title" name="title" value="<?php echo $assignment['title']; ?>" class="form-control">	
													
                                        </div>
                                    </div>
                                </div>
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>