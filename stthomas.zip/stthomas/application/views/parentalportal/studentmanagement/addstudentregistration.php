<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
					<li><a href="#" title="Student Management">Student Management</a></li>
                    <li class="active"><a href="#" title="Student Registration">Student Registration</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Add Student Registration</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Add Student Registration</h3>-->
                            <!-- start form -->
							<form  action="<?php echo base_url('parentalportal/Studentmanagement/savestudentregistration'); ?>" method="POST" enctype="multipart/form-data">
                            <div class="form">
							        <!-- student Details -->
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h4>Student Details:</h4>
                                        </div>
                                    </div>
                                    </div>							
                                <div class="control-group">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label>Name:</label>
											<input type="text" placeholder="Name" id="s_name" name="s_name" class="form-control">
                                        </div>
                                        <div class="col-md-4">
											<label>Image:</label>
                                            <input type="file" id="s_image" name="s_image" class="form-control">
                                        </div>
										<div class="col-md-4">
                                            <label>Admission No:</label>
											<input type="text" placeholder="Admission No" id="s_admissionno" name="s_admissionno" class="form-control">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label>Roll No:</label>
											<input type="text" placeholder="Roll No" id="s_rollno" name="s_rollno" class="form-control">
                                        </div>
										<div class="col-md-4">
                                            <label>Class:</label>
											<select name="s_class" class="form-control">
												<option selected disabled>Select Class</option>
												<option value="Nursery">Nursery</option>
												<option value="KG">KG</option>
												<option value="First">First</option>
												<option value="Second">Second</option>
												<option value="Third">Third</option>
												<option value="Fourth">Fourth</option>
												<option value="Fifth">Fifth</option>
										    </select>
                                        </div>	
										<div class="col-md-4">
                                            <label>Date Of Birth:</label>
											<input type="date" id="s_dob" name="s_dob" class="form-control">
                                        </div>
										 
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label>Date Of Joining:</label>
											<input type="date" id="s_dateofjoining" name="s_dateofjoining" class="form-control">
                                        </div>
										<div class="col-md-4">
                                            <label>Date Of Admission:</label>
											<input type="date" id="s_dateofadmission" name="s_dateofadmission" class="form-control">
                                        </div>
										<div class="col-md-4">
                                            <label>Blood Group:</label>
											<select name="s_bloodgroup" class="form-control">
												<option selected disabled>Select Blood Group</option>
												<option value="O +">O +</option>
												<option value="O -">O -</option>
												<option value="A +">A +</option>
												<option value="A -">A -</option>
												<option value="B +">B +</option>
												<option value="B -">B -</option>
												<option value="AB +">AB +</option>
												<option value="AB -">AB -</option>
										    </select>
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label>Nationality:</label>
											<input type="text" placeholder="Nationality" id="s_nationality" name="s_nationality" class="form-control">
                                        </div>
										<div class="col-md-4">
                                            <label>Present Address:</label>
											<input type="text" placeholder="Present Address" id="s_presentaddress" name="s_presentaddress" class="form-control">
                                        </div>
										<div class="col-md-4">
                                            <label>Permanent Address:</label>
											<input type="text" placeholder="Permanent Address" id="s_permanentaddress" name="s_permanentaddress" class="form-control">
                                        </div>
                                    </div>
                                    </div>
									<!-- Father Details-->
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h4>Father Details:</h4>
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label>Name:</label>
											<input type="text" placeholder="Name" id="f_name" name="f_name" class="form-control">
                                        </div>
                                        <div class="col-md-4">
											<label>Image:</label>
                                            <input type="file" id="f_image" name="f_image" class="form-control">
                                        </div>
										<div class="col-md-4">
                                            <label>Qualification:</label>
											<input type="text" placeholder="Qualification" id="f_qualification" name="f_qualification" class="form-control">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label>Organisation:</label>
											<input type="text" placeholder="Organisation" id="f_organisation" name="f_organisation" class="form-control">
                                        </div>
                                        <div class="col-md-4">
											<label>Occupation:</label>
                                            <input type="text" placeholder="Occupation" id="f_occupation" name="f_occupation" class="form-control">
                                        </div>
										<div class="col-md-4">
                                            <label>Designation:</label>
											<input type="text" placeholder="Designation" id="f_designation" name="f_designation" class="form-control">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label>Mobile No:</label>
											<input type="number" placeholder="Mobile No" id="f_mobileno" name="f_mobileno" class="form-control">
                                        </div>
                                        <div class="col-md-4">
											<label>Email:</label>
                                            <input type="email" placeholder="Email" id="f_email" name="f_email" class="form-control">
                                        </div>
										<div class="col-md-4">
                                            <label>Address:</label>
											<input type="text" placeholder="Address" id="f_address" name="f_address" class="form-control">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label>City:</label>
											<input type="text" placeholder="City" id="f_city" name="f_city" class="form-control">
                                        </div>
                                        <div class="col-md-4">
											<label>State:</label>
                                            <input type="text" placeholder="State" id="f_state" name="f_state" class="form-control">
                                        </div>
										<div class="col-md-4">
                                            <label>Country:</label>
											<input type="text" placeholder="Country" id="f_country" name="f_country" class="form-control">
                                        </div>
                                    </div>
                                    </div>	
									<!-- Mother details-->
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h4>Mother Details:</h4>
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label>Name:</label>
											<input type="text" placeholder="Name" id="m_name" name="m_name" class="form-control">
                                        </div>
                                        <div class="col-md-4">
											<label>Image:</label>
                                            <input type="file" id="m_image" name="m_image" class="form-control">
                                        </div>
										<div class="col-md-4">
                                            <label>Qualification:</label>
											<input type="text" placeholder="Qualification" id="m_qualification" name="m_qualification" class="form-control">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label>Organisation:</label>
											<input type="text" placeholder="Organisation" id="m_organisation" name="m_organisation" class="form-control">
                                        </div>
                                        <div class="col-md-4">
											<label>Occupation:</label>
                                            <input type="text" placeholder="Occupation" id="m_occupation" name="m_occupation" class="form-control">
                                        </div>
										<div class="col-md-4">
                                            <label>Designation:</label>
											<input type="text" placeholder="Designation" id="m_designation" name="m_designation" class="form-control">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label>Mobile No:</label>
											<input type="number" placeholder="Mobile No" id="m_mobileno" name="m_mobileno" class="form-control">
                                        </div>
                                        <div class="col-md-4">
											<label>Email:</label>
                                            <input type="email" placeholder="Email" id="m_email" name="m_email" class="form-control">
                                        </div>
										<div class="col-md-4">
                                            <label>Address:</label>
											<input type="text" placeholder="Address" id="m_address" name="m_address" class="form-control">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label>City:</label>
											<input type="text" placeholder="City" id="m_city" name="m_city" class="form-control">
                                        </div>
                                        <div class="col-md-4">
											<label>State:</label>
                                            <input type="text" placeholder="State" id="m_state" name="m_state" class="form-control">
                                        </div>
										<div class="col-md-4">
                                            <label>Country:</label>
											<input type="text" placeholder="Country" id="m_country" name="m_country" class="form-control">
                                        </div>
                                    </div>
                                    </div>
									<!--Local Guardian-->
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h4>Local Guardian Details:</h4>
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label>Name:</label>
											<input type="text" placeholder="Name" id="lg_name" name="lg_name" class="form-control">
                                        </div>
                                        <div class="col-md-4">
											<label>Image:</label>
                                            <input type="file" id="lg_image" name="lg_image" class="form-control">
                                        </div>
										<div class="col-md-4">
                                            <label>Mobile No:</label>
											<input type="text" placeholder="Mobile No" id="lg_mobileno" name="lg_mobileno" class="form-control">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-4">
											<label>Email:</label>
                                            <input type="email" placeholder="Email" id="lg_email" name="lg_email" class="form-control">
                                        </div>
										<div class="col-md-4">
                                            <label>Relation:</label>
											<input type="text" placeholder="Relation" id="lg_relation" name="lg_relation" class="form-control">
                                        </div>
										<div class="col-md-4">
                                            <label>Address:</label>
											<input type="text" placeholder="Address" id="lg_address" name="lg_address" class="form-control">
                                        </div>
                                    </div>
                                    </div>
									<!--Transport Details-->
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h4>Transport Details:</h4>
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
									<div class="col-md-3">
									<label>Route:</label>
									</div>
										<div class="col-md-9">
											<select name="route_id" class="form-control">
												<option selected disabled>Select Route</option>
												<?php foreach($routecat as $x) { ?>
												<option value="<?php echo $x['route_id']; ?>"><?php echo $x['name']; ?></option>
												<?php } ?>
										    </select>
                                        </div>
                                    </div>
                                    </div>
									
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>