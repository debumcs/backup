<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Student Management">Student Management</a></li>
                    <li class="active"><a href="#" title="Subject Details">Subject Details</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Add Subject Details</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Add Subject Details</h3>-->
                            <!-- start form -->
							<form  action="<?php echo base_url('parentalportal/Studentmanagement/savestudentsubject'); ?>" method="POST" enctype="multipart/form-data">
                            <div class="form">
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Class:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <select name="s_class" class="form-control">
												<option selected disabled>Select Class</option>
												<option value="Nursery">Nursery</option>
												<option value="KG">KG</option>
												<option value="First">First</option>
												<option value="Second">Second</option>
												<option value="Third">Third</option>
												<option value="Fourth">Fourth</option>
												<option value="Fifth">Fifth</option>
										    </select>
                                        </div>
                                    </div>
                                </div>
								 <div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Title:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Title No" id="title" name="title" class="form-control">
                                        </div>
                                    </div>
                                </div>								
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>