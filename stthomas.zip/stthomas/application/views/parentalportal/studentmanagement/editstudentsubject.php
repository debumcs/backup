<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Student Management">Student Management</a></li>
                    <li class="active"><a href="#" title="Subject Details">Subject Details</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <!-- start content-box -->
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Edit Subject Details</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Edit Subject Details</h3>-->
                            <!-- start form -->
							<form  action="<?php print base_url('parentalportal/Studentmanagement/updatestudentsubject'); ?>" method="POST" enctype="multipart/form-data">
                            <div class="form"> 								
								<div class="control-group">
                                    <div class="row">
										<div class="col-md-3">
                                           <label>Class:</label>
                                        </div>
										<div class="col-md-9">
											<select name="s_class" class="form-control">
												<option selected disabled>Select Class</option>
												<option value="Nursery" <?php if($studentsubject['s_class'] == 'Nursery') { echo 'selected'; } ?>>Nursery</option>
												<option value="KG" <?php if($studentsubject['s_class'] == 'KG') { echo 'selected'; } ?>>KG</option>
												<option value="First" <?php if($studentsubject['s_class'] == 'First') {echo 'selected'; } ?>>First</option>
												<option value="Second" <?php if($studentsubject['s_class'] == 'Second') { echo 'selected'; } ?>>Second</option>
												<option value="Third" <?php if($studentsubject['s_class'] == 'Third') { echo 'selected'; } ?>>Third</option>
												<option value="Fourth" <?php if($studentsubject['s_class'] == 'Fourth') { echo 'selected'; } ?>>Fourth</option>
												<option value="Fifth" <?php if($studentsubject['s_class'] == 'Fifth') { echo 'selected'; } ?>>Fifth</option>
										    </select>
                                        </div>
                                    </div>
                                    </div>
								
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Title:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Title" id="title" name="title" value="<?php echo $studentsubject['title']; ?>" class="form-control">	
											<input type="hidden" id="studentsubject_id" name="studentsubject_id" value="<?php echo $studentsubject['studentsubject_id']; ?>" class="form-control">		
                                        </div>
                                    </div>
                                </div>
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>