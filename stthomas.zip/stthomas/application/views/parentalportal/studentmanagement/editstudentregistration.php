<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
					<li><a href="#" title="Student Management">Student Management</a></li>
                    <li class="active"><a href="#" title="School Registration">School Registration</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <!-- start content-box -->
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Edit Student Registration</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Edit Student Registration</h3>-->
                            <!-- start form -->
							<form  action="<?php print base_url('parentalportal/Studentmanagement/updatestudentregistration'); ?>" method="POST" enctype="multipart/form-data">
                            <div class="form"> 
							<!-- student Details -->
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h4>Student Details:</h4>
                                        </div>
                                    </div>
                                    </div>
							<div class="control-group">
                                    <div class="row">				    
										 <div class="col-md-4">
										    <img src="<?php echo base_url().$studentregistration['s_image'];?>" style="width:100px; height:100px;" class="img-responsive" />
										 </div>
										 <div class="col-md-4">
										 <label>Image:</label>
                                            <input type="file" id="s_image" name="s_image" class="form-control">
											<input type="hidden" name="previousimagestudent" value="<?php echo basename($studentregistration['s_image']);?>">
                                        </div>
										<div class="col-md-4">
                                            <label>Name:</label>
											<input type="text" id="s_name" name="s_name" class="form-control" value="<?php echo $studentregistration['s_name']; ?>">
											<input type="hidden" id="studentregistration_id" name="studentregistration_id" class="form-control" value="<?php echo $studentregistration['studentregistration_id']; ?>">
                                        </div>
                                    </div>
                                    </div>
								<div class="control-group">
                                    <div class="row">
										<div class="col-md-4">
                                            <label>Admission No:</label>
											<input type="text" id="s_admissionno" name="s_admissionno" class="form-control" value="<?php echo $studentregistration['s_admissionno']; ?>">
                                        </div>
										 <div class="col-md-4">
                                            <label>Roll No:</label>
											<input type="text" id="s_rollno" name="s_rollno" class="form-control" value="<?php echo $studentregistration['s_rollno']; ?>">
                                        </div>
										<div class="col-md-4">
                                            <label>Class:</label>
											<select name="s_class" class="form-control">
												<option selected disabled>Select Class</option>
												<option value="Nursery" <?php if($studentregistration['s_class'] == 'Nursery') { echo 'selected'; } ?>>Nursery</option>
												<option value="KG" <?php if($studentregistration['s_class'] == 'KG') { echo 'selected'; } ?>>KG</option>
												<option value="First" <?php if($studentregistration['s_class'] == 'First') {echo 'selected'; } ?>>First</option>
												<option value="Second" <?php if($studentregistration['s_class'] == 'Second') { echo 'selected'; } ?>>Second</option>
												<option value="Third" <?php if($studentregistration['s_class'] == 'Third') { echo 'selected'; } ?>>Third</option>
												<option value="Fourth" <?php if($studentregistration['s_class'] == 'Fourth') { echo 'selected'; } ?>>Fourth</option>
												<option value="Fifth" <?php if($studentregistration['s_class'] == 'Fifth') { echo 'selected'; } ?>>Fifth</option>
										    </select>
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
									   <div class="col-md-4">
                                            <label>Date Of Birth:</label>
									<input type="date" id="s_dob" name="s_dob" class="form-control" value="<?php echo $studentregistration['s_dob']; ?>">
                                        </div>
                                        <div class="col-md-4">
                                            <label>Date Of Joining:</label>
											<input type="date" id="s_dateofjoining" name="s_dateofjoining" class="form-control" value="<?php echo
											$studentregistration['s_dateofjoining']; ?>">
                                        </div>
										<div class="col-md-4">
                                            <label>Date Of Admission:</label>
											<input type="date" id="s_dateofadmission" name="s_dateofadmission" class="form-control" value="<?php echo $studentregistration['s_dateofadmission']; ?>">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
										<div class="col-md-4">
                                            <label>Blood Group:</label>
											<select name="s_bloodgroup" class="form-control">
												<option selected disabled>Select Blood Group</option>
												<option value="O +" <?php if($studentregistration['s_bloodgroup'] == 'O +') {echo 'selected'; } ?>>O +</option>
												<option value="O -" <?php if($studentregistration['s_bloodgroup'] == 'O -') {echo 'selected'; } ?>>O -</option>
												<option value="A +" <?php if($studentregistration['s_bloodgroup'] == 'A +') {echo 'selected'; } ?>>A +</option>
												<option value="A -" <?php if($studentregistration['s_bloodgroup'] == 'A -') {echo 'selected'; } ?>>A -</option>
												<option value="B +" <?php if($studentregistration['s_bloodgroup'] == 'B +') {echo 'selected'; } ?>>B +</option>
												<option value="B -" <?php if($studentregistration['s_bloodgroup'] == 'B -') {echo 'selected'; } ?>>B -</option>
												<option value="AB +" <?php if($studentregistration['s_bloodgroup'] == 'AB +') {echo 'selected'; } ?>>AB +</option>
												<option value="AB -" <?php if($studentregistration['s_bloodgroup'] == 'AB -') {echo 'selected'; } ?>>AB -</option>
										    </select>
                                        </div>
										  <div class="col-md-4">
                                            <label>Nationality:</label>
											<input type="text" id="s_nationality" name="s_nationality" class="form-control" value="<?php echo $studentregistration['s_nationality']; ?>">
                                        </div>
										<div class="col-md-4">
                                            <label>Present Address:</label>
											<input type="text" id="s_presentaddress" name="s_presentaddress" class="form-control" value="<?php echo $studentregistration['s_presentaddress']; ?>">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
										<div class="col-md-4">
                                            <label>Permanent Address:</label>
											<input type="text" id="s_permanentaddress" name="s_permanentaddress" class="form-control" value="<?php echo $studentregistration['s_permanentaddress']; ?>">
                                        </div>
                                    </div>
                                    </div>
								<!-- Father Details -->
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h4>Father Details:</h4>
                                        </div>
                                    </div>
                                    </div>	
									<div class="control-group">
                                    <div class="row">				    
										 <div class="col-md-4">
										    <img src="<?php echo base_url().$studentregistration['f_image'];?>" style="width:100px; height:100px;" class="img-responsive" />
										 </div>
										 <div class="col-md-4">
										 <label>Image:</label>
                                            <input type="file" id="f_image" name="f_image" class="form-control">
											<input type="hidden" name="previousimagefather" value="<?php echo basename($studentregistration['f_image']);?>">
                                        </div>
										<div class="col-md-4">
                                            <label>Name:</label>
											<input type="text" id="f_name" name="f_name" class="form-control" value="<?php echo $studentregistration['f_name']; ?>">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
										<div class="col-md-4">
                                            <label>Qualification:</label>
											<input type="text" id="f_qualification" name="f_qualification" class="form-control" value="<?php echo $studentregistration['f_qualification']; ?>">
                                        </div>
										<div class="col-md-4">
                                            <label>Organisation:</label>
											<input type="text" id="f_organisation" name="f_organisation" class="form-control" value="<?php echo $studentregistration['f_organisation']; ?>">
                                        </div>
                                        <div class="col-md-4">
											<label>Occupation:</label>
                                            <input type="text" id="f_occupation" name="f_occupation" class="form-control" value="<?php echo $studentregistration['f_occupation']; ?>">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">                       
										<div class="col-md-4">
                                            <label>Designation:</label>
											<input type="text" id="f_designation" name="f_designation" class="form-control" value="<?php echo $studentregistration['f_designation']; ?>">
                                        </div>
										<div class="col-md-4">
                                            <label>Mobile No:</label>
											<input type="number" id="f_mobileno" name="f_mobileno" class="form-control" value="<?php echo $studentregistration['f_mobileno']; ?>">
                                        </div>
                                        <div class="col-md-4">
											<label>Email:</label>
                                            <input type="email" id="f_email" name="f_email" class="form-control" value="<?php echo $studentregistration['f_email']; ?>">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
										<div class="col-md-4">
                                            <label>Address:</label>
											<input type="text" id="f_address" name="f_address" class="form-control" value="<?php echo $studentregistration['f_address']; ?>">
                                        </div>
										<div class="col-md-4">
                                            <label>City:</label>
											<input type="text" id="f_city" name="f_city" class="form-control" value="<?php echo $studentregistration['f_city']; ?>">
                                        </div>
                                        <div class="col-md-4">
											<label>State:</label>
                                            <input type="text" id="f_state" name="f_state" class="form-control" value="<?php echo $studentregistration['f_state']; ?>">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
										<div class="col-md-4">
                                            <label>Country:</label>
											<input type="text" id="f_country" name="f_country" class="form-control" value="<?php echo $studentregistration['f_country']; ?>">
                                        </div>
                                    </div>
                                    </div>
									<!-- Mother Details -->
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h4>Mother Details:</h4>
                                        </div>
                                    </div>
                                    </div>	
									<div class="control-group">
                                    <div class="row">				    
										 <div class="col-md-4">
										    <img src="<?php echo base_url().$studentregistration['m_image'];?>" style="width:100px; height:100px;" class="img-responsive" />
										 </div>
										 <div class="col-md-4">
										 <label>Image:</label>
                                            <input type="file" id="m_image" name="m_image" class="form-control">
											<input type="hidden" name="previousimagemother" value="<?php echo basename($studentregistration['m_image']);?>">
                                        </div>
										<div class="col-md-4">
                                            <label>Name:</label>
											<input type="text" id="m_name" name="m_name" class="form-control" value="<?php echo $studentregistration['m_name']; ?>">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
										<div class="col-md-4">
                                            <label>Qualification:</label>
											<input type="text" id="m_qualification" name="m_qualification" class="form-control" value="<?php echo $studentregistration['m_qualification']; ?>">
                                        </div>
										<div class="col-md-4">
                                            <label>Organisation:</label>
											<input type="text" id="m_organisation" name="m_organisation" class="form-control" value="<?php echo $studentregistration['m_organisation']; ?>">
                                        </div>
                                        <div class="col-md-4">
											<label>Occupation:</label>
                                            <input type="text" id="m_occupation" name="m_occupation" class="form-control" value="<?php echo $studentregistration['m_occupation']; ?>">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">                       
										<div class="col-md-4">
                                            <label>Designation:</label>
											<input type="text" id="m_designation" name="m_designation" class="form-control" value="<?php echo $studentregistration['m_designation']; ?>">
                                        </div>
										<div class="col-md-4">
                                            <label>Mobile No:</label>
											<input type="number" id="m_mobileno" name="m_mobileno" class="form-control" value="<?php echo $studentregistration['m_mobileno']; ?>">
                                        </div>
                                        <div class="col-md-4">
											<label>Email:</label>
                                            <input type="email" id="m_email" name="m_email" class="form-control" value="<?php echo $studentregistration['m_email']; ?>">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
										<div class="col-md-4">
                                            <label>Address:</label>
											<input type="text" id="m_address" name="m_address" class="form-control" value="<?php echo $studentregistration['m_address']; ?>">
                                        </div>
										<div class="col-md-4">
                                            <label>City:</label>
											<input type="text" id="m_city" name="m_city" class="form-control" value="<?php echo $studentregistration['m_city']; ?>">
                                        </div>
                                        <div class="col-md-4">
											<label>State:</label>
                                            <input type="text" id="m_state" name="m_state" class="form-control" value="<?php echo $studentregistration['m_state']; ?>">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
										<div class="col-md-4">
                                            <label>Country:</label>
											<input type="text" id="m_country" name="m_country" class="form-control" value="<?php echo $studentregistration['m_country']; ?>">
                                        </div>
                                    </div>
                                    </div>
									<!-- Local Guardian Details -->
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h4>Local Guardian Details:</h4>
                                        </div>
                                    </div>
                                    </div>	
									<div class="control-group">
                                    <div class="row">				    
										 <div class="col-md-4">
										    <img src="<?php echo base_url().$studentregistration['lg_image'];?>" style="width:100px; height:100px;" class="img-responsive" />
										 </div>
										 <div class="col-md-4">
										 <label>Image:</label>
                                            <input type="file" id="lg_image" name="lg_image" class="form-control">
											<input type="hidden" name="previousimageguardation" value="<?php echo basename($studentregistration['lg_image']);?>">
                                        </div>
										<div class="col-md-4">
                                            <label>Name:</label>
											<input type="text" id="lg_name" name="lg_name" class="form-control" value="<?php echo $studentregistration['lg_name']; ?>">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
										<div class="col-md-4">
                                            <label>Mobile No:</label>
											<input type="text" id="lg_mobileno" name="lg_mobileno" class="form-control" value="<?php echo $studentregistration['lg_mobileno']; ?>">
                                        </div>
										<div class="col-md-4">
											<label>Email:</label>
                                            <input type="email" id="lg_email" name="lg_email" class="form-control" value="<?php echo $studentregistration['lg_email']; ?>">
                                        </div>
										<div class="col-md-4">
                                            <label>Relation:</label>
											<input type="text" id="lg_relation" name="lg_relation" class="form-control" value="<?php echo $studentregistration['lg_relation']; ?>">
                                        </div>
                                    </div>
                                    </div>
									<div class="control-group">
                                    <div class="row">
										<div class="col-md-4">
                                            <label>Address:</label>
											<input type="text" id="lg_address" name="lg_address" class="form-control"value="<?php echo $studentregistration['lg_address']; ?>">
                                        </div>
                                    </div>
                                    </div>
									<!-- Transport Details -->
									<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h4>Transport Details:</h4>
                                        </div>
                                    </div>
                                    </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Route:</label>
                                        </div>
                                        <div class="col-md-9">
											<select name="route_id" class="form-control">
												<?php foreach ($routecat as $x) { ?>
												<option value="<?php echo $x['route_id']; ?>" <?php if($x['route_id'] == $studentregistration['route_id']){echo "selected";}else{}?>><?php echo $x['name']; ?></option>
												<?php } ?>
											</select>
                                        </div>
                                    </div>
                                </div>									
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>