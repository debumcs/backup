<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Transport Management">Transport Management</a></li>
                    <li class="active"><a href="#" title="Bus Details">Bus Details</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <!-- start content-box -->
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Edit Bus Details</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Edit Bus Details</h3>-->
                            <!-- start form -->
							<form  action="<?php print base_url('parentalportal/Transport/updatebus'); ?>" method="POST" enctype="multipart/form-data">
                            <div class="form"> 
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Bus No:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Bus No" id="bus_number" name="bus_number" value="<?php echo $bus['bus_number']; ?>" class="form-control">	
											<input type="hidden" id="bus_id" name="bus_id" value="<?php echo $bus['bus_id']; ?>" class="form-control">		
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Driver:</label>
                                        </div>
                                        <div class="col-md-9">
											<select name="driver_id" class="form-control">
												<?php foreach ($drivercat as $x) { ?>
												<option value="<?php echo $x['transportdriver_id']; ?>" <?php if($x['transportdriver_id'] == $bus['driver_id']){echo "selected";}else{}?>><?php echo $x['name']; ?></option>
												<?php } ?>
											</select>
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Conductor:</label>
                                        </div>
                                        <div class="col-md-9">
											<select name="conductor_id" class="form-control">
												<?php foreach ($coductorcat as $x) { ?>
												<option value="<?php echo $x['transportconductor_id']; ?>" <?php if($x['transportconductor_id'] == $bus['conductor_id']){echo "selected";}else{}?>><?php echo $x['name']; ?></option>
												<?php } ?>
											</select>
                                        </div>
                                    </div>
                                </div>									
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>