<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Transport Management">Transport Management</a></li>
                    <li class="active"><a href="#" title="Coductor">Coductor</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Add Coductor</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Add Coductor</h3>-->
                            <!-- start form -->
							<form  action="<?php echo base_url('parentalportal/Transport/savetransportconductor'); ?>" method="POST" enctype="multipart/form-data">
                            <div class="form"> 								
                                <div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Name:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Name" id="name" name="name" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Date Of Joining:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="date" placeholder="Date Of Joining" id="dateofjoining" name="dateofjoining" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Mobile No:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="number" placeholder="Mobile No" id="mobileno" name="mobileno" class="form-control">
                                        </div>
                                    </div>
                                </div>	
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Qualification:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Qualification" id="qualification" name="qualification" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Present Address:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Present Address" id="presentaddress" name="presentaddress" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Permanent Address:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Permanent Address" id="permanentaddress" name="permanentaddress" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>