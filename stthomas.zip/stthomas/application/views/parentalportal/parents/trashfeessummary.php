<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Parents Management">Parents Management</a></li>
                    <li class="active"><a href="#" title="Fees Summary">Fees Summary</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <!-- start content-box -->
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Trash Fees Summary</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Trash Fees Summary</h3>-->
                            <!-- start table -->
				
						<div class="table-box">
						<div class="table-responsive">
                        <table class="table table-striped table-bordered table-checks media-table dataTable" id="example">
                            <thead>
                                <tr>
								    <th>S.No.</th>
									<th>Fee Type</th>		
                                    <th>Class</th>					
									<th>Tution Fee</th>
									<th>Mid day Meal Charge</th>
									<th>Other Charge</th>
									<th>Bus Charge</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
								<?php $y = 1;
									if(count($allfeessummary) > 0){
									foreach ($allfeessummary as $x) {  ?>
                                <tr class="odd">
								    <td><?php echo $y; ?></td>
									<td><?php echo $x['fee_type']; ?></td>	
									<td><?php echo $x['class']; ?></td>
									<td><?php echo $x['tution_fee']; ?></td>
									<td><?php echo $x['miday_charge']; ?></td>
									<td><?php echo $x['other_charge']; ?></td>
									<td><?php echo $x['bus_charge']; ?></td>
                                    <td>
                                        <ul>
                                            <li><a href="<?php echo base_url().'parentalportal/Parents/reactivefeessummary/'.$x['feessummary_id']; ?>" class="btn btn-danger btn-sm" title="Reactive">Reactive</a></li>
                                        </ul>
                                    </td>
                                </tr>
								<?php $y++;} } else{ ?>
									<tr><td colspan="12" align="center">No Data Available</td></tr>
									<?php } ?>
                                </tbody>
                        </table>
                    </div>
                </div>
                <!-- end table -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>