<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Parents Management">Parents Management</a></li>
                    <li class="active"><a href="#" title="Fees Summary">Fees Summary </a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <!-- start content-box -->
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Edit Fees Summary</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Edit Fees Summary</h3>-->
                            <!-- start form -->
							<form  action="<?php print base_url('parentalportal/Parents/updatefeessummary'); ?>" method="POST" enctype="multipart/form-data">
                            <div class="form">
								 <div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Fee Type:</label>
                                        </div>
                                        <div class="col-md-9">
										    <select name="fee_type" id="fee_type" class="form-control">
											<option value="null">--Select Type--</option>
											<option value="Montly"<?php if ($feessummary['fee_type'] == 'Montly') echo ' selected="selected"'; ?>>Montly</option>
											<option value="Quaterly"<?php if ($feessummary['fee_type'] == 'Quaterly') echo ' selected="selected"'; ?>>Quaterly</option>
											</select> 
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Class:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Class" id="class" name="class" value="<?php echo $feessummary['class']; ?>" class="form-control"><input type="hidden" name="feessummary_id" value="<?php echo $feessummary['feessummary_id']; ?>">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Tution Fee:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Tution Fee" id="tution_fee" name="tution_fee" value="<?php echo $feessummary['tution_fee']; ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Mid day Meal Charge:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Mid day Meal Charge" id="miday_charge" name="miday_charge" value="<?php echo $feessummary['miday_charge']; ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Other Charge:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Other Charge" id="other_charge" name="other_charge" value="<?php echo $feessummary['other_charge']; ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Bus Charge:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Bus Charge" id="bus_charge" name="bus_charge" value="<?php echo $feessummary['bus_charge']; ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>