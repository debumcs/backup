<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Parent Management">Parent Management</a></li>
                    <li class="active"><a href="#" title="Parent Registration">Parent Registration</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Add Parent Registration</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Add Parent Registration</h3>-->
                            <!-- start form -->
							<form  action="<?php echo base_url('parentalportal/Registration/saveparentregistration'); ?>" method="POST" enctype="multipart/form-data">
                            <div class="form"> 
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Type:</label>
                                        </div>
                                        <div class="col-md-9">
											<select name="type" id="type" class="form-control">
											<option value="null">--Select Type--</option>
											<option value="parent">Parent</option>
											<option value="student">Student</option>
											<option value="teacher">Teacher</option>
											</select>
                                        </div>
                                    </div>
                                </div>
                                <div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Student Name:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Student Name" id="student_name" name="student_name" class="form-control">
											<input type="hidden" name="random" value="Parent<?php echo rand(1000, 9999); ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Current Class:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Current Class" id="current_class" name="current_class" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Admission Year:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Admission Year" id="admission_year" name="admission_year" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Admission Class:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Admission Class" id="admission_class" name="admission_class" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Parent Name:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Parent Name" id="parent_name" name="parent_name" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Mother Name:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Mother Name" id="mother_name" name="mother_name" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Email:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Email" id="email" name="email" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Phone:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="number" placeholder="Phone" id="phone" name="phone" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Password:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Password" id="password" name="password" class="form-control">
                                        </div>
                                    </div>
                                </div>						
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>