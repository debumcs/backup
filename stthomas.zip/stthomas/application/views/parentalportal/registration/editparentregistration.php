<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Parent Management">Parent Management</a></li>
                    <li class="active"><a href="#" title="Parent Registration">Parent Registration</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <!-- start content-box -->
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Edit Parent Registration</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Edit Parent Registration</h3>-->
                            <!-- start form -->
							<form  action="<?php print base_url('parentalportal/Registration/updateparentregistration'); ?>" method="POST" enctype="multipart/form-data">
                            <div class="form">                                
                                <div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Type:</label>
                                        </div>
                                        <div class="col-md-9">
										    <select name="type" id="type" class="form-control">
											<option value="null">--Select Type--</option>
											<option value="parent"<?php if ($parentregistration['type'] == 'parent') echo ' selected="selected"'; ?>>Parent</option>
											<option value="student"<?php if ($parentregistration['type'] == 'student') echo ' selected="selected"'; ?>>Student</option>
											<option value="teacher"<?php if ($parentregistration['type'] == 'teacher') echo ' selected="selected"'; ?>>Teacher</option>
											</select>                                   
											 <input type="hidden" name="username" value="<?php echo $parentregistration['username']; ?>">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Username:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Username" id="username" name="username" value="<?php echo $parentregistration['username']; ?>" class="form-control">							
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Student Name:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Student Name" id="student_name" name="student_name" value="<?php echo $parentregistration['student_name']; ?>" class="form-control">
											<?php /* ?><input type="hidden" name="random" value="Parent<?php echo rand(1000, 9999); ?>" class="form-control"><?php */ ?>
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Current Class:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Current Class" id="current_class" name="current_class" value="<?php echo $parentregistration['current_class']; ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Admission Year:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Admission Year" id="admission_year" name="admission_year" value="<?php echo $parentregistration['admission_year']; ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Admission Class:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Admission Class" id="admission_class" name="admission_class" value="<?php echo $parentregistration['admission_class']; ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Parent Name:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Parent Name" id="parent_name" name="parent_name" value="<?php echo $parentregistration['parent_name']; ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Mother Name:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Mother Name" id="mother_name" name="mother_name" value="<?php echo $parentregistration['mother_name']; ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Email:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Email" id="email" name="email" value="<?php echo $parentregistration['email']; ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Phone:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="number" placeholder="Phone" id="phone" name="phone" value="<?php echo $parentregistration['phone']; ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Password:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Password" id="password" name="password" value="<?php echo $parentregistration['password']; ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>