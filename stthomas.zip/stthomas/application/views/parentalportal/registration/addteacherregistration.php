<?php 
$this->load->view('admin/header');
$this->load->view('admin/leftmenu');
?>
    <!-- start rightcol -->
    <div class="rightcol">
        <div class="rightcol-in">
		<div class="crumbs">
                <ul class="breadcrumbs"> 
                    <li><a href="<?php echo base_url('Admin'); ?>" title="Dashboard">Dashboard</a></li>
                    <li><a href="#" title="Teacher Management">Teacher Management</a></li>
                    <li class="active"><a href="#" title="Teacher Registration">Teacher Registration</a></li>
                </ul>
            <?php $this->load->view('admin/header_right'); ?>
            <div class="content-box">
                <!-- start heading1 -->
                <div class="heading1">
                    <h3><i class="fa fa-th" aria-hidden="true"></i> Add Teacher Registration</h3>
                </div>
                <!-- end heading1 -->
                <div class="row">
                    <div class="col-md-12">
					    <?php if($this->session->flashdata('MESSAGE')) { ?>
						<div class="alert alert-success" role="alert"><?php echo $this->session->flashdata('MESSAGE');?></div>
						<?php }?>
						
                        <!-- start widget-box -->
                        <div class="widget-box">
                            <!--<h3>Add Teacher Registration</h3>-->
                            <!-- start form -->
							<form  action="<?php echo base_url('parentalportal/Registration/saveteacherregistration'); ?>" method="POST" enctype="multipart/form-data">
                            <div class="form"> 
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Type:</label>
                                        </div>
                                        <div class="col-md-9">
											<select name="type" id="type" class="form-control">
											<option value="null">--Select Type--</option>
											<option value="parent">Parent</option>
											<option value="student">Student</option>
											<option value="teacher">Teacher</option>
											</select>
                                        </div>
                                    </div>
                                </div>
                                <div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Teacher Name:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Teacher Name" id="teacher_name" name="teacher_name" class="form-control">
											<input type="hidden" name="random" value="teacher<?php echo rand(1000, 9999); ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Father Name:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Father Name" id="father_name" name="father_name" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Join Year:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Join Year" id="join_year" name="join_year" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Qualification:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Qualification" id="qualification" name="qualification" class="form-control">
                                        </div>
                                    </div>
                                </div>
								
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Email:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Email" id="email" name="email" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Phone:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="number" placeholder="Phone" id="phone" name="phone" class="form-control">
                                        </div>
                                    </div>
                                </div>
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <label>Password:</label>
                                        </div>
                                        <div class="col-md-9">
                                            <input type="text" placeholder="Password" id="password" name="password" class="form-control">
                                        </div>
                                    </div>
                                </div>														
								<div class="control-group">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <button class="btn btn-primary btn-sm" type="submit" name="addSave" id="addSave">SAVE</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </div>
							</form>
                            <!-- end form -->
                        </div>
                        <!-- end widget-box -->
                    </div>
                </div>
            </div>
            <!-- end content-box -->
        </div>
    </div>
    <!-- end rightcol -->
<?php $this->load->view('admin/footer'); ?>