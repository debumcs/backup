<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
error_reporting(E_ALL); 
ini_set('display_errors', 1);
// include database and object files
include_once '../database.php';
include_once 'class/class.closeCases.php';
 
// instantiate database and product object
$database = new Database();
$db = $database->getConnection();
 
// initialize object
$case = new closeCases($db);

$data = json_decode(file_get_contents("php://input"));

/*echo '<pre>';
print_r($data);
echo '</pre>';
exit;*/
if($data->task == "allCloseCases"){

	$stmt 	= $case->getAllCloseCases($data);
	$num 	= $case->allCloseCasesTotalRecord($data);
	
	if($num>0){
		$cases_arr				= array();
		$cases_arr["records"]	= array();
		$cases_arr["numofrec"]	= $num;
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			array_push($cases_arr["records"], $row);
		}
		echo json_encode($cases_arr);
	}else{
		$cases_arr["numofrec"]	= 0;
		$cases_arr["records"]=array('No records found.');
		echo json_encode($cases_arr);
	}
	exit;
}else if($data->task == "submitCloseCases"){	
	$stmt 	= $case->getAllCloseCases($data);
	$num 	= $case->allCloseCasesTotalRecord($data);
	
	if($num>0){
		$cases_arr				= array();
		$cases_arr["records"]	= array();
		$cases_arr["numofrec"]	= $num;
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			array_push($cases_arr["records"], $row);
		}	 
		echo json_encode($cases_arr);
	}else{
		$cases_arr["numofrec"]	= 0;
		$cases_arr["records"]=array('No records found.');
		echo json_encode($cases_arr);
	}
	exit;
}else{
	echo json_encode(array("No record found."));
	exit;
}
?>