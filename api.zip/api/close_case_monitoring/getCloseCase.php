<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
// include database and object files
include_once '../database.php';
include_once 'class/class.closeCases.php';
 
// instantiate database and product object
$database = new Database();
$db = $database->getConnection();
$case = new closeCases($db);

$data = json_decode(file_get_contents("php://input"));

if($data->task == "submitRCCases"){	
	
	$stmt = $case->getAllRemarkClosedCases($data);
	$num  = $case->getAllRemarkClosedCasesTotalRecord($data);
	
	if($num>0){
		$cases_arr				= array();
		$cases_arr["records"]	= array();
		$cases_arr["numofrec"]	= $num;
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			array_push($cases_arr["records"], $row);
		}	 
		echo json_encode($cases_arr);
	}else{
		$cases_arr["records"]=array('No records found.');
		echo json_encode($cases_arr);
	}
	exit;
}else if($data->task == "allRemarkCloseCases"){
	
	$stmt = $case->getAllRemarkClosedCases($data);
	$num  = $case->getAllRemarkClosedCasesTotalRecord($data);

	if($num>0){
		$cases_arr				= array();
		$cases_arr["records"]	= array();
		$cases_arr["numofrec"]	= $num;
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			array_push($cases_arr["records"], $row);
		}	 
		echo json_encode($cases_arr);
	}else{
		$cases_arr["numofrec"]	= 0;
		$cases_arr["records"]	= array('No records found.');
		echo json_encode($cases_arr);
	}
	exit;
}else if($data->task == "caseNoteHistory"){
	
	$stmt = $case->getCaseNoteHistory($data);
	$num = $stmt->rowCount();

	if($num>0){
		$cases_arr				= array();
		$cases_arr["records"]	= array();
		$cases_arr["cid"]		= $data->id;
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			array_push($cases_arr["records"], $row);
		}	 
		echo json_encode($cases_arr);
	}else{
		$cases_arr["records"]=array('No records found.');
		echo json_encode($cases_arr);
	}
	exit;
}else if($data->task == "addRemark"){
	$msg = array();
	
	$success = $case->addRemark($data);
	
	if($success){
		$msg = array("errorFlag"=>"true","message"=>"Remark Added Successfully.");
	}else{
		$msg = array("errorFlag"=>"false","message"=>"Error while adding remark.");
	}
	
	echo json_encode($msg);
	exit;
}else if($data->task == "allCaseHistory"){
	$cases_arr = array();
	$cases_arr["records"]	= array();
	$cases_arr["caseid"]	= $data->caseid;
	
	$stmt = $case->getCaseIDHistory($data->caseid);
	$num = $stmt->rowCount();
	while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        array_push($cases_arr["records"], $row);
    } 
    echo json_encode($cases_arr);
	exit;
}else{
	echo json_encode(array("No record found."));
	exit;
}
?>