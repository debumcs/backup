<?php

class closeCases{
 
    // database connection and table name
    private $conn;
 
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
	
	// read All Close Cases
	public function getAllRemarkClosedCases($data){
		
		$itemsPerPage 		= $data->itemsPerPage;
		$from_record_num 	= ($data->pageno - 1)*$itemsPerPage;
		
		$firstinput	= $secondinput = $caseid = '';
		
		if(isset($data->caseid)){
			$caseid 		= $data->caseid;
		}
		
		if(isset($data->firstinput)){
			$firstinput		= date('Y-m-d 00:00:00',strtotime($data->firstinput));
		}
		
		if(isset($data->secondinput)){
			$secondinput	= date('Y-m-d 23:59:59',strtotime($data->secondinput));
		}
		
		// select all query
		$query = "select caseid, casetitle, remark, correct_closer, checkedby,createddate from close_case_monitoring where (createddate > '2018-07-01 00:00:00') ";
		
		if($caseid!=''){
			$query .= " and caseid = :caseid ";
		}
		
		if($firstinput!='' && $secondinput!=''){
			$query .= " and (createddate between :firstinput and :secondinput) ";
		}
		
		$query .= " order by createddate desc limit :from_record_num, :itemsPerPage";
		//echo $query; die();
		// prepare query statement
		$stmt = $this->conn->prepare($query);
		
		// bind values
		
		if($caseid!=''){
			$stmt->bindParam(":caseid", $caseid, PDO::PARAM_STR);
		}
		
		if($firstinput!='' && $secondinput!=''){
			$stmt->bindParam(":firstinput", $firstinput, PDO::PARAM_STR);
			$stmt->bindParam(":secondinput", $secondinput, PDO::PARAM_STR);
		}
		$stmt->bindParam(":from_record_num", $from_record_num, PDO::PARAM_INT);
		$stmt->bindParam(":itemsPerPage", $itemsPerPage, PDO::PARAM_INT);
		
		// execute query
		$stmt->execute();
		//$stmt->debugDumpParams();
		return $stmt;
	}
	
	// read All Remark Closed Cases Total Record
	public function getAllRemarkClosedCasesTotalRecord($data){
		// select all query
		$firstinput	= $secondinput = $caseid ='';
		
		if(isset($data->caseid)){
			$caseid 	= $data->caseid;
		}
		
		if(isset($data->firstinput)){
			$firstinput			= date('Y-m-d 00:00:00',strtotime($data->firstinput));
		}
		
		if(isset($data->secondinput)){
			$secondinput		= date('Y-m-d 23:59:59',strtotime($data->secondinput));
		}
		
		$query = "select  count(*) as total from case_info ci inner join close_case_monitoring ccm on ci.caseid = ccm.caseid where (ccm.createddate > '2018-07-01 00:00:00') ";
		
		if($caseid!=''){
			$query .= " and ccm.caseid = :caseid ";
		}
		
		if($firstinput!='' && $secondinput!=''){
			$query .= " and (ccm.createddate between :firstinput and :secondinput )";
		}
		
		// prepare query statement
		$stmt = $this->conn->prepare($query);
		
		// bind values
		
		if($caseid!=''){
			$stmt->bindParam(":caseid", $caseid, PDO::PARAM_STR);
		}
		
		if($firstinput!='' && $secondinput!=''){
			$stmt->bindParam(":firstinput", $firstinput, PDO::PARAM_STR);
			$stmt->bindParam(":secondinput", $secondinput, PDO::PARAM_STR);
		}
				
		// execute query
		$stmt->execute();
		$row = $stmt->fetch(PDO::FETCH_ASSOC);		
		return $row['total'];
	}
	
	// read All Close Cases
	public function getAllCloseCases($data){
		$itemsPerPage 		= $data->itemsPerPage;
		$from_record_num 	= ($data->pageno - 1) * $itemsPerPage;
		
		$firstinput	= $secondinput = $caseid ='';
		
		if(isset($data->caseid)){
			$caseid 	= $data->caseid;
		}
		
		if(isset($data->firstinput)){
			$firstinput			= date('Y-m-d 00:00:00',strtotime($data->firstinput));
		}
		
		if(isset($data->secondinput)){
			$secondinput		= date('Y-m-d 23:59:59',strtotime($data->secondinput));
		}
		
		// select all query
		
		$query = "select id, caseid, transid, casetitle, case_status, lastmodifyby, lastmodifyon from case_info where (lastmodifyon > '2018-07-01 00:00:00') and case_status = 'Close' ";
		
		if($caseid!=''){
			$query .= " and caseid = :caseid ";
		}
		
		if($firstinput!='' && $secondinput!=''){
			$query .= " and lastmodifyon between :firstinput and :secondinput ";
		}
		
		$query .= " and caseid not in (select caseid from close_case_monitoring) order by lastmodifyon desc limit :from_record_num, :itemsPerPage ";
		
		// prepare query statement
		$stmt = $this->conn->prepare($query);
		
		// bind values
		
		if($caseid!=''){
			$stmt->bindParam(":caseid", $caseid, PDO::PARAM_STR);
		}
		
		if($firstinput!='' && $secondinput!=''){
			$stmt->bindParam(":firstinput", $firstinput, PDO::PARAM_STR);
			$stmt->bindParam(":secondinput", $secondinput, PDO::PARAM_STR);
		}
		$stmt->bindParam(":from_record_num", $from_record_num, PDO::PARAM_INT);
		$stmt->bindParam(":itemsPerPage", $itemsPerPage, PDO::PARAM_INT);
		// execute query
		$stmt->execute();
	 
		return $stmt;
	}
	
	// get total number of records
	public function allCloseCasesTotalRecord($data){
		
		$firstinput	= $secondinput = $caseid ='';
		if(isset($data->caseid)){
			$caseid 	= $data->caseid;
		}
		
		if(isset($data->firstinput)){
			$firstinput			= date('Y-m-d 00:00:00',strtotime($data->firstinput));
		}
		
		if(isset($data->secondinput)){
			$secondinput			= date('Y-m-d 23:59:59',strtotime($data->secondinput));
		}
		
		// select all query
		$query = "select count(*) as total from case_info where (lastmodifyon > '2018-07-01 00:00:00') and case_status = 'Close' ";
		
		if($caseid!=''){
			$query .= " and caseid = :caseid ";
		}
		
		if($firstinput!='' && $secondinput!=''){
			$query .= " and lastmodifyon between :firstinput and :secondinput ";
		}
		
		$query .= " and caseid not in (select caseid from close_case_monitoring)";
		
		// prepare query statement
		$stmt = $this->conn->prepare($query);
		
		// bind values
		if($caseid!=''){
			$stmt->bindParam(":caseid", $caseid);
		}
		
		if($firstinput!='' && $secondinput!=''){
			$stmt->bindParam(":firstinput", $firstinput);
			$stmt->bindParam(":secondinput", $secondinput);
		}
		// execute query
		$stmt->execute();
		
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		
		return $row['total'];
	}
	
	// read get case information by id
	public function getCaseInfoById($data){
	 
		// select all query
		$query = "select id, casetitle, case_status from case_info where id=:id";
		
		// prepare query
		$stmt = $this->conn->prepare($query);
		
		// sanitize
		$id			= htmlspecialchars(strip_tags($data->cid));
		
		// bind values
		$stmt->bindParam(":id", $id);
		
		// execute query
		$stmt->execute();
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		return $row;
		
	}
	
	// read All Close Cases
	public function getCaseNoteHistory($data){
	 
		// select all query
		$query = "select distinct ci.caseid as caseno,replace(case_note,'<<','&lt;&lt;') as Summary,cs.action_date as createon,cs.username as createby,isdel from casenote_summary cs inner join case_info ci on ci.id=cs.caseid where ci.id=:id
		union all
		select distinct ci.caseid as caseno,replace(case_note,'<<','&lt;&lt;') as Summary,cs.action_date as createon,cs.username as createby,isdel from archive.casenote_summary cs inner join case_info ci on ci.id=cs.caseid where ci.id=:id order by createon desc";
	 
		// prepare query
		$stmt = $this->conn->prepare($query);
		
		// sanitize
		$id			= htmlspecialchars(strip_tags($data->id));
		
		// bind values
		$stmt->bindParam(":id", $id);
		
		// execute query
		$stmt->execute();
	 
		return $stmt;
	}
	
	// read Case ID History
	public function getCaseIDHistory($caseid){	 
		// select all query
		$query = "call spsCaseHistory(?)";
	 	// prepare query statement
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(1, $caseid, PDO::PARAM_STR|PDO::PARAM_INPUT_OUTPUT, 50);
		// call the stored procedure
		$stmt->execute();
		return $stmt;
	}
	
	// addRemark
	public function addRemark($data){
		// query to insert record

		$query = "insert into close_case_monitoring(case_sr_no, transid, caseid, casetitle, checkedby, remark, correct_closer, createddate, ipaddress) select id, transid, :caseid, casetitle, :checkedby, :remark, :correct_closer, now(),:ipaddress from case_info where caseid = :caseid";
		
		// prepare query
		$stmt = $this->conn->prepare($query);
		
		// sanitize
		//$uname = $_SESSION['ADMIN_NAME'];
		$ipaddress 		= $_SERVER['REMOTE_ADDR'];
		$checkedby		= $_SESSION['ADMIN_NAME'];
		$checkedby		= htmlspecialchars(strip_tags($checkedby));
		$remark			= htmlspecialchars(strip_tags($data->remark));
		$correct_closer = htmlspecialchars(strip_tags($data->correct_closer));
		$caseid			= htmlspecialchars(strip_tags($data->caseid));
		
		// bind values
		$stmt->bindParam(":checkedby", $checkedby);
		$stmt->bindParam(":remark", $remark);
		$stmt->bindParam(":correct_closer", $correct_closer);
		$stmt->bindParam(":caseid", $caseid);
		$stmt->bindParam(":ipaddress", $ipaddress);
	 
		// execute query
		if($stmt->execute()){
			return true;
		}	 
		return false;
	}
	
	// read products with pagination
	public function readPaging($from_record_num, $records_per_page){
	 
		// select query
		$query = "SELECT
					c.name as category_name, p.id, p.name, p.description, p.price, p.category_id, p.created
				FROM
					" . $this->table_name . " p
					LEFT JOIN
						categories c
							ON p.category_id = c.id
				ORDER BY p.created DESC
				LIMIT ?, ?";
	 
		// prepare query statement
		$stmt = $this->conn->prepare($query);
	 
		// bind variable values
		$stmt->bindParam(1, $from_record_num, PDO::PARAM_INT);
		$stmt->bindParam(2, $records_per_page, PDO::PARAM_INT);
	 
		// execute query
		$stmt->execute();
	 
		// return values from database
		return $stmt;
	}
	
	// used for paging products
	public function count(){
		$query = "SELECT COUNT(*) as total_rows FROM " . $this->table_name . "";
	 
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
	 
		return $row['total_rows'];
	}
	
	// read All Close Cases
	public function getAllCloseCases2($data){
		$itemsPerPage 		= $data->itemsPerPage;
		$from_record_num 	= ($data->pageno - 1) * $itemsPerPage;
		
		$firstinput	= $secondinput = $caseid ='';
		
		if(isset($data->caseid)){
			$caseid 	= $data->caseid;
		}
		
		if(isset($data->firstinput)){
			$firstinput			= date('Y-m-d 00:00:00',strtotime($data->firstinput));
		}
		
		if(isset($data->secondinput)){
			$secondinput		= date('Y-m-d 23:59:59',strtotime($data->secondinput));
		}
		
		// select all query
		
		$query = "select caseid, casetitle, remark, correct_closer, checkedby,createddate from close_case_monitoring where (createddate > '2018-07-01 00:00:00') ";
		
		if($caseid!=''){
			$query .= " and caseid = :caseid ";
		}
		
		if($firstinput!='' && $secondinput!=''){
			$query .= " and lastmodifyon between :firstinput and :secondinput ";
		}
		
		$query .= " and caseid not in (select caseid from close_case_monitoring) order by lastmodifyon desc limit :from_record_num, :itemsPerPage ";
		
		// prepare query statement
		$stmt = $this->conn->prepare($query);
		
		// bind values
		
		if($caseid!=''){
			$stmt->bindParam(":caseid", $caseid, PDO::PARAM_STR);
		}
		
		if($firstinput!='' && $secondinput!=''){
			$stmt->bindParam(":firstinput", $firstinput, PDO::PARAM_STR);
			$stmt->bindParam(":secondinput", $secondinput, PDO::PARAM_STR);
		}
		$stmt->bindParam(":from_record_num", $from_record_num, PDO::PARAM_INT);
		$stmt->bindParam(":itemsPerPage", $itemsPerPage, PDO::PARAM_INT);
		// execute query
		$stmt->execute();
	 
		return $stmt;
	}
	
	// get total number of records
	public function allCloseCasesTotalRecord2($data){
		
		$firstinput	= $secondinput = $caseid ='';
		if(isset($data->caseid)){
			$caseid 	= $data->caseid;
		}
		
		if(isset($data->firstinput)){
			$firstinput			= date('Y-m-d 00:00:00',strtotime($data->firstinput));
		}
		
		if(isset($data->secondinput)){
			$secondinput			= date('Y-m-d 23:59:59',strtotime($data->secondinput));
		}
		
		// select all query
		$query = "select count(*) as total from case_info where (lastmodifyon > '2018-07-01 00:00:00') and case_status = 'Close' ";
		
		if($caseid!=''){
			$query .= " and caseid = :caseid ";
		}
		
		if($firstinput!='' && $secondinput!=''){
			$query .= " and (createddate between :firstinput and :secondinput) ";
		}
		
		//$query .= " and caseid not in (select caseid from close_case_monitoring)";
		
		// prepare query statement
		$stmt = $this->conn->prepare($query);
		
		// bind values
		if($caseid!=''){
			$stmt->bindParam(":caseid", $caseid);
		}
		
		if($firstinput!='' && $secondinput!=''){
			$stmt->bindParam(":firstinput", $firstinput);
			$stmt->bindParam(":secondinput", $secondinput);
		}
		// execute query
		$stmt->execute();
		
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		
		return $row['total'];
	}
}