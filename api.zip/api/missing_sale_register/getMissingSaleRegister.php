<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
// include database and object files
include_once '../database.php';
include_once 'class/class.missingSaleRegister.php';
 
// instantiate database and product object
$database 	= new Database();
$db 		= $database->getConnection();
$msr 		= new MissingSaleRegister($db);

$data = json_decode(file_get_contents("php://input"));

if($data->task == "getAllPartner"){
	
	$msrs_arr				= array();
	$msrs_arr["records"]	= array(); 
	$stmt 	= $msr->getAllPartner();
	while($msrs_row = $stmt->fetch(PDO::FETCH_ASSOC)){
		array_push($msrs_arr["records"], $msrs_row);
	}
	echo json_encode($msrs_arr);	
	exit;
	
}else if($data->task == "getPlanCode"){
	
	$msrs_arr				= array();
	$msrs_arr["records"]	= array();
		
	$stmt 	= $msr->getAllPlanCode($data);
	while ($msrs_row = $stmt->fetch(PDO::FETCH_ASSOC)){
		array_push($msrs_arr["records"], $msrs_row);
	}
	echo json_encode($msrs_arr);	
	exit;	
}else if($data->task == "getPlanAmount"){ 
	$msrs_arr			= array();
	$msrs_arr["amount"]	= array(); 
	$row 				= $msr->getPlanAmount($data);
	$msrs_arr["amount"] = $row; 
	echo json_encode($msrs_arr);
	exit;
}else if($data->task == "checkOrderNumberExist"){
	
	$msrs_arr			= array();
	$msrs_arr["status"]	= array(); 
	$row 				= $msr->checkOrderNumberExist($data);
	$msrs_arr["status"] = $row; 
	echo json_encode($msrs_arr);	
	exit;	
}else if($data->task == "registerMissingSale"){
	$row = $msr->registerMissingSale($data);
	echo json_encode($row);
	exit;	
}else if($data->task == "viewSales"){
	$row = $msr->viewSales($data);
	echo json_encode($row);
	exit;	
}else{
	echo json_encode(array("No record found."));
	exit;
}
?>