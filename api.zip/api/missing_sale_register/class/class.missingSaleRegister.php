<?php

class MissingSaleRegister{

    // database connection and table name
    private $conn;
 
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
	
	public function viewSales($data){
		
		$query = "select plan_cost from vwProduct where productcode=:productcode";
		// prepare query statement 
		
		$stmt = $this->conn->prepare($query);
		
		$plancode = htmlspecialchars(strip_tags($data->plancode));
		// bind values
		$stmt->bindParam(":productcode",$plancode, PDO::PARAM_STR);
		
		// execute query
		$stmt->execute();
		
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		
		return $row['plan_cost'];
	}
		
	public function getAllPartner(){
				
		// select all query
		$query = "select name,ibcode from ibmaster where active='1' order by name asc";
		
		// prepare query statement
		$stmt = $this->conn->prepare($query);
		
		// execute query
		$stmt->execute();
		//$stmt->debugDumpParams();
		return $stmt;
	}
	
	public function getAllPlanCode($data){
				
		// select all query
		$query = "select productcode,productname from product P inner join product_info PI on PI.prod_id = P.srno where planaccount=:account";
		
		// prepare query statement
		$stmt = $this->conn->prepare($query);
		
		$account = htmlspecialchars(strip_tags($data->account));
		
		// bind values
		$stmt->bindParam(":account", $account, PDO::PARAM_INT);
		
		// execute query
		$stmt->execute();
		//$stmt->debugDumpParams();
		return $stmt;
	}
	
	public function getPlanAmount($data){
		
		$query = "select plan_cost from vwProduct where productcode=:productcode";
		// prepare query statement 
		
		$stmt = $this->conn->prepare($query);
		
		$plancode = htmlspecialchars(strip_tags($data->plancode));
		// bind values
		$stmt->bindParam(":productcode",$plancode, PDO::PARAM_STR);
		
		// execute query
		$stmt->execute();
		
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		
		return $row['plan_cost'];
	}
	
	public function checkOrderNumberExist($data){
		$query = "select count(*) as total from missingsale where orderno = :orderno";
		// prepare query statement 
		
		$stmt = $this->conn->prepare($query);
		
		$orderno = htmlspecialchars(strip_tags($data->orderid));
		// bind values
		$stmt->bindParam(":orderno",$orderno, PDO::PARAM_STR);
		
		// execute query
		$stmt->execute();
		
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		
		return $row['total'];
	}
	
	public function registerMissingSale($data){
		
		// sanitize
		$num = $this->checkOrderNumberExist($data);
		if($num<=0){
			$orderno		= htmlspecialchars(strip_tags($data->orderid));
			$email			= htmlspecialchars(strip_tags($data->email));
			$account		= htmlspecialchars(strip_tags($data->account));
			$productcode	= htmlspecialchars(strip_tags($data->plancode));
			$amount			= $this->getPlanAmount($data);
			$createdby		= $_SESSION['ADMIN_NAME'];
			$ipaddr			= $_SERVER['REMOTE_ADDR'];
			
			$query = "insert into missingsale(orderno,account,productcode,email,amount,createdby,createdon,ipaddr) values(:orderno,:account,:productcode,:email,:amount,:createdby,now(),:ipaddr)";
			
			$stmt = $this->conn->prepare($query);			
			
			// bind values
			$stmt->bindParam(":orderno", $orderno, PDO::PARAM_STR);
			$stmt->bindParam(":account", $account, PDO::PARAM_STR);
			$stmt->bindParam(":productcode", $productcode, PDO::PARAM_STR);
			$stmt->bindParam(":email", $email, PDO::PARAM_STR);
			$stmt->bindParam(":amount", $amount, PDO::PARAM_STR);
			$stmt->bindParam(":createdby", $createdby, PDO::PARAM_STR);
			$stmt->bindParam(":ipaddr", $ipaddr, PDO::PARAM_STR);
			
			// execute query
			if($stmt->execute()){
				$row['msg'] = "Sale successfully registered";
				$row['rstatus'] = "1";
				return $row;
			}else{
				$row['msg'] = "Error while executing query. ".implode(',',$stmt->errorInfo());
				$row['rstatus'] = "2";
				return $row;
			}
		}else{
			$row['msg'] = "Order number already exist";
			$row['rstatus'] = "3";
			return $row;
		}
	}
}