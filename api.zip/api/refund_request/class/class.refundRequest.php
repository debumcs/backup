<?php
class RefundRequest{

    // database connection and table name
    private $conn;
 
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
	
	// get total number of records
	public function getOrderInfo($data){
		
		$orderno = '';
		
		if(isset($data->orderno)){
			$orderno = $data->orderno;
		}
		
		$query = "select T.order_no, T.grandtot, T.order_date, S.soldby, tbl2.name, tbl3.sale_medium, 
		PO.descrip,P.productname, TC.contactid, TC.custEmailId, CR.refid, CR.ref_type 
		from transaction T
		left outer join sale_register S on T.order_no = S.orderno
		left join adminuser tbl2 on S.soldby = tbl2.username 
		left join sale_medium tbl3 on S.sale_medium = tbl3.id 
		inner join payoption PO on T.payoption=PO.code
		inner join product P on T.product_no=P.srno
		inner join totcustomer TC on T.cust_id=TC.srno
		inner join customer_ref CR on CR.contactid = TC.contactid
		where T.order_no=:orderno and T.status='SUCCESS'";
		
        if($_SESSION['CHECKPARTNERUSER'] == 'yes'){	
            $query .= " and instr(',:PARTNERUSERIBCODE,',CR.refid) ";
        }
		
		// prepare query statement 
		$stmt = $this->conn->prepare($query);
		
		// bind values
		$stmt->bindParam(":orderno",$orderno, PDO::PARAM_STR);
		
		if($_SESSION['CHECKPARTNERUSER'] == 'yes'){	
			$stmt->bindParam(":PARTNERUSERIBCODE", $_SESSION['PARTNERUSERIBCODE'], PDO::PARAM_STR);
		}
		
		// execute query
		$stmt->execute();
		
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		
		return $row;
	}
	
	
	
	
}