<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
// include database and object files
include_once '../database.php';
include_once 'class/class.refundRequest.php';
 
// instantiate database and product object
$database 	= new Database();
$db 		= $database->getConnection();
$rr 		= new RefundRequest($db);

$data = json_decode(file_get_contents("php://input"));

if($data->task == "getOrderInfo"){
	
	$row = $rr->getOrderInfo($data);
	
	$rrs_arr				= array();
	$rrs_arr["records"]		= array();
	$rrs_arr["saleMediums"]	= array();
		
	$stmt = $rr->getAllSaleMedium($row['refid']);
	
	while ($rrs_row = $stmt->fetch(PDO::FETCH_ASSOC)){
		array_push($rrs_arr["saleMediums"], $rrs_row);
	}
	
	$rrs_arr["username"] 	= $_SESSION['ADMIN_NAME'];
	if($row['order_no']!=''){
		if($row['soldby']!=""){
			$rrs_arr["orderStatus"]	= 0;
		}else{
			$rrs_arr["orderStatus"]	= 1;
		}
	}else{
		$rrs_arr["orderStatus"]	= 2;
	}
			
	$rrs_arr["records"] = $row;
	echo json_encode($rrs_arr);	
	exit;
	
}else if($data->task == "registerSale"){
	$row = $rr->registerSale($data);
	echo json_encode($row);
	exit;	
}else{
	echo json_encode(array("No record found."));
	exit;
}
?>