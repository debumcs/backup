<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
// include database and object files
include_once '../database.php';
include_once 'class/class.mailForCustomer.php';
 
// instantiate database and product object
$database 	= new Database();
$db 		= $database->getConnection();
$sendMail 	= new mailForCustomer($db);

$data = json_decode(file_get_contents("php://input"));

if($data->task == "getContactId"){ 
	$contactArr				= array(); 
	$row 	= $sendMail->getContactDetails($data);    
	if($row)
	{
		$customername = $row['customername'];
		$accountname  = $row['accountname'];
		$accountcode  = $row['accountcode'];
		$customerlname = $row['customerlname']; 
		$custEmailId = $row['custEmailId']; 
		$contactArr["flag"]  = "1";
		$contactArr["account_name"]  = $accountname;
		$contactArr["account_code"]  = $accountcode; 
		$contactArr["customer_name"]  = $customername;
		$contactArr["customer_lname"]  = $customerlname; 
		$contactArr["customer_email_id"]  = $custEmailId; 
		$contactArr["orderId"][] = array('trans_id'=>$row['Transid'],'orderno'=>$row['orderno']); 
		$getCases = $sendMail->getCaseId($row['Transid']);
	    //echo "<pre>";print_r($getCases);echo "</pre>";exit;
		$contactArr["cases"] = $getCases;
		
	}
	else  
	{ 
		$contactArr["flag"]  = "0";
		 
	}  
	echo json_encode($contactArr);
	exit;
	
}elseif($data->task == "getContactId"){
	
	$contactArr	= array(); 
	$row 	= $sendMail->getContactDetails($data);   
	
	if($row)
	{
		$customername = $row['customername'];
		$accountname  = $row['accountname'];
		$accountcode  = $row['accountcode'];
		$customerlname = $row['customerlname']; 
		$custEmailId = $row['custEmailId']; 
		$contactArr["flag"]  = "1";
		$contactArr["account_name"]  = $accountname;
		$contactArr["account_code"]  = $accountcode; 
		$contactArr["customer_name"]  = $customername;
		$contactArr["customer_lname"]  = $customerlname; 
		$contactArr["customer_email_id"]  = $custEmailId; 
		$contactArr["orderId"][] = array('trans_id'=>$row['Transid'],'orderno'=>$row['orderno']); 
		$getCases = $sendMail->getCaseId($row['Transid']);
		echo "<pre>";print_r($getCases);echo "</pre>";exit;
		$contactArr["cases"] = $getCases; 
	}
	else
	{ 
		$contactArr["flag"]  = "0";
		 
	}  
	echo json_encode($contactArr);
	exit;
	
}
else{
	
}
?>