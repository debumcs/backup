<?php

class mailForCustomer{

    // database connection and table name
    private $conn;
 
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
	
	// get total number of records
    public function getContactDetails($data){
		// select all query
		$query = "select accountcode, accountname, 
		(case when custName is null or custName='' then customer_name else  custName end) as customername,
	        custlName as customerlname ,c.custEmailId,t.Transid,t.orderno from totcustomer c
	        inner join transactiondetails t on c.contactid = t.contactid where c.contactid=:contactid";
	 
		// prepare query statement
		$stmt = $this->conn->prepare($query); 
		$contactid = htmlspecialchars(strip_tags($data->contactid));  
		// bind values
		$stmt->bindParam(":contactid", $contactid, PDO::PARAM_INT); 
		// execute query
		$stmt->execute();
		
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		
		return $row;
		
	}
	
	// get total number of records
    public function getCaseId($transid){
 		// select all query
		$query = "select caseid from case_info where transid = '$transid' and firstflag='1'"; 
		 
		// prepare query statement
		$stmt = $this->conn->prepare($query); 
		$transid = htmlspecialchars(strip_tags($transid));   
		// bind values
		$stmt->bindParam(":transid", $transid); 
		// execute query
		$stmt->execute();
		
		$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
		 
		return $row; 
	}
}