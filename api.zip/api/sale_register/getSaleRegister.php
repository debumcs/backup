<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
// include database and object files
include_once '../database.php';
include_once 'class/class.saleRegister.php';
 
// instantiate database and product object
$database 	= new Database();
$db 		= $database->getConnection();
$sale 	= new saleRegister($db);

$data = json_decode(file_get_contents("php://input"));

if($data->task == "getOrderInfo"){
	
	$row 	= $sale->getOrderInfo($data);
	
	$sales_arr				= array();
	$sales_arr["records"]	= array();
	$sales_arr["saleMediums"]	= array();
		
	$stmt 	= $sale->getAllSaleMedium($row['refid']);
	while ($sales_row = $stmt->fetch(PDO::FETCH_ASSOC)){
		array_push($sales_arr["saleMediums"], $sales_row);
	}
	
	$sales_arr["username"] 	= $_SESSION['ADMIN_NAME'];
	if($row['order_no']!=''){
		if($row['soldby']!=""){
			$sales_arr["orderStatus"]	= 0;
		}else{
			$sales_arr["orderStatus"]	= 1;
		}
	}else{
		$sales_arr["orderStatus"]	= 2;
	}
			
	$sales_arr["records"] = $row;
	echo json_encode($sales_arr);	
	exit;
	
}else if($data->task == "registerSale"){
	$row = $sale->registerSale($data);
	echo json_encode($row);
	exit;	
}else{
	echo json_encode(array("No record found."));
	exit;
}
?>