<?php

class saleRegister{

    // database connection and table name
    private $conn;
 
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
	
	// get total number of records
	public function getOrderInfo($data){
		
		$orderno = '';
		
		if(isset($data->orderno)){
			$orderno		= $data->orderno;
		}
		
		$query = "select T.order_no, T.grandtot, T.order_date, S.soldby, tbl2.name, tbl3.sale_medium, 
		PO.descrip,P.productname, TC.contactid, TC.custEmailId, CR.refid, CR.ref_type 
		from transaction T
		left outer join sale_register S on T.order_no = S.orderno
		left join adminuser tbl2 on S.soldby = tbl2.username 
		left join sale_medium tbl3 on S.sale_medium = tbl3.id 
		inner join payoption PO on T.payoption=PO.code
		inner join product P on T.product_no=P.srno
		inner join totcustomer TC on T.cust_id=TC.srno
		inner join customer_ref CR on CR.contactid = TC.contactid
		where T.order_no=:orderno and T.status='SUCCESS'";
		
        if($_SESSION['CHECKPARTNERUSER'] == 'yes'){	
            $query .= " and instr(',:PARTNERUSERIBCODE,',CR.refid) ";
        }
		
		// prepare query statement 
		$stmt = $this->conn->prepare($query);
		
		// bind values
		$stmt->bindParam(":orderno",$orderno, PDO::PARAM_STR);
		
		if($_SESSION['CHECKPARTNERUSER'] == 'yes'){	
			$stmt->bindParam(":PARTNERUSERIBCODE", $_SESSION['PARTNERUSERIBCODE'], PDO::PARAM_STR);
		}
		
		// execute query
		$stmt->execute();
		
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		
		return $row;
	}
	
	public function getAllSaleMedium($refid){
				
		// select all query
		$query = "select id,sale_medium from sale_medium where accountid=:refid and status='1' order by sale_medium";
		
		// prepare query statement
		$stmt = $this->conn->prepare($query);
		
		// bind values

		$stmt->bindParam(":refid", $refid, PDO::PARAM_INT);
		
		// execute query
		$stmt->execute();
		//$stmt->debugDumpParams();
		return $stmt;
	}
	
	public function getTimeDiff($orderNumber){
		
		$query = "select TIMESTAMPDIFF(SECOND,IFNULL(OS.action_date,T.order_date),now()) as timediff from transaction T left outer join order_status OS on T.order_no=OS.orderno where T.order_no=:orderNumber";
		// prepare query statement 
		
		$stmt = $this->conn->prepare($query);
		
		// bind values
		$stmt->bindParam(":orderNumber",$orderNumber, PDO::PARAM_STR);
		
		// execute query
		$stmt->execute();
		
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		
		return $row['timediff'];
	}
	
	public function registerSale($data){
		
		$loctimediff = $this->getTimeDiff($data->orderno);
		
		if($loctimediff>259200)
		{
			$row['msg'] = "Alert : Sale can be register within 72 Hours.Please contact to your Manager/TL.";
			$row['rstatus'] = "1";
			return $row;
		}else{
			$checkquery = "Select count(*) as total from sale_register where orderno=:orderno";
			$checkstmt = $this->conn->prepare($checkquery);
		
			// bind values
			$checkstmt->bindParam(":orderno",$data->orderno, PDO::PARAM_STR);
			
			// execute query
			$checkstmt->execute();
			
			$num = $checkstmt->fetch(PDO::FETCH_ASSOC);
		
		
			if($num['total'] > 0){
				$query = "update sale_register set soldby=:agentid, sale_medium=:sale_medium, action_date = now(), ipaddr=:ipaddr where orderno = :orderno";
				// prepare query
				$stmt = $this->conn->prepare($query);
				
				// sanitize
				$orderno		= htmlspecialchars(strip_tags($data->orderno));
				$agentid		= htmlspecialchars(strip_tags($data->agentid));
				$sale_medium	= htmlspecialchars(strip_tags($data->sale_medium));
				$ipaddr			= $_SERVER['REMOTE_ADDR'];
				// bind values
				$stmt->bindParam(":agentid", $agentid, PDO::PARAM_STR);
				$stmt->bindParam(":sale_medium", $sale_medium, PDO::PARAM_STR);
				$stmt->bindParam(":ipaddr", $ipaddr, PDO::PARAM_STR);
				$stmt->bindParam(":orderno", $orderno, PDO::PARAM_STR);
				
				// execute query
				if($stmt->execute()){
					$row['msg'] = "Sale successfully registered to $agentid...";
					$row['rstatus'] = "2";
					return $row;
				}else{
					$row['msg'] = "Error while executing query. ".implode(',',$stmt->errorInfo());
					$row['rstatus'] = "3";
					return $row;
				}
				
			}else{
				
				$query = "insert into sale_register(orderno, soldby, sale_medium, action_date, ipaddr) values(:orderno,  :agentid, :sale_medium, now(), :ipaddr)";
				
				$stmt = $this->conn->prepare($query);			
				// sanitize
				$orderno			= htmlspecialchars(strip_tags($data->orderno));
				$agentid			= htmlspecialchars(strip_tags($data->agentid));
				$sale_medium		= htmlspecialchars(strip_tags($data->sale_medium));
				$ipaddr				= $_SERVER['REMOTE_ADDR'];
				// bind values
				$stmt->bindParam(":agentid", $agentid, PDO::PARAM_STR);
				$stmt->bindParam(":sale_medium", $sale_medium, PDO::PARAM_STR);
				$stmt->bindParam(":ipaddr", $ipaddr, PDO::PARAM_STR);
				$stmt->bindParam(":orderno", $orderno, PDO::PARAM_STR);
				
				// execute query
				if($stmt->execute()){
					$row['msg'] = "Sale successfully registered to $agentid...";
					$row['rstatus'] = "2";
					return $row;
				}else{
					$row['msg'] = "Error while executing query. ".implode(',',$stmt->errorInfo());
					$row['rstatus'] = "3";
					return $row;
				}
			}
			
		}
		
	}	
}