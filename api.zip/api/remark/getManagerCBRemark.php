<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
// include database and object files
include_once '../database.php';
include_once 'class/class.managerCBRemark.php';
 
// instantiate database and product object
$database = new Database();
$db = $database->getConnection();
$remark = new agentRemark($db);

$data = json_decode(file_get_contents("php://input"));
/*echo '<pre>';
print_r($data);
echo '<pre>';
exit;*/
if(($data->task == "filterAgentRefundRemark") ||($data->task == "allAgentRemark")){
	
	$stmt = $remark->allAgentRemark($data);
	$num  = $remark->allAgentRemarkTotalRecord($data);
	
	if($num>0){
		$remarks_arr				= array();
		$remarks_arr["records"]		= array();
		$remarks_arr["numofrec"]	= $num;
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			array_push($remarks_arr["records"], $row);
		}	 
		echo json_encode($remarks_arr);
	}else{
		$remarks_arr["records"]		= array('No records found.');
		$remarks_arr["numofrec"]	= 0;
		echo json_encode($remarks_arr);
	}
	exit;
}else if($data->task == "getAgentRemark"){
	
	$row = $remark->getAgentRemarkById($data);
	echo json_encode($row);
	exit;
	
}else if($data->task == "agentRemarkInsertUpdate"){
	
	$row = $remark->agentRemarkInsertUpdate($data);
	echo json_encode($row);
	exit;
	
}else{
	echo json_encode(array("No record found."));
	exit;
}
?>