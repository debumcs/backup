<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
// include database and object files
include_once '../database.php';
include_once 'class/class.managerRefundRemark.php';
 
// instantiate database and product object
$database = new Database();
$db = $database->getConnection();
$remark = new managerRefundRemark($db);

$data = json_decode(file_get_contents("php://input"));
/*echo '<pre>';
print_r($data);
echo '<pre>';
exit;*/
if(($data->task == "filterManagerRefundRemark") ||($data->task == "allManagerRefundRemark")){
	
	$stmt = $remark->allManagerRefundRemark($data);
	$num  = $remark->allManagerRefundRemarkTotalRecord($data);
	
	if($num>0){
		$remarks_arr				= array();
		$remarks_arr["records"]		= array();
		$remarks_arr["numofrec"]	= $num;
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			array_push($remarks_arr["records"], $row);
		}	 
		echo json_encode($remarks_arr);
	}else{
		$remarks_arr["records"]		= array('No records found.');
		$remarks_arr["numofrec"]	= 0;
		echo json_encode($remarks_arr);
	}
	exit;
}else if($data->task == "getManagerRefundRemark"){
	
	$row = $remark->getManagerRefundRemarkById($data);
	echo json_encode($row);
	exit;
	
}else if($data->task == "managerRefundRemarkInsertUpdate"){
	
	$row = $remark->managerRefundRemarkInsertUpdate($data);
	echo json_encode($row);
	exit;
	
}else{
	echo json_encode(array("No record found."));
	exit;
}
?>