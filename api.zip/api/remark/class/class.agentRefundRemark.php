<?php

class agentRefundRemark{

    // database connection and table name
    private $conn;
 
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
	
	// read all Agent Refund Remark
	public function allAgentRemark($data){
		$itemsPerPage 		= $data->itemsPerPage;
		$from_record_num 	= ($data->pageno - 1) * $itemsPerPage;
		
		$remark	= $remFlag = '';
		
		if(isset($data->remark)){
			$remark 		= $data->remark;
		}
		
		if(isset($data->remFlag)){
			$remFlag		= $data->remFlag;
		}
		
		// select all query
		
		$query 	= "select * from refund_remarks "; 
			
		$query	.= " where remark != '' ";
	
		if($remark!='')
			$query	.= " and remark like :remark ";
		
		if($remFlag!='')
			$query	.= " and remFlag like :remFlag ";
		
		$query	.= " ORDER BY id DESC limit :from_record_num, :itemsPerPage";
		
		// prepare query statement
		$stmt = $this->conn->prepare($query);
		
		// bind values
		
		if($remark!=''){
			$remark = "%$remark%";
			$stmt->bindParam(":remark", $remark, PDO::PARAM_STR);
		}
		
		if($remFlag!=''){
			$stmt->bindParam(":remFlag", $remFlag, PDO::PARAM_STR);
		}
		$stmt->bindParam(":from_record_num", $from_record_num, PDO::PARAM_INT);
		$stmt->bindParam(":itemsPerPage", $itemsPerPage, PDO::PARAM_INT);
		// execute query
		$stmt->execute();
	 
		return $stmt;
	}
	
	// get total number of records
	public function allAgentRemarkTotalRecord($data){
		
		$remark	= $remFlag = '';
		
		if(isset($data->remark)){
			$remark 		= $data->remark;
		}
		
		if(isset($data->remFlag)){
			$remFlag		= $data->remFlag;
		}
		
		// select all query
		
		$query 	= "select count(*) as total from refund_remarks "; 
			
		$query	.= " where remark != '' ";
	
		if($remark!='')
			$query	.= " and remark like :remark ";
		
		if($remFlag!='')
			$query	.= " and remFlag like :remFlag ";
		
		// prepare query statement
		$stmt = $this->conn->prepare($query);
		
		// bind values
		
		if($remark!=''){
			$remark = "%$remark%";
			$stmt->bindParam(":remark",$remark, PDO::PARAM_STR);
		}
		
		if($remFlag!=''){
			$stmt->bindParam(":remFlag", $remFlag, PDO::PARAM_STR);
		}
		
		// execute query
		$stmt->execute();
		
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		
		return $row['total'];
	}
	
	// read get case information by id
	public function getAgentRemarkById($data){
	 
		// select all query
		$query = "Select * from refund_remarks where id=:id";
		
		// prepare query
		$stmt = $this->conn->prepare($query);
		
		// sanitize
		$id			= htmlspecialchars(strip_tags($data->id));
		
		// bind values
		$stmt->bindParam(":id", $id);
		
		// execute query
		$stmt->execute();
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		return $row;
	}
	
	public function agentRemarkInsertUpdate($data){
	 
		// select all query
		
		if($data->id > 0){
			$query = "update refund_remarks set remFlag=:remFlag, action_date=:modifieddatetime, uname=:username, ipaddr=:ipaddr where id=:id";
			// prepare query
			$stmt = $this->conn->prepare($query);
			
			// sanitize
			$id					= htmlspecialchars(strip_tags($data->id));
			$remFlag			= htmlspecialchars(strip_tags($data->remFlag));
			$modifieddatetime	= date('Y-m-d H:i:s');
			$username			= $_SESSION['ADMIN_NAME'];
			$ipaddr				= $_SERVER['REMOTE_ADDR'];
			// bind values
			$stmt->bindParam(":modifieddatetime", $modifieddatetime, PDO::PARAM_STR);
			$stmt->bindParam(":username", $username, PDO::PARAM_STR);
			$stmt->bindParam(":ipaddr", $ipaddr, PDO::PARAM_STR);
			$stmt->bindParam(":remFlag", $remFlag, PDO::PARAM_INT);
			$stmt->bindParam(":id", $id, PDO::PARAM_INT);
		}else{
			$check = $this->checkRemarkExist($data->remark);
			
			if($check>0){
				return array('rstatus'=>'0','message'=>'Remark already added to database.');
			}else{
				$query = "insert into refund_remarks(remark,action_date,uname,ipaddr) values(:remark, :action_date,:uname,:ipaddr)";
				
				$stmt = $this->conn->prepare($query);			
				// sanitize
				$remark			= htmlspecialchars(strip_tags($data->remark));
				$action_date	= date('Y-m-d H:i:s');
				$uname			= $_SESSION['ADMIN_NAME'];
				$ipaddr			= $_SERVER['REMOTE_ADDR'];
				// bind values
				$stmt->bindParam(":remark", $remark, PDO::PARAM_STR);
				$stmt->bindParam(":action_date", $action_date, PDO::PARAM_STR);
				$stmt->bindParam(":uname", $uname, PDO::PARAM_STR);
				$stmt->bindParam(":ipaddr", $ipaddr, PDO::PARAM_STR);
			}
		}
		
		// execute query
		if($stmt->execute()){
			return array('rstatus'=>'1','message'=>'Data updated successfully.');
		}else{
			return array('rstatus'=>'0','message'=>'Error found.'.$stmt->err);
		}
	}
	
	public function checkRemarkExist($remark){
	 
		// select all query
		$query = "Select count(*) as total from refund_remarks where remark like :remark";
		
		// prepare query
		$stmt = $this->conn->prepare($query);
		
		// sanitize
		$remark			= "%$remark%";
		
		// bind values
		$stmt->bindParam(":remark", $remark ,PDO::PARAM_STR);
		
		// execute query
		$stmt->execute();
		
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		
		return $row['total'];
	}
	
}