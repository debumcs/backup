<?php

class managerRefundRemark{

    // database connection and table name
    private $conn;
 
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
	
	// read all Agent Refund Remark
	public function allManagerRefundRemark($data){
		$itemsPerPage 		= $data->itemsPerPage;
		$from_record_num 	= ($data->pageno - 1) * $itemsPerPage;
		
		$remark	= $m_status = '';
		
		if(isset($data->remark)){
			$remark 		= $data->remark;
		}
		
		if(isset($data->m_status)){
			$m_status		= $data->m_status;
		}
		
		// select all query
		
		$query 	= "select * from managerremarks "; 
			
		$query	.= " where remark != '' ";
	
		if($remark!='')
			$query	.= " and remark like :remark ";
		
		if($m_status!='')
			$query	.= " and m_status like :m_status ";
		
		$query	.= " ORDER BY id DESC limit :from_record_num, :itemsPerPage";
		
		// prepare query statement
		$stmt = $this->conn->prepare($query);
		
		// bind values
		
		if($remark!=''){
			$remark = "%$remark%";
			$stmt->bindParam(":remark", $remark, PDO::PARAM_STR);
		}
		
		if($m_status!=''){
			$stmt->bindParam(":m_status", $m_status, PDO::PARAM_STR);
		}
		$stmt->bindParam(":from_record_num", $from_record_num, PDO::PARAM_INT);
		$stmt->bindParam(":itemsPerPage", $itemsPerPage, PDO::PARAM_INT);
		// execute query
		$stmt->execute();
	 
		return $stmt;
	}
	
	// get total number of records
	public function allManagerRefundRemarkTotalRecord($data){
		
		$remark	= $m_status = '';
		
		if(isset($data->remark)){
			$remark 		= $data->remark;
		}
		
		if(isset($data->m_status)){
			$m_status		= $data->m_status;
		}
		
		// select all query
		
		$query 	= "select count(*) as total from managerremarks "; 
			
		$query	.= " where remark != '' ";
	
		if($remark!='')
			$query	.= " and remark like :remark ";
		
		if($m_status!='')
			$query	.= " and m_status like :m_status ";
		
		// prepare query statement
		$stmt = $this->conn->prepare($query);
		
		// bind values
		
		if($remark!=''){
			$remark = "%$remark%";
			$stmt->bindParam(":remark",$remark, PDO::PARAM_STR);
		}
		
		if($m_status!=''){
			$stmt->bindParam(":m_status", $m_status, PDO::PARAM_STR);
		}
		
		// execute query
		$stmt->execute();
		
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		
		return $row['total'];
	}
	
	// read get case information by id
	public function getManagerRefundRemarkById($data){
	 
		// select all query
		$query = "Select * from managerremarks where id=:id";
		
		// prepare query
		$stmt = $this->conn->prepare($query);
		
		// sanitize
		$id			= htmlspecialchars(strip_tags($data->id));
		
		// bind values
		$stmt->bindParam(":id", $id);
		
		// execute query
		$stmt->execute();
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		return $row;
	}
	
	public function managerRefundRemarkInsertUpdate($data){
	 
		// select all query
		
		if($data->id > 0){
			$query = "update managerremarks set m_status=:m_status, action_date=:modifieddatetime, uname=:username, ipaddr=:ipaddr where id=:id";
			// prepare query
			$stmt = $this->conn->prepare($query);
			
			// sanitize
			$id					= htmlspecialchars(strip_tags($data->id));
			$m_status			= htmlspecialchars(strip_tags($data->m_status));
			$modifieddatetime	= date('Y-m-d H:i:s');
			$username			= $_SESSION['ADMIN_NAME'];
			$ipaddr				= $_SERVER['REMOTE_ADDR'];
			// bind values
			$stmt->bindParam(":modifieddatetime", $modifieddatetime, PDO::PARAM_STR);
			$stmt->bindParam(":username", $username, PDO::PARAM_STR);
			$stmt->bindParam(":ipaddr", $ipaddr, PDO::PARAM_STR);
			$stmt->bindParam(":m_status", $m_status, PDO::PARAM_INT);
			$stmt->bindParam(":id", $id, PDO::PARAM_INT);
		}else{
			$check = $this->checkRemarkExist($data->remark);
			
			if($check>0){
				return array('rstatus'=>'0','message'=>'Remark already added to database.');
			}else{
				$query = "insert into managerremarks(remark,action_date,uname,ipaddr) values(:remark, :action_date,:uname,:ipaddr)";
				
				$stmt = $this->conn->prepare($query);			
				// sanitize
				$remark			= htmlspecialchars(strip_tags($data->remark));
				$action_date	= date('Y-m-d H:i:s');
				$uname			= $_SESSION['ADMIN_NAME'];
				$ipaddr			= $_SERVER['REMOTE_ADDR'];
				// bind values
				$stmt->bindParam(":remark", $remark, PDO::PARAM_STR);
				$stmt->bindParam(":action_date", $action_date, PDO::PARAM_STR);
				$stmt->bindParam(":uname", $uname, PDO::PARAM_STR);
				$stmt->bindParam(":ipaddr", $ipaddr, PDO::PARAM_STR);
			}
		}
		
		// execute query
		if($stmt->execute()){
			return array('rstatus'=>'1','message'=>'Data updated successfully.');
		}else{
			return array('rstatus'=>'0','message'=>'Error found.'.$stmt->err);
		}
	}
	
	public function checkRemarkExist($remark){
	 
		// select all query
		$query = "Select count(*) as total from managerremarks where remark like :remark";
		
		// prepare query
		$stmt = $this->conn->prepare($query);
		
		// sanitize
		$remark			= "%$remark%";
		
		// bind values
		$stmt->bindParam(":remark", $remark ,PDO::PARAM_STR);
		
		// execute query
		$stmt->execute();
		
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		
		return $row['total'];
	}
	
}