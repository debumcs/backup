<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
// include database and object files
include_once '../database.php';
include_once 'class/class.agentCBRemark.php';
 
// instantiate database and product object
$database = new Database();
$db = $database->getConnection();
$remark = new agentCBRemark($db);

$data = json_decode(file_get_contents("php://input"));

if(($data->task == "filterAgentCBRemark") ||($data->task == "allAgentCBRemark")){
	
	$stmt = $remark->allAgentCBRemark($data);
	$num  = $remark->allAgentCBRemarkTotalRecord($data);
	
	if($num>0){
		$remarks_arr				= array();
		$remarks_arr["records"]		= array();
		$remarks_arr["numofrec"]	= $num;
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			array_push($remarks_arr["records"], $row);
		}	 
		echo json_encode($remarks_arr);
	}else{
		$remarks_arr["records"]		= array('No records found.');
		$remarks_arr["numofrec"]	= 0;
		echo json_encode($remarks_arr);
	}
	exit;
}else if($data->task == "getAgentCBRemark"){
	
	$row = $remark->getAgentCBRemarkById($data);
	echo json_encode($row);
	exit;
	
}else if($data->task == "agentCBRemarkInsertUpdate"){
	
	$row = $remark->agentCBRemarkInsertUpdate($data);
	echo json_encode($row);
	exit;
	
}else{
	echo json_encode(array("No record found."));
	exit;
}
?>