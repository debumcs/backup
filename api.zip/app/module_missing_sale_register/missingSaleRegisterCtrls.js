app.controller('missingSaleRegisterCtrl',function($scope,$http){
	$scope.myDate = new Date();
	$scope.fromDate = new Date();
	$scope.toDate = new Date();
	
	$scope.master = {};
	$scope.missingSaleList = 1;
	$scope.missingViewSales = -1;
	$scope.rStatus	= -1;
	$http({
		method: 'POST',
		url: 'api/missing_sale_register/getMissingSaleRegister.php',
		data:{'task':'getAllPartner'}
	}).then(function(response){
		$scope.allPartner = response.data.records;
	});
	
	$scope.getplancode = function(){
		
		$http({
			method: 'POST',
			url: 'api/missing_sale_register/getMissingSaleRegister.php',
			data:{'task':'getPlanCode','account':$scope.sale.account}
		}).then(function(response){
			$scope.allPlanCode = response.data.records;
		});
	}
	
	$scope.getplanamount = function(){
		
		$http({
			method: 'POST',
			url: 'api/missing_sale_register/getMissingSaleRegister.php',
			data:{'task':'getPlanAmount','plancode':$scope.sale.plancode}
		}).then(function(response){
			$scope.sale.amount = response.data.amount;
		});
	}
	
	
	$scope.reset = function() {
		$scope.sale = angular.copy($scope.master);
	};
	
	$scope.submitForm = function(valid){
		
		if(valid){
			$http({
				method: 'POST',
				url: 'api/missing_sale_register/getMissingSaleRegister.php',
				data:{'task':'registerMissingSale', 'orderid':$scope.sale.orderid, 'email':$scope.sale.email, 'account':$scope.sale.account, 'plancode':$scope.sale.plancode, 'amount':$scope.sale.amount}
			}).then(function(response){
				$scope.rMessage = response.data.msg;
				$scope.rStatus 	= response.data.rstatus;
				if(response.data.rstatus == '1'){
					$scope.ngclass = 'alert-success';
				}
				if(response.data.rstatus == '2'){
					$scope.ngclass = 'alert-danger';
				}
				if(response.data.rstatus == '3'){
					$scope.ngclass = 'alert-danger';
				}
				$scope.reset();
			});
		}else{
			console.log('Invalid form');
		}		
	}
	
	$scope.reset();
	
	$scope.viewList = function(){
		$scope.missingSaleList = 2;
	};
	
	$scope.viewSales = function(){
		
		$http({
			method: 'POST',
			url: 'api/missing_sale_register/getMissingSaleRegister.php',
			data:{'task':'viewSales', 'morderno':$scope.miss.morderno, 'order_status':$scope.miss.order_status, 'fromDate':$scope.miss.fromDate, 'toDate':$scope.miss.toDate }
		}).then(function(response){
			$scope.rMessage = response.data.msg;
			$scope.rStatus 	= response.data.rstatus;
		});
		$scope.missingViewSales = 3;
	};
	
});

app.directive('ngExists',function($http){
	return {
        require: 'ngModel',
        link: function(scope, element, attr, ngModel) {
            function myValidation(value) {
                $http({
					method: 'POST',
					url: 'api/missing_sale_register/getMissingSaleRegister.php',
					data:{'task':'checkOrderNumberExist','orderid':value}
				}).then(function(response){
					if (response.data.status > 0) {
						ngModel.$setValidity('exists', false);
					} else {
						ngModel.$setValidity('exists', true);
					}
				});
                return value;
            }
            ngModel.$parsers.push(myValidation);
        }
    };
});
