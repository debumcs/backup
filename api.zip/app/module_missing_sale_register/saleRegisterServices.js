app.controller('NaviCtrl', function($scope, $route) {
	$scope.route = $route;
});

app.controller('agentRefundRemarkCtrl',function($scope,$http){
	$scope.loading=true;
	$scope.total_count = 0;
	$scope.itemsPerPage = 10; //this could be a dynamic value from a drop down
	
	$scope.allAgentRemark = function(pageno){
		
		$scope.agentRemarks = []; //declare an empty array
		$scope.loading = true;
		if(pageno===undefined){
			$scope.pageno = 1; // initialize page no to 1
		}else{
			$scope.pageno = pageno; 
		}
		
		$http({
			method: 'POST',
			url: 'api/remark/getRemark.php',
			data:{'task':'allAgentRemark','itemsPerPage':$scope.itemsPerPage,'pageno':$scope.pageno,'remark':$scope.remark,'remFlag':$scope.remFlag}
		}).then(function(response){
			$scope.loading		= false;
			$scope.agentRemarks = response.data.records;
			$scope.total_count 	= response.data.numofrec;
		});		
	}
	
	$scope.filterAgentRefundRemark = function(pageno){
		$scope.closeCases = [];
		$scope.loading=true;
		if(pageno===undefined){
			$scope.pageno = 1; 
		}else{
			$scope.pageno = pageno; 
		}
		$http({
			method: 'POST',
			url: 'api/remark/getRemark.php',
			data:{'task':'filterAgentRefundRemark','itemsPerPage':$scope.itemsPerPage,'pageno':$scope.pageno,'remark':$scope.remark,'remFlag':$scope.remFlag}
		}).then(function(response){
			$scope.loading=false;
			$scope.agentRemarks = response.data.records;
			$scope.total_count 	= response.data.numofrec;
		});
	};
	
	$scope.reset = function(){
		$scope.remark 	= '';
		$scope.remFlag 	= '';
		$scope.allAgentRemark(1);
	};
	
});

app.controller('addEditAgentRefundRemarkCtrl',function($scope,$http,$routeParams){
	//$scope.loading=true;
	var id = ($routeParams.id) ? parseInt($routeParams.id) : 0;
	$scope.Title = (id > 0) ? "Edit Agent Refund Remark":"Add Agent Refund Remark";
    $scope.RecordToEdit = $routeParams.id; // get the parameter
	
	/*$scope.allAgentRemark = function(pageno){
		
		$scope.agentRemarks = []; //declare an empty array
		$scope.loading = true;
		if(pageno===undefined){
			$scope.pageno = 1; // initialize page no to 1
		}else{
			$scope.pageno = pageno; 
		}
		
		$http({
			method: 'POST',
			url: 'api/remark/getRemark.php',
			data:{'task':'allAgentRemark','itemsPerPage':$scope.itemsPerPage,'pageno':$scope.pageno,'remark':$scope.remark,'remFlag':$scope.remFlag}
		}).then(function(response){
			$scope.loading		= false;
			$scope.agentRemarks = response.data.records;
			$scope.total_count 	= response.data.numofrec;
		});		
	}
	
	$scope.filterAgentRefundRemark = function(pageno){
		$scope.closeCases = [];
		$scope.loading=true;
		if(pageno===undefined){
			$scope.pageno = 1; 
		}else{
			$scope.pageno = pageno; 
		}
		$http({
			method: 'POST',
			url: 'api/remark/getRemark.php',
			data:{'task':'filterAgentRefundRemark','itemsPerPage':$scope.itemsPerPage,'pageno':$scope.pageno,'remark':$scope.remark,'remFlag':$scope.remFlag}
		}).then(function(response){
			$scope.loading=false;
			$scope.agentRemarks = response.data.records;
			$scope.total_count 	= response.data.numofrec;
		});
	};
	
	$scope.reset = function(){
		$scope.remark 	= '';
		$scope.remFlag 	= '';
		$scope.allAgentRemark(1);
	};*/
	
});