app.controller('saleRegisterCtrl',function($scope,$http){
	$scope.loading = false;
	$scope.orderStatus=-1;
	$scope.rStatus 	= -1;
	$scope.findOrderInfo = function(){
		$scope.rStatus 	= -1;
		$scope.sale_medium='';
		$scope.agentid='';
		$scope.loading = true;
		$http({
			method: 'POST',
			url: 'api/sale_register/getSaleRegister.php',
			data:{'task':'getOrderInfo','orderno':$scope.orderno}
		}).then(function(response){
			$scope.orderDetails = response.data.records;
			$scope.orderStatus 	= response.data.orderStatus;
			$scope.agentid 		= response.data.username;
			$scope.saleMediums  = response.data.saleMediums;
		});
	}
	
	$scope.submitForm = function(){
		$scope.loading = true;		
		$http({
			method: 'POST',
			url: 'api/sale_register/getSaleRegister.php',
			data:{'task':'registerSale','orderno':$scope.orderno,'sale_medium':$scope.sale_medium,'agentid':$scope.agentid}
		}).then(function(response){
			$scope.rMessage = response.data.msg;
			$scope.rStatus 	= response.data.rstatus;
			$scope.loading = false;
			if(response.data.rstatus == '1'){
				$scope.ngclass = 'alert-warning';
			}
			if(response.data.rstatus == '2'){
				$scope.ngclass = 'alert-success';
			}
			if(response.data.rstatus == '3'){
				$scope.ngclass = 'alert-danger';
			}
			$scope.orderno='';
			$scope.sale_medium='';
			$scope.agentid='';
		});
	}
	
});