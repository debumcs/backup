app.controller('refundRequestCtrls',function($scope,$http){
	
	$scope.master = {};
	
	$scope.reset = function(){
		$scope.req = angular.copy($scope.master);
	};
	
	$scope.diffDate = function(date1, date2){
		var dateOut1 = new Date(date1);
		var dateOut2 = new Date(date2);

		var timeDiff = Math.abs(dateOut2.getTime() - dateOut1.getTime());
		var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
		//alert(diffDays);
		return diffDays;
	};
	
	$scope.refundRequest = function(valid){
		//$scope.request.$setSubmitted();
		
		var datediff = $scope.diffDate($scope.req.startdate,$scope.req.enddate)
		//alert(datediff);
		//alert($scope.req.startdate+'#'+$scope.req.enddate+'#'+$scope.req.orderno+'#'+$scope.req.contactid+'#'+$scope.req.status);
		
		if(valid){			
			if(datediff >= 0 && datediff <= 30){
				$scope.loading = true;		
				$http({
					method: 'POST',
					url: 'api/refund_request/getRefundRequest.php',
					data:{'task':'registerSale','orderno':$scope.orderno,'sale_medium':$scope.sale_medium,'agentid':$scope.agentid}
				}).then(function(response){
					$scope.rMessage = response.data.msg;
					$scope.rStatus 	= response.data.rstatus;
					$scope.loading = false;
					if(response.data.rstatus == '1'){
						$scope.ngclass = 'alert-warning';
					}
					if(response.data.rstatus == '2'){
						$scope.ngclass = 'alert-success';
					}
					if(response.data.rstatus == '3'){
						$scope.ngclass = 'alert-danger';
					}
					$scope.orderno='';
					$scope.sale_medium='';
					$scope.agentid='';
				});
			}else if(datediff < 0){
				alert('Please enter correct start date and end date!');
			}else{
				alert('Date Range should not greater than 31 days!');
			}
			
		}else{
			if($scope.req.startdate == ''){
				alert("select start date");
			}
			
			if($scope.req.enddate == ''){
				alert("select end date");
			}
			
			if($scope.req.status == ''){
				alert("select status");
			}
		}
		
		
		
	}
	
});