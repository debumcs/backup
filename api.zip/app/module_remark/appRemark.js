//var app = angular.module('remarkApp', ['ngRoute','ui.bootstrap','ngSanitize','ngResource','angularUtils.directives.dirPagination']);

app.config(function ($routeProvider, $locationProvider) {
    $routeProvider
        .when('/agentRefundRemark',{
            templateUrl: 'app/module_remark/template/agentRefundRemark.html',
			controller: 'agentRefundRemarkCtrl',
			activetab: "page1"
        })
		.when('/addEditAgentRefundRemark/:id',{
            templateUrl: 'app/module_remark/template/addEditAgentRefundRemark.html',
			controller: 'addEditAgentRefundRemarkCtrl',
			activetab: "page1"
        })
		.when('/managerRefundRemark',{
            templateUrl: 'app/module_remark/template/managerRefundRemark.html',
			controller: 'managerRefundRemarkCtrl',
			activetab: "page2"
        })
        .when('/addEditManagerRefundRemark/:id',{
            templateUrl: 'app/module_remark/template/addEditManagerRefundRemark.html',
			controller: 'addEditManagerRefundRemarkCtrl',
			activetab: "page2"
        })
		.when('/agentCBRemark',{
            templateUrl: 'app/module_remark/template/agentCBRemark.html',
			controller: 'agentCBRemarkCtrl',
			activetab: "page3"
        })
		.when('/addEditAgentCBRemark',{
            templateUrl: 'app/module_remark/template/addEditAgentCBRemark.html',
			controller: 'agentCBRemarkCtrl',
			activetab: "page3"
        })
		.when('/managerCBRemark',{
            templateUrl: 'app/module_remark/template/managerCBRemark.html',
			controller: 'managerCBRemarkCtrl',
			activetab: "page4"
        })
        .when('/addEditManagerCBRemark',{
            templateUrl: 'app/module_remark/template/addEditManagerCBRemark.html',
			controller: 'managerCBRemarkCtrl',
			activetab: "page4"
        })
        .otherwise({
            redirectTo: '/agentRefundRemark'
        });

    $locationProvider.hashPrefix('');
});