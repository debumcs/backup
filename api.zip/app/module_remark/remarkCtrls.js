app.controller('NaviCtrl', function($scope, $route) {
	$scope.route = $route;
});

app.controller('agentRefundRemarkCtrl',function($scope,$http){
	$scope.loading=true;
	$scope.total_count = 0;
	$scope.itemsPerPage = 10; //this could be a dynamic value from a drop down
	
	$scope.allAgentRemark = function(pageno){
		
		$scope.agentRemarks = []; //declare an empty array
		$scope.loading = true;
		if(pageno===undefined){
			$scope.pageno = 1; // initialize page no to 1
		}else{
			$scope.pageno = pageno; 
		}
		
		$http({
			method: 'POST',
			url: 'api/remark/getAgentRefundRemark.php',
			data:{'task':'allAgentRemark','itemsPerPage':$scope.itemsPerPage,'pageno':$scope.pageno,'remark':$scope.remark,'remFlag':$scope.remFlag}
		}).then(function(response){
			$scope.loading		= false;
			$scope.agentRemarks = response.data.records;
			$scope.total_count 	= response.data.numofrec;
		});		
	}
	
	$scope.filterAgentRefundRemark = function(pageno){
		$scope.agentRemarks = [];
		$scope.loading=true;
		if(pageno===undefined){
			$scope.pageno = 1; 
		}else{
			$scope.pageno = pageno; 
		}
		$http({
			method: 'POST',
			url: 'api/remark/getAgentRefundRemark.php',
			data:{'task':'filterAgentRefundRemark','itemsPerPage':$scope.itemsPerPage,'pageno':$scope.pageno,'remark':$scope.remark,'remFlag':$scope.remFlag}
		}).then(function(response){
			$scope.loading=false;
			$scope.agentRemarks = response.data.records;
			$scope.total_count 	= response.data.numofrec;
		});
	};
	
	$scope.reset = function(){
		$scope.remark 	= '';
		$scope.remFlag 	= '';
		$scope.allAgentRemark(1);
	};
	
});

app.controller('addEditAgentRefundRemarkCtrl',function($scope,$http,$routeParams){
	$scope.errorFlag=false;
	var id = ($routeParams.id) ? parseInt($routeParams.id) : 0;
	$scope.Title = (id > 0) ? "Change Agent Refund Remark Status":"Add Agent Refund Remark";
	$scope.buttonText = (id > 0) ? 'Update' : 'Add';	
    $scope.RecordToEdit = $routeParams.id; // get the parameter
	
	if(id > 0){
		$http({
			method: 'POST',
			url: 'api/remark/getAgentRefundRemark.php',
			data:{'task':'getAgentRemark','id':id}
		}).then(function(response){
			$scope.remark = response.data.remark;
			$scope.remFlagAddEdit 	= response.data.remFlag;
		});
	}
	
	$scope.agentRemarkInsertUpdate = function(){
		$http({
			method: 'POST',
			url: 'api/remark/getAgentRefundRemark.php',
			data:{'task':'agentRemarkInsertUpdate','remark':$scope.remark,'remFlag':$scope.remFlagAddEdit,'id':$scope.RecordToEdit}
		}).then(function(response){
			$scope.message 	= response.data.message;
			$scope.rstatus 	= response.data.rstatus;
			$scope.errorFlag=true;
		});
	}
	
});

app.controller('managerRefundRemarkCtrl',function($scope,$http){
	$scope.loading=true;
	$scope.total_count = -1;
	$scope.itemsPerPage = 10; //this could be a dynamic value from a drop down
	
	$scope.allManagerRefundRemark = function(pageno){
		
		$scope.managerRefundRemarks = []; //declare an empty array
		$scope.loading = true;
		if(pageno===undefined){
			$scope.pageno = 1; // initialize page no to 1
		}else{
			$scope.pageno = pageno; 
		}
		
		$http({
			method: 'POST',
			url: 'api/remark/getManagerRefundRemark.php',
			data:{'task':'allManagerRefundRemark','itemsPerPage':$scope.itemsPerPage,'pageno':$scope.pageno,'remark':$scope.remark,'m_status':$scope.m_status}
		}).then(function(response){
			$scope.loading = false;
			$scope.managerRefundRemarks = response.data.records;
			$scope.total_count = response.data.numofrec;
		});		
	}
	
	$scope.filterManagerRefundRemark = function(pageno){
		$scope.managerRefundRemarks = [];
		$scope.loading=true;
		if(pageno===undefined){
			$scope.pageno = 1; 
		}else{
			$scope.pageno = pageno; 
		}
		$http({
			method: 'POST',
			url: 'api/remark/getManagerRefundRemark.php',
			data:{'task':'filterManagerRefundRemark','itemsPerPage':$scope.itemsPerPage,'pageno':$scope.pageno,'remark':$scope.remark,'m_status':$scope.m_status}
		}).then(function(response){
			$scope.loading=false;
			$scope.managerRefundRemarks = response.data.records;
			$scope.total_count 	= response.data.numofrec;
		});
	};
	
	$scope.reset = function(){
		$scope.remark 	= '';
		$scope.m_status 	= '';
		$scope.allManagerRefundRemark(1);
	};
	
});

app.controller('addEditManagerRefundRemarkCtrl',function($scope,$http,$routeParams){
	$scope.errorFlag=false;
	var id = ($routeParams.id) ? parseInt($routeParams.id) : 0;
	$scope.Title = (id > 0) ? "Change Manager Refund Remark Status":"Add Manager Refund Remark";
	$scope.buttonText = (id > 0) ? 'Update' : 'Add';	
    $scope.RecordToEdit = $routeParams.id; // get the parameter
	
	if(id > 0){
		$http({
			method: 'POST',
			url: 'api/remark/getManagerRefundRemark.php',
			data:{'task':'getManagerRefundRemark','id':id}
		}).then(function(response){
			$scope.remark = response.data.remark;
			$scope.m_statusAddEdit 	= response.data.m_status;
		});
	}
	
	$scope.managerRefundRemarkInsertUpdate = function(){
		$http({
			method: 'POST',
			url: 'api/remark/getManagerRefundRemark.php',
			data:{'task':'managerRefundRemarkInsertUpdate', 'remark':$scope.remark, 'm_status':$scope.m_statusAddEdit, 'id':$scope.RecordToEdit}
		}).then(function(response){
			$scope.message 	= response.data.message;
			$scope.rstatus 	= response.data.rstatus;
			$scope.errorFlag=true;
		});
	}
	
});