//var app = angular.module('closeCaseMoniApp', ['ui.bootstrap','ngSanitize','ngResource','angularUtils.directives.dirPagination']);
app.controller('closeCaseMoniCtlr',function($scope,$http,$modal){
	
	$scope.tab = 1;
	$scope.loading=true;
	$scope.total_count = 0;
	$scope.itemsPerPage = 10; //this could be a dynamic value from a drop down
	
	$scope.allCloseCases = function(pageno){
		
		$scope.closeCases = []; //declare an empty array
		$scope.loading=true;
		if(pageno===undefined){
			$scope.pageno = 1; // initialize page no to 1
		}else{
			$scope.pageno = pageno; 
		}
		
		$http({
			method: 'POST',
			url: 'api/close_case_monitoring/getAllCloseCases.php',
			data:{'task':'allCloseCases','itemsPerPage':$scope.itemsPerPage,'pageno':$scope.pageno,'caseid':$scope.close_case_caseid,'firstinput':$scope.close_case_firstinput,'secondinput':$scope.close_case_secondinput}
		}).then(function(response){
			$scope.loading=false;
			$scope.closeCases = response.data.records;
			$scope.total_count = response.data.numofrec;
		});		
	}
	
	$scope.submitCloseCases = function(pageno){
		$scope.closeCases = [];
		$scope.loading=true;
		if(pageno===undefined){
			$scope.pageno = 1; 
		}else{
			$scope.pageno = pageno; 
		}
		$http({
			method: "POST",
			url:'api/close_case_monitoring/getAllCloseCases.php',
			data:{'task':'submitCloseCases','itemsPerPage':$scope.itemsPerPage,'pageno':$scope.pageno,'caseid':$scope.close_case_caseid,'firstinput':$scope.close_case_firstinput,'secondinput':$scope.close_case_secondinput}
		})
		.then(function(response){
			$scope.loading=false;
			$scope.closeCases = response.data.records;
			$scope.total_count = response.data.numofrec;
		});

	};
	
	$scope.ccases_reset = function(){
		$scope.close_case_caseid = '';
		$scope.close_case_firstinput = null;
		$scope.close_case_secondinput = null;
		$scope.allCloseCases(1);
	};
	
	
	$scope.rTotal_count = 0;
	$scope.rItemsPerPage = 10;
	$scope.allRemarkCloseCases = function(rpageno){
		$scope.remarkCloseCases = []; //declare an empty array
		$scope.loading=true;
		if(rpageno===undefined){
			$scope.rpageno = 1; // initialize page no to 1
		}else{
			$scope.rpageno = rpageno; 
		}
		$http({
			method: 'POST',
			url: 'api/close_case_monitoring/getCloseCase.php',
			data:{'task':'allRemarkCloseCases','itemsPerPage':$scope.rItemsPerPage,'pageno':$scope.rpageno,'caseid':$scope.rc_caseid,'firstinput':$scope.rc_firstinput,'secondinput':$scope.rc_secondinput}
		}).then(function(response){
			$scope.loading=false;
			$scope.remarkCloseCases = response.data.records;
			$scope.rTotal_count = response.data.numofrec;
		});		
	}
	
	$scope.submitRCCases = function(rpageno){
		$scope.remarkCloseCases = []; 
		$scope.loading=true;
		if(rpageno===undefined){
			$scope.rpageno = 1; 
		}else{
			$scope.rpageno = rpageno; 
		}
		$http({
			method: "POST",
			url:'api/close_case_monitoring/getCloseCase.php',
			data:{'task':'submitRCCases','itemsPerPage':$scope.rItemsPerPage,'pageno':$scope.rpageno,'caseid':$scope.rc_caseid,'firstinput':$scope.rc_firstinput,'secondinput':$scope.rc_secondinput}
		})
		.then(function(response){
			$scope.loading=false;
			$scope.remarkCloseCases = response.data.records;
			$scope.rTotal_count = response.data.numofrec;
		});

	};
	
	$scope.remark_cases_reset = function(){
		$scope.rc_caseid = '';
		$scope.rc_firstinput = null;
		$scope.rc_secondinput = null;
		$scope.allRemarkCloseCases(1);
	};
		
	$scope.getAllCaseHistory = function (caseid) {
		
		$http({
			method: "POST",
			url:'api/close_case_monitoring/getCloseCase.php',
			data:{'task':'allCaseHistory','caseid':caseid}
		})
		.then(function(response){
			$scope.allCaseHistory = response.data.records;
			$scope.caseid = response.data.caseid;
			var modalInstance = $modal.open({
				templateUrl: 'app/module_close_case_monitoring/template/all_casehistory.html',
				controller: ModalInsCaseHistoryCtrl,
				scope: $scope,
				resolve: true,
				windowClass: 'all-history-modal'
			});

			modalInstance.result.then(function (selectedItem) {
				$scope.selected = selectedItem;
			}, function () {
				console.log('Modal dismissed at: ' + new Date());
			});
		});
	};
	
	$scope.addRemark = function(caseid){
		$scope.message = "Add remark form";
		console.log($scope.message);
		$scope.caseid = caseid;
		var modalInstanceRemark = $modal.open({
			templateUrl: 'app/module_close_case_monitoring/template/addRemark.html',
			controller: AddRemarkCtrl,
			scope:$scope,
			resolve:{
				addRemark: function(){
					return $scope.addRemark;
				}
			}
		});
		
		modalInstanceRemark.result.then(function (modaldata){
			$scope.selected = modaldata.selectedItem;
			$scope.errorFlag = modaldata.errorFlag;
			$scope.messageSuccess = modaldata.messageSuccess;
			$scope.allCloseCases();
			$scope.allRemarkCloseCases();
			console.log('selected item: ' +$scope.selected);
		},function (){
			console.log('Modal dismissed at: ' + new Date());
		});
	};
	
	$scope.submitAddRemark = function(){
		
		if ($scope.form.addRemark.$valid) {
            
			$http({
				method: "POST",
				url:'api/close_case_monitoring/getCloseCase.php',
				data:{'task':'addRemark','remark':$scope.remark,'correct_closer':$scope.correct_closer,'caseid':$scope.caseid}
			})
			.then(function(response){
				
				var modaldata = {
					selectedItem: "closed",
					errorFlag: response.data.errorFlag,
					messageSuccess: response.data.message
				}
				console.log('ErrorFlag:'+$scope.errorFlag+', Message:'+$scope.messageSuccess);
				$scope.form = {};
				$scope.close(modaldata);
			});
			
        } else {
            console.log('userform is not in scope');
        }
	};

	$scope.popupnote = function (id) {
		
		$http({
			method: "POST",
			url:'api/close_case_monitoring/getCloseCase.php',
			data:{'task':'caseNoteHistory','id':id}
		})
		.then(function(response){
			$scope.noteCaseHistory = response.data.records;
			$scope.cid = response.data.cid;
			var modalInstance = $modal.open({
				templateUrl: 'app/module_close_case_monitoring/template/case_notes.html',
				controller: ModalCaseNoteCtrl,
				scope: $scope,
				windowClass: 'casenote-history-modal'
			});

			modalInstance.result.then(function (selectedItem) {
				$scope.selected = selectedItem;
			}, function () {
				console.log('Modal dismissed at: ' + new Date());
			});
		});
		
	};
	
});

var ModalInsCaseHistoryCtrl = function ($scope,$modalInstance) {
    $scope.cancel = function (){
        $modalInstance.dismiss('cancel');
    };
};

var ModalCaseNoteCtrl = function ($scope,$modalInstance) {
    $scope.cancel = function (){
        $modalInstance.dismiss('cancel');
    };    
};

var AddRemarkCtrl = function($http,$scope,$modalInstance,addRemark){
	
	$scope.close = function(modaldata){
		$modalInstance.close(modaldata);
	}
	
	$scope.cancel = function(){
		$modalInstance.dismiss('cancel');
	}
};