   app.controller( 'mailCtrl', [ '$scope','$http', '$sce',   function ($scope, $http,$sce) {
   $scope.flag = ''; 
   $scope.accountName = ''; 
   $scope.accountCode = ''; 
   $scope.customerName = '';  
   $scope.customerLname = ''; 
   $scope.customerEmailId = ''; 
    
   $scope.caseId = '';     
    $scope.findForm = function() {
       $http({
			method: 'POST',
			url: 'api/mail_for_customer/getContactId.php',
			data:{'task':'getContactId','contactid':$scope.contactid}
		}).then(function(response){
		   // console.log(response); 
	 
		   $scope.flag = response.data.flag;
		   $scope.accountName = response.data.account_name; 
		   $scope.accountCode = response.data.account_code; 
		   $scope.customerName = response.data.customer_name;  
		   $scope.customerLname = response.data.customer_lname; 
		   $scope.customerEmailId = response.data.customer_email_id;   
		   $scope.orders = response.data.orderId;
		   console.log($scope.orders);
		   $scope.caseId = response.data.cases; 	   		   
		  //$scope.contact_info = $sce.trustAsHtml(response.data.records);
		});
    };
	
	$scope.getcases = function() {
		console.log($scope.orders);
	   /*$http({
			method: 'POST',
			url: 'api/mail_for_customer/getContactId.php',
			data:{'task':'getCases','transid':$scope.transid}
		}).then(function(response){
		   // console.log(response); 
 		   $scope.orderId = response.data.orderId; 
		   $scope.caseId = response.data.cases; 	   		   
		  //$scope.contact_info = $sce.trustAsHtml(response.data.records);
		});*/
	}
	
	 

	 
}]);

