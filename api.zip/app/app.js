var app = angular.module('crmApp', [ 
'ngRoute',
'ngMaterial',
'ui.bootstrap',
'ngSanitize',
'ngResource',
'angularUtils.directives.dirPagination'
]);