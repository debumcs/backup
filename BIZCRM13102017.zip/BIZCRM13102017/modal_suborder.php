	<?php
	require_once('class/class.fabric.php');
	$objfabric 		= new Fabric();
	$allfabricdata = $objfabric->getAll();
	?>
	<!-- Add dying -->
	<div class="modal fade" id="adddying" tabindex="-1" role="dialog" aria-labelledby="adddyingLabel">
		<div class="modal-dialog" role="document">
		<form action="" method="post" name="formdying" id="formdying">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel"><?php if(count($dyerinfo) > 0){echo 'View Dying Agency'; $dydisable = 'disabled'; $dyreadonly = 'readonly="true"';}else{ echo  'Assign to Dying Agency'; $dyreadonly = ''; $dydisable = '';} ?></h4>
				</div>
				<div class="modal-body">
					<div class="row">
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Challan No</label>
											<input type="text" id="dychallanno" tabindex="1" name="dychallanno" <?php echo $dyreadonly; ?> class="form-control" value="<?php echo $dyerinfo['dychallanno']; ?>" />
											<input type="hidden" id="id" name="id" class="form-control" value="<?php echo $dyerinfo['id']; ?>" />
											<input type="hidden" id="orderno" name="orderno" class="form-control" value="<?php echo $orderno; ?>" />
											<input type="hidden" id="suborderno" name="suborderno" class="form-control" value="<?php echo $suborder; ?>" />
										</div>
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Details</label>
										  <input type="text" class="form-control" tabindex="2" id="dydetails" <?php echo $dyreadonly; ?> name="dydetails" placeholder="Enter details" value="<?php echo $dyerinfo['dydetails']; ?>">
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Dyer ID</label>
											<select class="form-control select2" tabindex="3" <?php echo $dydisable; ?> id="dyerid" name="dyerid" style="width:100%;">
											<option value="" selected>Select</option>
											<?php 				
											for($dyi=0; $dyi<count($allagent); $dyi++) {
												if($allagent[$dyi]['type'] == 'Dying'){ 
													if($dyerinfo['dyerid'] == $allagent[$dyi]['id']){$selected = 'selected';}
													echo "<option value='".$allagent[$dyi]['id']."' $selected>".$allagent[$dyi]['agencyname']."</option>"; 
												}
											}
											?>
											</select>
										</div>									  
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Fabric ID</label>
											<select class="form-control select2" tabindex="4" <?php echo $dydisable; ?> id="dyfabricid" name="dyfabricid" style="width:100%;">
											<option value="" selected>Select</option>
											<?php 				
											for($fbi=0; $fbi<count($allfabricdata); $fbi++) {												
												if($dyerinfo['dyfabricid'] == $allfabricdata[$fbi]['id']){$selected = 'selected';}
												echo "<option value='".$allfabricdata[$fbi]['id']."' $selected>".$allfabricdata[$fbi]['fabricname']."</option>";
											}
											?>
											</select>
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Quantity(in Metre)</label>
											<input type="text" class="form-control" tabindex="5" <?php echo $dyreadonly; ?> onKeyPress="return isDecimalNumber(event,this);" id="dyquantity" name="dyquantity" placeholder="Enter quantity" value="<?php echo $dyerinfo['dyquantity']; ?>">
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Dying Color</label>
											<input type="text" class="form-control" tabindex="6" <?php echo $dyreadonly; ?> id="dying_color" name="dying_color" placeholder="Enter dying color" value="<?php echo $dyerinfo['dying_color']; ?>">
										</div>			  
									</div><!-- /.col -->									
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Assign Date</label>
										  <input type="text" class="form-control datepicker" tabindex="7" <?php echo $dyreadonly; ?> id="dyassign_date" name="dyassign_date" placeholder="Enter assign date" value="<?php echo $dyerinfo['dyassign_date']; ?>">
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Due Date</label>
											<input type="text" class="form-control datepicker" tabindex="8" <?php echo $dyreadonly; ?> id="dydue_date" name="dydue_date" placeholder="Enter due date" value="<?php echo $dyerinfo['dydue_date']; ?>">
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Receiving Date</label>
											<input type="text" class="form-control datepicker" tabindex="9" <?php echo $dyreadonly; ?> id="dyreceiving_date" name="dyreceiving_date" placeholder="Enter receiving date" value="<?php echo $dyerinfo['dyreceiving_date']; ?>">
										</div>			  
									</div><!-- /.col -->									
								</div>
								
								<?php if(count($dyerinfo) > 0){	?> 
								
								<div class="col-lg-12">
									<div class="col-lg-8">
										<div class="response"></div>	
									</div><!-- /.col -->
								</div><!-- /.col -->
								
								<div class="col-lg-12">
									<div class="col-lg-8">
										<div class="form-group">											
											<input type="button" onclick="dyingreadonly();" class="btn btn-primary" tabindex="10" name="editdying" id="editdying" value="Edit" />
											<input type="button" onclick="updateDyingInfo();" style="display:none;" tabindex="11" class="btn btn-primary" name="updatedying" id="updatedying" value="Update" />
										</div>	
									</div><!-- /.col -->
								</div><!-- /.col -->
								<?php $alldyingnotes = $objord->getallnotes('dyer',$dyerinfo['dyerid'],$suborder); ?>
								<div class="col-lg-12 orderdiv" id="notesdyer" style="max-height: 100px;">
									<?php foreach($alldyingnotes as $dyingnote){?>
									<div class="col-lg-12">
										<div class="form-group">											
												Notes	: <?php echo $dyingnote['dying_notes']; ?>
										</div>	
									</div>
									<div class="col-lg-12">
										<div class="col-lg-6">
											<div class="form-group">											
												Date	: <?php echo $dyingnote['createdon']; ?>													
											</div>
										</div>
										<div class="col-lg-6">
											<div class="form-group">											
												Status	: <?php echo $dyingnote['dystatus']; ?>
											</div>
										</div>
									</div>
									<?php } ?>
								</div><!-- /.col -->
								<?php } ?>
								
								<div class="col-lg-12">
									<div class="col-lg-8">
										<div class="form-group">
										  <label for="name">Notes</label>
										  <input type="text" class="form-control" id="dying_notes" tabindex="12" name="dying_notes" placeholder="Enter notes" value="">
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Status</label>
											<select class="form-control select2" id="dystatus" tabindex="13" name="dystatus" style="width:100%;">
											<option value="" selected >Select Status</option>
											<option value="1" >Incomplete</option>
											<option value="2" >Pending</option>
											<option value="3" >Processed</option>
											<option value="4" >Partially Shipped</option>
											<option value="5" >Shipping</option>
											<option value="6" >Shipped</option>
											<option value="7" >Partially Returned</option>
											<option value="8" >Returned</option>
											<option value="9" >Cancelled</option>
											</select>
										</div>			  
									</div><!-- /.col -->									
								</div>                             
						  
					</div><!-- /.row -->
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					
					<?php if(count($dyerinfo) <= 0){ ?> 
					<input type="submit" class="btn btn-primary" name="savedying" id="savedying" tabindex="14" onclick="return validatedying();" value="Save" />
					<?php }else{ ?>
					<input type="button" class="btn btn-primary" name="adddyingnote" id="adddyingnote" tabindex="15" onclick="adddyingnotes();" value="Add Note" />
					<?php } ?>
				</div>
			</div>
		</form>
		</div>
	</div>
	<!-- Add dying -->
	
	<!-- Add Embroidery -->
	<div class="modal fade" id="addEmbroidery" tabindex="-1" role="dialog" aria-labelledby="addEmbroideryLabel">
		<div class="modal-dialog" role="document">
		<form action="" method="post" name="formEmbroidery" id="formEmbroidery">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel"><?php if(count($embroinfo) > 0){echo 'View Embroidery'; $emreadonly = 'readonly="true"'; $emdisable = 'disabled';}else{ echo  'Assign to Embroidery'; $emreadonly = ''; $emdisable = '';} ?></h4>
				</div>
				<div class="modal-body">
					<div class="row">
						
						<div class="col-lg-12">
							<div class="col-lg-4">
								<div class="form-group">
									<label for="name">Challan No</label>											
									<input type="text" id="emchallanno" name="emchallanno" class="form-control" tabindex="1" <?php echo $emreadonly; ?> value="<?php echo $embroinfo['emchallanno']; ?>" />
									<input type="hidden" id="id" name="id" class="form-control" value="<?php echo $embroinfo['id']; ?>" />
									<input type="hidden" id="orderno" name="orderno" class="form-control" value="<?php echo $orderno; ?>" />
									<input type="hidden" id="suborderno" name="suborderno" class="form-control" value="<?php echo $suborder; ?>" />
								</div>
							</div><!-- /.col -->

							<div class="col-lg-4">										
								<div class="form-group">
								  <label for="name">Details</label>
								  <input type="text" class="form-control" id="emdetails" name="emdetails" tabindex="2" placeholder="Enter details" <?php echo $emreadonly; ?> value="<?php echo $embroinfo['emdetails']; ?>">
								</div>									  
							</div><!-- /.col -->
							
							<div class="col-lg-4">										
								<div class="form-group">
								  <label for="name">Embroider ID</label>
								  <select class="form-control select2" id="embroiderid" <?php echo $emdisable; ?> tabindex="3" name="embroiderid" style="width:100%;">
									<option value="" selected>Select</option>
									<?php 				
									for($emi=0; $emi<count($allagent); $emi++) {
										if($allagent[$emi]['type'] == 'Embroidery'){ 		
											if($embroinfo['embroiderid'] == $allagent[$emi]['id']){$selected = 'selected';}
											echo "<option value='".$allagent[$emi]['id']."' $selected>".$allagent[$emi]['agencyname']."</option>"; 
										}
									}
									?>
									</select>
								</div>									  
							</div><!-- /.col -->
						</div>
						
						<div class="col-lg-12">
							<div class="col-lg-4">
								<div class="form-group">
								  <label for="name">Assign Date</label>
								  <input type="text" class="form-control datepicker" id="emassign_date" name="emassign_date" tabindex="4" placeholder="Enter assign date" <?php echo $emreadonly; ?> value="<?php echo $embroinfo['emassign_date']; ?>">
								</div>	
							</div><!-- /.col -->

							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Due Date</label>
									<input type="text" class="form-control datepicker" id="emdue_date" name="emdue_date" tabindex="5" placeholder="Enter due date" <?php echo $emreadonly; ?> value="<?php echo $embroinfo['emdue_date']; ?>">
								</div>			  
							</div><!-- /.col -->
							
							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Receiving Date</label>
									<input type="text" class="form-control datepicker" id="emreceiving_date" name="emreceiving_date" tabindex="6" placeholder="Enter receiving date" <?php echo $emreadonly; ?> value="<?php echo $embroinfo['emreceiving_date']; ?>">
								</div>			  
							</div><!-- /.col -->									
						</div>
						
						<?php if(count($embroinfo) > 0){	?> 
								
						<div class="col-lg-12">
							<div class="col-lg-8">
								<div class="response"></div>	
							</div><!-- /.col -->
						</div><!-- /.col -->
						
						<div class="col-lg-12">
							<div class="col-lg-8">
								<div class="form-group">											
									<input type="button" onclick="embroreadonly();" class="btn btn-primary" name="editembro" id="editembro" tabindex="7" value="Edit" />
									<input type="button" onclick="updateEmbroInfo();" style="display:none;" class="btn btn-primary" name="updateembro" tabindex="8" id="updateembro" value="Update" />
								</div>	
							</div><!-- /.col -->
						</div><!-- /.col -->
						<?php $allembronotes = $objord->getallnotes('embro',$embroinfo['embroiderid'],$suborder); ?>
						<div class="col-lg-12 orderdiv" id="notesembro" style="max-height: 100px;">
							<?php foreach($allembronotes as $embronote){?>
							<div class="col-lg-12">
								<div class="form-group">											
										Notes	: <?php echo $embronote['embroidery_notes']; ?>
								</div>	
							</div>
							<div class="col-lg-12">
								<div class="col-lg-6">
									<div class="form-group">											
										Date	: <?php echo $embronote['createdon']; ?>													
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group">											
										Status	: <?php echo $embronote['emstatus']; ?>
									</div>
								</div>
							</div>
							<?php } ?>
						</div><!-- /.col -->
						<?php } ?>
						
						<div class="col-lg-12">
							<div class="col-lg-8">
								<div class="form-group">
								  <label for="name">Notes</label>
								  <input type="text" class="form-control" id="embroidery_notes" name="embroidery_notes" placeholder="Enter assign date" tabindex="9" value="">
								</div>	
							</div><!-- /.col -->

							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Status</label>
									<select class="form-control select2" id="emstatus" name="emstatus" style="width:100%;">
									<option value="" selected disabled>Select Status</option>
									<option value="1">Incomplete</option>
									<option value="2">Pending</option>
									<option value="3">Processed</option>
									<option value="4">Partially Shipped</option>
									<option value="5">Shipping</option>
									<option value="6">Shipped</option>
									<option value="7">Partially Returned</option>
									<option value="8">Returned</option>
									<option value="9">Cancelled</option>
									</select>
								</div>			  
							</div><!-- /.col -->									
						</div>                            
						  
					</div><!-- /.row -->
				
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<?php if(count($embroinfo) <= 0){ ?> 
					<input type="submit" class="btn btn-primary" name="saveembroidery" id="saveembroidery" tabindex="10" onclick="return validateembroidery();" value="Save" />
					<?php }else{ ?>
					<input type="button" class="btn btn-primary" name="addembronote" id="addembronote" tabindex="11" onclick="addembronotes();" value="Add Note" />
					<?php } ?>
					
				</div>
			</div>
		</form>
		</div>
	</div>
	<!-- Add embroidery -->
	
	<!-- Add Cutting -->
	<div class="modal fade" id="addCutting" tabindex="-1" role="dialog" aria-labelledby="addCuttingLabel">
		<div class="modal-dialog" role="document">
		<form action="" method="post" name="formcutting" id="formcutting">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel"><?php if(count($cuttinfo) > 0){echo 'View Cutting Agency'; $cureadonly = 'readonly="true"';$cudisable = 'disabled';}else{ echo  'Assign to Cutting Agency'; $cureadonly = '';$cudisable = ''; } ?></h4>
				</div>
				<div class="modal-body">
					<div class="row">						
						
						<div class="col-lg-12">
							<div class="col-lg-4">
								<div class="form-group">
									<label for="name">Challan No</label>											
									<input type="text" id="cuchallanno" name="cuchallanno" class="form-control" tabindex="1" <?php echo $cureadonly; ?> value="<?php echo $cuttinfo['cuchallanno']; ?>" />
									<input type="hidden" id="id" name="id" class="form-control" value="<?php echo $cuttinfo['id']; ?>" />
									<input type="hidden" id="orderno" name="orderno" class="form-control" value="<?php echo $orderno; ?>" />
									<input type="hidden" id="suborderno" name="suborderno" class="form-control" value="<?php echo $suborder; ?>" />
								</div>
							</div><!-- /.col -->

							<div class="col-lg-4">										
								<div class="form-group">
								  <label for="name">Details</label>
								  <input type="text" class="form-control" id="cudetails" name="cudetails" tabindex="2" placeholder="Enter details" <?php echo $cureadonly; ?> value="<?php echo $cuttinfo['cuchallanno']; ?>" >
								</div>									  
							</div><!-- /.col -->
							
							<div class="col-lg-4">										
								<div class="form-group">
								  <label for="name">Cutter ID</label>
								  <select class="form-control select2" id="cutterid" name="cutterid" tabindex="3" style="width:100%;"  <?php echo $cudisable; ?>>
									<option value="" selected>Select</option>
									<?php 				
									for($cui=0; $cui<count($allagent); $cui++) {
										if($allagent[$cui]['type'] == 'Cutting'){ 				 
											if($cuttinfo['cutterid'] == $allagent[$cui]['id']){$selected = 'selected';}
											echo "<option value='".$allagent[$cui]['id']."' $selected>".$allagent[$cui]['agencyname']."</option>"; 
										}
									}
									?>
									</select>
								</div>									  
							</div><!-- /.col -->
						</div>
						
						<div class="col-lg-12">
							<div class="col-lg-4">
								<div class="form-group">
								  <label for="name">Assign Date</label>
								  <input type="text" class="form-control datepicker" id="cuassign_date" tabindex="4" name="cuassign_date" placeholder="Enter assign date"  <?php echo $cureadonly; ?> value="<?php echo $cuttinfo['cuassign_date']; ?>" >
								</div>	
							</div><!-- /.col -->

							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Due Date</label>
									<input type="text" class="form-control datepicker" id="cudue_date" tabindex="5" name="cudue_date" placeholder="Enter due date"  <?php echo $cureadonly; ?> value="<?php echo $cuttinfo['cudue_date']; ?>" >
								</div>			  
							</div><!-- /.col -->
							
							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Receving Date</label>
									<input type="text" class="form-control datepicker" id="cureceiving_date" tabindex="6" name="cureceiving_date" placeholder="Enter receiving date"  <?php echo $cureadonly; ?> value="<?php echo $cuttinfo['cureceiving_date']; ?>" >
								</div>			  
							</div><!-- /.col -->									
						</div>
						
						<?php if(count($cuttinfo) > 0){	?> 
								
						<div class="col-lg-12">
							<div class="col-lg-8">
								<div class="response"></div>	
							</div><!-- /.col -->
						</div><!-- /.col -->
						
						<div class="col-lg-12">
							<div class="col-lg-8">
								<div class="form-group">											
									<input type="button" onclick="cuttingreadonly();" class="btn btn-primary" tabindex="7" name="editcutting" id="editcutting" value="Edit" />
									<input type="button" onclick="updateCuttingInfo();" style="display:none;" tabindex="8" class="btn btn-primary" name="updatecutting" id="updatecutting" value="Update" />
								</div>	
							</div><!-- /.col -->
						</div><!-- /.col -->
						<?php $allcutternotes = $objord->getallnotes('cutting',$cuttinfo['cutterid'],$suborder); ?>
						<div class="col-lg-12 orderdiv" id="notescutting" style="max-height: 100px;">
							<?php foreach($allcutternotes as $cutternote){?>
							<div class="col-lg-12">
								<div class="form-group">											
										Notes	: <?php echo $cutternote['cutting_notes']; ?>
								</div>	
							</div>
							<div class="col-lg-12">
								<div class="col-lg-6">
									<div class="form-group">											
										Date	: <?php echo $cutternote['createdon']; ?>													
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group">											
										Status	: <?php echo $cutternote['custatus']; ?>
									</div>
								</div>
							</div>
							<?php } ?>
						</div><!-- /.col -->
						<?php } ?>
						
						<div class="col-lg-12">
							<div class="col-lg-8">
								<div class="form-group">
								  <label for="name">Notes</label>
								  <input type="text" class="form-control" id="cutting_notes" name="cutting_notes" tabindex="9" placeholder="Enter assign date" value="">
								</div>	
							</div><!-- /.col -->

							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Status</label>
									<select class="form-control select2" id="custatus" name="custatus" tabindex="10" style="width:100%;">
									<option value="" selected disabled>Select Status</option>
									<option value="1">Incomplete</option>
									<option value="2">Pending</option>
									<option value="3">Processed</option>
									<option value="4">Partially Shipped</option>
									<option value="5">Shipping</option>
									<option value="6">Shipped</option>
									<option value="7">Partially Returned</option>
									<option value="8">Returned</option>
									<option value="9">Cancelled</option>
									</select>
								</div>			  
							</div><!-- /.col -->									
						</div>
						  
					</div><!-- /.row -->
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					
					<?php if(count($cuttinfo) <= 0){ ?> 
					<input type="submit" class="btn btn-primary" name="savecutting" id="savecutting" tabindex="11" onclick="return validatecutting();" value="Save" />
					<?php }else{ ?>
					<input type="button" class="btn btn-primary" name="addcuttingnote" id="addcuttingnote" tabindex="12" onclick="addcuttingnotes();" value="Add Note" />
					<?php } ?>
				</div>
			</div>
		</form>
		</div>
	</div>
	<!-- Add Cutter -->
	
	<!-- Add Tailor -->
	<div class="modal fade" id="addTailor" tabindex="-1" role="dialog" aria-labelledby="addTailorLabel">
		<div class="modal-dialog" role="document">
		<form action="" method="post" name="formTailor" id="formTailor">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel"><?php if(count($tailorinfo) > 0){echo 'View Tailor Agency'; $tareadonly = 'readonly="true"';$tadisable = 'disabled';}else{ echo  'Assign to Tailor Agency'; $tareadonly = '';$tadisable = '';} ?></h4>
				</div>
				<div class="modal-body">
					<div class="row">
						
						<div class="col-lg-12">
							<div class="col-lg-4">
								<div class="form-group">
									<label for="name">Challan No</label>											
									<input type="text" id="tachallanno" name="tachallanno" class="form-control" tabindex="1" <?php echo $tareadonly; ?> value="<?php echo $tailorinfo['tachallanno']; ?>"  />
									<input type="hidden" id="id" name="id" class="form-control" value="<?php echo $tailorinfo['id']; ?>" />
									<input type="hidden" id="orderno" name="orderno" class="form-control" value="<?php echo $orderno; ?>" />
									<input type="hidden" id="suborderno" name="suborderno" class="form-control" value="<?php echo $suborder; ?>" />
								</div>
							</div><!-- /.col -->

							<div class="col-lg-4">										
								<div class="form-group">
								  <label for="name">Details</label>
								  <input type="text" class="form-control" id="tadetails" name="tadetails" tabindex="2" placeholder="Enter details" <?php echo $tareadonly; ?> value="<?php echo $tailorinfo['tadetails']; ?>" >
								</div>									  
							</div><!-- /.col -->
							
							<div class="col-lg-4">										
								<div class="form-group">
								  <label for="name">Tailor ID</label>
								  <select class="form-control select2" id="tailorid" name="tailorid" tabindex="3" <?php echo $tadisable; ?> style="width:100%;">
									<option value="" selected>Select</option>
									<?php 				
									for($tai=0; $tai<count($allagent); $tai++) {
										if($allagent[$tai]['type'] == 'Tailor'){ 				 
											if($tailorinfo['tailorid'] == $allagent[$tai]['id']){$selected = 'selected';}
											echo "<option value='".$allagent[$tai]['id']."' $selected>".$allagent[$tai]['agencyname']."</option>"; 
										}
									}
									?>
									</select>
								</div>									  
							</div><!-- /.col -->
						</div>
						
						<div class="col-lg-12">
							<div class="col-lg-4">
								<div class="form-group">
								  <label for="name">Assign Date</label>
								  <input type="text" class="form-control datepicker" id="taassigndate" tabindex="4" name="taassigndate" placeholder="Enter assign date"  <?php echo $tareadonly; ?> value="<?php echo $tailorinfo['taassigndate']; ?>" >
								</div>	
							</div><!-- /.col -->

							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Due Date</label>
									<input type="text" class="form-control datepicker" id="taduedate" tabindex="5" name="taduedate" placeholder="Enter due date"  <?php echo $tareadonly; ?> value="<?php echo $tailorinfo['taduedate']; ?>" >
								</div>			  
							</div><!-- /.col -->
							
							<div class="col-lg-4">
								<div class="form-group">
									<label for="name">Receiving Date</label>
									<input type="text" class="form-control datepicker" id="tareceivingdate" tabindex="6" name="tareceivingdate" placeholder="Enter receiving date"  <?php echo $tareadonly; ?> value="<?php echo $tailorinfo['tareceivingdate']; ?>" >
								</div>			  
							</div><!-- /.col -->									
						</div>
						
						<?php if(count($tailorinfo) > 0){	?> 
								
						<div class="col-lg-12">
							<div class="col-lg-8">
								<div class="response"></div>	
							</div><!-- /.col -->
						</div><!-- /.col -->
						
						<div class="col-lg-12">
							<div class="col-lg-8">
								<div class="form-group">											
									<input type="button" onclick="tailorreadonly();" class="btn btn-primary" tabindex="7" name="edittailor" id="edittailor" value="Edit" />
									<input type="button" onclick="updateTailorInfo();" style="display:none;" tabindex="8" class="btn btn-primary" name="updatetailor" id="updatetailor" value="Update" />
								</div>	
							</div><!-- /.col -->
						</div><!-- /.col -->
						<?php $alltailornotes = $objord->getallnotes('tailor',$tailorinfo['tailorid'],$suborder); ?>
						<div class="col-lg-12 orderdiv" id="notestailor" style="max-height: 100px;">
							<?php foreach($alltailornotes as $tailornote){?>
							<div class="col-lg-12">
								<div class="form-group">											
										Notes	: <?php echo $tailornote['tailor_notes']; ?>
								</div>	
							</div>
							<div class="col-lg-12">
								<div class="col-lg-6">
									<div class="form-group">											
										Date	: <?php echo $tailornote['createdon']; ?>													
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group">											
										Status	: <?php echo $tailornote['tastatus']; ?>
									</div>
								</div>
							</div>
							<?php } ?>
						</div><!-- /.col -->
						<?php } ?>
						
						<div class="col-lg-12">
							<div class="col-lg-8">
								<div class="form-group">
								  <label for="name">Notes</label>
								  <input type="text" class="form-control" id="tailor_notes" name="tailor_notes" placeholder="Enter notes" value="">
								</div>	
							</div><!-- /.col -->

							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Status</label>
									<select class="form-control select2" id="tastatus" name="tastatus" style="width:100%;">
									<option value="" selected disabled>Select Status</option>
									<option value="1">Incomplete</option>
									<option value="2">Pending</option>
									<option value="3">Processed</option>
									<option value="4">Partially Shipped</option>
									<option value="5">Shipping</option>
									<option value="6">Shipped</option>
									<option value="7">Partially Returned</option>
									<option value="8">Returned</option>
									<option value="9">Cancelled</option>
									</select>
								</div>			  
							</div><!-- /.col -->									
						</div>
						  
					</div><!-- /.row -->
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					
					<?php if(count($tailorinfo) <= 0){ ?> 
					<input type="submit" class="btn btn-primary" name="savetailor" id="savetailor" onclick="return validatetailor();" value="Save" />
					<?php }else{ ?>
					<input type="button" class="btn btn-primary" name="addtailornote" id="addtailornote" onclick="addtailornotes();" value="Add Note" />
					<?php } ?>
				</div>
			</div>
		</form>
		</div>
	</div>
	<!-- Add Tailor -->
	
	<!-- Add store management -->
	<div class="modal fade" id="addStore" tabindex="-1" role="dialog" aria-labelledby="addStoreLabel">
		<div class="modal-dialog" role="document">
		<form action="" method="post" name="formStore" id="formStore">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title" id="myModalLabel"><?php if(count($storeinfo) > 0){echo 'View Store management'; $streadonly = 'readonly="true"';}else{ echo  'Assign to Store management'; $streadonly = '';} ?></h4>
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="col-lg-12">
							<div class="col-lg-6">
								<div class="form-group">
									<label for="name">Order No</label>
									<input type="hidden" id="id" name="id" class="form-control" value="<?php echo $storeinfo['id']; ?>" />
									<input type="text" id="orderno" readonly name="orderno" class="form-control" value="<?php echo $orderno; ?>" />
									
								</div>	
							</div><!-- /.col -->

							<div class="col-lg-6">										
								<div class="form-group">
									<label for="name">Sub-order No</label>
									<input type="text" id="suborderno" readonly name="suborderno" class="form-control" value="<?php echo $suborder; ?>" />
								</div>			  
							</div><!-- /.col -->
							
						</div>
						
						<div class="col-lg-12">
							<div class="col-lg-6">
								<div class="form-group">
									<label for="name">Store in date</label>
									<input type="text" class="form-control datepicker" id="store_in_date" name="store_in_date" placeholder="Enter assign date"  <?php echo $streadonly; ?> value="<?php echo $storeinfo['store_in_date']; ?>" >
								</div>	
							</div><!-- /.col -->

							<div class="col-lg-6">										
								<div class="form-group">
									<label for="name">Store out date</label>
									<input type="text" class="form-control datepicker" id="store_out_date" name="store_out_date" placeholder="Enter due date"  <?php echo $streadonly; ?> value="<?php echo $storeinfo['store_out_date']; ?>" >
								</div>			  
							</div><!-- /.col -->
							
						</div>
						
						<?php if(count($storeinfo) > 0){	?> 
								
						<div class="col-lg-12">
							<div class="col-lg-8">
								<div class="response"></div>	
							</div><!-- /.col -->
						</div><!-- /.col -->
						
						<div class="col-lg-12">
							<div class="col-lg-8">
								<div class="form-group">											
									<input type="button" onclick="storereadonly();" class="btn btn-primary" name="editstore" id="editstore" value="Edit" />
									<input type="button" onclick="updatestoreInfo();" style="display:none;" class="btn btn-primary" name="updatestore" id="updatestore" value="Update" />
								</div>	
							</div><!-- /.col -->
						</div><!-- /.col -->
						<?php $allStorenotes = $objord->getallnotes('store','',$suborder); ?>
						<div class="col-lg-12 orderdiv" id="notesstore" style="max-height: 100px;">
							<?php foreach($allStorenotes as $Storenote){?>
							<div class="col-lg-12">
								<div class="col-lg-12">
									<div class="form-group">											
										Notes	: <?php echo $Storenote['store_notes']; ?>
									</div>	
								</div>	
							</div>
							<div class="col-lg-12">
								<div class="col-lg-6">
									<div class="form-group">											
										Date	: <?php echo $Storenote['createdon']; ?>													
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group">											
										Status	: <?php echo $Storenote['ststatus']; ?>
									</div>
								</div>
							</div>
							<?php } ?>
						</div><!-- /.col -->
						<?php } ?>
						
						<div class="col-lg-12">
							<div class="col-lg-8">
								<div class="form-group">
								  <label for="name">Notes</label>
								  <input type="text" class="form-control" id="store_notes" name="store_notes" placeholder="Enter notes" value="">
								</div>	
							</div><!-- /.col -->

							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Status</label>
									<select class="form-control select2" id="ststatus" name="ststatus" style="width:100%;">
									<option value="" selected disabled>Select Status</option>
									<option value="1">Incomplete</option>
									<option value="2">Pending</option>
									<option value="3">Processed</option>
									<option value="4">Partially Shipped</option>
									<option value="5">Shipping</option>
									<option value="6">Shipped</option>
									<option value="7">Partially Returned</option>
									<option value="8">Returned</option>
									<option value="9">Cancelled</option>
									</select>
								</div>			  
							</div><!-- /.col -->									
						</div>
						  
					</div><!-- /.row -->
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					
					<?php if(count($storeinfo) <= 0){ ?> 
					<input type="submit" class="btn btn-primary" name="saveStore" id="saveStore" onclick="return validatestore();" value="Save" />
					<?php }else{ ?>
					<input type="button" class="btn btn-primary" name="addStorenote" id="addStorenote" onclick="addstorenotes();" value="Add Note" />
					<?php } ?>
				</div>
			</div>
		</form>
		</div>
	</div>
	<!-- Add Store -->