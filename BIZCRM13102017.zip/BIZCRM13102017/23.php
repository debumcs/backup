<?php	
												for($fgi=0; $fgi<count($allfabricgroup); $fgi++){
													echo "<option value='".$allfabricgroup[$fgi]['id']."'>".$allfabricgroup[$fgi]['fabricname']."</option>";
												}