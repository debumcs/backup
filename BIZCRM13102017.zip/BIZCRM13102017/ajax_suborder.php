<?php 
require_once('class/class.customer.php');
$objCus = new Customer();

require_once('class/class.orderdetails.php');
$objord = new Orderdetails();

require_once('class/class.fabric.php');
$objfabric = new Fabric();
$allfabric = $objfabric->getAll();
$allfabricgroup = $objfabric->getAllgroup();

require_once('class/class.stylemaster.php');
$objstyle = new Stylemaster();
$allstyle = $objstyle->getAll();
$allCusStyle 	= $objstyle->getAllCustomized();

require_once('class/class.salesman.php');
$objsalesman = new Salesman();
$allsalesman = $objsalesman->getAll();

require_once('class/class.statusmaster.php');
require_once('class/class.agencymaster.php');

require_once('class/class.items.php');
$objitem = new item();

if($_REQUEST['task'] == 'addsubordernotes')
{
	$data = $objitem->addsubordernotes();
?>
<table class="table table-bordered table-striped">
	<thead class="abcd33">
		<tr>
			<tr>
			<th style="width: 12%;">Order No</th>
			<th style="width: 13%;">Sub-Order</th>
			<th style="width: 20%;">Agency</th>
			<th style="width: 10%;">Date</th>
			<th style="width: 20%;">Status</th>
			<th style="width: 25%;">Remark</th>
		</tr>
		</tr>
	</thead>
	<tbody class="abcd22">
<?php if(count($data) >0){ 
	foreach($data as $dat){
?>
		<tr>
			<td><?php echo $dat['orderno']; ?></td>
			<td><?php echo $dat['suborderno']; ?></td>
			<td><?php echo $dat['agencyname']; ?></td>
			<td><?php echo $dat['status_date']; ?></td>
			<td><?php echo $dat['statusname']; ?></td>
			<td><?php echo $dat['remark']; ?></td>
		</tr>
	<?php }} ?>
	</tbody>
</table>
<?php 	
	exit;
}

if($_REQUEST['task'] == 'getSubOrderNotes')
{
	$suborder_id = $_REQUEST['suborder_id'];
	$data = $objitem->getSubOrderNotes($suborder_id);
?>

<table class="table table-bordered table-striped">
	<thead class="abcd33">
		<tr>
			<tr>
			<th style="width: 12%;">Order No</th>
			<th style="width: 13%;">Sub-Order</th>
			<th style="width: 20%;">Agency</th>
			<th style="width: 10%;">Date</th>
			<th style="width: 20%;">Status</th>
			<th style="width: 25%;">Remark</th>
		</tr>
		</tr>
	</thead>
	<tbody class="abcd22">
<?php if(count($data) >0){ 
	foreach($data as $dat){
?>
		<tr>
			<td><?php echo $dat['orderno']; ?></td>
			<td><?php echo $dat['suborderno']; ?></td>
			<td><?php echo $dat['agencyname']; ?></td>
			<td><?php echo $dat['status_date']; ?></td>
			<td><?php echo $dat['statusname']; ?></td>
			<td><?php echo $dat['remark']; ?></td>
		</tr>
	<?php }} ?>
	</tbody>
</table>
<?php 	
	exit;	
}

if($_REQUEST['task'] == 'getOrderNotes')
{
	$orderno = $_REQUEST['orderno'];
	$data = $objitem->getOrderNotes($orderno);
?>

<table class="table table-bordered table-striped">
	<thead class="abcd33">
		<tr>
			<tr>
			<th style="width: 12%;">Order No</th>
			<th style="width: 13%;">Sub-Order</th>
			<th style="width: 20%;">Agency</th>
			<th style="width: 10%;">Date</th>
			<th style="width: 20%;">Status</th>
			<th style="width: 25%;">Remark</th>
		</tr>
		</tr>
	</thead>
	<tbody class="abcd22">
<?php if(count($data) >0){ 
	foreach($data as $dat){
?>
		<tr>
			<td><?php echo $dat['orderno']; ?></td>
			<td><?php echo $dat['suborderno']; ?></td>
			<td><?php echo $dat['agencyname']; ?></td>
			<td><?php echo $dat['status_date']; ?></td>
			<td><?php echo $dat['statusname']; ?></td>
			<td><?php echo $dat['remark']; ?></td>
		</tr>
	<?php }} ?>
	</tbody>
</table>
<?php 	
	exit;	
}

if($_REQUEST['task'] == 'addOrdernotes')
{
	$data = $objitem->addOrdernotes();
?>
<table class="table table-bordered table-striped">
	<thead class="abcd33">
		<tr>
			<tr>
			<th style="width: 12%;">Order No</th>
			<th style="width: 13%;">Sub-Order</th>
			<th style="width: 20%;">Agency</th>
			<th style="width: 10%;">Date</th>
			<th style="width: 20%;">Status</th>
			<th style="width: 25%;">Remark</th>
		</tr>
		</tr>
	</thead>
	<tbody class="abcd22">
<?php if(count($data) >0){ 
	foreach($data as $dat){
?>
		<tr>
			<td><?php echo $dat['orderno']; ?></td>
			<td><?php echo $dat['suborderno']; ?></td>
			<td><?php echo $dat['agencyname']; ?></td>
			<td><?php echo $dat['status_date']; ?></td>
			<td><?php echo $dat['statusname']; ?></td>
			<td><?php echo $dat['remark']; ?></td>
		</tr>
	<?php }} ?>
	</tbody>
</table>
<?php 	
	exit;
}

if($_REQUEST['task'] == 'GETORDERNO')
{
	$ordertype 	= $_POST['ordertype'];
	$orderid = $objord->getOrderID();
	$orderno = $ordertype.$orderid['orderid'];
	echo $orderno;
	exit;
}

if($_POST['AgencyEmailID']=='AgencyEmailID')
{
	$emailid 	= $_POST['emailid'];
	$objagency 	= new Agencymaster();
	$data 		= $objagency->checkAgencyEmailID($emailid);
	
	if($data['total'] < 1){
		echo "1";
	}else{
		echo "0";
	}
	exit;
}

if($_POST['checkSalesPersonID']=='checkSalesPersonID')
{
	$person_id 	= $_POST['person_id'];
	
	$data 		= $objsalesman->checkSalePersonCode($person_id);
	
	if($data['total'] < 1){
		echo "1";
	}else{
		echo "0";
	}
	exit;
}

if($_POST['checkSalesPersonID']=='checkSalesPersonID')
{
	$person_id 	= $_POST['person_id'];
	
	$data 		= $objsalesman->checkSalePersonCode($person_id);
	
	if($data['total'] < 1){
		echo "1";
	}else{
		echo "0";
	}
	exit;
}

if(isset($_POST['Req']) && $_POST['Req']=="classfabric")
{	
	$fabrics = $_POST['fabrics'];
	$fabricdata = $objfabric->getSelectedFabric($fabrics);
	$classfabric = '';
	
	$classfabric .= '<tr>
		<td valign="top">
		<select class="form-control form-control-sm classfabric" id="fabricgroupid'.$_POST['rn'].'" name="fabricgroup[]" onchange="get_fabric('.$_POST['rn'].',this.value);">
		<option selected value="">Select fabric group</option>';
						
		for($fgi=0; $fgi<count($allfabricgroup); $fgi++){
			$classfabric .= "<option value='".$allfabricgroup[$fgi]['id']."'>".$allfabricgroup[$fgi]['groupname']."</option>";
		}
		
		$classfabric .= '</select>
		</td>
		<td valign="top">
		<select class="form-control form-control-sm classfabric" id="fabricid'.$_POST['rn'].'" name="fabric[]" onchange="get_fabric_units('.$_POST['rn'].',this.value);"></select>
		</td>
		<td colspan="3" id="unitsin'.$_POST['rn'].'">
			<div class="col-lg-12">	
				<div class="col-lg-4"><input type="text" class="form-control form-control-sm" onKeyPress="return isDecimalNumber(event,this);" id="unitsvalue'.$_POST['rn'].'" name="unitsvalue[]" value="" /></div>
				<div class="col-lg-4"></div>
				<div class="col-lg-4"></div>
			</div>
		</td>												
	</tr>';
	echo $classfabric;
	exit;
}


if($_REQUEST['task'] == 'getFabrics')
{
	$indexid = $_REQUEST['indexid'];
	$fabricgroupid = $_REQUEST['fabricgroupid'];
	$datafg = $objfabric->getFabricByGroupID($fabricgroupid);
	$fabricdatabygroup = '<option selected value="">Select Fabric ID</option>';
	
	for($fbi=0; $fbi<count($datafg); $fbi++){
		$fabricdatabygroup .= "<option value='".$datafg[$fbi]['id']."'>".$datafg[$fbi]['fabricid']."</option>";
	}
	echo $fabricdatabygroup;
	exit;		
}

if($_REQUEST['task'] == 'getFabricUnits')
{
	$indexid = $_REQUEST['indexid'];
	$fabricid = $_REQUEST['fabricid'];
	$getFabricUnits = '';
	$data = $objfabric->getById($fabricid);
	$getFabricUnits .='<div class="col-lg-12">	
							<div class="col-lg-4"><input type="text" class="form-control form-control-sm" onKeyPress="return isDecimalNumber(event,this);" id="unitsvalue'.$indexid.'" name="unitsvalue[]" value="" /><input type="hidden" name="units[]" id="units_'.$indexid.'" value="'.$data['units'].'" />(Units in '.$data['units'].')</div>
							<div class="col-lg-4">'.$data['fabricname'].'</div>
							<div class="col-lg-4"><img src="'.$data['fabric_image'].'" width="150"></div>
						</div>';
	echo $getFabricUnits;
	exit;		
}


if(isset($_POST['task']) && $_POST['task'] == 'moveToRegular')
{
	$id 		= $_REQUEST['id'];
	$success 	= $objord->moveToRegularStyle($id);
	if($success){
		echo 'OK';
	}else{
		echo 'Error';
	}
	exit;
}

if (isset($_POST["task"]) and ($_POST["task"] == 'fileupload')) {
	$file = $_FILES['image'];
	
	$allowedExtensions = ["gif", "jpeg", "jpg", "png", "svg"];
	$fileExtension = explode(".", $file["name"]);
	
	$extension = end($fileExtension);
	
	$types = ['image/gif', 'image/png', 'image/x-png', 'image/pjpeg', 'image/jpg', 'image/jpeg','image/svg+xml'];
	if(in_array(strtolower($file['type']), $types) && in_array(strtolower($extension), $allowedExtensions) && !$file["error"] > 0)
	{ 
		if(move_uploaded_file($file["tmp_name"], 'styleimage/'.$file['name'])){
			echo '<img src="styleimage/'.$file['name'].'" width="200" />';
			echo '<input type="hidden" name="imagename_hidden" id="imagename_hidden" value="'.$file['name'].'" />
				<input type="hidden" name="imagelocation_hidden" id="imagelocation_hidden" value="styleimage/'.$file['name'].'" />';
		}else{
			echo 'Unable to move image. Is folder writable?';    
		}
	}else{    
		echo 'Please upload only png, jpg images';
	}
}

if(isset($_POST['task']) && $_POST['task'] == 'getCustomizedSelectedStyle'){
	$stylecode 	= $_REQUEST['stylecode'];
	$data = $objstyle->getCustomizedStyleDetails($stylecode);
	
?>
<fieldset class="fsStyle">
	<legend class="legendStyle">
		<a data-toggle="collapse" data-target="#demo" href="#">Selected Style Details <i class="fa fa-sort" aria-hidden="true"></i></a>
	</legend>
<div class="row collapse in" id="demo">
	<div class="row ">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Style Code</label><?php echo $MANDATORY; ?>
				<input type="text" class="form-control" readonly value="<?php echo $data['style_code']; ?>">
			</div>
		</div>
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Description</label><?php echo $MANDATORY; ?>
				<input type="text" class="form-control" readonly value="<?php echo $data['description']; ?>">
			</div>
		</div>
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Style Group Code</label>
				<input type="text" class="form-control" readonly value="<?php echo $data['style_group_code']; ?>">
			</div>
		</div>
	</div><!-- /.col -->
	
	<div class="row">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Designer Code</label>
				<input type="text" class="form-control" readonly value="<?php echo $data['designer_code']; ?>">
			</div>
		</div>
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Cost Price</label>
				<input type="text" class="form-control" readonly value="<?php echo $data['cost_price']; ?>" >
			</div>
		</div>
		
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Recommended Selling Price</label>
				<input type="text" class="form-control"  readonly value="<?php echo $data['selling_price']; ?>">
			</div>
		</div>
		
	</div><!-- /.col -->
	<div class="row">
		<div class="col-lg-6">
			<div class="form-group">
				<label for="name">Picture</label><?php echo $MANDATORY; ?>&nbsp;
				<img src="<?php echo $data['imagelocation']; ?>" width="150"/>
			</div>
		</div>
	</div><!-- /.col -->
</div>
</fieldset>
<?php
	exit;
}

if(isset($_POST['task']) && $_POST['task'] == 'getSelectedStyle'){
	$stylecode 	= $_REQUEST['stylecode'];
	$data = $objstyle->getStyleDetails($stylecode);
	
?>
<fieldset class="fsStyle">
	<legend class="legendStyle">
		<a data-toggle="collapse" data-target="#demo" href="#">Selected Style Details <i class="fa fa-sort" aria-hidden="true"></i></a>
	</legend>
<div class="row collapse in" id="demo">
	<div class="row ">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Style Code</label><?php echo $MANDATORY; ?>
				<input type="text" class="form-control" readonly value="<?php echo $data['style_code']; ?>">
			</div>
		</div>
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Description</label><?php echo $MANDATORY; ?>
				<input type="text" class="form-control" readonly value="<?php echo $data['description']; ?>">
			</div>
		</div>
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Style Group</label>
				<input type="text" class="form-control" readonly value="<?php echo $data['groupname']; ?>">
			</div>
		</div>
	</div><!-- /.col -->
	
	<div class="row">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Designer Code</label>
				<input type="text" class="form-control" readonly value="<?php echo $data['designer_code']; ?>">
			</div>
		</div>
		
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Recommended Selling Price</label>
				<input type="text" class="form-control"  readonly value="<?php echo $data['selling_price']; ?>">
			</div>
		</div>
		
	</div><!-- /.col -->
	<div class="row">
		<div class="col-lg-6">
			<div class="form-group">
				<label for="name">Picture</label><?php echo $MANDATORY; ?>&nbsp;
				<img src="<?php echo $data['imagelocation']; ?>" width="150"/>
			</div>
		</div>
	</div><!-- /.col -->
</div>
</fieldset>
<?php
	exit;
}

if(isset($_POST['task']) && $_POST['task'] == 'getAutoNumber')
{
	$assignstatus 	= $_POST['assignstatus'];
	$agencyid 		= $_POST['agencyid'];
	if($agencyid != ''){
		$objStatus 		= new Statusmaster();
		$objagency 		= new Agencymaster();
		
		$checkautochallan = $objStatus->getById($assignstatus);
		
		if($checkautochallan['autochallan'] == 'Yes'){
			$agencyname = $objagency->getById($agencyid);
			$arr = $objagency->initials($agencyname['agencyname']);

			$name = preg_replace('/[^A-Za-z0-9\-]/', '', $arr);
			
			$lastid = $objitem->getLastIDSuborderItems();
			$challanno = $name.str_pad((intval($lastid['id']) + 1), 5, "0", STR_PAD_LEFT);
			echo $challanno;
		}else{
			echo 'No';
		}
	}else{
		echo 'No';
	}
	exit;
}

if(isset($_POST['task']) && $_POST['task'] == 'delOrderbyno')
{
	$order_no = $_POST['order_no'];
	$objord->deleteOrder($order_no);
	exit();
}

if($_REQUEST['task'] == 'getfabricdetails')
{
	$fabricid = $_REQUEST['fabricid'];
	$data = $objfabric->getById($fabricid);
?>
<div class="row">							
	<div class="col-lg-12">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Fabric Name</label>
			</div>
		</div><!-- /.col -->
		
		<div class="col-lg-8">
			<div class="form-group">
				<?php echo $data['fabricname']; ?>
			</div>
		</div><!-- /.col -->
	</div>
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Description</label>
			</div>									  
		</div><!-- /.col -->
		
		<div class="col-lg-8">							
			<div class="form-group">
				<?php echo $data['description'];?>
			</div>									  
		</div><!-- /.col -->		
	</div>
	<div class="col-lg-12">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Preferred Vendor Name</label>
			</div>	
		</div><!-- /.col -->
		
		<div class="col-lg-8">
			<div class="form-group">
				<?php echo $data['preferred_vendor_name'];?>
			</div>	
		</div><!-- /.col -->
	</div>
	
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Last Price</label>
			</div>
		</div><!-- /.col -->
		
		<div class="col-lg-8">										
			<div class="form-group">
				<?php echo $data['last_price'];?>
			</div>
		</div><!-- /.col -->		
	</div>
	
	<div class="col-lg-12">
		<div class="col-lg-4">
			<div class="form-group">
			<label for="name">Fabric Type</label>
			</div>	
		</div><!-- /.col -->		
		<div class="col-lg-8">
			<div class="form-group">
			<?php echo $data['fabric_type'];?>
			</div>	
		</div><!-- /.col -->
	</div>
			
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Image</label>
			</div>
		</div><!-- /.col -->
		<div class="col-lg-8">										
			<div class="form-group">
				<img src="<?php echo $data['fabric_image'];?>" width="100">
			</div>
		</div><!-- /.col -->
	</div>
	
</div><!-- /.row -->
<?php
	exit;	
}

if($_REQUEST['task'] == 'styledetails')
{
	$stylecode = $_REQUEST['stylecode'];
	$data = $objstyle->getStyleDetails($stylecode);
?>
<div class="row">							
	<div class="col-lg-12">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Style Code</label>
			</div>
		</div><!-- /.col -->
		
		<div class="col-lg-8">
			<div class="form-group">
				<?php echo $data['style_code']; ?>
			</div>
		</div><!-- /.col -->
	</div>
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Description</label>
			</div>									  
		</div><!-- /.col -->
		
		<div class="col-lg-8">							
			<div class="form-group">
				<?php echo $data['description'];?>
			</div>									  
		</div><!-- /.col -->		
	</div>
	<div class="col-lg-12">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Style Group Code</label>
			</div>	
		</div><!-- /.col -->
		
		<div class="col-lg-8">
			<div class="form-group">
				<?php echo $data['style_group_code'];?>
			</div>	
		</div><!-- /.col -->
	</div>
	
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Designer Code</label>
			</div>
		</div><!-- /.col -->
		
		<div class="col-lg-8">										
			<div class="form-group">
				<?php echo $data['designer_code'];?>
			</div>
		</div><!-- /.col -->		
	</div>
	
	<div class="col-lg-12">
		<div class="col-lg-4">
			<div class="form-group">
			<label for="name">Creation Date</label>
			</div>	
		</div><!-- /.col -->		
		<div class="col-lg-8">
			<div class="form-group">
			<?php echo $objstyle->date_ymd_dmy($data['creation_date']); ?>
			</div>	
		</div><!-- /.col -->
	</div>
			
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Price</label>
			</div>			  
		</div><!-- /.col -->
		
		<div class="col-lg-8">										
			<div class="form-group">
				<?php echo $data['selling_price'];?>
			</div>			  
		</div><!-- /.col -->
	</div>
			
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Image</label>
			</div>
		</div><!-- /.col -->
		<div class="col-lg-8">										
			<div class="form-group">
				<img src="<?php echo $data['imagelocation'];?>" width="100">
			</div>
		</div><!-- /.col -->
	</div>
	
</div><!-- /.row -->
<?php
	exit;	
}

if($_REQUEST['task'] == 'getRecomandedPrice')
{
	$stylecode 	= $_REQUEST['stylecode'];
	$RecomandedPrice = $objord->getRecomandedPrice($stylecode);
	echo $RecomandedPrice;
	exit;		
}

if($_REQUEST['task'] == 'getCustomizedRecomandedPrice')
{
	$stylecode 	= $_REQUEST['stylecode'];
	$RecomandedPrice = $objord->getCustomizedRecomandedPrice($stylecode);
	echo $RecomandedPrice;
	exit;		
}

if($_REQUEST['task'] == 'getAgencyByStatus')
{
	$statusid 	= $_REQUEST['statusid'];
	$objagency = new Agencymaster();
	
	$allAgencyByStatus = $objagency->getAgencyByStatus($statusid);
	echo '<select id="agencyid" class="form-control input-sm" name="agencyid" onchange="checkchallanno();">';
	echo '<option selected value="">Select Agency</option>';
	for($i=0; $i<count($allAgencyByStatus); $i++){ 
?>
	<option value="<?php echo $allAgencyByStatus[$i]['id']; ?>"><?php echo $allAgencyByStatus[$i]['agencyname']; ?></option>
<?php }
	echo '</select>';
	exit;		
}

if($_REQUEST['task'] == 'allagencytype')
{
	$agencyVal 	= $_REQUEST['agencyVal'];
	$typeVal 	= $_REQUEST['typeVal'];
	$id 		= $_REQUEST['id'];
	$objagency = new Agencymaster();
	
	$allagency = $objagency->getAllAgencyByType($agencyVal,$typeVal);
	$allmappedstatus = $objagency->allmappedstatus($id);
	for($i=0; $i<count($allagency); $i++){ 
?>
<tr>
	<td><input type="checkbox" style="display:block;" <?php if (in_array($allagency[$i]['id'], $allmappedstatus)){echo "checked";} ?> name="mappinglist[]" class="checkbox" value="<?php print $allagency[$i]['id'];?>"/></td>
	<td><?php print $allagency[$i]['agencyname']; ?></td>
</tr>
<?php } 	
	exit;		
}

if($_REQUEST['task'] == 'getOrderbyno')
{
	$order_id = $_REQUEST['order_id'];
	$data = $objord->getorderDetailByorderID($order_id);
	$orderpayment = $objord->get_order_payemt_amount($order_id);
?>
<div class="row">							
	<div class="col-lg-12">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Order No</label><br/>
				<?php echo $data['orderno']; ?>
			</div>
		</div><!-- /.col -->
		
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Customer ID</label><br/>
				<?php echo $data['customer_id'];?>
			</div>									  
		</div><!-- /.col -->
		
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Order Details</label><br/>
				<?php echo $data['order_detail'];?>
			</div>	
		</div><!-- /.col -->
	</div>
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Quantity</label><br/>
				<?php echo $data['quantity'];?>
			</div>
		</div><!-- /.col -->
		
		<div class="col-lg-4">
			<div class="form-group">
			<label for="name">Order Date</label><br/>
			<?php echo $objord->date_ymd_dmy($data['order_date']);?>
			</div>	
		</div><!-- /.col -->

		<div class="col-lg-4">
			<div class="form-group">
			<label for="name">Sale Person</label><br/>
			<?php echo $data['sale_person'];?>
			</div>	
		</div><!-- /.col -->
	</div>	
			
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Bill Number</label><br/>
				<?php echo $data['billno'];?>
			</div>			  
		</div><!-- /.col -->
		
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Alt Order No</label><br/>
				<?php echo $data['alt_order_no'];?>
			</div>			  
		</div><!-- /.col -->
		
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Order Status</label><br/>
				<?php echo $data['orderstatus'];?>
			</div>
		</div><!-- /.col -->
		
	</div>
			
	<div class="col-lg-12">									
	
		<div class="col-lg-4">										
			<div class="form-group">
			  <label for="name">Gross Sale Amount</label><br/>
			  <a href="#"><?php echo $orderpayment['original_amount']; ?></a>
			</div>								  
		</div><!-- /.col -->

		<div class="col-lg-4">										
			<div class="form-group">
			  <label for="name">Net Sale amount</label><br/>
			  <a href="#"><?php echo $orderpayment['sale_amount']; ?></a>
			</div>									  
		</div><!-- /.col -->
		<div class="col-lg-4">
			<div class="form-group">
			  <label for="name">Amount received </label><br/>
			  <a href="#"><?php echo $orderpayment['received_amount']; ?></a>
			</div>
		</div>
		
	</div>
	
</div><!-- /.row -->
<?php
	exit;	
}


if($_REQUEST['task'] == 'updatesuborderrow')
{
	$suborderno = $_REQUEST['suborderno'];
	$alldata = $objord->getSuborderById($suborderno);	
?>							
	<td><?php echo $alldata['suborderno']; ?></td>
	<td><?php echo $alldata['original_amount']; ?></td>
	<td><?php echo $alldata['discount_amount']; ?></td>
	<td><?php echo $alldata['sale_amount']; ?></td>
	<td><a href="#" data-toggle="modal" data-target="#editsuborder" onclick='editsuborder("<?php print $alldata['suborderno']; ?>")' >Edit</a>&nbsp;|&nbsp;<a href="suborder.php?action=editsub&orderno=<?php print $alldata['orderno'];?>&suborder=<?php echo $alldata['suborderno']; ?>">View Suborder Details</a>&nbsp;|&nbsp;<a href="#" data-toggle="modal" data-target="#subOrderNotes" onclick='getSubOrderNotes("<?php print $alldata['suborderno']; ?>")'>Sub Order Notes</a></td>
<?php	
	exit;		
}

if($_REQUEST['task'] == 'UpdateSuborder')
{
	echo $objord->updatesuborder();
	exit();
}

if($_REQUEST['task'] == 'EditSuborder')
{
	$objStatus 	= new Statusmaster();
	$allStatus 	= $objStatus->getAll();
	
	$suborderno = $_REQUEST['suborderno'];	
	$data = $objord->getSuborderById($suborderno);
	/*echo '<pre>';
	print_r($data);
	echo '</pre>';die();*/
?>
		<div class="modal-body">
			
					<div class="row"  style="clear: both;">
						<fieldset class="fsStyle">
							<legend class="legendStyle">
								<a href="#">Style Selection</a>
							</legend>
							<input type="hidden" id="editsuborderno" name="editsuborderno" value="<?php echo $data['suborderno']; ?>" />
							<input type="hidden" id="editorderno" name="editorderno" value="<?php echo $data['orderno'];?>" />
							<div class="col-lg-4">
								<div class="form-group">
									<label for="name">Style Ref Type</label>
									<div style="width:100%;">
									<input type="radio" id="edit_existing_type" <?php if($data['style_ref_type'] == '1'){echo 'checked';} ?> name="edit_style_ref_type" value="1" />Existing
									<input type="radio" id="edit_customized_type" <?php if($data['style_ref_type'] == '0'){echo 'checked';} ?> name="edit_style_ref_type" value="0" />Customized
									</div>
								</div>	
							</div><!-- /.col -->
							
							<div style="width:100%;">
								<div class="col-lg-4" id="existing_type_ref" style="display:block;">
									<div class="form-group">
										<label for="name">Style Ref</label>
										<select id="edit_style_ref" tabindex="2" class="form-control" name="edit_style_ref" onchange="getRecomandedPrice(this.value);">
										<option value="" selected="selected">Select Style Ref</option>
										<?php for($si = 0; $si < count($allstyle); $si++){ 
										if($data['style_ref'] == $allstyle[$si]['style_code']){$selected = 'selected';}else{$selected = '';}
										?>										
										<option value="<?php echo $allstyle[$si]['style_code']; ?>" <?php echo $selected;?>><?php echo $allstyle[$si]['style_code']; ?></option>
										<?php } ?>
										</select>
									</div>
								</div>
														
							</div>
							</fieldset>
						</div>
						<div class="row" id="selectedstyle" style="display:block; clear: both;">
						
<?php 
	$stylecode 	= $data['style_ref'];
	if($data['style_ref_type'] == '1')
	{$data2 = $objstyle->getStyleDetails($stylecode);}
	else
	{$data2 = $objstyle->getCustomizedStyleDetails($stylecode);}
//echo '<pre>';print_r($data2); echo '</pre>';

?>
<fieldset class="fsStyle">
	<legend class="legendStyle">
		<a data-toggle="collapse" data-target="#demo" href="#">Selected Style Details <i class="fa fa-sort" aria-hidden="true"></i></a>
	</legend>
<div class="row collapse in" id="demo">
	<div class="row ">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Style Code</label><?php echo $MANDATORY; ?>
				<input type="text" class="form-control" readonly value="<?php echo $data2['style_code']; ?>">
			</div>
		</div>
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Description</label><?php echo $MANDATORY; ?>
				<input type="text" class="form-control" readonly value="<?php echo $data2['description']; ?>">
			</div>
		</div>
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Style Group Code</label>
				<input type="text" class="form-control" readonly value="<?php echo $data2['style_group_code']; ?>">
			</div>
		</div>
	</div><!-- /.col -->
	
	<div class="row">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Designer Code</label>
				<input type="text" class="form-control" readonly value="<?php echo $data2['designer_code']; ?>">
			</div>
		</div>
				
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Recommended Selling Price</label>
				<input type="text" class="form-control"  readonly value="<?php echo $data2['selling_price']; ?>">
			</div>
		</div>
		
	</div><!-- /.col -->
	<div class="row">
		<div class="col-lg-6">
			<div class="form-group">
				<label for="name">Picture</label><?php echo $MANDATORY; ?>&nbsp;
				<img src="<?php echo $data2['imagelocation']; ?>" width="150"/>
			</div>
		</div>
	</div><!-- /.col -->
</div>
</fieldset>
						
						</div>
						
					<div class="row"  style="clear: both;">
						<fieldset class="fsStyle">
							<legend class="legendStyle">
								<a href="#">Sub-Order Details</a>
							</legend>
						<div class="row">
							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Sale Amount</label>
									<input type="text" class="form-control" tabindex="3" id="edit_sale_amount" name="edit_sale_amount" onKeyPress="return isDecimalNumber(event,this);" onfocus="if(this.value=='0' || this.value=='0.00') this.value = ''" onblur="if(this.value=='')this.value = '0'" value="<?php echo $data['sale_amount']; ?>" >
								</div>			  
							</div><!-- /.col -->
							
							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Trial Date</label>
									<input type="text" class="form-control datepicker" tabindex="4" id="edit_trial_date1" name="edit_trial_date1" placeholder="Enter trial date" value="<?php echo $objord->date_ymd_dmy($data['trial_date']); ?>">
								</div>			  
							</div><!-- /.col -->
							
							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Delivery Due Date</label>
									<input type="text" class="form-control datepicker" tabindex="5" id="edit_delivery_due_date1" name="edit_delivery_due_date1" placeholder="Delivery due date" value="<?php echo $objord->date_ymd_dmy($data['delivery_due_date']); ?>">
								</div>			  
							</div><!-- /.col -->
							
						</div>
								
						<div class="row">
							<div class="col-lg-4">
								<div class="form-group">
									<label for="name">Discount Type </label>
									<div style="width:100%;">
									<input type="radio" id="edit_discount_type" <?php if($data['discount_type'] == 'Amount'){echo 'checked="true"';} ?> tabindex="6" name="edit_discount_type" value="Amount">Amount
									<input type="radio" id="edit_discount_type" <?php if($data['discount_type'] == 'Percentage'){echo 'checked="true"';} ?> tabindex="7" name="edit_discount_type" value="Percentage">Percentage
									</div>
								</div>
							</div><!-- /.col -->
							
							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Discount Value</label>
									<input type="text" class="form-control" tabindex="8" onKeyPress="return isDecimalNumber(event,this);" id="edit_discount_amount" name="edit_discount_amount" placeholder="Enter Discount Amount" onfocus="if(this.value=='0' || this.value=='0.00') this.value = ''" onblur="if(this.value=='')this.value = '0'" value="<?php echo $data['discount_amount']; ?>">
								</div>			  
							</div><!-- /.col -->
							
							<div class="col-lg-4">
								<div class="form-group">
									<label for="edit_substatus">Sub-Order Status</label>
									<select name="edit_substatus" tabindex="7" id="edit_substatus" class="form-control" style="width:100%;">
									<?php foreach($allStatus as $orderstatus){ ?>
									<option value="<?php echo $orderstatus['id']; ?>" <?php if($data['substatus'] == $orderstatus['id']){echo 'selected';}?>><?php echo $orderstatus['statusname']; ?></option>
									<?php } ?>
									</select>
								</div>	
							</div>
							
						</div>
						
						<div class="row">
							<div class="col-lg-12">										
								<div class="form-group">
									<label for="name">Sub-Order Detail</label>
									<textarea tabindex="9" id="edit_details" name="edit_details" class="form-control" placeholder="Order Detail" ><?php echo $data['details']; ?></textarea>
								</div>
							</div><!-- /.col -->
						</div>
						</fieldset>
							
					  </div><!-- /.row -->
					
		</div>

<?php	
	exit;		
}

if($_REQUEST['task'] == 'getSuborderrow')
{
	$orderno = $_REQUEST['orderno'];
	$alldata = $objord->getAllSuborder($orderno);

	if(count($alldata)>0){
?>							
	<table class="table table-bordered table-striped" width='100%'>
		<thead>
			<tr style="background-color:#D4AE87;">
				<th><b>Sub Order No</b></th>
				<th><b>Sale Amount</b></th>
				<th><b>Discount Type</b></th>
				<th><b>Discount</b></th>
				<th><b>Action</b></th>
			</tr>	
		</thead>
		<tbody>
		<?php 
		
		for($i = 0; $i <count($alldata); $i++)
		{
			?>
			<tr style="background-color:#EFD8C1;" id="<?php echo $alldata[$i]['suborderno']; ?>">
				<td><?php echo $alldata[$i]['suborderno']; ?></td>
				<td><?php echo $alldata[$i]['sale_amount']; ?></td>
				<td><?php echo $alldata[$i]['discount_type']; ?></td>
				<td><?php echo $alldata[$i]['discount_amount']; ?></td>
				<td><a href="#" data-toggle="modal" data-target="#editsuborder" onclick='editsuborder("<?php print $alldata[$i]['suborderno']; ?>")' >Edit</a>&nbsp;|&nbsp;
				<a href="suborder.php?action=editsub&orderno=<?php print $alldata[$i]['orderno'];?>&suborder=<?php echo $alldata[$i]['suborderno']; ?>">View Suborder Details</a>&nbsp;|&nbsp;
				<a href="#" data-toggle="modal" data-target="#subOrderNotes" onclick='getSubOrderNotes("<?php print $alldata[$i]['suborderno']; ?>")'>Sub Order Notes</a></td>
			</tr>
			<?php 										
		}
		?>									
		</tbody>
	</table>
<?php	
	}else{
?>							
	<table class="table table-bordered table-striped" width='100%'>
		<thead>
			<tr style="background-color:#D4AE87;">
				<th colspan="5" align="center"><b>No Data Found</b></th>
			</tr>	
		</thead>		
	</table>
<?php	
	}
	exit;		
}

if($_REQUEST['task'] == 'updateorderrow')
{
	$orderno = $_REQUEST['orderno'];
	$alldata = $objord->getById($orderno);
	$id= $alldata['id'];
?>							
	<td style='border: 1px solid;display: inline-block;position: relative; top:1px; left:5px;' class="accordion-toggle" data-toggle="collapse" data-target="#packageDetails<?php print $alldata['orderno']; ?>" onclick="getSuborderrow('<?php print $alldata['orderno']; ?>')"><i class="indicator glyphicon pull-right glyphicon-chevron-down"></i></td>
	<td><a href="#" data-toggle="modal" data-target="#orderdetails" onclick='getOrderbyno("<?php print $alldata['orderno']; ?>")'><?php print $alldata['orderno']; ?></a></td>
	<td><a href="#" data-toggle="modal" data-target="#getCutomerbyId" onclick='getCutomerbyId("<?php print $alldata['customer_id']; ?>")'><?php print $alldata['customer_id']; ?></a></td>
	<td><?php print $objord->date_ymd_dmy($alldata['order_date']); ?></td>
	<td>
	<a href="#" data-toggle="modal" data-target="#editorder" onclick='editorder("<?php print $alldata['orderno']; ?>")' >Edit</a>&nbsp;|&nbsp;
	<a href="#" data-toggle="modal" data-target="#suborder" onclick='getSuborderForm("<?php print $alldata['orderno']; ?>")'>Create Suborder</a>&nbsp;|&nbsp;
	<a href="#" data-toggle="modal" data-target="#paymentorder" onclick='getPaymentDetails("<?php print $alldata['orderno']; ?>")'>Payment</a>&nbsp;|&nbsp;
	<a href="#" data-toggle="modal" data-target="#ordernotes" onclick='getnotes("<?php print $alldata['orderno']; ?>")'>Order Notes</a>&nbsp;|&nbsp;
	<a href="#" onclick='getDeleteOrderNo("<?php print $alldata['orderno']; ?>")'>Delete</a>
	</td>
<?php	
	exit;		
}

if($_REQUEST['task'] == 'UpdateOrder')
{
	echo $objord->save();
	exit();
}


if($_REQUEST['task'] == 'AddSuborder')
{
	$msg = $objord->savesuborder();
	echo $msg;
	exit();
}

if($_REQUEST['task'] == 'AddPayment')
{
	$returnmsg = $objord->savePaymentDetails();
	echo $returnmsg;
	exit;		
}

if($_REQUEST['task'] == 'UpdatePayment')
{
	$returnmsg = $objord->updatePaymentDetails();
	echo $returnmsg;
	exit;		
}

if($_REQUEST['task'] == 'DeletePayment')
{
	$returnmsg = $objord->deletePaymentDetails();
	echo $returnmsg;
	exit;		
}

if($_REQUEST['task'] == 'EditPayment')
{
	$id = $_REQUEST['id'];
	$allsuborder = json_decode($_REQUEST['allsuborder']);
	$data = $objord->getPaymentInfoById($id);
	
?>
<div class="col-lg-12">
	<div class="form-group">
	  <label for="name">Sub-Order</label>
	  <select name="payment_suborder" class="form-control" id="payment_suborder">
	  <option value="" disabled selected>Select Sub-Order</option>
	  <?php foreach($allsuborder as $paysuborder){ ?>
	  <option <?php if($data['suborderno'] == $paysuborder){echo 'selected';} ?> value="<?php echo $paysuborder; ?>"><?php echo $paysuborder; ?></option>
	  <?php } ?>
	  </select>
	</div>
	
	<div class="form-group">
		<label for="name">Payment Date</label>
		<input type="text" tabindex="1" class="form-control datepicker" id="payment_date" name="payment_date" placeholder="Enter payment date" value="<?php echo $objord->date_ymd_dmy($data['payment_date']); ?>" />
		<input type="hidden" id="payment_id" name="payment_id" value="<?php echo $data['id']; ?>">
	</div>
	
	<div class="form-group">
	  <label for="name">Payment Mode</label>
	  <select name="payment_mode" tabindex="2" class="form-control" id="payment_mode">
	  <option value="">Select Payment Mode</option>
	  <option value="Cash" <?php if($data['payment_mode'] == 'Cash'){echo 'selected';} ?>>Cash</option>
	  <option value="CreditCard" <?php if($data['payment_mode'] == 'CreditCard'){echo 'selected';} ?>>CreditCard</option>
	  <option value="Cheque" <?php if($data['payment_mode'] == 'Cheque'){echo 'selected';} ?>>Cheque</option>
	  <option value="MobileWallet" <?php if($data['payment_mode'] == 'MobileWallet'){echo 'selected';} ?>>MobileWallet</option>
	  </select>
	</div>
	
	<div class="form-group">
	  <label for="name">Received Amount</label>
	  <input type="text" class="form-control" tabindex="3" id="received_amount" onKeyPress="return isDecimalNumber(event,this);" name="received_amount" placeholder="Enter received amount" value="<?php echo $data['received_amount']; ?>" />
	</div>
	
	<div class="form-group">
	  <label for="name">Remarks</label>
	  <input type="text" class="form-control" id="remarks" name="remarks" placeholder="Enter remarks" value="<?php echo $data['remarks']; ?>" />
	</div>
</div><!-- /.col -->
<?php
	exit;	
}



//task = 'update tailor info'
if($_REQUEST['task'] == 'updatetailorinfo')
{
	$updateinfo = $objord->updatetailorinfo();	
	echo $updateinfo;
	exit;		
}

if($_REQUEST['task'] == 'tailor_notes')
{
	$embronotes = $objord->addTailorNotes($_REQUEST['suborderno'],trim($_REQUEST['tailorid']),trim($_REQUEST['tailor_notes']),trim($_REQUEST['tastatus']));
	foreach($embronotes as $dn)
	{
		$html.=  '<div class="col-lg-12">
						<div class="form-group">
							Date	: '.$dn["createdon"].'<br/>
							Notes	: '.$dn["tailor_notes"].'
						</div>
					</div>
		<hr />';
	}
	echo $html;
	exit;
}


//task = 'update cutter info'
if($_REQUEST['task'] == 'updatecuttinginfo')
{
	$updateinfo = $objord->updatecutting();	
	echo $updateinfo;
	exit;		
}

if($_REQUEST['task'] == 'cutting_notes')
{
	$embronotes = $objord->addCuttingNotes($_REQUEST['suborderno'],trim($_REQUEST['cutterid']),trim($_REQUEST['cutting_notes']),trim($_REQUEST['custatus']));
	foreach($embronotes as $dn)
	{
		$html.=  '<div class="col-lg-12">
						<div class="form-group">											
							Date	: '.$dn["createdon"].'<br/>
							Notes	: '.$dn["cutting_notes"].'
						</div>	
					</div>  
		<hr />';
	}
	echo $html;
	exit;		
}


//task = 'updateembroinfo'
if($_REQUEST['task'] == 'updateembroinfo')
{
	$updateinfo = $objord->updateembro();	
	echo $updateinfo;
	exit;		
}

if($_REQUEST['task'] == 'embro_notes')
{
	$embronotes = $objord->addEmbroNotes($_REQUEST['suborderno'],trim($_REQUEST['embroiderid']),trim($_REQUEST['embroidery_notes']),trim($_REQUEST['emstatus']));
	foreach($embronotes as $dn)
	{
		$html.=  '<div class="col-lg-12">
						<div class="form-group">											
							Date	: '.$dn["createdon"].'<br/>
							Notes	: '.$dn["embroidery_notes"].'
						</div>	
					</div>  
		<hr />';
	}
	echo $html;
	exit;		
}

if($_REQUEST['task'] == 'updatedyinginfo')
{
	$updateinfo = $objord->updatedying();	
	echo $updateinfo;
	exit;		
}

if($_REQUEST['task'] == 'dying_notes')
{
	$dynotes = $objord->addDyingNotes($_REQUEST['suborderno'],trim($_REQUEST['dyerid']),trim($_REQUEST['dying_notes']),trim($_REQUEST['dystatus']));
	foreach($dynotes as $dn)
	{
		$html.=  '<div class="col-lg-12">
						<div class="form-group">											
							Date	: '.$dn["createdon"].'<br/>
							Notes	: '.$dn["dying_notes"].'
						</div>	
					</div><hr />';
	}
	echo $html;
	exit;		
}

if($_REQUEST['task'] == 'saveItem')
{
	echo $objitem->saveItemBySONO();
	exit();
}

if($_REQUEST['task'] == 'updateItem')
{
	echo $objitem->saveItemBySONO();
	exit();
}

if($_REQUEST['task'] == 'deleteItem')
{
	echo $objitem->deleteItemBySONO();
	exit();
}

if($_REQUEST['task'] == 'getItemDetails')
{
	$id = $_REQUEST['id'];
	$data = $objitem->getItemBySONO($id);
	$allitems = $objitem->getAll();
?>
<div class="col-lg-12">
	<div class="col-lg-4">
		<div class="form-group">
			<label for="name">Items</label>
			<select class="form-control select2" tabindex="4" id="ei_items" name="ei_items" style="width:100%;">
			<option value="" selected>Select</option>
			<?php 
			for($item=0; $item<count($allitems); $item++) {
				if($data['items'] == $allitems[$item]['id']){$selected = 'selected';}else{$selected = '';}
				echo "<option value='".$allitems[$item]['id']."' $selected>".$allitems[$item]['itemname']."</option>";
			}
			?>
			</select>
			<input type="hidden" id="ei_id" name="ei_id" class="form-control" value="<?php echo $data['id']; ?>" />
			<input type="hidden" id="ei_orderno" name="ei_orderno" class="form-control" value="<?php echo $data['orderno']; ?>" />
			<input type="hidden" id="ei_suborderno" name="ei_suborderno" class="form-control" value="<?php echo $data['suborderno']; ?>" />
		</div>	
	</div><!-- /.col -->
	
	<div class="col-lg-4">
		<div class="form-group">
			<label for="name">Fabric ID</label>
			<select class="form-control select2" tabindex="4" id="ei_fabricid" name="ei_fabricid" style="width:100%;">
			<option value="" selected>Select</option>
			<?php 				
			for($fbi=0; $fbi<count($allfabric); $fbi++) {
				if($data['fabric'] == $allfabric[$fbi]['id']){$selected = 'selected';}else{$selected = '';}
				echo "<option value='".$allfabric[$fbi]['id']."' $selected>".$allfabric[$fbi]['fabricname']."</option>";
			}
			?>
			</select>
		</div>	
	</div><!-- /.col -->

	<div class="col-lg-4">										
		<div class="form-group">
			<label for="name">Quantity(in Metre)</label>
			<input type="text" class="form-control" tabindex="5" onKeyPress="return isDecimalNumber(event,this);" id="ei_quantity" name="ei_quantity" placeholder="Enter quantity" value="<?php echo $data['meters']; ?>">
		</div>			  
	</div><!-- /.col -->
	
</div>
<?php
	exit;	
}

if($_REQUEST['task'] == 'history_assigned_id')
{
	$assignedid = $_REQUEST['assignedid'];
	$alldata = $objitem->getWorkStatusAssignedId($assignedid);
	
	foreach($alldata as $data) {
?>
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" >
		<p style="border-bottom: 1px solid #ccc; padding-bottom: 10px;"><?php echo $data['status_entry_date']; ?> | <?php echo $data['statusname']; ?> | Agency Name : <?php echo $data['agencyname']; ?></p>
		
	</div>
<?php
	}
	exit;	
}

if($_REQUEST['checkChallanNo']=='checkChallanNo')
{
	$challanno = $_POST['challanno'];
	$data 	= $objitem->checkChallanNo($challanno);
	
	if($data['total'] < 1){
		echo "1";
	}else{
		echo "0";
	}
	exit;
}

if($_REQUEST['task'] == 'updateAgencyAssignedWork')
{
	$alldata = $objitem->updateAgencyAssignedWork();
	echo $alldata;
	exit;	
}

if($_REQUEST['task'] == 'updateAssignedWork')
{
	$alldata = $objitem->updateAssignedWork();
	//echo $alldata;
	echo 'OK';
	exit;	
}

//agencyUpdateStatus
if($_REQUEST['task'] == 'agencyUpdateStatus')
{
	$objStatus 	= new Statusmaster();
		
	$username 	= $_REQUEST['username'];
	$assignedid = $_REQUEST['assignedid'];
	
	$allStatus 	= $objStatus->getAllAgencyStatus($username);
	$alldata 	= $objitem->getWorkStatusAssignedId($assignedid);
	
	foreach($alldata as $alldata) {
?>
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" >
		<p style="border-bottom: 1px solid #ccc; padding-bottom: 10px;"><?php echo $alldata['status_entry_date']; ?> | <?php echo $alldata['statusname']; ?> | <?php echo $alldata['agencyname']; ?> | Challan No: <?php echo $alldata['challanno']; ?><br/>
		Remark: <?php echo $alldata['remark']; ?></p>
	</div>
<?php
	}
?>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">										
		<div class="form-group">
			<label for="name">Status</label>
			<select id="aw_assignstatus" class="form-control input-sm" name="aw_assignstatus" >
			<?php foreach($allStatus as $orderstatus){ ?>
			<option value="<?php echo $orderstatus['id']; ?>"><?php echo $orderstatus['statusname']; ?></option>
			<?php } ?>
			</select>
		</div>			  
	</div><!-- /.col -->	
	
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
		<div class="form-group">
			<label for="name">Date</label>
			<input type="text" class="form-control input-sm datepicker" id="aw_status_date" name="aw_status_date" placeholder="Date" value="<?php echo date('d/m/Y'); ?>">
		</div>			  
	</div><!-- /.col -->
	
</div>

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="form-group">
			<label for="name">Remark</label>
			<input type="hidden" id="aw_assigned_id" name="aw_assigned_id" class="form-control" value="<?php echo $assignedid; ?>" />
			<input type="text" id="aw_remark" name="aw_remark" class="form-control input-sm" value="<?php echo $data['remark']; ?>" />
		</div>	
	</div><!-- /.col -->
	
</div>

<?php	
	exit;
}

if($_REQUEST['task'] == 'getAssignedWorkData')
{
	$objStatus = new Statusmaster();
	$allStatus = $objStatus->getAll();

	$assignedid = $_REQUEST['assignedid'];
	//$data = $objitem->getAssignedWorkData($assignedid);
	
	$alldata = $objitem->getWorkStatusAssignedId($assignedid);
	
	foreach($alldata as $alldata) {
?>
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" >
		<p style="border-bottom: 1px solid #ccc; padding-bottom: 10px;"><?php echo $alldata['status_entry_date']; ?> | <?php echo $alldata['statusname']; ?> | <?php echo $alldata['agencyname']; ?> | Challan No: <?php echo $alldata['challanno']; ?><br/>
		Remark: <?php echo $alldata['remark']; ?></p>
	</div>
<?php
	}
?>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">										
		<div class="form-group">
			<label for="name">Status</label>
			<select id="aw_assignstatus" class="form-control input-sm" name="aw_assignstatus" onchange="getAgencyByAssignedID(this.value);" tabindex="1" >
			<option value="0" selected="selected" disabled >No Work Done</option>
			<?php foreach($allStatus as $orderstatus){ if($data['status_id'] == $orderstatus['id']){$status_selected = 'selected';}else{$status_selected = '';} ?>
			<option value="<?php echo $orderstatus['id'].':'.$orderstatus['status_type']; ?>" <?php echo $status_selected; ?>><?php echo $orderstatus['statusname']; ?></option>
			<?php } ?>
			</select>
			<input type="hidden" id="aw_checkstatustype" name="aw_checkstatustype" value="None" />
		</div>			  
	</div><!-- /.col -->
	
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 initiald">
		<div class="form-group">
			<label for="name">Agency</label>
			<select id="aw_agencyid" class="form-control input-sm" name="aw_agencyid" ></select>
		</div>	
	</div><!-- /.col -->
	
</div>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
		<div class="form-group">
			<label for="name">Status Date</label>
			<input type="text" class="form-control input-sm datepicker" id="aw_status_date" name="aw_status_date" placeholder="Status Date" value="<?php echo date('d/m/Y'); ?>">
		</div>			  
	</div><!-- /.col -->
	
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 initiald">
		<div class="form-group">
			<label for="name">Expected Date</label>
			<input type="text" class="form-control input-sm datepicker" id="aw_expected_date" name="aw_expected_date" placeholder="Expected Date" value="<?php echo date('d/m/Y'); ?>">
		</div>			  
	</div><!-- /.col -->
</div>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
		<div class="form-group">
			<label for="name">Remark</label>
			<input type="hidden" id="aw_assigned_id" name="aw_assigned_id" class="form-control" value="<?php echo $assignedid; ?>" />
			<input type="text" id="aw_remark" name="aw_remark" class="form-control input-sm" placeholder="Remark" value="<?php echo $data['remark']; ?>" />
		</div>	
		
	</div><!-- /.col -->
	
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 initiald">
		<div class="form-group">
			<label for="name">Challan No</label>
			<input type="text" class="form-control input-sm" onblur="check_challanno(this.value,2);" id="aw_challanno" name="aw_challanno" placeholder="Challan Number" value="" />
			<div id="challanno_id_html2"></div>
		</div>			  
	</div><!-- /.col -->
</div>

<?php	
	exit;
}

if($_REQUEST['task'] == 'getItemBySO')
{
	$suborderno = $_REQUEST['suborderno'];
	$alldata = $objitem->itemsbysuborderno($suborderno);

	if(count($alldata)>0){
?>							
	<table class="table table-bordered table-striped inner-table" width='100%'>
		<thead>
			<tr>
				<th><b>Items</b></th>
				<th><b>Fabric</b></th>
				<th><b>Fabric Quantity</b></th>
				<th><b>Status</b></th>
				<th><b>View History</b></th>
			</tr>	
		</thead>
		<tbody>
		<?php 
		
		for($i = 0; $i <count($alldata); $i++)
		{	?>
			<tr id="<?php echo $alldata[$i]['suborderno']; ?>">
				<td><?php echo $alldata[$i]['itemname']; ?></td>
				<td><a href="#" data-toggle="modal" data-target="#viewfabric" onclick='getfabricdetails("<?php print $alldata[$i]['fabric']; ?>");'><?php echo $alldata[$i]['fabricname']; ?></a></td>
				<td><?php echo $alldata[$i]['meters']; ?></td>
				<td><?php 
				if($alldata[$i]['status_id'] == '0'){echo 'No work done.';}
				else{$statusname = $objitem->getStatusName($alldata[$i]['status_id']); echo $statusname['statusname'];}
				?></td>
				
				
				<td><a href="#" data-toggle="modal" data-target="#viewhistory" onclick='gethistorybyassignedid("<?php print $alldata[$i]['id']; ?>");'>View</a></td>
			</tr>
			<?php 										
		}
		?>									
		</tbody>
	</table>
<?php	
	}else{
?>							
	<table class="table table-bordered table-striped" width='100%'>
		<thead>
			<tr style="background-color:#D4AE87;">
				<th colspan="7" align="center"><b>No Data Found</b></th>
			</tr>	
		</thead>		
	</table>
<?php	
	}
	exit;		
}

	if($_REQUEST['task'] == 'getCustomer'){
		//echo $_REQUEST['cust_id'];die();
		$cust = $objCus->getCustomerDetailByID(trim($_REQUEST['cust_id']));
		//echo $cust;die();
		foreach($cust as $n)
		{
			$html.='<div class="row">							
					<div class="col-lg-12">
						<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Customer ID</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['cust_id'].'										  
							</div>										  
						</div><!-- /.col -->
							<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Name</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['salutation'].' '.$n['name_first'].' '.$n['name_last'].'										  
							</div>										  
						</div><!-- /.col -->								
					</div>
					
					
					<div class="col-lg-12">
						<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Address</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-10">										
							<div class="form-group">
								'.$n['address2'].' '.$n['city_name'].' '.$n['state_name'].' '.$n['country_name'].' '.$n['pin'].'
							</div>										  
						</div>
					</div>';
					
					$html.='<div class="col-lg-12">
						<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Phone</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['contact_no1'].'								  
							</div>										  
						</div><!-- /.col -->
							<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Email</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['email_1'].'
							</div>										  
						</div><!-- /.col -->								
					</div>
					

					<div class="col-lg-12">
						<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Preference</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['contact_preference'].'
							</div>										  
						</div><!-- /.col -->
							<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Relation</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['relation_a'].'
							</div>										  
						</div><!-- /.col -->								
					</div>
					
					
					<div class="col-lg-12">
						<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Refferal ID</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['refferal_id'].'
							</div>										  
						</div><!-- /.col -->
							<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Family</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['family'].'
							</div>										  
						</div><!-- /.col -->								
					</div>
					
					
					<div class="col-lg-12">
						<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Date Of Birth</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['dob'].'
							</div>										  
						</div><!-- /.col -->
						<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Source</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['source'].'
							</div>										  
						</div><!-- /.col -->								
					</div>
					
					
					<div class="col-lg-12">
						<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Remarks</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-10">										
							<div class="form-group">
								'.$n['notes'].'
							</div>										  
						</div>
					</div>
			   </div><!-- /.row -->';
		}



		echo $html;
		exit;
		
	}

?>