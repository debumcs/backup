<?php 
	//require_once('include/auth.php');
	require_once('class/class.orderdetails.php');
	
	$objord = new Orderdetails();
	$orderno = $_GET["orderno"];
	
	$data = $objord->getById($orderno);
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>BIZCRM | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
     
   <div class="wrapper">
			<!-- add payment -->
	  
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Order Information</h4>
			  </div>
			  <div class="modal-body">
							<div class="row">							
								<div class="col-lg-12">
									<div class="col-lg-3">
										<div class="form-group">
										  <label for="name">Customer ID</label>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-3">
										<div class="form-group">
											<?php echo $data['customer_id'];?>
										</div>
									</div><!-- /.col -->
									
									<div class="col-lg-3">
										<div class="form-group">
										  <label for="name">Order Number</label>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-3">
										<div class="form-group">
											<?php echo $data['orderno'];?>
										</div>
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-3">										
										<div class="form-group">
										  <label for="name">Order details</label>										  
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-9">
										<div class="form-group">
										<?php echo $data['order_detail'];?> 
										</div>
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-3">
										<div class="form-group">
										  <label for="name">Order Date</label>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-3">
										<div class="form-group">
											<?php echo $data['order_date'];?>
										</div>
									</div><!-- /.col -->
									
									<div class="col-lg-3">
										<div class="form-group">
										  <label for="name">Trial Date</label>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-3">
										<div class="form-group">
											<?php echo $data['trial_date'];?>
										</div>
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-3">
										<div class="form-group">
										  <label for="name">Delivery Due Date</label>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-3">
										<div class="form-group">
											<?php echo $data['delivery_due_date'];?>
										</div>
									</div><!-- /.col -->
									
									<div class="col-lg-3">
										<div class="form-group">
										  <label for="name">Indate</label>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-3">
										<div class="form-group">
											<?php echo $data['indate'];?>
										</div>
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-3">
										<div class="form-group">
										  <label for="name">Outdate</label>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-3">
										<div class="form-group">
											<?php echo $data['outdate'];?>
										</div>
									</div><!-- /.col -->
									
									<div class="col-lg-3">
										<div class="form-group">
										  <label for="name">Bundle Date</label>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-3">
										<div class="form-group">
											<?php echo $data['bundle_date'];?>
										</div>
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-3">
										<div class="form-group">
										  <label for="name">Delivery Date</label>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-3">
										<div class="form-group">
											<?php echo $data['delivery_date'];?>
										</div>
									</div><!-- /.col -->
									
									<div class="col-lg-3">
										<div class="form-group">
										  <label for="name">Quantity</label>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-3">
										<div class="form-group">
											<?php echo $data['quantity'];?>
										</div>
									</div><!-- /.col -->
									
									
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-3">
										<div class="form-group">
										  <label for="name">Original Amount</label>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-3">
										<div class="form-group">
											<?php echo $data['original_amount'];?>
										</div>
									</div><!-- /.col -->
									
									<div class="col-lg-3">
										<div class="form-group">
										  <label for="name">Discount</label>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-3">
										<div class="form-group">
											<?php echo $data['discount'];?>
										</div>
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-3">
										<div class="form-group">
										  <label for="name">Sale Amount</label>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-3">
										<div class="form-group">
											<?php echo $data['sale_amount'];?>
										</div>
									</div><!-- /.col -->
									
									<div class="col-lg-3">
										<div class="form-group">
										  <label for="name">Delivery Status</label>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-3">
										<div class="form-group">
											<?php echo $data['delivery_status'];?>
										</div>
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-3">
										<div class="form-group">
										  <label for="name">Agent ID</label>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-3">
										<div class="form-group">
											<?php echo $data['agent_id'];?>
										</div>
									</div><!-- /.col -->
									
									<div class="col-lg-3">
										<div class="form-group">
										  <label for="name">Style Ref</label>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-3">
										<div class="form-group">
											<?php echo $data['style_ref'];?>
										</div>
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-3">
										<div class="form-group">
										  <label for="name">Delivery Remarks</label>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-9">
										<div class="form-group">
											<?php echo $data['delivery_remarks'];?>
										</div>
									</div><!-- /.col -->
								</div>
								
                           </div><!-- /.row -->
                           
                           
                        </div><!-- /.box-body--> 
                    </div><!-- /.box-->
                        
                </div><!-- /.col -->
			  </div>			  
			
	<!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    
   
  </body>
</html>