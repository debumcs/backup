<?php 
	require_once('include/auth.php');
	require_once('class/class.customer.php');
	$objcus = new Customer();
	$alldata = $objcus->getAll();
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | Customer Manager</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="dist/css/dataTables.bootstrap.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
   <link rel="stylesheet/less" type="text/css" href="side.less" />
	<link rel="stylesheet" href="date/jquery-ui.css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
         <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body class="hold-transition skin-blue sidebar-mini" onload="startTime()">
 <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objcus->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objcus->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Manage Customer Master
          </h1>
            <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Control Panel</li>
            <li class="active">Manage Customer Master</li>
          </ol>
        </section><!--CONTENT HEADER-->
        
          <!-- Main content -->
		<?php ?>
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-body table-responsive'>
                            <table id="example111" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Customer ID</th>
                        <th>Customer Name</th>
                        <th>Email</th>
                        <th>Contact</th>                        
                        <th>Action</th>                    
                      </tr>
                    </thead>
                    <tbody>
					<?php for($i=0; $i<count($alldata); $i++) { ?>	
						<tr>
                            <td><a href="#" data-toggle="modal" data-target="#getCutomerbyId" onclick='getCutomerbyId("<?php print $alldata[$i]['cust_id']; ?>")'><?php print $alldata[$i]['cust_id']; ?></a></td>
							<td><?php print $alldata[$i]['salutation'].' '.$alldata[$i]['name_first'].' '.$alldata[$i]['name_last']; ?></td>
							<td><?php print $alldata[$i]['email_1']; ?></td>
							<td><?php print $alldata[$i]['contact_no1']; ?></td>
						    <td><a href="customer_edit.php?action=edit&id=<?php print $alldata[$i]['id']; ?>">Edit</a> | <a href="order.php?cust_id=<?php echo $alldata[$i]['cust_id']; ?>" >Create Order</a> <!--| <a href="#" data-toggle="modal" data-target="#cusnotes<?php echo $alldata[$i]['cust_id']; ?>">Notes</a>--></td>
						</tr>
						
						<div class="modal fade" id="cusnotes<?php echo $alldata[$i]['cust_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="addMyPaymentLabel">
							<div class="modal-dialog" role="document">
							<form method="post" name="payment" id="payment">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<h4 class="modal-title" id="myModalLabel">Customer Notes</h4>
									</div>
									<div class="modal-body">
										<div class="row">
											<div class="col-lg-12">
												<?php $notes = $objcus->getCustomerNotes($alldata[$i]['cust_id']); ?> 
												<div id="cus_note_tbl<?php echo  $alldata[$i]['cust_id']; ?>" class="orderdiv">
												<?php	foreach($notes as $n){ ?>
													<div class="row">  
														<div class="col-lg-12">
															<b>Note :-  </b>
															<?php echo $n['notes']; ?>
														</div>

														<div class="col-lg-6">
															<b>  Date:-  </b> 
															<?php echo $objcus->date_ymd_dmy($n['notes_date']); ?>
														</div>
														
														<div class="col-lg-6">
															<b>  Added By:-  </b> 
															<?php echo $n['name'].' ('.$n['agent_id'].')'; ?>
														</div>
													</div>  
													<hr />
												<?php } ?>
												</div><!-- /.col -->
											
												<div class="form-group">
													<label for="name">Enter Notes</label>
													<textarea  class="form-control" id="cus_note<?php echo  $alldata[$i]['cust_id']; ?>" name="cus_note" placeholder="Enter Notes"></textarea>
												</div>

											</div><!-- /.col -->

										</div><!-- /.row -->
									</div>
									<div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
										<input type="hidden" name="task" id="task" value="cus_notes" />
										<input type="hidden" name="cust_id" id ='cust_id' value="<?php echo $alldata[$i]['cust_id']; ?>" />
										<input type="hidden" name="agent_id" id ='agent_id' value="<?php echo $_SESSION['ADMIN_NAME']; ?>" />
										<input name="ipaddress" type="hidden" id="ipaddress" value="<?php echo $_SERVER['REMOTE_ADDR'];?>" >
										<input type="button" class="btn btn-primary" name="savePayment" id="savePayment" value="Save" onclick='addnotes("<?php echo  $alldata[$i]['cust_id']; ?>")'/>
									</div>
								</div>
							</form>
							</div>
						</div>
						
						
                    <?php } ?>						
                    </tbody>
                    
                  </table>
                           
                          </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
		<?php  ?>
      </div><!-- /.content-wrapper -->
      
 <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->
	
	<!-- Customer Popup Info-->
<div class="modal fade" id="getCutomerbyId" tabindex="-1" role="dialog" aria-labelledby="getCutomerbyIdLabel">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Customer Details </h4>
			</div>
			
			<div class="modal-body">
				<div class="row">
					<div id="getCustomer">

					</div><!-- /.col -->
				</div><!-- /.row -->
			</div>
			
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>		
		</div>
	</div>
</div>
	<!-- Customer Popup Info-->
	
    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
    <!-- DataTables -->
    <script src="dist/js/jquery.dataTables.js"></script>
    <script src="dist/js/dataTables.bootstrap.min.js"></script>
    <script>

function addnotes(cid){
	var note = $("#cus_note"+cid).val();
	var cust_id = cid;
	var agent_id = $("#agent_id").val();
	var ipaddress = $("#ipaddress").val();

	if(note == ''){
		alert('Please enter notes!');
		return false;
	}

	var task = 'cus_notes';
	$.ajax({
		type: "GET",
		url: "ajax.php",
		data: {cus_note:note,task:task,cust_id:cust_id,agent_id:agent_id,ipaddress:ipaddress},

		success: function(data){
			console.log(data);
			$("#cus_note_tbl"+cust_id).html('');
			$("#cus_note"+cust_id).val('');

			$("#cus_note_tbl"+cust_id).html(data);
			return false;
		}
	});

	return false;
}
	
function getCutomerbyId(cust_id){
	var task = 'getCustomer';
	
	$.ajax({
		type: "GET",
		url: "ajax_suborder.php",
		data: {task:task,cust_id:cust_id},
		success: function(data){
			console.log(data);
			$("#getCustomer").html('');
			$("#getCustomer").html(data);
			return false;
		}
	});
	return false;
}
	$(function () {
		$('#example111').DataTable({
			"bPaginate": true,
			"bFilter": true,
			"bInfo": true,
			order: [],
			columnDefs: [ { orderable: false, targets: [0] } ]
		});
	});
	
	
	$("#message").fadeIn('slow').delay(5000).fadeOut('slow');
    </script> 
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js"></script>
    
    <script type="text/javascript" src="plugins/datepicker/bootstrap-clockpicker.min.js"></script>
    
    <script type="text/javascript" src="dist/js/date.js"></script>
    
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
  </body>
</html>