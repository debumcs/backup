<?php
error_reporting(E_ERROR);
ini_set('display_errors', 0);

$GLOBALS["df_small"]	= "d-m-Y";
$GLOBALS["df_big"] 	= "d-m-Y H:i:s";




function connection(){
	$servername='localhost'; 
// test
    // Your MySql Server Name or IP address here
	$dbusername='bizcrmroot';            // Login user id here
	$dbpassword='$DRftgyhu@123456';     // Login password here
	$dbname='bizcrm';     

	// Your database name here
	define('servername','localhost');
	define('dbusername','root');
	define('dbpassword','');
	define('dbname','livebizcrm');

	$db = new MySQLI($servername,$dbusername,$dbpassword,$dbname);

	if ($db->connect_error) {
		die('Error : ('. $db->connect_errno .') '. $db->connect_error);
	}else{
		return $db;
	}
}	

$coni = connection();

//$coni = new Database();

?>
