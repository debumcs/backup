<?php 
	require_once('include/auth.php');
	require_once('class/class.category.php');
	$objcategory = new Category();
	
	$action = $_GET["action"];
	$id = $_GET["id"];
	$msgD = '';
	
		
	if($action=="edit")
	{
	    $btnvalue = "UPDATE";
		$data = $objcategory->getById($id);
	}
	else
	{
		$btnvalue = "SAVE";
	}
	
	if(isset($_POST['submit']))
	{
		$objcategory->save();
		exit();
	}

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | Add Category</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Bootstrap time Picker -->
    <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
    <!-- Date Picker -->
    <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<script type="text/javascript" language="javascript">

	function isDecimalNumber(evt, element)
	{			
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode!=46)
		{
			status = "This field accepts numbers only.";
			return false;
		}else {
			var len = $(element).val().length;
			var index = $(element).val().indexOf('.');
			if (index > 0 && charCode == 46) {
				return false;
			}
			if (index > 0) {
				var CharAfterdot = (len + 1) - index;
				if (CharAfterdot > 3) {
					return false;
				}
			}

		}
		return true;
	}
		//customer_category, description, advance_percentage, discount_percentage
		function validate_category(){
            
            if(document.getElementById('customer_category').value =='' )
            {
				alert('Please enter category type!');
				document.getElementById('customer_category').focus();
				return false;
			}
			else if(document.getElementById('description').value =='')
			{
				alert('Please enter description!');
				document.getElementById('description').focus();
				return false;
			}
			else if(document.getElementById('advance_percentage').value == '')
			{
				alert('Please enter advance percentage!');
				document.getElementById('advance_percentage').focus();
				return false;
			}else if(document.getElementById('discount_percentage').value == '')
			{
				alert('Please enter discount percentage!');
				document.getElementById('discount_percentage').focus();
				return false;
			}
			else{
				return true;
			}
      	}
	
	</script>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
     
   <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objcategory->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objcategory->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Category Master
          </h1>
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Control Panel</li>
            <li class="active">Category Master</li><li class="active">Add Category</li>
          </ol>
        </section><!--CONTENT HEADER-->
        
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title">Add Category</h3><span style='float:right'>Fields marked with a asterisk (<font color='red'>*</font>) are mandatory.</span>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <form action="" name="CategoryCreate" id="CategoryCreate" method="post" >
							<div class="row">
								<div class="col-lg-12">	
									<div class="col-lg-6">
										<div class="form-group">
											<label>Customer Category<font color='red'>*</font></label>
											<input type="text" class="form-control" id="customer_category"  name="customer_category" placeholder="Enter customer category" value="<?php echo $data['customer_category']; ?>">
											<input type="hidden" id="id" name="id" value="<?php echo $data['id']; ?>" />
										</div><!-- /.form-group -->
									</div><!-- /.col -->
									
									<div class="col-lg-6">
										<div class="form-group">
											<label>Description</label>
											<input type="text" class="form-control" id="description"  name="description" placeholder="Enter description" value="<?php echo $data['description']; ?>">
										</div><!-- /.form-group -->
									</div><!-- /.col -->
									
									
								</div><!-- /.col -->
								
								<div class="col-lg-12">	
									<div class="col-lg-6">
										<div class="form-group">
											<label for="name">Advance Percentage<font color='red'>*</font> </label>
											<input type="text" class="form-control" id="advance_percentage"  name="advance_percentage" placeholder="Enter advance percentage" onKeyPress="return isDecimalNumber(event,this);" onfocus="if(this.value=='0' || this.value=='0.00') this.value = ''" onblur="if(this.value=='')this.value = '0'" value="<?php if($data['advance_percentage']){echo $data['advance_percentage'];}else{echo '0';} ?>">
										</div>
										
									</div><!-- /.col -->
								  
									<div class="col-lg-6">
										<div class="form-group">
											<label for="name">Discount Percentage<font color='red'>*</font> </label>
											<input type="text" class="form-control" id="discount_percentage" onKeyPress="return isDecimalNumber(event,this);" onfocus="if(this.value=='0' || this.value=='0.00') this.value = ''" onblur="if(this.value=='')this.value = '0'" name="discount_percentage" placeholder="Enter discount percentage"  value="<?php if($data['discount_percentage']){echo $data['discount_percentage'];}else{echo '0';} ?>">
										</div>
										  
										
										<?php if($action=="edit") { ?>	
										<div class="form-group">
											<label>Category Visibility</label>
											  <ul class="columns">
												<li>
												<input type="checkbox" id="u1" name="cstatus" <?php if($data['cstatus'] == 1){echo 'checked';}else{echo '';} ?> value="<?php echo $data['cstatus']; ?>" />
												<label class="toggle <?php if($data['cstatus'] == 1){echo 'custom-checked';}else{echo '';} ?>" for="u1"></label>
												Active
												</li>
											  </ul>
										   </div><!-- /.form-group -->
										<?php } ?>
										
									</div><!-- /.col -->
								</div><!-- /.col -->
                           </div><!-- /.row -->
                           
                           <div class="row">
                              <div class="col-lg-12">
                                   <div class="form-group center">
                                      <input type="submit" name="submit" id="submit" class="btn btn-warning left-10" value="<?php echo $btnvalue; ?>" onclick="return validate_category();" />
									  <a href="manageCategoryMaster.php" class="btn btn-warning left-10">View All</a>
                                   </div>
                               </div><!-- /.col -->
             				 </div><!-- /.row -->
                           </form>
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
      </div><!-- /.content-wrapper -->
      
      
      <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
    
    <!-- daterangepicker -->
    <script src="dist/js/moment.min.js"></script>
    <!-- iCheck 1.0.1 -->
    <script src="plugins/iCheck/icheck.min.js"></script>

    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>

    <script>
		$("#message").fadeIn('slow').delay(5000).fadeOut('slow');
		$(".select2").select2();
		  //Date range picker
	</script>
  </body>
</html>