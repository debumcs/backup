<?php
session_start();
require_once('adminconfig_new.php');

function base_url(){
	$base_url = 'http://10.100.4.50/bizcrm/';
	return $base_url;
}

function ConvertTimezoneToAnotherTimezone($time, $currentTimezone) {
    
	$userTimezone = ''; 
    switch ($currentTimezone) 
    { 
        case 'PST':  $userTimezone = 'America/Los_Angeles'; break; 
        case 'CST':  $userTimezone = 'America/Chicago'; break; 
        case 'MST':  $userTimezone = 'US/Mountain'; break; 
        case 'EST':  $userTimezone = 'US/Eastern'; break;                 
        case 'IST':  $userTimezone = 'Asia/Kolkata'; break;    
    } 
    //if($userTimezone!='') 
    //date_default_timezone_set($userTimezone);
	
	$dayLightFlag = false;
    $dayLgtSecCurrent = $dayLgtSecReq = 0;
    $system_timezone = date_default_timezone_get();
    $local_timezone = $userTimezone;
    date_default_timezone_set($local_timezone);
    $local = date("Y-m-d H:i:s");
    date_default_timezone_set("GMT");
    $gmt = date("Y-m-d H:i:s ");

    $require_timezone = 'Asia/Kolkata';
    date_default_timezone_set($require_timezone);
    $required = date("Y-m-d H:i:s ");

    date_default_timezone_set($system_timezone);

    $diff1 = (strtotime($gmt) - strtotime($local));
    $diff2 = (strtotime($required) - strtotime($gmt));

    $date = new DateTime($time);

    $date->modify("+$diff1 seconds");
    $date->modify("+$diff2 seconds");

    if ($dayLightFlag) {
        $final_diff = $dayLgtSecCurrent + $dayLgtSecReq;
        $date->modify("$final_diff seconds");
    }

    $timestamp = $date->format("Y-m-d H:i:s ");

    return $timestamp;
}


function TimeZoneCastNew($currentdatetime,$zonetime) 
{ 
	$myDateTime = new DateTime($currentdatetime); 
	switch ($zonetime) 
	{ 
		case 'PST': 
			$myDateTime->setTimezone(new DateTimeZone('America/Los_Angeles')); 
			$finaldatetime = $myDateTime->format("Y-m-d H:i:s"); 
			break; 
				 
		case 'CST': 
			$myDateTime->setTimezone(new DateTimeZone('America/Chicago')); 
			$finaldatetime = $myDateTime->format("Y-m-d H:i:s"); 
			break; 
				 
		case 'MST': 
			$myDateTime->setTimezone(new DateTimeZone('US/Mountain')); 
			$finaldatetime = $myDateTime->format("Y-m-d H:i:s"); 
			break; 

		case 'EST':    
			$myDateTime->setTimezone(new DateTimeZone('US/Eastern')); 
			$finaldatetime = $myDateTime->format("Y-m-d H:i:s"); 
			break;                 
				 
		case 'IST':    
			$myDateTime->setTimezone(new DateTimeZone('Asia/Kolkata')); 
			$finaldatetime = $myDateTime->format("Y-m-d H:i:s"); 
			break;                                         

		default : 
			$finaldatetime = $currentdatetime; 
			break;         
	} 
	return $finaldatetime; 
}

function convertfromdatetodate($datetimerange)
{  
	$timerange = array();
	$timerange = explode('-',$datetimerange);
  
	$fromdate=  strtotime($timerange[0]);
	$fromdate=  date('Y-m-d H:i:s',$fromdate);
  
	$todate=  strtotime($timerange[1]);
	$todate= date('Y-m-d H:i:s',$todate);
	
	$date=array('fromdate'=>$fromdate,'todate'=>$todate);

	return $date;
}

function convertcombinddate($fromdate,$todate)
{  
	$fromdate = date('m/d/Y h:i A',strtotime($fromdate));
    $todate = date('m/d/Y h:i A',strtotime($todate));
    $datetimerange = $fromdate.' - '.$todate;

	return $datetimerange;
}



function getUserDetails($id){	
	$coni = connection();
	$sql = "SELECT username, name, empid, mgremailid, empemailid, managerid, role, queryno, authvisibility, expiredate FROM adminuser WHERE username = ? LIMIT 1";
	$result = $coni->prepare($sql);
	$result->bind_param('s',$id);
	$result->execute();
	$result->bind_result($username, $name, $empid, $mgremailid,$empemailid,$managerid,$role,$queryno,$authvisibility,$expiredate);
	$result->fetch();
	$coni->close();
	$data = array(
		'username' => $username, 
		'name' => $name, 
		'empid' => $empid, 
		'mgremailid' => $mgremailid,
		'empemailid' => $empemailid,
		'managerid' => $managerid,
		'role' => $role,
		'queryno' => $queryno,
		'authvisibility' => $authvisibility,
		'expiredate' => $expiredate
	);
	return $data;	
}

function all_menu_list(){
	
	$coni = connection();	
    $sql = "SELECT menuid, header, parent_menuid, pagename FROM menuitem";
	$query = $coni->query($sql);
	
	$refs = array();
    // create and array to hold the list
    $list = array();
	
	while($data = $query->fetch_assoc())
    {
        $thisref = &$refs[ $data['menuid'] ];
        $thisref['parent_menuid'] = $data['parent_menuid'];
        $thisref['header'] = $data['header'];
		$thisref['pagename'] = $data['pagename'];
		$thisref['menuid'] = $data['menuid'];

        if ($data['parent_menuid'] == 0)
        {
            $list[ $data['menuid'] ] = &$thisref;
        }
        else
        {
            $refs[ $data['parent_menuid'] ]['children'][ $data['menuid'] ] = &$thisref;
        }
    }	
	return $list;
}

function create_all_menu_list( $arr, $explode_menu )
{
	$html = "<ul>";
	foreach ($arr as $key=>$v) 
	{
		$html .= '<li>';
		$html .= '<input type="checkbox" name="tall[]" id="tall-'.$v['menuid'].'" '.checkarray($v['menuid'],$explode_menu).' value="'.$v['menuid'].'">';
		$html .= '<label for="tall-'.$v['menuid'].'" class="custom-'.checkarray($v['menuid'],$explode_menu).'">'.$v['header'].'</label>';
		if (array_key_exists('children', $v))
		{
			$html .= create_all_menu_list($v['children'], $explode_menu);
		}
		else{}
		$html .= "</li>";
	}
	$html .= "</ul>";
	return $html;
}

function hasChild($id){	
	$coni = connection();
	$sql = "SELECT COUNT(*) AS total FROM menuitem WHERE parent_menuid = ? ";
	$result = $coni->prepare($sql);
	$result->bind_param('i',$id);
	$result->execute();
	$result->bind_result($total);
	$result->fetch();
	$coni->close();
	
	return $total;	
}

function menu_items(){
	$user_details = getUserDetails($_SESSION['ADMIN_NAME']);
	$coni = connection();	
    $sql = "SELECT m.menuid, m.header, m.parent_menuid, m.pagename FROM grouprole g INNER JOIN menuitem m ON FIND_IN_SET(m.menuid, g.menu) WHERE g.groupid = '".$user_details['role']."'";
	//echo $sql;
	$query = $coni->query($sql);
	
	$refs = array();
    // create and array to hold the list
    $list = array();
	
	while($data = $query->fetch_assoc())
    {
        $thisref = &$refs[ $data['menuid'] ];
        $thisref['parent_menuid'] = $data['parent_menuid'];
        $thisref['header'] = $data['header'];
		$thisref['pagename'] = $data['pagename'];
		$thisref['menuid'] = $data['menuid'];

        if ($data['parent_menuid'] == 0)
        {
            $list[ $data['menuid'] ] = &$thisref;
        }
        else
        {
            $refs[ $data['parent_menuid'] ]['children'][ $data['menuid'] ] = &$thisref;
        }
    }	
	return $list;
}

function create_menu( $arr, $class )
{
	if($class == 0){
		$ulclass = 'sidebar-menu';
		$liclass = 'treeview';
		$istart = '<i class="fa fa-table"></i>';		
	}
	if($class == 1){
		$ulclass = 'treeview-menu';
		$liclass = '';
		$istart = '<i class="fa fa-circle-o"></i>';		
	}	
	
	$html = "<ul class=".$ulclass.">";
	foreach ($arr as $key=>$v) 
	{
		$child1 = hasChild($v['menuid']);
		
		$html .= '<li class='.$liclass.'><a href='.$v['pagename'].'>'.$istart.'<span>'.$v['header'].'</span>';
		if($child1>0){
			$html .= '<i class="fa fa-angle-left pull-right"></i>';
		}
		$html .='</a>';
		if (array_key_exists('children', $v))
		{
			$html .= create_menu($v['children'], 1);
		}
		else{}
		$html .= "</li>";
	}
	$html .= "</ul>";
	return $html;
}

function pssidebar(){
	
?>	
	<aside class="main-sidebar">
	<!-- sidebar: style can be found in sidebar.less -->
		<section class="sidebar">
		<!-- Sidebar user panel -->
			<div class="user-panel">
				<div class="pull-left image"><img src="dist/img/user3.png" class="img-circle" alt="User Image"></div>
				<div class="pull-left info"><p><?php echo $_SESSION['NAME']; ?></p></div>
			</div>
		<!-- sidebar menu: : style can be found in sidebar.less -->
		<?php 
			$menu_items = menu_items();
			echo create_menu( $menu_items,0);
		?>
		</section>
	<!-- /.sidebar -->
	</aside>	
<?php
}

function psheader(){ ?>
<header class="main-header">
        <!-- Logo -->
        <a href="home.php" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><img src="dist/img/logo-icon.png"/></span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><img src="dist/img/logo3.png" /></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="dist/img/user3.png" class="user-image" alt="User Image">
                  <span class="hidden-xs"><?php echo $_SESSION['NAME']; ?></span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                    <img src="dist/img/user3.png" class="img-circle" alt="User Image">
                    <p>
                      <?php echo $_SESSION['NAME']; ?>
                      <small>Member since Nov. 2012</small>
                    </p>
                  </li>
                  <!-- Menu Body  -->
                  
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-left">
                      <a href="#" class="btn btn-default btn-flat">Profile</a>
                    </div>
                    <div class="pull-right">
                      <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                    </div>
                  </li>
                </ul>
              </li>
              <!-- Control Sidebar Toggle Button -->
              
            </ul>
          </div>
        </nav>
      </header>	
<?php
}

function checkarray($item,$array){
	if(in_array($item,$array)){
		return 'checked';
	}else{
		return 'unchecked';
	}
}

?>
