<?php
//echo 'sdhfksjdf';die();
error_reporting(E_ERROR);
/*
include("adminconfig_new.php");

$PRO_TITLE='BIZCRM';
$MANDATORY="<font color='red'>*</font>";
$MAND_INSTRUCTION="<label style='float:right'>Fields marked with a asterisk (<font color='red'>*</font>) are mandatory.</span>";

session_start();
	
ps_auth();
	
function ps_auth(){
	
	if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
	{
		$rdirA = '';
		header("location: ".$rdirA."index.php");
		exit();
	}
	
	$pagename1 = basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']);
	
	$coni = connection();
	
	$sql21 = "SELECT COUNT(*) AS total FROM grouprole g INNER JOIN menuitem m ON FIND_IN_SET(m.menuid, g.menu) INNER JOIN adminuser a ON g.groupid = a.role WHERE a.username = '".$_SESSION['ADMIN_NAME']."' AND m.pagename = '".$pagename1."' ";
	
	$result21=$coni->prepare($sql21);
	$result21->execute();
	$result21->bind_result($total);
	$result21->fetch();
	
	if($total <= 0)
	{
		header("location: ".$rdirA."access-denied.php");	
		exit();
	}
	$coni->close();	
}


?>
