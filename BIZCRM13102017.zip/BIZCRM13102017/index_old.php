<?php session_start(); 
error_reporting(E_ERROR);
ini_set('display_errors', 0);
?>
<!DOCTYPE html>
<html lang="en">
 
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>BIZCRM</title>

    <!-- Bootstrap core CSS -->

    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styling plus plugins -->
    <link href="dist/css/form.css" rel="stylesheet">
    
    <style>
	body {
		color: #73879C;
		background:url(dist/img/bg8.jpg) no-repeat center center fixed;
		-webkit-background-size: cover;
		-moz-background-size: cover;
		-o-background-size: cover;
		background-size: cover;
    }
	</style>
	
<script language="javascript" type="text/javascript">
	function encode64(data){

		var b64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
		var o1, o2, o3, h1, h2, h3, h4, bits, i = 0,
		ac = 0,
		enc = "",
		tmp_arr = [];

		if (!data) {
		return data;
		}

		do { // pack three octets into four hexets
			o1 = data.charCodeAt(i++);
			o2 = data.charCodeAt(i++);
			o3 = data.charCodeAt(i++);

			bits = o1 << 16 | o2 << 8 | o3;

			h1 = bits >> 18 & 0x3f;
			h2 = bits >> 12 & 0x3f;
			h3 = bits >> 6 & 0x3f;
			h4 = bits & 0x3f;

			// use hexets to index into b64, and append result to encoded string
			tmp_arr[ac++] = b64.charAt(h1) + b64.charAt(h2) + b64.charAt(h3) + b64.charAt(h4);
		} while (i < data.length);

		enc = tmp_arr.join('');

		var r = data.length % 3;

		return (r ? enc.slice(0, r - 3) : enc) + '==='.slice(r || 3);

	}
	
	function validation(){
		if(document.getElementById('username').value == ''){
			alert('Please enter username!');
			document.getElementById('username').focus();
			return false;
		}else if(document.getElementById('password').value == ''){
			alert('Please enter password!');
			document.getElementById('password').focus();
			return false;
		}else{
			//alert('return true!');
			return true;
		}
	}

</script>
    
</head>

<body>

	<nav class="navbar navbar-default lognav" role="navigation">
    	<a class="lognav-brand" href="#"><img src="dist/img/logo3.jpg" /></a>
    <!-- Collect the nav links, forms, and other content for toggling -->
    </nav>
    
    <div class="wrapper">
			
			<div class="content">
				<div id="form_wrapper" class="form_wrapper">
					
					<form class="login active" name="bizcrmlogin" id="bizcrmlogin" method="post" action="postlogin6.php" >
						<h4>Login</h4>
						<?php if($_GET['flag']=="I") { ?><div><label style='color:red'>Incorrect Login ID or Password</label></div><?php } ?>

						<div>
							<label>Username:</label>
							<input type="text" name="username" class="form-control" id="username" autocomplete="off" value="" />
							<span class="error">This is an error</span>
						</div>
						<div>
							<label>Password: </label>
							<input type="password" name="password" class="form-control" id="password" autocomplete="off" value="" />
							<input name="ipaddress" type="hidden" class="form-control" id="ipaddress" value="<?php echo $_SERVER['REMOTE_ADDR'];?>" >
							<span class="error">This is an error</span>
						</div>
						<div class="bottom">
							<input type="submit" name="submit" id="submit" onclick="return validation();" value="Login" style="float:left" />
							<div class="clear"></div>
						</div>
					</form>
					
				</div>
				<div class="clear"></div>
			</div>
			
		</div>
        
<script language="javascript" type="text/javascript">
	document.bizcrmlogin.username.focus();
</script>    
</body>

</html>