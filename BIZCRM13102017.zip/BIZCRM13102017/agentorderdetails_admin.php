<?php 
	
	require_once('class/class.orderdetails.php');
	
	$objord = new Orderdetails();
	$alldata = $objord->getAgentAssignedDataAdmin();
	
	if($_REQUEST['task'] == 'addOrdernotes')
	{
		$notes = $objcus->addOrdernote($_REQUEST['order_note'],trim($_REQUEST['order_id']),trim($_REQUEST['agent_id']),trim($_REQUEST['ipaddress']));
		foreach($notes as $n)
		{
			$html.="<div class='col-lg-4'>".$n['order_notes']."</div><div class='col-lg-4'>".$n['notes_date']."</div><div class='col-lg-4'>".$n['agent_id']."</div>";
		}
		echo $html;
		exit;
	}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>BIZCRM | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Bootstrap time Picker -->
    <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="dist/css/dataTables.bootstrap.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
    <!-- Date Picker -->
    <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />
	<link rel="stylesheet" href="date/jquery-ui.css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
         <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<script>
		
		function getnotes(id,order_no){

			var  order_id = order_no;
			//var note = $("#order_note"+id).val();

			var task = 'getnotes';
			$.ajax({
				type: "GET",
				url: "ajax.php",
				data: {task:task,order_id:order_id},

				success: function(data){
					console.log(data);
					$("#dordernotes"+id).html('');
					$("#order_note"+id).val('');
					$("#dordernotes"+id).html(data);					
					return false;
				}
			});
			return false;
		}
		
		function getOrderbyno(order_no){
			var  order_id = order_no;
			var task = 'getOrderbyno';
			$.ajax({
				type: "GET",
				url: "ajax.php",
				data: {task:task,order_id:order_id},

				success: function(data){
					console.log(data);
					$("#orderdata"+order_no).html('');
					$("#orderdata"+order_no).html(data);
					return false;
				}
			});
			return false;
		}
		
	function addOrdernotes(id){
		var status= $("#status"+id).val();
		var order_id= $("#order_id"+id).val();
		var agent_id = $("#agent_id"+id).val();
		var ipaddress= $("#ipaddress").val();
		var note = $("#order_note"+id).val();
		var task = 'addOrdernotes';
		$.ajax({
			type: "GET",
			url: "ajax.php",
			data: {order_note:note,task:task,order_id:order_id,agent_id:agent_id,ipaddress:ipaddress,status:status},
			success: function(data){
				console.log(data);
				$("#dordernotes"+id).html('');
				$("#order_note"+id).val('');
				$("#dordernotes"+id).html(data);
				return false;
			}
		});

		return false;
	}
		
    </script>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
 <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objord->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objord->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
          <!-- Main content -->
		<section class="content-header">
          <h1>
            Customer Order Details
          </h1>
            <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Customer Order Details</li>
          </ol>
        </section><!--CONTENT HEADER-->
        <section class="content">
            
			<div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                    <div class='box-header'><h3 class="box-title">Customer Details</h3></div>
						<div class='box-body table-responsive'>
							<table id="OrderPackages" class="table table-bordered table-striped">
							
							<tbody>
							<thead>
							<tr style="background-color:#2A3F54;color:#fff;">
								<th></th>
								<th>Order No</th>
								<th>Customer ID</th>
								<th>Customer Name</th>
								<th>Order Date</th>
								<th>Delivery Due Date</th>
							</tr>
							</thead>
						<?php for($i=0; $i<count($alldata); $i++) { ?>	
							
							
								<tr style="background-color:#E4E4E4;" > 	
									<td style='border: 1px solid;display: inline-block;position: relative;top: 1px;left: 5px;' class="accordion-toggle" data-toggle="collapse" data-parent="#OrderPackages" data-target=".packageDetails<?php print $alldata[$i]['id']; ?>"><i class="indicator glyphicon pull-right glyphicon-chevron-down"></i></td>
									
									<td><a href="#" data-toggle="modal" data-target="#orderdetails" onclick='getOrderbyno("<?php print $alldata[$i]['orderno']; ?>")'><?php print $alldata[$i]['orderno']; ?></a></td>
									
									<td><a href="#" id="addpayment" data-toggle="modal" data-target="#getCutomerbyId" onclick='getCutomerbyId("<?php print $alldata[$i]['customer_id']; ?>")'><?php print $alldata[$i]['customer_id']; ?></a></td>
									
									<td><?php print $alldata[$i]['salutation']; ?> <?php print $alldata[$i]['name_first']; ?> <?php print $alldata[$i]['name_last']; ?></td>
									
									<td><?php print $alldata[$i]['order_date']; ?></td>
									
									<td><?php print $alldata[$i]['delivery_due_date']; ?></td>
								</tr>
								
								<?php 
								$Orderdata = $objord->getAssignedByOrderNo($alldata[$i]['orderno']);
							  
								if(count($Orderdata)) 
								{ ?>
								<tr><td colspan='6' style="padding: 0px !important;">
								<table id="OrderPackages1" class="table table-bordered table-striped packageDetails<?php print $alldata[$i]['id']; ?> collapse" width='100%'>
							    <thead>
								<tr style="background-color:#D4AE87;">
									<th><b>Agent ID</b></th>
									<th><b>Name</b></th>
									<th><b>Order No</b></th>									
									<th><b>Order Date</b></th>
									<th><b>Task Details</b></th>									
									<th><b>Action</b></th>
								</tr>	
								</thead>
								<tbody>
								<?php	
								
								foreach($Orderdata as $data)
                                { ?>	
									<tr style="background-color:#EFD8C1;">
										<td><?php echo $data['agent_id']; ?></td>
										<td><?php echo $data['name']; ?></td>
										<td><?php echo $data['orderno']; ?></td>
										<td><?php echo $data['order_date']; ?></td>
										<td><?php echo $data['task_details']; ?></td>
										<td><a data-toggle="modal" data-target="#ordernotes<?php echo $data['id']; ?>" onclick='getnotes("<?php echo $data['id']; ?>","<?php echo $data['orderno']; ?>")'>Notes</a></td>										
									</tr>
									
									<div class="modal fade" id="ordernotes<?php echo $data['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="ordernotes<?php echo $data['id']; ?>">
										<div class="modal-dialog" role="document">
										<form method="post" name="payment" id="payment">
										<div class="modal-content">
										<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<h4 class="modal-title" id="myModalLabel">Order Notes</h4>
										</div>
										<div class="modal-body">
										<div class="row">
										<div class="col-lg-12">
										<div class='table table-bordered table-striped' >
											<div class="col-lg-12">
												<div id='dordernotes<?php echo $data['id']; ?>' class='orderdiv'></div>
											</div>
										</div>
										<div class="form-group">
										<label for="name">Enter Notes</label>
										<textarea  class="form-control" id="order_note<?php echo $data['id']; ?>" name="order_note" placeholder="Enter Notes"></textarea>
										</div>
										<div class="form-group">
											<label for="name">Delivery Status</label>
											<select class="form-control" id="status<?php echo $data['id']; ?>" name="status" style="width:33%;" tabindex="-1" required>
											<option value="2" selected>Pending</option>
											<option value="1">Incomplete</option>
											<option value="3">Processed</option>
											<option value="4">Partially Shipped</option>
											<option value="5">Shipping</option>
											<option value="6">Shipped</option>
											<option value="7">Partially Returned</option>
											<option value="8">Returned</option>
											<option value="9">Cancelled</option>
											</select>
										</div>
										
										<div class="form-group">
										<label for="name">Agent ID</label>
										<?php echo $data['name'].' ('.$data['agent_id'].')'; ?>
										<input type="hidden" name="agent_id"  id="agent_id<?php echo $data['id']; ?>" class="btn btn-warning left-10" value="<?php echo $data['agent_id']; ?>" />
										</div>

										</div><!-- /.col -->                             
										
										</div><!-- /.row -->
										</div>
										<div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
										<input type="hidden" name="order_id"  id="order_id<?php echo $data['id']; ?>" class="btn btn-warning left-10" value="<?php echo  $data['orderno']; ?>" />
										
										<input name="ipaddress" type="hidden" id="ipaddress" value="<?php echo $_SERVER['REMOTE_ADDR'];?>" >

										<input type="button" class="btn btn-primary" name="savePayment" id="savePayment" value="Save" onclick='addOrdernotes("<?php echo $data['id']; ?>");'/>
										</div>
										</div>
										</form>
										</div>
									</div>
									
								<?php } ?>
										</tbody>
									</table>
						</td>
							 </tr>
								<?php	}else{ ?>				
								<tr><td colspan='6' style="padding: 0px !important;">
								<table id="OrderPackages1" class="table table-bordered table-striped packageDetails<?php print $alldata[$i]['id']; ?> collapse" width='100%'>
							    <tr style="background-color:#D4AE87;">
									<th><b>No Record Found!</b></th>
								</tr></table>
								</td></tr>
						<?php } } ?>
								</tbody>									
							</table>
							</div>
							
							
							
			
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
			  
        </section><!--CONTENT-->
      </div><!-- /.content-wrapper -->
      
<!-- Customer Popup Info-->
<div class="modal fade" id="getCutomerbyId" tabindex="-1" role="dialog" aria-labelledby="getCutomerbyIdLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Customer Details </h4>
			</div>
			
			<div class="modal-body">
				<div class="row">
					<div id="getCustomer">

					</div><!-- /.col -->
				</div><!-- /.row -->
			</div>
			
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>		
		</div>
	</div>
</div>

	
<div class="modal fade" id="orderdetails" tabindex="-1" role="dialog" aria-labelledby="orderdetailsLabel">
	<div class="modal-dialog" role="document">	
	<div class="modal-content">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Order Details </h4>
		</div>
		<div class="modal-body">
			<div class="row">
				<div class="col-lg-12" id="orderdata">


				</div><!-- /.col -->
			</div><!-- /.row -->
		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		</div>
	</div>	
	</div>
</div>
	<!-- Customer Popup Info-->
      <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->
	<script>
function getOrderbyno(order_no){
	var  order_id = order_no;
	var task = 'getOrderbyno';
	$.ajax({
		type: "GET",
		url: "ajax.php",
		data: {task:task,order_id:order_id},

		success: function(data){
			console.log(data);
			$("#orderdata").html('');
			$("#orderdata").html(data);
			return false;
		}
	});

	return false;
}

function getCutomerbyId(cust_id){
	var task = 'getCustomer';
	$.ajax({
		type: "GET",
		url: "ajax.php",
		data: {task:task,cust_id:cust_id},
		success: function(data){
			console.log(data);
			$("#getCustomer").html('');
			$("#getCustomer").html(data);
			return false;
		}
	});
	return false;
}

	</script>
    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
    <!-- DataTables -->
    <script src="dist/js/jquery.dataTables.js"></script>
    <script src="dist/js/dataTables.bootstrap.min.js"></script>
    <script>

	$(function () {
		$('#example111').DataTable({
			"bPaginate": true,
			"bFilter": true,
			"bInfo": true
		});
	});
	$("#message").fadeIn('slow').delay(5000).fadeOut('slow');
    </script> 
    
    <!-- daterangepicker -->
    <script src="dist/js/moment.min.js"></script>
    <!-- bootstrap time picker -->
    <script src="plugins/timepicker/bootstrap-timepicker.js"></script>
    <!-- iCheck 1.0.1 -->
    <script src="plugins/iCheck/icheck.min.js"></script>
    <script src="plugins/daterangepicker/daterangepicker.js"></script>
    <!-- datepicker -->
    <script src="plugins/datepicker/bootstrap-datepicker.js"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js"></script>
    
    <script type="text/javascript" src="plugins/datepicker/bootstrap-clockpicker.min.js"></script>
    
    <script type="text/javascript" src="dist/js/date.js"></script>
    
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    
	
  </body>
</html>