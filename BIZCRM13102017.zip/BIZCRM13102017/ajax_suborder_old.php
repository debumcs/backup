<?php 
require_once('class/class.customer.php');
$objCus = new Customer();
require_once('class/class.orderdetails.php');
$objord = new Orderdetails();
require_once('class/class.fabric.php');
$objfabric = new Fabric();
$allfabric = $objfabric->getAll();
require_once('class/class.stylemaster.php');
$objstyle = new Stylemaster();
$allstyle = $objstyle->getAll();
require_once('class/class.salesman.php');
$objsalesman = new Salesman();
$allsalesman = $objsalesman->getAll();

require_once('class/class.statusmaster.php');
require_once('class/class.agencymaster.php');

require_once('class/class.items.php');
$objitem = new item();

if($_REQUEST['task'] == 'getFabricUnits')
{
	$indexid = $_REQUEST['indexid'];
	$fabricid = $_REQUEST['fabricid'];
	$data = $objfabric->getById($fabricid);
	echo '<input type="hidden" name="units[]" id="units_'.$indexid.'" value="'.$data['units'].'" />(Units in '.$data['units'].')';
	exit;		
}


if(isset($_POST['task']) && $_POST['task'] == 'moveToRegular')
{
	$id 		= $_REQUEST['id'];
	$success 	= $objord->moveToRegularStyle($id);
	if($success){
		echo 'OK';
	}else{
		echo 'Error';
	}
	exit;
}

if (isset($_POST["task"]) and ($_POST["task"] == 'fileupload')) {
	$file = $_FILES['image'];
	/* Allowed file extension */
	$allowedExtensions = ["gif", "jpeg", "jpg", "png", "svg"];
	$fileExtension = explode(".", $file["name"]);
	/* Contains file extension */
	$extension = end($fileExtension);
	/* Allowed Image types */
	$types = ['image/gif', 'image/png', 'image/x-png', 'image/pjpeg', 'image/jpg', 'image/jpeg','image/svg+xml'];
	if(in_array(strtolower($file['type']), $types) && in_array(strtolower($extension), $allowedExtensions) && !$file["error"] > 0)
	{ 
		if(move_uploaded_file($file["tmp_name"], 'styleimage/'.$file['name'])){
			echo '<img src="styleimage/'.$file['name'].'" width="200" />';
			echo '<input type="hidden" name="imagename_hidden" id="imagename_hidden" value="'.$file['name'].'" />
				<input type="hidden" name="imagelocation_hidden" id="imagelocation_hidden" value="styleimage/'.$file['name'].'" />';
		}else{
			echo 'Unable to move image. Is folder writable?';    
		}
	}else{    
		echo 'Please upload only png, jpg images';
	}
}

if(isset($_POST['task']) && $_POST['task'] == 'getCustomizedSelectedStyle'){
	$stylecode 	= $_REQUEST['stylecode'];
	$data = $objstyle->getCustomizedStyleDetails($stylecode);
	
?>
<fieldset class="fsStyle">
	<legend class="legendStyle">
		<a data-toggle="collapse" data-target="#demo" href="#">Selected Style Details <i class="fa fa-sort" aria-hidden="true"></i></a>
	</legend>
<div class="row collapse in" id="demo">
	<div class="row ">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Style Code</label><?php echo $MANDATORY; ?>
				<input type="text" class="form-control" readonly value="<?php echo $data['style_code']; ?>">
			</div>
		</div>
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Description</label><?php echo $MANDATORY; ?>
				<input type="text" class="form-control" readonly value="<?php echo $data['description']; ?>">
			</div>
		</div>
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Style Group Code</label>
				<input type="text" class="form-control" readonly value="<?php echo $data['style_group_code']; ?>">
			</div>
		</div>
	</div><!-- /.col -->
	
	<div class="row">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Designer Code</label>
				<input type="text" class="form-control" readonly value="<?php echo $data['designer_code']; ?>">
			</div>
		</div>
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Cost Price</label>
				<input type="text" class="form-control" readonly value="<?php echo $data['cost_price']; ?>" >
			</div>
		</div>
		
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Recommended Selling Price</label>
				<input type="text" class="form-control"  readonly value="<?php echo $data['selling_price']; ?>">
			</div>
		</div>
		
	</div><!-- /.col -->
	<div class="row">
		<div class="col-lg-6">
			<div class="form-group">
				<label for="name">Picture</label><?php echo $MANDATORY; ?>&nbsp;
				<img src="<?php echo $data['imagelocation']; ?>" width="150"/>
			</div>
		</div>
	</div><!-- /.col -->
</div>
</fieldset>
<?php
	exit;
}

if(isset($_POST['task']) && $_POST['task'] == 'getSelectedStyle'){
	$stylecode 	= $_REQUEST['stylecode'];
	$data = $objstyle->getStyleDetails($stylecode);
	
?>
<fieldset class="fsStyle">
	<legend class="legendStyle">
		<a data-toggle="collapse" data-target="#demo" href="#">Selected Style Details <i class="fa fa-sort" aria-hidden="true"></i></a>
	</legend>
<div class="row collapse in" id="demo">
	<div class="row ">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Style Code</label><?php echo $MANDATORY; ?>
				<input type="text" class="form-control" readonly value="<?php echo $data['style_code']; ?>">
			</div>
		</div>
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Description</label><?php echo $MANDATORY; ?>
				<input type="text" class="form-control" readonly value="<?php echo $data['description']; ?>">
			</div>
		</div>
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Style Group Code</label>
				<input type="text" class="form-control" readonly value="<?php echo $data['style_group_code']; ?>">
			</div>
		</div>
	</div><!-- /.col -->
	
	<div class="row">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Designer Code</label>
				<input type="text" class="form-control" readonly value="<?php echo $data['designer_code']; ?>">
			</div>
		</div>
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Cost Price</label>
				<input type="text" class="form-control" readonly value="<?php echo $data['cost_price']; ?>" >
			</div>
		</div>
		
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Recommended Selling Price</label>
				<input type="text" class="form-control"  readonly value="<?php echo $data['selling_price']; ?>">
			</div>
		</div>
		
	</div><!-- /.col -->
	<div class="row">
		<div class="col-lg-6">
			<div class="form-group">
				<label for="name">Picture</label><?php echo $MANDATORY; ?>&nbsp;
				<img src="<?php echo $data['imagelocation']; ?>" width="150"/>
			</div>
		</div>
	</div><!-- /.col -->
</div>
</fieldset>
<?php
	exit;
}

if(isset($_POST['task']) && $_POST['task'] == 'getAutoNumber')
{
	$assignstatus 	= $_POST['assignstatus'];
	$agencyid 		= $_POST['agencyid'];
	if($agencyid != ''){
		$objStatus 		= new Statusmaster();
		$objagency 		= new Agencymaster();
		
		$checkautochallan = $objStatus->getById($assignstatus);
		
		if($checkautochallan['autochallan'] == 'Yes'){
			$agencyname = $objagency->getById($agencyid);
			$arr = $objagency->initials($agencyname['agencyname']);

			$name = preg_replace('/[^A-Za-z0-9\-]/', '', $arr);
			
			$lastid = $objitem->getLastIDSuborderItems();
			$challanno = $name.str_pad((intval($lastid['id']) + 1), 5, "0", STR_PAD_LEFT);
			echo $challanno;
		}else{
			echo 'No';
		}
	}else{
		echo 'No';
	}
	exit;
}

if(isset($_POST['task']) && $_POST['task'] == 'delOrderbyno')
{
	$order_no = $_POST['order_no'];
	$objord->deleteOrder($order_no);
	exit();
}

if($_REQUEST['task'] == 'getfabricdetails')
{
	$fabricid = $_REQUEST['fabricid'];
	$data = $objfabric->getById($fabricid);
?>
<div class="row">							
	<div class="col-lg-12">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Fabric Name</label>
			</div>
		</div><!-- /.col -->
		
		<div class="col-lg-8">
			<div class="form-group">
				<?php echo $data['fabricname']; ?>
			</div>
		</div><!-- /.col -->
	</div>
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Description</label>
			</div>									  
		</div><!-- /.col -->
		
		<div class="col-lg-8">							
			<div class="form-group">
				<?php echo $data['description'];?>
			</div>									  
		</div><!-- /.col -->		
	</div>
	<div class="col-lg-12">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Preferred Vendor Name</label>
			</div>	
		</div><!-- /.col -->
		
		<div class="col-lg-8">
			<div class="form-group">
				<?php echo $data['preferred_vendor_name'];?>
			</div>	
		</div><!-- /.col -->
	</div>
	
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Last Price</label>
			</div>
		</div><!-- /.col -->
		
		<div class="col-lg-8">										
			<div class="form-group">
				<?php echo $data['last_price'];?>
			</div>
		</div><!-- /.col -->		
	</div>
	
	<div class="col-lg-12">
		<div class="col-lg-4">
			<div class="form-group">
			<label for="name">Fabric Type</label>
			</div>	
		</div><!-- /.col -->		
		<div class="col-lg-8">
			<div class="form-group">
			<?php echo $data['fabric_type'];?>
			</div>	
		</div><!-- /.col -->
	</div>
			
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Image</label>
			</div>
		</div><!-- /.col -->
		<div class="col-lg-8">										
			<div class="form-group">
				<img src="<?php echo $data['fabric_image'];?>" width="100">
			</div>
		</div><!-- /.col -->
	</div>
	
</div><!-- /.row -->
<?php
	exit;	
}

if($_REQUEST['task'] == 'styledetails')
{
	$stylecode = $_REQUEST['stylecode'];
	$data = $objstyle->getStyleDetails($stylecode);
?>
<div class="row">							
	<div class="col-lg-12">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Style Code</label>
			</div>
		</div><!-- /.col -->
		
		<div class="col-lg-8">
			<div class="form-group">
				<?php echo $data['style_code']; ?>
			</div>
		</div><!-- /.col -->
	</div>
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Description</label>
			</div>									  
		</div><!-- /.col -->
		
		<div class="col-lg-8">							
			<div class="form-group">
				<?php echo $data['description'];?>
			</div>									  
		</div><!-- /.col -->		
	</div>
	<div class="col-lg-12">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Style Group Code</label>
			</div>	
		</div><!-- /.col -->
		
		<div class="col-lg-8">
			<div class="form-group">
				<?php echo $data['style_group_code'];?>
			</div>	
		</div><!-- /.col -->
	</div>
	
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Designer Code</label>
			</div>
		</div><!-- /.col -->
		
		<div class="col-lg-8">										
			<div class="form-group">
				<?php echo $data['designer_code'];?>
			</div>
		</div><!-- /.col -->		
	</div>
	
	<div class="col-lg-12">
		<div class="col-lg-4">
			<div class="form-group">
			<label for="name">Creation Date</label>
			</div>	
		</div><!-- /.col -->		
		<div class="col-lg-8">
			<div class="form-group">
			<?php echo $data['creation_date'];?>
			</div>	
		</div><!-- /.col -->
	</div>
			
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Price</label>
			</div>			  
		</div><!-- /.col -->
		
		<div class="col-lg-8">										
			<div class="form-group">
				<?php echo $data['selling_price'];?>
			</div>			  
		</div><!-- /.col -->
	</div>
			
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Image</label>
			</div>
		</div><!-- /.col -->
		<div class="col-lg-8">										
			<div class="form-group">
				<img src="<?php echo $data['imagelocation'];?>" width="100">
			</div>
		</div><!-- /.col -->
	</div>
	
</div><!-- /.row -->
<?php
	exit;	
}

if($_REQUEST['task'] == 'getRecomandedPrice')
{
	$stylecode 	= $_REQUEST['stylecode'];
	$RecomandedPrice = $objord->getRecomandedPrice($stylecode);
	echo $RecomandedPrice;
	exit;		
}

if($_REQUEST['task'] == 'getCustomizedRecomandedPrice')
{
	$stylecode 	= $_REQUEST['stylecode'];
	$RecomandedPrice = $objord->getCustomizedRecomandedPrice($stylecode);
	echo $RecomandedPrice;
	exit;		
}

if($_REQUEST['task'] == 'getAgencyByStatus')
{
	$statusid 	= $_REQUEST['statusid'];
	$objagency = new Agencymaster();
	
	$allAgencyByStatus = $objagency->getAgencyByStatus($statusid);
	echo '<select id="agencyid" class="form-control input-sm" name="agencyid" onchange="checkchallanno();">';
	echo '<option selected value="">Select Agency</option>';
	for($i=0; $i<count($allAgencyByStatus); $i++){ 
?>
	<option value="<?php echo $allAgencyByStatus[$i]['id']; ?>"><?php echo $allAgencyByStatus[$i]['agencyname']; ?></option>
<?php }
	echo '</select>';
	exit;		
}

if($_REQUEST['task'] == 'allagencytype')
{
	$agencyVal 	= $_REQUEST['agencyVal'];
	$typeVal 	= $_REQUEST['typeVal'];
	$id 		= $_REQUEST['id'];
	$objagency = new Agencymaster();
	
	$allagency = $objagency->getAllAgencyByType($agencyVal,$typeVal);
	$allmappedstatus = $objagency->allmappedstatus($id);
	for($i=0; $i<count($allagency); $i++){ 
?>
<tr>
	<td><input type="checkbox" style="display:block;" <?php if (in_array($allagency[$i]['id'], $allmappedstatus)){echo "checked";} ?> name="mappinglist[]" class="checkbox" value="<?php print $allagency[$i]['id'];?>"/></td>
	<td><?php print $allagency[$i]['agencyname']; ?></td>
</tr>
<?php } 	
	exit;		
}

if($_REQUEST['task'] == 'getOrderbyno')
{
	$order_id = $_REQUEST['order_id'];
	$data = $objord->getorderDetailByorderID($order_id);
	$orderpayment = $objord->get_order_payemt_amount($order_id);
?>
<div class="row">							
	<div class="col-lg-12">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Order No</label><br/>
				<?php echo $data['orderno']; ?>
			</div>
		</div><!-- /.col -->
		
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Customer ID</label><br/>
				<?php echo $data['customer_id'];?>
			</div>									  
		</div><!-- /.col -->
		
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Order Details</label><br/>
				<?php echo $data['order_detail'];?>
			</div>	
		</div><!-- /.col -->
	</div>
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Quantity</label><br/>
				<?php echo $data['quantity'];?>
			</div>
		</div><!-- /.col -->
		
		<div class="col-lg-4">
			<div class="form-group">
			<label for="name">Order Date</label><br/>
			<?php echo $data['order_date'];?>
			</div>	
		</div><!-- /.col -->

		<div class="col-lg-4">
			<div class="form-group">
			<label for="name">Sale Person</label><br/>
			<?php echo $data['sale_person'];?>
			</div>	
		</div><!-- /.col -->
	</div>	
			
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Bill Number</label><br/>
				<?php echo $data['billno'];?>
			</div>			  
		</div><!-- /.col -->
		
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Alt Order No</label><br/>
				<?php echo $data['alt_order_no'];?>
			</div>			  
		</div><!-- /.col -->
		
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Order Status</label><br/>
				<?php echo $data['orderstatus'];?>
			</div>
		</div><!-- /.col -->
		
	</div>
			
	<div class="col-lg-12">									
	
		<div class="col-lg-4">										
			<div class="form-group">
			  <label for="name">Gross Sale Amount</label><br/>
			  <a href="#"><?php echo $orderpayment['original_amount']; ?></a>
			</div>								  
		</div><!-- /.col -->

		<div class="col-lg-4">										
			<div class="form-group">
			  <label for="name">Net Sale amount</label><br/>
			  <a href="#"><?php echo $orderpayment['sale_amount']; ?></a>
			</div>									  
		</div><!-- /.col -->
		<div class="col-lg-4">
			<div class="form-group">
			  <label for="name">Amount received </label><br/>
			  <a href="#"><?php echo $orderpayment['received_amount']; ?></a>
			</div>
		</div>
		
	</div>
	
</div><!-- /.row -->
<?php
	exit;	
}
/* deleted code */
/*
if($_REQUEST['task'] == 'ViewAgency')
{
	$suborderno = $_REQUEST['suborderno'];
	$alldata = $objord->getSuborderById($suborderno);	
?>							
	<div class="row">
		<div class="col-lg-12">
			<div class="col-lg-4">
				<div class="form-group">
					<label for="name">Challan No</label>
					<input type="text" id="dychallanno" tabindex="1" name="dychallanno" <?php echo $dyreadonly; ?> class="form-control" value="<?php echo $dyerinfo['dychallanno']; ?>" />
					<input type="hidden" id="id" name="id" class="form-control" value="<?php echo $dyerinfo['id']; ?>" />
					<input type="hidden" id="orderno" name="orderno" class="form-control" value="<?php echo $orderno; ?>" />
					<input type="hidden" id="suborderno" name="suborderno" class="form-control" value="<?php echo $suborder; ?>" />
				</div>
			</div><!-- /.col -->

			<div class="col-lg-4">										
				<div class="form-group">
				  <label for="name">Details</label>
				  <input type="text" class="form-control" tabindex="2" id="dydetails" <?php echo $dyreadonly; ?> name="dydetails" placeholder="Enter details" value="<?php echo $dyerinfo['dydetails']; ?>">
				</div>									  
			</div><!-- /.col -->
			
			<div class="col-lg-4">										
				<div class="form-group">
				  <label for="name">Dyer ID</label>
					<select class="form-control select2" tabindex="3" <?php echo $dydisable; ?> id="dyerid" name="dyerid" style="width:100%;">
					<option value="" selected>Select</option>
					<?php 				
					for($dyi=0; $dyi<count($allagent); $dyi++) {
						if($allagent[$dyi]['type'] == 'Dying'){ 
							if($dyerinfo['dyerid'] == $allagent[$dyi]['id']){$selected = 'selected';}
							echo "<option value='".$allagent[$dyi]['id']."' $selected>".$allagent[$dyi]['agencyname']."</option>"; 
						}
					}
					?>
					</select>
				</div>									  
			</div><!-- /.col -->
		</div>
		
		<div class="col-lg-12">
			<div class="col-lg-4">
				<div class="form-group">
					<label for="name">Fabric ID</label>
					<select class="form-control select2" tabindex="4" <?php echo $dydisable; ?> id="dyfabricid" name="dyfabricid" style="width:100%;">
					<option value="" selected>Select</option>
					<?php 				
					for($fbi=0; $fbi<count($allfabricdata); $fbi++) {												
						if($dyerinfo['dyfabricid'] == $allfabricdata[$fbi]['id']){$selected = 'selected';}
						echo "<option value='".$allfabricdata[$fbi]['id']."' $selected>".$allfabricdata[$fbi]['fabricname']."</option>";
					}
					?>
					</select>
				</div>	
			</div><!-- /.col -->

			<div class="col-lg-4">										
				<div class="form-group">
					<label for="name">Quantity(in Metre)</label>
					<input type="text" class="form-control" tabindex="5" <?php echo $dyreadonly; ?> onKeyPress="return isDecimalNumber(event,this);" id="dyquantity" name="dyquantity" placeholder="Enter quantity" value="<?php echo $dyerinfo['dyquantity']; ?>">
				</div>			  
			</div><!-- /.col -->
			
			<div class="col-lg-4">										
				<div class="form-group">
					<label for="name">Dying Color</label>
					<input type="text" class="form-control" tabindex="6" <?php echo $dyreadonly; ?> id="dying_color" name="dying_color" placeholder="Enter dying color" value="<?php echo $dyerinfo['dying_color']; ?>">
				</div>			  
			</div><!-- /.col -->									
		</div>
		
		<div class="col-lg-12">
			<div class="col-lg-4">
				<div class="form-group">
				  <label for="name">Assign Date</label>
				  <input type="text" class="form-control datepicker" tabindex="7" <?php echo $dyreadonly; ?> id="dyassign_date" name="dyassign_date" placeholder="Enter assign date" value="<?php echo $dyerinfo['dyassign_date']; ?>">
				</div>	
			</div><!-- /.col -->

			<div class="col-lg-4">										
				<div class="form-group">
					<label for="name">Due Date</label>
					<input type="text" class="form-control datepicker" tabindex="8" <?php echo $dyreadonly; ?> id="dydue_date" name="dydue_date" placeholder="Enter due date" value="<?php echo $dyerinfo['dydue_date']; ?>">
				</div>			  
			</div><!-- /.col -->
			
			<div class="col-lg-4">										
				<div class="form-group">
					<label for="name">Receiving Date</label>
					<input type="text" class="form-control datepicker" tabindex="9" <?php echo $dyreadonly; ?> id="dyreceiving_date" name="dyreceiving_date" placeholder="Enter receiving date" value="<?php echo $dyerinfo['dyreceiving_date']; ?>">
				</div>			  
			</div><!-- /.col -->									
		</div>
		
		<?php if(count($dyerinfo) > 0){	?> 
		
		<div class="col-lg-12">
			<div class="col-lg-8">
				<div class="response"></div>	
			</div><!-- /.col -->
		</div><!-- /.col -->
		
		<div class="col-lg-12">
			<div class="col-lg-8">
				<div class="form-group">											
					<input type="button" onclick="dyingreadonly();" class="btn btn-primary" tabindex="10" name="editdying" id="editdying" value="Edit" />
					<input type="button" onclick="updateDyingInfo();" style="display:none;" tabindex="11" class="btn btn-primary" name="updatedying" id="updatedying" value="Update" />
				</div>	
			</div><!-- /.col -->
		</div><!-- /.col -->
		<?php $alldyingnotes = $objord->getallnotes('dyer',$dyerinfo['dyerid'],$suborder); ?>
		<div class="col-lg-12 orderdiv" id="notesdyer" style="max-height: 100px;">
			<?php foreach($alldyingnotes as $dyingnote){?>
			<div class="col-lg-12">
				<div class="form-group">											
						Notes	: <?php echo $dyingnote['dying_notes']; ?>
				</div>	
			</div>
			<div class="col-lg-12">
				<div class="col-lg-6">
					<div class="form-group">											
						Date	: <?php echo $dyingnote['createdon']; ?>													
					</div>
				</div>
				<div class="col-lg-6">
					<div class="form-group">											
						Status	: <?php echo $dyingnote['dystatus']; ?>
					</div>
				</div>
			</div>
			<?php } ?>
		</div><!-- /.col -->
		<?php } ?>
		
		<div class="col-lg-12">
			<div class="col-lg-8">
				<div class="form-group">
				  <label for="name">Notes</label>
				  <input type="text" class="form-control" id="dying_notes" tabindex="12" name="dying_notes" placeholder="Enter notes" value="">
				</div>	
			</div><!-- /.col -->

			<div class="col-lg-4">										
				<div class="form-group">
					<label for="name">Status</label>
					<select class="form-control select2" id="dystatus" tabindex="13" name="dystatus" style="width:100%;">
					<option value="" selected >Select Status</option>
					<option value="1" >Incomplete</option>
					<option value="2" >Pending</option>
					<option value="3" >Processed</option>
					<option value="4" >Partially Shipped</option>
					<option value="5" >Shipping</option>
					<option value="6" >Shipped</option>
					<option value="7" >Partially Returned</option>
					<option value="8" >Returned</option>
					<option value="9" >Cancelled</option>
					</select>
				</div>			  
			</div><!-- /.col -->									
		</div>  
	</div>
	
	<div class="row">
						
						<div class="col-lg-12">
							<div class="col-lg-4">
								<div class="form-group">
									<label for="name">Challan No</label>											
									<input type="text" id="emchallanno" name="emchallanno" class="form-control" tabindex="1" <?php echo $emreadonly; ?> value="<?php echo $embroinfo['emchallanno']; ?>" />
									<input type="hidden" id="id" name="id" class="form-control" value="<?php echo $embroinfo['id']; ?>" />
									<input type="hidden" id="orderno" name="orderno" class="form-control" value="<?php echo $orderno; ?>" />
									<input type="hidden" id="suborderno" name="suborderno" class="form-control" value="<?php echo $suborder; ?>" />
								</div>
							</div><!-- /.col -->

							<div class="col-lg-4">										
								<div class="form-group">
								  <label for="name">Details</label>
								  <input type="text" class="form-control" id="emdetails" name="emdetails" tabindex="2" placeholder="Enter details" <?php echo $emreadonly; ?> value="<?php echo $embroinfo['emdetails']; ?>">
								</div>									  
							</div><!-- /.col -->
							
							<div class="col-lg-4">										
								<div class="form-group">
								  <label for="name">Embroider ID</label>
								  <select class="form-control select2" id="embroiderid" <?php echo $emdisable; ?> tabindex="3" name="embroiderid" style="width:100%;">
									<option value="" selected>Select</option>
									<?php 				
									for($emi=0; $emi<count($allagent); $emi++) {
										if($allagent[$emi]['type'] == 'Embroidery'){ 		
											if($embroinfo['embroiderid'] == $allagent[$emi]['id']){$selected = 'selected';}
											echo "<option value='".$allagent[$emi]['id']."' $selected>".$allagent[$emi]['agencyname']."</option>"; 
										}
									}
									?>
									</select>
								</div>									  
							</div><!-- /.col -->
						</div>
						
						<div class="col-lg-12">
							<div class="col-lg-4">
								<div class="form-group">
								  <label for="name">Assign Date</label>
								  <input type="text" class="form-control datepicker" id="emassign_date" name="emassign_date" tabindex="4" placeholder="Enter assign date" <?php echo $emreadonly; ?> value="<?php echo $embroinfo['emassign_date']; ?>">
								</div>	
							</div><!-- /.col -->

							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Due Date</label>
									<input type="text" class="form-control datepicker" id="emdue_date" name="emdue_date" tabindex="5" placeholder="Enter due date" <?php echo $emreadonly; ?> value="<?php echo $embroinfo['emdue_date']; ?>">
								</div>			  
							</div><!-- /.col -->
							
							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Receiving Date</label>
									<input type="text" class="form-control datepicker" id="emreceiving_date" name="emreceiving_date" tabindex="6" placeholder="Enter receiving date" <?php echo $emreadonly; ?> value="<?php echo $embroinfo['emreceiving_date']; ?>">
								</div>			  
							</div><!-- /.col -->									
						</div>
						
						<?php if(count($embroinfo) > 0){	?> 
								
						<div class="col-lg-12">
							<div class="col-lg-8">
								<div class="response"></div>	
							</div><!-- /.col -->
						</div><!-- /.col -->
						
						<div class="col-lg-12">
							<div class="col-lg-8">
								<div class="form-group">											
									<input type="button" onclick="embroreadonly();" class="btn btn-primary" name="editembro" id="editembro" tabindex="7" value="Edit" />
									<input type="button" onclick="updateEmbroInfo();" style="display:none;" class="btn btn-primary" name="updateembro" tabindex="8" id="updateembro" value="Update" />
								</div>	
							</div><!-- /.col -->
						</div><!-- /.col -->
						<?php $allembronotes = $objord->getallnotes('embro',$embroinfo['embroiderid'],$suborder); ?>
						<div class="col-lg-12 orderdiv" id="notesembro" style="max-height: 100px;">
							<?php foreach($allembronotes as $embronote){?>
							<div class="col-lg-12">
								<div class="form-group">											
										Notes	: <?php echo $embronote['embroidery_notes']; ?>
								</div>	
							</div>
							<div class="col-lg-12">
								<div class="col-lg-6">
									<div class="form-group">											
										Date	: <?php echo $embronote['createdon']; ?>													
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group">											
										Status	: <?php echo $embronote['emstatus']; ?>
									</div>
								</div>
							</div>
							<?php } ?>
						</div><!-- /.col -->
						<?php } ?>
						
						<div class="col-lg-12">
							<div class="col-lg-8">
								<div class="form-group">
								  <label for="name">Notes</label>
								  <input type="text" class="form-control" id="embroidery_notes" name="embroidery_notes" placeholder="Enter assign date" tabindex="9" value="">
								</div>	
							</div><!-- /.col -->

							<div class="col-lg-4">										
								<div class="form-group">
									<label for="name">Status</label>
									<select class="form-control select2" id="emstatus" name="emstatus" style="width:100%;">
									<option value="" selected disabled>Select Status</option>
									<option value="1">Incomplete</option>
									<option value="2">Pending</option>
									<option value="3">Processed</option>
									<option value="4">Partially Shipped</option>
									<option value="5">Shipping</option>
									<option value="6">Shipped</option>
									<option value="7">Partially Returned</option>
									<option value="8">Returned</option>
									<option value="9">Cancelled</option>
									</select>
								</div>			  
							</div><!-- /.col -->									
						</div>                            
						  
					</div><!-- /.row -->
				
<?php	
	exit;		
}*/
/* deleted code above*/

if($_REQUEST['task'] == 'updatesuborderrow')
{
	$suborderno = $_REQUEST['suborderno'];
	$alldata = $objord->getSuborderById($suborderno);	
?>							
	<td><?php echo $alldata['suborderno']; ?></td>
	<td><?php echo $alldata['original_amount']; ?></td>
	<td><?php echo $alldata['discount_amount']; ?></td>
	<td><?php echo $alldata['sale_amount']; ?></td>
	<td><a href="#" data-toggle="modal" data-target="#editsuborder" onclick='editsuborder("<?php print $alldata['suborderno']; ?>")' >Edit</a>&nbsp;|&nbsp;<a href="suborder.php?action=editsub&orderno=<?php print $alldata['orderno'];?>&suborder=<?php echo $alldata['suborderno']; ?>">View Suborder Details</a>&nbsp;|&nbsp;<a href="#" data-toggle="modal" data-target="#subOrderNotes" onclick='getSubOrderNotes("<?php print $alldata['suborderno']; ?>")'>Sub Order Notes</a></td>
<?php	
	exit;		
}

if($_REQUEST['task'] == 'UpdateSuborder')
{
	echo $objord->savesuborder();
	exit();
}

if($_REQUEST['task'] == 'EditSuborder')
{
	$suborderno = $_REQUEST['suborderno'];	
	$data = $objord->getSuborderById($suborderno);	
?>	
<div class="row">							
	<div class="col-lg-12">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Sub-Order No</label>
				<input type="text" readonly="true" tabindex="1" id="editsuborderno" name="editsuborderno" class="form-control" value="<?php echo $data['suborderno']; ?>" />
			</div>
		</div><!-- /.col -->
		
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Order No</label>
				<input type="text"  readonly="true" tabindex="2" id="editorderno" name="editorderno" class="form-control" placeholder="Order Detail" value="<?php echo $data['orderno'];?>" />
			</div>									  
		</div><!-- /.col -->
		
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Style Ref</label>
				<select id="editstyle_ref" tabindex="3" class="form-control" name="editstyle_ref">
				<?php for($si = 0; $si < count($allstyle); $si++){ 
				if($data['style_ref'] == $allstyle[$si]['style_code']){$selected = 'selected';}else{$selected = '';}
				?>
				<option value="<?php echo $allstyle[$si]['style_code']; ?>" <?php echo $selected; ?>><?php echo $allstyle[$si]['style_code']; ?></option>
				<?php } ?>
				</select>
			</div>	
		</div><!-- /.col -->
	</div>
	
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Sale Amount</label>
				<input type="text" class="form-control" tabindex="8" id="editsale_amount" onKeyPress="return isDecimalNumber(event,this.value);" name="editsale_amount" placeholder="Sale Amount" value="<?php echo $data['sale_amount'];?>">
			</div>			  
		</div><!-- /.col -->
	
		<div class="col-lg-4">
			<div class="form-group">
			<label for="name">Discount Type </label><br>
			<input type="radio" id="discount_type" tabindex="6" name="discount_type" <?php if($data['discount_type'] == 'Amount'){echo 'checked';} ?> value="Amount">Amount
			<input type="radio" id="discount_type" tabindex="7" name="discount_type" <?php if($data['discount_type'] == 'Percentage'){echo 'checked';} ?> value="Percentage">Percentage
			</div>	
		</div><!-- /.col -->
		
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Discount Value</label>
				<input type="text" class="form-control" tabindex="7" onKeyPress="return isDecimalNumber(event,this.value);" id="editdiscount_amount" name="editdiscount_amount" placeholder="Enter Discount Amount" value="<?php echo $data['discount_amount'];?>">
			</div>			  
		</div><!-- /.col -->
		
	</div>	
			
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Trial Date</label>
				<input type="text" class="form-control datepicker" tabindex="10" id="edittrial_date" name="edittrial_date" placeholder="Enter trial date" value="<?php echo $data['trial_date'];?>">
			</div>			  
		</div><!-- /.col -->
		
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Delivery Due Date</label>
				<input type="text" class="form-control datepicker" tabindex="11" id="editdelivery_due_date" name="editdelivery_due_date" placeholder="Delivery due date" value="<?php echo $data['delivery_due_date'];?>">
			</div>			  
		</div><!-- /.col -->
		
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Status</label>
				<select class="form-control select2" tabindex="9" id="editsubstatus" name="editsubstatus" style="width:100%;">
				<option value="1" <?php if($data['substatus'] == 1){echo 'selected';} ?>>Incomplete</option>
				<option value="2" <?php if($data['substatus'] == 2){echo 'selected';} ?>>Pending</option>
				<option value="3" <?php if($data['substatus'] == 3){echo 'selected';} ?>>Processed</option>
				<option value="4" <?php if($data['substatus'] == 4){echo 'selected';} ?>>Partially Shipped</option>
				<option value="5" <?php if($data['substatus'] == 5){echo 'selected';} ?>>Shipping</option>
				<option value="6" <?php if($data['substatus'] == 6){echo 'selected';} ?>>Shipped</option>
				<option value="7" <?php if($data['substatus'] == 7){echo 'selected';} ?>>Partially Returned</option>
				<option value="8" <?php if($data['substatus'] == 8){echo 'selected';} ?>>Returned</option>
				<option value="9" <?php if($data['substatus'] == 9){echo 'selected';} ?>>Cancelled</option>
				</select>
			</div>
		</div><!-- /.col -->
		
	</div>
		
	<div class="col-lg-12">
		<div class="col-lg-12">										
			<div class="form-group">
				<label for="name">Order Detail</label>
				<textarea id="editdetails" name="editdetails" class="form-control" placeholder="Order Detail" ><?php echo $data['details'];?></textarea>
			</div>
		</div><!-- /.col -->
		
	</div>
	
</div><!-- /.row -->
<?php	
	exit;		
}

if($_REQUEST['task'] == 'getSuborderrow')
{
	$orderno = $_REQUEST['orderno'];
	$alldata = $objord->getAllSuborder($orderno);

	if(count($alldata)>0){
?>							
	<table class="table table-bordered table-striped" width='100%'>
		<thead>
			<tr style="background-color:#D4AE87;">
				<th><b>Sub Order No</b></th>
				<th><b>Sale Amount</b></th>
				<th><b>Discount Type</b></th>
				<th><b>Discount</b></th>
				<th><b>Action</b></th>
			</tr>	
		</thead>
		<tbody>
		<?php 
		
		for($i = 0; $i <count($alldata); $i++)
		{
			?>
			<tr style="background-color:#EFD8C1;" id="<?php echo $alldata[$i]['suborderno']; ?>">
				<td><?php echo $alldata[$i]['suborderno']; ?></td>
				<td><?php echo $alldata[$i]['sale_amount']; ?></td>
				<td><?php echo $alldata[$i]['discount_type']; ?></td>
				<td><?php echo $alldata[$i]['discount_amount']; ?></td>
				<td><a href="#" data-toggle="modal" data-target="#editsuborder" onclick='editsuborder("<?php print $alldata[$i]['suborderno']; ?>")' >Edit</a>&nbsp;|&nbsp;
				<a href="suborder.php?action=editsub&orderno=<?php print $alldata[$i]['orderno'];?>&suborder=<?php echo $alldata[$i]['suborderno']; ?>">View Suborder Details</a>&nbsp;|&nbsp;
				<a href="#" data-toggle="modal" data-target="#subOrderNotes" onclick='getSubOrderNotes("<?php print $alldata[$i]['suborderno']; ?>")'>Sub Order Notes</a></td>
			</tr>
			<?php 										
		}
		?>									
		</tbody>
	</table>
<?php	
	}else{
?>							
	<table class="table table-bordered table-striped" width='100%'>
		<thead>
			<tr style="background-color:#D4AE87;">
				<th colspan="5" align="center"><b>No Data Found</b></th>
			</tr>	
		</thead>		
	</table>
<?php	
	}
	exit;		
}

if($_REQUEST['task'] == 'updateorderrow')
{
	$orderno = $_REQUEST['orderno'];
	$alldata = $objord->getById($orderno);
	$id= $alldata['id'];
?>							
	<td style='border: 1px solid;display: inline-block;position: relative; top:1px; left:5px;' class="accordion-toggle" data-toggle="collapse" data-target="#packageDetails<?php print $alldata['orderno']; ?>" onclick="getSuborderrow('<?php print $alldata['orderno']; ?>')"><i class="indicator glyphicon pull-right glyphicon-chevron-down"></i></td>
	<td><a href="#" data-toggle="modal" data-target="#orderdetails" onclick='getOrderbyno("<?php print $alldata['orderno']; ?>")'><?php print $alldata['orderno']; ?></a></td>
	<td><a href="#" data-toggle="modal" data-target="#getCutomerbyId" onclick='getCutomerbyId("<?php print $alldata['customer_id']; ?>")'><?php print $alldata['customer_id']; ?></a></td>
	<td><?php print $alldata['order_date']; ?></td>
	<td>
	<a href="#" data-toggle="modal" data-target="#editorder" onclick='editorder("<?php print $alldata['orderno']; ?>")' >Edit</a>&nbsp;|&nbsp;
	<a href="#" data-toggle="modal" data-target="#suborder" onclick='getSuborderForm("<?php print $alldata['orderno']; ?>")'>Create Suborder</a>&nbsp;|&nbsp;
	<a href="#" data-toggle="modal" data-target="#paymentorder" onclick='getPaymentDetails("<?php print $alldata['orderno']; ?>")'>Payment</a>&nbsp;|&nbsp;
	<a href="#" data-toggle="modal" data-target="#ordernotes" onclick='getnotes("<?php print $alldata['orderno']; ?>")'>Order Notes</a>&nbsp;|&nbsp;
	<a href="#" onclick='getDeleteOrderNo("<?php print $alldata['orderno']; ?>")'>Delete</a>
	</td>
<?php	
	exit;		
}

if($_REQUEST['task'] == 'UpdateOrder')
{
	echo $objord->save();
	exit();
}
/* deleted code start*/
/*
if($_REQUEST['task'] == 'EditOrder')
{
	$orderno = $_REQUEST['orderno'];
	$data = $objord->getById($orderno);
?>	
<div class="row">
	<div class="col-lg-12">
		<div class="col-lg-4">										
			<div class="form-group">
			  <label for="name">Order Number</label>
			  <input type="text" tabindex="1" class="form-control" readonly="true" id="eo_orderno" name="eo_orderno" value="<?php echo $data['orderno']; ?>">
			</div>
		</div><!-- /.col -->
		
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Order Type</label>
				<select id="eo_order_type" class="form-control" name="eo_order_type" tabindex="2" >
				<option value="" selected="selected" disabled >Select Delivery Status</option>
				<option value="PD" <?php if($data['order_type']== 'PD'){echo 'selected';} ?>>Only for Stitching</option>
				<option value="RMO" <?php if($data['order_type']== 'RMO'){echo 'selected';} ?>>RMO (stitching and Ready Made Order)</option>
				<option value="ALT" <?php if($data['order_type']== 'ALT'){echo 'selected';} ?>>ALT ( Alteration)</option>
				</select>
			</div>
		</div><!-- /.col -->
		
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Old Order Number</label>
				<input type="text" readonly="true" tabindex="3" class="form-control" id="eo_alt_order_no" name="eo_alt_order_no" placeholder="Enter alteration order no" value="<?php echo $data['alt_order_no']; ?>">
			</div>			  
		</div><!-- /.col -->
	</div>
	
	<div class="col-lg-12">									
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Order Date</label>
				<input type="text" tabindex="4" name="eo_order_date" id="eo_order_date" placeholder="click here for order date" value="<?php if($data['order_date']){echo $data['order_date'];}else{echo date('Y-m-d');} ?>" class="form-control datepicker" />
			</div><!-- /.form-group -->
		</div><!-- /.col -->
		
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Trial Date</label>
				<input type="text" tabindex="5" name="eo_trial_date" id="eo_trial_date" placeholder="click here for trial date" value="<?php if($data['trial_date']){echo $data['trial_date'];}else{echo date('Y-m-d');} ?>" class="form-control datepicker" />
			</div><!-- /.form-group -->
		</div><!-- /.col -->
		
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Delivery Due Date</label>
				<input type="text" tabindex="6" name="eo_delivery_due_date" id="eo_delivery_due_date" placeholder="click here for delivery due date" value="<?php if($data['delivery_due_date']){echo $data['delivery_due_date'];}else{echo date('Y-m-d');} ?>" class="form-control datepicker" />
			</div><!-- /.form-group -->
		</div><!-- /.col -->
		
		
		
	</div>
	
	<div class="col-lg-12">
		<div class="col-lg-4">
			<div class="form-group">
				<label for="name">Sale Person</label>
				<select name="eo_sale_person" tabindex="7" class="form-control select2" id="eo_sale_person">
				<option value="" selected >Select Sale Person</option>
				<?php foreach($allsalesman as $salesman){?>
				<option value="<?php echo $salesman['id'];?>" <?php if($data['sale_person']== $salesman['id']){echo 'selected';} ?>><?php echo $salesman['personname']; ?></option>
				<?php } ?>
				</select>
			</div>	
		</div><!-- /.col -->
		
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Order Detail</label>
				<!--<input type="text" class="form-control" tabindex="6" id="eo_order_detail" name="eo_order_detail" placeholder="Enter order detail" value="<?php echo $data['order_detail']; ?>">-->
				<textarea class="form-control" tabindex="8" id="eo_order_detail" name="eo_order_detail" placeholder="Enter order detail"><?php echo $data['order_detail']; ?></textarea>
			</div>
		</div><!-- /.col -->
		
		<div class="col-lg-4">										
			<div class="form-group">
				<label for="name">Status</label>
				<select class="form-control select2" tabindex="9" id="eo_status" name="eo_status" style="width:100%;">
				<option value="1" <?php if($data['orderstatus'] == 1){echo 'selected';} ?>>Incomplete</option>
				<option value="2" <?php if($data['orderstatus'] == 2){echo 'selected';} ?>>Pending</option>
				<option value="3" <?php if($data['orderstatus'] == 3){echo 'selected';} ?>>Processed</option>
				<option value="4" <?php if($data['orderstatus'] == 4){echo 'selected';} ?>>Partially Shipped</option>
				<option value="5" <?php if($data['orderstatus'] == 5){echo 'selected';} ?>>Shipping</option>
				<option value="6" <?php if($data['orderstatus'] == 6){echo 'selected';} ?>>Shipped</option>
				<option value="7" <?php if($data['orderstatus'] == 7){echo 'selected';} ?>>Partially Returned</option>
				<option value="8" <?php if($data['orderstatus'] == 8){echo 'selected';} ?>>Returned</option>
				<option value="9" <?php if($data['orderstatus'] == 9){echo 'selected';} ?>>Cancelled</option>
				</select>
			</div>
		</div><!-- /.col -->
		
	</div>
	
</div><!-- /.row -->
<?php	
	exit;		
}*/
/* deleted code end */
if($_REQUEST['task'] == 'AddSuborder')
{
	$msg = $objord->savesuborder();
	echo $msg;
	exit();
}

if($_REQUEST['task'] == 'AddPayment')
{
	$returnmsg = $objord->savePaymentDetails();
	echo $returnmsg;
	exit;		
}

if($_REQUEST['task'] == 'UpdatePayment')
{
	$returnmsg = $objord->updatePaymentDetails();
	echo $returnmsg;
	exit;		
}

if($_REQUEST['task'] == 'DeletePayment')
{
	$returnmsg = $objord->deletePaymentDetails();
	echo $returnmsg;
	exit;		
}

if($_REQUEST['task'] == 'EditPayment')
{
	$id = $_REQUEST['id'];
	$allsuborder = json_decode($_REQUEST['allsuborder']);
	$data = $objord->getPaymentInfoById($id);
	
?>
<div class="col-lg-12">
	<div class="form-group">
	  <label for="name">Sub-Order</label>
	  <select name="payment_suborder" class="form-control" id="payment_suborder">
	  <option value="" disabled selected>Select Sub-Order</option>
	  <?php foreach($allsuborder as $paysuborder){ ?>
	  <option <?php if($data['suborderno'] == $paysuborder){echo 'selected';} ?> value="<?php echo $paysuborder; ?>"><?php echo $paysuborder; ?></option>
	  <?php } ?>
	  </select>
	</div>
	
	<div class="form-group">
		<label for="name">Payment Date</label>
		<input type="text" tabindex="1" class="form-control datepicker" id="payment_date" name="payment_date" placeholder="Enter payment date" value="<?php echo $data['payment_date']; ?>" />
		<input type="hidden" id="payment_id" name="payment_id" value="<?php echo $data['id']; ?>">
	</div>
	
	<div class="form-group">
	  <label for="name">Payment Mode</label>
	  <select name="payment_mode" tabindex="2" class="form-control" id="payment_mode">
	  <option value="">Select Payment Mode</option>
	  <option value="Cash" <?php if($data['payment_mode'] == 'Cash'){echo 'selected';} ?>>Cash</option>
	  <option value="CreditCard" <?php if($data['payment_mode'] == 'CreditCard'){echo 'selected';} ?>>CreditCard</option>
	  <option value="Cheque" <?php if($data['payment_mode'] == 'Cheque'){echo 'selected';} ?>>Cheque</option>
	  <option value="MobileWallet" <?php if($data['payment_mode'] == 'MobileWallet'){echo 'selected';} ?>>MobileWallet</option>
	  </select>
	</div>
	
	<div class="form-group">
	  <label for="name">Received Amount</label>
	  <input type="text" class="form-control" tabindex="3" id="received_amount" onKeyPress="return isDecimalNumber(event,this);" name="received_amount" placeholder="Enter received amount" value="<?php echo $data['received_amount']; ?>" />
	</div>
	
	<div class="form-group">
	  <label for="name">Remarks</label>
	  <input type="text" class="form-control" id="remarks" name="remarks" placeholder="Enter remarks">
	</div>
</div><!-- /.col -->
<?php
	exit;	
}
/* deleted code start */
/*
if($_REQUEST['task'] == 'updatestoreinfo')
{
	$updateinfo = $objord->updatestoreinfo();	
	echo $updateinfo;
	exit;		
}

if($_REQUEST['task'] == 'store_notes')
{
	$storenotes = $objord->addStoreNotes($_REQUEST['suborderno'],trim($_REQUEST['store_notes']),trim($_REQUEST['ststatus']));
	foreach($storenotes as $dn)
	{
		$html.=  '<div class="col-lg-12">
						<div class="form-group">											
							Date	: '.$dn["createdon"].'<br/>
							Notes	: '.$dn["store_notes"].'
						</div>	
					</div>  
		<hr />';
	}
	echo $html;
	exit;		
}

//task = 'update tailor info'
if($_REQUEST['task'] == 'updatetailorinfo')
{
	$updateinfo = $objord->updatetailorinfo();	
	echo $updateinfo;
	exit;		
}

if($_REQUEST['task'] == 'tailor_notes')
{
	$embronotes = $objord->addTailorNotes($_REQUEST['suborderno'],trim($_REQUEST['tailorid']),trim($_REQUEST['tailor_notes']),trim($_REQUEST['tastatus']));
	foreach($embronotes as $dn)
	{
		$html.=  '<div class="col-lg-12">
						<div class="form-group">
							Date	: '.$dn["createdon"].'<br/>
							Notes	: '.$dn["tailor_notes"].'
						</div>
					</div>
		<hr />';
	}
	echo $html;
	exit;
}


//task = 'update cutter info'
if($_REQUEST['task'] == 'updatecuttinginfo')
{
	$updateinfo = $objord->updatecutting();	
	echo $updateinfo;
	exit;		
}

if($_REQUEST['task'] == 'cutting_notes')
{
	$embronotes = $objord->addCuttingNotes($_REQUEST['suborderno'],trim($_REQUEST['cutterid']),trim($_REQUEST['cutting_notes']),trim($_REQUEST['custatus']));
	foreach($embronotes as $dn)
	{
		$html.=  '<div class="col-lg-12">
						<div class="form-group">											
							Date	: '.$dn["createdon"].'<br/>
							Notes	: '.$dn["cutting_notes"].'
						</div>	
					</div>  
		<hr />';
	}
	echo $html;
	exit;		
}


//task = 'updateembroinfo'
if($_REQUEST['task'] == 'updateembroinfo')
{
	$updateinfo = $objord->updateembro();	
	echo $updateinfo;
	exit;		
}

if($_REQUEST['task'] == 'embro_notes')
{
	$embronotes = $objord->addEmbroNotes($_REQUEST['suborderno'],trim($_REQUEST['embroiderid']),trim($_REQUEST['embroidery_notes']),trim($_REQUEST['emstatus']));
	foreach($embronotes as $dn)
	{
		$html.=  '<div class="col-lg-12">
						<div class="form-group">											
							Date	: '.$dn["createdon"].'<br/>
							Notes	: '.$dn["embroidery_notes"].'
						</div>	
					</div>  
		<hr />';
	}
	echo $html;
	exit;		
}

if($_REQUEST['task'] == 'updatedyinginfo')
{
	$updateinfo = $objord->updatedying();	
	echo $updateinfo;
	exit;		
}

if($_REQUEST['task'] == 'dying_notes')
{
	$dynotes = $objord->addDyingNotes($_REQUEST['suborderno'],trim($_REQUEST['dyerid']),trim($_REQUEST['dying_notes']),trim($_REQUEST['dystatus']));
	foreach($dynotes as $dn)
	{
		$html.=  '<div class="col-lg-12">
						<div class="form-group">											
							Date	: '.$dn["createdon"].'<br/>
							Notes	: '.$dn["dying_notes"].'
						</div>	
					</div><hr />';
	}
	echo $html;
	exit;		
}*/
/* deleted code end */

if($_REQUEST['task'] == 'saveItem')
{
	echo $objitem->saveItemBySONO();
	exit();
}

if($_REQUEST['task'] == 'updateItem')
{
	echo $objitem->saveItemBySONO();
	exit();
}

if($_REQUEST['task'] == 'deleteItem')
{
	echo $objitem->deleteItemBySONO();
	exit();
}

if($_REQUEST['task'] == 'getItemDetails')
{
	$id = $_REQUEST['id'];
	$data = $objitem->getItemBySONO($id);
	$allitems = $objitem->getAll();
?>
<div class="col-lg-12">
	<div class="col-lg-4">
		<div class="form-group">
			<label for="name">Items</label>
			<select class="form-control select2" tabindex="4" id="ei_items" name="ei_items" style="width:100%;">
			<option value="" selected>Select</option>
			<?php 
			for($item=0; $item<count($allitems); $item++) {
				if($data['items'] == $allitems[$item]['id']){$selected = 'selected';}else{$selected = '';}
				echo "<option value='".$allitems[$item]['id']."' $selected>".$allitems[$item]['itemname']."</option>";
			}
			?>
			</select>
			<input type="hidden" id="ei_id" name="ei_id" class="form-control" value="<?php echo $data['id']; ?>" />
			<input type="hidden" id="ei_orderno" name="ei_orderno" class="form-control" value="<?php echo $data['orderno']; ?>" />
			<input type="hidden" id="ei_suborderno" name="ei_suborderno" class="form-control" value="<?php echo $data['suborderno']; ?>" />
		</div>	
	</div><!-- /.col -->
	
	<div class="col-lg-4">
		<div class="form-group">
			<label for="name">Fabric ID</label>
			<select class="form-control select2" tabindex="4" id="ei_fabricid" name="ei_fabricid" style="width:100%;">
			<option value="" selected>Select</option>
			<?php 				
			for($fbi=0; $fbi<count($allfabric); $fbi++) {
				if($data['fabric'] == $allfabric[$fbi]['id']){$selected = 'selected';}else{$selected = '';}
				echo "<option value='".$allfabric[$fbi]['id']."' $selected>".$allfabric[$fbi]['fabricname']."</option>";
			}
			?>
			</select>
		</div>	
	</div><!-- /.col -->

	<div class="col-lg-4">										
		<div class="form-group">
			<label for="name">Quantity(in Metre)</label>
			<input type="text" class="form-control" tabindex="5" onKeyPress="return isDecimalNumber(event,this);" id="ei_quantity" name="ei_quantity" placeholder="Enter quantity" value="<?php echo $data['meters']; ?>">
		</div>			  
	</div><!-- /.col -->
	
</div>
<?php
	exit;	
}

if($_REQUEST['task'] == 'history_assigned_id')
{
	$assignedid = $_REQUEST['assignedid'];
	$alldata = $objitem->getWorkStatusAssignedId($assignedid);
	
	foreach($alldata as $data) {
?>
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" >
		<p style="border-bottom: 1px solid #ccc; padding-bottom: 10px;"><?php echo $data['status_entry_date']; ?> | <?php echo $data['statusname']; ?> | Agency Name : <?php echo $data['agencyname']; ?></p>
		
	</div>
<?php
	}
	exit;	
}

if($_REQUEST['task'] == 'updateAssignedWork')
{
	$alldata = $objitem->updateAssignedWork();
	echo $alldata;
	exit;	
}

if($_REQUEST['task'] == 'getAssignedWorkData')
{
	$objStatus = new Statusmaster();
	$allStatus = $objStatus->getAll();

	$assignedid = $_REQUEST['assignedid'];
	//$data = $objitem->getAssignedWorkData($assignedid);
	
	$alldata = $objitem->getWorkStatusAssignedId($assignedid);
	
	foreach($alldata as $alldata) {
?>
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" >
		<p style="border-bottom: 1px solid #ccc; padding-bottom: 10px;"><?php echo $alldata['status_entry_date']; ?> | <?php echo $alldata['statusname']; ?> | Agency Name : <?php echo $alldata['agencyname']; ?> | Challan No: <?php echo $alldata['challanno']; ?></p>
	</div>
<?php
	}
?>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">										
		<div class="form-group">
			<label for="name">Status</label>
			<select id="aw_assignstatus" class="form-control input-sm" name="aw_assignstatus" onchange="getAgencyByAssignedID(this.value);" tabindex="1" >
			<option value="0" selected="selected" disabled >No Work Done</option>
			<?php foreach($allStatus as $orderstatus){ if($data['status_id'] == $orderstatus['id']){$status_selected = 'selected';}else{$status_selected = '';} ?>
			<option value="<?php echo $orderstatus['id']; ?>" <?php echo $status_selected; ?>><?php echo $orderstatus['statusname']; ?></option>
			<?php } ?>
			</select>
		</div>			  
	</div><!-- /.col -->
	
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
		<div class="form-group">
			<label for="name">Agency</label>
			<select id="aw_agencyid" class="form-control input-sm" name="aw_agencyid" ></select>
		</div>	
	</div><!-- /.col -->
	
</div>

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
		<div class="form-group">
			<label for="name">Date</label>
			<input type="text" class="form-control input-sm datepicker" id="aw_status_date" name="aw_status_date" placeholder="Date" value="<?php echo date('Y-m-d'); ?>">
		</div>			  
	</div><!-- /.col -->
	
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
		<div class="form-group">
			<label for="name">Challan No</label>
			<input type="hidden" id="aw_assigned_id" name="aw_assigned_id" class="form-control" value="<?php echo $assignedid; ?>" />
			<input type="text" id="aw_challanno" name="aw_challanno" class="form-control input-sm" value="<?php echo $data['challanno']; ?>" />
		</div>	
	</div><!-- /.col -->
	
</div>

<?php	
	exit;
}

if($_REQUEST['task'] == 'getItemBySO')
{
	$suborderno = $_REQUEST['suborderno'];
	$alldata = $objitem->itemsbysuborderno($suborderno);

	if(count($alldata)>0){
?>							
	<table class="table table-bordered table-striped inner-table" width='100%'>
		<thead>
			<tr>
				<th><b>Items</b></th>
				<th><b>Fabric</b></th>
				<th><b>Fabric Quantity</b></th>
				<th><b>Status</b></th>
				<th><b>View History</b></th>
			</tr>	
		</thead>
		<tbody>
		<?php 
		
		for($i = 0; $i <count($alldata); $i++)
		{
			?>
			<tr id="<?php echo $alldata[$i]['suborderno']; ?>">
				<td><?php echo $alldata[$i]['itemname']; ?></td>
				<td><a href="#" data-toggle="modal" data-target="#viewfabric" onclick='getfabricdetails("<?php print $alldata[$i]['fabric']; ?>");'><?php echo $alldata[$i]['fabricname']; ?></a></td>
				<td><?php echo $alldata[$i]['meters']; ?></td>
				<td><?php if($alldata[$i]['status_id'] == '0'){echo 'No work done.';}else{echo $objitem->getStatusName($alldata[$i]['status_id']);} ?></td>
				<td><a href="#" data-toggle="modal" data-target="#viewhistory" onclick='gethistorybyassignedid("<?php print $alldata[$i]['id']; ?>");'>View</a></td>
			</tr>
			<?php 										
		}
		?>									
		</tbody>
	</table>
<?php	
	}else{
?>							
	<table class="table table-bordered table-striped" width='100%'>
		<thead>
			<tr style="background-color:#D4AE87;">
				<th colspan="7" align="center"><b>No Data Found</b></th>
			</tr>	
		</thead>		
	</table>
<?php	
	}
	exit;		
}

	if($_REQUEST['task'] == 'getCustomer'){
		//echo $_REQUEST['cust_id'];die();
		$cust = $objCus->getCustomerDetailByID(trim($_REQUEST['cust_id']));
		//echo $cust;die();
		foreach($cust as $n)
		{
			$html.='<div class="row">							
					<div class="col-lg-12">
						<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Customer ID</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['cust_id'].'										  
							</div>										  
						</div><!-- /.col -->
							<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Name</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['salutation'].' '.$n['name_first'].' '.$n['name_last'].'										  
							</div>										  
						</div><!-- /.col -->								
					</div>
					
					
					<div class="col-lg-12">
						<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Address</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-10">										
							<div class="form-group">
								'.$n['address2'].' '.$n['city_name'].' '.$n['state_name'].' '.$n['country_name'].' '.$n['pin'].'
							</div>										  
						</div>
					</div>';
					
					$html.='<div class="col-lg-12">
						<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Phone</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['contact_no1'].'								  
							</div>										  
						</div><!-- /.col -->
							<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Email</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['email_1'].'
							</div>										  
						</div><!-- /.col -->								
					</div>
					

					<div class="col-lg-12">
						<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Preference</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['contact_preference'].'
							</div>										  
						</div><!-- /.col -->
							<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Relation</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['relation_a'].'
							</div>										  
						</div><!-- /.col -->								
					</div>
					
					
					<div class="col-lg-12">
						<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Refferal ID</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['refferal_id'].'
							</div>										  
						</div><!-- /.col -->
							<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Family</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['family'].'
							</div>										  
						</div><!-- /.col -->								
					</div>
					
					
					<div class="col-lg-12">
						<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Date Of Birth</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['dob'].'
							</div>										  
						</div><!-- /.col -->
						<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Source</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-4">										
							<div class="form-group">
								'.$n['source'].'
							</div>										  
						</div><!-- /.col -->								
					</div>
					
					
					<div class="col-lg-12">
						<div class="col-lg-2">
							<div class="form-group">
							  <label for="name">Remarks</label>										  										  
							</div>
						</div><!-- /.col -->

						<div class="col-lg-10">										
							<div class="form-group">
								'.$n['notes'].'
							</div>										  
						</div>
					</div>
			   </div><!-- /.row -->';
		}



		echo $html;
		exit;
		
	}

?>