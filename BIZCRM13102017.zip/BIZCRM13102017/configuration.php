<?php  
ini_set("display_errors", "1");
error_reporting(E_ALL);

require_once('class/class.config.php');
$objCon = new Config();

$msgD = '';

if(isset($_POST['submit']))
{
	$msgD = $objCon->updateConfig();
}

$data = $objCon->getConfig();

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>BIZCRM | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css"></link>
	<link rel="stylesheet" href="bootstrap/css/datepicker.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    
	<!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini" >
	<?php if($msgD != ''){echo '<div id="message">'.$msgD.'</div>';} unset($msgD);?>
	<div class="wrapper">
		<?php $objCon->psheader(); ?>
		<?php $objCon->pssidebar(); ?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>Configuration</h1>
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Control Panel</li>
            <li class="active">Configuration</li>
          </ol>
        </section><!--CONTENT HEADER-->
        
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title">Configuration</h3> <?php echo $MAND_INSTRUCTION;?>
                        </div><!-- box-header -->
                        <div class='box-body'>
                            <form action="" name="Configuration" id="Configuration" method="post" >
							<div class="row">
							
								<div class="col-lg-12">

									<div class="col-lg-12">
										<div class="form-group">
										  <b>Customer ID (If it is Yes then generate through system function or else manual)</b><br/>
										  <input type="radio" id="customerid1" name="customerid" <?php if($data['customerid'] == '1'){echo 'checked';} ?> value="1">Yes
										  <input type="radio" id="customerid2" name="customerid" <?php if($data['customerid'] == '0'){echo 'checked';} ?> value="0">No
										</div>
									</div>
									<div class="col-lg-12">
										<div class="form-group">
										  <b>Order ID (If it is Yes then generate through system function or else manual)</b><br/>
										  <input type="radio" id="orderid1" name="orderid" <?php if($data['orderid'] == '1'){echo 'checked';} ?> value="1">Yes
										  <input type="radio" id="orderid2" name="orderid" <?php if($data['orderid'] == '0'){echo 'checked';} ?> value="0">No
										</div>
									</div>
									
								</div>
								
                           </div><!-- /.row -->
                           
                           <div class="row">
                              <div class="col-lg-12">
                                   <div class="form-group center">
                                      <input type="submit" name="submit" id="submit" class="btn btn-warning left-10" value="Update" />
                                   </div>
                               </div><!-- /.col -->
             				 </div><!-- /.row -->
                           </form>
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
      </div><!-- /.content-wrapper -->
      
      
 <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->
	<!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
	

    <script src="dist/js/jquery-ui.min.js"></script>
    <script>
		$("#message").fadeIn('slow').delay(5000).fadeOut('slow');
		$.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
   
</body>
</html>