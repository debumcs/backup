<?php 
	session_start();
	$_SESSION['ADMIN_NAME'] = 'CUSTOMER';
	/*error_reporting(E_ALL); 
	ini_set('display_errors', 1);*/
	$MANDATORY 	= "<font color='red'>*</font>";
	$base_url 	= "http://".str_replace('customer','crm',$_SERVER['HTTP_HOST'])."/";
	//$base_url = 'http://crm.suemue.in/';
	//echo $base_url ; 
	include_once("../class/class.customer.php");
	include_once("../class/class.salutation.php");
	
	$objsalutation 	= new Salutation();
	$allsalutation	= $objsalutation->getAll();
	
	$objcus 		= new Customer();
	$allcountry 	= $objcus->getCountry();
	
	
	$msgD = '';
	
	if($_REQUEST['getState']=='ajaxState')
	{
		$id = $_POST['id'];
		$objsta = new Customer();
		$allstate = $objsta->getState($id);
		
		echo '<select class="form-control select2" id="state" name="state" style="width:100%;" onchange="getCity(this.value);">
				<option value="">Select</option>';
		for($si=0; $si<count($allstate); $si++) {
			echo "<option value='".$allstate[$si]['id']."' $selected >".$allstate[$si]['name']."</option>"; 
		}
		echo '</select>';		
		exit;
	}
	
	if($_REQUEST['getCity']=='ajaxCity')
	{
		$id = $_POST['id'];
		$objcity = new Customer();
		$allcity = $objcity->getCity($id);
		
		echo '<select class="form-control select2" id="city" name="city" style="width:100%;"><option value="">Select</option>';
		for($cti=0; $cti<count($allcity); $cti++) {			
			echo "<option value='".$allcity[$cti]['id']."' >".$allcity[$cti]['name']."</option>"; 
		}
		echo '</select>';		
		exit;
	}
	
	$btnvalue = "SAVE";
	
	if(isset($_POST["captcha"])&&$_POST["captcha"]!=""&&$_SESSION["code"]==$_POST["captcha"]){
		//echo 'Your data saved successfully.';die();
		if(isset($_POST['submit']))
		{
			$result = $objcus->save();
			if($result == '1'){
				$_SESSION['msgD'] = 'Your data saved successfully.';
			}else{
				$_SESSION['msgD'] = 'Data not saved.';
			}
		}
	}if(isset($_POST["captcha"])&&$_POST["captcha"]!=""&&$_SESSION["code"]!=$_POST["captcha"]){
		$_SESSION['msgD'] = '#Invalid Security Code#';
	}else{
		//unset($_SESSION['captcha']);
	}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Suemue | Customer Details</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" type="text/css" href="<?php echo $base_url; ?>bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $base_url; ?>plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css"></link>
	<link rel="stylesheet" type="text/css" href="<?php echo $base_url; ?>bootstrap/css/datepicker.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" type="text/css" href="<?php echo $base_url; ?>dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" type="text/css" href="<?php echo $base_url; ?>dist/css/ionicons.min.css">
    
	<!-- Select2 -->
    <link rel="stylesheet" type="text/css" href="<?php echo $base_url; ?>plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" type="text/css" href="<?php echo $base_url; ?>dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" type="text/css" href="<?php echo $base_url; ?>dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" type="text/css" href="<?php echo $base_url; ?>plugins/iCheck/minimal/orange.css">
   
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	
	
	<script type="text/javascript" language="javascript">
	
	function getState(stateid){
		
		$.ajax({
			url: "index.php",
			type: 'POST',
			context: this,
			data: {getState:'ajaxState',id:stateid},
			success: function(response){
				$('#ajaxstate').html(response);
			}
		});			
	}
		
	function checkIt(evt)
	{
		evt = (evt) ? evt : window.event
		var charCode = (evt.which) ? evt.which : evt.keyCode
		if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode != 43)
		{
			status = "This field accepts numbers only.";
			return false;
		}
		status = "";
		return true ;
	}
	
	function checkalphanumeric(evt)
	{
		evt = (evt) ? evt : event;
		var charCode = (evt.charCode) ? evt.charCode : ((evt.keyCode) ? evt.keyCode :((evt.which) ? evt.which : 0));
		if (charCode == 8) {
			return true;
		} else if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 122)) {
			// alert("Enter letters only.");
			return false;
		}
		return true;
	}

	
	function getCity(cityid){
	
		$.ajax({
			url: "index.php",
			type: 'POST',
			context: this,
			data: {getCity:'ajaxCity',id:cityid},
			success: function(response){
				$('#ajaxcity').html(response);
			}
		});
		
	}
	
	function validateEmail(email) {
		var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		return re.test(email);
	}
	  
	function validateuser(){
		
		if(document.getElementById("salutation").value==""){
			alert("Please Select Salutation.");
			document.getElementById("salutation").focus();
			return false;
		}else if(document.getElementById("name_first").value.length < 3){
			alert("Please Enter First Name(Minimum 3 character).");
			document.getElementById("name_first").focus();
			return false;
		}else if(document.getElementById("name_last").value.length < 3){
			alert("Please Enter Last Name(Minimum 3 character).");
			document.getElementById("name_last").focus();
			return false;
		}else if(document.getElementById("address2").value==""){
			alert("Please Enter Address");
			document.getElementById("address2").focus();
			return false;
		}else if(document.getElementById("country").value==""){
			alert("Please Select Country.");
			document.getElementById("country").focus();
			return false;
		}else if(document.getElementById("state").value==""){
			alert("Please Select State.");
			document.getElementById("state").focus();
			return false;
		}else if(document.getElementById("city").value==""){
			alert("Please Select City.");
			document.getElementById("city").focus();
			return false;
		}else if(document.getElementById("pin").value==""){
			alert("Please Enter Pin Code.");
			document.getElementById("pin").focus();
			return false;
		}else if(document.getElementById("contact_no1").value.length < 10){
			alert("Please enter 10 digit mobile number.");
			document.getElementById("contact_no1").focus();
			return false;
		}else if(document.getElementById("captcha").value == ""){
			alert("Please enter security code.");
			document.getElementById("captcha").focus();
			return false;
		}else{
			return true;
		}
	}
</script>
<style>
	.form-control2 {
		display: block;
		width: 100%;
		height: 34px;
		font-size: 14px;
		line-height: 1.42857;
		color: #555;
		background-color: #FFF;
		background-image: none;
	}

</style>
  </head>
  <body class="hold-transition skin-blue sidebar-mini" >
     
  <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">
		
	<header class="main-header">
		<nav class="navbar navbar-static-top" role="navigation" style="margin-left: 0px; background-color: #000 !important; text-align: center;">
			<span class="logo-lg"><img src="logo3.jpg"></span>
		</nav>
	</header>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper" style="margin-left: 0px">
        
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title">Customer Details</h3> <?php //echo $MAND_INSTRUCTION;?>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <form action="" name="userCreate" id="userCreate" method="post" >
							<div class="row">							
								<div class="col-lg-12">
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Salutation</label><?php echo $MANDATORY;?>
											<select class="form-control select2" id="salutation" name="salutation" style="width:100%;">
											<option value="">Select</option>
											<?php 				
											for($sli=0; $sli<count($allsalutation); $sli++) {
											echo "<option value='".$allsalutation[$sli]['salutation']."' >".$allsalutation[$sli]['salutation']."</option>"; 
											}
											?>
											</select>
										</div>										  
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">First Name</label><?php echo $MANDATORY;?>
											<input type="text" class="form-control" id="name_first" name="name_first" placeholder="Enter First Name" value="">
											<input type="hidden" name="registrationfrom" value="customer">
										</div>
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Last Name</label><?php echo $MANDATORY;?>
											<input type="text" class="form-control" id="name_last" name="name_last" placeholder="Enter Last Name" value="">
										</div>
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">DOB</label>
											<input type="text" class="form-control datepicker" id="dob" name="dob" placeholder="Enter DOB(Format: DD/MM/YYYY)" value="">
										</div>	
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Marital Status</label>
											<div class="row" style="width:100%;">
												<input type="radio" id="marital_status1" name="marital_status" value="Married">Married
												<input type="radio" id="marital_status2" name="marital_status" value="UnMarried">UnMarried
											</div>
										</div>
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Aniv. Date</label>
										  <input type="text" class="form-control datepicker" id="anniversary" name="anniversary" placeholder="Format: DD/MM/YYYY" value="">
										</div>	
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Address</label><?php echo $MANDATORY;?>
										  <input type="text" class="form-control" id="address2" name="address2" placeholder="Enter Address" value="">
										</div>									  
									</div><!-- /.col -->	
									
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Country</label><?php echo $MANDATORY;?>
											<select class="form-control select2" id="country" name="country" style="width:100%;" onchange="getState(this.value);">
											<option value="" selected>Select</option>
											<?php 				
											for($ci=0; $ci<count($allcountry); $ci++) {	
												if($allcountry[$ci]['id'] == '101'){$ciselected = 'selected="selected"';}else{$ciselected = '';}
												echo "<option value='".$allcountry[$ci]['id']."' $ciselected>".$allcountry[$ci]['name']."</option>"; 
											}
											?>
											</select>
										</div>
									</div><!-- /.col -->
									
									<div class="col-lg-4">						
										<div class="form-group">
										  <label for="name">State</label><?php echo $MANDATORY;?>
										  <div id="ajaxstate" style="width:100%;" >
												<select class="form-control select2" id="state" name="state" style="width:100%;">
													<option value="" selected>Select</option>
													</select>
											</div>
										</div>
									</div><!-- /.col -->
									
								</div>
								
								<div class="col-lg-12">									
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">City</label><?php echo $MANDATORY;?>										  
											<div id="ajaxcity" style="width:100%;">
											<select class="form-control select2" id="city" name="city" style="width:100%;">
											<option value="" selected>Select</option>
											</select> 
											</div>
										</div>
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Pin Code</label><?php echo $MANDATORY;?>
										  <input type="text" class="form-control" id="pin" name="pin" onKeyPress="return checkalphanumeric(event);" placeholder="Enter Pin Code" maxlength="8" value="">
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
										<label for="name">Mobile</label><?php echo $MANDATORY;?>
										<div class="form-control2" >
										<input type="text"  name="contact_no1" id="contact_no1" maxlength="13" placeholder="Primary Contact No" class="form-control" onKeyPress="return checkIt(event);" value=""/>&nbsp;										
										</div>
										</div>	
									</div><!-- /.col -->
									
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">										
										<div class="form-group" id="addinput">
										<label for="name">Mobile (Office)</label>										
										
										<input type="text" class="form-control" id="contact_no2" name="contact_no2" placeholder="Mobile (Office)" onKeyPress="return checkIt(event);" maxlength="13" value="">
										
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Email</label>
										  <input type="text" class="form-control" id="email_1" name="email_1" placeholder="Enter Email" value="">
										</div>	
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Connecting Preference</label>
											<select class="form-control" id="contact_preference" name="contact_preference">
											<option value="" >Select</option>
											<option value="SMS" >SMS</option>
											<option value="CALL" >CALL</option>
											<option value="EMAIL" >EMAIL</option>
											</select>
										</div>	
									</div><!-- /.col -->
									
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-12">
										<div class="form-group">
											<label for="name">Remarks</label>
											<textarea class="form-control" id="notes" name="notes" placeholder="Enter Notes"></textarea>
										</div>	
									</div>
								</div>
								
								<div class="col-lg-12" style="width:100%;">
									<div class="col-lg-12" style="width:100%;">
										<img src="captcha.php" alt="CAPTCHA code">
									</div>
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
											<input type="text" class="form-control" id="captcha" name="captcha" placeholder="Enter Above Security Code" value="">
										</div>	
									</div>
								</div>
                           </div><!-- /.row -->
                           
                           <div class="row">
                              <div class="col-lg-12">
                                   <div class="form-group center">
                                      <input type="submit" name="submit" onclick="return validateuser();" id="submit" class="btn btn-warning left-10" value="<?php echo $btnvalue; ?>"/>
                                   </div>
                               </div><!-- /.col -->
             				 </div><!-- /.row -->
                           </form>
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
      </div><!-- /.content-wrapper -->
      
      
	<footer class='main-footer' style="margin-left: 0px; text-align:center;"><strong>Copyright &copy; 2016 SUEMUE.COM </strong> All rights reserved.</footer>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->
	<!-- jQuery 2.1.4 -->
    <script src="<?php echo $base_url; ?>plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="<?php echo $base_url; ?>dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<script src="<?php echo $base_url; ?>bootstrap/js/bootstrap-datepicker.js"></script>
	<script type="text/javascript">
	
	$(document).ready(function () {		
		$('.datepicker').datepicker({
			format: "dd/mm/yyyy",
			autoclose: true
		});
		
		$.ajax({
			url: "index.php",
			type: 'POST',
			context: this,
			data: {getState:'ajaxState',id:'101'},
			success: function(response){
				$('#ajaxstate').html(response);
			}
		});
		
		$("#message").fadeIn('slow').delay(2000).fadeOut('slow');
	});	
	
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="<?php echo $base_url; ?>bootstrap/js/bootstrap.min.js"></script>
    <script src="<?php echo $base_url; ?>plugins/select2/select2.js"></script>

    <!-- Bootstrap WYSIHTML5 -->
    <!--<script src="<?php echo $base_url; ?>plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>-->
	<script>
	//$('#notes').wysihtml5();
	</script>
   
</body>
</html>