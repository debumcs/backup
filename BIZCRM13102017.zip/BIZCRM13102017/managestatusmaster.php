<?php 
	require_once('include/auth.php');
	require_once('class/class.statusmaster.php');
	$objStatus = new Statusmaster();
	
	$action = "";
	$action = $_GET["action"];
	$id = $_GET["id"];
	$msgD = '';
	
		
	if($action=="Edit")
	{
	    $btnvalue = "UPDATE";
		$data = $objStatus->getById($id);
		
	}elseif($action=="Add")
	{
		$btnvalue = "SAVE";
		
	}else{
		$btnvalue = "";
		$alldata = $objStatus->getAll();
	}
	
	if(isset($_POST['submit']))
	{
		$objStatus->save();
		exit();
	}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | Manage Status</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Bootstrap time Picker -->
    <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
    <!-- Date Picker -->
    <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<script type="text/javascript" language="javascript">

		function validaterel(){
            
            if(document.getElementById('statusname').value =='' )
            {
				alert('Please enter relation name!');
				document.getElementById('statusname').focus();
				return false;
			}
			else if(document.getElementById('description').value =='' )
			{
				alert('Please enter description!');
				document.getElementById('description').focus();
				return false;
			}else if(document.getElementById('type').value =='' )
			{
				alert('Please enter agency type!');
				document.getElementById('type').focus();
				return false;
			}else if(document.getElementById('status_type').value =='' )
			{
				alert('Please enter status type!');
				document.getElementById('status_type').focus();
				return false;
			}			
			else{
				return true;
			}
			
      	}
	
	</script>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
     
   <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objStatus->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objStatus->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Status Master
          </h1>
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Control Panel</li>
            <li class="active">Status Master</li><li class="active"><?php echo $action; ?></li>
          </ol>
        </section><!--CONTENT HEADER-->
        <?php if($action == 'Add' || $action == 'Edit'){?>
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title"><?php echo $action; ?> Status</h3><span style='float:right'>Fields marked with a asterisk (<font color='red'>*</font>) are mandatory.</span>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <form action="" name="statusmaster" id="statusmaster" method="post" >
							<div class="row">
								<div class="col-lg-12">	
									<div class="col-lg-6">
										<div class="form-group">
											<label>Status<font color='red'>*</font></label>
											<input type="text" class="form-control" id="statusname"  name="statusname" placeholder="Enter Status" value="<?php echo $data['statusname']; ?>">
										</div><!-- /.form-group -->
									</div><!-- /.col -->
								  
									<div class="col-lg-6">
										<div class="form-group">
											<label for="name">Description<font color='red'>*</font> </label>
											<input type="text" class="form-control" id="description" name="description" placeholder="Enter Description" value="<?php echo $data['description']; ?>">
											<input type="hidden" id="id" name="id" value="<?php echo $data['id']; ?>" />
										</div>
										
									</div><!-- /.col -->
								</div><!-- /.col -->
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
											<label>Agency Type<font color='red'>*</font></label>
											<select class="form-control" id="type" name="type" style="width:100%;">
											<option value="" selected>Select Agency Type</option>
											<option value="Dying" <?php if($data['type']=='Dying'){echo "selected";} ?>>Dying</option>
											<option value="Embroidering" <?php if($data['type']=='Embroidering'){echo "selected";} ?>>Embroidering</option>
											<option value="FabricCutting" <?php if($data['type']=='FabricCutting'){echo "selected";} ?>>FabricCutting</option>
											<option value="Marking" <?php if($data['type']=='Marking'){echo "selected";} ?>>Marking</option>
											<option value="MasterCutting" <?php if($data['type']=='MasterCutting'){echo "selected";} ?>>MasterCutting</option>
											<option value="Tailoring" <?php if($data['type']=='Tailoring'){echo "selected";} ?>>Tailoring</option>
											</select>
										</div><!-- /.form-group -->
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
											<!--assinged, returned, received, closed, cancelled, reopened -->
											<label>Status Type<font color='red'>*</font></label>
											<div class="col-lg-12">
												<input type="radio" name="status_type" id="status_type1" <?php if($action=='Add'){echo "checked";} if($data['status_type']=='Initial'){echo "checked";} ?> value="Initial" />Initial
												<input type="radio" name="status_type" id="status_type2" <?php if($data['status_type']=='Middle'){echo "checked";} ?> value="Middle" />Middle
												<input type="radio" name="status_type" id="status_type3" <?php if($data['status_type']=='Agency'){echo "checked";} ?> value="Agency" />Agency
												<input type="radio" name="status_type" id="status_type4" <?php if($data['status_type']=='End'){echo "checked";} ?> value="End" />End
											</div>
										</div><!-- /.form-group -->
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
											<label>Auto-generated Challan Number</label>
											<div class="col-lg-12">
											<input type="radio" name="autochallan" id="autochallan1" <?php if($action=='Add'){echo "checked";} if($data['autochallan']=='No'){echo "checked";} ?> value="No" />No
											<input type="radio" name="autochallan" id="autochallan2" <?php if($data['autochallan']=='Yes'){echo "checked";} ?> value="Yes" />Yes
											</div>
										</div>
									</div><!-- /.col -->
								
								</div>
								
                           </div><!-- /.row -->
                           
                           <div class="row">
                              <div class="col-lg-12">
                                   <div class="form-group center">
                                      <input type="submit" name="submit" id="submit" class="btn btn-warning left-10" value="<?php echo $btnvalue; ?>" onclick="return validaterel();" />
									  <a href="managestatusmaster.php" class="btn btn-warning left-10">View All</a>
                                   </div>
                               </div><!-- /.col -->
             				 </div><!-- /.row -->
                           </form>
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
		<?php }else{ ?>
		
		<section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title pull-right"><a href="managestatusmaster.php?action=Add&id=">Add New</a></h3>
                        </div><!-- /.box-header -->
                        <div class='box-body table-responsive'>
                            <table id="example111" class="table table-bordered table-striped">
							<thead>
							  <tr>
								<th>Status</th>
								<th>Agency Type</th>
								<th>Status Type</th>
								<th>Action</th>							
							  </tr>
							</thead>
                    <tbody>
					<?php for($i=0; $i<count($alldata); $i++){ ?>	
						<tr>
                            <td><?php print $alldata[$i]['statusname']; ?></td>
							<td><?php print $alldata[$i]['type']; ?></td>
							<td><?php print $alldata[$i]['status_type']; ?></td>
							<td><a href="managestatusmaster.php?action=Edit&id=<?php print $alldata[$i]['id']; ?>">Edit</a></td>
				        </tr>
                    <?php } ?>						
                    </tbody>
                    
                  </table>
                           
                          </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
            </div><!-- /.row -->
        </section><!--CONTENT-->		
		<?php } ?>
		
      </div><!-- /.content-wrapper -->
      
      
      <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
    
    <!-- daterangepicker -->
    <script src="dist/js/moment.min.js"></script>
    <!-- bootstrap time picker -->
    <script src="plugins/timepicker/bootstrap-timepicker.js"></script>
    <!-- iCheck 1.0.1 -->
    <script src="plugins/iCheck/icheck.min.js"></script>
    <script src="plugins/daterangepicker/daterangepicker.js"></script>
    <!-- datepicker -->
    <script src="plugins/datepicker/bootstrap-datepicker.js"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js"></script>
    
    <script type="text/javascript" src="plugins/datepicker/bootstrap-clockpicker.min.js"></script>
    
    <script type="text/javascript" src="dist/js/date.js"></script>
    
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <script>
		$("#message").fadeIn('slow').delay(5000).fadeOut('slow');
		$(".select2").select2();
			
		//iCheck for checkbox and radio inputs
        $('input[type="radio"].minimal').iCheck({
           radioClass: 'iradio_minimal-orange'
        });
	</script>
  </body>
</html>