<?php 
include_once("class.config.php");
class Customer extends config{
	
	//public $database;
	
	function __construct(){
		
		if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
		{
			$this->redirect('index.php');
			exit();
		}
	}
	
	function __destruct(){
		//parent::__construct();
		//$database->close;
	}
	
	public function getCustomerDetailByID($cust_id) {
		$database = new Database();
		if($cust_id){
			
			$sql = "SELECT c.*, ct.name city_name, co.name AS country_name, st.name state_name, '' AS alt_no FROM customer AS c LEFT JOIN cities AS ct ON ct.id=c.city LEFT JOIN countries AS co ON co.id=c.country LEFT JOIN states AS st ON st.id=c.state WHERE c.cust_id='".$cust_id."'";
			//echo $sql; die();
			$result = $database->query($sql);
			$alldata = array();
						
			while($field = $result->fetch_array(MYSQLI_ASSOC))
			{
				$alldata[] = $field;
			}
		}
	    
		$database->close();
		
		//return $field = $result->fetch_assoc();
		return $alldata;
	}
	
	public function checkCustomerCode($cust_id){
		$database = new Database();
		
		$sql = "SELECT COUNT(*) AS total FROM `customer` WHERE cust_id = '".$cust_id."'";
		
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$result->close();
		$database->close();
		return $data;
	}
	
	public function addCustomernote($notes,$custid,$agent_id,$ip)  
	{
		$database = new Database();

		$timestamp = date('Y-m-d H:i:s');

		$sql="insert into notes(customer_id,notes,notes_date,status,agent_id,ipaddr) VALUES('".$custid."','".$notes."','".$timestamp."','1','".$agent_id."','".$ip."')";
		$res = $database->query($sql);
		$database->close();
		return $result = $this->getCustomerNotes($custid);
	}
	  
	public function getCustomerNotes($cust_id)
	{
		$database = new Database();

		if($cust_id){
			$sql = "SELECT a.*, b.name FROM notes a LEFT JOIN adminuser b ON a.agent_id = b.username WHERE a.customer_id ='".$cust_id."' ORDER BY id DESC"; 
			$result = $database->query($sql);

			$alldata = array();

			while($field = $result->fetch_array(MYSQLI_ASSOC))
			{
				$alldata[] = $field;
			}
		}
		$database->close();
		return $alldata;
	}
	
	public function getCustomerInfo($customer_id){
		$database = new Database();
		
		$sql = "SELECT a.cust_id, a.salutation, a.name_first, a.name_last, a.address1, a.address2, a.pin, a.contact_no1, a.contact_no2, a.email_1, a.email_2, a.relation_a, a.refferal_id, a.dob, a.anniversary, a.notes, a.discount_categoryegory, a.advance_categoryegory, b.name AS city, c.name AS state, d.name AS country FROM customer a LEFT JOIN cities b ON a.city = b.id LEFT JOIN states c ON a.state = c.id LEFT JOIN countries d ON a.country = d.id WHERE a.cust_id = '".$customer_id."'";
		
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$result->close();
		$database->close();
		return $data;
	}
	
	public function checkReferalCode($referal_id){
		$database = new Database();
		
		$sql = "SELECT 1 AS rstatus, referrer_name FROM ( SELECT cust_id AS referal_id, CONCAT(name_first,' ',name_last) AS referrer_name  FROM customer UNION SELECT username AS referal_id, name AS referrer_name FROM adminuser ) a WHERE referal_id = '".$referal_id."'";
		
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$result->close();
		$database->close();
		return $data;
	}
	
	public function getCustomerID() {
		$database = new Database();
		
		$sql = "SELECT func_get_Cus_ID() AS cus_id";
		
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}
	
	public function getAll() {
		$database = new Database();
		$proAction = 'CUSALL';			
		
		$sql = "SELECT * FROM customer ORDER BY action_date DESC";
		//echo $sql; die();
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getCustomerDetailsID($cust_id) {
		$database = new Database();
	
		// Initialize result array
		$result = array();
		$id = $this->sanitize($id);
		$sql = "SELECT * FROM customer WHERE cust_id = '".$cust_id."'";
		
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}
	
	public function getById($id) {
		$database = new Database();
	
		// Initialize result array
		$result = array();
		$id = $this->sanitize($id);
		$sql = "SELECT * FROM customer WHERE id = '".$id."'";
		
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}
	
	/*public function savecontact($cust_id, $alt_contact_code, $alt_contact_no, $alt_contact_tag, $createdby, $action_date, $ipaddress){
		$database = new Database();
		
		for($nos = 0; $nos < count($alt_contact_no); $nos++ ){
			$sql = "INSERT INTO customer_alt_contact_no(cust_id, alt_contact_code, alt_contact_no, alt_contact_tag, createdby, createdon, ipaddress) VALUES ('$cust_id', '".$alt_contact_code[$nos]."', '".$alt_contact_no[$nos]."', '".$alt_contact_tag[$nos]."', '$createdby', NOW(), '$ipaddress')";
			$result = $database->prepare($sql);
			$result->execute();
			$result->close();
		}
		$database->close();		
	}
	
	public function deletecontact($cust_id){
		$database = new Database();
		$sql = "DELETE FROM customer_alt_contact_no WHERE cust_id = '".$cust_id."'";
		$result = $database->prepare($sql);
		$result->execute();
		$result->close();
		$database->close();		
	}*/
	
	public function save() {
		
		$database = new Database();
		
		$registrationfrom	= $this->sanitize($_POST["registrationfrom"]);
		
		$id 				= $this->sanitize($_POST["id"]);		
		
		$salutation 		= $this->sanitize($_POST["salutation"]);
		$name_first 		= $this->sanitize($_POST["name_first"]);
		$name_last 			= $this->sanitize($_POST["name_last"]);
		
		if($registrationfrom == 'admin'){
			$cust_id = $this->sanitize($_POST["cust_id"]);
		}else{
			$last_cust_id 	= $this->last_insert_customer_id();
			//$cust_id		= strtoupper(substr($name_first, 0,2)).strtoupper(substr($name_last, 0,2)).str_pad((intval($last_cust_id) + 1), 5, "0", STR_PAD_LEFT);
			$custid = $this->getCustomerID();
			$cust_id = $custid['cus_id'];
		}
		
		$dob 				= $this->date_dmy_ymd($this->sanitize($_POST["dob"]));
		
		$marital_status 	= $this->sanitize($_POST["marital_status"]);
		
		if($_POST["anniversary"] == ''){
			$anniversary = '';
		}else{
			$anniversary	= $this->date_dmy_ymd($this->sanitize($_POST["anniversary"]));
		}
				
		$email_1 			= $this->sanitize($_POST["email_1"]);
		$contact_preference	= $this->sanitize($_POST["contact_preference"]);
		
		$address2 			= $this->sanitize($_POST["address2"]);
		$city 				= $this->sanitize($_POST["city"]);
		$pin 				= $this->sanitize($_POST["pin"]);
		$state 				= $this->sanitize($_POST["state"]);
		$country 			= $this->sanitize($_POST["country"]);
		
		$contact_no1 		= $this->sanitize($_POST["contact_no1"]);
		$contact_no2		= $this->sanitize($_POST["contact_no2"]);
		
		$notes 				= $this->sanitize($_POST["notes"]);
		
		$ipaddress 			= $this->sanitize($_SERVER['REMOTE_ADDR']);
		$createdby 			= $this->sanitize($_SESSION['ADMIN_NAME']);
		$action_date 		= date('Y-m-d H:i:s');
				
		$submit 			= $this->sanitize($_POST["submit"]);
		if($submit == 'UPDATE'){
			$refferal_id 		= $this->sanitize($_POST["refferal_id"]);
			$relation_a 		= $this->sanitize($_POST["relation_a"]);
			$family 			= $this->sanitize($_POST["family"]);
			$customer_category 	= $this->sanitize($_POST["customer_category"]);
			$source 			= $this->sanitize($_POST["source"]);
		}
		if($submit == 'SAVE'){
			
			$sql = "INSERT INTO customer(cust_id, salutation, name_first, name_last, address2, city, pin, state, country, contact_no1, contact_no2, email_1, contact_preference, dob, marital_status, anniversary, notes, createdby, action_date, ipaddress) VALUES ('$cust_id', '$salutation', '$name_first', '$name_last', '$address2', '$city', '$pin', '$state', '$country','$contact_no1', '$contact_no2', '$email_1', '$contact_preference', '$dob', '$marital_status', '$anniversary', '$notes', '$createdby', '$action_date', '$ipaddress');";
			$result = $database->prepare($sql);
			//echo $sql; die();
			if($result->execute()){
				$_SESSION['msgD'] = "Customer Data Created Successfully";
			}else{
				$_SESSION['msgD'] = "Error found on customer data creation.";
			}
		}
		
		if($submit == 'UPDATE'){
			
			$sql_log = "INSERT INTO customer_log SELECT id, cust_id, salutation, name_first, name_middle, name_last, address1, address2, city, pin, state, country, contact_no1, contact_no2, email_1, email_2, relation_a, refferal_id, family, contact_preference, dob, marital_status, anniversary, notes, discount_category, advance_category, customer_category, source, customer_since, createdby, action_date, ipaddress FROM customer WHERE id = '".$id."'";
			$result_log = $database->query($sql_log);
			
			$sql = "UPDATE customer SET salutation='$salutation', name_first='$name_first', name_last='$name_last', address2='$address2', city='$city', pin='$pin', state='$state', country='$country', contact_no1='$contact_no1', contact_no2='$contact_no2', email_1='$email_1', contact_preference='$contact_preference', dob='$dob', marital_status='$marital_status', anniversary='$anniversary', notes='$notes', refferal_id='$refferal_id', relation_a='$relation_a', family='$family', customer_category='$customer_category', source='$source' WHERE id = '$id'";
			
			$result = $database->prepare($sql);
			if($result->execute()){
				$_SESSION['msgD'] = "Customer Data Updated Successfully";
			}else{
				$_SESSION['msgD'] = "Error found on customer data update.";
			}			
		}
		
		$result->close();
		
		$database->close();
		if($registrationfrom == 'customer'){
			return '1';
		}else{
			$this->redirect('customer_order.php?cust_id='.$cust_id);
		}
			
	}
	
	public function last_insert_customer_id(){
		$database = new Database();
	
		$result = array();
		$sql = "SELECT id FROM customer ORDER BY id DESC LIMIT 1";		
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data['id'];
	}
}

?>
