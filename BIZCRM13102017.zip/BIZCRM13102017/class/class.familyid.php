<?php 
error_reporting(E_ERROR);
ini_set('display_errors', 1);
include_once("database.class.php");
include_once("class.config.php");

class Familyid extends config{
	
	//public $database;
	
	function __construct() {
		if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
		{
			$this->redirect('index.php');
			exit();
		}
	}
	
	function __destruct() {
		//parent::__construct();
		//$database->close;
	}
	
	public function getFamilyID() {
		$database = new Database();
		
		$sql = "SELECT func_get_fmi_id() AS fmi_id";
		
		$result = $database->query($sql);
		if (!$result) {
			echo "<p>There was an error in query: $sql</p>";
			echo $database->error;
			die();
		}
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}
	
	public function getAll() {
		$database = new Database();
		
		$sql = "SELECT * FROM familyid ORDER BY modifiedon DESC";
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getById($id){
		$database = new Database();

		$result = array();
		$id = $this->sanitize($id);
		$sql = "SELECT * FROM familyid WHERE id = '".$id."'";

		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}	
	
	public function save(){
		$database = new Database();
		
		$admin_name = $_SESSION['ADMIN_NAME'];
		$submit = $this->sanitize($_POST["submit"]);
		
		$id 			= $this->sanitize($_POST["id"]);
		$familyid 		= $this->sanitize($_POST["familyid"]);
        $shortname 		= $this->sanitize($_POST["shortname"]);
		$longname 		= $this->sanitize($_POST["longname"]);
		$address 		= $this->sanitize($_POST["address"]);
		$contactno 		= $this->sanitize($_POST["contactno"]);
		$email 			= $this->sanitize($_POST["email"]);
		$createdon 		= date('Y-m-d H:i:s');
		$createdby 		= $admin_name? $admin_name: '';
		$modifiedon 	= date('Y-m-d H:i:s');
		$modifiedby 	= $admin_name? $admin_name: '';
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		if($submit == 'SAVE'){
			$sql = "INSERT INTO familyid(familyid, shortname, longname, address, contactno, email, createdby, createdon, modifiedby, modifiedon, ipaddress) VALUES ('".$familyid."', '".$shortname."', '".$longname."', '".$address."', '".$contactno."', '".$email."', '".$createdby."', '".$createdon."', '".$modifiedby."', '".$modifiedon."', '".$ipaddress."')";			
		}
		if($submit == 'UPDATE'){
			
			$sql_log = "INSERT INTO familyid_log SELECT id, familyid, shortname, longname, address, contactno, email, createdby, createdon, '".$modifiedby."', '".$modifiedon."', '".$ipaddress."' FROM familyid WHERE id = '".$id."'";
			$result_log = $database->query($sql_log);
			
			$sql = "UPDATE familyid SET shortname='".$shortname."', longname='".$longname."', address='".$address."', contactno='".$contactno."', email='".$email."', modifiedby='".$modifiedby."', modifiedon='".$modifiedon."', ipaddress='".$ipaddress."' WHERE id = '".$id."'";	
		}
		
		$result = $database->prepare($sql);
		if($result->execute()){
			if($submit == 'SAVE'){
				$_SESSION['msgD'] = 'Family Data Inserted Successfully.';
			}else{
				$_SESSION['msgD'] = 'Family Data Updated Successfully.';
			}			
		}else{
			$_SESSION['msgD'] = 'Error while executing query.';
		}
		$result->close();
		$database->close();
		$this->redirect('managefamilyid.php');
	}	
}

?>
