<?php 
error_reporting(E_ERROR);
ini_set('display_errors', 1);
include_once("database.class.php");
include_once("class.config.php");

class Source extends config{
	
	//public $database;
	
	function __construct() {
		if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
		{
			$this->redirect('index.php');
			exit();
		}
	}
	
	function __destruct() {
		//parent::__construct();
		//$database->close;
	}
	
	public function getAll() {
		$database = new Database();
		$proAction = 'SRCALL';			
		
		$sql = "SELECT * FROM source ORDER BY modifiedon DESC";
		//echo $sql; die();
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getById($id){
		$database = new Database();
	
		// Initialize result array
		$result = array();
		$proAction = 'SRCGET';			
		$psuid = $this->sanitize($id);
		$sql = "SELECT * FROM source WHERE id = '".$psuid."'";
		//echo $sql; die();
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}	
	
	public function save(){
		$database = new Database();
		
		$admin_name = $_SESSION['ADMIN_NAME'];
		$submit = $this->sanitize($_POST["submit"]);
		
		$id 			= $this->sanitize($_POST["id"]);
		$sourcename 	= $this->sanitize($_POST["sourcename"]);
        $description 	= $this->sanitize($_POST["description"]);
		$createdon 		= date('Y-m-d H:i:s');
		$createdby 		= $admin_name? $admin_name: '';
		$modifiedon 	= date('Y-m-d H:i:s');
		$modifiedby 	= $admin_name? $admin_name: '';
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		if($submit == 'SAVE'){
			$sql = "INSERT INTO source(sourcename, description, createdby, createdon, modifiedby, modifiedon, ipaddress) VALUES ('".$sourcename."', '".$description."', '".$createdby."', '".$createdon."', '".$modifiedby."', '".$modifiedon."', '".$ipaddress."')";
		}
		if($submit == 'UPDATE'){
			$sql_log = "INSERT INTO source_log SELECT id, sourcename, description, createdby, createdon, '".$modifiedby."', '".$modifiedon."', '".$ipaddress."' FROM source WHERE id = '".$id."'";
			$result_log = $database->query($sql_log);
			
			$sql = "UPDATE source SET sourcename='".$sourcename."', description='".$description."', modifiedby='".$modifiedby."', modifiedon='".$modifiedon."', ipaddress='".$ipaddress."' WHERE id = '".$id."'";
		}
		
		$result = $database->prepare($sql);
		if($result->execute()){
			if($submit == 'SAVE'){
				$_SESSION['msgD'] = 'Source Data Inserted Successfully';
			}else{
				$_SESSION['msgD'] = 'Source Data Updated Successfully';
			}			
		}else{
			$_SESSION['msgD'] = 'Error while executing query.';
		}
		$result->close();
		$database->close();
		$this->redirect('managesource.php');
	}	
}

?>
