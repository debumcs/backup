<?php 
error_reporting(E_ERROR);
ini_set('display_errors', 1);
include_once("database.class.php");
include_once("class.config.php");

class Stylemaster extends config{
	
	//public $database;
	
	function __construct() {
		//parent::__construct(); 
		//$database = new Database();
		if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
		{
			$this->redirect('index.php');
			exit();
		}
	}
	
	function __destruct() {
		//parent::__construct();
		//$database->close;
	}
	
	// Style group

	public function getAllgroup() {
		
		$sql = "SELECT * FROM style_group order by groupname asc";
		$result = $this->fetchAssoc($sql);
		
		return $result;
	}
	
	public function getgroupById($id){
		$database = new Database();
		
		$id = $this->sanitize($id);
		$sql = "SELECT * FROM style_group where id='".$id."'";
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}
	
	public function savegroup(){
		$database 		= new Database();
		
		$admin_name 	= $_SESSION['ADMIN_NAME'];
		$submit 		= $this->sanitize($_POST["submit"]);
		
		$id 				= $this->sanitize($_POST["id"]);
		$groupname 			= $this->sanitize($_POST["groupname"]);
		$style_group_code 	= $this->sanitize($_POST["style_group_code"]);				
		$description 		= $this->sanitize($_POST["description"]);
				
		$createdby 		= $admin_name? $admin_name: '';
		$createdon 		= date('Y-m-d H:i:s');

		$modifiedby		= $admin_name? $admin_name: '';
		$modifiedon		= date('Y-m-d H:i:s');

        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		if($submit == 'SAVE'){
			$sql = "INSERT INTO style_group(groupname, style_group_code, description, createdby, createdon, modifiedby, modifiedon, ipaddress) VALUES ('".$groupname."', '".$style_group_code."', '".$description."', '".$createdby."', '".$createdon."', '".$modifiedby."', '".$modifiedon."', '".$ipaddress."')";
		}
		if($submit == 'UPDATE'){
			$sql_log = "INSERT INTO style_group_log SELECT id, groupname, style_group_code, description, createdby, createdon, '".$modifiedby."', '".$modifiedon."', ipaddress FROM style_group WHERE id = '".$id."'";
			$result_log = $database->query($sql_log);
			
			$sql = "UPDATE style_group SET groupname='".$groupname."', style_group_code='".$style_group_code."', description='".$description."', modifiedby='".$modifiedby."', modifiedon='".$modifiedon."', ipaddress='".$ipaddress."' WHERE id = '".$id."'";
		}
		//echo $sql; die();
		$result = $database->prepare($sql);
		if($result->execute()){
			if($submit == 'SAVE'){
				$_SESSION['msgD'] = 'Style Group inserted successfully.';
			}else{
				$_SESSION['msgD'] = 'Style Group updated successfully.';
			}			
		}else{
			$_SESSION['msgD'] = 'Error while executing query.';
		}
        
		$result->close();
		$database->close();
		$this->redirect('managestylegroup.php');
	}
	
	// style 
	public function getCustomizedStyleDetails($stylecode) {
		$database = new Database();
	    
		$stylecode = $this->sanitize($stylecode);
	   	$sql = "SELECT * FROM customized_style WHERE style_code = '".$stylecode."'";
		
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}
	
	public function getStyleDetails($stylecode) {
		$database = new Database();
	    
		$stylecode = $this->sanitize($stylecode);
	   	$sql = "SELECT b.groupname, a.* FROM style_master a LEFT JOIN style_group b ON a.style_group_code = b.id WHERE style_code = '".$stylecode."'";
		
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}
	
	public function getAllCustomized(){
		$database = new Database();
		
		$sql = "SELECT * FROM customized_style order by modifieddate desc";
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getAll(){
		$database = new Database();
		$proAction = 'STYLEALL';			
		
		$sql = "SELECT S.*, A.name FROM style_master S INNER JOIN adminuser A ON S.createdby=A.username";
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getById($id) {
		$database = new Database();
	        
		// Initialize result array
		$result = array();
		$proAction = 'STYLEGET';			
		$id = $this->sanitize($id);
	   	$sql = "SELECT * FROM style_master WHERE id = '".$id."'";
		//$sql; die();
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}

	public function save() {

		$database = new Database();

		$submit = $this->sanitize($_POST["submit"]);
		$id = $this->sanitize($_POST["id"]);
		
		$style_code = $this->sanitize($_POST["style_code"]);
		$description     	= $this->sanitize($_POST["description"]);
		$style_group_code	= $this->sanitize($_POST["style_group_code"]);
		$designer_code		= $this->sanitize($_POST["designer_code"]);
		$creation_date		= $this->date_dmy_ymd($this->sanitize($_POST["creation_date"]));
		$cost_price			= $this->sanitize($_POST["cost_price"]);
		$selling_price		= $this->sanitize($_POST["selling_price"]);
		$status				= $this->sanitize($_POST["status"]);
		$style_group_code	= $this->sanitize($_POST["style_group_code"]);
		
		$createddate		= date('Y-m-d H:i:s');
		$createdby 			= $this->sanitize($_SESSION['ADMIN_NAME']);
		$modifieddate		= date('Y-m-d H:i:s');
		$modifiedby 		= $this->sanitize($_SESSION['ADMIN_NAME']);
		$ipadd 				= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		if(is_uploaded_file($_FILES['styleimage']['tmp_name']))
		{	
			$file 			= $_FILES['styleimage']['name']; 
			$filesize 		= $_FILES['styleimage']['size'];  
			$array 			= explode('.', $file);
			$fileName		= $array[0];
			$fileExt		= $array[1];
			$imagename		= $fileName."_".time().".".$fileExt;
			$image_tmp  	= $_FILES['styleimage']['tmp_name'];
			$imagelocation	= "styleimage/".$imagename;
			move_uploaded_file($image_tmp,"styleimage/".$imagename);
		}
		else
		{       
			$imagename		= $_POST['image_image_hidden'];
			$imagelocation	= $_POST['image_location_hidden'];
		}
		
		if($submit == 'SAVE')
		{
			$sql = "INSERT INTO style_master(style_code, description, style_group_code, designer_code, creation_date, cost_price, selling_price, imagename, imagelocation, createdby, createddate, ipaddr, modifieddate, modifiedby) VALUES ('".$style_code."', '".$description."', '".$style_group_code."', '".$designer_code."', '".$creation_date."', '".$cost_price."', '".$selling_price."', '".$imagename."', '".$imagelocation."', '".$createdby."', '".$createddate."', '".$ipaddr."', '".$modifieddate."', '".$modifiedby."')";
		}
		if($submit == 'UPDATE')
		{
			$sql_log = "INSERT INTO style_master_log SELECT id, style_code, description, style_group_code, designer_code, creation_date, cost_price, selling_price,  imagename, imagelocation, status, createdby, createddate, '".$ipaddr."', '".$modifieddate."', '".$modifiedby."' FROM style_master WHERE id = '".$id."'";
			$result_log = $database->query($sql_log);
			
			$sql = "UPDATE style_master SET style_code='".$style_code."', description='".$description."', style_group_code='".$style_group_code."', designer_code='".$designer_code."', creation_date='".$creation_date."', cost_price='".$cost_price."', selling_price='".$selling_price."', imagename='".$imagename."', imagelocation='".$imagelocation."', status='".$status."', ipaddr='".$ipaddr."', modifieddate='".$modifieddate."', modifiedby='".$modifiedby."' WHERE id='".$id."'";
			
		}
		
		$result = $database->prepare($sql);
		if($result->execute()){
			if($submit == 'SAVE'){
				$_SESSION['msgD'] = 'Style master data inserted successfully.';
			}else{
				$_SESSION['msgD'] = 'Style master data updated successfully.';
			}			
		}else{
			$_SESSION['msgD'] = 'Error while executing query.';
		}
		
		$database->close();
              
		$this->redirect('managestyleMaster.php');
	}	
}

?>
