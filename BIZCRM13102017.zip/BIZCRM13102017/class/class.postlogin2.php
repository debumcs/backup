<?php
//error_reporting(E_ERROR);
ini_set('display_errors', 0);
include_once("database.class.php");
include_once("class.config.php");

class postlogin extends config{
    
    function __construct() {
		//parent::__construct(); 
		//$database = new Database();
	}
	
	function __destruct() {
		//parent::__construct();
		//$database->close;
	}
        
              
    public function getuserlogin($username,$password,$ipaddress) {
	
        $fields	=	$this->checkuserlogin($username,$password);
		
		if(($fields['errorFlag'] == 0) || ($fields['errorFlag'] == 3)){

			session_regenerate_id();
			// Ldap Part Start here
			// LDAP variables
			$loginflag		= $fields['loginflag'];
			$ipaddress		= $_SERVER['REMOTE_ADDR'];
			/**/
			
			$result_insert2 = $this->checkothersession($username);;		
						
			if($result_insert2) {
				if($result_insert2->num_rows == 1){
					
					$fields2 = $result_insert2->fetch_array(MYSQLI_ASSOC);
					
					if($fields2['logouttime']=="0" ){
						$phpsessid = $fields2['session_id'];
						session_id($phpsessid);
						session_start();
						session_destroy();
						session_commit();
						session_start();
						
						$result_insert3 = $this->updatelogininfo($username,$phpsessid);						
						session_regenerate_id();
					}
				}
			}
			
			$_SESSION['ADMIN_NAME'] 	= $fields['username'];
			$_SESSION['ROLE'] 			= $fields['role'];
			$_SESSION['NAME'] 			= $fields['name'];
			$_SESSION['EMAILID'] 		= $fields['empemailid'];
			$_SESSION['createddate'] 	= $fields['createddate'];			
			$_SESSION['SES_ID']			= session_id();
			
			$result_insert4 = $this->insertlogininfo();
						
			if($loginflag == 0){
				$result_insert5 = $this->updateloginflag();					
			}
			
			session_write_close();
			$this->redirect("home.php");
			exit();
		}else {
			//Login failed
			$this->redirect("index.php?flag=I");
			exit();
		}
    }
	
    public function checkuserlogin($username,$password) {
        $database = new Database();
        	
        $proAction = 'LOGIN';
     	$sql_insert = "CALL spslogin('$proAction', '$username', '$password', '$session_id', '$ipaddress')";
		//echo $sql_insert;
		//die();
		$result_insert = $database->query($sql_insert);	
        $fields = $result_insert->fetch_array(MYSQLI_ASSOC);
        $database->close();
        return $fields;
    }
       
    
     public function checkothersession($username){
        $database = new Database();
        	
        // Initialize result array
		$proAction = 'CHECKOTHERSESSION';
        $sql_insert = "CALL spslogin('$proAction', '$username', '$logintime', '$session_id', '$ipaddress')";
        $result_insert = $database->query($sql_insert);	
        $fields = $result_insert->fetch_array(MYSQLI_ASSOC);
        $database->close();
        return $fields;
    }
    
    
     public function updatelogininfo($username,$phpsessid) {
        $database = new Database();
        	
        // Initialize result array
		$proAction = 'UPDATELOGININFO';
        $database->close();
        $database = new Database();
        $sql_insert = "CALL spslogin('$proAction', '$username', '$logintime', '$phpsessid', '$ipaddress')";
        $result_insert = $database->query($sql_insert);
        $fields = $result_insert->fetch_array(MYSQLI_ASSOC);
        $database->close();
        return $fields;
        
    }
    
    public function insertlogininfo() {
        $database = new Database();
        	
        // Initialize result array
		$proAction 		= 'INSERTLOGININFO';
		$ipaddress		= $_SERVER['REMOTE_ADDR'];
		$logintime		= date('Y-m-d H:i:s');
        $database = new Database();
        $sql_insert = "CALL spslogin('$proAction', '".$_SESSION['ADMIN_NAME']."', '$logintime', '".$_SESSION['SES_ID']."', '$ipaddress')";
        $result_insert = $database->query($sql_insert);
        $database->close();
        return $result_insert;
        
    }
    public function updateloginflag(){
        $database = new Database();
        	
        // Initialize result array
		$proAction = 'UPDATELOGINFLAG';
        $database->close();
        $database = new Database();
        $sql_insert = "CALL spslogin('$proAction', '".$_SESSION['ADMIN_NAME']."', '$logintime', '".$_SESSION['SES_ID']."', '$ipaddress')";
        $result_insert = $database->query($sql_insert);
        $database->close();
        return $result_insert;
        
    }
	
	public function changepassword($password, $newpassword, $confirmpassword){
        $database = new Database();
		
		$username        = $_SESSION['ADMIN_NAME'];
		$password        = $this->sanitize($_POST["password"]);
		$newpassword     = $this->sanitize($_POST["newpassword"]);
		$confirmpassword = $this->sanitize($_POST["confirmpassword"]);

        $fields	=	$this->checkuserlogin($username,$password);
		
		if($fields['errorFlag'] == 0){
                   
			$sql2  = "update adminuser set password = '".$confirmpassword."' where username='".$username."'";
			//$sql2; die();
			 
			$result = $database->prepare($sql2);
			//$result->bind_param('ss',$confirmpassword,$username);
			$result->execute();
			$result->close();
			
			$_SESSION['msgCP'] = 'Password changed successfully.';
                  	
		}
		else
		{ 
			$_SESSION['msgCP'] = 'Entered current password is wrong.';
		}
		//$database->close();
		$this->redirect('change_password.php');
    }
}
