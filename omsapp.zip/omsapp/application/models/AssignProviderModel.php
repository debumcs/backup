<?php

class AssignProviderModel extends CI_Model
{
	function __construct() {
		parent::__construct();
	}
        
	function getOrderList($filters){
		
		$url = WEBSERVICE_URL . "order/getAll";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$filters,"POST");		
		return $output;		
	}
	
	function assignProvider($data){
		///api/v1/order/assignProvider
		$url = WEBSERVICE_URL . "order/assignProvider?accountId=".$data["accountId"]."&orderNumber=".$data["orderNumber"];
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"PUT");		
		return $output;		
	}
	
	function getAccountById($accountId){
		
		$url = WEBSERVICE_URL . "account/findById/".$accountId;
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callWebService($url,$header,'',"GET");		
		return $output;		
	}
	
	function getOrderDetailsById($orderNo){
		//api/v1/order/findById/{id}
		$url = WEBSERVICE_URL . "order/findById/".$orderNo;
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callWebService($url,$header,'',"GET");		
		return $output;		
	}
	
	///api/v1/provider/getAll
	
	function getAllProvider($orderno){
		
		$url = WEBSERVICE_URL . "provider/getAll?OrderNumber=".$orderno;
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,'',"POST");		
		return $output;		
	}
}