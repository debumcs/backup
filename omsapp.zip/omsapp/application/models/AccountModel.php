<?php

class AccountModel extends CI_Model
{
	function __construct() {
		parent::__construct();
	}
        
	function getAccountList($filters){
		
		$url = WEBSERVICE_URL . "account/getAll";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$filters,"POST");		
		return $output;		
	}
	
	function getAccountById($accountId){
		
		$url = WEBSERVICE_URL . "account/findById/".$accountId;
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callWebService($url,$header,'',"GET");		
		return $output;		
	}
	
	function getAllLocations($filters){
		
		$url = WEBSERVICE_URL . "location/getAll";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$filters,"POST");		
		return $output;
	}
	
	function getLocationById($locationId){
		///api/v1/location/findById/{id}
		$url = WEBSERVICE_URL . "location/findById/".$locationId;
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callWebService($url,$header,'',"GET");		
		return $output;		
	}
	
		
	function createAccount($data){
		
		$url = WEBSERVICE_URL . "account/createAccount";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"POST");		
		return $output;		
	}
	
	function updateAccount($data){
		
		$url = WEBSERVICE_URL . "account/updateAccount";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"PUT");		
		return $output;		
	}
}