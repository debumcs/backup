<?php

class InventoryMovementModel extends CI_Model
{
	function __construct() {
		parent::__construct();
	}
	
	function fileUpload($data){
		
		$url = WEBSERVICE_URL . "account/getAll";
		//$url = "http://localhost/test/upload.php";
		$token = $this->session->userdata['token'];
		/* $header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"cache-control: no-cache",
			"content-type: multipart/form-data",
		  ); */
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		);
		
		$output = callWebServiceFileUpload($url,$header,$data,"POST");
		return $output;
	}

	function getInventoryList($filters){
		
		$url = WEBSERVICE_URL . "inventory/getAll";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$filters,"POST");		
		
		//print_r($output);die;
		if($output["responseStatusCode"] == 403){
			redirect('Login/tokenExpire', 'refresh');
		}else{
			return $output;	
		}		
	}
	
	function getShipToList($filters){
		
		$url = WEBSERVICE_URL . "inventory/getShipTo";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		//echo json_encode($filters); die();
		$output = callPostMethod($url,$header,$filters,"POST");		
		
		//print_r($output); die();
		
		if($output["responseStatusCode"] == 403){
			redirect('Login/tokenExpire', 'refresh');
		}else{
			return $output;	
		}
	}
	///api/v1/inventory/createInventory
	function createInventory($data){
		
		$url = WEBSERVICE_URL . "inventory/createInventory";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"POST");		
		
		//print_r($output);die;
		if($output["responseStatusCode"] == 403){
			redirect('Login/tokenExpire', 'refresh');
		}else{
			return $output;	
		}
	}
	
}