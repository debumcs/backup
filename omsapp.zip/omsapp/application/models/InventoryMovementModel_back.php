<?php

class InventoryMovementModel extends CI_Model
{
	function __construct() {
		parent::__construct();
	}
	
	function fileUpload($data){
		
		$url = WEBSERVICE_URL . "account/getAll";
		//$url = "http://localhost/test/upload.php";
		$token = $this->session->userdata['token'];
		/* $header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"cache-control: no-cache",
			"content-type: multipart/form-data",
		  ); */
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		);
		
		$output = callWebServiceFileUpload($url,$header,$data,"POST");
		return $output;
	}
	
}