<?php

class RoleModel extends CI_Model
{
	function __construct() {
		parent::__construct();
	}
        
	function getRoleById($roleId){
		
		$url = WEBSERVICE_URL . "config/roles?roleId=".$roleId;
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callWebService($url,$header,'',"POST");		
		return $output;		
	}
	
	function createRole($data){
		
		$url = WEBSERVICE_URL . "user/createUserRole";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"POST");		
		return $output;		
	}
	
	function updateRole($data){
		///api/v1/user/editUserRole/{id}
		$url = WEBSERVICE_URL . "user/editUserRole/".$data["roleId"];
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"PUT");
		return $output;		
	}

	function getRoleList($data){
		///api/v1/config/roles

		$url = WEBSERVICE_URL . "config/roles";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"POST");		
		return $output;		
	}
	
	function createPassword($data){
		
		$url = WEBSERVICE_URL . "role/createPassword";
		$RequestToken = $data['requestToken'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"RequestToken:$RequestToken",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"POST");		
		return $output;		
	}
}