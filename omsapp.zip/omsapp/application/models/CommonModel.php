<?php

class CommonModel extends CI_Model
{
	function __construct() {
		parent::__construct();
	}
        
	function getProviderTypesList(){
		
		$url = WEBSERVICE_URL . "config/providerTypesList";
		$header = array(
			"device-type: Web",
			"ver: 1.0"
		);
		
		$output = callWebService($url,$header,'',"GET");
		return $output;
	}
	
	function getModulesList(){
		
		$url = WEBSERVICE_URL . "config/modulesList";
		$header = array(
			"device-type: Web",
			"ver: 1.0"
		);
		
		$output = callWebService($url,$header,'',"GET");
		return $output;
	}
	
	function getCountryList(){
		
		$url = WEBSERVICE_URL . "config/countries";
		$header = array(
			"device-type: Web",
			"ver: 1.0"
		  );
		$output = callWebService($url,$header,'',"GET");
		return $output;
	}

	function getStateList($id){
		
		$url = WEBSERVICE_URL . "config/states/".$id;
		$header = array(
			"device-type: Web",
			"ver: 1.0"
		  );
		$output = callWebService($url,$header,'',"GET");
		return $output;
	}

	function getCityList($id){
		
		$url = WEBSERVICE_URL . "config/cities/".$id;
		$header = array(
			"device-type: Web",
			"ver: 1.0"
		  );
		$output = callWebService($url,$header,'',"GET");
		return $output;
	}	

	function getSKUTypes(){
		
		$url = WEBSERVICE_URL . "config/skuTypes";
		
		$header = array(
			"device-type: Web",
			"ver: 1.0"
		  );
		
		$output = callWebService($url,$header,'',"GET");
		
		return $output;
		
	}

	function getUserStatus(){
		$url = WEBSERVICE_URL . "config/userStatus";
		
		$header = array(
			"device-type: Web",
			"ver: 1.0"
		);
		
		$output = callWebService($url,$header,'',"GET");
		
		return $output;
	}

	function getRoleList(){
		$url = WEBSERVICE_URL . "config/roles";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callWebService($url,$header,'',"POST");
		
		return $output;
	}
	
	function getAccountTypes(){
		
		$url = WEBSERVICE_URL . "config/accountTypes";
		
		$header = array(
			"device-type: Web",
			"ver: 1.0"
		  );
		
		$output = callWebService($url,$header,'',"GET");
		
		return $output;
		
	}
	
	function getLocationTypes(){
		
		$url = WEBSERVICE_URL . "config/locationTypes";
		
		$header = array(
			"device-type: Web",
			"ver: 1.0"
		  );
		
		$output = callWebService($url,$header,'',"GET");
		
		return $output;
		
	}

	function getOrderTypes(){
		
		$url = WEBSERVICE_URL . "config/orderTypes";
		
		$header = array(
			"device-type: Web",
			"ver: 1.0"
		  );
		
		$output = callWebService($url,$header,'',"GET");
		
		return $output;
		
	}
	
	function getAccountStatus(){
		
		$url = WEBSERVICE_URL . "config/accountStatus";
		$header = array(
			"device-type: Web",
			"ver: 1.0"
		  );		
		$output = callWebService($url,$header,'',"GET");		
		return $output;
		
	}
	
	function getOrderStatus(){
		
		$url = WEBSERVICE_URL . "config/orderStatus";
		$header = array(
			"device-type: Web",
			"ver: 1.0"
		  );		
		$output = callWebService($url,$header,'',"GET");		
		return $output;
	}
	
	function getLocationStatus(){
		
		$url = WEBSERVICE_URL . "config/status";
		$header = array(
			"device-type: Web",
			"ver: 1.0"
		  );		
		$output = callWebService($url,$header,'',"GET");		
		return $output;
		
	}
	
	
}