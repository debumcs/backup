<?php

class OrderModel extends CI_Model
{
	function __construct() {
		parent::__construct();
	}
        
	function getOrderList($filters){
		
		$url = WEBSERVICE_URL . "order/getAll";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$filters,"POST");		
		////checkResponse($output);
		return $output;		
	}
	
	function getAccountList($filters){
		
		$url = WEBSERVICE_URL . "account/getAll";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$filters,"POST");		
		////checkResponse($output);
		if($output["responseStatusCode"] == 403){
			/*$ci->session->unset_userdata('token');
			$ci->session->unset_userdata('name');
			$ci->session->unset_userdata('role');
			$ci->session->sess_destroy();*/
			redirect('Login/tokenExpire', 'refresh');
		}else{
			return $output;	
		}		
	}
	
		function getAccountById($accountId){
		
		$url = WEBSERVICE_URL . "account/findById/".$accountId;
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callWebService($url,$header,'',"GET");		
		//checkResponse($output);
		return $output;		
	}
	

		function getProviderById($accountId){
		
		$url = WEBSERVICE_URL . "location/findById/".$accountId;
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callWebService($url,$header,'',"GET");		
		//checkResponse($output);
		return $output;		
	}
	

	function getAllLocations($filters){
		
		$url = WEBSERVICE_URL . "location/getAll";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$filters,"POST");
		//checkResponse($output);
		return $output;
	}
	
	function getLocationById($locationId){
		///api/v1/location/findById/{id}
		$url = WEBSERVICE_URL . "location/findById/".$locationId;
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callWebService($url,$header,'',"GET");
		//checkResponse($output);
		return $output;		
	}
	
	function getOrderDetailsById($orderNo){
		//api/v1/order/findById/{id}
		$url = WEBSERVICE_URL . "order/findById/".$orderNo;
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callWebService($url,$header,'',"GET");		
		//checkResponse($output);
		return $output;		
	}
	
	function createOrder($data){
		
		$url = WEBSERVICE_URL . "order/createOrder";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"POST");		
		//checkResponse($output);
		return $output;		
	}
	
	function cancelOrder($data){
		
		$url = WEBSERVICE_URL . "order/cancelOrder";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"DELETE");		
		//checkResponse($output);
		return $output;		
	}
	
	function updateOrder($data){
		
		$url = WEBSERVICE_URL . "order/updateOrder";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"PUT");		
		//checkResponse($output);
		return $output;		
	}

		function getAllProvider($filters){
		
		$url = WEBSERVICE_URL . "provider/getAll";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$filters,"POST");		
		return $output;		
	}
}