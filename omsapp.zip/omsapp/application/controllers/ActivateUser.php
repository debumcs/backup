<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ActivateUser extends CI_Controller {

	function __construct() {
		parent::__construct();
		$this->load->model('UserModel');
	} 

	public function activate_user($token){
		
		$string1 		= base64_decode($token);
		$reqArray 		= explode("|",$string1);
    
		$requestToken 	= $reqArray[0];
    
		$username 		= $reqArray[1];
		
		$data1['username'] 		= $username;
		$data1['requestToken'] 	= $requestToken;
		
		$this->load->view('activateUser/activateUser', $data1);
	}
	
	public function session_expired(){
		
		$data1		= array();
		
		$this->load->view('activateUser/sessionExpired', $data1);
	}
	
	public function activate(){

		$data = array(
			"confirmPassword"=>$this->input->post('confpassword'),
			"currentPassword"=>'',
			"newPassword"=>$this->input->post('password'),
			"requestToken"=>$this->input->post('requestToken')
		);
		
		//echo json_encode($data); exit;
		
		$out = $this->UserModel->createPassword($data);
		echo json_encode($out);
	}
}
