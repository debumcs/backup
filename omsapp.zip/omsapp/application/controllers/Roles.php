<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Roles extends CI_Controller {

	function __construct() {
		parent::__construct();
		validateToken();
		$this->load->model('RoleModel');
		$this->load->model('CommonModel');
	} 

	public function create_role(){
		$data1["accountTypes"] 	= $this->CommonModel->getAccountTypes();
		$data1["modulesList"] 	= $this->CommonModel->getModulesList();
		$data['body'] = $this->load->view('roles/createRole', $data1, true);
		$this->load->view('template', $data);
	}

	public function post_role(){
		
		$modulesArr = array();		
		
		if($this->input->post('modules')){
			$modules = $this->input->post('modules');
			
			foreach($modules as $menuId){
				$subMenuIds = array();
				if(is_array($this->input->post('subMenus_'.$menuId))){
					$subMenuIds = array_map('intval', $this->input->post('subMenus_'.$menuId));
				}				
				
				$modulesArr[] = array(
					"menuId"=>intval($menuId),
					"subMenuIds"=>$subMenuIds
				);
			}
		}
		
		$data = array(
			"roleType"=>$this->input->post('accountType'),
			"roleName"=>$this->input->post('roleName'),
			"roleDesc"=>$this->input->post('roleDescription'),
			"menuSubMenus"=>$modulesArr
		);
		
		//echo json_encode($data); exit;
		
		$out = $this->RoleModel->createRole($data);
		
		if($out["responseStatusCode"] == 200){
			//$this->role_confirm($out["responseObject"]["roleId"]);
			redirect('Roles/role_confirm/'.$out["responseObject"]["roleId"]);
		}
		echo json_encode($out);
	}

	public function update_role(){
		$modulesArr = array();		
		
		if($this->input->post('modules')){
			$modules = $this->input->post('modules');
			
			foreach($modules as $menuId){
				$subMenuIds = array();
				if(is_array($this->input->post('subMenus_'.$menuId))){
					$subMenuIds = array_map('intval', $this->input->post('subMenus_'.$menuId));
				}				
				
				$modulesArr[] = array(
					"menuId"=>intval($menuId),
					"subMenuIds"=>$subMenuIds
				);
			}
		}
		
		$data = array(
			"roleId"=>$this->input->post('roleId'),
			"roleType"=>$this->input->post('accountType'),
			"roleName"=>$this->input->post('roleName'),
			"roleDesc"=>$this->input->post('roleDescription'),
			"menuSubMenus"=>$modulesArr
		);
		
		//echo json_encode($data); exit;
		
		$out = $this->RoleModel->updateRole($data);
		
		if($out["responseStatusCode"] == 200){
			redirect('Roles/role_confirm/'.$out["responseObject"]["roleId"]);
		}
		echo json_encode($out);
	}

	public function role_confirm($roleId){
		
		$data1['roleDetails'] = $this->RoleModel->getRoleById($roleId);
		$data['body'] = $this->load->view('roles/confirmRole', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function view_role($roleId){
		
		$data1['roleDetails'] = $this->RoleModel->getRoleById($roleId);
		$data['body'] = $this->load->view('roles/viewRole', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function edit_role($roleId){
		$data1["accountTypes"] 	= $this->CommonModel->getAccountTypes();
		$data1["modulesList"] 	= $this->CommonModel->getModulesList();
		
		$menuids = array();
		$submenuids = array();
		
		$data1["roleDetails"] 	= $roleDetails = $this->RoleModel->getRoleById($roleId);
		
		foreach($roleDetails["responseObject"]["menus"] as $value){
			$menuids[] = $value["menuId"];
			foreach($value["subMenus"] as $submenu){
				$submenuids[] = $submenu["subMenuId"];
			}
		}
		$data1["menuids"] 		= $menuids;
		$data1["submenuids"] 	= $submenuids;
		
		$data['body'] = $this->load->view('roles/editRole', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function getRoleById($roleId){
		
		$out = $this->RoleModel->getUserById($roleId);
		echo json_encode($out);
	}

	public function viewAllRoles(){
		$data1 = array();
		$data['body'] = $this->load->view('roles/manageRoles', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}

	public function getAllRoles(){
		$filters = array(
			array("key"=>"AccountType","value"=>$this->input->post('AccountType')),
			array("key"=>"RoleId","value"=>$this->input->post('RoleId')),
			array("key"=>"RoleName","value"=>$this->input->post('RoleName')),
			array("key"=>"RoleStatus","value"=>$this->input->post('RoleStatus'))
		);
		
		$out = $this->RoleModel->getRoleList($filters);
		echo json_encode($out);
	}
	
	public function checkUserNameExists($rolename){
		$out = $this->RoleModel->checkUserNameExists($rolename);
		echo json_encode($out);
	}
}
