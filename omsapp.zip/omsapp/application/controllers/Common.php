<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Common extends CI_Controller {

	function __construct() {
		parent::__construct();
		validateToken();
		$this->load->model('CommonModel','CommonModel');
	} 
	public function index()
	{
		
	}
	
	public function get_providerTypesList(){
		
		$out = $this->CommonModel->getProviderTypesList();
		
		echo json_encode($out);
		
	}
	
	public function get_modulesList(){
		
		$out = $this->CommonModel->getModulesList();
		
		echo json_encode($out);
		
	}
	
	public function get_country_list(){
		
		$out = $this->CommonModel->getCountryList();
		
		echo json_encode($out);
		
	}

	public function get_state_list($id){
		
		$out = $this->CommonModel->getStateList($id);
		
		echo json_encode($out);
		
	}

	public function get_city_list($id){
		
		$out = $this->CommonModel->getCityList($id);
		
		echo json_encode($out);
		
	}

	public function get_account_type(){
		
		$out = $this->CommonModel->getAccountTypes();
		
		echo json_encode($out);
		
	}

	public function get_role_list(){
		
		$out = $this->CommonModel->getRoleList();
		
		echo json_encode($out);
		
	}

	public function get_user_status(){
		
		$out = $this->CommonModel->getUserStatus();
		
		echo json_encode($out);
		
	}
	
	public function get_sku_type(){
		
		$out = $this->CommonModel->getSKUTypes();
		
		echo json_encode($out);
		
	}
	
	public function get_location_type(){
		
		$out = $this->CommonModel->getLocationTypes();
		
		echo json_encode($out);
		
	}
	
	public function get_order_type(){
		
		$out = $this->CommonModel->getOrderTypes();
		
		echo json_encode($out);
		
	}
	
	public function get_account_status(){
		
		$out = $this->CommonModel->getAccountStatus();
		
		echo json_encode($out);
		
	}
	
	public function get_order_status(){
		
		$out = $this->CommonModel->getOrderStatus();
		
		echo json_encode($out);
		
	}
	
	public function get_location_status(){
		
		$out = $this->CommonModel->getLocationStatus();
		
		echo json_encode($out);
		
	}
}
