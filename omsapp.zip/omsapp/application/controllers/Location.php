<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Location extends CI_Controller {
	
	public function __construct() {
        parent::__construct();
		validateToken();
		$this->load->model('LocationModel','LocationModel');
	}
	
	public function create_location()
	{
		$data1 = array();
		$data['body'] = $this->load->view('location/create_location', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function getAllAccounts(){
		$this->load->model('AccountModel');
		$filters = array(
			array("key"=>"AccountType","value"=>$this->input->post('accountType')),
			array("key"=>"AccountId","value"=>$this->input->post('accountId')),
			array("key"=>"AccountName","value"=>$this->input->post('accountName')),
			array("key"=>"AccountNickName","value"=>$this->input->post('accountNickName')),
			array("key"=>"AccountRef","value"=>$this->input->post('accountRef')),
			array("key"=>"State","value"=>$this->input->post('accountState'))
		);
		
		$out = $this->AccountModel->getAccountList($filters);
		echo json_encode($out);
	}
	
	public function getProviderList(){
		
		$filters = array(
			array("key"=>"LocationId","value"=>$this->input->post('providerLocationNo')),
			array("key"=>"AccountName","value"=>$this->input->post('providerName')),
			array("key"=>"LocationNickName","value"=>$this->input->post('providerLocationNickname')),
			array("key"=>"State","value"=>$this->input->post('providerState'))
		);
		//array("key"=>"AccountRef","value"=>$this->input->post('providerType')),
		$out = $this->LocationModel->getProviderList($filters);
		echo json_encode($out);
	}
	
	public function post_location(){
		
		$locationAssociationsIds = '';
		$primaryProviderDetails = array(
			"associationId"=> $this->input->post('associationId'),
			"locationId"=> $this->input->post('proLocationId'),
			"providerId"=> $this->input->post('proAccountId')
		);
		$operationalHours = array();
		
		if($this->input->post('dayOpr') && $this->input->post('startTimeOpr') && $this->input->post('endTimeOpr')){
			$dayOpr 		= $this->input->post('dayOpr');
			$startTimeOpr 	= $this->input->post('startTimeOpr');
			$endTimeOpr 	= $this->input->post('endTimeOpr');
			foreach ($dayOpr as $key => $value){
				$startTime 	= '';
				$endTime	= '';
				
				$startTime 	= date("H:i:s", strtotime($startTimeOpr[$key]));
				$endTime 	= date("H:i:s", strtotime($endTimeOpr[$key]));
				
				$operationalHours[] = array(
					"day"=>$dayOpr[$key],
					"startTime"=>$startTime,
					"endTime"=>$endTime
				);
			}
		}
		
		$locationAssociationsIds = array();
		if($this->input->post('locationId')){
			$locationId 		= $this->input->post('locationId');
			$locationIds 		= $this->input->post('locationIds');
			
			foreach ($locationId as $key => $value){
				$locationAssociationsIds[] = $locationIds[$key];
			}
		}
		
		$data = array(
          "locationType"=>intval($this->input->post('locationType')),
          "referenceCode" =>$this->input->post('referenceCode'),
          "unitNumber" => $this->input->post('unitNumber'),
          "locationName" => $this->input->post('locationName'),
          "nickName" => $this->input->post('nickName'),
          "addressLine1" => $this->input->post('addressLine1'),
          "addressLine2" => $this->input->post('addressLine2'),
          "zipCode" => intval($this->input->post('zipCode')),
          "country" => intval($this->input->post('country')),
          "state" => intval($this->input->post('state')),
          "city" => intval($this->input->post('city')),
          "businessPhone" => $this->input->post('businessPhone'),
		  "fax" => $this->input->post('fax'),
          "operationalHours" => $operationalHours,
          "contactEmail" => $this->input->post('contactEmail'),
		  "contactName" => $this->input->post('contactName'),
		  "contactPhone" => $this->input->post('contactPhone'),
		  "locationAssociationsIds" => $locationAssociationsIds		  
        );
		
		/*
		"primaryProviderDetails"=>$primaryProviderDetails,
		  "providerLocationType"=>$this->input->post('providerLocationType'),
		  "nextCallDate"=>strtotime($this->input->post('nextCallDate')),
		  "lastCallDate"=>strtotime($this->input->post('lastCallDate')),
		  "lastServiceDate"=>strtotime($this->input->post('lastServiceDate')),
		  "maxQuantity"=>intval($this->input->post('maxQty')),
		  "minQuantity"=>intval($this->input->post('minQty'))
		*/
		
		if($this->input->post('locationType') == '1' || $this->input->post('locationType') == '5'){
			$data["primaryProviderDetails"] = $primaryProviderDetails;
			if($this->input->post('nextCallDate')){
				$data["nextCallDate"]=strtotime($this->input->post('nextCallDate'));
			}else{
				$data["nextCallDate"]='';
			}
			
			if($this->input->post('lastCallDate')){
				$data["lastCallDate"]=strtotime($this->input->post('lastCallDate'));
			}else{
				$data["lastCallDate"]='';
			}
			
			if($this->input->post('lastServiceDate')){
				$data["lastServiceDate"]=strtotime($this->input->post('lastServiceDate'));
			}else{
				$data["lastServiceDate"]='';
			}			
			
			$data["lastServiceDate"]=strtotime($this->input->post('lastServiceDate'));
			$data["maxQuantity"]=intval($this->input->post('maxQty'));
			$data["minQuantity"]=intval($this->input->post('minQty'));
		}else{
			$data["primaryProviderDetails"]=array(
					"associationId"=>'',
					"locationId"=>'',
					"providerId"=>''
				);
			$data["nextCallDate"]='';
			$data["lastCallDate"]='';
			$data["lastServiceDate"]='';
			$data["maxQuantity"]='';
			$data["minQuantity"]='';
		}
		
		if($this->input->post('locationType') == '7'){
			$data["providerLocationType"] = intval($this->input->post('providerLocationType'));
		}else{
			$data["providerLocationType"] = '';
		}
		
		//echo json_encode($data);exit;
		
		$out = $this->LocationModel->createLocation($data);
		echo json_encode($out);
	}
	
	public function confirm_location($locationId){
		
		$data1['locationDetails'] = $this->LocationModel->getLocationById($locationId);
		$data['body'] = $this->load->view('location/confirm_location', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function edit_location($locationId){
		
		$data1['locationDetails'] = $this->LocationModel->getLocationById($locationId);
		$data['body'] = $this->load->view('location/edit_location', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}

	public function viewAllLocations(){
		
		$data['body'] = $this->load->view('location/manage_location', '', true);
		
		$this->load->view('template', $data);
	}
	
	public function getAllLocations(){
		
		$filters = array(
			array("key"=>"LocationType","value"=>$this->input->post('searchLocationType')),
			array("key"=>"LocationId","value"=>$this->input->post('searchLocationNo')),
			array("key"=>"LocationRef","value"=>$this->input->post('searchLocationRef')),
			array("key"=>"LocationName","value"=>$this->input->post('searchLocationName')),
			array("key"=>"LocationStatus","value"=>$this->input->post('searchLocationStatus')),
			array("key"=>"State","value"=>$this->input->post('searchLocationState')),
			array("key"=>"City","value"=>$this->input->post('searchLocationCity'))
		);
		
		$out = $this->LocationModel->getAllLocations($filters);
		echo json_encode($out);
	}
	
	public function view_location($locationId){
		
		$data1['locationDetails'] = $this->LocationModel->getLocationById($locationId);
		$data['body'] = $this->load->view('location/view_location', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	
}