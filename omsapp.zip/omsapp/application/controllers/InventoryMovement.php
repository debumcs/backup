<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class InventoryMovement extends CI_Controller {

	function __construct() {
		parent::__construct();
		validateToken();
		$this->load->model('InventoryMovementModel','InventoryMovementModel');
	}
	
	public function index()
	{
		$data1 = array();
		$data['body'] = $this->load->view('inventoryMovement/sentToLocation', $data1, true);
		$this->load->view('template', $data);
	}
	
	public function sentToLocation()
	{
		$data1 = array();
		$data['body'] = $this->load->view('inventoryMovement/sentToLocationFileUpload', $data1, true);
		$this->load->view('template', $data);
	}
	
	public function sentToLocationFileUpload()
	{
		$filename = $_FILES['filename']['name'];
		$filedata = chunk_split(base64_encode(file_get_contents($_FILES['filename']['tmp_name'])));
		$filesize = $_FILES['filename']['size'];
		$filetype = $_FILES['filename']['type'];
		
		$data = array(
			"filename"=>$filename,
			"filedata"=>$filedata,
			"filesize"=>$filesize,
			"filetype"=>$filetype,
		);
		
		$out = $this->InventoryMovementModel->fileUpload($data);
		echo json_encode($out);
	}

    public function ShipFromInventoryMovement(){
    
		//validateToken();
		$filters = array(
			array("key"=>"AccountType","value"=>$this->input->post('accountType')),
			array("key"=>"LocationType","value"=>$this->input->post('locationType')),
			array("key"=>"AccountName","value"=>$this->input->post('customerName')),
			array("key"=>"AccountId","value"=>$this->input->post('customerNumber')),
			array("key"=>"LocationName","value"=>$this->input->post('locationName')),
			array("key"=>"LocationId","value"=>$this->input->post('locationNumber'))			
		);
		$out = $this->InventoryMovementModel->getInventoryList($filters);
	
		echo json_encode($out);
	
	}
	
	public function GetShipTo(){
		//accountType
		
		
		$filters = array(
			array("key"=>"AccountId","value"=>$this->input->post('shipFromAccountId')),
			array("key"=>"AccountName","value"=>$this->input->post('accountName')),
			array("key"=>"LocationRef","value"=>$this->input->post('refcode')),
			array("key"=>"LocationNickName","value"=>$this->input->post('nickname')),			
			array("key"=>"State","value"=>$this->input->post('state'))
		);
		
		//array("key"=>"LocationName","value"=>$this->input->post('locationName'))
		
		if($this->input->post('accountType') == '1'){
			$filters[] = array("key"=>"LocationType","value"=>1);
		}
		
		$out = $this->InventoryMovementModel->getShipToList($filters);
	
		echo json_encode($out); 
	}
	
	public function create_sent_to_inventory(){
		
		/*echo '<pre>';
		print_r($_POST);
		echo '<pre>';
		exit;*/
		
		$array = array();
		$arrayheader = array();
		$arraybody = array();
		
		$arrayheader[] = 'ShipToAssociationId';
		$arrayheader[] = 'ShipToAccountId';
		$arrayheader[] = 'ShipToLocationId';
		
		$arrayheader[] = $this->input->post('headDealership');
		$arrayheader[] = $this->input->post('headLocName');
		$arrayheader[] = $this->input->post('headStore');
		$arrayheader[] = $this->input->post('headRef');
		$arrayheader[] = $this->input->post('headNickname');
		$arrayheader[] = $this->input->post('headCity');
		$arrayheader[] = $this->input->post('headState');
		$headSkuNumber = $this->input->post('headSkuNumber');
		foreach($headSkuNumber as $key => $value){
			$arrayheader[] = $headSkuNumber[$key];
		}
		$arrayheader[] = $this->input->post('headShipDate');
		
		$array[] = $arrayheader;
		
		$skuList = $this->input->post('skuNumber');
		
		$shipToAssociationId = $this->input->post('shipToAssociationId');
		$shipToAccountId = $this->input->post('shipToAccountId');
		$shipToLocationId = $this->input->post('shipToLocationId');
		$companyName = $this->input->post('companyName');
		$shipToLocationName = $this->input->post('shipToLocationName');
		$unitNumber = $this->input->post('unitNumber');
		$referenceCode = $this->input->post('referenceCode');
		$nickName = $this->input->post('nickName');
		$cityName = $this->input->post('cityName');
		$stateName = $this->input->post('stateName');
		$serialNumber = $this->input->post('serialNumber');
		$shipDate = $this->input->post('shipDate');
		
		
		foreach($skuList as $key => $skuNumberList){
			$skuNumber = array();
			
			if($shipDate[$key]){
				
				$skunumbers = implode(',',$skuNumber);
				
				$arraybody[0] = $shipToAssociationId[$key];
				$arraybody[1] = $shipToAccountId[$key];
				$arraybody[2] = $shipToLocationId[$key];
				
				$arraybody[3] = $companyName[$key];
				$arraybody[4] = $shipToLocationName[$key];
				$arraybody[5] = $unitNumber[$key];
				$arraybody[6] = $referenceCode[$key];
				$arraybody[7] = $nickName[$key];
				$arraybody[8] = $cityName[$key];
				$arraybody[9] = $stateName[$key]; //$counter
				$counter=9;
				
				foreach($skuNumberList as $skukey => $qty){
					$counter++;
					if(isset($serialNumber[$key][$skukey]) && is_array($serialNumber[$key][$skukey])){						
						$arraybody[$counter] = implode(",",$serialNumber[$key][$skukey]);
					}else{
						$arraybody[$counter] = $qty;
					}
				}
				$counter = $counter+1;
				$arraybody[$counter] = $shipDate[$key];
				
				$array[] = $arraybody;
			}
		}
		
		if(empty($arraybody)){
			$errorData = array(
				"responseStatusCode"=>600,
				"responseObject"=>'Please enter SKU quantity and Ship Date'
			);
			echo json_encode($errorData); exit;
		}
		
		$data = array(
			"inventoryList"=>$array,
			"shipFromAssociationId"=>$this->input->post('shipFromAssociationId'),
			"shipFromAccountId"=>$this->input->post('shipFromAccountId'),
			"shipFromLocationId"=>$this->input->post('shipFromLocationId')
		);
		
		//echo json_encode($data); exit;
		
		$out = $this->InventoryMovementModel->createInventory($data);
		echo json_encode($out);
		
	}
	
}