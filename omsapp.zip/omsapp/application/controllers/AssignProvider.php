<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AssignProvider extends CI_Controller {

	function __construct() {
		parent::__construct();
		validateToken();
		$this->load->model('AssignProviderModel','AssignProviderModel');
	} 
		
	public function viewAllOrders(){
		
		$data['body'] = $this->load->view('assignprovider/viewAllOrders', '', true);
		
		$this->load->view('template', $data);
	}
	
	public function getAllOrders(){
		$filters = array(
			array("key"=>"OrderType","value"=>$this->input->post('OrderType')),
			array("key"=>"OrderNumber","value"=>$this->input->post('OrderNumber')),
			array("key"=>"OrderStatus","value"=>$this->input->post('OrderStatus')),
			array("key"=>"AccountId","value"=>$this->input->post('AccountId')),
			array("key"=>"LocationId","value"=>$this->input->post('LocationId')),
			array("key"=>"LocationRef","value"=>$this->input->post('LocationRef')),
			array("key"=>"LocationName","value"=>$this->input->post('LocationName')),
			array("key"=>"LocationNickName","value"=>$this->input->post('LocationNickName'))
		);
		
		$out = $this->AssignProviderModel->getOrderList($filters);
		echo json_encode($out);
	}
	
	public function assign_provider($orderno){
		/*echo '<pre>';
		print_r($this->AssignProviderModel->getOrderDetailsById($orderno));
		echo '</pre>';exit;*/
		$providers = $this->AssignProviderModel->getAllProvider($orderno);
		$data1['getAllProvider'] = $providers["responseObject"];
		$data1['orderDetails'] = $this->AssignProviderModel->getOrderDetailsById($orderno);
		$data['body'] = $this->load->view('assignprovider/assign_provider', $data1, true);
		
		$this->load->view('template', $data);
	}
	
	public function assign_order_confirm($orderno){
		
		$data1['orderDetails'] = $orderDetails = $this->AssignProviderModel->getOrderDetailsById($orderno);
		$data1['providerDetails'] = $this->AssignProviderModel->getAccountById($orderDetails["responseObject"]["orderAssignments"][0]["assignAccount"]);
		$data['body'] = $this->load->view('assignprovider/assign_provider_confirm', $data1, true);
		
		$this->load->view('template', $data);
	}
	
	public function assigned_provider(){
		
		$data = array(
			"accountId"=>$this->input->post('accountNumber'),
			"orderNumber"=>$this->input->post('orderNumber')
		);
		
		$out = $this->AssignProviderModel->assignProvider($data);
		echo json_encode($out);
	}
}
