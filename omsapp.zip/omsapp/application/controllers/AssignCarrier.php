<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AssignCarrier extends CI_Controller {

	function __construct() {
		parent::__construct();
		validateToken();
		$this->load->model('AssignCarrierModel','AssignCarrierModel');
	} 
		
	public function viewAllOrders(){
		
		$data['body'] = $this->load->view('assigncarrier/viewAllOrders', '', true);
		
		$this->load->view('template', $data);
	}
	
	public function getAllOrders(){
		$filters = array(
			array("key"=>"OrderType","value"=>$this->input->post('OrderType')),
			array("key"=>"OrderNumber","value"=>$this->input->post('OrderNumber')),
			array("key"=>"OrderStatus","value"=>$this->input->post('OrderStatus')),
			array("key"=>"AccountId","value"=>$this->input->post('AccountId')),
			array("key"=>"LocationId","value"=>$this->input->post('LocationId')),
			array("key"=>"LocationRef","value"=>$this->input->post('LocationRef')),
			array("key"=>"LocationName","value"=>$this->input->post('LocationName')),
			array("key"=>"LocationNickName","value"=>$this->input->post('LocationNickName'))
		);
		
		$out = $this->AssignCarrierModel->getOrderList($filters);
		echo json_encode($out);
	}
	
	public function assign_carrier($orderno){
		
		$carriers = $this->AssignCarrierModel->getAllCarrier($orderno);
		$data1['getAllCarrier'] = $carriers["responseObject"];
		$data1['orderDetails'] = $this->AssignCarrierModel->getOrderDetailsById($orderno);
		$data['body'] = $this->load->view('assigncarrier/assign_carrier', $data1, true);
		
		$this->load->view('template', $data);
	}
	
	public function assign_order_confirm($orderno){
		
		$data1['orderDetails'] = $orderDetails = $this->AssignCarrierModel->getOrderDetailsById($orderno);
		$data1['carrierDetails'] = $this->AssignCarrierModel->getAccountById($orderDetails["responseObject"]["orderAssignments"][0]["assignAccount"]);
		$data['body'] = $this->load->view('assigncarrier/assign_carrier_confirm', $data1, true);
		
		$this->load->view('template', $data);
	}
	
	public function assigned_carrier(){
		
		$carrierAssignmentDataList = array();
		
		if($this->input->post('expectedPickUp')){
			$expectedPickUp = date("Y-m-d", strtotime($this->input->post('expectedPickUp'))); 
		}else{
			$expectedPickUp = '';
		}
		
		$carrierAssignmentDataList[] = array(
			"accountId"=>$this->input->post('accountNumber'),
			"expectedPickUp"=>$expectedPickUp,
			"spotRate"=>floatval($this->input->post('spotRate'))
		);
		
		$data = array(
			"carrierAssignmentDataList"=>$carrierAssignmentDataList,
			"orderNumber"=>$this->input->post('orderNumber')
		);
		
		//$_SESSION["ORDERDATA"] = $data;
		//echo json_encode($data);exit;
		
		$out = $this->AssignCarrierModel->assignCarrier($data);
		echo json_encode($out);
	}
	
}
