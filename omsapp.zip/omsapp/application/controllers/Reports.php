<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends CI_Controller {

	function __construct() {
		parent::__construct();
	}
	
	public function inventoryReport()
	{
		$data1 = array();
		$data['body'] = $this->load->view('reports/inventoryReport', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function planedPickupReport()
	{
		$data1 = array();
		$data['body'] = $this->load->view('reports/planedPickupReport', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function plannedPUDateCompliance()
	{
		$data1 = array();
		$data['body'] = $this->load->view('reports/plannedPUDateCompliance', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function plannedPUDateConfirmation()
	{
		$data1 = array();
		$data['body'] = $this->load->view('reports/plannedPUDateConfirmation', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function returnLoadTracking()
	{
		$data1 = array();
		$data['body'] = $this->load->view('reports/returnLoadTracking', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	
}
