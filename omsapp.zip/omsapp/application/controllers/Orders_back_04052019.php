<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Orders extends CI_Controller {

	function __construct() {
		parent::__construct();
		validateToken();
		$this->load->model('OrderModel','OrderModel');
	} 
	
	public function create()
	{
		validateToken();
		$data1 = array();
		$data['body'] = $this->load->view('orders/create_order', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	
	
	public function create_order(){
		validateToken();
		if($this->input->post('orderType') == '1'){
			$isRental = 1;
		}else{
			$isRental = 0;
		}
		//echo $pickUpDate = date("Y-m-d", strtotime($this->input->post('requestedPickupDate'))); exit;
		if($this->input->post('requestedPickupDate')){

			$pickUpDate = date("Y-m-d", strtotime($this->input->post('requestedPickupDate'))); 
		}else{
			$pickUpDate = '';
		}
		
		if($this->input->post('pickUpDueDate')){
			$pickUpDueDate = date("Y-m-d", strtotime($this->input->post('pickUpDueDate'))); 
		}else{
			$pickUpDueDate = '';
		}
		
		if($this->input->post('requestedPickUpTime1') != ''){
			$pickUpTime = $this->input->post('requestedPickUpTime1');
		}else{			
			if($this->input->post('requestedPickUpTime2')){
				$pickUpTime = date("H:i:s", strtotime($this->input->post('requestedPickUpTime2'))); 
			}else{
				$pickUpTime = '';
			}
		}
		
		$orderComponents = array();
		if($this->input->post('qty')){
			$qty = $this->input->post('qty');
			$description = $this->input->post('description');
			$weight = $this->input->post('weight');
			$skutypeord = $this->input->post('skutypeord');
			foreach ($qty as $key => $value){
				$orderComponents[] = array(
					"description"=>$description[$key],
					"quantity"=>intval($value),
					"sku"=>$key,
					"skuType"=>intval($skutypeord[$key]),
					"weight"=>intval($weight[$key])
				);
			}
		}

		$data = array(
			"accountId"=>$this->input->post('billto'),
			"locationId"=>$this->input->post('locationId'),
			"billToLocation"=>$this->input->post('billToLocation'),
			"shipToLocation"=>$this->input->post('shipToLocation'),			
			"isRental"=>intval($isRental),
			"orderComponents"=>$orderComponents,
			"orderType"=>intval($this->input->post('orderType')),
			"pickUpDate"=>$pickUpDate,
			"pickUpDueDate"=>$pickUpDueDate,
			"pickUpTime"=>$pickUpTime,
			"poNumber"=>$this->input->post('poNumber'),
			"instructions"=>$this->input->post('instructions'),
			"referenceCol1"=>$this->input->post('refNumber1'),
			"referenceCol2"=>$this->input->post('refNumber2')
		);
		
		//$_SESSION["ORDERDATA"] = $data;
		//echo json_encode($data);exit;
		
		$out = $this->OrderModel->createOrder($data);
		echo json_encode($out);
	}
	
	public function create_order_summary()
	{
		validateToken();
		$data1['orderData'] = $orderdata = $_SESSION["ORDERDATA"];
		$data1['accountDetails'] = $this->OrderModel->getAccountById($orderdata["accountId"]);
		$data1['locationDetails'] = $this->OrderModel->getLocationById($orderdata["locationId"]);
		
		$data['body'] = $this->load->view('orders/order_summary', $data1, true);


		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function order_confirm($orderno){
		validateToken();
		$data1['orderDetails'] = $this->OrderModel->getOrderDetailsById($orderno);
		$data['body'] = $this->load->view('orders/order_confirm', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function view_order($orderno){
		validateToken();
		$data1['orderDetails'] = $this->OrderModel->getOrderDetailsById($orderno);
		$data['body'] = $this->load->view('orders/view_order', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function getOrderDetailsById($orderno){
		validateToken();
		$out = $this->OrderModel->getOrderDetailsById($orderno);
		echo json_encode($out);
	}
	
	public function getAllAccounts(){
		validateToken();
		$filters = array(
			array("key"=>"AccountType","value"=>$this->input->post('accountType')),
			array("key"=>"AccountId","value"=>$this->input->post('accountId')),
			array("key"=>"AccountName","value"=>$this->input->post('accountName')),
			array("key"=>"AccountNickName","value"=>$this->input->post('accountNickName')),
			array("key"=>"AccountRef","value"=>$this->input->post('accountRef')),
			array("key"=>"State","value"=>$this->input->post('accountState')),
			array("key"=>"City","value"=>$this->input->post('accountCity')),
			array("key"=>"AccountStatus","value"=>$this->input->post('accountStatus'))
		);
		
		$out = $this->OrderModel->getAccountList($filters);
		echo json_encode($out);
	}
	
	public function viewAllOrders(){
		validateToken();
		$data['body'] = $this->load->view('orders/viewAllOrders', '', true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function getAllOrders(){
		validateToken();
		$filters = array(
			array("key"=>"OrderType","value"=>$this->input->post('OrderType')),
			array("key"=>"OrderNumber","value"=>$this->input->post('OrderNumber')),
			array("key"=>"OrderStatus","value"=>$this->input->post('OrderStatus')),
			array("key"=>"AccountId","value"=>$this->input->post('AccountId')),
			array("key"=>"LocationId","value"=>$this->input->post('LocationId')),
			array("key"=>"LocationRef","value"=>$this->input->post('LocationRef')),
			array("key"=>"LocationName","value"=>$this->input->post('LocationName')),
			array("key"=>"LocationNickName","value"=>$this->input->post('LocationNickName'))
		);
		
		$out = $this->OrderModel->getOrderList($filters);
		echo json_encode($out);
	}
	
	
	public function getAccountById($acountId){
		validateToken();
		$out = $this->OrderModel->getAccountById($acountId);
		echo json_encode($out);		
	}
	
	public function getAllLocations(){
		validateToken();
		$filters = array(
			array("key"=>"LocationType","value"=>$this->input->post('locationType')),
			array("key"=>"LocationId","value"=>$this->input->post('locationid')),
			array("key"=>"LocationRef","value"=>$this->input->post('locRef')),
			array("key"=>"LocationName","value"=>$this->input->post('locname')),
			array("key"=>"LocationUnit","value"=>$this->input->post('unit')),
			array("key"=>"LocationNickName","value"=>$this->input->post('locNickName')),
			array("key"=>"State","value"=>$this->input->post('locState')),
			array("key"=>"City","value"=>$this->input->post('locCity')),
			array("key"=>"LocationStatus","value"=>$this->input->post('locStatus'))
		);
		
		$out = $this->OrderModel->getAllLocations($filters);
		echo json_encode($out);
	}
	
	public function getLocationById($locationId){
		validateToken();
		$out = $this->OrderModel->getLocationById($locationId);
		echo json_encode($out);
		
	}
	
	public function edit_order($orderno)
	{
		validateToken();
		$data1["orderno"] = $orderno;
		
		$data['body'] = $this->load->view('orders/edit_order', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function update_order(){
		
		validateToken();
		
		if($this->input->post('orderType') == '1'){
			$isRental = 1;
		}else{
			$isRental = 0;
		}
		
		if($this->input->post('requestedPickupDate')){

			$pickUpDate = date("Y-m-d", strtotime($this->input->post('requestedPickupDate'))); 
		}else{
			$pickUpDate = '';
		}
		
		if($this->input->post('pickUpDueDate')){
			$pickUpDueDate = date("Y-m-d", strtotime($this->input->post('pickUpDueDate'))); 
		}else{
			$pickUpDueDate = '';
		}
		
		if($this->input->post('requestedPickUpTime1') != ''){
			$pickUpTime = $this->input->post('requestedPickUpTime1');
		}else{			
			if($this->input->post('requestedPickUpTime2')){
				$pickUpTime = date("H:i:s", strtotime($this->input->post('requestedPickUpTime2'))); 
			}else{
				$pickUpTime = '';
			}
		}
		
		$orderComponents = array();
		
		if($this->input->post('qty')){
			$qty = $this->input->post('qty');
			$description = $this->input->post('description');
			$weight = $this->input->post('weight');
			$id = $this->input->post('id');
			foreach ($qty as $key => $value){
				$orderComponents[] = array(
					"description"=>$description[$key],
					"quantity"=>intval($value),
					"sku"=>$key,
					"weight"=>intval($weight[$key]),
					"id"=>intval($id[$key])
				);
			}
		}
		
		$data = array(
			"orderNumber"=>$this->input->post('orderNumber'),
			"accountId"=>$this->input->post('accountId'),
			"locationId"=>$this->input->post('locationId'),
			"billToLocation"=>$this->input->post('billToLocation'),
			"shipToLocation"=>$this->input->post('shipToLocation'),			
			"isRental"=>intval($isRental),
			"orderComponents"=>$orderComponents,
			"orderType"=>intval($this->input->post('orderType')),
			"pickUpDate"=>$pickUpDate,
			"pickUpDueDate"=>$pickUpDueDate,
			"pickUpTime"=>$pickUpTime,
			"poNumber"=>$this->input->post('poNumber'),
			"instructions"=>$this->input->post('instructions'),
			"referenceCol1"=>$this->input->post('refNumber1'),
			"referenceCol2"=>$this->input->post('refNumber2'),
		);
		
		//$_SESSION["ORDERDATA"] = $data;
		//echo json_encode($data);exit;
		
		$out = $this->OrderModel->updateOrder($data);
		echo json_encode($out);
	}
	
	public function cancel_order(){
		
		validateToken();
		
		$data = array(
			"orderNumber"=>$this->input->post('orderNumber'),
			"reason"=>$this->input->post('reasonCancel')			
		);
		//echo json_encode($data);exit;
		$out = $this->OrderModel->cancelOrder($data);
		echo json_encode($out);
	}
}
