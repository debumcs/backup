<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ReverseLogistics extends CI_Controller {

	function __construct() {
		parent::__construct();
		validateToken();
		$this->load->model('ReverseLogisticsModel');
	}
	
	public function assetSearch()
	{
		$data1 = array();
		$data['body'] = $this->load->view('reverseLogistics/assetSearch', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function getLocationInventoryInformation()
	{
		$data1 = array();
		$data['body'] = $this->load->view('reverseLogistics/getLocationInventoryInformation', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function editLocationInventoryInformation()
	{
		$data1 = array();
		$data['body'] = $this->load->view('reverseLogistics/editLocationInventoryInformation', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
}
