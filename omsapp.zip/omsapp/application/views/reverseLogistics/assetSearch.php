<div class="content-wrapper" ng-controller="assetSearchCtrl">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Reverse Logistics</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li><a href="#">Reverse Logistics</a></li>
        <li class="active">Reverse Logistics Asset Search</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          
          <div class="box">
            
			<div class="box-header with-border">
				<h3 class="box-title m10"><b>Reverse Logistics Asset Search</b></h3>
			</div>
			
            <!-- /.box-header -->
			<form autocomplete="off" name="assetSearchForm" ng-submit="createOrderAssetSearch()">
            <div class="box-body">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="row">
							<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
								<div class="form-group">
									<label>Location Type</label>
									<select ng-model="assetSearchData.locationType" name="locationType" id="locationType" ng-change="getAssetSearchData()" class="form-control">
									<option selected="selected" value="">Select Type</option>
									<option ng-repeat='location in locationTypes' value="{{location.id}}">{{location.locationType}}</option>
									</select>
								</div>
							</div>
							
							<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
								<div class="form-group">
									<label>Location Ref #</label>
									<input type="text" ng-model="assetSearchData.locationRef" name="locationRef" id="locationRef" ng-keyup="getAssetSearchData()" class="form-control input-sm" value="" />
								</div>
							</div>
							
							<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
								<div class="form-group">
									<label>Location Name</label>
									<input type="text" ng-model="assetSearchData.locationName" name="locationName" id="locationName" ng-keyup="getAssetSearchData()" class="form-control input-sm" value="" />
								</div>
							</div>
							
							<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
								<div class="form-group">
									<label>City</label>
									<input type="text" ng-model="assetSearchData.city" name="city" id="city" ng-keyup="getAssetSearchData()" class="form-control input-sm" value="" />
								</div>
							</div>
							
							<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
								<div class="form-group">
									<label>State</label>
									<input type="text" ng-model="assetSearchData.state" name="state" id="state" ng-keyup="getAssetSearchData()" class="form-control input-sm" value="" />
								</div>
							</div>
							
							<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
								<div class="form-group">
									<label>Primary Asset Recovery Provider</label>
									<input type="text" ng-model="assetSearchData.primaryAssetRevery" name="primaryAssetRecovery" id="primaryAssetRecovery" ng-keyup="getAssetSearchData()" class="form-control input-sm" value="" />
								</div>
							</div>
						</div>						
					</div>
				</div>
				
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">&nbsp;</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<table id="example1" class="table table-bordered table-striped " width="100%">
							<thead>
								<tr>
									<th class="trGray" rowspan="3">&nbsp;</th>
									<th class="trGray" rowspan="3">Location Type</th>
									<th class="trGray" rowspan="3">Loc Ref #</th>
									<th class="trGray" rowspan="3">Loc Name</th>
									<th class="trGray" rowspan="3">City</th>
									<th class="trGray" rowspan="3">State</th>
									<th class="trGray" rowspan="3">Zip Code</th>
									<th class="trGray" rowspan="3">Primary Asset Recovery  Provider #</th>
									<th class="trGray" rowspan="3">Last Call Date</th>
									<th class="trGray" rowspan="3">Next Call Date</th>
									<th class="trGray" rowspan="3">Last Service Date</th>
									<th class="trGray" colspan="12" class="text-center">On Hand Inventory</th>
									<th class="trGray" colspan="4" class="text-center">Confirmed Available</th>
								</tr>
								<tr>
									<th class="trBlue" align="center" colspan="3">SKU APU TRI48</th>
									<th class="trBlue" align="center" colspan="3">SKU APU TRI57</th>
									<th class="trBlue" align="center" colspan="3">SP TRUCK</th>
									<th class="trBlue" align="center" colspan="3">SP TRUCK2</th>
									<th class="trBlue" align="center" rowspan="2">SKU APU TRI48</th>
									<th class="trBlue" align="center" rowspan="2">SKU APU TRI57</th>
									<th class="trBlue" align="center" rowspan="2">SP TRUCK</th>
									<th class="trBlue" align="center" rowspan="2">SP TRUCK2</th>									
								</tr>
								<tr>
									<th>30</th>
									<th>60</th>
									<th>90+</th>
									<th>30</th>
									<th>60</th>
									<th>90+</th>
									<th>30</th>
									<th>60</th>
									<th>90+</th>
									<th>30</th>
									<th>60</th>
									<th>90+</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td><input type="checkbox" name="assetId" onclick="showOrderButton()" value="1" /></td>
									<td>dealership Loc</td>
									<td><a href="<?php echo base_url();?>ReverseLogistics/getLocationInventoryInformation">12334US</a></td>
									<td>Thermo King Atlanta </td>
									<td>Atlanta</td>
									<td>GA</td>
									<td>34847</td>
									<td>ABMEMA</td>
									<td>2/15/2019</td>
									<td>3/28/2019</td>
									<td>1/5/2019</td>
									<td>4</td>
									<td>9</td>
									<td>39</td>
									<td>2</td>
									<td>5</td>
									<td>0</td>
									<td>1</td>
									<td>0</td>
									<td>3</td>
									<td>0</td>
									<td>9</td>
									<td>0</td>
									<td>3</td>
									<td></td>
									<td>2</td>
									<td>1</td>
								</tr>
								
							</tbody>
						</table>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">&nbsp;</div>
				</div>
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><a href="#" class="btn btn-primary">Create Order</a></div>
				</div>
            </div>
			</form>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/reverseLogistics/assetSearchCtrl.js"></script>