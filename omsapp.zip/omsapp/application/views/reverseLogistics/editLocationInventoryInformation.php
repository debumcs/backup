<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Edit Location Inventory</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Reverse Logistics Asset Search</a></li>
        <li class="active">Edit Location Inventory</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content form-page">
	
		<div class="box">
		<div class="box-body">
			<div class="padleftright20">
				<div class="accordion-option">
					<!-- <h3 class="title">Lorem Ipsum</h3> -->
					<!--a href="edit_savedorder.html" class="btn btn-primary">Edit</a-->
					<a href="javascript:void(0)" class="toggle-accordion active" accordion-id="#accordion"></a>
				</div>
				<div class="clearfix"></div>
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
								Location Details
								</a>
							</h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
							<div class="panel-body">
								<div class="row ">
									<div class="col-md-12 col-lg-12 col-sm-12">
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Location Type:</strong> Dealership Loc</label>
												</div>
											</div>										
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Reference Code:</strong> REF001</label>
												</div>
											</div>					
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Location Name:</strong> LocationMainName</label>
												</div>
											</div>						
										</div>									
										<div class="row">														
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Account Nickname:</strong> MainMA</label>
												</div>
											</div>		
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Address 1:</strong> Address 1</label>
												</div>
											</div>									
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Address 2:</strong> Address 2</label>
												</div>
											</div>	
										</div>
										
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>City:</strong> Florida</label>
												</div>
											</div>
											
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>State:</strong> California</label>
												</div>
											</div>
											
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Country:</strong> USA</label>
												</div>
											</div>									
											
										</div>
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Zip Code:</strong> 57186</label>
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Business Phone:</strong> +1 548-848-4154</label>
												</div>						
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Fax:</strong> +1 864-707-6547</label>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Email:</strong> email@gmail.com</label>
												</div>
											</div>										
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Contact Name:</strong> Bill</label>
												</div>
											</div>						
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Contact Phone:</strong> +1 558-958-5566</label>
												</div>
											</div>												
										</div>
										<div class="row">					
											<div class="col-md-6" id="time-range">
												<table id="example1" class="table table-bordered table-striped ">
													<thead>
														<tr>
															<th style="text-align:center;" align="center" colspan="3">Operational Hours</th>
														</tr>
														<tr>
															<td align="center">Open Days</td>
															<td align="center">From Time</td>
															<td align="center">To Time</td>
														</tr>
													</thead>
													<tbody>
														<tr>												
															<td>Monday</td>
															<td>9:30AM</td>
															<td>6:30PM</td>												
														</tr>
														<tr>												
															<td>Tuesday</td>
															<td>9:30AM</td>
															<td>6:30PM</td>												
														</tr>
														<tr>												
															<td>Wednesday</td>
															<td>9:30AM</td>
															<td>6:30PM</td>												
														</tr>
														<tr>												
															<td>Thursday</td>
															<td>9:30AM</td>
															<td>6:30PM</td>												
														</tr>
														<tr>												
															<td>Friday</td>
															<td>9:30AM</td>
															<td>6:30PM</td>												
														</tr>
														<tr>												
															<td>Saturday</td>
															<td>-</td>
															<td>-</td>												
														</tr>
														<tr>												
															<td>Sunday</td>
															<td>-</td>
															<td>-</td>												
														</tr>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>							
							</div>
						</div>
					</div>
					
					<div class="panel panel-default" id="primaryAssetRecovery">
						<div class="panel-heading" role="tab" id="headingTwo">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
								Location Management
								</a>
							</h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
							<div class="panel-body">
								<div class="row col-lg-12">
									<div class="row"><div class="col-lg-12"><h3>Primary Asset Recovery Provider</h3></div></div>
									<div class="row">&nbsp;</div>
									<div class="row" id="selectedProvider">
										<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
											<div class="form-group">
												<label>Provider Account #</label> : 201903PRO001
											</div>
										</div>
										
										<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
											<div class="form-group">
												<label>Account Name</label> : Provider Name 1
											</div>
										</div>
										<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
											<div class="form-group">
												<label>Provider Location #</label> : 201903PROLOC001
											</div>
										</div>
										<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
											<div class="form-group">
												<label>Location Name</label> : Location Name 1
											</div>
										</div>	
										
										<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
											<div class="form-group">
												<label>Location Nickname</label> : Location Nickname 1
											</div>
										</div>	
										
										<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
											<div class="form-group">
												<label>Address</label> : Address01, Address02, City01, State01
											</div>
										</div>	
										
										<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
											<div class="form-group">
												<label>Email</label> : proLocTest@email.com
											</div>
										</div>	
										
										<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
											<div class="form-group">
												<label>Phone</label> : +1 132-456-9870
											</div>
										</div>
										
										<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
											<div class="form-group">
												<label>Asset Recovery Provider Type</label> : Asset Recover Only
											</div>
										</div>
									</div>
									
									
								</div>
							
								<div class="row"><div class="col-lg-12"><h3>Asset Recovery</h3><br/></div></div>
								<div class="row">
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Asset Min Qty</label>
											<input type="text" readonly name="next_call_date" id="next_call_date" class="form-control input-sm" value="10">
										</div>
									</div>
									
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Asset Max Qty</label>
											<input type="text" readonly name="next_call_date" id="next_call_date" class="form-control input-sm" value="1000">
										</div>
									</div>
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Last Service Date</label>
											<input type="text" readonly name="next_call_date" id="next_call_date" class="form-control input-sm" value="09/15/2018">
										</div>
									</div>
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Last Call Date</label>
											<input type="text" readonly name="next_call_date" id="next_call_date" class="form-control input-sm" value="09/15/2018">
										</div>
									</div>	
									
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Next Call Date</label>
											<input type="date" name="next_call_date" id="next_call_date" class="form-control input-sm" value="">
										</div>
									</div>									
								</div>	
								
							</div>
						</div>
					</div>
						
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingThree">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
								Location Inventory
								</a>
							</h4>
						</div>
						<div id="collapseThree" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingThree">
							<div class="panel-body">
								<div class="row">
									<div class="col-lg-12">
										<table id="example1" class="table table-bordered table-striped ">
											<tbody>
												<tr>
													<td colspan="13" style="text-align:center;"><b>On Hand Inventory</b></td>
												</tr>
												<tr>
													<td align="center">SKU</td>
													<td align="center" colspan="3">SKU APU TRI48</td>
													<td align="center" colspan="3">SKU APU TRI57</td>
													<td align="center" colspan="3">SP TRUCK</td>
													<td align="center" colspan="3">SP TRUCK2</td>
												</tr>
												<tr>
													<td>Aging [Days]</td>
													<td>30</td>
													<td>60</td>
													<td>90+</td>
													<td>30</td>
													<td>60</td>
													<td>90+</td>
													<td>30</td>
													<td>60</td>
													<td>90+</td>
													<td>30</td>
													<td>60</td>
													<td>90+</td>
												</tr>
												<tr>
													<td>QTY</td>
													<td>4</td>
													<td>9</td>
													<td>39</td>
													<td>2</td>
													<td>5</td>
													<td>0</td>
													<td>1</td>
													<td>0</td>
													<td>3</td>
													<td>0</td>
													<td>9</td>
													<td>0</td>
												</tr>
											</tbody>
										</table>
									</div>
								</div>
								
								<div class="row">
									<div class="col-lg-12">
										<table id="example1" class="table table-bordered table-striped ">
											<!-- <thead>
												<tr>
													<th colspan="5" style="text-align:center;">Confirmed Available</th>
												</tr>												
											</thead> -->
											<tbody>
												<tr class="success">
													<td colspan="5" style="text-align:center;"><b>Confirmed Available</b></td>
												</tr>
												<tr class="info">
													<td align="center">SKU</td>
													<td align="center">SKU APU TRI48</td>
													<td align="center">SKU APU TRI57</td>
													<td align="center">SP TRUCK</td>
													<td align="center">SP TRUCK2</td>
												</tr>
												<tr>
													<td>QTY</td>
													<td><input type="text" name="sku11" id="sku11" class="form-control input-sm" value="3"></td>
													<td><input type="text" name="sku12" id="sku12" class="form-control input-sm" value=""></td>
													<td><input type="text" name="sku13" id="sku13" class="form-control input-sm" onkeypress="displayskulist('sku13')" value="2"></td>
													<td><input type="text" name="sku14" id="sku14" class="form-control input-sm" onkeypress="displayskulist('sku14')" value="1"></td>
												</tr>
												<tr>
													<td class="no-border"></td>
													<td class="no-border"></td>
													<td class="no-border"></td>
													<td class="no-border">
													<div class="sku13" style="display:block;">														
														<div class="well" style="max-height: 200px; max-width: 250px;overflow: auto;">
															<p>Select SNs corresponding to the Confired Ready Units:</p>
															<ul class="list-group checked-list-box">
															  <li class="list-group-item"><input checked type="checkbox" name="skucheckbox1" id="skucheckbox1" value="SN 16888246" /> SN 16888246</li>
															  <li class="list-group-item"><input type="checkbox" name="skucheckbox1" id="skucheckbox1" value="SN 16888246" />SN 46971324</li>
															  <li class="list-group-item"><input checked type="checkbox" name="skucheckbox1" id="skucheckbox1" value="SN 16888246" /> SN 28449782</li>
															  <li class="list-group-item"><input type="checkbox" name="skucheckbox1" id="skucheckbox1" value="SN 16888246" /> SN 45668759</li>
															  <li class="list-group-item"><input type="checkbox" name="skucheckbox1" id="skucheckbox1" value="SN 16888246" /> SN 54468732</li>
															  <li class="list-group-item"><input type="checkbox" name="skucheckbox1" id="skucheckbox1" value="SN 16888246" /> SN 55648822</li>
															</ul>
														</div>
													</div>
													</td>
													<td class="no-border">
													<div class="sku14" style="display:block;">
														<div class="well" style="max-height: 200px; max-width: 250px;overflow: auto;">
															<p>Select SNs corresponding to the Confired Ready Units:</p>
															<ul class="list-group checked-list-box">
															  <li class="list-group-item"><input type="checkbox" name="skucheckbox1" id="skucheckbox1" value="SN 16888246" /> SN 16888246</li>
															  <li class="list-group-item"><input checked type="checkbox" name="skucheckbox1" id="skucheckbox1" value="SN 16888246" /> SN 46971324</li>
															  <li class="list-group-item"><input type="checkbox" name="skucheckbox1" id="skucheckbox1" value="SN 16888246" /> SN 28449782</li>
															  <li class="list-group-item"><input type="checkbox" name="skucheckbox1" id="skucheckbox1" value="SN 16888246" /> SN 45668759</li>
															  <li class="list-group-item"><input type="checkbox" name="skucheckbox1" id="skucheckbox1" value="SN 16888246" /> SN 54468732</li>
															  <li class="list-group-item"><input type="checkbox" name="skucheckbox1" id="skucheckbox1" value="SN 16888246" /> SN 55648822</li>
															</ul>
														</div>
													</div>
													</td>
												</tr>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					
				</div>
				
				
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>
								<!--<button type="button" class="btn btn-primary">Submit</button>-->
								<a href="<?php echo base_url();?>ReverseLogistics/assetSearch" class="btn btn-primary">Submit</a>
							</label>
							<label>
								<a href="<?php echo base_url();?>ReverseLogistics/assetSearch" class="btn btn-default">Back</a>
							</label>											
						</div>
					</div>
				</div>
				
			</div>
		</div>
		</div>
    </section>
    <!-- /.content -->
  </div>