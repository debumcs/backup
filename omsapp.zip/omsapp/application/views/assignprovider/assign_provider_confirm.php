<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Assign Order Confirmation</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Order Management</a></li>
        <li class="active">Assign Order Confirmation</li>
      </ol>
    </section>
    
    <section class="content form-page">
		<div class="box">
		<div class="box-body">
		<?php //echo '<pre>'; print_r($orderDetails); echo '</pre>'; ?>
			<div class="padleftright20">
			<div class="accordion-option">
				<a href="javascript:void(0)" class="toggle-accordion active" accordion-id="#accordion"></a>
				</div>
				<div class="clearfix"></div>
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
								Bill To
								</a>
							</h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
							<div class="panel-body">
								<div class="row ">
									<div class="col-md-12 col-lg-12 col-sm-12">
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
												<input type="hidden" id="orderNo" name="orderNo" value="<?php echo $orderDetails["responseObject"]["orderNumber"];?>" />
													<label><strong>Order Number:</strong> <?php echo $orderDetails["responseObject"]["orderNumber"];?></label>
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Account Type:</strong> <?php echo $orderDetails["responseObject"]["accountInfo"]["accountTypeDetails"]["accountType"];?></label>
												</div>
											</div>
											<div class="col-lg-4">
												<div class="form-group">
													<label><strong>Account ID:</strong> <?php echo $orderDetails["responseObject"]["accountId"];?></label>
												</div>
											</div>
										</div>
										
										<div class="row">
											<div class="col-lg-4">
												<div class="form-group">
													<label><strong>Account Name:</strong> <?php echo $orderDetails["responseObject"]["accountInfo"]["companyName"];?></label>
												</div>
											</div>
											<div class="col-lg-4">
												<div class="form-group">
													<label><strong>Address :</strong> <?php echo $orderDetails["responseObject"]["accountInfo"]["addressLine1"].' '.$orderDetails["responseObject"]["accountInfo"]["addressLine2"].' '.$orderDetails["responseObject"]["accountInfo"]["cityDetails"]["cityName"].' '.$orderDetails["responseObject"]["accountInfo"]["stateDetails"]["stateName"].' '.$orderDetails["responseObject"]["accountInfo"]["zipCode"];?></label>
												</div>
											</div>
											<div class="col-lg-4">
												<div class="form-group">
													<label><strong>Business Phone:</strong> +1 <?php echo $orderDetails["responseObject"]["accountInfo"]["businessPhone"];?></label>
												</div>
											</div>
										</div>
										
										<div class="row">
											<div class="col-lg-4">
												<div class="form-group">
													<label><strong>Email Address:</strong> <?php echo $orderDetails["responseObject"]["accountInfo"]["contactEmail"];?></label>
												</div>
											</div>					
										</div>									
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingTwo">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
								Ship From
								</a>
							</h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
							<div class="panel-body">
								<div class="row">
									<div class="col-md-12 col-lg-12">
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Location ID:</b> <?php echo $orderDetails["responseObject"]["locationId"];?></label></label>
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Customer :</b> <?php echo $orderDetails["responseObject"]["locationInfo"]["locationName"];?></label>
												</div>
											</div>		
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Address:</b> <?php echo $orderDetails["responseObject"]["locationInfo"]["addressLine1"].' '.$orderDetails["responseObject"]["locationInfo"]["addressLine2"].' '.$orderDetails["responseObject"]["locationInfo"]["cityDetails"]["cityName"].' '.$orderDetails["responseObject"]["locationInfo"]["stateDetails"]["stateName"].' '.$orderDetails["responseObject"]["locationInfo"]["zipCode"];?></label>
												</div>
											</div>								
										</div>
										<div class="row">										
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Business Phone :</b> <?php echo $orderDetails["responseObject"]["locationInfo"]["businessPhone"];?></label>
												</div>
											</div>		
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Email:</b> <?php echo $orderDetails["responseObject"]["locationInfo"]["contactEmail"];?></label>
												</div>
											</div>
										</div>
									</div>									
								</div>
							</div>
						</div>
					</div>
					
					
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingThree">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
								Order
								</a>
							</h4>
						</div>
						<div id="collapseThree" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingThree">
							<div class="panel-body">											
							<div class="row">
								
								<div class="col-lg-12">
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>PO Number:</strong> <?php echo $orderDetails["responseObject"]["poNumber"];?></label>
											</div>
										</div>	
										
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Reference Number 1:</strong> <?php echo $orderDetails["responseObject"]["referenceCol1"];?></label>
											</div>
										</div>
										
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Reference Number 2:</strong> <?php echo $orderDetails["responseObject"]["referenceCol2"];?></label>
											</div>
										</div>
									</div>	
									
									<div class="row">								
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Pick Up Due Date:</strong> <?php echo date('m/d/Y',($orderDetails["responseObject"]["pickUpDueDate"]/1000));?></label>
											</div>
										</div>	
										
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Requested Pickup Date :</strong> <?php if($orderDetails["responseObject"]["pickUpDueDate"] > 1){echo date('m/d/Y',($orderDetails["responseObject"]["pickUpDueDate"]/1000));}?></label>
											</div>
										</div>	
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Requested Pick up Time :</strong> <?php echo $orderDetails["responseObject"]["pickUpTime"];?></label>
											</div>
										</div>
									</div>
							
									<div class="row">								
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Special Instructions :</strong> <?php echo $orderDetails["responseObject"]["instructions"];?></label>
											</div>
										</div>
									</div>
							
							
								</div>
							</div>					
							</div>
						</div>
					</div>
				
				<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingFour">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
								Order Summary
								</a>
							</h4>
						</div>
						<div id="collapseFour" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingFour">
							<div class="panel-body">											
							<div class="row">
								
								<div class="col-lg-12">
									<div class="row">
										<div class="col-lg-6">
											
											<table class="display table table-bordered table-striped dataTable no-footer" width="100%">
												<thead>
													<tr>
														<th width="75">SKU</th>
														<th width="120">Description</th>
														<th width="75">Quantity</th>
														<th width="75">LBS</th>
													</tr>
												</thead>
												<tbody>
													<?php foreach($orderDetails["responseObject"]["orderComponents"] as $value){if(intval($value["quantity"])>0){ ?>
													<tr>
														<td><?php echo $value["sku"]; ?></td>
														<td><?php echo $value["description"]; ?></td>
														<td><?php echo $value["quantity"]; ?></td>
														<td><?php echo intval($value["quantity"])*intval($value["weight"]); ?></td>
													</tr>
													<?php }} ?>
												</tbody>
											</table>
										</div>										
									</div>
								</div>	
								
							</div>
							</div>
						</div>					
				</div>
				
				<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingFive">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="true" aria-controls="collapseFive">
								Order Details
								</a>
							</h4>
						</div>
						<div id="collapseFive" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingFive">
							<div class="panel-body">											
							<div class="row">
								
								<div class="col-lg-12">
									<div class="row">
										<div class="col-lg-6">
											
											<table class="display table table-bordered table-striped dataTable no-footer" width="100%">
												<thead>
													<tr>
														<th width="75">SKU</th>
														<th width="120">Description</th>
														<th width="50">Quantity</th>
														<th width="50">Total Pieces</th>
														<th width="50">LBS</th>
													</tr>
												</thead>
												<tbody>
													<?php foreach($orderDetails["responseObject"]["skuSubList"] as $value){ ?>
													<tr>
														<td><?php echo $value["skuNumber"]; ?></td>
														<td><?php echo $value["skuNumber"]; ?></td>
														<td><?php echo $value["quantity"]; ?></td>
														<td><?php echo $value["quantity"]; ?></td>
														<td><?php echo intval($value["weight"]) * intval($value["quantity"]); ?></td>
													</tr>
													<?php } ?>
												</tbody>
											</table>
										</div>										
									</div>
								</div>	
								
							</div>
							</div>
						</div>					
				</div>
				
				<div class="panel panel-default">
					<div class="panel-heading" role="tab" id="headingSeven">
						<h4 class="panel-title">
							<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseSeven" aria-expanded="true" aria-controls="collapseSeven">
							Assigned Provider
							</a>
						</h4>
					</div>
					<div id="collapseSeven" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingSeven">
						<div class="panel-body">
							<div class="row">
								<div class="col-md-12 col-lg-12 col-sm-12">
									<!-- provider details -->	
									
									<div class="row">
										<div class="col-md-6"><label>Provider ID</label>: <?php echo $providerDetails["responseObject"]["accountId"];
										//echo '<pre>';print_r($providerDetails); echo '</pre>'; ?></div>
										<div class="col-md-6"><label>Provider Name</label>: <?php echo $providerDetails["responseObject"]["companyName"]; ?></div>
									</div>
									
									<div class="row">
										<div class="col-md-6"><label>Address</label>: <?php echo $providerDetails["responseObject"]["addressLine1"]; ?> <?php echo $providerDetails["responseObject"]["addressLine2"]; ?></div>
										<div class="col-md-6"><label>Business Number</label>: +1 <?php echo $providerDetails["responseObject"]["businessPhone"]; ?></div>
									</div>
									
									
									<div class="row">
										<div class="col-md-6"><label>Email</label>: <?php echo $providerDetails["responseObject"]["contactEmail"]; ?></div>
									</div>
									<div class="row">
									</div>
									
									<!-- provider details -->
								</div>									
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
		</div>
    </section>
    <!-- /.content -->
  </div>