<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>View Order Information</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Order Management</a></li>
        <li class="active">View Order Information</li>
      </ol>
    </section>
    
    <section class="content form-page">
		<div class="box">
		<div class="box-body">
			<div class="padleftright20">
				<div class="accordion-option">
					<!--?php echo "<pre>";print_r($orderDetails);die; ?-->

				<?php if($orderDetails["responseObject"]["orderStatus"] == 1 ){ ?>
					<a href="<?php echo base_url().'index.php/Orders/edit_order/'.$orderDetails["responseObject"]["orderNumber"]; ?>" class="btn btn-primary">Edit</a>
					<a href="#" data-toggle="modal" class="btn btn-danger" data-target="#modalCancelOrder">Cancel Order</a>
					<a href="javascript:void(0)" class="toggle-accordion active" accordion-id="#accordion"></a>
				<?php } ?>
				</div>
				<div class="clearfix"></div>
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					<?php 
								/* echo '<pre>';
								print_r($orderDetails);
								echo '</pre>'; */
								
								?>
					<?php if($orderDetails["responseObject"]["orderStatus"] == 3 ){ ?>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingZero">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseZero" aria-expanded="true" aria-controls="collapseZero">
								Order Status
								</a>
							</h4>
						</div>
						<div id="collapseZero" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingZero">
							<div class="panel-body">
								<div class="row ">
									<div class="col-md-12 col-lg-12 col-sm-12">
										<div class="row">
											<div class="col-md-12">
												<div class="form-group">
													<label><strong>Order Status:</strong> <?php echo $orderDetails["responseObject"]["orderStatusDetails"]["statusDesc"];?></label>
												</div>
											</div>
										</div>
										<!--div class="row">
											<div class="col-md-12">
												<div class="form-group">
													<label><strong>Reason:</strong> <?php //echo $orderDetails["responseObject"]["orderNumber"];?></label>
												</div>
											</div>
										</div-->
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php } ?>
					
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
								Bill To
								</a>
							</h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
							<div class="panel-body">
								<div class="row ">
									<div class="col-md-12 col-lg-12 col-sm-12">
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Order Number:</strong> <?php echo $orderDetails["responseObject"]["orderNumber"];?></label>
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Account Type:</strong> <?php echo $orderDetails["responseObject"]["accountInfo"]["accountTypeDetails"]["accountType"];?></label>
												</div>
											</div>
											<div class="col-lg-4">
												<div class="form-group">
													<label><strong>Account ID:</strong> <?php echo $orderDetails["responseObject"]["accountId"];?></label>
												</div>
											</div>
										</div>
										
										<div class="row">
											<div class="col-lg-4">
												<div class="form-group">
													<label><strong>Account Name:</strong> <?php echo $orderDetails["responseObject"]["accountInfo"]["companyName"];?></label>
												</div>
											</div>
											<div class="col-lg-4">
												<div class="form-group">
													<label><strong>Address :</strong> <?php echo $orderDetails["responseObject"]["accountInfo"]["addressLine1"].' '.$orderDetails["responseObject"]["accountInfo"]["addressLine2"].' '.$orderDetails["responseObject"]["accountInfo"]["cityDetails"]["cityName"].' '.$orderDetails["responseObject"]["accountInfo"]["stateDetails"]["stateName"].' '.$orderDetails["responseObject"]["accountInfo"]["zipCode"];?></label>
												</div>
											</div>
											<div class="col-lg-4">
												<div class="form-group">
													<label><strong>Business Phone:</strong> +1 <?php echo $orderDetails["responseObject"]["accountInfo"]["businessPhone"];?></label>
												</div>
											</div>
										</div>
										
										<div class="row">
											<div class="col-lg-4">
												<div class="form-group">
													<label><strong>Email Address:</strong> <?php echo $orderDetails["responseObject"]["accountInfo"]["contactEmail"];?></label>
												</div>
											</div>					
										</div>									
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingTwo">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
								Ship From
								</a>
							</h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
							<div class="panel-body">
								<div class="row">
									<div class="col-md-12 col-lg-12">
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Location ID:</b> <?php echo $orderDetails["responseObject"]["shipFromLocationId"];?></label></label>
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Customer :</b> <?php echo $orderDetails["responseObject"]["shipFromLocationDetails"]["locationName"];?></label>
												</div>
											</div>		
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Address:</b> <?php 
													echo $orderDetails["responseObject"]["shipFromLocationDetails"]["addressLine1"].' '.
													     //$orderDetails["responseObject"]["shipFromLocationDetails"]["addressLine2"].' '.
													     $orderDetails["responseObject"]["shipFromLocationDetails"]["cityDetails"]["cityName"].' '.
													     $orderDetails["responseObject"]["shipFromLocationDetails"]["stateDetails"]["stateName"].' '.
													     $orderDetails["responseObject"]["shipFromLocationDetails"]["zipCode"];?></label>
												</div>
											</div>								
										</div>
										<div class="row">										
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Business Phone :</b> <?php echo $orderDetails["responseObject"]["shipFromLocationDetails"]["businessPhone"];?></label>
												</div>
											</div>		
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Email:</b> <?php echo $orderDetails["responseObject"]["shipFromLocationDetails"]["contactEmail"];?></label>
												</div>
											</div>
										</div>
									</div>									
								</div>
							</div>
						</div>
					</div>
					

					<!-- Ship To -->
                      <div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingsix">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapsesix" aria-expanded="true" aria-controls="collapsesix">
								Ship To
								</a>
							</h4>
						</div>
						<div id="collapsesix" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingsix">
							<div class="panel-body">
								<div class="row">
									<div class="col-md-12 col-lg-12">
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Location ID:</b> <?php  if(isset($orderDetails["responseObject"]["shipToLocationId"])){
														echo $orderDetails["responseObject"]["shipToLocationId"];
													};?> </label>
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Customer :</b>  <?php  if(isset($orderDetails["responseObject"]["shipToLocationDetails"])){
														echo $orderDetails["responseObject"]["shipToLocationDetails"];
													};?>  </label>
												</div>
											</div>		
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Address:</b> <?php  if(isset($orderDetails["responseObject"]["shipToLocationDetails"])){
														echo $orderDetails["responseObject"]["shipToLocationDetails"];
													};?> </label>
												</div>
											</div>								
										</div>
										<div class="row">										
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Business Phone :</b> <?php  if(isset($orderDetails["responseObject"]["shipToLocationDetails"]["contactEmail"])){
														echo $orderDetails["responseObject"]["shipToLocationDetails"]["contactEmail"];
													};?> </label>
												</div>
											</div>		
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Email:</b> <?php  if(isset($orderDetails["responseObject"]["shipToLocationDetails"]["contactEmail"])){
														echo $orderDetails["responseObject"]["shipToLocationDetails"]["contactEmail"];
													};?> </label>
												</div>
											</div>
										</div>
									</div>									
								</div>
							</div>
						</div>
					</div>

					<!--End -->

					<div class="panel panel-default" <?php if($orderDetails["responseObject"]["orderTypeDetails"]["typeDesc"] == 'Outbound'){ 
											echo 'style="display:none;"'; 
										} ?>>
						<div class="panel-heading" role="tab" id="headingseven">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseseven" aria-expanded="true" aria-controls="collapseseven">
								Primary Asset Recovery Provider Details
								</a>
							</h4>
						</div>
						<div id="collapseseven" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingseven"
                       >
							<div class="panel-body">											
							<div class="row">
								
								<div class="col-lg-12">
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Provider ID:</strong> AAA000006 </label>
											</div>
										</div>	
										
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Provider Name:</strong> Above and Beyond Moving Services </label>
											</div>
										</div>
										
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Address:</strong> 57 Chase St. Unit 5D </label>
											</div>
										</div>
									</div>	
									
									<div class="row">								
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Business Number:</strong> +1 9782412236 </label>
											</div>
										</div>	
										
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Email:</strong> aboveandbeyondmovers@gmail.com </label>
											</div>
										</div>	
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Asset Recovery Provider Type:</strong> aboveandbeyondmovers@gmail.com</label>
											</div>
										</div>
									</div>
							   </div>
							</div>					
							</div>
						</div>
					</div>
					
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingThree">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
								Order
								</a>
							</h4>
						</div>
						<div id="collapseThree" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingThree">
							<div class="panel-body">											
							<div class="row">
								
								<div class="col-lg-12">
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
											
												<label><strong>PO Number:</strong> <?php echo $orderDetails["responseObject"]["poNumber"];?></label>
											</div>
										</div>	
										
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Reference Number 1:</strong> <?php echo $orderDetails["responseObject"]["referenceCol1"];?></label>
											</div>
										</div>
										
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Reference Number 2:</strong> <?php echo $orderDetails["responseObject"]["referenceCol2"];?></label>
											</div>
										</div>
									</div>	
									
									<div class="row">								
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Pick Up Due Date:</strong> <?php echo date('m/d/Y',($orderDetails["responseObject"]["pickUpDueDate"]/1000));?></label>
											</div>
										</div>	
										
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Requested Pickup Date :</strong> <?php if($orderDetails["responseObject"]["pickUpDueDate"] > 1){echo date('m/d/Y',($orderDetails["responseObject"]["pickUpDueDate"]/1000));}?></label>
											</div>
										</div>	
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Requested Pick up Time :</strong> <?php echo $orderDetails["responseObject"]["pickUpTime"];?></label>
											</div>
										</div>
									</div>
							
									<div class="row">								
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Special Instructions :</strong> <?php echo $orderDetails["responseObject"]["instructions"];?></label>
											</div>
										</div>
										
										<div class="col-md-4" id="content" 
										<?php if($orderDetails["responseObject"]["orderTypeDetails"]["typeDesc"] == 'Outbound'){ 
											echo 'style="display:none;"'; 
										} ?>>
                                          <div class="form-group">
												<label><strong>Customer Price :</strong> THGH67887 </label>
											</div>
										</div>
										<div class="col-md-4" id="contentprice" 
										<?php if($orderDetails["responseObject"]["orderTypeDetails"]["typeDesc"] == 'Outbound'){ 
											echo 'style="display:none;"'; 
										} ?>>
											<div class="form-group">
												<label><strong>Provider Price :</strong> HFG7899 </label>
											</div>
										</div>
										<div class="col-md-4" id="contentprice" 
										<?php if($orderDetails["responseObject"]["orderTypeDetails"]["typeDesc"] == 'Asset Collection'){ 
											echo 'style="display:none;"'; 
										} ?>>
											<div class="form-group">
												<label><strong>Spot Rate :</strong> $6876 </label>
											</div>
										</div>
									</div>
							
							
								</div>
							</div>					
							</div>
						</div>
					</div>
				
				<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingFour">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
								Order Details
								</a>
							</h4>
						</div>
						<div id="collapseFour" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingFour">
							<div class="panel-body">											
							<div class="row">
								
								<div class="col-lg-12">
									<div class="row">
										<div class="col-lg-6">
											<div class="col-md-12 col-lg-12">
												<div class="row"><h5><b>Pickup</b></h5></div>
											</div>
											<table class="display table table-bordered table-striped dataTable no-footer" width="100%">
												<thead>
													<tr>
														<th width="75">SKU</th>
														<th width="120">Quantity</th>
														<th width="120">Serial #s</th>
													</tr>
												</thead>
												<tbody>
													<?php foreach($orderDetails["responseObject"]["orderComponents"] as $value){ ?>
													<tr>
														<td width="30"><?php echo $value["sku"]; ?></td>
														<td width="120"><?php echo $value["quantity"]; ?></td>
														<td width="120">78,879.779</td>
													</tr>
													<?php } ?>
												</tbody>
											</table>
										</div>										
									</div>
								</div>	
								
							</div>
							</div>
						</div>					
				</div>
				
				<div class="row">
					<div class="col-md-6">&nbsp;</div>
				</div>
				
			</div>
		</div>
		</div>
    </section>
    <!-- /.content -->
  </div>

<div id="modalCancelOrder" class="modal fade" role="dialog" ng-controller="cancelOrderCtrl">
	<div class="modal-dialog modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<div class="col-md-12">	
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h3 class="modal-title"><b>Cancel Order</b></h3>
				</div>
			</div>
			<div class="modal-body" style="min-height:200px;">
			
			<form autocomplete="off" name="cancelOrderForm" >
				<div class="col-md-12">
					<div class="row">				
						<div class="col-md-12">							
							<div class="form-group">
								<label>Are you sure want to cancel this order? </label>
								
								
								
								<input type="hidden" id="orderNo" name="orderNo" value="<?php echo $orderDetails["responseObject"]["orderNumber"];?>" />
								<input type="hidden" ng-model="orderData.orderNumber" name="orderNo" />
								<label>
									<input type="radio" ng-model="orderData.reason" ng-click="showReason('Yes')" name="reason" id="reasonYes" value="Yes" /> Yes
								</label>
								<label>
									<input type="radio" ng-model="orderData.reason" ng-click="showReason('No')" name="reason" id="reasonNo"  value="No" /> No
								</label>							
							</div>
						</div>						
						<div class="col-md-12" ng-show="reasonDiv">
							<div class="form-group">
								<label>Reason: </label>
								<textarea class="form-control" ng-model="orderData.reasonCancel" name="reasonCancel" id="reasonCancel" rows="2" placeholder="Enter ..."></textarea>
							</div>
						</div>
					</div>	
					<div class="row">				
						<div class="col-md-12">							
							<div class="form-group">
								<button type="button" ng-click="cancelOrder()" ng-disabled="cancelButton" class="btn btn-primary">Submit</button>
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							</div>
						</div>
					</div>
					
					<div class="row" ng-show="errorMsg">				
						{{ errorMsg }}
					</div>
				</div>
			</form>
			</div>
			<div class="modal-footer">
				<!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
			</div>
		</div>
	</div>
</div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/orders/cancelOrderCtrl.js"></script>