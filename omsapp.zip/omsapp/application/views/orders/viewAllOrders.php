<div class="content-wrapper" ng-controller="viewAllOrders">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Order</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li><a href="#">Order Management</a></li>
        <li class="active">List of all orders</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          
          <div class="box">
            <div class="box-header with-border">
				<!--<a href="createorder.html" class="pull-right btn btn-default">Create Order</a>-->
				<h3 class="box-title m10"><b>List of all Orders</b></h3>
			</div>
			
            <!-- /.box-header -->
			<form autocomplete="off" name="viewAllOrders">
            <div class="box-body">
				<div class="row">
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Order Type </label><!-- onchange="redirectPage(this.value);" -->
							<select class="form-control input-md" ng-change="getAllOrders()" width="100%" ng-init='orderData.OrderType=""' ng-model="orderData.OrderType" name="OrderType" id="OrderType" required>
								<option value="" >Select Order Type</option>
								<option ng-repeat="type in orderTypes" value="{{type.id}}">{{type.typeDesc}}</option>
							</select>
						</div>
					</div>
					
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Order# </label>
							<input type="text" ng-model="orderData.OrderNumber" name="OrderNumber" id="OrderNumber" ng-keyup="getAllOrders()" class="form-control input-sm" value="" placeholder="Enter Order Number">
						</div>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Account# </label>
							<input type="text"  ng-model="orderData.AccountId" name="AccountId" id="AccountId" ng-keyup="getAllOrders()" class="form-control input-sm" value="" placeholder="Enter Account ID">
						</div>
					</div>
										
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Status</label>
							<select class="form-control input-md" ng-model="orderData.OrderStatus" name="OrderStatus" id="OrderStatus" ng-change="getAllOrders()" width="100%">
							<option value="" selected>Select Status</option>
							<option ng-repeat="status in allOrderStatus" value="{{status.id}}">{{status.statusDesc}}</option>
							</select>
						</div>
					</div>
					
					<div class="col-md-4">
						<div class="form-group">
							<label>&nbsp;<br/></label>
							<div class="input-group">
								<button class="btn btn-success" type="button" ng-click="cust_search_fields()">Advanced Search</button>
							</div>
						</div>
					</div>
				</div>
				
				<div class="row" ng-show="IsCustSearchFieldsVisible">
					
					
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Location# </label>
							<input type="text" ng-model="orderData.LocationId" name="LocationId" id="LocationId" ng-keyup="getAllOrders()" class="form-control input-sm" value="" placeholder="Enter Location ID">
						</div>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Customer Ref#</label>
							<input type="text" ng-model="orderData.LocationRef" name="LocationRef" id="LocationRef" ng-keyup="getAllOrders()" class="form-control input-sm" value="" placeholder="Enter Location Ref Code">
						</div>
					</div>
					
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Customer </label>
							<input type="text" ng-model="orderData.LocationName" name="LocationName" id="LocationName" ng-keyup="getAllOrders()" class="form-control input-sm" value="" placeholder="Enter Location name">
						</div>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Customer Nickname </label>
							<input type="text" ng-model="orderData.LocationNickName" name="LocationNickName" id="LocationNickName" ng-keyup="getAllOrders()" class="form-control input-sm" value="" placeholder="Enter Location Nickname">
						</div>
					</div>					
				</div>
				
				<div class="row">
					<div class="col-lg-12 col-md-12">
						<!--<table id="example" class="table table-bordered table-striped">-->
						<table datatable="ng" dt-options="dtOptions" class="table table-striped table-bordered">
						<thead>
						<tr>
						  <th>Order#</th>
						  <th>Account#</th>
						  <th>Customer#</th>
						  <th>Customer Ref#</th>
						  <th>Name</th>
						  <th>Nickname</th>
						  <th>Address</th>
						  <th>City</th>
						  <th>State</th>
						  <th>PU Due</th>
						  <th>PU Requested</th>
						  <th>Status</th>
						  <th>Action</th>
						</tr>
						</thead>
						<tbody>
							<tr ng-repeat="order in allOrderList">
							  <td><a href="<?php echo base_url();?>Orders/view_order/{{order.orderNumber}}">{{order.orderNumber}}</a></td>
							  <td>{{order.accountId}}</td>
							  <td>{{order.shipFromLocationDetails.locationId}}</td>
							  <td>{{order.accountInfo.referenceCode}}</td>
							  <td>{{order.shipFromLocationDetails.locationName}}</td>
							  <td>{{order.accountInfo.nickName}}</td>
							  <td>{{order.shipFromLocationDetails.addressLine1}} {{order.locationInfo.addressLine2}}</td>
							  <td>{{order.shipFromLocationDetails.cityDetails.cityName}}</td>
							  <td>{{order.shipFromLocationDetails.stateDetails.stateName}}</td>
							  <td>{{order.pickUpDueDate | date:'MM/dd/yyyy' }}</td>
							  <td>{{order.pickUpDate | date:'MM/dd/yyyy' }}</td>
							  <td>{{order.orderStatusDetails.statusDesc}}</td>
							  <td><!--<a href="edit_savedorder_asset_tk.html"><img src="<?php echo base_url(); ?>asset/dist/img/iconfinder_edit_3218.png" style="width: 20px;" /></a>&nbsp;&nbsp;--><a href="#"><img src="<?php echo base_url(); ?>asset/dist/img/pdf.png" style="width: 20px;" /></a></td>
							</tr>
						</tbody>
					  </table>
					</div>
				</div>
              
            </div>
			</form>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/orders/viewAllOrders.js"></script>