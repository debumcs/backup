<div class="content-wrapper">
  <section class="content-header">
    <h1>Account Confirmation</h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">Account Management</a></li>
      <li class="active">Account Confirmation</li>
    </ol>
  </section>
  <section class="content form-page">
  <div class="box">
  <div class="box-body">
    <div class="padleftright20">
      <div class="accordion-option">
        <!-- <h3 class="title">Lorem Ipsum</h3> -->
        <!--a href="edit_savedorder.html" class="btn btn-primary">Edit</a-->
        <a href="javascript:void(0)" class="toggle-accordion active" accordion-id="#accordion"></a>
      </div>
      <div class="clearfix"></div>
      <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
        <div class="panel panel-default">
          <div class="panel-heading" role="tab" id="headingOne">
            <h4 class="panel-title">
              <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
              Account Details
              </a>
            </h4>
          </div>
          <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
            <div class="panel-body">
			<?php echo '<pre>'; print_r($accountDetails); echo '</pre>';?>
			
              <div class="row">
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Account#:</strong> <?php echo $accountDetails["responseObject"]["accountId"]; ?></label>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Account Type:</strong> <?php echo $accountDetails["responseObject"]["accountTypeDetails"]["accountType"]; ?></label>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Ref #:</strong> <?php echo $accountDetails["responseObject"]["referenceCode"]; ?></label>
                  </div>
                </div>									
              </div>									
              <div class="row">														
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Company Name:</strong> <?php echo $accountDetails["responseObject"]["companyName"]; ?></label>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Account Nickname:</strong> <?php echo $accountDetails["responseObject"]["nickName"]; ?></label>
                  </div>
                </div>		
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Address 1:</strong> <?php echo $accountDetails["responseObject"]["addressLine1"]; ?></label>
                  </div>
                </div>
              </div>
              
              <div class="row">
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Address 2:</strong> <?php echo $accountDetails["responseObject"]["addressLine2"]; ?></label>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>City:</strong> <?php echo $accountDetails["responseObject"]["cityDetails"]["cityName"]; ?></label>
                  </div>
                </div>
                                  
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>State:</strong> <?php echo $accountDetails["responseObject"]["stateDetails"]["stateName"]; ?></label>
                  </div>
                </div>
                
              </div>
              <div class="row">
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Country:</strong> <?php echo $accountDetails["responseObject"]["countryDetails"]["countryName"]; ?></label>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Zip Code:</strong> <?php echo $accountDetails["responseObject"]["zipCode"]; ?></label>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Business Phone:</strong> <?php echo $accountDetails["responseObject"]["businessPhone"]; ?></label>
                  </div>						
                </div>									
              </div>
              <div class="row">
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Fax:</strong> <?php echo $accountDetails["responseObject"]["fax"]; ?></label>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Contact Email:</strong> <?php echo $accountDetails["responseObject"]["contactEmail"]; ?></label>
                  </div>
                </div>										
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Contact Name:</strong> <?php echo $accountDetails["responseObject"]["contactName"]; ?></label>
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Contact Phone:</strong> <?php echo $accountDetails["responseObject"]["contactPhone"]; ?></label>
                  </div>
                </div>
                <!--<div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Status:</strong> <?php echo $accountDetails["responseObject"]["accountStatusDetails"]["statusDesc"]; ?></label>
                  </div>
                </div>-->
              </div>

              <div class="row">					
                <div class="col-md-6" id="time-range">
                  <table id="example1" class="table table-bordered table-striped ">
                    <thead>
                      <tr>
                        <th align="center">&nbsp;</th>
                        <th align="center" colspan="2">Operational hours</th>
                      </tr>
                      <tr>
                        <th align="center">Open Days</th>
                        <th align="center">From Time</th>
                        <th align="center">To Time</th>
                      </tr>
                    </thead>
                    <tbody>
					<?php foreach($accountDetails["responseObject"]["operationalHours"] as $value){ ?>
                      <tr>												
                        <td><?php echo $value["day"]; ?></td>
                        <td><?php echo $value["startTime"]; ?></td>
                        <td><?php echo $value["endTime"]; ?></td>
                      </tr>
                    <?php } ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
          
        <div class="panel panel-default">
          <div class="panel-heading" role="tab" id="headingTwo">
            <h4 class="panel-title">
              <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
              Administrator Setup
              </a>
            </h4>
          </div>
          <div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
            <div class="panel-body">
              <div class="row">
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>User Name:</strong> <?php echo $accountDetails["responseObject"]["adminDetails"]["userName"]; ?></label>
                  </div>
                </div>									
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Employee No:</strong> <?php echo $accountDetails["responseObject"]["adminDetails"]["employeeNumber"]; ?></label>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>First Name:</strong> <?php echo $accountDetails["responseObject"]["adminDetails"]["firstName"]; ?></label>
                  </div>
                </div>	
              </div>							
              <div class="row">								
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Last Name:</strong> <?php echo $accountDetails["responseObject"]["adminDetails"]["lastName"]; ?></label>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Email Address:</strong> <?php echo $accountDetails["responseObject"]["adminDetails"]["email"]; ?></label>
                  </div>
                </div>								
                <div class="col-md-4">
                  <div class="form-group">
                    <label><strong>Phone Number:</strong> <?php echo $accountDetails["responseObject"]["adminDetails"]["phoneNumber"]; ?></label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="panel panel-default">
          <div class="panel-heading" role="tab" id="headingThree">
            <h4 class="panel-title">
              <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
              Associations
              </a>
            </h4>
          </div>
          <div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
            <div class="panel-body">
              
              <div class="row">
                <div class="col-lg-12">
                  <table id="datatable" class="table table-bordered table-striped dataTable">
                    <thead>
                      <tr>
                        <th>Location Id</th>
                        <th>Location Type</th>
                        <th>Customer Ref #</th>
                        <th>Customer</th>
                        <th>Unit #</th>
                        <th>Customer Nickname</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
					<?php foreach($accountDetails["responseObject"]["associatedLocations"] as $value){ ?>
                      <tr>
                        <td><?php echo $value["locationId"]; ?></td>
                        <td><?php echo $value["locationTypeDetails"]["locationType"]; ?></td>
                        <td><?php echo $value["referenceCode"]; ?></td>
                        <td><?php echo $value["locationName"]; ?></td>
                        <td><?php echo $value["unitNumber"]; ?></td>
                        <td><?php echo $value["nickName"]; ?></td>
                        <td><?php echo $value["addressLine1"]. ' ' . $value["addressLine2"]; ?></td>
                        <td><?php echo $value["cityDetails"]["cityName"]; ?></td>
                        <td><?php echo $value["stateDetails"]["stateName"]; ?></td>
                        <td><?php echo $value["statusDetails"]["statusDesc"]; ?></td>
                      </tr>
					<?php } ?>
                    </tbody>
                  </table>
                </div>
              </div>
              
            </div>
          </div>
        </div>
        
      </div>
      
      
      
    </div>
    
  </div>
  </div>
  </section>
</div>