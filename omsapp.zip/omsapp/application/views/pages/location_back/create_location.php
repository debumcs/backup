  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Create Location</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Location</a></li>
        <li class="active">Create Location</li>
      </ol>
    </section>
    <section class="content form-page">
		<div class="box">
		<div class="box-body">
			<form name="create_location" id="create_location" method="post" action="<?php echo base_url(); ?>index.php/Location/post_create_location">
			<div class="padleftright20">
				<div class="accordion-option">
					<a href="javascript:void(0)" class="toggle-accordion active" accordion-id="#accordion"></a>
				</div>
				<div class="clearfix"></div>
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
								Location Details
								</a>
							</h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
							<div class="panel-body">
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Location Type</label>
											<select class="form-control" required id="locationType" name="locationType">
											<option value="" selected="selected">Select Location</option>
											<?php 
											foreach($locationTypes as $value){
												echo '<option value="'.$value->id.'">'.$value->locationType.'</option>';
											}
											?>
											</select>
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label>Ref#</label>
													<input type="text" name="referenceCode" id="referenceCode" class="form-control" placeholder="Enter Ref#">
												</div>
											</div>
											
											<div class="col-md-6">
												<div class="form-group">
													<label>Unit Number</label>
													<input type="text" name="unitNumber" id="unitNumber" class="form-control" placeholder="Enter Unit Number">
												</div>
											</div>
										</div>
									</div>
									
								</div>
								
								<div class="row">					
									<div class="col-md-6">
										<div class="form-group">
											<label>Location Name</label>
											<input type="text" name="locationName" required id="locationName" class="form-control" placeholder="Enter Location Name">
										</div>
									</div>					
								<!-- /.form-group -->
											
									<div class="col-md-6">
										<div class="form-group">
											<label>Location Nickname</label>
											<input type="text" name="nickName" id="nickName" class="form-control" placeholder="Enter Location Nick Name">
										</div>
									</div>	
								</div>
								
								<div class="row">	
									<div class="col-md-6">
										<div class="form-group">
											<label>Address 1</label>
											<input type="text" name="addressLine1" required id="addressLine1" class="form-control" placeholder="Enter Address">
										</div>
									</div>
								
									<div class="col-md-6">
										<div class="form-group">
											<label>Address 2</label>
											<input type="text" name="addressLine2" id="addressLine2" class="form-control" placeholder="Enter Address">
										</div>
									</div>	
								</div>
								
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Zip Code</label>
											<input type="text" name="zipCode" required id="zipCode" class="form-control" placeholder="Enter Zip Code">
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="form-group">
											<label>Country</label>
											<select class="form-control" required style="width: 100%;" id="country" name="country" onchange="getStates(this.value)">
											<option selected="selected" value="">Select Country</option>
											<option value="1">USA</option>
											</select>
										</div>
									</div>
									
								</div>
								
								<div class="row">										
									<div class="col-md-6">
										<div class="form-group">
											<label>State</label>
											<select class="form-control select2" required id="state" onchange="getCities(this.value)" name="state" style="width: 100%;">
											</select>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>City</label>
											<select class="form-control select2" required id="city" name="city" style="width: 100%;">
											</select>
										</div>
									</div>	
								</div>
								
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Business Phone</label>
											<div class="input-group">
												<span class="input-group-addon">+1</span>
												<input type="text" name="businessPhone" id="businessPhone" class="form-control" placeholder="Enter Business Phone Number">
											</div>	
										</div>						
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Fax</label>
											<div class="input-group">
												<span class="input-group-addon">+1</span>
												<input type="text" name="fax" id="fax" class="form-control" placeholder="Enter Fax" />
											</div>
										</div>
									</div>	
								<!-- /.form-group -->
								</div>
								
								<div class="row">					
									<div class="col-md-6" id="time-range">
										<div class="row">
											<div class="col-md-3"><label>Days Open</label></div>
											<div class="col-md-9" style="text-align: center;"><label><center>Operational hours</center></label></div>
										</div>
										<div class="row">
											<div class="col-md-3"><label>&nbsp;</label></div>
											<div class="col-md-9">
												<div class="col-md-7"><label>From Time</label></div>
												<div class="col-md-5"><label>To Time</label></div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-3">
												<select class="form-control" id="selectday">
													<option value="All">All</option>
													<option value="Monday">Monday</option>
													<option value="Tuesday">Tuesday</option>
													<option value="Wednesday">Wednesday</option>
													<option value="Thursday">Thursday</option>
													<option value="Friday">Friday</option>
													<option value="Saturday">Saturday</option>
													<option value="Sunday">Sunday</option>
												</select>
											</div>
											<div class="col-md-3">
												<div class="input-group">
													<input type="time" id="fromtime" class="form-control" value="" />
												</div>
											</div>												
											<div class="col-md-1">&nbsp;</div>
											<div class="col-md-3">
												<div class="input-group">
													<input type="time" id="totime" class="form-control" value="" />
												</div>
											</div>
											<div class="col-md-2"><button type="button" onclick="append_day()" class="btn btn-info btn-sm"><span class="glyphicon glyphicon-plus"></span></button></div>
										</div>
											
										<div class="row" id="example">											
											
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="form-group">
											<label>Email</label>
											<input type="text" name="contactEmail" required id="contactEmail" class="form-control" placeholder="Enter Email">
										</div>
										
										<div class="form-group">
											<label>Contact Name</label>
											<input type="text" name="contactName" required id="contactName" class="form-control" placeholder="Enter Contact Name">
										</div>
									
										<div class="form-group">
											<label>Contact Phone</label>
											<div class="input-group">
												<span class="input-group-addon">+1</span>
												<input type="text" name="contactPhone" required id="contactPhone" class="form-control" placeholder="Enter Contact Phone">
											</div>											
										</div>
									</div>
								</div>								
							</div>
						</div>
					</div>
						
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingTwo">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
								Associations
								</a>
							</h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
							<div class="panel-body">
								<div class="row">
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account Type</label>
											<select class="form-control input-md" id="assoAccounttype" onchange="getAccountAssoc();" width="100%" name="assoAccounttype">
											<option value="" selected>Select Account</option>
											<?php 
											foreach($accountTypes as $value){
												echo '<option value="'.$value->id.'">'.$value->accountType.'</option>';
											}
											?>
											</select>
										</div>
									</div>
									
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account#</label>
											<input type="text" name="assoAccountNo" id="assoAccountNo" onkeyup="getAccountAssoc();" class="form-control input-sm" value="">
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account Name</label>
											<input type="text" name="assoAccountName" id="assoAccountName" onkeyup="getAccountAssoc();" class="form-control input-sm" value="">
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account Ref #</label>
											<input type="text" name="assoAccountRef" id="assoAccountRef" onkeyup="getAccountAssoc();" class="form-control input-sm" value="">
										</div>
									</div>	
									
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account Nickname</label>
											<input type="text" name="assoAccountNickname" id="assoAccountNickname" onkeyup="getAccountAssoc();" class="form-control input-sm" value="">
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>State</label>
											<input type="text" name="assoAccountState" id="assoAccountState" onkeyup="getAccountAssoc();" class="form-control input-sm" value="">
										</div>
									</div>
								</div>
								
								<div class="row" id="showhidetable2">								
									<div class="col-lg-12">
										<table id="example1" class="table table-bordered table-striped ">
											<thead>
												<tr>
													<th>#</th>
													<th>Account #</th>
													<th>Account Name</th>
													<th>Account Nickame</th>
													<th>Account Ref #</th>
													<th>Account Type</th>													
													<th>Address</th>
													<th>City</th>
													<th>State</th>
													<th>Status</th>
												</tr>
											</thead>
											<tbody id="accountAssociation">
												
											</tbody>
										</table>	
									</div>
								</div>								
							</div>
						</div>
					</div>					
				</div>
				
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>
								<button type="submit" class="btn btn-primary">Submit</button>
							</label>
							<label>
								<button type="reset" class="btn btn-danger">Cancel</button>
							</label>
						</div>
					</div>
				</div>
				
			</div>
			</form>
		</div>
		</div>
    </section>
    <!-- /.content -->
  </div>
<script >
function getStates(val){
	//alert(val);
	$.ajax({
		type: "GET",
		url: "<?php echo base_url();?>index.php/Location/getStateList/"+val,
		success: function(data){
			var obj = JSON.parse(data);
			$.each(obj.responseObject, function(i, p) {
				$('#state').append($('<option></option>').val(p.id).html(p.stateName));
			});
		}
	}); 
	$("#state").append('<option selected="selected" value="">Select State</option>');
}

function getCities(val){
	
	$.ajax({
		type: "GET",
		url: "<?php echo base_url();?>index.php/Location/getCityList/"+val,
		success: function(data){
			var obj = JSON.parse(data);
			$.each(obj.responseObject, function(i, p) {
				$('#city').append($('<option></option>').val(p.id).html(p.cityName));
			});
		}
	});
	$("#city").append('<option selected="selected" value="">Select City</option>');
}

function getAccountAssoc(){
	var account_assoc_list = [];
	var e = document.getElementById("assoAccounttype");
	var assoAccounttype = e.options[e.selectedIndex].value;
	//var assoAccounttype = document.getElementById("assoAccounttype").options[e.selectedIndex].value;
	var assoAccountNo = document.getElementById("assoAccountNo").value;
	var assoAccountName = document.getElementById("assoAccountName").value;
	var assoAccountRef = document.getElementById("assoAccountRef").value;
	var assoAccountNickname = document.getElementById("assoAccountNickname").value;
	var assoAccountState = document.getElementById("assoAccountState").value;
	//alert(assoAccountState);
	$.ajax({
		type: "POST",
		data:{assoAccounttype:assoAccounttype,assoAccountNo:assoAccountNo,assoAccountName:assoAccountName,assoAccountRef:assoAccountRef,assoAccountNickname:assoAccountNickname,assoAccountState:assoAccountState},
		url: "<?php echo base_url();?>index.php/Location/getAccountAssoc/",
		success: function(res){
			var obj = JSON.parse(res);
			console.log(res);
			
			$.each(obj.responseObject, function(i, p) {
				var newOption = '<tr><td align="center"><input type="checkbox" name="assoAcounts[]" value="'+p.accountId+'" /></td><td>'+p.accountId+'</td><td>'+p.companyName+'</td><td>'+p.nickName+'</td><td>'+p.referenceCode+'</td><td>'+p.accountTypeDetails.accountType+'</td><td>'+p.addressLine1+' '+p.addressLine2+'</td><td>'+p.cityDetails.cityName+'</td><td>'+p.stateDetails.stateName+'</td><td>'+p.accountStatusDetails.statusDesc+'</td></tr>';
				account_assoc_list.push(newOption);
			});			
			document.getElementById('accountAssociation').innerHTML = account_assoc_list;
		}
	});
}

function append_day() {

	var day = $('#selectday :selected').text();
	if(day !==''){
		var fromtime = $('#fromtime').val();
		var totime = $('#totime').val();
		
		weekdays = [ "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" ];
		
		if(day == 'All'){
			var i;
			for (i = 0; i < weekdays.length; i++) { 
				var text = '';
				var text = '<div class="parent"><div class="col-md-3 weekday"><input type="hidden" class="day" name="weekdays[]" value="'+weekdays[i]+'" />'+weekdays[i]+'</div><div class="col-md-3"><div class="input-group"><input type="time" name="fromtime_'+weekdays[i]+'" id="fromtime_'+weekdays[i]+'" value="'+fromtime+'" class="form-control"></div></div><div class="col-md-1">&nbsp;</div><div class="col-md-3"><div class="input-group"><input type="time" name="totime_'+weekdays[i]+'" id="totime_'+weekdays[i]+'" value="'+totime+'" class="form-control"></div></div><span class="child col-md-2"><button type="button" class="btn btn-danger btn-sm"><i class="glyphicon glyphicon-minus"></i></button></span></div>';
				$("#selectday option[value='"+weekdays[i]+"']").remove();
				$('#example').append(text);
			}
			$("#selectday option[value='All']").remove();
		}else{
			var text = '';
			text = '<div class="parent"><div class="col-md-3 weekday"><input type="hidden" class="day" name="weekdays[]" value="'+day+'" />'+day+'</div><div class="col-md-3"><div class="input-group"><input type="time" name="fromtime_'+day+'" id="fromtime_'+day+'" value="'+fromtime+'" class="form-control"></div></div><div class="col-md-1">&nbsp;</div><div class="col-md-3"><div class="input-group"><input type="time" name="totime_'+day+'" id="totime_'+day+'" value="'+totime+'" class="form-control"></div></div><span class="child col-md-2"><button type="button" class="btn btn-danger btn-sm"><i class="glyphicon glyphicon-minus"></i></button></span></div>';
			$("#selectday option[value='"+day+"']").remove();
			$('#example').append(text);
		}
	}
}

</script>