<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>EZR | Log in</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="icon" type="image/x-icon" href="favicon.ico">
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/plugins/iCheck/square/blue.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/dist/css/style.css">
  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <script src="<?php echo base_url(); ?>asset/bower_components/jquery/dist/jquery.min.js"></script>
  <script src="<?php echo base_url(); ?>asset/angular/angular.min.js"></script>
  <script src="<?php echo base_url(); ?>asset/angular/app.js"></script>
</head>
<body class="hold-transition login-page" ng-app="ezrOmsApp">
<div class="login-box" ng-controller="loginCtrl">
	<div class="login-logo">
		<span class="logo-lg"><img src="<?php echo base_url(); ?>asset/dist/img/logo-dashboard.png" class="logo-lg" style="width: 146px; margin: 5px;" alt="logo-lg"></span>
	</div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Sign in to start your session</p>

    <form autocomplete="off" novalidate name="loginForm" ng-submit="login()">
      <div class="form-group has-feedback">
        <input type="text" class="form-control" placeholder="Username" ng-model="loginData.userName" name="userName" required />
        <span class="glyphicon glyphicon-user form-control-feedback"></span>
		<div ng-if="(loginForm.userName.$dirty && loginForm.userName.$error.required) || (submitted && loginForm.userName.$error.required)" class="invalid-feedback">Username is required</div>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" placeholder="Password" ng-model="loginData.password" name="password" required />
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
		<div ng-if="(loginForm.password.$dirty && loginForm.password.$error.required) || (submitted && loginForm.password.$error.required)" class="invalid-feedback">Password is required</div>
      </div>
      <div class="row">
        <div class="col-xs-8">
          &nbsp;
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
        </div>
      </div>
	  <div class="row">
        <div class="col-xs-8">
          &nbsp;
        </div>
      </div>
    </form>

  </div>
  <div class="row">
    <div class="col-xs-12" style="padding: 20px; border-top: 0;">
      <div class="invalid-feedback">
        <label>{{errorMsg}} </label>
		<label><?php echo $message; ?></label>
      </div>
    </div>
  </div>
  <!-- /.login-box-body -->
</div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/login/loginCtrl.js"></script>
<script src="<?php echo base_url(); ?>asset/kendo/js/kendo.all.min.js"></script>
<script src="<?php echo base_url(); ?>asset/angular/angular-datatables.min.js"></script>
<script src="<?php echo base_url(); ?>asset/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>asset/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/angularjs-datepicker/2.1.23/angular-datepicker.js"></script>
</body>
</html>