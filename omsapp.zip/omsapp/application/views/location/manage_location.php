<div class="content-wrapper" ng-controller="viewAllLocations">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Locations</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li><a href="#">Locations</a></li>
        <li class="active">List of all Locations</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content form-page">
    	<div class="nav-tabs-custom">
    	<div class="pad20">
	      	<div class="row">
	        <div class="col-lg-12">
	          
	          <div class="box box-primary">
	            <div class="box-header with-border">
	            	<!-- <a href="create_location.html" class="pull-right btn btn-default">Create Location</a> -->
					<h3 class="box-title m10"><b>List of all Locations</b></h3>
				</div>
				
	            <!-- /.box-header -->
	            <div class="box-body">
					
					<div class="row">
						<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
							<div class="form-group">
								<label>Location Type</label>
								<select class="form-control input-md" ng-model="locationData.searchLocationType" ng-change="getLocationData()" id="locationType" name="locationType">
								<option selected="selected" value="">Select Location Type</option>
								<option ng-repeat='location in locationTypes' value="{{location.id}}">{{location.locationType}}</option>
								</select>
								
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
							<div class="form-group">
								<label>Location #</label>
								<input type="text" placeholder="Enter Location#" ng-model="locationData.searchLocationNo" ng-keyup="getLocationData()" name="searchLocationNo" id="searchLocationNo" class="form-control input-sm" value="">
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Status</label>
								<select class="form-control input-md" ng-model="locationData.searchLocationStatus" ng-change="getLocationData()" name="searchLocationStatus" id="searchLocationStatus" width="100%">
								<option selected="selected" value="">Select Location Status</option>
								<option ng-repeat="loc in allLocationStatus" value="{{loc.id}}">{{loc.statusDesc}}</option>
								</select>
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
							<div class="form-group">
								<label>&nbsp;</label><br/>
								<button type="button" class="btn btn-success" ng-click="showAdvanceSearch = !showAdvanceSearch">Advanced Search</button>
							</div>
						</div>
					</div>
						
					<div class="row" ng-if="showAdvanceSearch">
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Customer Ref #</label>
								<input type="text" placeholder="Enter Customer Ref #" ng-model="locationData.searchLocationRef" ng-keyup="getLocationData()" name="searchLocationRef" id="searchLocationRef" class="form-control input-sm" value="">
							</div>
						</div>
						
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Customer</label>
								<input type="text" placeholder="Enter Customer Name" ng-model="locationData.searchLocationName" ng-keyup="getLocationData()" name="searchLocationName" id="searchLocationName" class="form-control input-sm" value="">
							</div>
						</div>
						
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>City</label>
								<input type="text" placeholder="Enter City" ng-model="locationData.searchLocationCity" ng-keyup="getLocationData()" name="searchLocationCity" id="searchLocationCity" class="form-control input-sm" value="">
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>State</label>
								<input type="text" placeholder="Enter State" ng-model="locationData.searchLocationState" ng-keyup="getLocationData()" name="searchLocationState" id="searchLocationState" class="form-control input-sm" value="">
							</div>
						</div>
						
					</div>
					
					
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">&nbsp;</div>
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<table datatable="ng" dt-options="dtOptions" class="table table-striped table-bordered" width="100%">
								<thead>
									<tr>
										<th>Location#</th>
										<th>Location Type</th>
										<th>Customer Ref#</th>
										<th>Customer Name</th>
										<th>Unit#</th>
										<th>Nickname</th>
										<th>Address</th>
										<th>City</th>
										<th>State</th>
										<th>Status</th>
									</tr>
								</thead>
								<tbody>
								
									<tr ng-repeat="location in allLocationList">
									  <td><a href="<?php echo base_url(); ?>Location/view_location/{{ location.locationId }}">{{ location.locationId }}</a></td>
									  <td>{{ location.locationTypeDetails.locationType }}</td>
									  <td>{{ location.referenceCode }}</td>
									  <td>{{ location.locationName }}</td>
									  <td>{{ location.unitNumber }}</td>
									  <td>{{ location.nickName }}</td>
									  <td>{{ location.addressLine1 }} {{ location.addressLine2 }}</td>
									  <td>{{ location.cityDetails.cityName }}</td>
									  <td>{{ location.stateDetails.stateName }}</td>
									  <td>{{ location.statusDetails.statusDesc }} </td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
	            </div>
	            <!-- /.box-body -->
	          </div>
	          <!-- /.box -->
	        </div>
	        <!-- /.col -->
	      </div>
	    </div>
	    </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
<script>
/*
function getAllLocations(){
	
	var allLocationList = [];
	var e = document.getElementById("searchLocationType");
	var LocationType = e.options[e.selectedIndex].value;
	var LocationId = document.getElementById("searchLocationNo").value;
	var LocationRef = document.getElementById("searchLocationRef").value;
	var LocationName = document.getElementById("searchLocationName").value;
	//var LocationUnit = document.getElementById("assoAccountNickname").value;
	//var LocationNickName = document.getElementById("assoAccountState").value;
	var LocationStatus = document.getElementById("searchLocationStatus").value;
	var token = '<?php echo $_COOKIE["sessionId"];?>';
	//alert(assoAccountState);searchLocationStatus, searchLocationCity, searchLocationState
	document.getElementById('allLocations').innerHTML = '';
	$.ajax({
		type: "POST",
		data:{LocationType:LocationType,LocationId:LocationId,LocationRef:LocationRef,LocationName:LocationName,LocationStatus:LocationStatus,token:token},
		url: "<?php echo base_url();?>index.php/Location/getAllLocations/",
		success: function(res){
			//console.log(res);
			var obj = JSON.parse(res);
			console.log(res);
			
			$.each(obj.responseObject, function(i, p) {
				var newOption = '<tr><td><a href="<?php echo base_url();?>index.php/Location/getLocationById/'+p.locationId+'">'+p.locationId+'</a></td><td>'+p.locationTypeDetails.locationType+'</td><td>'+p.referenceCode+'</td><td>'+p.locationName+'</td><td>'+p.unitNumber+'</td><td>'+p.nickName+'</td><td>'+p.addressLine1+' '+p.addressLine2+'</td><td>'+p.cityDetails.cityName+'</td><td>'+p.stateDetails.stateName+'</td><td>'+p.statusDetails.statusDesc+'</td></tr>';
				allLocationList.push(newOption);
			});
			
			document.getElementById('allLocations').innerHTML = allLocationList.join("");
		}
	});
}

function filter_fields(){
	$('#customfields').toggle();
}*/
</script>
<script src="<?php echo base_url(); ?>asset/angular/controllers/locations/viewAllLocations.js"></script>