<div class="content-wrapper" ng-controller="editLocationCtrl">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Edit Location</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Location</a></li>
        <li class="active">Edit Location</li>
      </ol>
    </section>
    <section class="content form-page">
		<div class="box">
		<div class="box-body">
			<form autocomplete="off" novalidate name="locationForm" ng-submit="updateLocation()">
			<div class="padleftright20">
				<div class="accordion-option">
					<a href="javascript:void(0)" class="toggle-accordion active" accordion-id="#accordion"></a>
				</div>
				<div class="clearfix"></div>
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
								Location Details
								</a>
							</h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
							<div class="panel-body">
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Location Type <span class="asterisk">*</span></label>
											<input type="hidden" name="locationId" id="locationId" value="<?php echo $locationDetails["responseObject"]["locationId"]; ?>" />
											<input type="hidden" ng-model="locationData.locationNumber" name="locationNumber" id="locationNumber" />
											<select class="form-control" ng-model="locationData.locationType" required id="locationType" name="locationType" ng-options="value.id as value.locationType for (key, value) in locationTypes">
											</select>
											<div ng-if="submitted && locationForm.locationType.$invalid" class="invalid-feedback">
					                            <span ng-if="locationForm.locationType.$error.required">Location Type required. </span>
											</div>
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label>Ref#</label>
													<input type="text" name="referenceCode" id="referenceCode" ng-model="locationData.referenceCode" class="form-control" placeholder="Enter Ref#">
													<div ng-if="submitted && locationForm.referenceCode.$invalid" class="invalid-feedback">
							                            <span ng-if="locationForm.referenceCode.$error.pattern">Enter valid characters. </span>
													</div>
												</div>
											</div>
											
											<div class="col-md-6">
												<div class="form-group">
													<label>Unit Number</label>
													<input type="text" name="unitNumber" ng-model="locationData.unitNumber" id="unitNumber" class="form-control" placeholder="Enter Unit Number">
													<div ng-if="submitted && locationForm.unitNumber.$invalid" class="invalid-feedback">
							                            <span ng-if="locationForm.unitNumber.$error.pattern">Enter valid characters. </span>
													</div>
												</div>
											</div>
										</div>
									</div>
									
								</div>
								
								<div class="row">					
									<div class="col-md-6">
										<div class="form-group">
											<label>Location Name <span class="asterisk">*</span></label>
											<input type="text" name="locationName" id="locationName" class="form-control" placeholder="Enter Location Name" ng-model="locationData.locationName" required>
											<div ng-if="submitted && locationForm.locationName.$invalid" class="invalid-feedback">
					                            <span ng-if="locationForm.locationName.$error.required">Location Name required. </span>
											</div>
										</div>
									</div>					
								<!-- /.form-group -->
											
									<div class="col-md-6">
										<div class="form-group">
											<label>Location Nickname</label>
											<input type="text" name="nickName" ng-model="locationData.nickName" id="nickName" class="form-control" placeholder="Enter Location Nick Name">
											<div ng-if="submitted && locationForm.nickName.$invalid" class="invalid-feedback">
					                            <span ng-if="locationForm.nickName.$error.pattern">Enter valid characters. </span>
											</div>
										</div>
									</div>	
								</div>
								
								<div class="row">	
									<div class="col-md-6">
										<div class="form-group">
											<label>Address 1 <span class="asterisk">*</span></label>
											<input type="text" name="addressLine1" id="addressLine1" class="form-control" placeholder="Enter Address" ng-model="locationData.addressLine1" required>
											<div ng-if="submitted && locationForm.addressLine1.$invalid" class="invalid-feedback">
					                            <span ng-if="locationForm.addressLine1.$error.required">Address required. </span>
											</div>
										</div>
									</div>
								
									<div class="col-md-6">
										<div class="form-group">
											<label>Address 2</label>
											<input type="text" name="addressLine2" ng-model="locationData.addressLine2" id="addressLine2" class="form-control" placeholder="Enter Address">
											<div ng-if="submitted && locationForm.addressLine2.$invalid" class="invalid-feedback">
					                            <span ng-if="locationForm.addressLine2.$error.pattern">Enter valid characters. </span>
											</div>
										</div>
									</div>	
								</div>
								
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Zip Code <span class="asterisk">*</span></label>
											<input type="text" name="zipCode" id="zipCode" class="form-control" placeholder="Enter Zip Code" ng-model="locationData.zipCode" required pattern="^[0-9]{5,9}$">
											<div ng-if="submitted && locationForm.zipCode.$invalid" class="invalid-feedback">
					                            <span ng-if="locationForm.zipCode.$error.required">Zip Code required. </span>
					                            <span ng-if="locationForm.zipCode.$error.pattern">Enter digits only. </span>
											</div>
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="form-group">
											<label>Country <span class="asterisk">*</span></label>
											<select class="form-control" style="width: 100%;" ng-model="locationData.country" name="country" id="country" ng-change="getStates(locationData.country)" required ng-options="value.id as value.countryName for (key, value) in allCountries">
											</select>
											<div ng-if="submitted && locationForm.country.$invalid" class="invalid-feedback">
					                            <span ng-if="locationForm.country.$error.required">Country required. </span>
					                        </div>
										</div>
									</div>
									
								</div>
								
								<div class="row">										
									<div class="col-md-6">
										<div class="form-group">
											<label>State <span class="asterisk">*</span></label>
											<select class="form-control select2" ng-model="locationData.state" name="state" id="state" ng-change="getCities(locationData.state)" style="width: 100%;" required ng-options="value.id as value.stateName for (key, value) in allStates">
											</select>
											<div ng-if="submitted && locationForm.state.$invalid" class="invalid-feedback">
							                    <span ng-if="locationForm.state.$error.required">State required. </span>
							                </div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>City <span class="asterisk">*</span></label>
											<select class="form-control" ng-model="locationData.city" name="city" id="city" style="width: 100%;" ng-options="value.id as value.cityName for (key, value) in allCities">
												<option value="">select city</option>
											</select>
											<div ng-if="submitted && locationForm.city.$invalid" class="invalid-feedback">
							                    <span ng-if="locationForm.city.$error.required">City required. </span>
							                </div>
										</div>
									</div>	
								</div>
								
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Business Phone <span class="asterisk">*</span></label>
											<div class="input-group">
												<span class="input-group-addon">+1</span>
												<input type="text" name="businessPhone" required id="businessPhone" class="form-control" placeholder="Enter Business Phone Number" ng-model="locationData.businessPhone" required pattern="^[0-9]{10}$">
											</div>
											<div ng-if="submitted && locationForm.businessPhone.$invalid" class="invalid-feedback">
					                            <span ng-if="locationForm.businessPhone.$error.required">Enter Business Phone. </span>
					                            <span ng-if="locationForm.businessPhone.$error.pattern">Enter valid numbers. </span>
											</div>
										</div>						
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Fax</label>
											<div class="input-group">
												<span class="input-group-addon">+1</span>
												<input type="text" name="fax" ng-model="locationData.fax" id="fax" class="form-control" placeholder="Enter Fax" pattern="^[0-9]{10}$" />
											</div>
											<div ng-if="submitted && locationForm.fax.$invalid" class="invalid-feedback">
												<span ng-if="locationForm.fax.$error.pattern">Enter valid numbers. </span>
											</div>
										</div>
									</div>	
								<!-- /.form-group -->
								</div>
								
								<div class="row">					
									<div class="col-md-6" id="time-range">
										<div class="row">
											<div class="col-md-3"><label>Days Open</label></div>
											<div class="col-md-9" style="text-align: center;"><label><center>Operational hours</center></label></div>
										</div>
										<div class="row">
											<div class="col-md-3"><label>&nbsp;</label></div>
											<div class="col-md-9">
												<div class="col-md-7"><label>From Time</label></div>
												<div class="col-md-5"><label>To Time</label></div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-3">
												<select class="form-control" ts-select-fix ng-init="locationData.selectdayAccnts='Select Day'" ng-model="locationData.selectdayAccnts" id="selectdayAccnts" name="selectdayAccnts">
												<option ng-selected="true" disabled="true" value="Select Day">Select Day</option>
												<option ng-repeat="wday in weekdaysviews" value="{{wday}}">{{wday}}</option>
												</select>
											</div>
											<div class="col-md-3">
												<div class="input-group">
													<input type="time" ng-model="locationData.fromtimeAccnts" id="fromtimeAccnts" name="fromtimeAccnts" class="form-control" value="" />
												</div>
											</div>												
											<div class="col-md-1">&nbsp;</div>
											<div class="col-md-3">
												<div class="input-group">
													<input type="time" ng-model="locationData.totimeAccnts" name="totimeAccnts" id="totimeAccnts" class="form-control" value="" />
												</div>
											</div>
											<div class="col-md-2"><button type="button" ng-click="append_dayNg(locationData.selectdayAccnts, locationData.fromtimeAccnts, locationData.totimeAccnts)" class="btn btn-info btn-sm"><span class="glyphicon glyphicon-plus"></span></button></div>
										</div>
										<div ng-if="timeSelect" class="invalid-feedback">Please select day and time. </div>

										<div class="row" id="example">
										    <div class="" ng-repeat="opt in operationalHoursArr">
										        <div class="col-md-3 weekday">
										          <input type="text" readonly style="border: none;" ng-model="locationData.dayOpr[$index]" ng-init="locationData.dayOpr[$index] = opt.dayarray" class="day" />
										        </div>
										        <div class="col-md-3">
										          <div class="input-group">
										            <input type="time" ng-init="locationData.startTimeOpr[$index] = opt.fromtimearray" ng-model="locationData.startTimeOpr[$index]" class="form-control">
										          </div>
										        </div>
										        <div class="col-md-1">&nbsp;</div>
										        <div class="col-md-3">
										          <div class="input-group">
										            <input type="time" ng-init="locationData.endTimeOpr[$index] = opt.totimearray" ng-model="locationData.endTimeOpr[$index]" class="form-control">
										          </div>
										        </div>
										        <span class="col-md-2">
										          <button type="button" ng-click="deleteOperationalDayNg($index,opt.dayarray)" class="btn btn-danger btn-sm"><i class="glyphicon glyphicon-minus"></i></button>
										        </span>
										    </div>
										</div>


									</div>
									
									<div class="col-md-6">
										<div class="form-group">
											<label>Email <span class="asterisk">*</span></label>
											<input type="text" name="contactEmail" id="contactEmail" class="form-control" placeholder="Enter Email" ng-model="locationData.contactEmail" required />
											<div ng-if="submitted && locationForm.contactEmail.$invalid" class="invalid-feedback">
					                            <span ng-if="locationForm.contactEmail.$error.required">Email required. </span>
											</div>
										</div>
										
										<div class="form-group">
											<label>Contact Name <span class="asterisk">*</span></label>
											<input type="text" name="contactName" id="contactName" class="form-control" placeholder="Enter Contact Name" ng-model="locationData.contactName" required />
											<div ng-if="submitted && locationForm.contactName.$invalid" class="invalid-feedback">
					                            <span ng-if="locationForm.contactName.$error.required">Contact Name required. </span>
											</div>
										</div>
									
										<div class="form-group">
											<label>Contact Phone <span class="asterisk">*</span></label>
											<div class="input-group">
												<span class="input-group-addon">+1</span>
												<input type="text" name="contactPhone" required id="contactPhone" class="form-control" placeholder="Enter Contact Phone" ng-model="locationData.contactPhone" required />
											</div>
											<div ng-if="submitted && locationForm.contactPhone.$invalid" class="invalid-feedback">
					                            <span ng-if="locationForm.contactPhone.$error.required">Contact Phone required. </span>
											</div>
										</div>

										<div class="form-group">
											<label>Location Status </label>
											<select class="form-control" ng-model="locationData.locationStatus" id="locationStatus" name="locationStatus" ng-options="value.id as value.statusDesc for (key, value) in allLocationStatus">
												<option value="">select status</option>
											</select>
											<div ng-if="submitted && locationForm.locationStatus.$invalid" class="invalid-feedback">
					                            <span ng-if="locationForm.locationStatus.$error.required">Location Status required. </span>
											</div>
										</div>

									</div>
								</div>								
							</div>
						</div>
					</div>
						
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingTwo">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
								Associations
								</a>
							</h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
							<div class="panel-body">
								<div class="row">
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account Type</label>
											<select class="form-control input-md" width="100%" ng-change="getAllAccounts()" ng-model="locationData.accountType" name="accountType">
											<option value="" >Select Account Type</option>
											<option  ng-repeat="accountType in accountTypes" value="{{accountType.id}}">{{accountType.accountType}}</option>
											</select>
										</div>
									</div>
									
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account#</label>
											<input type="text" ng-model="locationData.accountId" ng-keyup="getAllAccounts()" id="accountId" name="accountId" class="form-control input-sm" value="">
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account Name</label>
											<input type="text" ng-model="locationData.accountName" ng-keyup="getAllAccounts()" id="accountName" name="accountName" class="form-control input-sm" value="">
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account Ref #</label>
											<input type="text" ng-model="locationData.accountRef" ng-keyup="getAllAccounts()" id="accountRef" name="accountRef" class="form-control input-sm" value="">
										</div>
									</div>	
									
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account Nickname</label>
											<input type="text" ng-model="locationData.accountNickName" ng-keyup="getAllAccounts()" id="accountNickName" name="accountNickName" class="form-control input-sm" value="">
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>State</label>
											<input type="text" ng-model="locationData.accountState" ng-keyup="getAllAccounts()" id="accountState" name="accountState" class="form-control input-sm" value="">
										</div>
									</div>
								</div>
								
								<div class="row" id="showhidetable2">								
									<div class="col-lg-12">
										<table datatable="ng" dt-options="accountOptions" class="table table-striped table-bordered" width="100%">
											<thead>
												<tr>
													<th></th>
													<th>Account #</th>
													<th>Account Name</th>
													<th>Account Nickame</th>
													<th>Account Ref #</th>
													<th>Account Type</th>
													<th>Address</th>
													<th>City</th>
													<th>State</th>
													<th>Status</th>
												</tr>
											</thead>
											<tbody>
												<tr ng-repeat="account in allAccountList">
													<td><input type="checkbox" ng-model="locationData.locationId[account.accountId]" name="locationId" id="locationId" />
													<input type="hidden" ng-model="locationData.locationIds[account.accountId]" ng-init="locationData.locationIds[account.accountId] = account.accountId" name="locationIds" id="locationIds" /></td>
													<td>{{account.accountId}}</td>
													<td>{{account.companyName}}</td>
													<td>{{account.nickName}}</td>
													<td>{{account.referenceCode}}</td>
													<td>{{account.accountTypeDetails.accountType}}</td>
													<td>{{account.addressLine1}} {{account.addressLine2}}</td>
													<td>{{account.cityDetails.cityName}}</td>
													<td>{{account.stateDetails.stateName}}</td>
													<td>{{account.accountStatusDetails.statusDesc}}</td>
												</tr>
											</tbody>
										</table>	
									</div>
								</div>								
							</div>
						</div>
					</div>					
				</div>
				
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>
								<button type="submit" class="btn btn-primary">Update</button>
							</label>
							<label>
								<button type="button" class="btn btn-danger">Cancel</button>
							</label>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-md-6">
						<div class="invalid-feedback">
							{{errorMsg}}
						</div>
					</div>
				</div>
				
			</div>
			</form>
		</div>
		</div>
    </section>
    <!-- /.content -->
  </div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/locations/editLocationCtrl.js"></script>