<div class="content-wrapper" ng-controller="editProductCtrl">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Edit Product</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Configuration Management</a></li>
        <li class="active">Edit Product</li>
      </ol>
    </section>
    <section class="content form-page">
    	
	<div class="box box-primary pad20">
		<form autocomplete="off" name="productForm" ng-submit="updateProduct()">
        <div class="box-body">
			
			<div class="row">
				<div class="col-lg-12 col-md-12">
					<div class="row">
						<div class="col-lg-4 col-md-4">
							<div class="form-group">
								<label>Product Number</label>
								<input type="hidden" name="productNumber" id="productNumber" value="<?php echo $productDetails["responseObject"]["productId"]; ?>" />
								<input type="text" readonly class="form-control input-sm" ng-hide="editorEnabled" ng-model="productData.productId" name="productId" id="productId" />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.productId }}</span>
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Account Name</label>
								<input type="hidden" ng-model="productData.accountNumber" name="accountNumber" />
								<input type="text" readonly class="form-control input-sm" ng-hide="editorEnabled" ng-model="productData.accountName" name="accountName" />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.accountName }}</span>
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>SKU Type</label>
								<input type="text" readonly class="form-control input-sm" ng-hide="editorEnabled" ng-model="productData.skuTypeText" name="skuTypeText" value="" />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.skuTypeText }}</span>
								<input type="hidden" readonly class="form-control input-sm" ng-model="productData.skuType" name="skuType" value="" />
							</div>
						</div>
					</div>
			
					<div class="row">	
						
						<div class="col-lg-4 col-md-4">
							<div class="form-group">
								<label>SKU Number</label>
								<input type="text" readonly placeholder="Enter SKU Number" ng-hide="editorEnabled" class="form-control input-sm" ng-model="productData.skuNumber" name="skuNumber" value="" required />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.skuNumber }}</span>
								<div ng-if="submitted && productForm.skuNumber.$error.required" class="invalid-feedback">Please enter sku number</div>
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>SKU Name</label>
								<input type="text" placeholder="Enter SKU Name" ng-hide="editorEnabled" class="form-control input-sm" ng-model="productData.skuName" name="skuName" value="" required />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.skuName }}</span>
								<div ng-if="submitted && productForm.skuName.$error.required" class="invalid-feedback">Please enter sku name</div>
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Description</label>
								<input type="text" placeholder="Enter SKU Description" ng-hide="editorEnabled" class="form-control input-sm" ng-model="productData.description" name="description" value="" required />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.description }}</span>
								<div ng-if="submitted && productForm.description.$error.required" class="invalid-feedback">Please enter description</div>
							</div>
						</div>
					</div>
					
					<div class="row">							
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Length</label>
								<input type="text" placeholder="Enter Length" ng-hide="editorEnabled" class="form-control input-sm" ng-model="productData.length" name="length" value="" required />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.length }}</span>
								<div ng-if="submitted && productForm.length.$error.required" class="invalid-feedback">Please enter length</div>
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Width</label>
								<input type="text" placeholder="Enter Width" ng-hide="editorEnabled" class="form-control input-sm" ng-model="productData.width" name="width" value="" required />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.width }}</span>
								<div ng-if="submitted && productForm.width.$error.required" class="invalid-feedback">Please enter width</div>
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Height</label>
								<input type="text" placeholder="Enter Height" ng-hide="editorEnabled" class="form-control input-sm" ng-model="productData.height" name="height" value="" required />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.height }}</span>
								<div ng-if="submitted && productForm.height.$error.required" class="invalid-feedback">Please enter height</div>
							</div>
						</div>
					</div>
					
					<div class="row" ng-show="showskulist">	
						<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
							<table class="table table-fixed ">
								<thead>
									<tr>
										<th class="col-xs-5 col-md-5 col-lg-5">{{ skuHeaderTitle }}</th>
										<th class="col-xs-2 col-md-2 col-lg-2">Quantity</th>
										<th class="col-xs-2 col-md-2 col-lg-2">Weight</th>
										<th class="col-xs-2 col-md-2 col-lg-2">Ext. Weight</th>
									</tr>
								</thead>
								<tbody class="tableheight">
									<tr ng-repeat="sku in allSKUBySkuType" ng-hide="!productData.qty[sku.productId] && editorEnabled">
										<td class="col-xs-5 col-md-5 col-lg-5">{{ sku.productDetails.description }}
										<input type="hidden" ng-model="productData.productNumber[sku.productId]" name="productNumber[sku.productId]" ng-init="productData.productNumber[sku.productId] = sku.productId" />
										<input type="hidden" ng-model="productData.id[sku.productId]" name="id[sku.productId]" ng-init="productData.id[sku.productId] = sku.id" />
										
										<input type="hidden" ng-model="productData.skuTypes[sku.productId]" name="skuTypes[sku.productId]" ng-init="productData.skuTypes[sku.productId] = sku.skuType" />
										<input type="hidden" ng-model="productData.skunumber[sku.productId]" name="skunumber[sku.productId]" ng-init="productData.skunumber[sku.productId] = sku.productDetails.skuNumber" /></td>
										
										<td class="col-xs-2 col-md-2 col-lg-2">
										<input type="text" style="width:50px;" ng-hide="editorEnabled" ng-keyup="calculateNetWeight(productData.qty[sku.productId],sku.weight)" ng-model="productData.qty[sku.productId]" ng-init="productData.qty[sku.productId]=sku.quantity" name="qty[sku.productId]" class="input-quantity" value="" />
										<span class="form-control-static" ng-show="editorEnabled">{{ productData.qty[sku.productId] }}</span>
										</td>
										
										<td class="col-xs-2 col-md-2 col-lg-2">{{sku.weight}}
										<input type="hidden" ng-model="productData.wgt[sku.productId]" name="wgt[sku.productId]" ng-init="productData.wgt[sku.productId] = sku.weight" />										
										</td>
										<td class="col-xs-2 col-md-2 col-lg-2">{{ +productData.qty[sku.productId] * sku.weight }}</td>
									</tr>									
								</tbody>
							</table>
							<div ng-if="submitted && !skuqty && productForm.skuTypeDrop != '1'" class="invalid-feedback">Enter quantity for at least one SKU</div>
						</div>
					</div>
					
					<div class="row">	
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Weight in lbs</label>
								<input type="text" ng-model="productData.weight" ng-hide="editorEnabled" name="weight" placeholder="Enter Weight in lbs" class="form-control input-sm" required />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.weight }}</span>
								<div ng-if="submitted && productForm.weight.$error.required" class="invalid-feedback">Please enter weight</div>
							</div>
						</div>				
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Quantity</label>
								<input type="text" placeholder="Enter Quantity" ng-hide="editorEnabled" readonly ng-init="productData.quantity = 1" ng-model="productData.quantity" name="quantity" class="form-control input-sm" value="" required />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.quantity }}</span>
								<div ng-if="submitted && productForm.quantity.$error.required" class="invalid-feedback">Please enter serial number</div>
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Sequence</label>
								<input type="text" placeholder="Enter Sequence" ng-hide="editorEnabled" ng-model="productData.sequence" name="sequence" class="form-control input-sm" value="" required />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.sequence }}</span>
								<div ng-if="submitted && productForm.sequence.$error.required" class="invalid-feedback">Please enter sequence number</div>
							</div>
						</div>						
					</div>
					
					<div class="row">	
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Show on Inventory Movement Page ?&nbsp;&nbsp;
								<span class="form-control-static" ng-show="editorEnabled"> : <span ng-if="productData.showInInventory">Yes</span><span ng-if="!productData.showInInventory">No</span></span>
								<input type="checkbox" ng-hide="editorEnabled" class="minimal" name="showInInventory" ng-model="productData.showInInventory"  /></label>
								
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							
							<div class="form-group">
								<label>Is Serialized ?&nbsp;&nbsp;
								<span class="form-control-static" ng-show="editorEnabled"> : <span ng-if="productData.isSerialized">Yes</span><span ng-if="!productData.isSerialized">No</span></span>
								<input type="checkbox" ng-hide="editorEnabled" class="minimal" name="isSerialized" ng-model="productData.isSerialized"  /></label>
								
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
							<div class="form-group">
								<label>
									<input type="button" class="btn btn-primary" ng-hide="editorEnabled" ng-click="productSummary()" value="Continue" />
									<input type="submit" class="btn btn-primary" ng-show="editorEnabled" value="Update" />
									<input type="button" class="btn btn-info" ng-show="editorEnabled" ng-click="showProductForm()" value="Edit" />
								</label>
								<label>
									<input type="reset" class="btn btn-danger" value="Cancel" />
								</label>
							</div>
						</div>
					</div>
					
				</div>
			</div>	
			
			<div class="row">
				<div class="col-md-12 invalid-feedback" ng-show="errorMsg.length>0">
					{{errorMsg}}
				</div>
			</div>
			
        </div>
		</form>
    </div>
    	
    </section>
    <!-- /.content -->
</div>
  
  <script src="<?php echo base_url(); ?>asset/angular/controllers/products/editProductCtrl.js"></script>