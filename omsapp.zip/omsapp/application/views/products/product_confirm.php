<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Product Confirmation</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Configuration Management</a></li>
        <li class="active">Product Confirmation</li>
      </ol>
    </section>
    <section class="content form-page">
    	
	<div class="box box-primary pad20">
       <!--  <div class="box-header with-border">
			<h3 class="box-title"><b>Ship From</b></h3>
        </div> -->
        <!-- /.box-header -->
        <div class="box-body">
			<div class="row proFormElement2">
				<div class="col-lg-12 col-md-12">
					<div class="row">
						<div class="col-lg-4 col-md-4">
							<div class="form-group">
							<?php //echo '<pre>'; print_r($productDetails); echo '</pre>';?>
								<label>Product ID</label> : <?php echo $productDetails["responseObject"]["productId"]; ?>
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Account #</label> : <?php echo $productDetails["responseObject"]["accountId"]; ?>
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Account Name</label>: <?php echo $productDetails["responseObject"]["accountInfo"]["companyName"]; ?>
							</div>
						</div>
					</div>
			
					<div class="row">	
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>SKU Type</label> : <?php echo $productDetails["responseObject"]["skuTypeDetails"]["skuType"]; ?>
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4">
							<div class="form-group">
								<label>SKU Number</label> : <?php echo $productDetails["responseObject"]["skuNumber"]; ?>
							</div>
						</div>

						<div class="col-lg-4 col-md-4">
							<div class="form-group">
								<label>SKU Name</label> : <?php echo $productDetails["responseObject"]["skuName"]; ?>
							</div>
						</div>
						
					</div>
			
					<div class="row">	
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Description</label> : <?php echo $productDetails["responseObject"]["description"]; ?>
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Length</label> : <?php echo $productDetails["responseObject"]["length"]; ?>
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Width</label> : <?php echo $productDetails["responseObject"]["width"]; ?>
							</div>
						</div>						
						
					</div>
					<?php if($productDetails["responseObject"]["skuType"] > 1){ ?>
					<div class="row">	
						<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
							<table class="table table-bordered ">
								<thead>
									<tr>
										<th>KIT/Component</th>
										<th>Quantity</th>
										<th>Weight</th>
										<th>Ext. Weight</th>
									</tr>
								</thead>
								<tbody>
								<?php foreach($productDetails["responseObject"]["subComponents"] as $value){ if($value["id"]!=NULL){?>
									<tr>
										<td><?php echo $value["productDetails"]["skuNumber"];?> </td>
										<td><?php echo $value["quantity"];?> </td>
										<td><?php echo intval($value["weight"]);?> </td>
										<td><?php echo intval($value["extWeight"]);?> </td>
									</tr>
								<?php }} ?>
								</tbody>
							</table>
						</div>
					</div>
					<?php } ?>
					<div class="row">	
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Height</label> : <?php echo $productDetails["responseObject"]["height"]; ?>
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Weight in lbs</label> : <?php echo $productDetails["responseObject"]["weight"]; ?>
							</div>
						</div>				
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Quantity</label> : <?php echo $productDetails["responseObject"]["quantity"]; ?>
							</div>
						</div>
					</div>
					
					<div class="row">		
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Sequence</label> : <?php echo $productDetails["responseObject"]["sequence"]; ?>
							</div>
						</div>
					</div>
					
				</div>
			</div>	
			
			
			
        </div>
    </div>
    	
    </section>
    <!-- /.content -->
  </div>