<div class="content-wrapper" ng-controller="viewAllProducts">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>View Products</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li><a href="#">Configuration Management</a></li>
        <li class="active">View Products</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          
          <div class="box">
			<!-- /.box-header -->
			
            <div class="box-body">
				<form autocomplete="off" novalidate name="viewAllProducts" >
				<div class="row">
					<div class="col-md-2">
						<div class="form-group">
							<label>Account #</label>
							<input type="text" placeholder="Enter Account #" ng-model="products.AccountId" id="AccountId" name="AccountId" ng-keyup="showAllProducts()" class="form-control input-sm" value="">
						</div>
					</div>
					
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Account Name</label>
							<input type="text" placeholder="Enter Account Name" ng-model="products.AccountName" name="AccountName" id="AccountName" ng-keyup="showAllProducts()" class="form-control input-sm" value="">
						</div>
					</div>
					
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>SKU Type</label>
							<select class="form-control input-md" ng-change="showAllProducts()" name="SKUType" id="SKUType" ng-model="products.SKUType" >
							<option value="" selected>Select SKU Type</option>
							<option  ng-repeat="skuType in allSKUTypes" value="{{skuType.id}}">{{skuType.skuType}}</option>
							</select>
						</div>
					</div>
					
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>SKU Number</label>
							<input type="text" placeholder="Enter SKU Number" name="SKUNumber" id="SKUNumber" ng-model="products.SKUNumber" class="form-control input-sm" ng-keyup="showAllProducts()" value="" />
						</div>
					</div>					
				</div>
				</form>
				<div class="row showDataGrid">
					<div class="col-lg-12 col-md-12">
					  <table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
							  <th>SKU #</th>
							  <th>SKU Type</th>
							  <th>Name</th>
							  <th>Sequence</th>
							  <th>Account #</th>
							  <th>Account Name</th>
							  <th>Status</th>
							</tr>
						</thead>
						<tbody>
							<tr ng-repeat="product in allProductList">
							  <td><a href="<?php echo base_url(); ?>Products/view_product/{{product.productId}}">{{product.skuNumber}}</a></td>
							  <td>{{product.skuTypeDetails.skuType}}</td>
							  <td>{{product.skuName}}</td>
							  <td>{{product.sequence}}</td>
							  <td>{{product.accountId}}</td>
							  <td>{{product.skuNumber}}</td>							  
							  <td>{{product.skuNumber}}</td>
							</tr>
						  </tbody>
						</table>
					</div>
				</div>
              
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/products/viewAllProducts.js"></script>