<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Manage Price List</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li><a href="#">Price Setting</a></li>
        <li class="active">Manage Price List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content dashboard">
      <div class="row">
        <div class="col-xs-12">
          
          <div class="box">
            <div class="box-body PB20">
      				<div class="row">
          			<div class="col-md-12">
                  
					  <div class="row">
						  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<p>&nbsp;</p>
						  </div>
						</div>
					<div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                      
					  
					  
					  <div class="flat">
                        
                        <table class="display table table-bordered table-striped dataTable" width="100%">
                          <thead>
                            <tr>
                              <th width="30"></th>
                              <th width="125">Customer/Provider</th>
							  <th width="125">Price List Type</th>
							  <th width="125">Cluster</th>							  
							  <th width="125">Price List Code</th>
                              <th width="125">Price List</th>
                              <th width="120">Valid From</th>
                              <th width="120">Valid To</th>
                              <th width="120">Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td><input type="checkbox" /></td>
                              <td width="125">Customer1</td>
							  <td width="125">Flat Pricing</td>
							  <td width="125">Cluster 1</td>
							  <td width="100">PL001</td>
                              <td width="120">Price1</td>
                              <td width="120">02/08/2019</td>
                              <td width="120">03/08/2019</td>
                              <td><a href="manage_price.html" class="btn btn-primary btn-sm">Manage Price List</a></td>
                            </tr>
                            <tr>
                              <td><input type="checkbox" /></td>
                              <td>Provider1</td>
							  <td>Per unit</td>
							  <td>Cluster 2</td>
							  <td>PL002</td>
                              <td>Price2</td>
                              <td>02/08/2019</td>
                              <td>03/08/2019</td>
                              <td><a href="manage_price_pro.html" class="btn btn-primary btn-sm">Manage Price List</a></td>
                            </tr>
                            <tr>
                              <td><input type="checkbox" /></td>
							  <td>Customer3</td>
							  <td>Flat Pricing</td>
							  <td>Cluster 3</td>
                              <td>PL003</td>
                              <td>Price3</td>
                              <td>02/08/2019</td>
                              <td>03/08/2019</td>
                              <td><a href="manage_price.html" class="btn btn-primary btn-sm">Manage Price List</a></td>
                            </tr>
                          </tbody>
                        </table>
                        
                      </div>
					  
                    </div>
                  </div>                  

          			</div>
              <!-- /.col -->
            </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>