  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Create Price List</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li><a href="#">Price Setting</a></li>
        <li class="active">Create Price List</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content dashboard">
      <div class="row">
        <div class="col-xs-12">
          
          <div class="box">
            <div class="box-header">
              <h3>Create Price List</h3>
            </div>      
            <!-- /.box-header -->			
            <div class="box-body pad20">
      				<div class="row">
          			<div class="col-md-12">
                  <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                      <div class="form-group">
                        <label>Account Type</label>
                        <select class="form-control" id="accountType" name="accountType" onchange="getCusPro(this.value)">
                          <option selected value="Customer">Customer</option>
                          <option value="Provider">Provider</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						<div class="form-group" id="Customer">
							<label>Customer:</label>
							<select class="form-control">
							<option value="MM">Mercury Marine</option>
							<option value="TK">Thermo King</option>
							</select>
						</div>
						<div class="form-group" id="Provider">
							<label>Provider:</label>
							<select class="form-control multiselect-ui" multiple>
							<option value="Provider1">Provider 1</option>
							<option value="Provider2">Provider 2</option>"
							</select>
						</div>
                    </div>
                  </div>
				  
                  <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                      <div class="form-group">
                        <label>Pricing Type</label>
                        <select class="form-control" name="privileges" id="privileges">
                          <option value="">Select</option>
                          <option selected="selected" value="Flat Pricing">Flat Pricing</option>
                          <option value="PerUnit">Per Unit</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                      <div class="form-group">
                        <label>Price List Name</label>
                        <input type="text" class="form-control" value="">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                      <div class="form-group">
                        <label>Valid From</label>
                        <div class="input-group date">
                          <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
                          <input type="text" class="form-control pull-right datepicker" value="" id="datefrom">
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                      <div class="form-group">
                        <label>Valid To</label>
                        <div class="input-group date">
                          <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
                          <input type="text" class="form-control pull-right datepicker" value="" id="datefrom">
                        </div>
                      </div>
                    </div>
                  </div>
				  
				  <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                      <div class="form-group">
                        <label>Cluster</label>
                        <select class="form-control multiselect-ui" multiple>
                          <option value="Location 1">Cluster 1</option>
                          <option value="Location 2">Cluster 2</option>
						  <option value="Location 3">Cluster 3</option>
						  <option value="Location 4">Cluster 4</option>
                        </select>
                      </div>
                    </div>
                  </div>
				  
                  <div class="borderRound">
					<div class="row">
                      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <h3><span>Mix-Min Pricing</span></h3>
                        <p>&nbsp;</p>
                      </div>
                    </div>
					
					<div class="row sku1">
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <label>Mix-Min Price</label>
                        </div>
                      </div>
                      
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <input type="text" class="form-control" value="">
                        </div>
                      </div>
                      
                    </div>
					
				  </div>
				  
                  <div class="borderRound flatPricing">
                    <div class="row">
                      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <h3><span>Components Pricing</span></h3>
                        <p>&nbsp;</p>
                      </div>
                    </div>
                    <div class="row sku1">
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <label>SKU1</label>
                        </div>
                      </div>
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="Min Qty.">
                        </div>
                      </div>
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="Max Qty.">
                        </div>
                      </div>
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="$">
                        </div>
                      </div>
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="show-sku1">
                          <span class="btn btn-primary">Add Slab<span>
                        </div>
                      </div>
                    </div>
                    <div class="row sku2">
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <label>SKU2</label>
                        </div>
                      </div>
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="Min Qty.">
                        </div>
                      </div>
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="Max Qty.">
                        </div>
                      </div>
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="$">
                        </div>
                      </div>
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="show-sku2">
                          <span class="btn btn-primary">Add Slab<span>
                        </div>
                      </div>
                    </div>
                    <div class="row sku3">
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <label>SKU3</label>
                        </div>
                      </div>
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="Min Qty.">
                        </div>
                      </div>
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="Max Qty.">
                        </div>
                      </div>
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="$">
                        </div>
                      </div>
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="show-sku3">
                          <span class="btn btn-primary">Add Slab<span>
                        </div>
                      </div>
                    </div>
                  </div>
				  
				  <div class="borderRound perUnitPricing">
                    <div class="row">
                      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <h3><span>Components Pricing</span></h3>
                        <p>&nbsp;</p>
                      </div>
                    </div>
                    <div class="row sku1">
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <label>SKU1</label>
                        </div>
                      </div>
                      
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="Qty.">
                        </div>
                      </div>
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="$">
                        </div>
                      </div>                      
                    </div>
					
                    <div class="row sku2">
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <label>SKU2</label>
                        </div>
                      </div>
                      
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="Qty.">
                        </div>
                      </div>
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="$">
                        </div>
                      </div>
                      
                    </div>
                    <div class="row sku3">
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <label>SKU3</label>
                        </div>
                      </div>
                      
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="Qty.">
                        </div>
                      </div>
                      <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <input type="text" class="form-control" placeholder="$">
                        </div>
                      </div>
                      
                    </div>
                  </div>
				  
				  <div class="row">
					  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div>
						  <h3>Additional Charges</h3>
						  <hr />
						  <div class="row additional-row">
							<div class="col-lg-12 col-md-12">
							  <div class="form-group">
								<div class="row">
								  <div class="col-lg-1 col-md-1 text-right"><input type="checkbox" onclick="myFunction()"></div>
								  <div class="col-lg-2 col-md-2">Fuel Surcharges&nbsp;<a href="#" data-toggle="modal" data-target="#modalFuelSurcharges">(<i>&nbsp;i&nbsp;</i>)</a></div>
								  <div class="col-lg-3 col-md-3"><input type="text" class="form-control" readonly placeholder="Price" id="myCheck" value="3.01"></div>
								  <div class="col-lg-1 col-md-1 text-right"><input type="checkbox" onclick="myFunction2()"></div>
								  <div class="col-lg-2 col-md-2">Quality Inspection</div>
								  <div class="col-lg-3 col-md-3"><input type="text" class="form-control" placeholder="Price" id="myCheck2" ></div>
								</div>
							  </div>
							  <div class="form-group">
								<div class="row">
								  <div class="col-lg-1 col-md-1 text-right"><input type="checkbox" onclick="myFunction3()"></div>
								  <div class="col-lg-2 col-md-2">Packaging</div>
								  <div class="col-lg-3 col-md-3"><input type="text" class="form-control" placeholder="Price" id="myCheck3" ></div>
								  <div class="col-lg-1 col-md-1 text-right"><input type="checkbox" onclick="myFunction4()"></div>
								  <div class="col-lg-2 col-md-2">Cleaning</div>
								  <div class="col-lg-3 col-md-3"><input type="text" class="form-control" placeholder="Price" id="myCheck4" ></div>
								</div>
							  </div>
							  <div class="form-group">
								<div class="row">
								  <div class="col-lg-1 col-md-1 text-right"><input type="checkbox" onclick="myFunction5()"></div>
								  <div class="col-lg-2 col-md-2">Inventory Assesment</div>
								  <div class="col-lg-3 col-md-3"><input type="text" class="form-control" placeholder="Price" id="myCheck5" ></div>
								  <div class="col-lg-1 col-md-1 text-right"><input type="checkbox" onclick="myFunction6()"></div>
								  <div class="col-lg-2 col-md-2">Dealer Communication</div>
								  <div class="col-lg-3 col-md-3"><input type="text" class="form-control" placeholder="Price" id="myCheck6" ></div>
								</div>
							  </div>
							</div>
						  </div>						  
						</div>
					  </div>
					</div>
				  
                  <div class="borderRound">
                    <div class="row">
                      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <h3 class="with-border"><span>Price List Description</span></h3>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                          <textarea class="form-control"></textarea>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                      <p>&nbsp;</p>
                      <div class="input-group">
                          <a class="btn btn-primary">Submit</a> &nbsp;
                          <a class="btn btn-danger">Cancel</a>
                        </div>
                        <p>&nbsp;</p>
                    </div>
                  </div>
                  

          			</div>
              <!-- /.col -->
            </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>