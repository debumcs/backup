<div class="content-wrapper" ng-controller="sentToLocationCtrl">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Sent To Location</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Inventory Management</a></li>
        <li class="active">Sent To Location</li>
      </ol>
    </section>
    <section class="content form-page">
    	
		<div class="box box-primary pad20">
        <div class="box-header with-border classBoxTitle" >
			<h3 class="box-title" id="shipFrom"><b>Ship From</b></h3>
        </div>
        <!-- /.box-header -->
		<form autocomplete="off" novalidate name="sentToLocForm" ng-submit="createSentToInventory()" >
        <div class="box-body">			
			<div class="row" ng-hide="IsSuccessHide">
				<div class="col-md-2">
					<div class="form-group">
						<label>Account Type</label>
						<select class="form-control input-md" width="100%" id="accounttype" ng-model="sentToLocData.accountType" ng-change="getAllAccounts()" name="accounttype" >
							<option value="" selected>Select Account Type</option>
							<option ng-repeat="accountType in accountTypes" value="{{accountType.id}}">{{accountType.accountType}}</option>
						</select>
					</div>
				</div>
				
				<div class="col-md-2">
					<div class="form-group">
						<label>Location Type</label>
						<select class="form-control input-md" width="100%" ng-model="sentToLocData.locationType" id="locationType" name="locationType" ng-change="getAllAccounts()">
							<option value="" selected>Select Location</option>
							<option ng-repeat="loc in locationTypes" value="{{loc.id}}">{{loc.locationType}}</option>					
						</select>
					</div>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
					<div class="form-group">
						<label>Customer Name</label>
						<input type="text" placeholder="Enter Account Name" autocomplete="off" ng-model="sentToLocData.customerName" id="customerName" name="customerName" ng-keyup="getAllAccounts()" class="form-control input-sm" value="">
					</div>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
					<div class="form-group">
						<label>Customer#</label>
						<input type="text" placeholder="Enter Account#" autocomplete="off" ng-model="sentToLocData.customerNumber" id="customerNumber" name="customerNumber" ng-keyup="getAllAccounts()" class="form-control input-sm" value="">
					</div>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
					<div class="form-group">
						<label>Location Name</label>
						<input type="text" placeholder="Enter Locatoin Name" autocomplete="off" ng-model="sentToLocData.locationName" id="locationName" name="locationName" ng-keyup="getAllAccounts()" class="form-control input-sm" value="">
					</div>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
					<div class="form-group">
						<label>Location#</label>
						<input type="text" placeholder="Enter Location#" autocomplete="off" ng-model="sentToLocData.locationNumber" id="locationNumber" name="locationNumber" ng-keyup="getAllAccounts()" class="form-control input-sm" value="">
					</div>
				</div>
				
			</div>
			
			<div class="row" ng-hide="IsSuccessHide">
				<div class="col-lg-12">
					<table datatable="ng" width="100%" dt-options="accountOptions" id="maxheight" class="table table-striped table-bordered">
						<thead>
							<tr>
								<th align="center"></th>
								<th>Account Name</th>
								<th>Location Type</th>
								<th>Customer</th>
								<th>Customer#</th>
								<th>Customer Nickname</th>
								<th>Customer Ref#</th>
								<th>City</th>
								<th>State</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
							<tr ng-repeat="account in allAccountList">
								<td align="center">
									<input type="radio" ng-click="selectAccountLocation(account);" name="locationId" value="{{account}}" />
								</td>
								<td><a href="#" data-toggle="modal" data-target="#myAccount" title="{{account.accountDetails.accountId}}">{{account.accountDetails.companyName}}</a></td>
								<td>{{account.locationDetails.locationTypeDetails.locationType}}</td>
								<td>{{account.locationDetails.locationName}}</td>
								<td>{{account.locationDetails.locationId}}</td>
								<td>{{account.locationDetails.nickName}}</td>
								<td>{{account.locationDetails.referenceCode}}</td>
								<td>{{account.locationDetails.cityDetails.cityName}}</td>
								<td>{{account.locationDetails.stateDetails.stateName}}</td>
								<td>{{account.locationDetails.statusDetails.statusDesc}}</td>
							</tr>
						</tbody>
					</table>					
				</div>
			</div>
			
			<div class="row">&nbsp;&nbsp;</div>
			
			<div class="row" ng-show="IsLocationDetailsVisible">
				<div class="col-md-12 col-lg-12">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Account Name</b></label> : {{ selectedAccount.accountDetails.companyName }}
								<input type="hidden" ng-model="sentToLocData.shipFromAssociationId" name="shipFromAssociationId" />
								<input type="hidden" ng-model="sentToLocData.shipFromAccountId" name="shipFromAccountId" />
								<input type="hidden" ng-model="sentToLocData.shipFromLocationId" name="shipFromLocationId" />
							</div>
						</div>					
								
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Location Type</b></label> : {{ selectedAccount.locationDetails.locationTypeDetails.locationType }}
							</div>
						</div>
						
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Customer</b></label> : {{ selectedAccount.locationDetails.locationName }}
							</div>
						</div>
						
					</div>
				</div>
				
				<div class="col-md-12 col-lg-12">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Customer#</b></label> : {{ selectedAccount.locationDetails.locationId }}
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Customer Nickname</b></label> : {{ selectedAccount.locationDetails.nickName }}
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Customer Ref#</b></label> : {{ selectedAccount.locationDetails.referenceCode }}
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-12 col-lg-12">
					<div class="row">
						<div class="col-md-8">
							<div class="form-group">
								<label><b>Address</b></label> : {{ selectedAccount.locationDetails.addressLine1 }} {{ selectedAccount.locationDetails.addressLine2 }} {{ selectedAccount.locationDetails.cityDetails.cityName }} {{ selectedAccount.locationDetails.stateDetails.stateName }}
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="box-header with-border" ng-show="showShipToList">
				<h3 class="box-title" id="shipTo"><b>Ship To</b></h3>
				<!--<h4 ng-repeat="skuheader in selectedAccount.accountDetails.products">{{skuheader.skuNumber}}</h4>-->
			</div>
			<div class="row" ng-show="showShipToList">				
				<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
					<div class="form-group">
						<label>Company Name:</label>
						<div class="input-group">
							<input type="text" placeholder="Enter Company Name" ng-keyup="getShipTo()" ng-model="sentToLocData.accountName" name="accountName" id="accountName" class="form-control" />
						</div>
					</div>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
					<div class="form-group">
						<label>Ref Code:</label>
						<div class="input-group">
							<input type="text" placeholder="Enter Ref Code" ng-keyup="getShipTo()" ng-model="sentToLocData.refcode" name="refcode" id="refcode" class="form-control" />
						</div>
					</div>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
					<div class="form-group">
						<label>Nickname:</label>
						<div class="input-group">
							<input type="text" placeholder="Enter Nickname" ng-keyup="getShipTo()" ng-model="sentToLocData.nickname" name="nickname" id="nickname" class="form-control" />
						</div>
					</div>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
					<div class="form-group">
						<label>State:</label>
						<div class="input-group">
							<input type="text" placeholder="Enter State" class="form-control" ng-keyup="getShipTo()" ng-model="sentToLocData.state" name="state" id="state" />
						</div>
					</div>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
					&nbsp;
				</div>
				
			</div>
			
			<div class="row" ng-show="showShipToList">
				<div class="col-lg-12">
					<div class="">
					<!--<table datatable="ng" width="100%" dt-options="dealerOptions" class="table table-striped table-bordered">-->
					<table width="100%" class="table table-striped table-bordered " id="sentToLocTable">
						<thead>
							<tr>								
								<th>Dealership<input type="hidden" ng-model="sentToLocData.headDealership" name="headDealership" ng-init="sentToLocData.headDealership='Dealership'" />
								
								</th>
								<th>Name<input type="hidden" ng-model="sentToLocData.headLocName" name="headLocName" ng-init="sentToLocData.headLocName='Name'" /></th>
								<th>Store #<input type="hidden" ng-model="sentToLocData.headStore" name="headStore" ng-init="sentToLocData.headStore='Store'" /></th>
								<th>Ref #<input type="hidden" ng-model="sentToLocData.headRef" name="headRef"  ng-init="sentToLocData.headRef='Ref'" /></th>
								<th>Nickname<input type="hidden" ng-model="sentToLocData.headNickname" name="headNickname" ng-init="sentToLocData.headNickname='Nickname'" /></th>
								<th>City<input type="hidden" ng-model="sentToLocData.headCity" name="headCity" ng-init="sentToLocData.headCity='City'" /></th>
								<th>State<input type="hidden" ng-model="sentToLocData.headState" name="headState" ng-init="sentToLocData.headState='State'" /></th>
								<th ng-repeat="skuheader in selectedAccount.accountDetails.products">{{skuheader.skuNumber}}
								
								<input type="hidden" ng-model="sentToLocObject.headSkuNumber[skuheader.skuNumber]" name="headSkuNumber" ng-init="sentToLocObject.headSkuNumber[skuheader.skuNumber]=skuheader.skuNumber" />
								
								</th>
								<th>Ship Date<input type="hidden" ng-model="sentToLocData.headShipDate" name="headShipDate" ng-init="sentToLocData.headShipDate='Ship Date'" /></th>
							</tr>
						</thead>
						<tbody>
							<tr ng-repeat="shipTo in allShipToList">								
								<td>{{shipTo.accountDetails.companyName}}
								<input type="hidden" ng-model="sentToLocObject.shipToAccountId[shipTo.accountId]" name="shipToAccountId_{{shipTo.accountId}}" ng-init="sentToLocObject.shipToAccountId[shipTo.accountId]=shipTo.accountId" />								
								<input type="hidden" ng-model="sentToLocObject.shipToAssociationId[shipTo.accountId]" name="shipToAssociationId_{{shipTo.accountId}}" ng-init="sentToLocObject.shipToAssociationId[shipTo.accountId]=shipTo.associationId" />								
								<input type="hidden" ng-model="sentToLocObject.shipToLocationId[shipTo.accountId]" name="shipToLocationId_{{shipTo.accountId}}" ng-init="sentToLocObject.shipToLocationId[shipTo.accountId]=shipTo.locationId" />								
								<input type="hidden" ng-model="sentToLocObject.companyName[shipTo.accountId]" name="companyName_{{shipTo.accountId}}" ng-init="sentToLocObject.companyName[shipTo.accountId]=shipTo.accountDetails.companyName" />
								</td>
								<td>{{shipTo.locationDetails.locationName}}
								<input type="hidden" ng-model="sentToLocObject.shipToLocationName[shipTo.accountId]" name="locationName_{{shipTo.accountId}}" ng-init="sentToLocObject.shipToLocationName[shipTo.accountId]=shipTo.locationDetails.locationName" />
								</td>
								<td>{{shipTo.locationDetails.unitNumber}}
								<input type="hidden" ng-model="sentToLocObject.unitNumber[shipTo.accountId]" name="unitNumber_{{shipTo.accountId}}" ng-init="sentToLocObject.unitNumber[shipTo.accountId]=shipTo.locationDetails.unitNumber" />
								</td>
								<td>{{shipTo.locationDetails.referenceCode}}
								<input type="hidden" ng-model="sentToLocObject.referenceCode[shipTo.accountId]" name="referenceCode_{{shipTo.accountId}}" ng-init="sentToLocObject.referenceCode[shipTo.accountId]=shipTo.locationDetails.referenceCode" />
								</td>
								<td>{{shipTo.locationDetails.nickName}}
								<input type="hidden" ng-model="sentToLocObject.nickName[shipTo.accountId]" name="nickName_{{shipTo.accountId}}" ng-init="sentToLocObject.nickName[shipTo.accountId]=shipTo.locationDetails.nickName" />
								</td>
								<td>{{shipTo.locationDetails.cityDetails.cityName}}
								<input type="hidden" ng-model="sentToLocObject.cityName[shipTo.accountId]" name="cityName_{{shipTo.accountId}}" ng-init="sentToLocObject.cityName[shipTo.accountId]=shipTo.locationDetails.cityDetails.cityName" />
								</td>
								<td>{{shipTo.locationDetails.stateDetails.stateName}}
								<input type="hidden" ng-model="sentToLocObject.stateName[shipTo.accountId]" name="stateName_{{shipTo.accountId}}" ng-init="sentToLocObject.stateName[shipTo.accountId]=shipTo.locationDetails.stateDetails.stateName" />
								</td>
								<td ng-repeat="sku in selectedAccount.accountDetails.products">
								
								<input only-numbers type="text" class="form-control input-sm" ng-model="sentToLocObject.skuNumber[shipTo.accountId][sku.skuNumber]" name="sku_{{shipTo.accountId}}_{{sku.skuNumber}}" id="sku_{{shipTo.accountId}}_{{sku.skuNumber}}" style="width:70px;" value="" />
								<span ng-if="sku.isSerialized && sentToLocObject.skuNumber[shipTo.accountId][sku.skuNumber] > 0"></span>								
								<div class="show-popup serialNumberBox{{sku.skuNumber}}" ng-if="sku.isSerialized && sentToLocObject.skuNumber[shipTo.accountId][sku.skuNumber] > 0">
									<div class="closebtn col-md-6">Serial#</div>
									<!--<div class="closebtn col-md-6">Close</div>-->
									<div ng-repeat="n in getNumber(sentToLocObject.skuNumber[shipTo.accountId][sku.skuNumber])" class="input-row"><input type="text" class="form-control input-sm" name="serialNumber{{n}}" ng-model="sentToLocObject.serialNumber[shipTo.accountId][sku.skuNumber][n]" style="width:100px; margin-top:3px;" /></div>
								</div>
								
								</td>
								<td>
									<datepicker date-format="MM/dd/yyyy">
									<input type="text" ng-model="sentToLocObject.shipDate[shipTo.accountId]" name="shipDate_{{shipTo.accountId}}" placeholder="Click here to select date" class="form-control" />
									</datepicker>
								</td>
							</tr>						
							
						</tbody>
					</table></div>			
				</div>
				
				
				<!--<div class="col-lg-12" id="addedDestinationmmdiv">
					<div class="row">
						<div class="col-lg-12" id=""><h4><b>Ship in Process</b></h4></div>
					</div>
					<table class="table table-bordered table-striped dataTable">
						<thead>
							<tr>
								<th>Dealership</th>
								<th>Name</th>
								<th>Store #</th>
								<th>Ref #</th>
								<th>Nickname</th>
								<th>City</th>
								<th>State</th>
								<th>BLU</th>
								<th>BLK</th>
								<th>MCM</th>
								<th>BRIZO</th>
								<th>Ship Date</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody class="addedDestinationmm">
							
						</tbody>
					</table>					
				</div>-->
				
				<div class="col-lg-12" ng-if="errorMsg">
					<div class="row">
						<div class="col-lg-12" id=""><h4 class="invalid-feedback"><b>{{ errorMsg }}</b></h4></div>
					</div>										
				</div>
				
				<div class="col-lg-12">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>
									<!--<input type="button" class="btn btn-primary" ng-hide="editorEnabled" ng-click="accountSummary()" value="Continue" />-->
									<input type="submit" class="btn btn-primary" value="Submit" />
									<!--<input type="button" class="btn btn-info" ng-show="editorEnabled" ng-click="accountCreateForm()" value="Edit" />-->
								</label>
								<label>
									<input type="button" ng-click="reset()" class="btn btn-danger" value="Cancel" />
								</label>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			
			<div ng-show="IsSuccessHide">
				<div class="box-header with-border">
					<h3 class="box-title" id="shipTo"><b>Ship To</b></h3>
				</div>
				
				<div class="row">
					<div class="col-lg-12">
						<table width="100%" class="table table-striped table-bordered ">
							<tr ng-repeat="row in successData">
								<td ng-repeat="col in row track by $index">{{ col }}</td>
							</tr>
						</table>
					</div>				
				</div>
				
				<div class="box-header with-border">
					<h3 class="box-title"><b>Data inserted successfully.</b></h3>
				</div>
				
			</div>
			
			
        </div>
		</form>
    </div>
    	
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 0.0
    </div>
    <strong>&nbsp;Copyright &copy; 2018, Powered by <a href="https://www.advatix.com/" target="_blank">&nbsp;Advatix</a></strong>
  </footer>

  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/inventoryMovement/sentToLocationCtrl.js"></script>