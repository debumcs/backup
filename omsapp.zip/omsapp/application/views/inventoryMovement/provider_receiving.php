<div class="content-wrapper" ng-controller="viewAllOrders">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Provider</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li><a href="#">Inventory Management</a></li>
        
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          
          <div class="box">
            <div class="box-header with-border">
				<!--<a href="createorder.html" class="pull-right btn btn-default">Create Order</a>-->
				<h3 class="box-title m10"><b>List of all Provider</b></h3>
			</div>
			
            <!-- /.box-header -->
			<form autocomplete="off" name="viewAllOrders">
            <div class="box-body">
				<div class="row">
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Order Type</label><!-- onchange="redirectPage(this.value);" -->
							<select class="form-control input-md"  width="100%" name="OrderType" id="OrderType" required>
                                <option value="#">Asset Collection</option>
								<option value="#">Outbound</option>
							</select>
						</div>
					</div>
					
					<div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Provider Location</label>
							<input type="text" name="provider_location" id="provider_location" class="form-control input-sm" value="" placeholder="Enter Provider Location">
						</div>
					</div>
					
										
					<div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Provider Name</label>
						<input type="text" name="provider_name" id="provider_name" class="form-control input-sm" value="" placeholder="Enter Provider Name">
						</div>
					</div>
					
					<div class="col-md-4">
						<div class="form-group">
							<label>&nbsp;<br/></label>
							<div class="input-group">
								<button class="btn btn-success" type="button" >Advanced Search</button>
							</div>
						</div>
					</div>
				</div>
				
				<div class="row" ng-show="IsCustSearchFieldsVisible">
					
					
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Location# </label>
							<input type="text" name="LocationId" id="LocationId" class="form-control input-sm" value="" placeholder="Enter Location ID">
						</div>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Customer Ref#</label>
							<input type="text" name="LocationRef" id="LocationRef" class="form-control input-sm" value="" placeholder="Enter Location Ref Code">
						</div>
					</div>
					
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Customer </label>
							<input type="text"  name="LocationName" id="LocationName" class="form-control input-sm" value="" placeholder="Enter Location name">
						</div>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Customer Nickname </label>
							<input type="text" name="LocationNickName" id="LocationNickName" class="form-control input-sm" value="" placeholder="Enter Location Nickname">
						</div>
					</div>					
				</div>
				
				<div class="row">
					<div class="col-lg-12 col-md-12">
						<!--<table id="example" class="table table-bordered table-striped">-->
						<table  class="table table-striped table-bordered">
						<thead>
					<tr>
						<th rowspan="3" class="text-center">Order Type</th>
						<th colspan="2" class="text-center">Provider Receiving Location</th>
						
						<th colspan="6" class="text-center">Route/Trk Order Identification</th>
						
						<th colspan="5" class="text-center">Summary	</th>
						
						</tr>
					
	                    <tr>
						
						<th></th>
						<th></th>
						<th></th>
						<th></th>
						<th></th>
						<th></th>
						<th></th>
						<th></th>
						<th></th>
						<th></th>
						<th></th>
						<th></th>
						<th></th>
						</tr>					
						
						<tr>
						
						<th>Provider Location #</th>
						<th>Provider Name</th>
						<th>Route #</th>
						<th>Order #</th>
						<th>Route Name</th>
						<th>From</th>
						<th>To</th>
						<th>Pending Receipt Date</th>
						<th>Total Qty Ordered</th>
						<th>OK</th>
						<th>Damaged</th>
						<th>OK</th>
						<th>Damaged</th>
						
                        </tr>
					     
						 <tr>
						 <td>Outbound</td>
						 <td>Loc Name</td>
						 <td>Carrier Jane</td>
						 <td></td>
						 <td>44646464</td>
						 <td></td>
						 <td></td>
						 <td></td>
						 <td>2019-03-29</td>
						 <td></td>
						 <td></td>
						 <td></td>
						 <td></td>
						 <td></td>
						 
						 
						 </tr>
					
						
					  </table>
					</div>
				</div>
              
            </div>
			</form>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <style>
 
  </style>
<script src="<?php echo base_url(); ?>asset/angular/controllers/orders/viewAllOrders.js"></script>