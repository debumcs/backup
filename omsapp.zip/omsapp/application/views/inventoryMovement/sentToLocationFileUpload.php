<div class="content-wrapper" ng-controller="sentToLocationUploadCtrl">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Sent to Location</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Inventory Management</a></li>
        <li class="active">Sent to Location</li>
      </ol>
    </section>
    <section class="content form-page">
    	
		<div class="box box-primary pad20">
        <!-- <div class="box-header with-border classBoxTitle" >
			<h3 class="box-title" id="shipFrom"><b>Ship From</b></h3>
        </div> -->
        <!-- /.box-header -->
        <div class="box-body">
		<form autocomplete="off" novalidate  name="fileUploadForm">
			<div class="row">
				<div class="col-md-12">
					<div class="form-group">
						<p>&nbsp;<br/><br/></p>
						<a href="http://14.143.158.230/api/v1/inventory/downloadSampleCSV" class="btnDownloadTemplate"><span ng-click="showForm()"><i class="fa fa-download"></i> Download Template</span></a>
					</div>
				</div>
				<div class="col-md-12" ng-show="showUploadForm">
					<div class="form-group">
						<div class="input-group">
						  <div class="input-group-prepend">
							<span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
						  </div>
						  <div class="custom-file">
							<input type="file" class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
							<input type="hidden" id="tokennu" value = "<?php echo $this->session->userdata['token']; ?>"/>
						  </div>
						</div>
					</div>
					<div class="form-group">
						<input type="button"  name="submit" id="submit" class="btn btn-primary"  ng-click="uploadFile()" value="Upload" />
					</div>
				</div>
				<!-- /.form-group -->
					
			</div>
			<div class="row">
				<div class="col-md-6">
					
          <div class="row">
          <div class="col-md-12 invalid-feedback" ng-show="errorMsg.length>0">
            {{errorMsg}}
          </div>
          <div class="col-md-12" style="color: green"  ng-show="sucessmesg.length>0">
            {{sucessmesg}}
          </div>
        </div>
				</div>
			</div>
		</form>
        </div>
    </div>
    	
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 0.0
    </div>
    <strong>&nbsp;Copyright &copy; 2018, Powered by <a href="https://www.advatix.com/" target="_blank">&nbsp;Advatix</a></strong>
  </footer>

  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/inventoryMovement/sentToLocationUploadCtrl.js"></script>