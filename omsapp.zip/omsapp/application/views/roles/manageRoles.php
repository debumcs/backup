<div class="content-wrapper" ng-controller="viewAllRoles">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>Role Management</h1>
    <ol class="breadcrumb">
      <li><a href='#'><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href='#'>Role Management</a></li>
      <li class="active">List of all Roles</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        
        <div class="box">
          
    <div class="box-header with-border">
      
      <h3 class="box-title m10"><b>List of all Roles</b></h3>
    </div>
    
          <!-- /.box-header -->
          <div class="box-body">
      <div class="row">
        <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
          <form name="roleSearchForm">
          <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
              <div class="form-group">
                <label>Account Type</label>
                <select class="form-control" ng-model="roleData.AccountType" name="AccountType" id="AccountType" ng-change="getRoledata()" >
				<option value="" selected>Select Type</option>
				<option  ng-repeat="accountType in accountTypes" value="{{accountType.id}}">{{accountType.accountType}}</option>
				</select>
              </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
              <div class="form-group">
                <label>Role Id</label>
                <input type="text" ng-model="roleData.RoleId" ng-keyup="getRoledata()" name="RoleId" id="RoleId" class="form-control input-sm" value="">
              </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
              <div class="form-group">
                <label>Role Name</label>
                <input type="text" ng-model="roleData.RoleName" ng-keyup="getRoledata()" name="RoleName" id="RoleName" class="form-control input-sm" value="">
              </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
              <div class="form-group">
                <label>Status</label>
                <select class="form-control input-md" ng-change="getRoledata()" ng-model="roleData.UserStatus" name="UserStatus" id="UserStatus" >
                <option value="" selected>Select Status</option>
                <option ng-repeat="user in allUserStatus" value="{{user.id}}">{{user.statusDesc}}</option>
                </select>
              </div>
            </div>
          </div>
        </form>
        </div>
      </div>
      
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">&nbsp;</div>
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <table datatable="ng" dt-options="dtOptions" class="table table-striped table-bordered" width="100%">
            <thead>
								<tr>
									<th>Role Id</th>
									<th>Role Name</th>
									<th>Role Description</th>
									<th>Account Type</th>
									<th>Created Date</th>
									<th>Updated Date</th>
									<th>Status</th>
								</tr>
							</thead>
							
							<tbody>
							  
							  <tr ng-repeat="role in allRoleList">
								<td><a href="<?php echo base_url(); ?>Roles/view_role/{{ role.roleId }}">{{ role.roleId }}</a></td>
								<td>{{ role.roleName }}</td>
								<td>{{ role.roleDesc }}</td>
								<td>{{ role.roleTypeDetails.accountType }}</td>
								<td>{{ role.updatedOn }}</td>
								<td>{{ role.updatedOn }}</td>
								<td>{{ role.statusDetails.statusDesc }}</td>
							  </tr>              
							</tbody>
          </table>
        </div>
      </div>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/roles/viewAllRoles.js"></script>