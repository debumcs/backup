<div class="content-wrapper" ng-controller="editUserCtrl">
<section class="content-header">
    <h1>User Management</h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">User Management</a></li>
      <li class="active">Create User</li>
    </ol>
  </section>

  <!-- Main content -->
	<section class="content">

      <!-- SELECT2 EXAMPLE -->
      <div class="box box-primary">
        <div class="box-header with-border">
			<h3 class="box-title"><b>Create Role</b></h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
		<form autocomplete="off" novalidate name="roleForm" action="<?php echo base_url().'Roles/update_role'?>" method="post">
			<div class="row">
				<div class="col-md-12 col-lg-12 col-sm-12">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label>Account Type</label>
								<select name="accountType" id="accountType" disabled class="form-control">
								<?php 
									echo '<option value="'.$roleDetails["responseObject"]["roleId"].'">'.$roleDetails["responseObject"]["roleTypeDetails"]["accountType"].'</option>';
								?>
								</select>
								
							</div>
						</div>
					
						<div class="col-md-4">
							<div class="form-group">
								<label>Role Name</label>
								<input type="text" name="roleName" readonly id="roleName" class="form-control" value="<?php echo $roleDetails["responseObject"]["roleName"]; ?>">
							</div>
						</div>					
					
						<div class="col-md-4">
							<div class="form-group">
								<label>Role Description</label>
								<input type="text" name="roleDescription" id="roleDescription" class="form-control" value="<?php echo $roleDetails["responseObject"]["roleDesc"]; ?>">
								<input type="hidden" name="roleId" id="roleId" value="<?php echo $roleDetails["responseObject"]["roleId"]; ?>">
							</div>
						</div>
					</div>
										
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<h4><b>List of Modules</b></h4>
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
							<ul class="treeview">
								<?php foreach($modulesList["responseObject"] as $value){?>
								<li>
									<input type="checkbox" name="modules[]" id="modules_<?php echo $value["menuId"]; ?>" value="<?php echo $value["menuId"]; ?>">
									<?php if(in_array($value["menuId"], $menuids)){ ?>
									<label for="<?php echo $value["menuDesc"]; ?>" class="custom-checked"><?php echo $value["menuDesc"]; ?></label>
									<?php }else{ ?>
									<label for="<?php echo $value["menuDesc"]; ?>" class="custom-unchecked"><?php echo $value["menuDesc"]; ?></label>
									<?php } ?>
									<ul>
										<?php foreach($value["subMenus"] as $submenu){?> 
										<li>
											 <input type="checkbox" name="subMenus_<?php echo $value["menuId"]; ?>[]" id="subMenus<?php echo $submenu["subMenuId"]; ?>" value="<?php echo $submenu["subMenuId"]; ?>">
											 <?php if(in_array($submenu["subMenuId"], $submenuids)){ ?>
												<label for="<?php echo $value["menuDesc"]; ?>-<?php echo $submenu["subMenuId"]; ?>" class="custom-checked"><?php echo $submenu["subMenuDesc"]; ?></label>
											 <?php }else{ ?>
												<label for="<?php echo $value["menuDesc"]; ?>-<?php echo $submenu["subMenuId"]; ?>" class="custom-unchecked"><?php echo $submenu["subMenuDesc"]; ?></label>
											<?php } ?>
										</li>
										<?php } ?>
									</ul>
								</li>
								<?php } ?>
								
							</ul>
						</div>
						
					</div>
					
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label><button type="submit" class="btn btn-primary">Update</button></label>&nbsp;&nbsp;&nbsp;
						<label><a href="<?php echo base_url(); ?>Roles/viewAllRoles" class="btn btn-danger">Cancel</a></label>
					</div>
				</div>
			</div>
		</form>
        </div>
        <!-- /.box-body -->
        
      </div>
      <!-- /.box -->
      <!-- /.row -->
    </section>
</div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/users/editUserCtrl.js"></script>