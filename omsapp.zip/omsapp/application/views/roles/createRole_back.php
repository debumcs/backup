<div class="content-wrapper" ng-controller="createRoleCtrl">
  <!-- Content Header (Page header) -->
	<section class="content-header">
		<h1>Role Management</h1>
		<ol class="breadcrumb">
			<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
			<li><a href="#">Role Management</a></li>
			<li class="active">Create Role</li>
		</ol>
	</section>

	<!-- Main content -->
	<section class="content">

      <!-- SELECT2 EXAMPLE -->
      <div class="box box-primary">
        <div class="box-header with-border">
			<h3 class="box-title"><b>Create Role</b></h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
		<form autocomplete="off" novalidate name="roleForm" ng-submit="createRole()">
			<div class="row">
				<div class="col-md-12 col-lg-12 col-sm-12">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label>Account Type</label>
								<select name="accountType" ng-model="roleData.accountType" id="accountType" class="form-control">
								<option value="" selected>Select Account Type</option>
								<option ng-repeat="accountType in accountTypes" value="{{accountType.id}}">{{accountType.accountType}}</option>
								</select>
								<div ng-if="submitted && roleForm.accountType.$invalid" class="invalid-feedback">
									<div ng-if="roleForm.accountType.$error.required">Account Type required</div>
								</div>
							</div>
						</div>
					
						<div class="col-md-4">
							<div class="form-group">
								<label>Role Name</label>
								<input type="text" ng-model="roleData.roleName" name="roleName" id="roleName" class="form-control" placeholder="Enter Role Name">
								<div ng-if="submitted && roleForm.roleName.$invalid" class="invalid-feedback">
									<div ng-if="roleForm.roleName.$error.required">Role Name required</div>
								</div>
							</div>
						</div>					
					
						<div class="col-md-4">
							<div class="form-group">
								<label>Role Description</label>
								<input type="text" ng-model="roleData.roleDescription" name="roleDescription" id="roleDescription" class="form-control" placeholder="Enter Role Description">
								<div ng-if="submitted && roleForm.roleDescription.$invalid" class="invalid-feedback">
									<div ng-if="roleForm.roleDescription.$error.required">Role Description required</div>
								</div>
							</div>
						</div>
					</div>
										
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<h4><b>List of Modules</b></h4>
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
							<ul class="treeview">
								
								
								<li ng-repeat="module in modulesList">
									<input type="checkbox" ng-model="roleData.modules[module.menuId]" name="modules[module.menuId]" id="modules[module.menuId]">
									<label for="{{module.menuDesc}}">{{module.menuDesc}}</label>
									<ul>
										 <li ng-repeat="sub in module.subMenus">
											 <input type="checkbox" ng-model="roleData.subMenus[sub.subMenuId]" name="subMenus[sub.subMenuId]" id="subMenus[sub.subMenuId]">
											 <label for="Account-1" class="custom-unchecked">{{sub.subMenuDesc}}</label>
										 </li>
									</ul>
								</li>
								
								
							</ul>
						</div>
						
					</div>
					
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label><button type="submit" class="btn btn-primary">Submit</button></label>&nbsp;&nbsp;&nbsp;
						<label><button type="button" ng-click="reset()" class="btn btn-danger">Cancel</button></label>
					</div>
				</div>
			</div>
		</form>
        </div>
        <!-- /.box-body -->
        
      </div>
      <!-- /.box -->

      
      <!-- /.row -->

    </section>
</div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/roles/createRoleCtrl.js"></script>