<div class="content-wrapper">
<section class="content-header">
    <h1>Role Management</h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">Role Management</a></li>
      <li class="active">Role Confirmation</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- SELECT2 EXAMPLE -->
    <div class="box box-primary">
      <div class="box-header with-border">
    <h3 class="box-title"><b>Role Confirmation</b></h3>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
	<?php //echo '<pre>'; print_r($roleDetails); echo '</pre>'; ?>
    <div class="row">
		<div class="col-md-12 col-lg-12 col-sm-12">
			<div class="row">
				<div class="col-md-4">
					<div class="form-group">
						<label>Account Type</label> : <?php echo $roleDetails["responseObject"]["roleTypeDetails"]["accountType"];?>
					</div>
				</div>
			
				<div class="col-md-4">
					<div class="form-group">
						<label>Role Name</label> : <?php echo $roleDetails["responseObject"]["roleName"];?>
					</div>
				</div>					
			
				<div class="col-md-4">
					<div class="form-group">
						<label>Role Description</label> : <?php echo $roleDetails["responseObject"]["roleDesc"];?>
					</div>
				</div>
			</div>
								
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<h4><b>List of Modules</b></h4>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
					<ul class="treeview">
					<?php foreach($roleDetails["responseObject"]["menus"] as $value){?>
					<li>
						<input type="checkbox"  checked disabled value="<?php echo $value["menuId"]; ?>">
						<label for="<?php echo $value["menuDesc"]; ?>" class="custom-checked"><?php echo $value["menuDesc"]; ?></label>
						<ul>
							<?php foreach($value["subMenus"] as $submenu){?> 
							<li>
								 <input type="checkbox" name="subMenus_<?php echo $value["menuId"]; ?>[]" id="subMenus<?php echo $submenu["subMenuId"]; ?>" value="<?php echo $submenu["subMenuId"]; ?>">
								 <label for="<?php echo $value["menuDesc"]; ?>-<?php echo $submenu["subMenuId"]; ?>" class="custom-checked"><?php echo $submenu["subMenuDesc"]; ?></label>
							</li>
							<?php } ?>
						</ul>
					</li>
					<?php } ?>
					</ul>
				</div>				
			</div>
			
		</div>
	</div>
	
	<div class="row">
		<div class="col-md-6">
			<div class="form-group">
				<label><a href="<?php echo base_url().'';?>" class="btn btn-primary">Create new role</a></label>
			</div>
		</div>
	</div>     
	
</div>
<!-- /.box-body -->
</div>
    <!-- /.box -->
</section>
</div>