<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Planned Pickup Report</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li><a href="#">Report</a></li>
        <li class="active">Planned Pickup Report</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          
          <div class="box">
            <div class="box-header">
				<h3 class="box-title"><b></b></h3>
            </div>
			
            <!-- /.box-header -->
			
            <div class="box-body">
				<div class="row">
			<div class="col-md-12">
			  <!-- Custom Tabs -->
			  <div class="nav-tabs-custom">
				<ul class="nav nav-tabs">
				  <li class="active"><a href="#tab_1" data-toggle="tab">Search by </a></li>
				 
				</ul>
				<div class="tab-content">
					<div class="tab-pane active" id="tab_1">
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			
								<div class="row">
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Report Format Type:</label>
											<select class="form-control" id="reportFormat">
												<option selected>Select</option>
												<option value="daily">Daily</option>
												<option value="weekly">Weekly</option>
												<option value="monthly">Monthly</option>
											</select>
										</div>
									</div>	
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Customer:</label>
											<select class="form-control">
												<option>Racks</option>
												<option>TK</option>
											</select>
										</div>
									</div>				
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Date From:</label>
											<div class="input-group date">
												<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
												<input type="text" class="form-control pull-right datepicker" id="datefrom">
											</div>
										</div>
									</div>
								</div>
								
								<!-- <div class="row">
									<div id="filter_fields"></div>
								</div> -->
								<div class="row">	
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Date To:</label>
											<div class="input-group date">
												<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
												<input type="text" class="form-control pull-right datepicker" id="dateto">
											</div>
										</div>
									</div>							
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>State:</label>
											<select class="form-control">
												<option selected="selected">Alabama</option>
												<option>Alaska</option>
												<option>California</option>
												<option>Delaware</option>
												<option>Tennessee</option>
												<option>Texas</option>
												<option>Washington</option>
											</select>
										</div>
									</div>						
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>City:</label>
											<select class="form-control">
												<option selected="selected">City1</option>
												<option>City2</option>
												<option>City3</option>
												<option>City4</option>
												<option>City5</option>
												<option>City6</option>
												<option>City7</option>
											</select>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Zipcode:</label>
											<input type="text" class="form-control">
										</div>
									</div>
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Report Type:</label>
											<select class="form-control" onchange="redirectPage(this.value);">
												<option selected>Select</option>
												<option value="ondemand-and-sweeps.html">OnDemand and Sweeps</option>
												<option value="compliance-request-date.html">Compliance to request date</option>		
												<option value="compliance-planned-date.html">Compliance to planned date</option>
												<option value="compliance-5-days-window.html">Compliance to 5 days window</option>
											</select>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<button class="btn btn-primary" type="button">Display</button>
											<button class="btn btn-primary" type="button">Download Excel</button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				  <!-- /.tab-pane -->

				  <!-- /.tab-pane -->
				</div>
				<!-- /.tab-content -->
			  </div>
			  <!-- nav-tabs-custom -->
			</div>
			<!-- /.col -->

        <!-- /.col -->
      </div>

            <div class="table-scroll">
            	<table id="daily" class="table table-bordered table-striped dt-responsive selectDropdown" style="display:none;">
                <thead>
                <tr>
                  	<th>Date/Interval</th>
				  	<th>Customer#</th>
                  	<th>Account#</th>
                  	<th>State</th>
                  	<th>City</th>
				  	<th>Total Orders</th>
				  	<th>On Demand</th>
				  	<th>Sweeps</th>
				  	<th>Ratio/Average</th>
                </tr>
                </thead>
                <tbody>
                	<tr>
	                	<td>02/06/2019</td>
	                	<td>C1236584</td>
	                	<td>A1236525</td>
	                	<td>Tennessee</td>
	                	<td>City1</td>
	                	<td>30</td>
	                	<td>10</td>
	                	<td>20</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>02/06/2019</td>
	                	<td>C2365215</td>
	                	<td>A2365214</td>
	                	<td>California</td>
	                	<td>City2</td>
	                	<td>50</td>
	                	<td>30</td>
	                	<td>20</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>01/06/2019</td>
	                	<td>C253586</td>
	                	<td>A252875</td>
	                	<td>Texas</td>
	                	<td>City3</td>
	                	<td>40</td>
	                	<td>20</td>
	                	<td>20</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>01/06/2019</td>
	                	<td>C252365</td>
	                	<td>A253654</td>
	                	<td>California</td>
	                	<td>City4</td>
	                	<td>100</td>
	                	<td>70</td>
	                	<td>30</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>01/06/2019</td>
	                	<td>C245214</td>
	                	<td>A265230</td>
	                	<td>Alaska</td>
	                	<td>City5</td>
	                	<td>190</td>
	                	<td>90</td>
	                	<td>100</td>
	                	<td>%</td>
	                </tr>
                </tbody>
              </table>
              <table id="weekly" class="table table-bordered table-striped dt-responsive selectDropdown" style="display:none;">
                <thead>
                <tr>
                  	<th>Date/Interval</th>
				  	<th>Customer#</th>
                  	<th>Account#</th>
                  	<th>State</th>
                  	<th>City</th>
				  	<th>Total Orders</th>
				  	<th>On Demand</th>
				  	<th>Sweeps</th>
				  	<th>Ratio/Average</th>
                </tr>
                </thead>
                <tbody>
                	<tr>
	                	<td>02/06/2019</td>
	                	<td>C1236584</td>
	                	<td>A1236525</td>
	                	<td>Tennessee</td>
	                	<td>City1</td>
	                	<td>30</td>
	                	<td>10</td>
	                	<td>20</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>02/05/2019</td>
	                	<td>C2365215</td>
	                	<td>A2365214</td>
	                	<td>California</td>
	                	<td>City2</td>
	                	<td>50</td>
	                	<td>30</td>
	                	<td>20</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>02/04/2019</td>
	                	<td>C253586</td>
	                	<td>A252875</td>
	                	<td>Texas</td>
	                	<td>City3</td>
	                	<td>40</td>
	                	<td>20</td>
	                	<td>20</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>02/03/2019</td>
	                	<td>C252365</td>
	                	<td>A253654</td>
	                	<td>California</td>
	                	<td>City4</td>
	                	<td>100</td>
	                	<td>70</td>
	                	<td>30</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>02/02/2019</td>
	                	<td>C245214</td>
	                	<td>A265230</td>
	                	<td>Alaska</td>
	                	<td>City5</td>
	                	<td>190</td>
	                	<td>90</td>
	                	<td>100</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>02/02/2019</td>
	                	<td>C1236584</td>
	                	<td>A1236525</td>
	                	<td>Tennessee</td>
	                	<td>City1</td>
	                	<td>30</td>
	                	<td>10</td>
	                	<td>20</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>02/05/2019</td>
	                	<td>C2365215</td>
	                	<td>A2365214</td>
	                	<td>California</td>
	                	<td>City2</td>
	                	<td>50</td>
	                	<td>30</td>
	                	<td>20</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>02/04/2019</td>
	                	<td>C253586</td>
	                	<td>A252875</td>
	                	<td>Texas</td>
	                	<td>City3</td>
	                	<td>40</td>
	                	<td>20</td>
	                	<td>20</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>01/30/2019</td>
	                	<td>C252365</td>
	                	<td>A253654</td>
	                	<td>California</td>
	                	<td>City4</td>
	                	<td>100</td>
	                	<td>70</td>
	                	<td>30</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>01/28/2019</td>
	                	<td>C245214</td>
	                	<td>A265230</td>
	                	<td>Alaska</td>
	                	<td>City5</td>
	                	<td>190</td>
	                	<td>90</td>
	                	<td>100</td>
	                	<td>%</td>
	                </tr>
                </tbody>
              </table>

              <table id="monthly" class="table table-bordered table-striped dt-responsive selectDropdown" style="display:none;">
                <thead>
                <tr>
                  	<th>Date/Interval</th>
				  	<th>Customer#</th>
                  	<th>Account#</th>
                  	<th>State</th>
                  	<th>City</th>
				  	<th>Total Orders</th>
				  	<th>On Demand</th>
				  	<th>Sweeps</th>
				  	<th>Ratio/Average</th>
                </tr>
                </thead>
                <tbody>
                	<tr>
	                	<td>02/06/2019</td>
	                	<td>C1236584</td>
	                	<td>A1236525</td>
	                	<td>Tennessee</td>
	                	<td>City1</td>
	                	<td>30</td>
	                	<td>10</td>
	                	<td>20</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>02/05/2019</td>
	                	<td>C2365215</td>
	                	<td>A2365214</td>
	                	<td>California</td>
	                	<td>City2</td>
	                	<td>50</td>
	                	<td>30</td>
	                	<td>20</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>02/04/2019</td>
	                	<td>C253586</td>
	                	<td>A252875</td>
	                	<td>Texas</td>
	                	<td>City3</td>
	                	<td>40</td>
	                	<td>20</td>
	                	<td>20</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>02/03/2019</td>
	                	<td>C252365</td>
	                	<td>A253654</td>
	                	<td>California</td>
	                	<td>City4</td>
	                	<td>100</td>
	                	<td>70</td>
	                	<td>30</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>02/02/2019</td>
	                	<td>C245214</td>
	                	<td>A265230</td>
	                	<td>Alaska</td>
	                	<td>City5</td>
	                	<td>190</td>
	                	<td>90</td>
	                	<td>100</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>02/02/2019</td>
	                	<td>C1236584</td>
	                	<td>A1236525</td>
	                	<td>Tennessee</td>
	                	<td>City1</td>
	                	<td>30</td>
	                	<td>10</td>
	                	<td>20</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>02/05/2019</td>
	                	<td>C2365215</td>
	                	<td>A2365214</td>
	                	<td>California</td>
	                	<td>City2</td>
	                	<td>50</td>
	                	<td>30</td>
	                	<td>20</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>02/04/2019</td>
	                	<td>C253586</td>
	                	<td>A252875</td>
	                	<td>Texas</td>
	                	<td>City3</td>
	                	<td>40</td>
	                	<td>20</td>
	                	<td>20</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>01/30/2019</td>
	                	<td>C252365</td>
	                	<td>A253654</td>
	                	<td>California</td>
	                	<td>City4</td>
	                	<td>100</td>
	                	<td>70</td>
	                	<td>30</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>01/28/2019</td>
	                	<td>C245214</td>
	                	<td>A265230</td>
	                	<td>Alaska</td>
	                	<td>City5</td>
	                	<td>190</td>
	                	<td>90</td>
	                	<td>100</td>
	                	<td>%</td>
	                </tr>
                </tbody>
              </table>
              <table id="example1" class="table table-bordered table-striped dt-responsive" style="display:none;">
                <thead>
                <tr>
                  	<th>Date/Interval</th>
				  	<th>Customer#</th>
                  	<th>Account#</th>
                  	<th>State</th>
                  	<th>City</th>
				  	<th>Total Orders</th>
				  	<th>On Demand</th>
				  	<th>Sweeps</th>
				  	<th>Ratio/Average</th>
                </tr>
                </thead>
                <tbody>
                	<tr>
	                	<td>02/04/2019</td>
	                	<td>C1236584</td>
	                	<td>A1236525</td>
	                	<td>Tennessee</td>
	                	<td>City1</td>
	                	<td>30</td>
	                	<td>10</td>
	                	<td>20</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>02/02/2019</td>
	                	<td>C2365215</td>
	                	<td>A2365214</td>
	                	<td>California</td>
	                	<td>City2</td>
	                	<td>50</td>
	                	<td>30</td>
	                	<td>20</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>01/30/2019</td>
	                	<td>C253586</td>
	                	<td>A252875</td>
	                	<td>Texas</td>
	                	<td>City3</td>
	                	<td>40</td>
	                	<td>20</td>
	                	<td>20</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>01/28/2019</td>
	                	<td>C252365</td>
	                	<td>A253654</td>
	                	<td>California</td>
	                	<td>City4</td>
	                	<td>100</td>
	                	<td>70</td>
	                	<td>30</td>
	                	<td>%</td>
	                </tr>
                	<tr>
	                	<td>01/25/2019</td>
	                	<td>C245214</td>
	                	<td>A265230</td>
	                	<td>Alaska</td>
	                	<td>City5</td>
	                	<td>190</td>
	                	<td>90</td>
	                	<td>100</td>
	                	<td>%</td>
	                </tr>
                </tbody>
              </table>
            </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
</div>