<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Detailed Order Report</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li><a href="#">Report</a></li>
        <li class="active">Detailed Order Report</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          
          <div class="box">
            <div class="box-header">
				<h3 class="box-title"><b></b></h3>
            </div>
			
            <!-- /.box-header -->
			
            <div class="box-body">
				<div class="row">
			<div class="col-md-12">
			  <!-- Custom Tabs -->
			  <div class="nav-tabs-custom">
				<ul class="nav nav-tabs">
				  <li class="active"><a href="#tab_1" data-toggle="tab">Search by </a></li>
				 
				</ul>
				<div class="tab-content">
					<div class="tab-pane active" id="tab_1">
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			
								<div class="row">
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Customer:</label>
											<select class="form-control">
												<option>Customer1</option>
												<option>Customer2</option>
												<option>Customer3</option>
												<option>Customer4</option>
												<option>Customer5</option>
												<option>Customer6</option>
											</select>
										</div>
									</div>				
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Date From:</label>
											<div class="input-group date">
												<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
												<input type="text" class="form-control pull-right datepicker" id="datefrom">
											</div>
										</div>
									</div>
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Date To:</label>
											<div class="input-group date">
												<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
												<input type="text" class="form-control pull-right datepicker" id="dateto">
											</div>
										</div>
									</div>					
								
								</div>
								
								<!-- <div class="row">
									<div id="filter_fields"></div>
								</div> -->
								<div class="row">							
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Provider:</label>
											<select class="form-control">
												<option>Location 1</option>
												<option>Location 2</option>
												<option>Location 3</option>
												<option>Location 4</option>												
											</select>
										</div>
									</div>
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Retailer:</label>
											<select class="form-control">
												<option>Location 1</option>
												<option>Location 2</option>
												<option>Location 3</option>
												<option>Location 4</option>												
											</select>
										</div>
									</div>
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Report Type:</label>
											<select class="form-control input-md" onchange="redirectPage(this.value);">
												<option value="planed-pickup-report.html" selected>Summarised Report</option>
												<option value="detailed-reports.html">Detailed Report</option>												
											</select>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<button class="btn btn-primary" type="button">Display</button>
											<button class="btn btn-primary" type="button">Download Excel</button>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				  <!-- /.tab-pane -->

				  <!-- /.tab-pane -->
				</div>
				<!-- /.tab-content -->
			  </div>
			  <!-- nav-tabs-custom -->
			</div>
			<!-- /.col -->

        <!-- /.col -->
      </div>

            <div class="table-scroll">
              <table id="example1" class="table table-bordered table-striped dt-responsive">
                <thead>
                <tr>
                  	<th>Date/Interval</th>
				  	<th>Customer#</th>
                  	<th>Account#</th>
                  	<th>OrderNumber</th>
                  	<th>Provider</th>
				  	<th>Location</th>
				  	<th>ServiceDueDate</th>
				  	<th>PU CommittedDate</th>
				  	<th>PU ClosedDate</th>
				  	<th>OrderAssets</th>
                </tr>
                </thead>
                <tbody>
                	<tr>
	                	<td>02/04/2019</td>
	                	<td>C123658</td>
	                	<td>A1236525</td>
	                	<td>1235569</td>
	                	<td>Provider1</td>
	                	<td>Location1</td>
	                	<td>02/06/2019</td>
	                	<td>02/06/2019</td>
	                	<td>02/07/2019</td>
	                	<td>Bottom</td>
	                </tr>
                	<tr>
	                	<td>02/02/2019</td>
	                	<td>C153674</td>
	                	<td>A1568544</td>
	                	<td>23552595</td>
	                	<td>Provider2</td>
	                	<td>Location2</td>
	                	<td>02/04/2019</td>
	                	<td>02/05/2019</td>
	                	<td>02/06/2019</td>
	                	<td>Top</td>
	                </tr>
                	<tr>
	                	<td>01/31/2019</td>
	                	<td>C523658</td>
	                	<td>A2365421</td>
	                	<td>25358426</td>
	                	<td>Provider3</td>
	                	<td>Location3</td>
	                	<td>02/01/2019</td>
	                	<td>02/02/2019</td>
	                	<td>02/03/2019</td>
	                	<td>Bottom</td>
	                </tr>
                	<tr>
	                	<td>01/25/2019</td>
	                	<td>C523658</td>
	                	<td>A2365421</td>
	                	<td>25358426</td>
	                	<td>Provider4</td>
	                	<td>Location4</td>
	                	<td>01/28/2019</td>
	                	<td>02/29/2019</td>
	                	<td>02/31/2019</td>
	                	<td>Top</td>
	                </tr>
                	<tr>
	                	<td>01/20/2019</td>
	                	<td>C523652</td>
	                	<td>A2562542</td>
	                	<td>23652219</td>
	                	<td>Provider5</td>
	                	<td>Location5</td>
	                	<td>01/22/2019</td>
	                	<td>02/23/2019</td>
	                	<td>02/24/2019</td>
	                	<td>Bottom</td>
	                </tr>
                </tbody>
              </table>
            </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
</div>