<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Return Load Tracking</h1><ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li><a href="#">Report</a></li>
        <li class="active">Return Load Tracking</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          
          <div class="box">
            <div class="box-header">
				<h3 class="box-title"><b></b></h3>
            </div>
			
            <!-- /.box-header -->
			
            <div class="box-body">
				<div class="row">
			<div class="col-md-12">
			  <!-- Custom Tabs -->
			  <div class="nav-tabs-custom">
				<ul class="nav nav-tabs">
				  <li class="active"><a href="#tab_1" data-toggle="tab">Search by </a></li>
				 
				</ul>
				<div class="tab-content">
					<div class="tab-pane active" id="tab_1">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
			
								<div class="row">
				
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Date From:</label>
											<div class="input-group date">
												<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
												<input type="text" class="form-control pull-right datepicker" id="datefrom">
											</div>
										</div>
									</div>
									<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Date To:</label>
											<div class="input-group date">
												<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
												<input type="text" class="form-control pull-right datepicker" id="dateto">
											</div>
										</div>
									</div>
						
								
								</div>
								
								<div class="row">
									<div id="filter_fields"></div>
								</div>
								
								
												<div class="row">
							
								<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Provider:</label>
											<div class="input-group">
												<select class="form-control">
												<option>Location 1</option>
												<option>Location 2</option>
												<option>Location 3</option>
												<option>Location 4</option>												
												</select>
											</div>
										</div>
									</div>
													<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Retailer:</label>
											<div class="input-group">
												<select class="form-control">
												<option>Location 1</option>
												<option>Location 2</option>
												<option>Location 3</option>
												<option>Location 4</option>												
												</select>
											</div>
										</div>
									</div>
												<!-- <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Status:</label>
											<div class="input-group">
												<select class="form-control" >
												<option>Open</option>
												<option>Pending</option>
												<option>Overdue</option>
												<option>Closed</option>												
												</select>
											</div>
										</div>
									</div> -->
									
									
							</div>
							
							
							<div class="row">
								<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
										<label>&nbsp;</label>
										<div class="form-group">
											<button class="btn btn-primary" type="button">Display</button>
											<button class="btn btn-primary" type="button">Download Excel</button>
											
										</div>
									</div>
							</div>
							</div>
						</div>
					</div>
				  <!-- /.tab-pane -->

				  <!-- /.tab-pane -->
				</div>
				<!-- /.tab-content -->
			  </div>
			  <!-- nav-tabs-custom -->
			</div>
			<!-- /.col -->

        <!-- /.col -->
      </div>

              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>LocationType</th>
				  <th>LocationName</th>
                  <th>Provider</th>
                  <th>AssetsCount</th>
                  <th>DeliveryDate</th>
				  <th>ShipmentId</th>
				
                </tr>
                </thead>
                <tbody>
                
                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>