<div class="content-wrapper" ng-controller="createUserCtrl">

  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>User Management</h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">User Management</a></li>
      <li class="active">Create User</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- SELECT2 EXAMPLE -->
    <div class="box box-primary">
      <div class="box-header with-border">
    <h3 class="box-title"><b>Create User</b></h3>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
  <form autocomplete="off" novalidate name="userForm" ng-submit="createUser()">
    <div class="row">
      <div class="col-md-12 col-lg-12 col-sm-12">
        <div class="row">
          <div class="col-md-6">
            <label>Username <span class="asterisk">*</span></label>
            <div class="form-group" ng-class="{ 'has-error' : userForm.userName.$invalid && submitted }">
              <input type="text" ng-model="userData.userName" required pattern="^[a-zA-Z0-9_-]{5,30}$" name="userName" id="userName" maxlength="30" minlength="5" class="form-control" unique-field ng-class="{ 'has-error' : userForm.name.$invalid && !userForm.name.$pristine }" placeholder="Enter username">
              <div ng-if="submitted && userForm.userName.$invalid" class="invalid-feedback">
                <span ng-if="userForm.userName.$error.required">Username required</span>
                <span ng-if="userForm.userName.$error.minlength">Username must be at least 5 characters</span>
                <span ng-if="userForm.userName.$error.maxlength">Username must be max length of 30 characters</span>
                <span ng-if="userForm.userName.$error.pattern">Enter valid characters. </span>
                <span ng-if="userForm.userName.$error.uniqueField">Username exists already</span>
              </div>

            </div>
          </div>
        <!-- /.form-group -->
          <div class="col-md-6">
            <label>Employee Number</label>
            <div class="form-group" ng-class="{ 'has-error' : userForm.employeeNumber.$invalid && submitted }">
              <input type="text" ng-model="userData.employeeNumber" pattern="^[a-zA-Z0-9_-]{1,30}$" name="employeeNumber" id="employeeNumber" class="form-control" maxlength="25" placeholder="Enter employee number">
              <div ng-if="submitted && userForm.employeeNumber.$invalid" class="invalid-feedback">
                <span ng-if="userForm.employeeNumber.$error.maxlength">Employee Number must be max length of 25 characters</span>
                <span ng-if="userForm.employeeNumber.$error.pattern">Enter valid characters. </span>
              </div>
            </div>
          </div>					
        <!-- /.form-group -->
        </div>
        
        <div class="row">			
          <div class="col-md-6">
            <label>First Name <span class="asterisk">*</span></label>
            <div class="form-group" ng-class="{ 'has-error' : userForm.firstName.$invalid && submitted }">
              <input type="text" ng-model="userData.firstName" required name="firstName" id="firstName" class="form-control" placeholder="Enter first name">
              <div ng-if="submitted && userForm.firstName.$invalid" class="invalid-feedback">
                  <span ng-if="userForm.firstName.$error.required">First Name required</span>
                  <span ng-if="userForm.firstName.$error.maxlength">Maximum length for First Name is 20 characters</span>
                  <span ng-if="userForm.firstName.$error.pattern">Enter valid characters. </span>
                </div>
            </div>
          </div>
        <!-- /.form-group -->
          <div class="col-md-6">
            <label>Last Name <span class="asterisk">*</span></label>
            <div class="form-group" ng-class="{ 'has-error' : userForm.lastName.$invalid && submitted }">
              <input type="text" ng-model="userData.lastName" required name="lastName" id="lastName" class="form-control" placeholder="Enter last name">
              <div ng-if="submitted && userForm.lastName.$invalid" class="invalid-feedback">
                <span ng-if="userForm.lastName.$error.required">Last Name required. </span>
                <span ng-if="userForm.lastName.$error.maxlength">Maximum length for Last Name is 20 characters. </span>
                <span ng-if="userForm.lastName.$error.pattern">Enter valid characters. </span>
              </div>
            </div>
          </div>					
        <!-- /.form-group -->
        </div>
        
        <div class="row">
          <div class="col-md-6">
            <label>Email Address <span class="asterisk">*</span></label>
            <div class="form-group" ng-class="{ 'has-error' : userForm.email.$invalid && submitted }">
              <input type="email" maxlength="40" ng-model="userData.email" required name="email" id="email" class="form-control" placeholder="Enter email">
              <div ng-if="submitted && userForm.email.$invalid" class="invalid-feedback">
                <div ng-if="userForm.email.$error.required">Email required</div>
                <div ng-if="userForm.email.$error.email">Valid email required</div>
                <div ng-if="userForm.email.$error.maxlength">Maximum length for email is 40 characters</div>
              </div>
            </div>
          </div>
        <!-- /.form-group -->
          <div class="col-md-6">
            <label>Phone Number <span class="asterisk">*</span></label>
            <div class="form-group" ng-class="{'has-error':userForm.phoneNumber.$invalid && submitted }">
              
              <!-- <input type="text" name="address" id="address" class="form-control" placeholder="Enter phone number"> -->
              <div class="input-group">
                <span class="input-group-addon">+1</span>
                <input type="text" ng-model="userData.phoneNumber" pattern="^[0-9]{10}$" required name="phoneNumber" id="phoneNumber" class="form-control" placeholder="Enter phone number">
              </div>
              <div ng-if="submitted && userForm.phoneNumber.$invalid" class="invalid-feedback">
                  <span ng-if="userForm.phoneNumber.$error.required">Phone Number required. </span>
                  <span ng-if="userForm.phoneNumber.$error.pattern">Enter 10 digit phone number. </span>
              </div>
            </div>
          </div>					
        <!-- /.form-group -->
        </div>
        
        <div class="row">
          <div class="col-md-6">
            <label>Role <span class="asterisk">*</span></label>
            <div class="form-group" ng-class="{ 'has-error' : userForm.roleId.$invalid && submitted }">
              <select ng-model="userData.roleId" required name="roleId" id="roleId" class="form-control">
                <option value="">Select Role</option>
                <option ng-repeat='role in roleTypes' value="{{role.roleId}}">{{role.roleDesc}}</option>
              </select>
				<div ng-if="submitted && userForm.roleId.$invalid" class="invalid-feedback">
					<div ng-if="userForm.roleId.$error.required">Role required</div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <label>
            <button type="submit" class="btn btn-primary">Submit</button>
            </label>&nbsp;&nbsp;&nbsp;
          <label><button type="button" ng-click="reset()" class="btn btn-danger">Cancel</button></label>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="invalid-feedback" ng-if="errorMsg" >
          {{errorMsg}}
        </div>
      </div>
    </div>
  </form>
      </div>
      <!-- /.box-body -->
      
    </div>
    <!-- /.box -->

    
    <!-- /.row -->

  </section>
  </div>
 <script src="<?php echo base_url(); ?>asset/angular/controllers/users/createUserCtrl.js"></script>