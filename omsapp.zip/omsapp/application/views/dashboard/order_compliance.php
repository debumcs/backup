<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Order Compliance</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li><a href="#">Dashboard</a></li>
        <li class="active">Order Compliance</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          
          <div class="box">
            <div class="box-header with-border">
				<!--<a href="createorder.html" class="pull-right btn btn-default">Create Order</a>-->
				<h3 class="box-title m10"><b>Search Order</b></h3>
			</div>
			
            <!-- /.box-header -->
			<form autocomplete="off" name="viewAllOrders">
            <div class="box-body">
				<div class="row">
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Order Type </label><!-- onchange="redirectPage(this.value);" -->
							<select class="form-control input-md"  width="100%" name="OrderType" id="OrderType" required>
                                <option value="ordercompliance.html">Outbound</option>
								<option value="#">Asset Collection</option>
							</select>
						</div>
					</div>
					
					<div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Provider/Carrier Loc # </label>
							<input type="text" name="company_name" id="company_name" class="form-control input-sm" value="" placeholder="Enter Provider/Carrier Loc #">
						</div>
					</div>
					
										
					<div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Status</label>
							<select class="form-control input-md" id="accounttype" onchange="showDataGrid();" width="100%" name="status">
							<option value="" selected>Select Status</option>
							<option value="All" >All</option>
							<option value="Active" >Created</option>
							<option value="Inactive">Assigned</option>
							</select>
						</div>
					</div>
					
					<!--<div class="col-md-4">
						<div class="form-group">
							<label>&nbsp;<br/></label>
							<div class="input-group">
								<button class="btn btn-success" type="button" >Advanced Search</button>
							</div>
						</div>
					</div>-->
				</div>
				
				<div class="row" ng-show="IsCustSearchFieldsVisible">
					
					
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Location# </label>
							<input type="text" name="LocationId" id="LocationId" class="form-control input-sm" value="" placeholder="Enter Location ID">
						</div>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Customer Ref#</label>
							<input type="text" name="LocationRef" id="LocationRef" class="form-control input-sm" value="" placeholder="Enter Location Ref Code">
						</div>
					</div>
					
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Customer </label>
							<input type="text"  name="LocationName" id="LocationName" class="form-control input-sm" value="" placeholder="Enter Location name">
						</div>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
						<div class="form-group">
							<label>Customer Nickname </label>
							<input type="text" name="LocationNickName" id="LocationNickName" class="form-control input-sm" value="" placeholder="Enter Location Nickname">
						</div>
					</div>					
				</div>
				
				<div class="row">
					<div class="col-lg-12 col-md-12">
						<!--<table id="example" class="table table-bordered table-striped">-->
					   <div class="table-scroll">	
						<table  id="example1" class="table table-striped table-bordered">
						<thead>
						<tr>
						<th rowspan="2" class="text-center">Order#</th>
						<th colspan="2" class="text-center">Provider / Carrier</th>
						<th colspan="6" class="text-center">SHIP FROM</th>
						<th colspan="6" class="text-center">SHIP TO</th>
						<th colspan="3" class="text-center">ORDER</th>
						<th rowspan="2">Order Assigned Date</th>
						<th colspan="3" class="text-center">Order Acceptance</th>
						<th colspan="2" class="text-center">Confirmation Call</th>
						<th colspan="3" class="text-center">Status</th>
						</tr>
						
						
						<tr>
						  
						  <th> Assigned Provider/Carrier Location</th>
						  <th>Provider/Carrier ID</th>
						  <th>Ship From Location</th>
						  <th>Location Name</th>
						  <th>Address</th>
						  <th>City</th>
						  <th>State</th>
						  <th>Zip Code</th>
						  <th>Ship To Location</th>
						  <th>Location Name</th>
						  <th>Address</th>
						  <th>City</th>
						  <th>State</th>
						  <th>Zip Code</th>
						  <th>Order #</th>
						  <th>PU Request Date</th>
						 <th> PU Due Date</th>
						 
						 <th>Accept/ Reject</th>
						 
						 <th>Date/Timestamp</th>
						 <th>Confirmed with</th>
						 <th>Date/Timestamp</th>
						 <th>Status</th>
						 <th>Status Date</th>
						 <th>Carrier Transit Event</th>


						</tr>
						
						</thead>
						<tbody>
						<tr>
						<td><a href="<?php echo base_url();?>Orders/compliance_detail">A000000</a></td>
						<td>Above and Beyond</td>
						<td>ABMEMA</td>
						<td>Loc ID</td>
						<td>Loc Name</td>
						<td>Address Line 1 & 2</td>
						<td>Atlanta</td>
						<td>GA</td>
						<td>34847</td>
						<td>ABMEMA</td>
						<td>Above and Beyond</td>
						<td>Address Line 1 & 2</td>
						<td>Atlanta</td>
						<td>GA</td>
						<td>34847</td>
						<td>2019-01-28</td>
						<td>2019-01-28</td>
						<td>2019-01-25</td>
						<td>2019-04-01</td>
						<td>
<select><option>Accept</option>

							<option>Reject</option>
</td>
						<td>1/25/2019 2:15PM </td>
						<td>Jane Doe</td>
						<td>1/27/2019 8:45AM</td>
						<td>Transit Order Accepted</td>
						<td>1/27/2019 8:45AM</td>
						<td>0</td>
						</tr>	


						<tr>
						<td><a href="<?php echo base_url();?>Orders/compliance_detail">A000001</a></td>
						<td>Above and Beyond</td>
						<td>ABMEMA</td>
						<td>Loc ID</td>
						<td>Loc Name</td>
						<td>Address Line 1 & 2</td>
						<td>Atlanta</td>
						<td>GA</td>
						<td>34847</td>
						<td>ABMEMA</td>
						<td>Above and Beyond</td>
						<td>Address Line 1 & 2</td>
						<td>Atlanta</td>
						<td>GA</td>
						<td>34847</td>
						<td>2019-01-28</td>
						<td>2019-01-28</td>
						<td>2019-01-25</td>
						<td>2019-04-01</td>
						<td>
<select><option>Accept</option>

							<option>Reject</option>
</td>
						<td>1/25/2019 2:15PM </td>
						<td>Jane Doe</td>
						<td>1/27/2019 8:45AM</td>
						<td>Transit Order Accepted</td>
						<td>1/27/2019 8:45AM</td>
						<td>0</td>
						</tr>
						<tr>
						<td><a href="<?php echo base_url();?>Orders/compliance_detail">A000002</a></td>
						<td>Above and Beyond</td>
						<td>ABMEMA</td>
						<td>Loc ID</td>
						<td>Loc Name</td>
						<td>Address Line 1 & 2</td>
						<td>Atlanta</td>
						<td>GA</td>
						<td>34847</td>
						<td>ABMEMA</td>
						<td>Above and Beyond</td>
						<td>Address Line 1 & 2</td>
						<td>Atlanta</td>
						<td>GA</td>
						<td>34847</td>
						<td>2019-01-28</td>
						<td>2019-01-28</td>
						<td>2019-01-25</td>
						<td>2019-04-01</td>
						<td>
<select><option>Accept</option>

							<option>Reject</option>
</td>
						<td>1/25/2019 2:15PM </td>
						<td>Jane Doe</td>
						<td>1/27/2019 8:45AM</td>
						<td>Transit Order Accepted</td>
						<td>1/27/2019 8:45AM</td>
						<td>0</td>
						</tr>
						</tbody>
					  </table></div>
					</div>
				</div>
              
            </div>
			</form>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
