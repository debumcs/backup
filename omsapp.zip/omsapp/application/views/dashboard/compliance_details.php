<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>View Compliance Information</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Order Management</a></li>
        <li class="active">View Compliance Information</li>
      </ol>
    </section>
    
    <section class="content form-page">
		<div class="box">
		<div class="box-body">
			<div class="padleftright20">
				<div class="accordion-option">
				
					<a href="#" class="btn btn-primary">Edit</a>
					<a href="#" data-toggle="modal" class="btn btn-danger">Cancel Order</a>
					<a href="javascript:void(0)" class="toggle-accordion active" accordion-id="#accordion"></a>
				
				</div>
				<div class="clearfix"></div>
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
				
					
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingZero">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseZero" aria-expanded="true" aria-controls="collapseZero">
								Order Status
								</a>
							</h4>
						</div>
						<div id="collapseZero" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingZero">
							<div class="panel-body">
								<div class="row ">
									<div class="col-md-12 col-lg-12 col-sm-12">
										<div class="row">
											<div class="col-md-12">
												<div class="form-group">
													<label><strong>Order Status:</strong></label>
												</div>
											</div>
										</div>
										<!--div class="row">
											<div class="col-md-12">
												<div class="form-group">
													<label><strong>Reason:</strong> <?php //echo $orderDetails["responseObject"]["orderNumber"];?></label>
												</div>
											</div>
										</div-->
									</div>
								</div>
							</div>
						</div>
					</div>
					
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
								Bill To
								</a>
							</h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
							<div class="panel-body">
								<div class="row ">
									<div class="col-md-12 col-lg-12 col-sm-12">
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Order Number:</strong></label>
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Account Type:</strong></label>
												</div>
											</div>
											<div class="col-lg-4">
												<div class="form-group">
													<label><strong>Account ID:</strong> </label>
												</div>
											</div>
										</div>
										
										<div class="row">
											<div class="col-lg-4">
												<div class="form-group">
													<label><strong>Account Name:</strong> </label>
												</div>
											</div>
											<div class="col-lg-4">
												<div class="form-group">
													<label><strong>Address :</strong></label>
												</div>
											</div>
											<div class="col-lg-4">
												<div class="form-group">
													<label><strong>Business Phone:</strong> </label>
												</div>
											</div>
										</div>
										
										<div class="row">
											<div class="col-lg-4">
												<div class="form-group">
													<label><strong>Email Address:</strong></label>
												</div>
											</div>					
										</div>									
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingTwo">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
								Ship From
								</a>
							</h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
							<div class="panel-body">
								<div class="row">
									<div class="col-md-12 col-lg-12">
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Location ID:</b> </label></label>
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Customer :</b></label>
												</div>
											</div>		
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Address:</b></label>
												</div>
											</div>								
										</div>
										<div class="row">										
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Business Phone :</b></label>
												</div>
											</div>		
											<div class="col-md-4">
												<div class="form-group">
													<label><b>Email:</b></label>
												</div>
											</div>
										</div>
									</div>									
								</div>
							</div>
						</div>
					</div>
					
					
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingThree">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
								Order
								</a>
							</h4>
						</div>
						<div id="collapseThree" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingThree">
							<div class="panel-body">											
							<div class="row">
								
								<div class="col-lg-12">
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>PO Number:</strong></label>
											</div>
										</div>	
										
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Reference Number 1:</strong> </label>
											</div>
										</div>
										
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Reference Number 2:</strong></label>
											</div>
										</div>
									</div>	
									
									<div class="row">								
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Pick Up Due Date:</strong> </label>
											</div>
										</div>	
										
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Requested Pickup Date :</strong> </label>
											</div>
										</div>	
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Requested Pick up Time :</strong></label>
											</div>
										</div>
									</div>
							
									<div class="row">								
										<div class="col-md-4">
											<div class="form-group">
												<label><strong>Special Instructions :</strong></label>
											</div>
										</div>
									</div>
							
							
								</div>
							</div>					
							</div>
						</div>
					</div>
				
				<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingFour">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
								Order Details
								</a>
							</h4>
						</div>
						<div id="collapseFour" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingFour">
							<div class="panel-body">											
							<div class="row">
								
								<div class="col-lg-12">
									<div class="row">
										<div class="col-lg-6">
											<div class="col-md-12 col-lg-12">
												<div class="row"><h5><b>Pickup</b></h5></div>
											</div>
											<table class="display table table-bordered table-striped dataTable no-footer" width="100%">
												<thead>
													<tr>
														<th width="75">SKU</th>
														<th width="120">Quantity</th>
													</tr>
												</thead>
												<tbody>
													
													<tr>
														<td width="30"></td>
														<td width="120"></td>
													</tr>
													
												</tbody>
											</table>
										</div>										
									</div>
								</div>	
								
							</div>
							</div>
						</div>					
				</div>
				
				<div class="row">
					<div class="col-md-6">&nbsp;</div>
				</div>
				
			</div>
		</div>
		</div>
    </section>
    <!-- /.content -->
  </div>

<div id="modalCancelOrder" class="modal fade" role="dialog" ng-controller="cancelOrderCtrl">
	<div class="modal-dialog modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<div class="col-md-12">	
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h3 class="modal-title"><b>Cancel Order</b></h3>
				</div>
			</div>
			<div class="modal-body" style="min-height:200px;">
			
			<form autocomplete="off" name="cancelOrderForm" >
				<div class="col-md-12">
					<div class="row">				
						<div class="col-md-12">							
							<div class="form-group">
								<label>Are you sure want to cancel this order? </label>
								
								
								
								<input type="hidden" id="orderNo" name="orderNo" value="" />
								<input type="hidden" ng-model="orderData.orderNumber" name="orderNo" />
								<label>
									<input type="radio" name="reason" id="reasonYes" value="Yes" /> Yes
								</label>
								<label>
									<input type="radio" name="reason" id="reasonNo"  value="No" /> No
								</label>							
							</div>
						</div>						
						<div class="col-md-12" ng-show="reasonDiv">
							<div class="form-group">
								<label>Reason: </label>
								<textarea class="form-control" name="reasonCancel" id="reasonCancel" rows="2" placeholder="Enter ..."></textarea>
							</div>
						</div>
					</div>	
					<div class="row">				
						<div class="col-md-12">							
							<div class="form-group">
								<button type="button" ng-click="cancelOrder()" ng-disabled="cancelButton" class="btn btn-primary">Submit</button>
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							</div>
						</div>
					</div>
					
					<div class="row">				
						
					</div>
				</div>
			</form>
			</div>
			<div class="modal-footer">
				<!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
			</div>
		</div>
	</div>
</div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/orders/cancelOrderCtrl.js"></script>