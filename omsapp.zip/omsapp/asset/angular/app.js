'use strict';

var myApp = angular.module("ezrOmsApp", ['datatables','720kb.datepicker']); 
//var myApp = angular.module("ezrOmsApp", ['datatables','720kb.datepicker','kendo.directives']); 

var EMAIL_REGEXP = /^[_a-zA-Z0-9]+(\.[_a-zA-Z0-9]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-z]{2,4})$/;
var MOBILE_REGEXP = /^[7-9][0-9]{9}$/;
var NAME_REGEXP = /^[A-z ]+$/;

var appBaseUrl = "/omsapp";

var msg_norecord = "No record(s) found.";
var currencyCode = "USD";

myApp.filter('formatTime', function ($filter) {
	return function (time, format) {
		var parts = time.split(':');
		var date = new Date(0, 0, 0, parts[0], parts[1], parts[2]);
		return $filter('date')(date, format || 'h:mm a');
	};
});

myApp.directive('uniqueField', function($http) {
  var toId;
  return {
    restrict: 'A',
    require: 'ngModel',
    link: function(scope, elem, attr, ctrl) { 
      //when the scope changes, check the field.
      scope.$watch(attr.ngModel, function(value) {
        // if there was a previous attempt, stop it.
        if(toId) clearTimeout(toId);

        // start a new attempt with a delay to keep it from
        toId = setTimeout(function(){
        // call to some API that echo "1" or echo "0"
          $http.get(appBaseUrl + '/Users/checkUserNameExists/'+value).success(function(response) {

            console.log(response);
            if (response.responseObject === false)
            {
              ctrl.$setValidity('uniqueField', true);
            }else
            {
              ctrl.$setValidity('uniqueField', false);
            }
          });
        }, 200);
      })
    }
  }
});

myApp.directive('uniqueSkunumber', function($http) {
  var toId;
  return {
    restrict: 'A',
    require: 'ngModel',
    link: function(scope, elem, attr, ctrl) { 
      //when the scope changes, check the field.
      scope.$watch(attr.ngModel, function(value) {
        // if there was a previous attempt, stop it.
        if(toId) clearTimeout(toId);

        // start a new attempt with a delay to keep it from
        toId = setTimeout(function(){
        // call to some API that echo "1" or echo "0"
          $http.get(appBaseUrl + '/Products/checkSKUExists/'+value).success(function(response) {

            console.log(response);
            if (response.responseObject === false)
            {
              ctrl.$setValidity('uniqueField', true);
            }else
            {
              ctrl.$setValidity('uniqueField', false);
            }
          });
        }, 200);
      })
    }
  }
});

myApp.directive('tsSelectFix', function () {
    return {
        link: function (scope, element, attrs) {
            var model = scope;

            attrs.ngModel.split('.').forEach(function (part) {
                model = model[part];
            });

            scope.$watch(function() {
                return element.children().length;
            }, function() {
                scope.$evalAsync(function() {
                    // iterate through <option>s
                    Array.prototype.some.call(element.children(), function (child) {
                        if (child.value === model.toString()) {
                            child.setAttribute('selected', 'selected');
                        }
                        setTimeout(function () {
                            element.triggerHandler('change');
                        }, 0);
                        return false;
                    });
                });
            });
        }
    };
});

myApp.directive('passwordVerify', function() {
    return {
      restrict: 'A', // only activate on element attribute
      require: '?ngModel', // get a hold of NgModelController
      link: function(scope, elem, attrs, ngModel) {
        if (!ngModel) return; // do nothing if no ng-model

        // watch own value and re-validate on change
        scope.$watch(attrs.ngModel, function() {
          validate();
        });

        // observe the other value and re-validate on change
        attrs.$observe('passwordVerify', function(val) {
          validate();
        });

        var validate = function() {
          // values
          var val1 = ngModel.$viewValue;
          var val2 = attrs.passwordVerify;

          // set validity
          ngModel.$setValidity('passwordVerify', val1 === val2);
        };
      }
    };
});

//Angular Directive for username validation
myApp.directive('mobileEmail', function() 
{
  return {
    require: 'ngModel',
    link: function(scope, element, attr, mCtrl) {
      function myValidation(value) {
		if(value!=""){
			if (EMAIL_REGEXP.test(value) || MOBILE_REGEXP.test(value)) {
			  mCtrl.$setValidity('mobEmail', true);
			} else {
			  mCtrl.$setValidity('mobEmail', false);
			}
		}
        return value;
      }
		mCtrl.$parsers.push(myValidation);
    }
  };
});

myApp.directive('alphaVal', function() 
{
  return {
    require: 'ngModel',
    link: function(scope, element, attr, mCtrl) {
      function myValidation(value) {
		if(value!=""){
			if (NAME_REGEXP.test(value)) {
			  mCtrl.$setValidity('alphVal', true);
			} else {
			  mCtrl.$setValidity('alphVal', false);
			}
		}
        return value;
      }
      mCtrl.$parsers.push(myValidation);
    }
  };
});

myApp.directive('mobileName', function() {

  return {
    require: 'ngModel',
    link: function(scope, element, attr, mCtrl) {
      function myValidation(value) {
		if(value!=""){
			if (NAME_REGEXP.test(value)) {
			  mCtrl.$setValidity('mobName', true);
			} else {
			  mCtrl.$setValidity('mobName', false);
			}
		}
        return value;
      }
      mCtrl.$parsers.push(myValidation);
    }
  };
});


myApp.filter('dateToISO', function() 
{
	return function(input) 
  {
	if(!input)
	return null;
    var t = input.split(/[- :]/);
	var d = new Date(t[2], t[1]-1, t[0], t[3], t[4], t[5]);
	return new Date(d).toISOString();
    
  };
  
});


myApp.filter('datysCal', function() 
{
	return function(input) 
  {
	if(!input)
	return null;
    var t = input.split(/[- :]/);
	var d = new Date(t[2], t[1]-1, t[0], t[3], t[4], t[5]);
	var today = new Date();
	return new Date(d).toISOString();
    
  };
  
});

myApp.filter('dateDiff', function() 
{
return function(input) 
  {
	if(!input)
	return null;
	
	var today = new Date();
	
	//console.log(input);
	dateDiff(today,input);
	return input;
    
  };
  
});

myApp.directive('onlyNumbers', function () {
    return  {
        restrict: 'A',
        link: function (scope, elm, attrs, ctrl) {
            elm.on('keydown', function (event) {
                if(event.shiftKey){event.preventDefault(); return false;}
                //console.log(event.which);
                if ([8, 13, 27, 37, 38, 39, 40].indexOf(event.which) > -1) {
                    // backspace, enter, escape, arrows
                    return true;
                } else if (event.which >= 48 && event.which <= 57) {
                    // numbers 0 to 9
                    return true;
                } else if (event.which >= 96 && event.which <= 105) {
                    // numpad number
                    return true;
                } 
                // else if ([110, 190].indexOf(event.which) > -1) {
                //     // dot and numpad dot
                //     return true;
                // }
                else {
                    event.preventDefault();
                    return false;
                }
            });
        }
    }
});

function dateDiff(dt1, dt2)
{
    /*
     * setup 'empty' return object
     */
	 var t = dt2.split(/[- :]/);
	 console.log(t);
	 var dt2 = new Date(t[0], t[1]-1, t[2], t[3], t[4], t[5]);
	 console.log(dt1,dt2);
     var ret = {days:0, months:0, years:0};

    /*
     * If the dates are equal, return the 'empty' object
     */
    if (dt1 == dt2) return ret;

    /*
     * ensure dt2 > dt1
     */
    if (dt1 > dt2)
    {
        var dtmp = dt2;
        dt2 = dt1;
        dt1 = dtmp;
    }

    /*
     * First get the number of full years
     */

    var year1 = dt1.getFullYear();
    var year2 = dt2.getFullYear();

    var month1 = dt1.getMonth();
    var month2 = dt2.getMonth();

    var day1 = dt1.getDate();
    var day2 = dt2.getDate();

    /*
     * Set initial values bearing in mind the months or days may be negative
     */

    ret['years'] = year2 - year1;
    ret['months'] = month2 - month1;
    ret['days'] = day2 - day1;

    /*
     * Now we deal with the negatives
     */

    /*
     * First if the day difference is negative
     * eg dt2 = 13 oct, dt1 = 25 sept
     */
    if (ret['days'] < 0)
    {
        /*
         * Use temporary dates to get the number of days remaining in the month
         */
        var dtmp1 = new Date(dt1.getFullYear(), dt1.getMonth() + 1, 1, 0, 0, -1);

        var numDays = dtmp1.getDate();

        ret['months'] -= 1;
        ret['days'] += numDays;

    }

    /*
     * Now if the month difference is negative
     */
    if (ret['months'] < 0)
    {
        ret['months'] += 12;
        ret['years'] -= 1;
    }

    return ret;
}



