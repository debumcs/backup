myApp.controller('assignCarrierCtrl', function($scope,$http) {
	
	$scope.pageTitle = "Assign Carrier";
	$scope.errorMsg = '';
	$scope.assignData = {};
	$scope.showMsgs = false;
	$scope.carrierDetails = false;
	$scope.showAssignedCarriers = false;
	$scope.carrierList = true;
	
	$scope.orderno = document.getElementById("orderNo").value;
	
	$scope.carrierInfo = {};
	$scope.assignedCarrier = {};
	
	//$scope.IsCreateOrder = true;
	$scope.editorEnabled = false;
	
	$scope.assignSummary = function(){
		$scope.editorEnabled = true;
	}
		
	$scope.assignForm = function(){
		$scope.editorEnabled = false;
	}
	
	$scope.getProInfo = function(accountId){
		//console.log($scope.orderData);
		$http({
			method : 'GET',
			url : appBaseUrl + '/Orders/getAccountById/'+accountId
		}).success(function(response){	
			console.log(response);
			$scope.carrierInfo = response.responseObject;
		});		
		$scope.carrierDetails = true;
		$scope.carrierList = false;
	};
	
	$scope.showProList = function(){
		$scope.carrierDetails = false;
		$scope.carrierList = true;
	};
	
	$scope.assignCarrier = function(carrierInfo){
		$scope.assignedCarrier = {};
		$scope.assignedCarrier = carrierInfo;
		
		$scope.assignData.accountNumber = $scope.assignedCarrier.accountId;
		$scope.assignData.orderNumber = $scope.orderno;
		
		$scope.showAssignedCarriers = true;
	};
	
	$scope.assignOrder = function(){
		//alert($scope.assignData.accountNumber);
		$http({
			method : 'POST',
			url : appBaseUrl + '/AssignCarrier/assigned_carrier',
			data : $.param($scope.assignData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response) {	
			console.log(response);
			
			if(response.responseStatusCode == 200){
				window.location = appBaseUrl + '/AssignCarrier/assign_order_confirm/' + response.responseObject.orderNumber;
			}else{
				$scope.errorMsg = response.responseMessage;
			}	
		});
		
	};
	
});