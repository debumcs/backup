myApp.controller('createRoleCtrl', function($scope,$http) {
	
	$scope.pageTitle = "Create Role";
	$scope.errorMsg = '';
	$scope.accountTypes = [];
	$scope.roleTypes = [];
	$scope.modulesList = [];
	$scope.roleForm = {};
	$scope.submitted = false;
	
	$scope.editorEnabled = false;
	
	//alert("alert");
	
	$http.get(appBaseUrl + '/Common/get_account_type').success(function(response){
		$scope.accountTypes = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Common/get_modulesList').success(function(response){
		console.log(response.responseObject);
		$scope.modulesList = response.responseObject;
	});

	$scope.reset = function(){
		$scope.roleData = {};
	}
	
	$scope.createRole = function(){
		$scope.submitted = true;
		
		/*if($scope.roleForm.$valid) {
			$http({
				method : 'POST',
				url : appBaseUrl + '/Users/create_user',
				data : $.param($scope.userData),
				headers: {'Content-Type': 'application/x-www-form-urlencoded'}
			}).success(function(response) {	
				
				if(response.responseStatusCode == 200){
					window.location = appBaseUrl + '/Users/user_confirm/' + response.responseObject.userId;
				}else{
					$scope.errorMsg = response.responseMessage;
				}			
			});
		}*/
	};
	
});