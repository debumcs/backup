myApp.controller('editRoleCtrl', function($scope,$http,$filter) {
	
	$scope.pageTitle = "Edit User";
	$scope.userData = {};
	$scope.errorMsg = '';
	$scope.allStatus = null;
	$scope.roleTypes = null;
	
	$scope.userInfo = null;
	$scope.userNumber = document.getElementById("userNo").value;
	
	$http.get(appBaseUrl + '/Common/get_role_list').success(function(response){
		$scope.roleTypes = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Common/get_user_status').success(function(response){
		$scope.allStatus = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Users/getUserById/'+$scope.userNumber).success(function(response){
		
		$scope.userInfo = response.responseObject;
		console.log(response.responseObject);
		
		$scope.userData.userId 			= $scope.userInfo.userId;
		$scope.userData.accountId		= $scope.userInfo.accountId;
		$scope.userData.userName 		= $scope.userInfo.userName;
		$scope.userData.employeeNumber 	= $scope.userInfo.employeeNumber;
		$scope.userData.firstName 		= $scope.userInfo.firstName;
		$scope.userData.lastName 		= $scope.userInfo.lastName;
		$scope.userData.email			= $scope.userInfo.email;
		$scope.userData.phoneNumber		= $scope.userInfo.phoneNumber;
		$scope.userData.roleId			= $scope.userInfo.roleId;
		$scope.userData.userStatus		= $scope.userInfo.userStatus;
		
	});
	
	$scope.updateUser = function(){
		//console.log($scope.userData.orderNumber);
		$http({
			method : 'POST',
			url : appBaseUrl + '/Users/update_user',
			data : $.param($scope.userData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response) {	
			console.log(response);
			
			if(response.responseStatusCode == 200){
				window.location = appBaseUrl + '/Users/user_confirm/' + response.responseObject.userId;
			}else{
				$scope.errorMsg = response.responseMessage;
			}			
		});
		
	};
	
});