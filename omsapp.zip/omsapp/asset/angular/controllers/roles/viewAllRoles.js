myApp.controller('viewAllRoles', function($scope,$http) {
	
	$scope.pageTitle = "View All Roles";
	$scope.errorMsg = '';
	
	$scope.accountTypes = [];
	$scope.allUserStatus = [];
	$scope.allRoleList = [];
	
	$http.get(appBaseUrl + '/Common/get_account_type').success(function(response){
		$scope.accountTypes = response.responseObject;
	});
	
	$scope.dtOptions = { retrieve: true, paging:false, searching:false, info:false, scrollY:'550px',scrollX: true };
	
	$http.get(appBaseUrl + '/Common/get_user_status').success(function(response){
		$scope.allUserStatus = response.responseObject;
	});
		
	$scope.getRoledata = function(){
		
		$http({
			method : 'POST',
			url : appBaseUrl + '/Roles/getAllRoles',
			data : $.param($scope.roleData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		  }).success(function(response){	
			console.log(response);
			$scope.allRoleList = response.responseObject;
		});
		
	};
});