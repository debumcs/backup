myApp.controller('assetSearchCtrl', function($scope,$http){
	
	$scope.pageTitle = "Asset Search";
	$scope.errorMsg = '';
	
	$scope.allLocationList 	= [];
	$scope.locationTypes 	= [];
	
	$scope.submitted = false;
	
	$scope.editorEnabled = false;
	
	$http.get(appBaseUrl + '/Common/get_location_type').success(function(response){
		$scope.locationTypes = response.responseObject;
	});
	
	$scope.getLocationList = function(){
		
		$http({
			method : 'POST',
			url : appBaseUrl + '/Accounts/getAllLocations',
			data : $.param($scope.accountData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response){	
			console.log(response);
			$scope.allLocationList = response.responseObject;
		});
		
	};
	
	$scope.createOrderAssetSearch = function(){
		
		$http({
			method : 'POST',
			url : appBaseUrl + '/Accounts/post_account',
			data : $.param($scope.accountData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response) {	
			console.log(response);
			if(response.responseStatusCode == 200){
				window.location = appBaseUrl + '/Accounts/account_confirm/' + response.responseObject.accountId;
			}else{
				$scope.errorMsg = response.responseMessage;
			}			
		});
	};
	
});