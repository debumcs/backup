myApp.controller('viewAllProducts', function($scope,$http) {
	
	$scope.pageTitle = "View All Orders";
	$scope.errorMsg = '';
	$scope.allSKUTypes = [];
	
	$scope.allProductList = [];
	
	$http.get(appBaseUrl + '/Common/get_sku_type').success(function(response){
		$scope.allSKUTypes = response.responseObject;
	});
	
	$scope.cust_search_fields = function () {
		$scope.IsCustSearchFieldsVisible = $scope.IsCustSearchFieldsVisible ? false : true;
	}
		
	$scope.showAllProducts = function(){
		
		$http({
			method : 'POST',
			url : appBaseUrl + '/Products/getAllProducts',
			data : $.param($scope.products),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response){	
			console.log(response);
			$scope.allProductList = response.responseObject;
		});
		
	};
});