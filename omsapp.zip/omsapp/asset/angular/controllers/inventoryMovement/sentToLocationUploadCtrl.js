myApp.controller('sentToLocationUploadCtrl', function($scope,$http) {
	
	$scope.pageTitle = "Add Product";
	$scope.errorMsg = '';
	
	$scope.allAccountStatus = [];
	$scope.allAccountList = [];
	$scope.productData = {};
	$scope.submitted = false;
	$scope.token='';
	$scope.showUploadForm = false;
	
	
	$scope.orderSummary = function(){
		$scope.editorEnabled = true;
	}
	
	$scope.showForm = function(){
		$scope.showUploadForm = true;
	}
	
	$scope.uploadFile = function(){
		//alert("hi");	
		var token = document.getElementById('tokennu').value;
		//console.log(token);
		var formData = new FormData();
		var files = document.getElementById('filename').files[0];
		
		formData.append('file',files);
		$http({
			method : 'POST',
			url: 'http://14.143.158.230/api/v1/uploads/createInventory',
			data : formData,
			headers: {
				'Content-Type' : undefined,
				'Device-Type' : 'Web',
				'VER' : '1.0',
				'Auth-Token' : token
			}
		}).success(function(response){	
			console.log(response);
			if(response.responseStatusCode == 200){
	        	  $scope.sucessmesg = 'File Uploaded Sussessfully!!';
			}
		}).error(function(response){
           console.log(response);

					$scope.errorMsg = response.responseMessage;
			
		});
	

		
	}
	
});