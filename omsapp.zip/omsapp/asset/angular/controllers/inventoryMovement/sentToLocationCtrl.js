myApp.controller('sentToLocationCtrl', function($scope,$http) {
	
	$scope.pageTitle = "Add Product";
	$scope.errorMsg = '';
	$scope.skuHeaderTitle = '';
	$scope.allAccountStatus = [];
	$scope.allAccountList = [];
	
	$scope.successData = [];
	
	$scope.sentToLocData = {};
	$scope.sentToLocObject = {};
	$scope.submitted = false;
	$scope.skuqty = false;
	$scope.showShipToList = false;
	$scope.IsSuccessHide = false;
	
	$http.get(appBaseUrl + '/Common/get_location_type').success(function(response){
		$scope.locationTypes = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Common/get_account_type').success(function(response){
		$scope.accountTypes = response.responseObject;
	});
	
	$scope.accountOptions = { retrieve: true, paging:false, searching:false, info:false, scrollX: true, language:{emptyTable: "No Records found..!"}};
	
	$scope.dealerOptions = { retrieve: true, paging:false, searching:false, info:false, scrollY:'550px', scrollX: true, language:{emptyTable: "No Records found..!"}};
	
	
	$scope.IsLocationDetailsVisible = false;
	
	//api/v1/inventory/getShipTo
	
	$scope.getShipTo = function(){
		
		$http({
			method : 'POST',
			url : appBaseUrl + '/InventoryMovement/GetShipTo',
			data : $.param($scope.sentToLocData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response){	
			console.log(response);
			$scope.allShipToList = response.responseObject;
		});
	};
	
	$scope.getAllAccounts = function(){
		$scope.showAccountList = true;
		
		$http({
			method : 'POST',
			url : appBaseUrl + '/InventoryMovement/ShipFromInventoryMovement',
			data : $.param($scope.sentToLocData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response){	
			console.log(response);
			$scope.allAccountList = response.responseObject;
		});
		
		
	};
	
	$scope.showHideSerialNoBox = function(num) {
		
		//return x;
	}
	
	$scope.getNumber = function(num) {
		
		var x=new Array(); 
		for(var i=0;i<num;i++)
		{ 
			x.push(i+1); 
		} 
		return x; 
	}
	
	$scope.selectAccountLocation = function(account){
		
		$scope.showShipToList = true;
		$scope.IsLocationDetailsVisible = true;
		
		console.log(account);
		
		///$scope.sentToLocData.headSkuNumber = [];
		//$scope.sentToLocData.skuNumber = [];
		$scope.sentToLocObject = {};
		$scope.selectedAccount = {};
		$scope.selectedAccount = account;
		
		$scope.sentToLocData.shipFromAssociationId	= account.associationId;
		$scope.sentToLocData.shipFromAccountId		= account.accountId;
		$scope.sentToLocData.shipFromLocationId		= account.locationId;
		
		$http({
			method : 'POST',
			url : appBaseUrl + '/InventoryMovement/GetShipTo',
			data : $.param($scope.sentToLocData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response){	
			console.log(response);
			$scope.allShipToList = response.responseObject;
		});
		
		//alert($scope.sentToLocData.shipFromAssociationId+$scope.sentToLocData.shipFromAccountId+$scope.sentToLocData.shipFromLocationId);
	}
	
	$scope.productSummary = function(){
		
		$scope.submitted = true;
		
		if($scope.productForm.$valid) {
			$scope.editorEnabled = true;
			$scope.proSKUType = false;
			$scope.showAccountList = false;
		}
		
	};
	
	$scope.showProductForm = function(){
		$scope.submitted = false;
		$scope.editorEnabled = false;
		$scope.proSKUType = true;
		$scope.showAccountList = true;
	};
	
	/*$scope.showAccountDetails = function(accountId){
		$scope.proFormElement = false;
		$scope.allSKUBySkuType = [];
		$scope.productData.accountType = '';
		$scope.productData.accountNumber = '';
		$scope.productData.accountName = '';
		
		$scope.proSKUType = true;
		$http({
			method : 'GET',
			url : appBaseUrl + '/Products/getAccountById/'+accountId
		}).success(function(response){	
			$scope.productData.accountType = response.responseObject.accountTypeDetails.accountType;
			$scope.productData.accountNumber = response.responseObject.accountId;
			$scope.productData.accountName = response.responseObject.companyName;
		});
	};
	
	$scope.showAccountDetailsModal = function(accountId){
		$scope.proSKUType = true;
		$http({
			method : 'GET',
			url : appBaseUrl + '/Products/getAccountById/'+accountId
		}).success(function(response){
			console.log(response.responseObject);
			$scope.accountDetailsModal = response.responseObject;
		});
	};*/
	
	$scope.createSentToInventory = function(){
		$scope.sentToLocData.headSkuNumber 			= $scope.sentToLocObject.headSkuNumber;
		
		//console.log($scope.sentToLocObject);
		
		$scope.sentToLocData.shipToAccountId 		= $scope.sentToLocObject.shipToAccountId;
		$scope.sentToLocData.shipToAssociationId 	= $scope.sentToLocObject.shipToAssociationId;
		$scope.sentToLocData.shipToLocationId 		= $scope.sentToLocObject.shipToLocationId;
		$scope.sentToLocData.companyName 			= $scope.sentToLocObject.companyName;
		$scope.sentToLocData.shipToLocationName 	= $scope.sentToLocObject.shipToLocationName;
		$scope.sentToLocData.unitNumber 			= $scope.sentToLocObject.unitNumber;
		$scope.sentToLocData.referenceCode 			= $scope.sentToLocObject.referenceCode;
		$scope.sentToLocData.nickName 				= $scope.sentToLocObject.nickName;
		$scope.sentToLocData.cityName 				= $scope.sentToLocObject.cityName;
		$scope.sentToLocData.stateName 				= $scope.sentToLocObject.stateName;
		$scope.sentToLocData.skuNumber 				= $scope.sentToLocObject.skuNumber;
		$scope.sentToLocData.serialNumber 			= $scope.sentToLocObject.serialNumber;
		$scope.sentToLocData.shipDate 				= $scope.sentToLocObject.shipDate;

		
		$http({
			method : 'POST',
			url : appBaseUrl + '/InventoryMovement/create_sent_to_inventory',
			data : $.param($scope.sentToLocData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response) {	
			console.log(response);
			if(response.responseStatusCode == 600){
				$scope.errorMsg = response.responseObject;
			}
			if(response.responseStatusCode == 200){
				$scope.IsSuccessHide = true;
				$scope.showShipToList = false;
				$scope.successData = response.responseObject;
			}			
		});
	};
	
	
	
});