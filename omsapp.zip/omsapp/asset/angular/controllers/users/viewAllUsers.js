myApp.controller('viewAllUsers', function($scope,$http) {
	
	$scope.pageTitle = "View All Orders";
	$scope.errorMsg = '';
	
	$scope.allRole = null;
	$scope.allUserStatus = null;
	$scope.allUserList = null;
	
	$scope.dtOptions = { retrieve: true, paging:false, searching:false, info:false, scrollY:'550px',scrollX: true };
	
	$http.get(appBaseUrl + '/Common/get_user_status').success(function(response){
		$scope.allUserStatus = response.responseObject;
		console.log(response.responseObject);
	});
		
	$scope.getUserdata = function(){
		
		$http({
			method : 'POST',
			url : appBaseUrl + '/Users/getAllUsers',
			data : $.param($scope.userData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response){	
			console.log(response);
			$scope.allUserList = response.responseObject;
		});
		
	};
});