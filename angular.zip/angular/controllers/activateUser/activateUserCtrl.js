myApp.controller('activateUserCtrl', function($scope,$http) {
	
	$scope.pageTitle = "Login";
	$scope.errorMsg = '';
	$scope.responseStatusCode = '';
	$scope.submitted = false;
	$scope.userActivate = {};
	
	
	$scope.urlToken = document.getElementById("urlToken").value;
	$scope.userActivate.requestToken = $scope.urlToken;
	
	$scope.onSubmit = function(){
		
		$scope.submitted = true;
		
		if($scope.activateUserForm.$valid) {
			//alert('hi');
			$http({
				method : 'POST',
				url : appBaseUrl + '/ActivateUser/activate',
				data : $.param($scope.userActivate),
				headers: {'Content-Type': 'application/x-www-form-urlencoded'}
			}).success(function(response){
				console.log(response);
				$scope.userActivate = {};
				
				$scope.submitted = false;
				$scope.responseStatusCode = response.responseStatusCode;
				$scope.errorMsg = response.responseMessage;
			
			});
			
			
		}
		
	};
	
});