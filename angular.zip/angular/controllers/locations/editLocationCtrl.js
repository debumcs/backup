myApp.controller('editLocationCtrl', function($scope,$http,$filter) {
	
	$scope.pageTitle = "Edit Location";
	$scope.accountData = {};
	$scope.errorMsg = '';
	
	$scope.editorEnabled = false;
	
	$scope.locationInfo = null;
	$scope.accountNumber = document.getElementById("accountid").value;
	
	$scope.pageTitle = "Create Account";
	$scope.errorMsg = '';
	$scope.accountTypes = null;
	$scope.locationTypes = null;
	$scope.allAccountStatus = null;
	$scope.allCountries = [];
	$scope.allStates = [];
	$scope.allCities = [];
	$scope.operationalHoursArr = [];
	$scope.temp = [];
	$scope.allLocationStatus = null;
	$scope.allLocationList = null;
	
	$scope.submitted = false;
	$scope.shortName = false;
	$scope.showMsgs = false;
	$scope.timeSelect = false;
	$scope.IsCustomLocFields = false;
	//$scope.IsCreateOrder = true;
	$scope.editorEnabled = false;
	
	$scope.order = { All: 0, Sunday: 1, Monday: 2, Tuesday: 3, Wednesday: 4, Thursday: 5, Friday: 6, Saturday: 7 };
	
	$scope.weekdaysviews = ["All","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

  	$scope.weekdays = [ "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" ];

	$scope.append_dayNg = function(day,startTime,endTime){

		if(day===null){return false;}

		if(day=="Select Day" || startTime==undefined || endTime==undefined){
			$scope.timeSelect = true;
			return false;	
		}else{
			$scope.timeSelect = false;
		}
		
	    if(day == 'All'){
	      for(i=0;i<$scope.weekdays.length;i++) { 
	        $scope.operationalHoursArr.push(
	        	{'dayarray' : $scope.weekdays[i], 'fromtimearray' : startTime, 'totimearray' : endTime}
	        );
	      }
	      $scope.weekdaysviews = [];
	    }else{
	      $scope.operationalHoursArr.push({'dayarray' : day, 'fromtimearray' : startTime, 'totimearray' : endTime});
	      $scope.removeWeekDay("All");
	      $scope.removeWeekDay(day);
	    }
	    console.log($scope.weekdaysviews);
	}

	$scope.removeWeekDay = function(opday){
	    for(var i=0; i < $scope.weekdaysviews.length; i++){
	      if($scope.weekdaysviews[i]==opday){
	        $scope.weekdaysviews.splice(i,1);
	      }
	    }
	}

	$scope.deleteOperationalDayNg = function(index,dayname) {
	    
	    $scope.weekdaysviews.push(dayname);

	    if($scope.weekdaysviews.length == 7 ){
	     	$scope.weekdaysviews.push("All");
	    }
	    
		$scope.operationalHoursArr.splice(index,1);

        $scope.weekdaysviews.sort(function (a, b){
			return $scope.order[a] - $scope.order[b];
		});
	}
	
	$http.get(appBaseUrl + '/Common/get_location_type').success(function(response){
		$scope.locationTypes = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Common/get_account_type').success(function(response){
		$scope.accountTypes = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Common/get_account_status').success(function(response){
		$scope.allAccountStatus = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Common/get_location_status').success(function(response){
		$scope.allLocationStatus = response.responseObject;
	});
	
	$scope.cust_search_fields = function () {
		$scope.IsCustSearchFieldsVisible = $scope.IsCustSearchFieldsVisible ? false : true;
	}

	$http.get(appBaseUrl + '/Common/get_country_list').success(function(response){
		$scope.allCountries = response.responseObject;
	});
	
	$scope.getStates = function(country){
		$http.get(appBaseUrl + '/Common/get_state_list/'+country).success(function(response){
			$scope.allStates = response.responseObject;
		});
	}

	$scope.getCities = function(state){
		$http.get(appBaseUrl + '/Common/get_city_list/'+state).success(function(response){
			$scope.allCities = response.responseObject;
		});
	}

	$scope.accountSummary = function(){
		$scope.submitted = true;
		if($scope.accountForm.$valid){
			$scope.editorEnabled = true;
		}
	}
	
	$scope.accountCreateForm = function(){
		$scope.editorEnabled = false;
		$scope.IsCustDataVisible = true;
		$scope.IsLocationDataVisible = true;
	}	
	
	$scope.appendShortName = function(accountType){
		if(accountType == 1){
			$scope.shortName = true;
		}else{
			$scope.shortName = false;
		}
	}
	
	
	$scope.getLocationList = function(){
		
		$http({
			method : 'POST',
			url : appBaseUrl + '/Accounts/getAllLocations',
			data : $.param($scope.accountData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response){	
			console.log(response);
			$scope.allLocationList = response.responseObject;
		});
		
	};
	
	$http.get(appBaseUrl + '/Accounts/getAccountById/'+$scope.accountNumber).success(function(response){
		$scope.locationInfo = response.responseObject;
		
		$scope.accountData.accountType 				= $scope.locationInfo.accountType;
		$scope.accountData.accountNumber 			= $scope.accountNumber;
		
		if($scope.locationInfo.accountType == '1'){
			$scope.shortName = true;
		}else{
			$scope.shortName = false;
		}
		$scope.accountData.accountStatus 			= $scope.locationInfo.accountStatus;
		$scope.accountData.accountTypeShortCode 	= $scope.locationInfo.accountTypeShortCode;
		$scope.accountData.referenceCode 			= $scope.locationInfo.referenceCode;
		$scope.accountData.companyName				= $scope.locationInfo.companyName;
		$scope.accountData.nickName					= $scope.locationInfo.nickName;
		$scope.accountData.addressLine1				= $scope.locationInfo.addressLine1;
		$scope.accountData.addressLine2				= $scope.locationInfo.addressLine2;
		$scope.accountData.country					= $scope.locationInfo.country;
		
		$http.get(appBaseUrl + '/Common/get_state_list/'+$scope.locationInfo.country).success(function(response){
			$scope.allStates = response.responseObject;
		});
		$scope.accountData.state					= $scope.locationInfo.state;
		
		$http.get(appBaseUrl + '/Common/get_city_list/'+$scope.locationInfo.state).success(function(response){
			$scope.allCities = response.responseObject;
		});
				
		$scope.accountData.city						= $scope.locationInfo.city;
		$scope.accountData.zipCode					= $scope.locationInfo.zipCode;
		$scope.accountData.businessPhone			= $scope.locationInfo.businessPhone;
		$scope.accountData.fax						= $scope.locationInfo.fax;
		$scope.accountData.contactEmail				= $scope.locationInfo.contactEmail;
		$scope.accountData.contactName				= $scope.locationInfo.contactName;
		$scope.accountData.contactPhone				= $scope.locationInfo.contactPhone;
		$scope.accountData.userName					= $scope.locationInfo.adminDetails.userName;
		$scope.accountData.userId					= $scope.locationInfo.adminDetails.userId;
		$scope.accountData.employeeNumber			= $scope.locationInfo.adminDetails.employeeNumber;
		$scope.accountData.firstName				= $scope.locationInfo.adminDetails.firstName;
		$scope.accountData.lastName					= $scope.locationInfo.adminDetails.lastName;
		$scope.accountData.email					= $scope.locationInfo.adminDetails.email;
		$scope.accountData.phoneNumber				= $scope.locationInfo.adminDetails.phoneNumber;
		$scope.allLocationList2						= $scope.locationInfo.associatedLocations;
		//console.log(response.responseObject);
		
		/*for(i=0;i<$scope.operationalHours.length;i++) { 
	        $scope.operationalHoursArr.push(
	        	{'dayarray' : $scope.weekdays[i], 'fromtimearray' : startTime, 'totimearray' : endTime}
	        );
	    }*/
		
		angular.forEach($scope.locationInfo.operationalHours, function(value, key){
			//if(value.day){
				$scope.operationalHoursArr.push({'dayarray' : value.day, 'fromtimearray' : '2019-02-28 '+ value.startTime, 'totimearray' : '2019-02-28 '+ value.endTime});
				$scope.removeWeekDay("All");
				$scope.removeWeekDay(value.day);
			//}
			console.log('day : ' + value.day+', fromtimearray : ' + '2019-02-28 '+ value.startTime + ', totimearray :' + '2019-02-28 '+ value.endTime);
		});
		console.log(response.responseObject);
	});
	
	$scope.updateLocation = function(){
		//console.log($scope.orderData.orderNumber);
		$http({
			method : 'POST',
			url : appBaseUrl + '/Accounts/update_account',
			data : $.param($scope.accountData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response) {	
			console.log(response);
			
			if(response.responseStatusCode == 200){
				window.location = appBaseUrl + '/Accounts/account_confirm/' + response.responseObject.accountId;
			}else{
				$scope.errorMsg = response.responseMessage;
			}		
		});
		
	};
	
});