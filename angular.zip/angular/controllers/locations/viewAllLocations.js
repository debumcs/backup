myApp.controller('viewAllLocations', function($scope,$http) {
	
	$scope.pageTitle = "View All Locations";
	$scope.errorMsg = '';
	$scope.locationTypes = [];
	$scope.allLocationStatus = [];
	$scope.allLocationList = [];
	
	$scope.dtOptions = { paging:false, searching:false, info:false, scrollY:'550px' };
	
	$http.get(appBaseUrl + '/Common/get_location_type').success(function(response){
		$scope.locationTypes = response.responseObject;
	});
		
	$http.get(appBaseUrl + '/Common/get_location_status').success(function(response){
		$scope.allLocationStatus = response.responseObject;
	});
	
	
	
	$scope.cust_search_fields = function () {
		$scope.IsCustSearchFieldsVisible = $scope.IsCustSearchFieldsVisible ? false : true;
	}
		
	$scope.getLocationData = function(){
		
		$http({
			method : 'POST',
			url : appBaseUrl + '/Location2/getAllLocations',
			data : $.param($scope.locationData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response){	
			//console.log(response);
			$scope.allLocationList = response.responseObject;
		});
		
	};
});