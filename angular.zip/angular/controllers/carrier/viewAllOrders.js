myApp.controller('viewAllOrders', function($scope,$http) {
	
	$scope.pageTitle = "View All Orders";
	$scope.errorMsg = '';
	$scope.accountTypes = null;
	$scope.locationTypes = null;
	$scope.orderTypes = null;
	$scope.allOrderStatus = null;
	
	$scope.allOrderList = null;
	
	$scope.dtOptions = { paging:false, searching:false, info:false, scrollY:'550px' };
	
	$http.get(appBaseUrl + '/index.php/Common/get_location_type').success(function(response){
		$scope.locationTypes = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/index.php/Common/get_account_type').success(function(response){
		$scope.accountTypes = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/index.php/Common/get_order_type').success(function(response){
		$scope.orderTypes = response.responseObject;
		console.log($scope.orderTypes);
	});
	
	$http.get(appBaseUrl + '/index.php/Common/get_order_status').success(function(response){
		$scope.allOrderStatus = response.responseObject;
		console.log($scope.allOrderStatus);
	});
	
	$scope.cust_search_fields = function () {
		$scope.IsCustSearchFieldsVisible = $scope.IsCustSearchFieldsVisible ? false : true;
	}
		
	$scope.getAllOrders = function(){
		
		$http({
			method : 'POST',
			url : appBaseUrl + '/index.php/Orders/getAllOrders',
			data : $.param($scope.orderData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response){	
			console.log(response);
			$scope.allOrderList = response.responseObject;
		});
		
	};
});