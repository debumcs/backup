myApp.controller('cancelOrderCtrl', function($scope,$http) {
	
	$scope.pageTitle = "Edit Order";
	$scope.orderData = {};
	$scope.errorMsg = '';
	
	$scope.reasonDiv = false;
	$scope.cancelButton = true;
	$scope.IsCreateOrder = true;
	$scope.errorMsg = '';
	$scope.orderInfo = null;
	$scope.orderData.orderNumber = document.getElementById("orderNo").value;
	
	
	$scope.showReason = function(val){
		
		if(val == 'Yes'){
			$scope.reasonDiv = true;
			$scope.cancelButton = false;
		}else{
			$scope.orderData.reasonCancel = '';
			$scope.reasonDiv = false;
			$scope.cancelButton = true;
		}
		
	}
	
	$scope.cancelOrder = function(){
		
		$http({
			method : 'POST',
			url : appBaseUrl + '/index.php/Orders/cancel_order',
			data : $.param($scope.orderData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response) {	
			console.log(response);
			
			if(response.responseStatusCode == 200){
				window.location = appBaseUrl + '/index.php/index.php/Orders/view_order/' + $scope.orderData.orderNumber;
			}else{
				$scope.errorMsg = response.responseObject;
			}
		});
		
	};
	
});