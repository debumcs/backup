myApp.controller('createOrderCtrl', function($scope,$http) {
	
	$scope.pageTitle = "Create Order";
	$scope.errorMsg = '';
	$scope.accountTypes = null;
	$scope.locationTypes = null;
	$scope.orderTypes = null;
	$scope.allAccountStatus = null;
	$scope.allAccountList = null;
	$scope.billDetails = null;
	
	$scope.allLocationStatus = null;
	$scope.allLocationList = null;
	$scope.shipDetails = null;
	
	$scope.submitted = false;
	$scope.skuqty = false;
	
	$scope.showMsgs = false;
	$scope.IsLocationDataVisible = false;
	$scope.shiptodetails = false;
	$scope.IsCustSearchFieldsVisible = false;
	$scope.IsBillDetailsVisible = false;
	$scope.IsCustDataVisible = false;
	$scope.IsCustomLocFields = false;
	//$scope.IsCreateOrder = true;
	$scope.editorEnabled = false;
	
	$scope.accountOptions = { retrieve: true, paging:false, searching:false, info:false, scrollY:'200px',scrollX: true };
	$scope.locationOptions = { retrieve: true, paging:false, searching:false, info:false, scrollY:'200px',scrollX: true };
	
	$http.get(appBaseUrl + '/Common/get_location_type').success(function(response){
		$scope.locationTypes = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Common/get_account_type').success(function(response){
		$scope.accountTypes = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Common/get_order_type').success(function(response){
		$scope.orderTypes = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Common/get_account_status').success(function(response){
		$scope.allAccountStatus = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Common/get_location_status').success(function(response){
		$scope.allLocationStatus = response.responseObject;
	});
	
	$scope.cust_search_fields = function () {
		$scope.IsCustSearchFieldsVisible = $scope.IsCustSearchFieldsVisible ? false : true;
	}
	
	$scope.customLocField = function () {
		$scope.IsCustomLocFields = $scope.IsCustomLocFields ? false : true;
	}
	
	$scope.orderCreateForm = function(){
		$scope.editorEnabled = false;
		$scope.IsCustDataVisible = true;
		$scope.IsLocationDataVisible = true;
	}
	
	$scope.setTimePicker = function(){
		//alert(value);
		if($scope.orderData.requestedPickUpTime1 != ''){
			$scope.orderData.requestedPickUpTime2 = '';
		}
	}
	
	$scope.setTimePickerDropDown = function(){
		//alert(value);
		if($scope.orderData.requestedPickUpTime2 != ''){
			$scope.orderData.requestedPickUpTime1 = '';
		}
	}
	
	$scope.numberOnly = function(){
		const charCode = (event.which) ? event.which : event.keyCode;
		if (charCode > 31 && (charCode < 48 || charCode > 57)) {
			return false;
		}
		return true;
	}
	
	$scope.checkQuantity = function () {
		angular.forEach($scope.orderData.qty, function(value, key){
			
			if(value > 0){
				$scope.skuqty = true;
				return;
			}else{
				$scope.skuqty = false;
			}
		});
	}
	
	$scope.orderSummary = function(){
		
		$scope.submitted = true;
		
		if($scope.orderDataForm.$valid) {
			$scope.editorEnabled = true;
			$scope.IsCustSearchFieldsVisible = false;
			$scope.IsCustDataVisible = false;
			$scope.IsCustomLocFields = false;
			$scope.IsLocationDataVisible = false;
		}
		
	}
	
	$scope.getLocationList = function(){
		//console.log($scope.orderData);
		$scope.IsCustDataVisible = true;
		$http({
				method : 'POST',
				url : appBaseUrl + '/Orders/getAllLocations',
				data : $.param($scope.orderData),
				headers: {'Content-Type': 'application/x-www-form-urlencoded'}
			}).success(function(response){	
				console.log(response);
				$scope.allLocationList = response.responseObject;
				$scope.IsLocationDataVisible = true;
			});
		
	};
	
	$scope.shippingDetails = function(accountId){
		//console.log($scope.orderData);
		
		$http({
			method : 'GET',
			url : appBaseUrl + '/Orders/getLocationById/'+accountId
		}).success(function(response){	
			console.log(response);
			$scope.shipDetails = response.responseObject;
			$scope.shiptodetails = true;
			$scope.orderData.shipToLocation = $scope.shipDetails.addressLine1 + ' ' + $scope.shipDetails.addressLine2 +' '+ $scope.shipDetails.cityDetails.cityName +' '+ $scope.shipDetails.stateDetails.stateName +' '+$scope.shipDetails.zipCode;
		});
		
	};
	
	$scope.getAllAccounts = function(){
		
		$http({
			method : 'POST',
			url : appBaseUrl + '/Orders/getAllAccounts',
			data : $.param($scope.orderData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response){	
			console.log(response);
			$scope.allAccountList = response.responseObject;
			$scope.IsCustDataVisible = true;
		});
		
	};
	
	$scope.showbilltodetails = function(accountId){
		//console.log($scope.orderData);
		$http({
			method : 'GET',
			url : appBaseUrl + '/Orders/getAccountById/'+accountId
		}).success(function(response){	
			console.log(response);
			$scope.billDetails = response.responseObject;
			$scope.IsBillDetailsVisible = true;
			$scope.orderData.billToLocation = $scope.billDetails.addressLine1 + ' ' + $scope.billDetails.addressLine2 +' '+ $scope.billDetails.cityDetails.cityName +' '+ $scope.billDetails.stateDetails.stateName +' '+$scope.billDetails.zipCode;
		});
		
	};
	
	$scope.createOrder = function(){
		//console.log($scope.orderData);
		$http({
			method : 'POST',
			url : appBaseUrl + '/Orders/create_order',
			data : $.param($scope.orderData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response) {	
			console.log(response);
			//$window.location.href = 'http://localhost/omsapp/Orders/create_order_summary';
			if(response.responseStatusCode == 200){
				window.location = appBaseUrl + '/Orders/order_confirm/' + response.responseObject.orderNumber;
			}else{
				$scope.errorMsg = response.responseMessage;
			}			
		});
		
	};
	
});