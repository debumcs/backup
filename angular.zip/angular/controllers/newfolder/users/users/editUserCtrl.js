myApp.controller('editUserCtrl', function($scope,$http,$filter) {
	
	$scope.pageTitle = "Edit User";
	$scope.orderData = {};
	$scope.errorMsg = '';
	
	$scope.editorEnabled = false;
	
	$scope.orderInfo = null;
	$scope.ordNumber = document.getElementById("orderNo").value;
	
	$scope.orderCreateForm = function(){
		$scope.editorEnabled = false;
	}
	
	$scope.setTimePicker = function(){
		if($scope.orderData.requestedPickUpTime1 != ''){
			$scope.orderData.requestedPickUpTime2 = '';
		}
	}
	
	$scope.setTimePickerDropDown = function(){
		if($scope.orderData.requestedPickUpTime2 != ''){
			$scope.orderData.requestedPickUpTime1 = '';
		}
	}
	
	$scope.orderSummary = function(){
		$scope.editorEnabled = true;
	}
	
	
	$http.get(appBaseUrl + '/index.php/Orders/getOrderDetailsById/'+$scope.ordNumber).success(function(response){
		$scope.orderInfo = response.responseObject;
		console.log(response.responseObject);
		$scope.orderData.orderNumber = $scope.orderInfo.orderNumber;
		$scope.orderData.orderTypeDetails = $scope.orderInfo.orderTypeDetails.typeDesc;
		$scope.orderData.orderType = $scope.orderInfo.orderType;
		$scope.orderData.isRental = $scope.orderInfo.isRental;
		$scope.orderData.accountTypeDetails = $scope.orderInfo.accountInfo.accountTypeDetails.accountType;
		
		$scope.orderData.accountId = $scope.orderInfo.accountId;
		$scope.orderData.companyName = $scope.orderInfo.accountInfo.companyName;
		$scope.orderData.billToLocation = $scope.orderInfo.billToLocation;
		
		$scope.orderData.businessPhone = $scope.orderInfo.accountInfo.businessPhone;
		$scope.orderData.contactEmail = $scope.orderInfo.accountInfo.contactEmail;
		
		$scope.orderData.locationId = $scope.orderInfo.locationId;
		$scope.orderData.locationName = $scope.orderInfo.locationInfo.locationName;
		$scope.orderData.shipToLocation = $scope.orderInfo.shipToLocation;
		$scope.orderData.locBusinessPhone = $scope.orderInfo.locationInfo.businessPhone;
		$scope.orderData.locContactEmail = $scope.orderInfo.locationInfo.contactEmail;
		
		$scope.orderData.poNumber = $scope.orderInfo.poNumber;
		$scope.orderData.refNumber1 = $scope.orderInfo.referenceCol1;
		
		$scope.orderData.pickUpDueDate = $filter('date')($scope.orderInfo.pickUpDueDate, "MM/dd/yyyy");
		
		/*let dateAsString = $filter('date')($scope.orderInfo.pickUpDueDate, "MM/dd/yyyy"); 
		console.log(dateAsString);*/
		
		$scope.orderData.requestedPickupDate =  $filter('date')($scope.orderInfo.pickUpDate, "MM/dd/yyyy");
		$scope.orderData.refNumber2 = $scope.orderInfo.referenceCol2;
		
		if($scope.orderInfo.pickUpTime == 'Morning' || $scope.orderInfo.pickUpTime == 'Afternoon'){
			$scope.orderData.requestedPickUpTime1 = $scope.orderInfo.pickUpTime;
		}else{
			$scope.orderData.requestedPickUpTime1 = '';
		}
		
		if($scope.orderInfo.pickUpTime != 'Morning' || $scope.orderInfo.pickUpTime != 'Afternoon'){
			$scope.orderData.requestedPickUpTime2 = $scope.orderInfo.pickUpTime;
		}else{
			$scope.orderData.requestedPickUpTime2 = '';
		}
		$scope.orderData.instructions = $scope.orderInfo.instructions;
		
		$http({
			method : 'GET',
			url : appBaseUrl + '/index.php/Orders/getAccountById/'+$scope.orderInfo.accountId
		}).success(function(response){	
			$scope.billDetails = response.responseObject;
			$scope.billDetails.products = angular.copy($scope.orderInfo.orderComponents);
			console.log($scope.billDetails.products);			
		});
		
	});
	
	$scope.updateOrder = function(){
		//console.log($scope.orderData.orderNumber);
		$http({
			method : 'POST',
			url : appBaseUrl + '/index.php/Orders/update_order',
			data : $.param($scope.orderData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response) {	
			console.log(response);
			
			if(response.responseStatusCode == 200){
				window.location = appBaseUrl + '/index.php/Orders/order_confirm/' + response.responseObject.orderNumber;
			}else{
				$scope.errorMsg = response.responseMessage;
			}			
		});
		
	};
	
});