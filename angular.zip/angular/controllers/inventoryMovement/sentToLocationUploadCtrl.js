myApp.controller('sentToLocationUploadCtrl', function($scope,$http) {
	
	$scope.pageTitle = "Add Product";
	$scope.errorMsg = '';
	
	$scope.allAccountStatus = [];
	$scope.allAccountList = [];
	$scope.productData = {};
	$scope.submitted = false;
		
	$scope.uploadFile = function(){
		//alert("hi");	
		
		var formData = new FormData();
		var files = document.getElementById('filename').files[0];
		formData.append('filename',files);
		
		$http({
			method : 'POST',
			url: appBaseUrl + '/InventoryMovement/sentToLocationFileUpload',
			data : formData,
			headers: {'Content-Type': undefined}
		}).success(function(response){	
			console.log(response);
		});
		
	}
	
});