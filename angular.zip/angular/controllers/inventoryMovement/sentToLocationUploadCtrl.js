myApp.controller('sentToLocationUploadCtrl', function($scope,$http) {
	
	$scope.pageTitle = "Add Product";
	$scope.errorMsg = '';
	
	$scope.allAccountStatus = [];
	$scope.allAccountList = [];
	$scope.productData = {};
	$scope.submitted = false;
	$scope.skuqty = false;
	
	$scope.uploadSentToFile = function(){
		
	}
	
});