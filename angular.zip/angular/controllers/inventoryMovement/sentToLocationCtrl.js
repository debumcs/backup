myApp.controller('sentToLocationCtrl', function($scope,$http) {
	
	$scope.pageTitle = "Add Product";
	$scope.errorMsg = '';
	$scope.skuHeaderTitle = '';
	$scope.allAccountStatus = [];
	$scope.allAccountList = [];
	$scope.productData = {};
	$scope.submitted = false;
	$scope.skuqty = false;
	
	$scope.accountDetailsModal = null;
	
	$scope.showskulist = false;
	$scope.showMsgs = false;
	$scope.showAccountList = false;
	$scope.proSKUType = false;
	
	$scope.proFormElement = false;
	$scope.editorEnabled = false;
	
	$scope.dtOptions = { paging:false, searching:false, info:false, scrollY:'150px' };
	
	$http.get(appBaseUrl + '/Common/get_account_status').success(function(response){
		$scope.allAccountStatus = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Common/get_sku_type').success(function(response){
		$scope.allSKUTypes = response.responseObject;
	});
	
	$scope.uploadSentToFile = function(){
		
	}
	
	$scope.getAllAccounts = function(){
		$scope.showAccountList = true;
		$http({
			method : 'POST',
			url : appBaseUrl + '/Products/getAllAccounts',
			data : $.param($scope.productData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response){	
			console.log(response);
			$scope.allAccountList = response.responseObject;
		});
		
	};	
	
	
	
	$scope.productSummary = function(){
		
		$scope.submitted = true;
		
		if($scope.productForm.$valid) {
			$scope.editorEnabled = true;
			$scope.proSKUType = false;
			$scope.showAccountList = false;
		}
		
	};
	
	$scope.showProductForm = function(){
		$scope.submitted = false;
		$scope.editorEnabled = false;
		$scope.proSKUType = true;
		$scope.showAccountList = true;
	};
	
	$scope.showAccountDetails = function(accountId){
		$scope.proFormElement = false;
		$scope.allSKUBySkuType = [];
		$scope.productData.accountType = '';
		$scope.productData.accountNumber = '';
		$scope.productData.accountName = '';
		
		$scope.proSKUType = true;
		$http({
			method : 'GET',
			url : appBaseUrl + '/Products/getAccountById/'+accountId
		}).success(function(response){	
			$scope.productData.accountType = response.responseObject.accountTypeDetails.accountType;
			$scope.productData.accountNumber = response.responseObject.accountId;
			$scope.productData.accountName = response.responseObject.companyName;
		});
	};
	
	$scope.showAccountDetailsModal = function(accountId){
		$scope.proSKUType = true;
		$http({
			method : 'GET',
			url : appBaseUrl + '/Products/getAccountById/'+accountId
		}).success(function(response){
			console.log(response.responseObject);
			$scope.accountDetailsModal = response.responseObject;
		});
	};
	
	
	$scope.addProduct = function(){
		//console.log($scope.orderData);
		$http({
			method : 'POST',
			url : appBaseUrl + '/Products/create_product',
			data : $.param($scope.productData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response) {	
			console.log(response);
			//$window.location.href = 'http://localhost/omsapp/Orders/create_order_summary';
			if(response.responseStatusCode == 200){
				window.location = appBaseUrl + '/Products/product_confirm/' + response.responseObject.productId;
			}else{
				$scope.errorMsg = response.responseMessage;
			}
		});
	};
	
});