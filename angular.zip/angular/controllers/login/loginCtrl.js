myApp.controller('loginCtrl', function($scope,$http) {
	
	$scope.pageTitle = "Login";
	$scope.errorMsg = '';
	$scope.submitted = false;
	$scope.login = function(){
		$scope.submitted = true;
		
		if($scope.loginForm.$valid) {
			//alert('hi');
			$http({
				method : 'POST',
				url : appBaseUrl + '/Login/login_action',
				data : $.param($scope.loginData),
				headers: {'Content-Type': 'application/x-www-form-urlencoded'}
			}).success(function(response){
				console.log(response);
				if(response.responseStatusCode == 200){
					//window.localStorage.setItem('isLoggedIn', JSON.stringify(true));
					window.location = appBaseUrl + '/Dashboard/';
				}else{
					$scope.errorMsg = response.responseMessage;
				}
			});
			
			
		}
		
	};
	
});