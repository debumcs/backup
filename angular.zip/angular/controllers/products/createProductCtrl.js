myApp.controller('createProductCtrl', function($scope,$http) {
	
	$scope.pageTitle = "Add Product";
	$scope.errorMsg = '';
	$scope.skuHeaderTitle = '';
	$scope.allAccountStatus = null;
	$scope.allAccountList = null;
	$scope.allSKUTypes = null;
	$scope.allSKUBySkuType = null;
	$scope.productData = {};
	$scope.submitted = false;
	$scope.skuqty = false;
	
	$scope.accountDetailsModal = null;
	
	$scope.showskulist = false;
	$scope.showMsgs = false;
	$scope.showAccountList = false;
	$scope.proSKUType = false;
	
	$scope.proFormElement = false;
	$scope.editorEnabled = false;
	
	$scope.dtOptions = { retrieve: true, paging:false, searching:false, info:false, scrollY:'150px',scrollX: true };
	
	$http.get(appBaseUrl + '/Common/get_account_status').success(function(response){
		$scope.allAccountStatus = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Common/get_sku_type').success(function(response){
		$scope.allSKUTypes = response.responseObject;
	});
	
	$scope.cust_search_fields = function () {
		$scope.IsCustSearchFieldsVisible = $scope.IsCustSearchFieldsVisible ? false : true;
	}
	
	$scope.calculateNetWeight = function(qty,weight){
		
		$scope.skuqty = true;
		
		$scope.totalQuantity = 0;
		$scope.totalWeight = 0;
		
		angular.forEach($scope.productData.qty, function(value, key){
			$scope.totalQuantity = parseInt($scope.totalQuantity) + parseInt(+value);
			$scope.totalWeight = parseInt($scope.totalWeight) + parseInt(+$scope.productData.wgt[key]) * parseInt(+value);
		});
				
		$scope.productData.weight = $scope.totalWeight;
		$scope.productData.quantity = $scope.totalQuantity;
	}
	
	$scope.getAllAccounts = function(){
		$scope.showAccountList = true;
		$http({
			method : 'POST',
			url : appBaseUrl + '/Products/getAllAccounts',
			data : $.param($scope.productData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response){	
			console.log(response);
			$scope.allAccountList = response.responseObject;
		});
		
	};	
	
	$scope.showSKUType = function(SKUType){
		$scope.proFormElement = true;
		$scope.allSKUBySkuType = [];
		if(SKUType == 1){
			$scope.productData.skuTypeText = 'Component';
			$scope.skuHeaderTitle = '';
			$scope.showskulist = false;
		}
		
		if(SKUType == 2){
			$scope.productData.skuTypeText = 'Kit';
			$scope.showskulist = true;
			$scope.skuHeaderTitle = 'Component';
			
			$http({
				method : 'GET',
				url : appBaseUrl + '/Products/getAllSKUBySkuType/'+SKUType+'/'+$scope.productData.accountNumber
			}).success(function(response){	
				console.log(response);
				$scope.allSKUBySkuType = response.responseObject;
			});
			
		}
		
		if(SKUType == 3){
			$scope.productData.skuTypeText = 'Truck';
			$scope.showskulist = true;
			$scope.skuHeaderTitle = 'Kit/Component';
			
			$http({
				method : 'GET',
				url : appBaseUrl + '/Products/getAllSKUBySkuType/'+SKUType+'/'+$scope.productData.accountNumber
			}).success(function(response){	
				console.log(response);
				$scope.allSKUBySkuType = response.responseObject;
			});
		}
		$scope.productData.skuType = SKUType;		
	};
	
	$scope.productSummary = function(){
		
		$scope.submitted = true;
		
		if($scope.productForm.$valid) {
			$scope.editorEnabled = true;
			$scope.proSKUType = false;
			$scope.showAccountList = false;
		}
		
	};
	
	$scope.showProductForm = function(){
		$scope.submitted = false;
		$scope.editorEnabled = false;
		$scope.proSKUType = true;
		$scope.showAccountList = true;
	};
	
	$scope.showAccountDetails = function(accountId){
		$scope.proFormElement = false;
		$scope.allSKUBySkuType = [];
		$scope.productData.accountType = '';
		$scope.productData.accountNumber = '';
		$scope.productData.accountName = '';
		
		$scope.proSKUType = true;
		$http({
			method : 'GET',
			url : appBaseUrl + '/Products/getAccountById/'+accountId
		}).success(function(response){	
			$scope.productData.accountType = response.responseObject.accountTypeDetails.accountType;
			$scope.productData.accountNumber = response.responseObject.accountId;
			$scope.productData.accountName = response.responseObject.companyName;
		});
	};
	
	$scope.showAccountDetailsModal = function(accountId){
		$scope.proSKUType = true;
		$http({
			method : 'GET',
			url : appBaseUrl + '/Products/getAccountById/'+accountId
		}).success(function(response){
			console.log(response.responseObject);
			$scope.accountDetailsModal = response.responseObject;
		});
	};
	
	
	$scope.addProduct = function(){
		//console.log($scope.orderData);
		$http({
			method : 'POST',
			url : appBaseUrl + '/Products/create_product',
			data : $.param($scope.productData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response) {	
			console.log(response);
			//$window.location.href = 'http://localhost/omsapp/Orders/create_order_summary';
			if(response.responseStatusCode == 200){
				window.location = appBaseUrl + '/Products/product_confirm/' + response.responseObject.productId;
			}else{
				$scope.errorMsg = response.responseMessage;
			}
		});
	};
	
});