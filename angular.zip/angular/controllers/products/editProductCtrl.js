myApp.controller('editProductCtrl', function($scope,$http) {
	
	$scope.pageTitle = "Edit Order";
	
	$scope.errorMsg = '';
	$scope.skuHeaderTitle = '';
	
	$scope.productData = {};
	$scope.submitted = false;
	$scope.skuqty = true;
	$scope.allSKUBySkuType = [];
	
	$scope.accountDetailsModal = null;
	
	$scope.showskulist = false;
	$scope.showMsgs = false;
	$scope.showAccountList = false;
	$scope.proSKUType = false;
	
	$scope.productNumber = document.getElementById("productNumber").value;
	
	$scope.editorEnabled = false;
	
	$http.get(appBaseUrl + '/Products/getOrderDetailsById/'+$scope.productNumber).success(function(response){
		$scope.productInfo = response.responseObject;
		console.log(response.responseObject);
		
		$scope.productData.productId 		= $scope.productInfo.productId;
		$scope.productData.accountNumber 	= $scope.productInfo.accountId;
		$scope.productData.accountName		= $scope.productInfo.accountId;
		$scope.productData.skuTypeText 		= $scope.productInfo.skuTypeDetails.skuType;
		$scope.productData.skuType 			= $scope.productInfo.skuType;
		$scope.productData.skuNumber 		= $scope.productInfo.skuNumber;
		
		$scope.productData.description 		= $scope.productInfo.description;
		$scope.productData.length 			= $scope.productInfo.length;
		$scope.productData.width 			= $scope.productInfo.width;		
		$scope.productData.height 			= $scope.productInfo.height;
		
		if($scope.productData.skuType == 2){
			$scope.showskulist = true;
			$scope.skuHeaderTitle = 'Kit';
		}
		
		if($scope.productData.skuType == 3){
			$scope.showskulist = true;
			$scope.skuHeaderTitle = 'Kit/Component';
		}
		
		$scope.allSKUBySkuType				= $scope.productInfo.subComponents;
		
		$scope.productData.weight 			= $scope.productInfo.weight;
		$scope.productData.quantity 		= $scope.productInfo.quantity;
		$scope.productData.sequence 		= $scope.productInfo.sequence;
		$scope.productData.showInInventory 	= $scope.productInfo.showInInventory;
		$scope.productData.isSerialized 	= $scope.productInfo.isSerialized;
		
	});
	
	
	$scope.calculateNetWeight = function(qty,weight){
		
		$scope.skuqty = true;
		
		$scope.totalQuantity = 0;
		$scope.totalWeight = 0;
		
		angular.forEach($scope.productData.qty, function(value, key){
			$scope.totalQuantity = parseInt($scope.totalQuantity) + parseInt(+value);
			$scope.totalWeight = parseInt($scope.totalWeight) + parseInt(+$scope.productData.wgt[key]) * parseInt(+value);
		});
				
		$scope.productData.weight = $scope.totalWeight;
		$scope.productData.quantity = $scope.totalQuantity;
	}	
	
	$scope.productSummary = function(){
		
		$scope.submitted = true;
		
		if($scope.productForm.$valid) {
			$scope.editorEnabled = true;
			$scope.proSKUType = false;
			$scope.showAccountList = false;
		}
		
	};
	
	$scope.showProductForm = function(){
		$scope.submitted = false;
		$scope.editorEnabled = false;
		$scope.proSKUType = true;
		$scope.showAccountList = true;
	};

	$scope.updateProduct = function(){
		//console.log($scope.productData);
		$http({
			method : 'POST',
			url : appBaseUrl + '/Products/update_product',
			data : $.param($scope.productData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response) {	
			console.log(response);
			//$window.location.href = 'http://localhost/omsapp/Orders/create_order_summary';
			if(response.responseStatusCode == 200){
				window.location = appBaseUrl + '/Products/product_confirm/' + response.responseObject.productId;
			}else{
				$scope.errorMsg = response.responseMessage;
			}
		});
	};
	
});