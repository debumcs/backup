myApp.controller('assignProviderCtrl', function($scope,$http) {
	
	$scope.pageTitle = "Assign Provider";
	$scope.errorMsg = '';
	$scope.assignData = {};
	$scope.showMsgs = false;
	$scope.providerDetails = false;
	$scope.showAssignedProviders = false;
	$scope.providerList = true;
	
	$scope.orderno = document.getElementById("orderNo").value;
	//$scope.assignData.accountNumber = '';
	
	$scope.providerInfo = {};
	$scope.assignedProvider = {};
	
	//$scope.IsCreateOrder = true;
	$scope.editorEnabled = false;
	
	$scope.assignSummary = function(){
		$scope.editorEnabled = true;
	}
		
	$scope.editAssignForm = function(){
		$scope.editorEnabled = false;
	}
	
	$scope.getProInfo = function(accountId){
		//console.log($scope.orderData);
		$http({
			method : 'GET',
			url : appBaseUrl + '/index.php/Orders/getAccountById/'+accountId
		}).success(function(response){	
			console.log(response);
			$scope.providerInfo = response.responseObject;
		});		
		$scope.providerDetails = true;
		$scope.providerList = false;
	};
	
	$scope.showProList = function(){
		$scope.providerDetails = false;
		$scope.providerList = true;
	};
	
	$scope.assignProvider = function(providerInfo){
		$scope.assignedProvider = {};
		$scope.assignedProvider = providerInfo;
		
		$scope.assignData.accountNumber = $scope.assignedProvider.accountId;
		$scope.assignData.orderNumber = $scope.orderno;
		
		$scope.showAssignedProviders = true;
	};
	
	$scope.assignOrder = function(){
		//alert($scope.assignData.accountNumber);
		$http({
			method : 'POST',
			url : appBaseUrl + '/index.php/AssignProvider/assigned_provider',
			data : $.param($scope.assignData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response) {	
			console.log(response);
			
			if(response.responseStatusCode == 200){
				window.location = appBaseUrl + '/index.php/AssignProvider/assign_order_confirm/' + response.responseObject.orderNumber;
			}else{
				$scope.errorMsg = response.responseMessage;
			}	
		});
		
	};
	
});