myApp.controller('viewAllAccounts', function($scope,$http) {
	
	$scope.pageTitle = "View All Accounts";
	$scope.errorMsg = '';
	$scope.accountTypes = [];
	$scope.allAccountStatus = [];
	
	$scope.allAccountList = [];
	
	$scope.dtOptions = { paging:false, searching:false, info:false, scrollY:'550px' };
	
	$http.get(appBaseUrl + '/Common/get_account_type').success(function(response){
		$scope.accountTypes = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Common/get_account_status').success(function(response){
		$scope.allAccountStatus = response.responseObject;
		console.log(response.responseObject);
	});
	
	$scope.cust_search_fields = function () {
		$scope.IsCustSearchFieldsVisible = $scope.IsCustSearchFieldsVisible ? false : true;
	}
		
	$scope.getAccountdata = function(){
		
		$http({
			method : 'POST',
			url : appBaseUrl + '/Accounts/getAllAccounts',
			data : $.param($scope.accountData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response){	
			//console.log(response);
			$scope.allAccountList = response.responseObject;
		});
		
	};
});