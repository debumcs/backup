myApp.controller('createAccountCtrl', function($scope,$http) {
	
	$scope.pageTitle = "Create Account";
	$scope.errorMsg = '';
	$scope.accountTypes = null;
	$scope.locationTypes = null;
	$scope.allAccountStatus = null;
	$scope.allCountries = null;
	$scope.allStates = null;
	$scope.allCities = null;
	$scope.operationalHoursArr = [];
	$scope.temp = [];
	$scope.allLocationStatus = null;
	$scope.allLocationList = null;
	
	$scope.submitted = false;
	$scope.shortName = false;
	$scope.showMsgs = false;
	$scope.timeSelect = false;
	$scope.IsCustomLocFields = false;
	//$scope.IsCreateOrder = true;
	$scope.editorEnabled = false;
	
	
	
	$scope.order = { All: 0, Sunday: 1, Monday: 2, Tuesday: 3, Wednesday: 4, Thursday: 5, Friday: 6, Saturday: 7 };
	
	$scope.weekdaysviews = ["All","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];

  	$scope.weekdays = [ "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" ];

	$scope.append_dayNg = function(day,startTime,endTime){

		if(day===null){return false;}

		if(day=="Select Day" || startTime==undefined || endTime==undefined){
			$scope.timeSelect = true;
			return false;	
		}else{
			$scope.timeSelect = false;
		}
		
	    if(day == 'All'){
	      for(i=0;i<$scope.weekdays.length;i++) { 
	        $scope.operationalHoursArr.push(
	        	{'dayarray' : $scope.weekdays[i], 'fromtimearray' : startTime, 'totimearray' : endTime}
	        );
	      }
	      $scope.weekdaysviews = [];
	    }else{
	      $scope.operationalHoursArr.push({'dayarray' : day, 'fromtimearray' : startTime, 'totimearray' : endTime});
	      $scope.removeWeekDay("All");
	      $scope.removeWeekDay(day);
	    }
	    console.log($scope.weekdaysviews);
	}

	$scope.removeWeekDay = function(opday){
	    for(var i=0; i < $scope.weekdaysviews.length; i++){
	      if($scope.weekdaysviews[i]==opday){
	        $scope.weekdaysviews.splice(i,1);
	      }
	    }
	}

	$scope.deleteOperationalDayNg = function(index,dayname) {
	    
	    //alert(index+' '+dayname);

		$scope.weekdaysviews.push(dayname);

	    if($scope.weekdaysviews.length == 7 ){
	     	$scope.weekdaysviews.push("All");
	    }
	    //var index = $scope.operationalHoursArr.findIndex( record => record.dayarray == dayname );
	    
        $scope.operationalHoursArr.splice(index,1);

        $scope.weekdaysviews.sort(function (a, b){
			return $scope.order[a] - $scope.order[b];
		});
	}
	
	$http.get(appBaseUrl + '/Common/get_location_type').success(function(response){
		$scope.locationTypes = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Common/get_account_type').success(function(response){
		$scope.accountTypes = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Common/get_account_status').success(function(response){
		$scope.allAccountStatus = response.responseObject;
	});
	
	$http.get(appBaseUrl + '/Common/get_location_status').success(function(response){
		$scope.allLocationStatus = response.responseObject;
	});
	
	$scope.cust_search_fields = function () {
		$scope.IsCustSearchFieldsVisible = $scope.IsCustSearchFieldsVisible ? false : true;
	}

	$http.get(appBaseUrl + '/Common/get_country_list').success(function(response){
		$scope.allCountries = response.responseObject;
	});
	
	$scope.getStates = function(country){
		$http.get(appBaseUrl + '/Common/get_state_list/'+country).success(function(response){
			$scope.allStates = response.responseObject;
		});
	}

	$scope.getCities = function(state){
		$http.get(appBaseUrl + '/Common/get_city_list/'+state).success(function(response){
			$scope.allCities = response.responseObject;
		});
	}

	$scope.accountSummary = function(){
		$scope.submitted = true;
		if($scope.accountForm.$valid){
			$scope.editorEnabled = true;
		}
	}
	
	$scope.accountCreateForm = function(){
		$scope.editorEnabled = false;
		$scope.IsCustDataVisible = true;
		$scope.IsLocationDataVisible = true;
	}	
	
	$scope.appendShortName = function(accountType){
		if(accountType == 1){
			$scope.shortName = true;
		}else{
			$scope.shortName = false;
		}
	}
	
	$scope.showLocationDetailsModal = function(locationId){
		
		$http({
			method : 'GET',
			url : appBaseUrl + '/Accounts/getLocationById/'+locationId
		}).success(function(response){
			console.log(response.responseObject);
			$scope.locationDetailsModal = response.responseObject;
		});
	};
	
	$scope.getLocationList = function(){
		
		$http({
			method : 'POST',
			url : appBaseUrl + '/Accounts/getAllLocations',
			data : $.param($scope.accountData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response){	
			console.log(response);
			$scope.allLocationList = response.responseObject;
		});
		
	};
	
	$scope.reset = function() {
      $scope.accountData = {};
	  $scope.operationalHoursArr = [];
	  $scope.weekdaysviews = ["All","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
      $scope.accountForm.$setPristine();
    }
	
	$scope.createAccount = function(){
		////console.log($scope.orderData);
		$http({
			method : 'POST',
			url : appBaseUrl + '/Accounts/post_account',
			data : $.param($scope.accountData),
			headers: {'Content-Type': 'application/x-www-form-urlencoded'}
		}).success(function(response) {	
			console.log(response);
			//$window.location.href = 'http://localhost/omsapp/Orders/create_order_summary';
			if(response.responseStatusCode == 200){
				window.location = appBaseUrl + '/Accounts/account_confirm/' + response.responseObject.accountId;
			}else{
				$scope.errorMsg = response.responseMessage;
			}			
		});
		
	};
	
});