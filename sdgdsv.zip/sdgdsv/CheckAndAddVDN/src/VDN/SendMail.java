/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package VDN;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author qua06066
 */
public class SendMail 
{
    private static  String FROM = null;  
    private static  String TO = null;
    private static  String CC =null;
    private static  String BODY =null;
    private static  String SUBJECT =null;
    private static  String HOST =null;
    private static  int PORT =-1;
    private static SendMail objSendMail;
    private static final Object obj=new Object();
    
    private SendMail(){}
    
    public static SendMail getMailInstance(String strFrom,String strTo, String strCC, String strBody,String strSubject,String strHost, int intPort)
    {
        FROM=strFrom;BODY=strBody;PORT=intPort;
        TO=strTo;SUBJECT=strSubject;
        CC=strCC;HOST=strHost;
        if(objSendMail==null)
        {
            synchronized(obj)
            {
                if(objSendMail==null)
                    objSendMail=new SendMail();
            }
        }
        return objSendMail;
    }
    
    public void send()
    {
        try
        {
            Properties props = System.getProperties(); 
            props.put("mail.transport.protocol", "smtp");
            props.setProperty("mail.smtp.host", HOST);
            props.put("mail.smtp.port", PORT); 
            Session session = Session.getDefaultInstance(props);
            MimeMessage msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(FROM));

            String[] recipientList = TO.split(",");
            InternetAddress[] recipientAddress = new InternetAddress[recipientList.length];
            int counter = 0;
            for (String recipient : recipientList) 
            {
                recipientAddress[counter] = new InternetAddress(recipient.trim());
                counter++;
            }
            msg.setRecipients(Message.RecipientType.TO, recipientAddress);

            try
            {    
                String []recipientListCC = CC.split(",");
                recipientAddress = new InternetAddress[recipientListCC.length];
                counter = 0;
                for (String recipient : recipientListCC) 
                {
                    recipientAddress[counter] = new InternetAddress(recipient.trim());
                    counter++;
                }
                if(counter>0)
                    msg.setRecipients(Message.RecipientType.CC, recipientAddress);
            }catch(Exception errr){}
            
            msg.setRecipients(Message.RecipientType.BCC, "CTI.support@quatrro.com");
            msg.setSubject(SUBJECT);
            msg.setContent(BODY,"text/html");
            Transport transport = session.getTransport();
            try
            {
                Transport.send(msg, msg.getAllRecipients());
            }
            catch (Exception ex) 
            {

            }
            finally
            {
                transport.close();        	
            }
        }
        catch(Exception rtt)
        {
            System.out.println("Send Mail :"+rtt);
        }
    }       
}