/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package VDN;

/**
 *
 * @author qua06066
 */
import java.io.*;
import java.net.*;
import java.sql.DriverManager;
public class AddVdn 
{

    java.sql.Connection dataBaseConnection=null;
    java.sql.ResultSet dataBaseResultSet=null;
    java.sql.PreparedStatement dataBasePreparedStatement=null;
    SendMail objSendMail;
    public static void main(String[] args) throws Exception 
    {
        AddVdn objAddVdn=new AddVdn();
        objAddVdn.setVDN();
    }
    
    public void setVDN()
    {
        try
        {           
            URL url = new URL("http://qts:8081/CTIMonitoringAdmin/registerVdn.jsp");
            URLConnection connection = url.openConnection();
            connection.setDoOutput(true);
            OutputStreamWriter out = null;
            BufferedReader in = null;
            String strBody=null;
            int intCounter=0;
            connn(0);
            while(true)
            {    
                try
                {    
                    dataBasePreparedStatement=dataBaseConnection.prepareStatement("SELECT device_name FROM device_info WHERE device_type=? AND isexist=?");
                    dataBasePreparedStatement.setString(1, "VDN");
                    dataBasePreparedStatement.setInt(2, 0);
                    dataBaseResultSet=dataBasePreparedStatement.executeQuery();
                }catch(Exception e)
                {
                    if(e.getMessage()!=null)
                        connn(1);
                }
                
                while(dataBaseResultSet.next())
                {
                    try
                    {    
                        connection = url.openConnection();
                        connection.setDoOutput(true);
                        out = new OutputStreamWriter(connection.getOutputStream());
                        out.write("vdn_subvdn="+dataBaseResultSet.getString(1));
                        out.close();
                        in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                        in.close();

                    }
                    catch(Exception err)
                    {
                        System.out.println("setVDN Thread.sleep(3600000): "+err.getMessage());
                    }
                    out=null;
                    in=null;
                    connection=null;
                }
                 
                
                 strBody="";
                 intCounter=0;
                 dataBasePreparedStatement = dataBaseConnection.prepareStatement("SELECT * FROM device_info WHERE (device_name LIKE '2%' OR device_name LIKE '6%') AND LENGTH(device_name) = 5 AND isexist=?");
                 dataBasePreparedStatement.setInt(1, 0);
                 dataBaseResultSet = dataBasePreparedStatement.executeQuery();
                 while(dataBaseResultSet.next())
                 {
                     if(intCounter%2==0)
                        strBody=strBody+"<tr bgcolor='#DDDDDD'><td nowrap align='center'><span><font size='2'>"+(intCounter+1)+"</font></span></td><td nowrap align='center'><span><font size='2'>"+dataBaseResultSet.getString(1) +"</font></span></td><td nowrap align='center'><span><font size='2'>"+dataBaseResultSet.getString(2)+"</font></span></td></tr>";
                     else
                        strBody=strBody+"<tr bgcolor='#EEEEEE'><td nowrap align='center'><span><font size='2'>"+(intCounter+1)+"</font></span></td><td nowrap align='center'><span><font size='2'>"+dataBaseResultSet.getString(1) +"</font></span></td><td nowrap align='center'><span><font size='2'>"+dataBaseResultSet.getString(2)+"</font></span></td></tr>"; 
                     intCounter++;
                 }
                 strBody= "<table border='0' style = 'Left: 8px; Top: 45px'>"
                 +"<tr bgcolor='#D6CBBD'>"
                 +"<td nowrap align='center' ><span><font color='#000000' size='3'><B>SrNo.</B></font></span></td>"        
                 +"<td nowrap align='center' ><span><font color='#000000' size='3'><B>Device Name</B></font></span></td>"
                 +"<td nowrap align='center' ><span><font color='#000000' size='3'><B>Device Type</B></font></span></td>"
                 +"</tr></tr>"
                 +strBody
                 +"</table>";
                 strBody="<table><tr><td>Hi Team,</td></tr><tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr><tr><td>Please find below the list of devices which are not exists into the AES ctiapp user, due to this CTI Application i.e. \"QTS\" does not able to add the observer on it , please add below mentioned devices into the  AES ctiapp user.</td></tr></table><BR/>"
                 +strBody+"<BR/><BR/><table><tr><td>Regards,</td></tr><tr><td>CTI Support Team</td></tr></table>";
                 if(intCounter>0)
                 {    
                    objSendMail=SendMail.getMailInstance("CTI.support@quatrro.com", "Voice.Support@quatrro.com", null, strBody, "Alert : Missing Devices in AES ctiapp User", "10.100.4.153", 25);
                    objSendMail.send();
                 }
                 strBody=null;
                 try{
                     Thread.sleep(3600000);
                 }catch(Exception err){
                     System.out.println("setVDN Thread.sleep(3600000): "+err.getMessage());
                 }
                 
                 try{
                     Thread.sleep(60000);
                 }catch(Exception err){
                     System.out.println("setVDN Thread.sleep(60000): "+err.getMessage());
                 }
            }
        }
        catch(Exception errr)
        {
            System.out.println("setVDN: "+errr.getMessage());
        }
    }
    
    private void connn(int i)
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            while(true)
            {
                try
                {
                    if(i==0)
                    {   
                        dataBaseConnection=DriverManager.getConnection("jdbc:mysql://10.100.4.142:3306/jtapi", "ctiuser","cti@4321");                        
                        break;
                    }
                    else
                    {
                        dataBaseConnection=DriverManager.getConnection("jdbc:mysql://10.100.4.142:3306/jtapi", "ctiuser","cti@4321");
                        dataBasePreparedStatement=dataBaseConnection.prepareStatement("SELECT device_name FROM device_info WHERE device_type=? AND isexist=?");
                        dataBasePreparedStatement.setString(1, "VDN");
                        dataBasePreparedStatement.setInt(2, 0);
                        dataBaseResultSet=dataBasePreparedStatement.executeQuery();
                        break;
                    }    
                        
                }catch(Exception errr)
                {
                    Thread.sleep(60000);
                    System.out.println("connn: "+errr.getMessage());
                }
            }
        }catch(Exception err){
            System.out.println("connn: "+err.getMessage());
        }
    }
}