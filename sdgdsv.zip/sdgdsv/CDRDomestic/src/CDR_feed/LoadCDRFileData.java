package CDR_feed;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class LoadCDRFileData
{
  private static String CDRFilePath = "";
  private static String NewCDRFilePath = "";
  private static String UNCPath = "";
  private static String UNCuser = "";
  private static String DBconn = "";
  private static String user = "";
  private static String pwd = "";
  private static String Log4jPath = "";
  private static String LogPropPath = "";
  public static Logger logger = Logger.getLogger(LoadCDRFileData.class);
  
  public static void main(String[] args)
  {
    LoadCDRFileData app = new LoadCDRFileData();
    app.ReadConfigFile();
    
    PropertyConfigurator.configure(Log4jPath);
    try
    {
      importData();
    }
    catch (Exception err)
    {
      logger.info("exceptions 66= " + err.getMessage());
    }
  }
  
  public static void importData()
  {
    Connection connMysql = null;
    Statement stmt = null;
    File[] files = null;
    File dir = null;
    try
    {
      connMysql = getConnection();
      try
      {
        stmt = connMysql.createStatement(1005, 1008);
        try
        {
          System.out.println("CDRFilePath" + CDRFilePath);
          dir = new File(CDRFilePath);
          System.out.println("Directory = " + dir.isFile());
          if (dir.isDirectory())
          {
            logger.info("CDR File Count ---> " + dir.list().length + "\n");
            if (dir.list().length == 0)
            {
              logger.info("No file at the Location !!" + CDRFilePath + "\n"); return;
            }
            files = dir.listFiles();
            logger.info("Files -->" + Arrays.toString(files));
             Arrays.sort(files, new Comparator<File>() {
              @Override
              public int compare(File f1, File f2)
              {
                return Long.valueOf(f2.lastModified()).compareTo(Long.valueOf(f1.lastModified()));
              }
            });
          }
          else
          {
            logger.info("No file at the Location !" + CDRFilePath + "\n"); return;
          }
        }
        catch (Exception err)
        {
          logger.info("exception= 33 " + err.getMessage() + "\n");
        }
        String filePath = CDRFilePath;
        int intIndexOfLastFile = 0;
        String StrDtToAppInFileName = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
        String fname = "";
        logger.info("dir path ---->" + dir.getAbsoluteFile() + "\n");
        if (dir.isDirectory())
        {
          if (dir.list().length > 0)
          {
            logger.info("File Count -----> " + files.length + "\n");
            for (int index = files.length - 1; index >= 0; index--)
            {
              logger.info("<------------------------- START " + StrDtToAppInFileName + " ---------------------------->");
              String FileName = "";
              FileName = files[index].getName();
              logger.info("index File Number and Name ----> " + index + "File Name is --->" + FileName);
              if ((FileName.contains("CDR")) || (FileName.contains("cdr")) || (FileName.contains("Cdr")))
              {
                String query = "";
                query = " TRUNCATE TABLE temptxCDR";
                
                stmt.executeUpdate(query);
                logger.info("TRUNCATE TABLE temptxCDR Successfully\n");
                try
                {
                  query = "";
                  query = "LOAD DATA LOCAL INFILE '" + filePath + FileName + "' INTO TABLE temptxCDR " + "LINES TERMINATED BY '\\n';";
                  
                  logger.info("filePath..." + filePath);
                  logger.info("query444..." + query + "\n");
                  logger.info("Uploaded File Name --- >" + FileName);
                  stmt.executeUpdate(query);
                  
                  logger.info("Uploaded CDR File --- >" + FileName + "Successfully to temptxCDR table");
                }
                catch (SQLException er)
                {
                  er.printStackTrace();
                }
                query = "";
                query = "DELETE FROM temptxCDR WHERE LENGTH(CDRtext)<110;";
                logger.info("query4..." + query + "\n");
                stmt.executeUpdate(query);
                logger.info("Delete data WHERE LENGTH(CDRtext)<110 from temptxCDR Successfully");
                
                logger.info("Delete data WHERE LENGTH(CDRtext)<>127 from temptxCDR Successfully");
                
                query = "";
                query = "TRUNCATE TABLE tmp_tx_Cdr;";
                logger.info("query9..." + query + "\n");
                stmt.executeUpdate(query);
                logger.info("TRUNCATE TABLE tmp_tx_Cdr Successfully");
                
                query = "";
                query = "INSERT INTO tmp_tx_Cdr SELECT TRIM(CONCAT(DATE_FORMAT(STR_TO_DATE(SUBSTR(CDRtext,1,6), '%m%d%y'),'%Y-%m-%d'),' ', \nCONCAT(SUBSTR(CDRtext,8,2),':',SUBSTR(CDRtext,10,2), ':00'))) AS 'Row Date Time',\nTRIM(DATE_FORMAT(STR_TO_DATE(SUBSTR(CDRtext,1,6), '%m%d%y'),'%Y-%m-%d')) AS 'Row Date',\nTRIM(SUBSTR(CDRtext,8,4)) AS 'Row Time',\nTRIM(SUBSTR(CDRtext,13,5)) AS 'Duration',\nTRIM(SUBSTR(CDRtext,19,4)) AS 'Code Used',\nTRIM(SUBSTR(CDRtext,24,3)) AS 'Out CRT Id',\nTRIM(SUBSTR(CDRtext,28,4)) AS 'Code Dialed',\nTRIM(SUBSTR(CDRtext,32,23)) AS 'Called Number',\nTRIM(SUBSTR(CDRtext,56,13)) AS 'Auth Code',\nTRIM(SUBSTR(CDRtext,71,15)) AS 'Acct Code',\nTRIM(SUBSTR(CDRtext,86,15)) AS 'Extension',\nTRIM(SUBSTR(CDRtext,101,1)) AS 'Frl',\nTRIM(SUBSTR(CDRtext,103,3)) AS 'In CRT Id',\nTRIM(SUBSTR(CDRtext,108,15)) AS 'CLG Num',\nTRIM(SUBSTR(CDRtext,123,7)) AS 'VDN',\n'" + FileName + "' AS 'Fileid'\n" + "FROM temptxCDR";
                
                logger.info("query3..." + query);
                stmt.executeUpdate(query);
                logger.info("File " + FileName + " Uploaded successfully to tmp_tx_Cdr table" + "\n");
                
                query = "";
                query = "DELETE FROM tx_Cdr WHERE fileid='" + FileName + "'";
                logger.info("query111..." + query + "\n");
                stmt.executeUpdate(query);
                logger.info("Delete data WHERE WHERE fileid='" + FileName + "' from tx_Cdr Successfully");
                
                query = "";
                query = "INSERT INTO tx_Cdr SELECT DISTINCT * FROM tmp_tx_Cdr;";
                logger.info("query11..." + query + "\n");
                stmt.executeUpdate(query);
                logger.info("INSERT INTO tx_Cdr SELECT DISTINCT * FROM tmp_tx_Cdr Successfully");
                
                MoveCDRFile(FileName);
              }
              else
              {
                logger.info("File " + FileName + " was not Uploaded as it is not a CDR file2!!!!" + "\n");
                MoveCDRFile(FileName);
              }
            }
            logger.info("Total CDR files ----> " + files.length + "\n");
          }
          logger.info("No File at the Location !!! -----> " + CDRFilePath + "\n");
        }
        else
        {
          logger.info("No File at the Location !!!!-----> " + CDRFilePath + "\n");
        }
        stmt.close();
        connMysql.close();
      }
      catch (Exception e)
      {
        logger.info("exceptions 6= " + e.getMessage());
       
      }
      return;
    }
    catch (SQLException se)
    {
      logger.info("exceptions 7= " + se.getMessage());
    }
    catch (Exception e)
    {
      logger.info("exceptions 8= " + e.getMessage());
    }
    finally
    {
      try
      {
        connMysql.close();
      }
      catch (SQLException se)
      {
        logger.info("exceptions 9= " + se.getMessage());
      }
      try
      {
        connMysql.close();
      }
      catch (SQLException se)
      {
        logger.info("exceptions 10= " + se.getMessage());
      }
    }
  }
  
  public static void MoveCDRFile(String CDRFileName)
  {
    InputStream in = null;
    OutputStream out = null;
    String ProcessFile = "";
    try
    {
      String todayAsString = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
      try
      {
        ProcessFile = "ProcessedChrFiles_" + todayAsString;
        File theDir = new File(NewCDRFilePath + ProcessFile);
        if (!theDir.exists())
        {
          logger.info("creating directory: " + ProcessFile + "\n");
          logger.info("theDir: " + theDir + "\n");
          theDir.mkdir();
        }
        else
        {
          logger.info("directory: " + ProcessFile + "Already exists!!!!!" + "\n");
        }
      }
      catch (Exception e)
      {
        logger.info("exceptions 12= " + e.getMessage());
      }
      String NewLocCDRFiles = "";
      NewLocCDRFiles = NewCDRFilePath + ProcessFile;
      if ((CDRFileName.contains("CDR")) || (CDRFileName.contains("cdr")) ||  (CDRFileName.contains("Cdr")))
      {
        logger.info("CDRFilePath+CDRFileName" + CDRFilePath + CDRFileName + "\n");
        File oldFile = new File(CDRFilePath + CDRFileName);
        
        File newFile = new File(NewLocCDRFiles + "/" + CDRFileName);
        in = new FileInputStream(oldFile);
        out = new FileOutputStream(newFile);
        byte[] moveBuff = new byte['?'];
        int butesRead;
        while ((butesRead = in.read(moveBuff)) > 0) {
          out.write(moveBuff, 0, butesRead);
        }
        in.close();
        out.close();
        oldFile.delete();
        logger.info("The File was successfully moved to the folder---> " + NewLocCDRFiles + "\n");
        logger.info("<------------------------- END ---------------------------->");
      }
      else
      {
        logger.info("Not a CDR file ");
        try
        {
          String UnprocessedFileName = "";
          UnprocessedFileName = "UnProcessedChrFiles_" + todayAsString;
          File theDir = new File(NewCDRFilePath + UnprocessedFileName);
          if (!theDir.exists())
          {
            logger.info("creating directory: unProcessedChrFiles");
            theDir.mkdir();
          }
          else
          {
            logger.info("directory: unProcessedChrFiles Already exists!!!!!");
          }
          File oldFile = new File(CDRFilePath + CDRFileName);
          logger.info("NewCDRFilePath + CDRFileName" + NewLocCDRFiles + CDRFileName + "\n");
          File newFile = new File(NewCDRFilePath + "/" + UnprocessedFileName + "/" + CDRFileName);
          in = new FileInputStream(oldFile);
          out = new FileOutputStream(newFile);
          byte[] moveBuff = new byte['?'];
          int butesRead;
          while ((butesRead = in.read(moveBuff)) > 0) {
            out.write(moveBuff, 0, butesRead);
          }
          in.close();
          out.close();
          oldFile.delete();
          logger.info("The File was successfully moved to the folder ---> " + NewLocCDRFiles + "\n");
        }
        catch (Exception e)
        {
          logger.info("exceptions 16= " + e.getMessage());
        }
      }
    }
    catch (IOException e)
    {
      logger.info("exceptions 23= " + e.getMessage());
    }
  }
  
  private static Connection getConnection()
    throws Exception
  {
    Class.forName("com.mysql.jdbc.Driver");
    
    return DriverManager.getConnection(DBconn, user, pwd);
  }
  
  public static void createDateWiseDir(String directoryName)
  {
    File theDir = new File(directoryName);
    if (!theDir.exists())
    {
      logger.info("creating directory: " + directoryName + "\n");
      theDir.mkdir();
    }
    else
    {
      logger.info("directory: " + directoryName + "Already exists!!!!!" + "\n");
    }
  }
  
  private void ReadConfigFile()
  {
    Properties prop = new Properties();
    InputStream input = null;
    try
    {
      String filename = "config/config.properties";
      input = getClass().getClassLoader().getResourceAsStream(filename);
      if (input == null)
      {
        logger.info("Sorry, unable to find Configuration file :--> " + filename + "\n");
      }
      else
      {
        prop.load(input);
        
        CDRFilePath = prop.getProperty("CDRFilePath");
        
        UNCPath = prop.getProperty("UNCPath");
        UNCuser = prop.getProperty("UNCuser");
        DBconn = prop.getProperty("DBconn");
        user = prop.getProperty("user");
        pwd = prop.getProperty("pwd");
        NewCDRFilePath = prop.getProperty("NewCDRFilePath");
        LogPropPath = prop.getProperty("LogPropPath");
        Log4jPath = prop.getProperty("Log4jPath");
      }
      return;
    }
    catch (IOException ex)
    {
      logger.info("Exception" + ex.getMessage() + "\n");
    }
    finally
    {
      if (input != null) {
        try
        {
          input.close();
        }
        catch (IOException e)
        {
          logger.info("exceptions 36= " + e.getMessage());
        }
      }
    }
  }
}
