/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sendemailsmtptls;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import java.io.*;
import java.util.Arrays;

import java.util.*;
import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author p-fs0121
 */
public class SendEmailSMTPTLS {

    /**
     * @param args the command line arguments
     */
    public String FROM, TO,BCC, CC, HOST, PORT, DB, UserName, Password, FilePath, Log4jPath;
    
    //static Logger logger = Logger.getLogger(SendEmailSMTPTLS.class);
    
    public static void main(String[] args) {
        // TODO code application logic here
        SendEmailSMTPTLS obj = new SendEmailSMTPTLS();
        
        try {
            obj.sendmail();            
            //logger.info("Config file opened.\n");
            System.out.println("Email sent successfully.");
            System.exit(0);
        } catch (Exception e) {
            System.out.println("Could not send email "+e.getMessage());
            System.exit(0);
            //logger.warn("Could not open Config file. "+e.getMessage());
        }
    }
    
    public void sendmail()
    {
        try
        {  
            FROM="mukesh.kumar@quatrro.com";
            TO="p-fs0121@internal.quatrro.com";
            CC="p-iap0477@internal.quatrro.com";
            BCC="Brijesh.Maurya@quatrro.com, mukesh.kumar@quatrro.com";
            HOST="smtp.office365.com";
            PORT="587";
            
            String strBody = "";
            String strSubject = "Test Email";
            
            strBody="<html>"; 
            strBody+="<body>";
            strBody+= "<table border='0' cellspacing='2' width='60%' cellpadding='3' align='left' style='width:600px;text-align:left;border:solid 5px #C52622;'>";
            strBody+= "<tr><th colspan='2' style='padding:6px 15px;color:#C52622;font-weight:normal;text-align:left;background:#eeeeee;border:solid 1px #cccccc;'>Hi Team,</th></tr>";
            strBody+= "<tr><td colspan='2'>&nbsp;</td></tr>";
            strBody+= "<tr><td colspan='2' style='padding:5px 15px;font-size:11px;'>The scheduler run at and found the details given below : </td></tr>";
            strBody+= "<tr><td colspan='2'>&nbsp;</td></tr>";
            strBody+= "<tr><td colspan='2' style='padding:5px 15px;font-size:11px;'>Regards,</td></tr>";
            strBody+= "<tr><td colspan='2' style='padding:5px 15px;font-size:11px;'>CRM Support</td></tr>";
            strBody+= "<tr><td colspan='2'>&nbsp;</td></tr>";
            strBody+= "<tr><td colspan='2' style='padding:5px 15px;font-size:11px;'>&nbsp;</td></tr>";
            strBody+= "<tr><th colspan='2' style='color:#C52622;font-weight:normal;font-size:12px;text-align:center;background:#eeeeee;border:solid 1px #cccccc;'>";
            strBody+= "&nbsp;</td></tr>";
            strBody+= "</table>";
            strBody+="</body></html>";
            
            
            
            final String username = "mukesh.kumar@quatrro.com";//change accordingly
            final String password = "Passw0rd08067";//change accordingly
            
            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", HOST);
            props.put("mail.smtp.port", PORT);
            
            
            // Get the Session object.
            Session session = Session.getInstance(props,new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(username, password);
                }
            });
            
            // Create a default MimeMessage object.
            Message msg = new MimeMessage(session);
            
            
            // Set From: header field of the header.
            msg.setFrom(new InternetAddress(FROM));
            
            // Set To: header field of the header.
            String[] recipientList = TO.split(",");
            InternetAddress[] recipientAddress = new InternetAddress[recipientList.length];
            int counter = 0;
            for (String recipient : recipientList) 
            {
                recipientAddress[counter] = new InternetAddress(recipient.trim());
                counter++;
            }            
            msg.setRecipients(Message.RecipientType.TO, recipientAddress);

            // Set CC: header field of the header.
            String []recipientListCC = CC.split(",");
            recipientAddress = new InternetAddress[recipientListCC.length];
            counter = 0;
            for (String recipient : recipientListCC) 
            {
                recipientAddress[counter] = new InternetAddress(recipient.trim());
                counter++;
            }
            if(counter>0)
                msg.setRecipients(Message.RecipientType.CC, recipientAddress);
            
            // Set BCC: header field of the header.
            String []recipientListBCC = BCC.split(",");
            recipientAddress = new InternetAddress[recipientListBCC.length];
            counter = 0;
            for (String recipient : recipientListBCC) 
            {
                recipientAddress[counter] = new InternetAddress(recipient.trim());
                counter++;
            }
            if(counter>0)
                msg.setRecipients(Message.RecipientType.BCC, recipientAddress);
            
            // Set Subject: header field
            msg.setSubject(strSubject);
            
            // Set the actual message
            msg.setContent(strBody,"text/html");
            
            // Send message
            Transport.send(msg);
            System.out.println("Sent message successfully....");
            
        }catch(Exception rtt)
        {
            //System.out.println("Send Mail :"+rtt);
            //logger.warn("sendmail fn exceptions3 = " + rtt.getMessage());
            System.out.println("sendmail fn exceptions3 "+rtt.getMessage());
        }
    }
}