
package CDR_feed;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class testCDR
{
  public static void main(String[] argv)
    throws Exception
  {
    Class.forName("com.mysql.jdbc.Driver");
    Connection connection = DriverManager.getConnection("jdbc:mysql://10.100.4.50:3306/Reportdb", "root", "Saimaa#2010");
    Statement stmt = connection.createStatement();
    
    String filename = "C:/ECHICTI/CDR_File/cdr_output_19112011.txt";
    String tablename = "tempCDR";
    stmt.executeUpdate("LOAD DATA LOCAL INFILE \"" + filename + "\" INTO TABLE " + tablename);
  }
}
