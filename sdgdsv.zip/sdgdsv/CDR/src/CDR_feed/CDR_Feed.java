
package CDR_feed;

import java.io.File;
import java.io.FileFilter;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.FileFileFilter;
import org.apache.commons.io.filefilter.IOFileFilter;

public class CDR_Feed {
    public static void main(String[] args) {
        try {
            ArrayList<String> DBfileCnt = null;
            Connection connMysql = null;
            ResultSet dataBaseResultSet = null;
            connMysql = CDR_Feed.getConnection();
            Statement stmt = connMysql.createStatement(1005, 1008);
            String query = "";
            query = "SELECT DISTINCT(filename) FROM CDR_data WHERE DATE(SEGSTART)=DATE(NOW()) order by filename; ";
            System.out.println("Querry executed Successfully");
            dataBaseResultSet = stmt.executeQuery(query);
            DBfileCnt = new ArrayList<String>();
            while (dataBaseResultSet.next()) {
                DBfileCnt.add(dataBaseResultSet.getString(1));
            }
            System.out.println("listOfFiles " + DBfileCnt + "\n");
            System.out.println("count of files " + DBfileCnt.size());
            File directory = new File("C:\\shareDhruva");
            File[] files = directory.listFiles((FileFilter)FileFileFilter.FILE);
            System.out.println("Default order");
            Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_COMPARATOR);
            System.out.println("\nLast Modified Ascending Order (LASTMODIFIED_COMPARATOR)");
            CDR_Feed.displayFiles(files, DBfileCnt);
        }
        catch (Exception err) {
            System.out.println("exception= 11" + err.getMessage());
        }
    }

    public static void displayFiles(File[] files, List DBFileCnt) {
        try {
            String ModDate = "";
            int CurrentDateFileCnt = 0;
            String todayAsString = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
            String FileDate = "";
            System.out.printf("File count :" + files.length + "\n", new Object[0]);
            for (File file : files) {
                FileDate = new SimpleDateFormat("dd-MM-yyyy").format(new Date(file.lastModified()));
                if (!FileDate.equalsIgnoreCase(todayAsString)) continue;
                System.out.printf("File: %-20s Last Modified:" + new Date(file.lastModified()) + "\n", file.getName());
                System.out.printf("File name chr" + file.getName() + "\n", new Object[0]);
                ++CurrentDateFileCnt;
            }
            System.out.printf("Current File count :" + CurrentDateFileCnt + "\n", new Object[0]);
            System.out.printf("DB List File count :" + DBFileCnt.size() + "\n", new Object[0]);
        }
        catch (Exception err) {
            System.out.println("exception= 12" + err.getMessage());
        }
    }

    private static Connection getConnection() throws Exception {
        Class.forName("com.mysql.jdbc.Driver");
        return DriverManager.getConnection("jdbc:mysql://10.100.4.50:3306/Reportdb", "root", "Saimaa#2010");
    }
}