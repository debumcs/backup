/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cticallcheck;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.sql.*;  

import java.util.*;
import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author p-fs0121
 */
public class CTICallCheck {

    /**
     * @param args the command line arguments
     */
    public String DB, DBUser, DBPass, FROM, TO, CC, BCC, HOST, PORT, SMTPUser, SMTPPass, Log4jPath;
    static Logger logger = Logger.getLogger(CTICallCheck.class);
    
    public static void main(String[] args) {
        
        // TODO code application logic here
        CTICallCheck objCTI = new CTICallCheck();
        String html, strSubject = "Alert : Status on CTI Call updation in jtapi.disposition.";
        String logmsg = "";
        Date date = new Date();
        
        try {
            objCTI.ReadConfigFile();
            logger.info("Config file opened.\n");
            
            String CTIvalues[] = objCTI.checkLastEntryinDB();            
            
            if(Integer.parseInt(CTIvalues[0]) > 900){
            
                html="<html>"; 
                html+="<body>";
                html+= "<table border='0' cellspacing='2' width='60%' cellpadding='3' align='left' style='width:600px;text-align:left;border:solid 5px #C52622;'>";
                html+= "<tr><th colspan='2' style='padding:6px 15px;color:#C52622;font-weight:normal;text-align:left;background:#eeeeee;border:solid 1px #cccccc;'>Hi Team,</th></tr>";
                html+= "<tr><td colspan='2'>&nbsp;</td></tr>";
                html+= "<tr><td colspan='2' style='padding:5px 15px;font-size:11px;'>The scheduler run at date-time "+date+". The last data entered in database at "+CTIvalues[1]+". </td></tr>";
                
                
                logmsg+= "The scheduler run at date-time "+date+". The last data entered in database at "+CTIvalues[1]+".";
                
                html+= "<tr><td colspan='2'>&nbsp;</td></tr>";
                
                html+= "<tr><td colspan='2'>&nbsp;</td></tr>";
                html+= "<tr><td colspan='2' style='padding:5px 15px;font-size:11px;'>Regards,</td></tr>";
                html+= "<tr><td colspan='2' style='padding:5px 15px;font-size:11px;'>CRM Support</td></tr>";
                html+= "<tr><td colspan='2'>&nbsp;</td></tr>";
                html+= "<tr><td colspan='2' style='padding:5px 15px;font-size:11px;'>&nbsp;</td></tr>";
                html+= "<tr><th colspan='2' style='color:#C52622;font-weight:normal;font-size:12px;text-align:center;background:#eeeeee;border:solid 1px #cccccc;'>";
                html+= "&nbsp;<br/></td></tr>";
                html+= "</table>";
                html+="</body></html>";
            
                logger.info(logmsg);
                objCTI.sendmail(html, strSubject);
            }else{
                logger.info("Data entered in db on time.\n");
            }
            
            
        } catch (NullPointerException e) {
            logger.warn("Could not open Config file. "+e.getMessage());
            e.printStackTrace();
        }
	
    }
    
    public String[] checkLastEntryinDB() {
        PreparedStatement pst = null;
        ResultSet rs= null;
        String total = "0", lastntrydate = "";
        String[] returnValues = new String[]{total, lastntrydate};
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection(DB,DBUser,DBPass);
            String sql = "SELECT TIMESTAMPDIFF(SECOND,DATE,NOW()) AS seconds, date AS lastntrydate FROM jtapi.jtapi_dispostion ORDER BY DATE DESC LIMIT 1";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                if(rs.getInt("seconds")>0 ){
                    total           = rs.getString("seconds");
                    lastntrydate    = rs.getString("lastntrydate");                    
                    returnValues    =  new String[]{total, lastntrydate};
                    return returnValues;
                }else{
                    return returnValues;
                }
            }
            con.close();
        }
        catch(Exception e)
        { 
            logger.warn("function checkLastEntryinDB(), exceptions= " + e.getMessage());
            e.printStackTrace();
        }
        return returnValues;
    }
    
    public void sendmail(String strBody, String strSubject)
    {
        try
        {  
            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", HOST);
            props.put("mail.smtp.port", PORT);
            
            // Get the Session object.
            Session session = Session.getInstance(props,new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(SMTPUser, SMTPPass);
                }
            });
            
            // Create a default MimeMessage object.
            Message msg = new MimeMessage(session);
                        
            // Set From: header field of the header.
            msg.setFrom(new InternetAddress(FROM));
            
            // Set To: header field of the header.
            String[] recipientList = TO.split(",");
            InternetAddress[] recipientAddress = new InternetAddress[recipientList.length];
            int counter = 0;
            for (String recipient : recipientList) 
            {
                recipientAddress[counter] = new InternetAddress(recipient.trim());
                counter++;
            }            
            msg.setRecipients(Message.RecipientType.TO, recipientAddress);

            // Set CC: header field of the header.
            String []recipientListCC = CC.split(",");
            recipientAddress = new InternetAddress[recipientListCC.length];
            counter = 0;
            
            for (String recipient : recipientListCC) 
            {
                recipientAddress[counter] = new InternetAddress(recipient.trim());
                counter++;
            }
            
            if(counter>0)
                msg.setRecipients(Message.RecipientType.CC, recipientAddress);
            
            // Set BCC: header field of the header.
            String []recipientListBCC = BCC.split(",");
            recipientAddress = new InternetAddress[recipientListBCC.length];
            counter = 0;
            
            for (String recipient : recipientListBCC) 
            {
                recipientAddress[counter] = new InternetAddress(recipient.trim());
                counter++;
            }
            
            if(counter>0)
                msg.setRecipients(Message.RecipientType.BCC, recipientAddress);
            
            // Set Subject: header field
            msg.setSubject(strSubject);
            
            // Set the actual message
            msg.setContent(strBody,"text/html");
            
            // Send message
            Transport.send(msg);
            logger.warn("Sent message successfully...");
            
        }catch(Exception e){
            logger.warn("sendmail fn exceptions3 = " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    public void ReadConfigFile(){
        
        Properties prop = new Properties();
        
        try
        {
            prop.load(CTICallCheck.class.getResourceAsStream("/config/config.properties"));

            DB          = prop.getProperty("DB");
            DBUser      = prop.getProperty("DBUser");
            DBPass      = prop.getProperty("DBPass");
            FROM    	= prop.getProperty("FROM");
            TO      	= prop.getProperty("TO");
            CC      	= prop.getProperty("CC");
            BCC      	= prop.getProperty("BCC");
            HOST    	= prop.getProperty("HOST");
            PORT    	= prop.getProperty("PORT");
            SMTPUser    = prop.getProperty("SMTPUser");
            SMTPPass    = prop.getProperty("SMTPPass");
            Log4jPath   = prop.getProperty("Log4jPath");            
            
            PropertyConfigurator.configure(Log4jPath);
                
        } catch (Exception e) {
            logger.warn("ReadConfigFile(), Exception" + e.getMessage() + "\n");
            e.printStackTrace();
        }
    }
}