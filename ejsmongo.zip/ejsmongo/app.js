var chalk = require('chalk');
var express=require('express');
var mongoose=require('mongoose');
var db=require('./models/db.js');

var routes=require('./routes/routes.js');
var user=require('./routes/users.js');
var bodyParser=require('body-parser');

var session=require('express-session');

var app=express();

app.set('view engine','ejs');

app.use(express.static(__dirname + '/public'));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));

var session=require('express-session');
app.use(session({secret:"abcdwxyz",resave: true, saveUninitialized: true}));


app.get('/',routes.index);

app.get('/register',routes.register); //VIEW

app.post('/newUser',user.doCreate); //BACKEND OPRN

app.get('/registrationSuccessful',user.registrationSuccessful); // NOT USED

app.get('/login',routes.login); // VIEW

app.post('/authenticate',user.login); // actually login

app.get('/techStack',routes.techStack);

app.get('/logout',user.logout);

var port = process.env.PORT || 8080;

var server=app.listen(port,function(req,res){
    console.log(chalk.green("HOst at http://localhost:"+port));
});