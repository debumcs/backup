/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package echifilemissing;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.sql.*;  
import java.io.*;
import java.util.Arrays;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import java.util.*;
import java.util.Date;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
/**
 *
 * @author p-fs0121
 */
public class EchiFileMissing {

    public String FROM, TO, CC, HOST, PORT, DB, UserName, Password, FilePath;
    
    static Logger logger = Logger.getLogger(EchiFileMissing.class);
    
    public static void main(String args[]){
        EchiFileMissing obj = new EchiFileMissing();
        String configProperties = "config.properties";
        
        String log4jConfigFile = "log4j.properties";
        PropertyConfigurator.configure(log4jConfigFile);
        
        Properties properties = new Properties();
        try {
            properties.load(new FileInputStream(configProperties));
            logger.info("Config file opened.\n");
        } catch (IOException e) {
            System.out.println("Could not open Config file");
            logger.warn("Could not open Config file. "+e.getMessage());
        }
        
        obj.FROM    = properties.getProperty("From");
        obj.TO      = properties.getProperty("To");
        obj.CC      = properties.getProperty("CC");
        obj.HOST    = properties.getProperty("Host");
        obj.PORT    = properties.getProperty("Port");
        
        obj.FilePath = properties.getProperty("FilePath");
       
        File folder = new File(obj.FilePath);
        File[] listOfFiles = folder.listFiles();
        String filename;
        String html, strSubject = "Echi Files Missing Status";
        String NonExistFiles = "";
        String RecordNotMatchFiles = "";
        String logmsg = "";
        Date date = new Date();
        
        Arrays.sort(listOfFiles, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
        
        try {
            for(int i=0, length=Math.min(listOfFiles.length, 5); i<length; i++) {
                if (listOfFiles[i].isFile()) {
                    filename = listOfFiles[i].getName();
                    int count=0;
                    int noofrow = obj.doesFileExistinDB(filename);
                    
                    if(noofrow > 0){
                        //System.out.println("File " + filename + " is found in database. Number of row found "+noofrow+".");
                        InputStream is = new FileInputStream(obj.FilePath+"/"+filename);
                        for (int aChar = 0; aChar != -1;aChar = is.read())
                            count += aChar == '\n' ? 1 : 0;
                        //System.out.println(count);
                        is.close();
                        if(noofrow != count){
                            //RecordNotMatchFiles[i] = filename;
                            RecordNotMatchFiles = RecordNotMatchFiles + " " + filename;
                        }
                    }else{
                        //NonExistFiles[i] = filename;
                        NonExistFiles = NonExistFiles + " " + filename;
                        
                    }

                } else if (listOfFiles[i].isDirectory()) {
                    System.out.println("Directory " + listOfFiles[i].getName());
                }
            }
        }catch(IOException e) {
            System.out.print("Exception");
            logger.warn("exceptions= " + e.getMessage());
        }
        
        html="<html>"; 
        html+="<body>";
        html+= "<table border='0' cellspacing='2' width='60%' cellpadding='3' align='left' style='width:600px;text-align:left;border:solid 5px #C52622;'>";
        html+= "<tr><th colspan='2' style='padding:6px 15px;color:#C52622;font-weight:normal;text-align:left;background:#eeeeee;border:solid 1px #cccccc;'>Hi Team,</th></tr>";
        html+= "<tr><td colspan='2'>&nbsp;</td></tr>";
        html+= "<tr><td colspan='2' style='padding:5px 15px;font-size:11px;'>The scheduler run at "+date+" and found the details given below : </td></tr>";
        logmsg+= "The scheduler run at "+date+" and found the details : ";
        if(NonExistFiles != ""){
            html+= "<tr><td colspan='2' style='padding:5px 15px;font-size:11px;'>The file(s) "+NonExistFiles+" is/are not found in database.</td></tr>";
            logmsg+= "The file(s) "+NonExistFiles+" is/are not found in database. ";
        }
        
        if(RecordNotMatchFiles != ""){
            html+= "<tr><td colspan='2' style='padding:5px 15px;font-size:11px;'>"+RecordNotMatchFiles+" Files records are not matched with database.</td></tr>";
            logmsg+= RecordNotMatchFiles+" files records are not matched with database.";
        }
        
        html+= "<tr><td colspan='2'>&nbsp;</td></tr>";
        html+= "<tr><td colspan='2' style='padding:5px 15px;font-size:11px;'>Regards,</td></tr>";
        html+= "<tr><td colspan='2' style='padding:5px 15px;font-size:11px;'>CRM Support</td></tr>";
        html+= "<tr><td colspan='2'>&nbsp;</td></tr>";
        html+= "<tr><td colspan='2' style='padding:5px 15px;font-size:11px;'>&nbsp;</td></tr>";
        html+= "<tr><th colspan='2' style='color:#C52622;font-weight:normal;font-size:12px;text-align:center;background:#eeeeee;border:solid 1px #cccccc;'>";
        html+= "&nbsp;</td></tr>";
        html+= "</table>";
        html+="</body></html>";
        
        if(RecordNotMatchFiles != "" || NonExistFiles != ""){
            logger.info(logmsg);
            obj.sendmail(obj.FROM, obj.TO,  obj.CC, html, strSubject, obj.HOST, obj.PORT);
        }else{
            logger.info("All files are found in database and number of records of each file are matched. \n");
        }
        
    }
        
    public int doesFileExistinDB(String fileName) {
        PreparedStatement pst = null;
        ResultSet rs= null;
        EchiFileMissing obj = new EchiFileMissing();
        
        Properties properties = new Properties();
        try {
            properties.load(new FileInputStream("config.properties"));
            logger.info("Config file opened.\n");            
        } catch (IOException e) {
            System.out.println("Could not open Config file");
            logger.warn("exceptions= " + e.getMessage());
        }
        obj.DB = properties.getProperty("DB");
        obj.UserName = properties.getProperty("UserName");
        obj.Password = properties.getProperty("Password");
        
        try{
            Class.forName("com.mysql.jdbc.Driver");  
            Connection con=DriverManager.getConnection(obj.DB,obj.UserName,obj.Password);  
            //here sonoo is database name, root is username and password  
            
            String sql = "SELECT COUNT(*) AS total FROM tx_echi WHERE SEQ_NUM LIKE ? ";
            pst = con.prepareStatement(sql);  
            pst.setString(1, fileName + "%"); 
            rs = pst.executeQuery();  
            while (rs.next()) {
                if(rs.getInt("total")>0 ){
                    int total = rs.getInt("total");
                    return total;
                }else{
                    return 0;
                }
            }            
            con.close();
        }
        catch(Exception e)
        { 
            System.out.println(e);
            logger.warn("exceptions= " + e.getMessage());
        }
        return 0;
    }
    
    public void sendmail(String strFrom,String strTo, String strCC, String strBody,String strSubject,String strHost, String strPort)
    {
        try
        {  
            FROM=strFrom;PORT=strPort;
            TO=strTo;
            CC=strCC;HOST=strHost;

            
            Properties props = System.getProperties(); 
            props.put("mail.transport.protocol", "smtp");
            props.setProperty("mail.smtp.host", HOST);
            props.put("mail.smtp.port", PORT); 
            Session session = Session.getDefaultInstance(props);
            MimeMessage msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(FROM));

            String[] recipientList = TO.split(",");
            InternetAddress[] recipientAddress = new InternetAddress[recipientList.length];
            int counter = 0;
            for (String recipient : recipientList) 
            {
                recipientAddress[counter] = new InternetAddress(recipient.trim());
                counter++;
            }
            msg.setRecipients(Message.RecipientType.TO, recipientAddress);

            try
            {    
                String []recipientListCC = CC.split(",");
                recipientAddress = new InternetAddress[recipientListCC.length];
                counter = 0;
                for (String recipient : recipientListCC) 
                {
                    recipientAddress[counter] = new InternetAddress(recipient.trim());
                    counter++;
                }
                if(counter>0)
                    msg.setRecipients(Message.RecipientType.CC, recipientAddress);
            }catch(Exception errr){
                logger.warn("sendmail fn exceptions1 = " + errr.getMessage());
            }
            
            msg.setRecipients(Message.RecipientType.BCC, "");
            msg.setSubject(strSubject);
            msg.setContent(strBody,"text/html");
            Transport transport = session.getTransport();
            try
            {
                Transport.send(msg, msg.getAllRecipients());
            }
            catch (Exception ex) 
            {
                logger.warn("sendmail fn exceptions2 = " + ex.getMessage());
            }
            finally
            {
                transport.close();             
            }
        }catch(Exception rtt)
        {
            System.out.println("Send Mail :"+rtt);
            logger.warn("sendmail fn exceptions3 = " + rtt.getMessage());
        }
    }
    
} 