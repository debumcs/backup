export enum TransactionType {
  Cash,
  Credit,
  LemonCoin,
}
