﻿(function () {

    var value = {
        useBreeze: false
    };

    angular.module('customersApp').value('config', value);

}());