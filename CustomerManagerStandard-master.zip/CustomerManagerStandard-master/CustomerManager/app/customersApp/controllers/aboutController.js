﻿(function () {

    var injectParams = [];

    var AboutController = function () {

    };

    AboutController.$inject = injectParams;

    angular.module('customersApp').controller('AboutController', AboutController);

}());