<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Location Management</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Location Management</a></li>
        <li class="active">View Location</li>
      </ol>
    </section>
    <section class="content form-page">
	
		<div class="box">
		<div class="box-body">
			<div class="padleftright20">
				<div class="accordion-option">
					<!-- <h3 class="title">Lorem Ipsum</h3> -->
					<!--a href="edit_savedorder.html" class="btn btn-primary">Edit</a-->
					<a href="javascript:void(0)" class="toggle-accordion active" accordion-id="#accordion"></a>
				</div>
				<div class="clearfix"></div>
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
								Location Details
								</a>
							</h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
							<div class="panel-body">
								<div class="row ">
									<div class="col-md-12 col-lg-12 col-sm-12">
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Location Type:</strong> <?php echo $locationDetails["responseObject"]["locationTypeDetails"]["locationType"]; ?></label>
												</div>
											</div>										
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Reference Code:</strong> <?php echo $locationDetails["responseObject"]["referenceCode"]; ?></label>
												</div>
											</div>					
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Location Name:</strong> <?php echo $locationDetails["responseObject"]["locationName"]; ?></label>
												</div>
											</div>						
										</div>									
										<div class="row">														
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Nickname:</strong> <?php echo $locationDetails["responseObject"]["nickName"]; ?></label>
												</div>
											</div>		
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Address 1:</strong> <?php echo $locationDetails["responseObject"]["addressLine1"]; ?></label>
												</div>
											</div>									
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Address 2:</strong> <?php echo $locationDetails["responseObject"]["addressLine2"]; ?></label>
												</div>
											</div>	
										</div>
										
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>City:</strong> <?php echo $locationDetails["responseObject"]["cityDetails"]["cityName"]; ?></label>
												</div>
											</div>
											
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>State:</strong> <?php echo $locationDetails["responseObject"]["stateDetails"]["stateName"]; ?></label>
												</div>
											</div>
											
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Country:</strong> <?php echo $locationDetails["responseObject"]["countryDetails"]["countryName"]; ?></label>
												</div>
											</div>									
											
										</div>
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Zip Code:</strong> <?php echo $locationDetails["responseObject"]["zipCode"]; ?></label>
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Business Phone:</strong> <?php echo $locationDetails["responseObject"]["businessPhone"]; ?></label>
												</div>						
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Fax:</strong> <?php echo $locationDetails["responseObject"]["fax"]; ?></label>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Email:</strong> <?php echo $locationDetails["responseObject"]["contactEmail"]; ?></label>
												</div>
											</div>										
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Contact Name:</strong> <?php echo $locationDetails["responseObject"]["contactName"]; ?></label>
												</div>
											</div>						
											<div class="col-md-4">
												<div class="form-group">
													<label><strong>Contact Phone:</strong> <?php echo $locationDetails["responseObject"]["contactPhone"]; ?></label>
												</div>
											</div>												
										</div>
										<div class="row">					
											<div class="col-md-6" id="time-range">
												<table id="example1" class="table table-bordered table-striped ">
													<thead>
														<tr>
															<th align="center">&nbsp;</th>
															<th align="center" colspan="2">Operational Hours</th>
														</tr>
														<tr>
															<th align="center">Open Days</th>
															<th align="center">From Time</th>
															<th align="center">To Time</th>
														</tr>
													</thead>
													<tbody>
														<?php foreach($locationDetails["responseObject"]["operationalHours"] as $value){ ?>
															<tr>												
																<td><?php echo $value["day"]; ?></td>
																<td><?php echo date("g:i a", strtotime($value["startTime"])); ?></td>
																<td><?php echo date("g:i a", strtotime($value["endTime"])); ?></td>
															</tr>
														<?php } ?>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>							
							</div>
						</div>
					</div>
						
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingTwo">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
								Associations
								</a>
							</h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
							<div class="panel-body">
								<div class="row">
									<div class="col-lg-12">
										<table id="example1" class="table table-bordered table-striped ">
											<thead>
												<tr>
													<th>Account #</th>
													<th>Account Name</th>
													<th>Account Nickame</th>
													<th>Account Ref #</th>
													<th>Account Type</th>													
													<th>Address</th>
													<th>City</th>
													<th>State</th>
													<th>Status</th>
												</tr>
											</thead>
											<tbody>
											<?php foreach($locationDetails["responseObject"]["associatedAccounts"] as $value){ ?>
												<tr>
													<td><?php echo $value["accountId"]; ?></td>
													<td><?php echo $value["companyName"]; ?></td>
													<td><?php echo $value["nickName"]; ?></td>
													<td><?php echo $value["referenceCode"]; ?></td>
													<td><?php echo $value["accountTypeDetails"]["accountType"]; ?></td>
													<td><?php echo $value["addressLine1"]; ?> <?php echo $value["addressLine2"]; ?></td>
													<td><?php echo $value["cityDetails"]["cityName"]; ?></td>
													<td><?php echo $value["stateDetails"]["stateName"]; ?></td>
													<td><?php echo $value["accountStatusDetails"]["statusDesc"]; ?></td>
												</tr>
											<?php } ?>
												
											</tbody>
										</table>
									</div>
								</div>
								
							</div>
						</div>
					</div>
					
				</div>
				
				
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>
								<a href="<?php echo base_url();?>Location2/edit_location/<?php echo $locationDetails["responseObject"]["locationId"]; ?>" class="btn btn-primary">Edit</a>
							</label>
							<label>
								<a href="<?php echo base_url();?>Location2/viewAllLocations" class="btn btn-default">Back</a>
							</label>											
						</div>
					</div>
				</div>
				
			</div>
		</div>
		</div>    
    </section>
    <!-- /.content -->
  </div>
