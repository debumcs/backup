
import java.util.concurrent.ConcurrentHashMap;


public class ReverseString {
    public static void main(String args[])
    {
      String str="hello this is hilary hilton";
      StringBuilder sb = new StringBuilder(str);
      
        for(int i=0;i<str.length();i++)
        {       
                int j=0;
                char c= str.charAt(i);
               
               for(int k=0;k<str.length();k++)
               {
                if(str.indexOf(c) !=-1)
                {
                j++;
                }
                str=str.substring(str.indexOf(c), str.length());
                 System.out.println("string="+str);
               }
               System.out.println(c+" ="+j);
               
                
        }
    
    }
}
