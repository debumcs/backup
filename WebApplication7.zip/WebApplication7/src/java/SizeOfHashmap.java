
import java.util.HashMap;




public class SizeOfHashmap {
    public static void main(String args[])
    {
  /*  Thread t1= new Thread(new ThreadPattern("1"));
    Thread t2= new Thread(new ThreadPattern("2"));
    Thread t3= new Thread(new ThreadPattern("3"));
    t1.setName("Thread 1");t2.setName("Thread 2");t3.setName("Thread 3");
    t1.start();t2.start();t3.start();*/
        
        Student s1= new Student(101, "sachin");
        Student s2= new Student(101, "sachin");
        HashMap<Student,String> h1= new HashMap<>();
        h1.put(s1, "student1");
        h1.put(s2, "student1");
        
        System.out.println(h1.size());
    }
    
}
