
package com.test.serialization;

import java.io.FileInputStream;
import java.io.ObjectInputStream;


public class DesrialEmployee {
     public static void main(String args[])
    {
   
    try
    {
        FileInputStream fout = new FileInputStream("D:/serial.txt");
        ObjectInputStream out =  new ObjectInputStream(fout);
       SerialEmployee e1= (SerialEmployee)out.readObject();
        System.out.println(e1.getEmpid()+" "+e1.getEmpname());
    }
catch(Exception e )
{
e.printStackTrace();
}    
    
    }
}
