
package com.test.serialization;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class TestSerialization {
    public static void main(String args[]) throws IOException
    {
    SerialEmployee e1= new SerialEmployee(101,"Sachin Tandon");
    try
    {
        FileOutputStream fout = new FileOutputStream("D:/serial.txt");
        ObjectOutputStream out =  new ObjectOutputStream(fout);
        out.writeObject(e1);
        
    }
catch(FileNotFoundException e )
{
e.printStackTrace();
}    
    
    }
            
}
