
package com.test.serialization;

import java.io.Serializable;


public class SerialEmployee implements Serializable {
    private int empid;

    public int getEmpid() {
        return empid;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }
    private String empname;
    static private String companyname="Quatrro Global Services Pvt Ltd";

  
 SerialEmployee(int empid,String empname)
 {
 this.empid=empid;
 this.empname=empname;
 }

}
