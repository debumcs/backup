
package com.test.NoClassDefFoundError;

class GeeksForGeeks  
{ 
    void greeting() 
    { 
        System.out.println("hello!"); 
    } 
} 
  
class G4G { 
    public static void main(String args[])  
    { 
        GeeksForGeeks geeks = new GeeksForGeeks(); 
        geeks.greeting(); 
    } 
} 
