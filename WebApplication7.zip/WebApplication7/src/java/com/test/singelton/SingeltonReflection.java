
package com.test.singelton;

public class SingeltonReflection implements Cloneable {
     private static SingeltonReflection Instance;
    
      private SingeltonReflection()  
        { 
            // private constructor 
            if(Instance !=null)
            {
            throw new RuntimeException("Use getInstance() method to get the single instance of this class.");
            }
        } 
    
      public static SingeltonReflection getInstance()
      {
          if(Instance==null)
          {
          synchronized(SingeltonReflection.class)
          {
               if(Instance==null)
               {
               Instance= new SingeltonReflection();
               }
          }
          
          }
          
      return Instance;
      
      }
  protected Object clone() throws CloneNotSupportedException  
  { 
    throw new CloneNotSupportedException(); 
  } 
   
}
