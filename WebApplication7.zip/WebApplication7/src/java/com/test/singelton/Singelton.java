package com.test.singelton;



import java.io.FileInputStream; 
import java.io.FileOutputStream; 
import java.io.ObjectInput; 
import java.io.ObjectInputStream; 
import java.io.ObjectOutput; 
import java.io.ObjectOutputStream; 
import java.io.Serializable; 
  
class Singleton implements Serializable  
{ 
    // public instance initialized when loading the class 
    public static Singleton instance = new Singleton(); 
      
    private Singleton()  
    { 
        // private constructor 
    } 
    
    //override this method to avoid the multiple instance of serializable singelton class
    protected Object readResolve() 
    { 
        return instance; 
    } 
} 
  