
package com.test.singelton;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class SingeltonReflectionMain {
       public static void main(String[] args)   
        { 
            
            try
            {
            SingeltonReflection instance1= SingeltonReflection.getInstance();
                        
            /*
            Using Reflection breaking singelton property
            SingeltonReflection instance2= null;
            Class<SingeltonReflection> cls=SingeltonReflection.class;
            Constructor<SingeltonReflection> constructor =cls.getDeclaredConstructor();
            constructor.setAccessible(true);
            instance2= constructor.newInstance();
           */
            
            SingeltonReflection instance2= (SingeltonReflection)instance1.clone();
              System.out.println("instance1 hashCode:- "+ instance1.hashCode()); 
              System.out.println("instance2 hashCode:- " + instance2.hashCode()); 
            }
            catch(Exception ex)
            {
            ex.printStackTrace();
            }
            
             
        }
}
