
package com.test.interfaces;

interface Inttest {
    void show(String str);
}
