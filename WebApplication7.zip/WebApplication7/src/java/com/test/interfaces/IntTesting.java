
package com.test.interfaces;

import java.util.Scanner;
import org.apache.log4j.Logger;


class IntTesting 
{
       static Logger log = Logger.getLogger(IntTesting.class.getName());
 static boolean checkpower(int n) 
    { 
        if (n == 0) 
            return false; 
          
        while (n != 1) 
        { 
            if (n % 2 != 0) 
                return false; 
            n = n / 2; 
        } 
        return true; 
    }     
public static void main(String args[])
{
Scanner sc = new Scanner(System.in);
int num =  sc.nextInt();
System.out.println("Your number is :"+num);
boolean i= checkpower(num);
System.out.println(i);
for(int j=1;j<1000;j++)
{
      log.debug("Hello this is a debug message");
      log.info("Hello this is an info message");
      log.error("Hello this is an info message");
}

}
}