
package com.test.Sorting;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;


public class TestComparable {
    public static void main(String args[])
    {
    Employee[] empArr = new Employee[4];
    empArr[0] = new Employee(10, "Mikey", "Tech", "Quatrro");
    empArr[1] = new Employee(10, "Arun", "Sale", "Quatrro");
    empArr[2] = new Employee(5, "Lisa", "IT", "Quatrro");
    empArr[3] = new Employee(1, "Pankaj","Linux", "Quatrro");
    
     List<Employee> employees = new ArrayList<Employee>();
     employees.add(empArr[0]);
      employees.add(empArr[1]);
       employees.add(empArr[2]);
        employees.add(empArr[3]);
    //Arrays.sort(empArr);
    Collections.sort(employees, new DepartmentComparator());
    System.out.println("Default Sorting of Employees list:\n"+employees.toString());
    
    }
}
