
package com.test.Sorting;

import java.util.Comparator;

public class DepartmentComparator  implements Comparator<Employee>{

    @Override
    public int compare(Employee t, Employee t1) {
        return t.getDeptname().compareTo(t1.getDeptname());

    }

   
    
    
}
