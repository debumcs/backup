
package com.test.Sorting;

import java.util.Comparator;

public class Employee  implements Comparable<Employee>{
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }

    public String getDeptname() {
        return deptname;
    }

    public void setDeptname(String deptname) {
        this.deptname = deptname;
    }

    public static String getCompanyname() {
        return Companyname;
    }

    public static void setCompanyname(String Companyname) {
        Employee.Companyname = Companyname;
    }
    private String empname;
    private String deptname;
    private static String Companyname;

    public Employee(int id,String empname,String deptname,String Companyname)
    {
    this.id=id;
    this.empname=empname;
    this.deptname=deptname;
    this.Companyname= Companyname;

    }
    
    @Override
    public String toString() {
        return id+" "+empname+" "+deptname+" "+Companyname; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int compareTo(Employee t) 
    {
        if(this.id < t.id)
        {  return -1;}
        else if(this.id == t.id)
                {
                    //we can use this if two emp ids are same then sort bby empname
                    //return this.empname.compareTo(t.empname);
                    return 0;
                }
        else
                { return 1;}
    }
    
  
    
    
}
