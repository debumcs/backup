
package com.test.Sorting;

import java.util.Comparator;

  class NameComparator implements Comparator<Employee>
    {

        @Override
        public int compare(Employee t, Employee t1) {
            int namecomp=t.getEmpname().compareTo(t1.getEmpname());
           return namecomp;
    
    }
  }