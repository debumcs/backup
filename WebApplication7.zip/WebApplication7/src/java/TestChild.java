
import java.io.IOException;


public abstract class TestChild {
  
    abstract void show() ;
    private void test()
    {
    System.out.println("Hi");
    }
   
}

class Testing extends TestChild
{

    @Override
    void show() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    void test()
    {
     System.out.println("Hiwwwwwwwwwwwwww");
    }

}