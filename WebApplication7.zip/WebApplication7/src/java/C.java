
public class C {
  void show()
  {
   System.out.println("Show method");
  }
     
}

class D extends C
{
    public D(int i ,int j)
    {
     super.show();
     System.out.println(j);
    }
   public static void main(String args[])
    {
     D obj = new D(1,2);
    }
}