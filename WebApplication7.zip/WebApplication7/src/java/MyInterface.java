
public interface MyInterface<T> {
  public   T show(T args);
  
}
