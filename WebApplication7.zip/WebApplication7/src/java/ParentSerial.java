
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ParentSerial {
    int id;
    String name;
    ParentSerial(int id,String name)
    {
    this.id=id;
    this.name=name;
    }
    ParentSerial()
    {
        id=101;
        name="sachin";
    }
}
class Child extends ParentSerial implements Serializable
{
    String Department;
    static String filename = "D://file.ser";
    public Child(int id, String name,String Department) {
        super(id, name);
        this.Department=Department;
    }
public static void main(String args[])
{   
    Child obj =new Child(1,"sachin","IT Department");
        try {
            /*FileOutputStream fout = new FileOutputStream(filename);
            ObjectOutputStream out = new ObjectOutputStream(fout);
            out.writeObject(obj);*/
            FileInputStream fin = new FileInputStream(filename);
            ObjectInputStream oin = new ObjectInputStream(fin);
            Child ch =(Child)oin.readObject();
            System.out.println(ch.id+" "+ch.name+" "+ch.Department);
        } 
        catch (IOException | ClassNotFoundException ex) 
        {
            Logger.getLogger(Child.class.getName()).log(Level.SEVERE, null, ex);
        }
}

}