
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;  
import java.util.Map;
import java.util.Set;

public class MultiHashMapExample {

    public static void main(String[] args) {

        List list;
        Hashtable<String,String> map = new Hashtable<>();
        map.put("A", "sac");
        map.put("B", "sac1");
        map.put("A", "sac3");
        map.put("C", "sac4");

        Set entrySet = map.entrySet();
        Iterator it = entrySet.iterator();
        System.out.println("  Object key  Object value");
        while (it.hasNext()) {
            Map.Entry mapEntry = (Map.Entry) it.next();
           System.out.println(mapEntry.getKey()+" "+mapEntry.getValue());
        }
    }
}