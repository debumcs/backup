
import java.util.concurrent.locks.ReentrantLock;


public class Test {
    public static void main(String args[])
    {
        System.out.println("Test Class");
    }
    void show()
    {
    System.out.println("The batch-size fetching strategy not define how many records inside collection loaded but "
            + "define how many collections loded."
            + "  ");
    }
}
/*
 class Testingnew 
    {
         public static void main(String args[])
        {
            System.out.println("Testinggg Class");
        }
        void show()
        {
        System.out.println("Testingnew Class");
        }
    }

*/