
import java.util.HashMap;



public class HMCollection {
    public static void main(String args[]){  
        HashMap<String,String> hm = new HashMap<>();
        hm.put("A", "Sachin");
        hm.put("B", "Sachin1");
        hm.put("FB", "Sachin2");
        hm.put("Ea", "Sachin2");
        System.out.print(hm.size());
 }  

   

    
}
