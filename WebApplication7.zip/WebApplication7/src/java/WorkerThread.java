



public class WorkerThread implements Runnable{
  static boolean one = true;
  static boolean two = false;
  static boolean three = false;
  private static final int N = 2;
  int threadId;
 
   static Object monitor = new Object();
   int i ;
    public WorkerThread(int threadId) 
    {
            this.threadId = threadId;
            i=1;
    }
    
    @Override
    public void run() 
    {
     print();   
    }
    
    public void print()
    {
    try {
     for(int i=0; i<=N; i++){
         
     synchronized (monitor) {
      if (1 == threadId) {
       if (!one) {
        monitor.wait();
       } else {
        System.out.print(" A");
        one = false;
        two = true;
        three = false;
        monitor.notifyAll();
       }
      }
      if (2 == threadId) {
       if (!two) {
           
        monitor.wait();
       } else {
        System.out.print("B");
        one = false;
        two = false;
        three = true;
        monitor.notifyAll();
       }
      }
    if (3 == threadId) {
       if (!three) {
         
        monitor.wait();
       } else {
        System.out.print("C");
        one = true;
        two = false;
        three = false;
        monitor.notifyAll();
       }
      }
      
      
     }
     }
   } catch (InterruptedException e) {
    e.printStackTrace();
   }
    
    }
    }
   
  
   
