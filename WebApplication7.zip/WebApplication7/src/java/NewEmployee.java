
import java.io.Serializable;


public class NewEmployee implements Serializable{
    public String lastName;
	static  String companyName="Quatrro";
	transient  String address;
	static transient String companyCEO="sachin";
}
