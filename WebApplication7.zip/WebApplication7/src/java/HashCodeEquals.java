
import java.util.HashMap;


public class HashCodeEquals {
        public static void main(String[] args) {

        Student alex1 = new Student(1, "Alex");

        Student alex2 = new Student(1, "Alex");
        
        HashMap<Student,String> hm = new HashMap<>();
        hm.put(alex1,"Sachin");
        hm.put(alex2,"Sachin");
        System.out.println(hm.size());
        }
}
