
import static java.lang.Thread.sleep;




 class Pattern1 implements Runnable{
     String th="";
     Pattern1(String th)
     {
     this.th=th;
     }
static Object lock = new Object();
    
@Override
    public void run() {

         try {
             synchronized(lock){
                        for(int i=1;i<=5;i++)
                        {  
                          System.out.print(th);
                          try {
                            lock.notify();
                            lock.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        }
               
             }
          
            
         } catch (Exception ex) {
             //Logger.getLogger(Pattern1.class.getName()).log(Level.SEVERE, null, ex);
             System.out.print("Pattern2 Notify");
         }
     
    }
    
     
    
}
