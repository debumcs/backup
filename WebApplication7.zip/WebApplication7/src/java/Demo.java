
import java.lang.reflect.Method;


public class Demo 
{
    public static void main(String args[]) throws Exception
    {
   /* 
    Test obj  = new Test();
    Class cls = obj.getClass();
    Method method3call = cls.getDeclaredMethod("method3");
    method3call.setAccessible(true);
    method3call.invoke(obj);
    */
   
        String s1 = new String("abc");
        String s2 = new String("abc");
        String s3 = "abc";
        if (s1==s2)
            System.out.println("s1==s2");
        if(s1==s3)
            System.out.println("s1==s3");
        if(s2==s3)
            System.out.println("s2==s3");
         System.out.println(s1.hashCode());
         System.out.println(s2.hashCode());
         System.out.println(s3.hashCode());
    }
}
