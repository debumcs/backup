
import java.util.concurrent.locks.ReentrantLock;

public class SingleTest implements Runnable{

    private static volatile int counter=1;
    
   static ReentrantLock counterlock =new ReentrantLock(true);
    
     void  incrementCounter()
    {
   counterlock.lock();
        try
        {
            System.out.println(Thread.currentThread().getName() + ": " + counter);
            counter++;
        }
        finally
        {
       counterlock.unlock();
        }
    }
    @Override
    public void run() {
        while(counter<1000)
            incrementCounter();
        
    }
    
public static void main(String args[])
{
SingleTest obj = new SingleTest();
Thread t1 = new Thread(obj);
Thread t2 = new Thread(obj);

t1.start();t2.start();
}
 
   
}
