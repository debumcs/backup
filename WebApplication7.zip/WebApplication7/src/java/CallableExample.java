
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
 
public class CallableExample
{
    public static Future<Integer> result;
      public static void main(String[] args)
      {
          ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(1);
           
          List<Future<Integer>> resultList = new ArrayList<>();
           
        
              Integer number = 8;Integer number1 = 9;
              FactorialCalculator calculator  = new FactorialCalculator(number);
              
               FactorialCalculator calculator1  = new FactorialCalculator(number1);
              Future<Integer> result1 = executor.submit(calculator1);
               System.out.println(result1.isDone());
             if(result1.isDone())
              {
              result = executor.submit(calculator);
              }
            //  resultList.add(result);
                try
                {
                    //System.out.println("Future result is - " + " - " + result.get() + "; And Task done is " + result.isDone());
                    System.out.println("Future result is - " + " - " + result1.get() + "; And Task done is " + result1.isDone());

                }
                catch (InterruptedException | ExecutionException e)
                {
                    e.printStackTrace();
                }
           if(result1.isDone())
              {
              result = executor.submit(calculator);
              }
        
            executor.shutdown();
      }
}