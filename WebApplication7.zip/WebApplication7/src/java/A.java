

public class A {
  

    A()
   {
   System.out.println("Init block A");
   }
}
