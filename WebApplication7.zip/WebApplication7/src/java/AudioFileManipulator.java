
interface AudioFileManipulator<T> {
    public  T add(T t1,T t2);
}

class TestInter implements AudioFileManipulator<Integer>
{

    @Override
    public Integer add(Integer t1, Integer t2) {
            return (t1+t2);
    }

}

class TestString implements AudioFileManipulator<String>
{

    @Override
    public String add(String t1, String t2) {
        return t1+t2;
    }
}

class TestGenInterface
{
    public static void main(String args[])
    {
    TestInter obj1= new TestInter();
  int i=obj1.add(2,3);
  System.out.print(i);
  
  TestString obj2 = new TestString();
  
  System.out.print(obj2.add("Sachin ", "Tandon"));
    }

}