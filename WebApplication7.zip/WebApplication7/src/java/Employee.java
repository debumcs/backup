
import java.util.Comparator;

public class Employee {
    private int id;
    private String empname;
    private String designation;
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }
    
    Employee(int id,String empname,String designation)
    {
    this.id=id;
    this.empname=empname;
    this.designation=designation;
    }

     public static Comparator<Employee> idComparator = 
            new Comparator<Employee>()
            {
        @Override
        public int compare(Employee t, Employee t1) {
           if(t.getId()<t1.getId())
           {
               return -1;
           }
           if(t.getId()==t1.getId())
           {
           return 0;
           }
           return 1;
        }
        };
    
    public static Comparator<Employee> nameComparator = 
            new Comparator<Employee>()
            {
        @Override
        public int compare(Employee t, Employee t1) {
            return t.getEmpname().compareTo(t1.getEmpname());
        }
            
            };
    public static Comparator<Employee> desgnationComp = 
            new Comparator<Employee>()
            {
        @Override
        public int compare(Employee t, Employee t1) {
            return t.getDesignation().compareTo(t1.getEmpname());
        }
            
            };
    public String toString() {
        return "[id=" + this.id + ", name=" + this.empname + ", designation=" + this.designation + "]";
    }



}
