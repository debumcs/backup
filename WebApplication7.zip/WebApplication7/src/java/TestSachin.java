


public class TestSachin {
    public static void main(String args[])
    {
             /*   Thread t1= new Thread(new ThreadPatternWithoutSynchronized("1"));
                Thread t2= new Thread(new ThreadPatternWithoutSynchronized("2"));
                Thread t3= new Thread(new ThreadPatternWithoutSynchronized("3"));*/
                
                Thread t1= new Thread(new ThreadPatternUsingVolatile("1"));
                Thread t2= new Thread(new ThreadPatternUsingVolatile("2"));
                Thread t3= new Thread(new ThreadPatternUsingVolatile("3"));
                t1.start();t2.start();t3.start();
    }
}
