
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


public class NewTest {
    public static long sum()
    {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date d = new Date();
       
        System.out.println("Time starts:"+dateFormat.format(d));
         long sum=0;
      for(long i=1;i<=1000; i++)
        {
            sum=sum+i;
           
        }
      return sum;
    }
    public static void main(String args[])
    {
       
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        
      
         System.out.println("Sum is:"+NewTest.sum());   
          Date d1 = new Date();
           System.out.println("Time starts:"+dateFormat.format(d1)); 
    }
    }
