
public class ThreadPattern implements Runnable {
   String threadid;
   static int i=1;
  static boolean one = true;
  static boolean two = false;
  static boolean three = false;
  
  static Object monitor= new Object();
   ThreadPattern(String threadid)
   {
   this.threadid=threadid;
   }
    @Override
    public void run() {
        printpattern();
    }
    public void printpattern()
    {
     while(true)
     {
     synchronized(monitor)
     {
     if(threadid=="1")
     {
        if(!one)
        {
         try{ monitor.wait();}catch(Exception e){e.printStackTrace();}
        }
        else
        {
           System.out.println(Thread.currentThread().getName()+":"+i);
           i++;
           one=false;
           two=true;
           three=false;
            try{ monitor.notifyAll();}catch(Exception e){e.printStackTrace();}

        }    
     }
     else if(threadid=="2")
     {
        if(!two)
        {
         try{ monitor.wait();}catch(Exception e){e.printStackTrace();}
        }
        else
        {
           System.out.println(Thread.currentThread().getName()+":"+i);
           i++;
           one=false;
           two=false;
           three=true;
            try{ monitor.notifyAll();}catch(Exception e){e.printStackTrace();}

        }    
     }
      else if(threadid=="3")
     {
        if(!three)
        {
         try{ monitor.wait();}catch(Exception e){e.printStackTrace();}
        }
        else
        {
           System.out.println(Thread.currentThread().getName()+":"+i);
           i++;
           one=true;
           two=false;
           three=false;
            try{ monitor.notifyAll();}catch(Exception e){e.printStackTrace();}

        }    
     }    
     
     
     }
     }
    
    }
}
