

import java.util.HashSet;
import java.util.Set;


public class FindStringOccurance {
    public static void main(String args[])
    {
    String str="geeksofgeekffsgggg";
      Character c1, c2;
      Set<Character> al=new HashSet<>();
        for(int i=0;i<str.length();i++)
        {
             c1=new Character(str.charAt(i));
            int counter=0;
            for(int j=0;j<str.length();j++)
            {
                c2=new Character(str.charAt(j));
                if(c1.compareTo(c2)==0)
                {
                counter++;
                }
                
            }
                if(!al.contains(c1))
                System.out.println("Occurance of character : "+c1+" is="+counter);
                al.add(c1);
        }
    }
}
