
import java.util.Scanner;


public class PrintStatement {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int i = scan.nextInt();
        Double d= scan.nextDouble();
        String s="";
        //scan.next();
        if(scan.hasNext())
         s =s+scan.next();
        // Write your code here.

        System.out.println("String: " + s);
        System.out.println("Double: " + d);
        System.out.println("Int: " + i);
    }
}
