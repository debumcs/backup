
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class MultiThreadingReaderWriter 
{
    public static void main(String args[])
    {
    Reader obj = new Reader();
    Thread t1 = new Thread(obj);
    
    Writer obj1 = new Writer();
    Thread t2 = new Thread(obj1);
    
    t1.start();
    t2.start();
    }
}

class Reader implements Runnable
{

    @Override
    public void run() {
        
         writeFile();
    }
    public void writeFile() 
    {
       try
       { 
        FileWriter fw=new FileWriter("D:\\testout.txt");   
        fw.write("1,2:tfn did TFN/DID Changes ,testing,add new reporting campaign name functionality\n" +
"3:qresolve survey for french,tfn lookup development\n" +
"4:cti pages changes\n" +
"5:tsg support page changes in email,cc mail semicolon replace\n" +
"8,9,10 : customer editing by email in crm\n" +
"18:qresolve french survey page changes\n" +
"22,23,24:qtms changes\n" +
"25,26: new partner setup module development1,2:tfn did TFN/DID Changes ,testing,add new reporting campaign name functionality\n" +
"3:qresolve survey for french,tfn lookup development\n" +
"4:cti pages changes\n" +
"5:tsg support page changes in email,cc mail semicolon replace\n" +
"8,9,10 : customer editing by email in crm\n" +
"18:qresolve french survey page changes\n" +
"22,23,24:qtms changes\n" +
"25,26: new partner setup module development1,2:tfn did TFN/DID Changes ,testing,add new reporting campaign name functionality\n" +
"3:qresolve survey for french,tfn lookup development\n" +
"4:cti pages changes\n" +
"5:tsg support page changes in email,cc mail semicolon replace\n" +
"8,9,10 : customer editing by email in crm\n" +
"18:qresolve french survey page changes\n" +
"22,23,24:qtms changes\n" +
"25,26: new partner setup module development1,2:tfn did TFN/DID Changes ,testing,add new reporting campaign name functionality\n" +
"3:qresolve survey for french,tfn lookup development\n" +
"4:cti pages changes\n" +
"5:tsg support page changes in email,cc mail semicolon replace\n" +
"8,9,10 : customer editing by email in crm\n" +
"18:qresolve french survey page changes\n" +
"22,23,24:qtms changes\n" +
"25,26: new partner setup module development1,2:tfn did TFN/DID Changes ,testing,add new reporting campaign name functionality\n" +
"3:qresolve survey for french,tfn lookup development\n" +
"4:cti pages changes\n" +
"5:tsg support page changes in email,cc mail semicolon replace\n" +
"8,9,10 : customer editing by email in crm\n" +
"18:qresolve french survey page changes\n" +
"22,23,24:qtms changes\n" +
"25,26: new partner setup module development1,2:tfn did TFN/DID Changes ,testing,add new reporting campaign name functionality\n" +
"3:qresolve survey for french,tfn lookup development\n" +
"4:cti pages changes\n" +
"5:tsg support page changes in email,cc mail semicolon replace\n" +
"8,9,10 : customer editing by email in crm\n" +
"18:qresolve french survey page changes\n" +
"22,23,24:qtms changes\n" +
"25,26: new partner setup module development");
        fw.close();
       }
       catch(Exception e)
       {
       e.printStackTrace();
       }
       
    }

}

class Writer implements Runnable
{

    @Override
    public void run() {
        readFile();
    }
    public void readFile()
    {
     try{   
     FileReader fr=new FileReader("D:\\testout.txt");    
          int i;    
          while((i=fr.read())!=-1)    
          System.out.print((char)i);    
          fr.close();  
     }
     catch(Exception e)
     {
     e.printStackTrace();
     }
    }

}