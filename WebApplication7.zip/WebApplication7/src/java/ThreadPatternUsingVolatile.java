
import java.util.concurrent.locks.ReentrantLock;


public class ThreadPatternUsingVolatile implements Runnable{
     String threadid;
  static volatile int i=1;
  static boolean one = true;
  static boolean two = false;
  static boolean three = false;
   //private static ReentrantLock re =new ReentrantLock();
  
   ThreadPatternUsingVolatile(String threadid)
   {
   this.threadid=threadid;
   
   }
    @Override
    public void run() {
        printpattern();
    }
    public void printpattern()
    {
     while(true)
     {
            //re.lock();
                if(threadid=="1" && one==true)
                    {
                          System.out.println(Thread.currentThread().getName()+":"+i);
                          i++;
                          one=false;
                          two=true;
                          three=false;
                    }
                    else if(threadid=="2" && two==true)
                    { 
                          System.out.println(Thread.currentThread().getName()+":"+i);
                          i++;
                          one=false;
                          two=false;
                          three=true;
                    }
                     else if(threadid=="3" && three==true)
                    {
                          System.out.println(Thread.currentThread().getName()+":"+i);
                          i++;
                          one=true;
                          two=false;
                          three=false;  
                    }     
                //re.unlock();

     }
    
    }
    
}
