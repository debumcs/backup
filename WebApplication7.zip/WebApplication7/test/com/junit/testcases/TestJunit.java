/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.junit.testcases;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author qua08163
 */
public class TestJunit {
    @Test
    public void testAdd() {
      String str = "Junit is working fine";
      assertEquals("Junit is working fine",str);
   }
    
}
