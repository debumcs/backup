import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  isLoggedIn = false;
  constructor(private http: HttpClient) { }

  checkLoginSatus(): Observable<boolean> {
    return of(JSON.parse(localStorage.getItem('isLoggedIn')));
  }

  
  login(username: string, password: string) {
    return this.http.post<any>('https://reqres.in/api/login', { email: username, password: password })
        .pipe(map(user => {
            // login successful if there's a jwt token in the response
            if (user && user.token) {
                // store user details and jwt token in local storage to keep user logged in between page refreshes
                localStorage.setItem('currentUser', JSON.stringify(user));
            }
            this.isLoggedIn = true;
            return user;
        }));
  }


  
  login2(): Observable<boolean> {
    // authenticaion mechanism
    localStorage.setItem('isLoggedIn', JSON.stringify(true));
    this.isLoggedIn = true;
    return of(true);
  }

  logout():void {
    localStorage.removeItem('isLoggedIn');
    this.isLoggedIn = false;
  }
}
