package com.bharam_shakti.Dao;

import static com.bharam_shakti.Dao.UserDao.getConnection;
import com.bharam_shakti.bean.About_us;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.bharam_shakti.bean.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Paths;

public class UserDao {

    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/brahma_shakti", "root", "");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
        return con;
    }
/*
    public static int save(User u) {
        int status = 0;
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("insert into login(name,password,email,sex,country) values(?,?,?,?,?)");
            ps.setString(1, u.getName());
            ps.setString(2, u.getPassword());
            ps.setString(3, u.getEmail());
            ps.setString(4, u.getSex());
            ps.setString(5, u.getCountry());
            status = ps.executeUpdate();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return status;
    }

    public static int update(User u) {
        int status = 0;
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("update login set name=?,password=?,email=?,sex=?,country=? where id=?");
            ps.setString(1, u.getName());
            ps.setString(2, u.getPassword());
            ps.setString(3, u.getEmail());
            ps.setString(4, u.getSex());
            ps.setString(5, u.getCountry());
            ps.setInt(6, u.getId());
            status = ps.executeUpdate();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return status;
    }

    public static int delete(User u) {
        int status = 0;
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("delete from login where id=?");
            ps.setInt(1, u.getId());
            status = ps.executeUpdate();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }

        return status;
    }

    public static List<User> getAllRecords() {
        List<User> list = new ArrayList<>();

        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("select * from register");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                User u = new User();
                u.setId(rs.getInt("id"));
                u.setName(rs.getString("name"));
                u.setPassword(rs.getString("password"));
                u.setEmail(rs.getString("email"));
                u.setSex(rs.getString("sex"));
                u.setCountry(rs.getString("country"));
                list.add(u);

            }
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public static User getRecordById(int id) {
        User u = null;
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement("select * from register where id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                u = new User();
                u.setId(rs.getInt("id"));
                u.setName(rs.getString("name"));
                u.setPassword(rs.getString("password"));
                u.setEmail(rs.getString("email"));
                u.setSex(rs.getString("sex"));
                u.setCountry(rs.getString("country"));
                con.close();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return u;
    }*/

    
    
    
    //Login's Function
    
    
    public static int login_Compare(String username, String password) {
        int i = 0;

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select username,password from login where username=? and password=? ");
                ps.setString(1, username);
                ps.setString(2, password);
                
                ResultSet rs = ps.executeQuery();
                
                while (rs.next()) {
                    if (username.equals(rs.getString(1))) {
                        if (password.equals(rs.getString(2))) {
                            i = 1;
                        } else {
                            i = 0;
                        }
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return i;

    }

    
    //Login's Function End
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    //Slider's Function
    public static List<Slider> getallrecordfrom_slider() {

        List<Slider> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select * from slider");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Slider u = new Slider();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setButton_text(rs.getString("button_text"));
                    u.setButton_link(rs.getString("button_link"));
                    u.setCreated_by(rs.getString("created_by"));
                    u.setIpadd(rs.getString("ipadd"));
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    public static Slider getRecordBySliderId(int id) {
        Slider u = null;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select * from slider where id=?");
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    u = new Slider();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setButton_text(rs.getString("button_text"));
                    u.setButton_link(rs.getString("button_link"));
                    /*u.setCreated_by(rs.getString("created_by"));
                    u.setIpadd(rs.getString("ipadd"));*/
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return u;
    }

    public static List<Slider> Index_slider() {

        List<Slider> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select file_link,title,button_text,button_link from slider");
                
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Slider u = new Slider();
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setButton_text(rs.getString("button_text"));
                    u.setButton_link(rs.getString("button_link"));
                    
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    public static int upload_slider(String file_link, String title, String button_text, String button_link, String created_by, String ip_add, java.sql.Timestamp date) throws SQLException {
        int i = 0;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("insert into slider (file_link,title,button_text,button_link,created_by,ipadd,date) values(?,?,?,?,?,?,?) ");
                ps.setString(1, file_link);
                ps.setString(2, title);
                ps.setString(3, button_text);
                ps.setString(4, button_link);
                ps.setString(5, created_by);
                ps.setString(6, ip_add);
                ps.setTimestamp(7, date);
                
                int r = ps.executeUpdate();
                
                if (r > 0) {
                    i = 1;
                } else {
                    i = 0;
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return i;
    }

    public static int update_slider(int id, String file_link, String title, String button_text, String button_link, String created_by, String ip_add, java.sql.Timestamp date) {
        int status = 0;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("update slider set file_link=?,title=?,button_text=?,button_link=?,created_by=?,ipadd=?,date=? where id=?");
                
                ps.setString(1, file_link);
                ps.setString(2, title);
                ps.setString(3, button_text);
                ps.setString(4, button_link);
                ps.setString(5, created_by);
                ps.setString(6, ip_add);
                ps.setTimestamp(7, date);
                ps.setInt(8, id);
                status = ps.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return status;
    }

    public static int delete_slider(String file_link) {
        int status = 0;
        String fileName = Paths.get(file_link).getFileName().toString();
        String file = "/home/unixon/Documents/bharam_shakti/web/images/" + fileName;
        boolean b = UserDao.deleteImage(file);

        try {

            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("delete from slider where file_link=?");
                
                ps.setString(1, file_link);
                if (b) {
                    status = ps.executeUpdate();
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }

        return status;
    }

    public static String Link_of_Slider(InputStream inputstream, String fileName) {

        OutputStream outputstream = null;
        String name = "/home/unixon/Documents/bharam_shakti/web/images/" + fileName;
        String name2 = "/bharam_shakti/images/" + fileName;
        try {

            outputstream = new FileOutputStream(new File(name));
            int read = 0;
            byte[] bytes = new byte[1024];

            while ((read = inputstream.read(bytes)) != -1) {
                outputstream.write(bytes, 0, read);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (outputstream != null) {
                try {
                    // outputStream.flush();
                    outputstream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }
        return name2;
    }

    public static boolean deleteImage(String file_link) {
        boolean b = false;

        try {
            File file = new File(file_link);
            if (file.exists()) {
                b = file.delete();

            } else {
                b = true;
            }

        } catch (Exception e) {
            System.out.println("Exception occured");
        }
        return b;
    }

    //Slider's Function End
    
    
    
    //Index's page Function End
    
    public static int update_index(int id, String file_link, String title, String content, String created_by, String ip_add,String parent_link ,java.sql.Timestamp date) {
        int status = 0;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("update indexx set file_link=?,title=?,content=?,created_by=?,ipadd=?,parent_link=?,date=? where id=?");
                
                ps.setString(1, file_link);
                ps.setString(2, title);
                ps.setString(3, content);
                ps.setString(4, created_by);
                ps.setString(5, ip_add);
                ps.setString(6, parent_link);
                ps.setTimestamp(7, date);
                ps.setInt(8, id);
                status = ps.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return status;
    }

    
      public static List<Index> getallrecordfrom_index() {

        List<Index> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link,title,content,parent_link from indexx");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Index u = new Index();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setContent(rs.getString("content"));
                    u.setParent_link(rs.getString("parent_link"));
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }
    
    
    public static Index getRecordBy_index_id(int id) {
        Index u = null;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link,title,content,parent_link from indexx where id=?");
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    u = new Index();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setContent(rs.getString("content"));
                    u.setParent_link(rs.getString("parent_link"));
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return u;
    }
    
    
    
    public static List<Index> index_rehabilation(String parent_link) {

        List<Index> list = new ArrayList<>();
        
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select file_link,title,content from indexx where parent_link=? order by id asc");
                ps.setString(1, parent_link);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Index u = new Index();
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setContent(rs.getString("content"));
                    
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

     public static List index_rehabilation_list(String parent_link) {

        List list = new ArrayList<>();
        
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select file_link,title,content from indexx where parent_link=? order by id asc");
                ps.setString(1, parent_link);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    list.add(rs.getString("file_link"));
                    list.add(rs.getString("title"));
                    list.add(rs.getString("content"));
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    //Index Function End
    
    
    
    
    
    
    //About Us Function Start
    public static int upload_about_us(String file_link, String title, String parent_link, String content, String created_by, String ip_add, java.sql.Timestamp date) throws SQLException {
        int i = 0;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("insert into about_us (file_link,title,parent_link,content,created_by,ipadd,date) values(?,?,?,?,?,?,?) ");
                ps.setString(1, file_link);
                ps.setString(2, title);
                ps.setString(3, parent_link);
                ps.setString(4, content);
                ps.setString(5, created_by);
                ps.setString(6, ip_add);
                ps.setTimestamp(7, date);
                
                int r = ps.executeUpdate();
                
                if (r > 0) {
                    i = 1;
                } else {
                    i = 0;
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return i;
    }

    public static List<About_us> getallrecordfrom_about_us() {

        List<About_us> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link,title,child_link,content from about_us");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    About_us u = new About_us();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setChild_link(rs.getString("child_link"));
                    u.setContent(rs.getString("content"));
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    public static About_us getRecordBy_about_us_id(int id) {
        About_us u = null;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link,title,child_link,content from about_us where id=?");
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    u = new About_us();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setChild_link(rs.getString("child_link"));
                    u.setContent(rs.getString("Content"));
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return u;
    }

    public static int update_about_us(int id, String file_link, String title, String content, String created_by, String ip_add, java.sql.Timestamp date) {
        int status = 0;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("update about_us set file_link=?,title=?,content=?,created_by=?,ipadd=?,date=? where id=?");
                
                ps.setString(1, file_link);
                ps.setString(2, title);
                ps.setString(3, content);
                ps.setString(4, created_by);
                ps.setString(5, ip_add);
                ps.setTimestamp(6, date);
                ps.setInt(7, id);
                
                status = ps.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return status;
    }

    public static int delete_about_us(String file_link) {
       int status = 0;
        String fileName = Paths.get(file_link).getFileName().toString();
        String file = "/home/unixon/Documents/bharam_shakti/web/images/" + fileName;
        boolean b = UserDao.deleteImage(file);

        try {

           try (Connection con = getConnection()) {
               PreparedStatement ps = con.prepareStatement("delete from about_us where file_link=?");
               
               ps.setString(1, file_link);
               if (b) {
                   status = ps.executeUpdate();
               }
           }
        } catch (SQLException e) {
            System.out.println(e);
        }

        return status;
    }

    public static String Link_of_About_us(InputStream inputstream, String fileName) {

        OutputStream outputstream = null;
        String name = "/home/unixon/Documents/bharam_shakti/web/images/" + fileName;
        String name2 = "/bharam_shakti/images/" + fileName;
        try {

            outputstream = new FileOutputStream(new File(name));
            int read = 0;
            byte[] bytes = new byte[1024];

            while ((read = inputstream.read(bytes)) != -1) {
                outputstream.write(bytes, 0, read);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (outputstream != null) {
                try {
                    // outputStream.flush();
                    outputstream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }
        return name2;
    }

    

    public static List aboutus_Search_Child(String parent_link) {

        List list = new ArrayList();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id from about_us where parent_link=?");
                ps.setString(1, parent_link);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    list.add(rs.getString("id"));
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

public static List<About_us> aboutus_Data_main_data(int id) {

        List<About_us> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select file_link,title,content from about_us where id=?");
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    About_us u = new About_us();
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setContent(rs.getString("content"));
                    
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    public static int about_us_id_fetch()
{
    List list = new ArrayList<>();
    int i;
      try {
        try (Connection con = getConnection()) {
            PreparedStatement ps = con.prepareStatement("select id from about_us order by id asc limit 1");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(rs.getString("id"));
            }
        }
        } catch (SQLException e) {
            System.out.println(e);
        }
      i = Integer.parseInt(list.get(0).toString());
        return i;
}
   
    //About Us Function End 
    
    
    //Facilities Page's Functions
    
    public static List<Facilities> getallrecordfrom_facilities() {

        List<Facilities> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select * from facilities");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Facilities u = new Facilities();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setChild_link(rs.getString("child_link"));
                    u.setContent(rs.getString("content"));
                    u.setCreated_by(rs.getString("created_by"));
                    u.setIpadd(rs.getString("ipadd"));
                    
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }
    
    
    public static Facilities getRecordBy_facilities_id(int id) {
        Facilities u = null;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select * from facilities where id=?");
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    u = new Facilities();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setChild_link(rs.getString("child_link"));
                    u.setContent(rs.getString("Content"));
                    /*u.setCreated_by(rs.getString("created_by"));
                    u.setIpadd(rs.getString("ipadd"));*/
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return u;
    }

    
    public static String Link_of_facilities(InputStream inputstream, String fileName) {

        OutputStream outputstream = null;
        String name = "/home/unixon/Documents/bharam_shakti/web/images/"+fileName;
        String name2 = "/bharam_shakti/images/" + fileName;
        try {

            outputstream = new FileOutputStream(new File(name));
            int read = 0;
            byte[] bytes = new byte[1024];

            while ((read = inputstream.read(bytes)) != -1) {
                outputstream.write(bytes, 0, read);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (outputstream != null) {
                try {
                    // outputStream.flush();
                    outputstream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }
        return name2;
    }

public static int update_facilities(int id, String file_link, String title, String child_link, String content, String created_by, String ip_add,java.sql.Timestamp date) {
        int status = 0;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("update facilities set file_link=?,title=?,child_link=?,content=?,created_by=?,ipadd=?,date=? where id=?");
                
                ps.setString(1, file_link);
                ps.setString(2, title);
                ps.setString(3, child_link);
                ps.setString(4, content);
                ps.setString(5, created_by);
                ps.setString(6, ip_add);
                ps.setTimestamp(7, date);
                ps.setInt(8, id);
                status = ps.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return status;
    }

public static List facilities_Search_Child(String parent_link) {

        List list = new ArrayList();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id from facilities where parent_link=?");
                ps.setString(1, parent_link);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    list.add(rs.getString("id"));
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

public static List<Facilities> facilities_Data_main_data(int id) {

        List<Facilities> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select file_link,title,content from facilities where id=?");
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Facilities u = new Facilities();
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setContent(rs.getString("content"));
                    
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }


public static int facilities_id_fetch()
{
    List list = new ArrayList<>();
    int i;
      try {
        try (Connection con = getConnection()) {
            PreparedStatement ps = con.prepareStatement("select id from facilities order by id asc limit 1");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(rs.getString("id"));
            }
        }
        } catch (SQLException e) {
            System.out.println(e);
        }
      i = Integer.parseInt(list.get(0).toString());
        return i;
}
   
//Facilities's Page Funtions end




//Services's Page Funtions Start

 public static List<Services> getallrecordfrom_services() {

        List<Services> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select * from services");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Services u = new Services();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setChild_link(rs.getString("child_link"));
                    u.setContent(rs.getString("content"));
                    u.setCreated_by(rs.getString("created_by"));
                    u.setIpadd(rs.getString("ipadd"));
                    
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }
    
    
    public static Services getRecordBy_services_id(int id) {
        Services u = null;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select * from services where id=?");
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    u = new Services();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setChild_link(rs.getString("child_link"));
                    u.setContent(rs.getString("Content"));
                    /*u.setCreated_by(rs.getString("created_by"));
                    u.setIpadd(rs.getString("ipadd"));*/
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return u;
    }

    
    public static String Link_of_services(InputStream inputstream, String fileName) {

        OutputStream outputstream = null;
        String name = "/home/unixon/Documents/bharam_shakti/web/images/"+fileName;
        String name2 = "/bharam_shakti/images/" + fileName;
        try {

            outputstream = new FileOutputStream(new File(name));
            int read = 0;
            byte[] bytes = new byte[1024];

            while ((read = inputstream.read(bytes)) != -1) {
                outputstream.write(bytes, 0, read);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (outputstream != null) {
                try {
                    // outputStream.flush();
                    outputstream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }
        return name2;
    }

public static int update_services(int id, String file_link, String title, String child_link, String content, String created_by, String ip_add, java.sql.Timestamp date) {
        int status = 0;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("update services set file_link=?,title=?,child_link=?,content=?,created_by=?,ipadd=?,date=? where id=?");
                
                ps.setString(1, file_link);
                ps.setString(2, title);
                ps.setString(3, child_link);
                ps.setString(4, content);
                ps.setString(5, created_by);
                ps.setString(6, ip_add);
                ps.setTimestamp(7, date);
                ps.setInt(8, id);
                status = ps.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return status;
    }

public static List services_Search_Child(String parent_link) {

        List list = new ArrayList();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id from services where parent_link=?");
                ps.setString(1, parent_link);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    list.add(rs.getString("id"));
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

public static List<Services> services_Data_main_data(int id) {

        List<Services> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select file_link,title,content from services where id=?");
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Services u = new Services();
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setContent(rs.getString("content"));
                    
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }


public static int services_id_fetch()
{
    List list = new ArrayList<>();
    int i;
      try {
        try (Connection con = getConnection()) {
            PreparedStatement ps = con.prepareStatement("select id from services order by id asc limit 1");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(rs.getString("id"));
            }
        }
        } catch (SQLException e) {
            System.out.println(e);
        }
      i = Integer.parseInt(list.get(0).toString());
        return i;
}
   
//Services's Page Funnction End






//Staff's Function Start
public static int upload_staff(String file_link, String title, String position, String created_by, String ip_add , java.sql.Timestamp date) throws SQLException {
        int i = 0;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("insert into staff (file_link,title,position,created_by,ipadd,date) values(?,?,?,?,?,?) ");
                ps.setString(1, file_link);
                ps.setString(2, title);
                ps.setString(3, position);
                ps.setString(4, created_by);
                ps.setString(5, ip_add);
                ps.setTimestamp(6, date);
                
                i = ps.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return i;
    }

    public static List<Staff> getallrecordfrom_staff() {

        List<Staff> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link,title,position from staff");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Staff u = new Staff();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setPosition(rs.getString("position"));
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    public static Staff getRecordBy_staff_id(int id) {
        Staff u = null;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select * from staff where id=?");
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    u = new Staff();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setPosition(rs.getString("position"));
                    /*u.setCreated_by(rs.getString("created_by"));
                    u.setIpadd(rs.getString("ipadd"));*/
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return u;
    }

    public static int update_staff(int id, String file_link, String title, String position,String created_by, String ip_add , java.sql.Timestamp date) {
        int status = 0;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("update staff set file_link=?,title=?,position=?,created_by=?,ipadd=?,date=? where id=?");
                
                ps.setString(1, file_link);
                ps.setString(2, title);
                ps.setString(3, position);
                ps.setString(4, created_by);
                ps.setString(5, ip_add);
                ps.setTimestamp(6, date);
                ps.setInt(7, id);
                status = ps.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return status;
    }

    public static int delete_staff(String file_link) {
       int status = 0;
        String fileName = Paths.get(file_link).getFileName().toString();
        String file = "/home/unixon/Documents/bharam_shakti/web/images/" + fileName;
        boolean b = UserDao.deleteImage(file);

        try {

           try (Connection con = getConnection()) {
               PreparedStatement ps = con.prepareStatement("delete from staff where file_link=?");
               
               ps.setString(1, file_link);
               if (b) {
                   status = ps.executeUpdate();
               }
           }
        } catch (SQLException e) {
            System.out.println(e);
        }

        return status;
    }

    
    public static List<Staff> staff_Data() {

        List<Staff> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select file_link,title,position from staff ");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Staff u = new Staff();
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setPosition(rs.getString("position"));
                    
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    
//Staff's Function End

    
    
    
    //News Events Function Start
public static int upload_news_events(String file_link,String file_link2, String title, Date sdate,String description,String content, String created_by, String ip_add,java.sql.Timestamp date) throws SQLException {
        int i = 0;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("insert into news_events (file_link,file_link2,title,sdate,description,content,created_by,ipadd,datetm) values(?,?,?,?,?,?,?,?,?) ");
                ps.setString(1, file_link);
                ps.setString(2, file_link2);
                ps.setString(3, title);
                ps.setDate(4, sdate);
                ps.setString(5, description);
                ps.setString(6, content);
                ps.setString(7, created_by);
                ps.setString(8, ip_add);
                ps.setTimestamp(9, date);
                
                i = ps.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return i;
    }

    public static List<News_events> getallrecordfrom_news_events() {

        List<News_events> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link,file_link2,title,sdate,description,content from news_events");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    News_events u = new News_events();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setFile_link2(rs.getString("file_link2"));
                    u.setTitle(rs.getString("title"));
                    u.setSdate(rs.getDate("sdate"));
                    u.setDescription(rs.getString("description"));
                    u.setContent(rs.getString("content"));
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    public static News_events getRecordBy_news_events_id(int id) {
        News_events u = null;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link,file_link2,title,sdate,description,content from news_events where id=?");
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    u = new News_events();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setFile_link2(rs.getString("file_link2"));
                    u.setTitle(rs.getString("title"));
                    u.setSdate(rs.getDate("sdate"));
                    u.setDescription(rs.getString("description"));
                    u.setContent(rs.getString("content"));
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return u;
    }

    public static int update_news_events(int id, String file_link, String file_link2, String title, Date sdate,String description,String content,String created_by, String ip_add,java.sql.Timestamp date) {
        int status = 0;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("update news_events set file_link=?,file_link2=?,title=?,sdate=?,description=?,content=?,created_by=?,ipadd=?,datetm=? where id=?");
                
                ps.setString(1, file_link);
                ps.setString(2, file_link2);
                ps.setString(3, title);
                ps.setDate(4, sdate);
                ps.setString(5, description);
                ps.setString(6, content);
                ps.setString(7, created_by);
                ps.setString(8, ip_add);
                ps.setTimestamp(9, date);
                ps.setInt(10, id);
                status = ps.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return status;
    }

    public static int delete_news_events(String file_link,String file_link2) {
       int status = 0;
        String fileName = Paths.get(file_link).getFileName().toString();
        String file = "/home/unixon/Documents/bharam_shakti/web/images/" + fileName;
        boolean b = UserDao.deleteImage(file);
        
        String fileName2 = Paths.get(file_link2).getFileName().toString();
        String file2 = "/home/unixon/Documents/bharam_shakti/web/images/" + fileName2;
        boolean b2 = UserDao.deleteImage(file2);

        try {

           try (Connection con = getConnection()) {
               PreparedStatement ps = con.prepareStatement("delete from news_events where file_link=?");
               
               ps.setString(1, file_link);
               if (b && b2) {
                   status = ps.executeUpdate();
               }
           }
        } catch (SQLException e) {
            System.out.println(e);
        }

        return status;
    }

    
    public static List<News_events> news_events_Data() {

        List<News_events> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link,title,sdate,description from news_events order by id desc; ");
                
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    News_events u = new News_events();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setSdate(rs.getDate("sdate"));
                    u.setDescription(rs.getString("description"));
                    
                    
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }
    
    
    public static List<News_events> news_events_Data_media1_after() {

        List<News_events> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link,title,sdate from news_events order by id desc; ");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    News_events u = new News_events();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setSdate(rs.getDate("sdate"));
                    
                    
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }
    
     public static List news_events_Data_id(int id) {

        List list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select file_link2,title,sdate,content from news_events where id=? ");
                ps.setInt(1,id);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    
                    list.add(rs.getString("file_link2"));
                    list.add(rs.getString("title"));
                    list.add(rs.getDate("sdate"));
                    list.add(rs.getString("content"));
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }
     
     
   

    // News Events Function Stop
    
 //Success Function Start
     
     
     public static int upload_success_stories(String file_link,String file_link2, String title, Date sdate,String description,String content, String created_by, String ip_add,java.sql.Timestamp date) throws SQLException {
        int i = 0;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("insert into success_stories (file_link,file_link2,title,sdate,description,content,created_by,ipadd,datetm) values(?,?,?,?,?,?,?,?,?) ");
                ps.setString(1, file_link);
                ps.setString(2, file_link2);
                ps.setString(3, title);
                ps.setDate(4, sdate);
                ps.setString(5, description);
                ps.setString(6, content);
                ps.setString(7, created_by);
                ps.setString(8, ip_add);
                ps.setTimestamp(9, date);
                
                i = ps.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return i;
    }

    public static List<Success_stories> getallrecordfrom_success_stories() {

        List<Success_stories> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link,file_link2,title,sdate,description,content from success_stories");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Success_stories u = new Success_stories();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setFile_link2(rs.getString("file_link2"));
                    u.setTitle(rs.getString("title"));
                    u.setSdate(rs.getDate("sdate"));
                    u.setDescription(rs.getString("description"));
                    u.setContent(rs.getString("content"));
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    public static Success_stories getRecordBy_success_stories_id(int id) {
        Success_stories u = null;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link,file_link2,title,sdate,description,content from success_stories where id=?");
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    u = new Success_stories();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setFile_link2(rs.getString("file_link2"));
                    u.setTitle(rs.getString("title"));
                    u.setSdate(rs.getDate("sdate"));
                    u.setDescription(rs.getString("description"));
                    u.setContent(rs.getString("content"));
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return u;
    }

    public static int update_success_stories(int id, String file_link, String file_link2, String title, Date sdate,String description,String content,String created_by, String ip_add,java.sql.Timestamp date) {
        int status = 0;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("update success_stories set file_link=?,file_link2=?,title=?,sdate=?,description=?,content=?,created_by=?,ipadd=?,datetm=? where id=?");
                
                ps.setString(1, file_link);
                ps.setString(2, file_link2);
                ps.setString(3, title);
                ps.setDate(4, sdate);
                ps.setString(5, description);
                ps.setString(6, content);
                ps.setString(7, created_by);
                ps.setString(8, ip_add);
                ps.setTimestamp(9, date);
                ps.setInt(10, id);
                status = ps.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return status;
    }

    public static int delete_success_stories(String file_link,String file_link2) {
       int status = 0;
        String fileName = Paths.get(file_link).getFileName().toString();
        String file = "/home/unixon/Documents/bharam_shakti/web/images/" + fileName;
        boolean b = UserDao.deleteImage(file);
        
        String fileName2 = Paths.get(file_link2).getFileName().toString();
        String file2 = "/home/unixon/Documents/bharam_shakti/web/images/" + fileName2;
        boolean b2 = UserDao.deleteImage(file2);

        try {

           try (Connection con = getConnection()) {
               PreparedStatement ps = con.prepareStatement("delete from success_stories where file_link=?");
               
               ps.setString(1, file_link);
               if (b && b2) {
                   status = ps.executeUpdate();
               }
           }
        } catch (SQLException e) {
            System.out.println(e);
        }

        return status;
    }

    
    public static List<Success_stories> success_stories_Data() {

        List<Success_stories> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link,title,sdate,description from success_stories order by id desc;");
                
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Success_stories u = new Success_stories();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setSdate(rs.getDate("sdate"));
                    u.setDescription(rs.getString("description"));
                    
                    
                    
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }
    
    public static List<Success_stories> success_stories_Data_media1_after() {

        List<Success_stories> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link,title,sdate from success_stories order by id desc;");
                
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Success_stories u = new Success_stories();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    u.setSdate(rs.getDate("sdate"));
                    
                    
                    
                    
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }
        
     public static List success_stories_Data_id(int id) {

        List list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select file_link2,title,sdate,content from success_stories where id=? ");
                ps.setInt(1,id);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    
                    list.add(rs.getString("file_link2"));
                    list.add(rs.getString("title"));
                    list.add(rs.getDate("sdate"));
                    list.add(rs.getString("content"));
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

     
    // Success  Function Stop
    

 //Photo Gallery Function Start
public static int upload_photo_gallery(String file_link, String title,String created_by, String ip_add) throws SQLException {
        int i = 0;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("insert into photo_gallery (file_link,title,created_by,ipadd) values(?,?,?,?) ");
                ps.setString(1, file_link);
                ps.setString(2, title);
                ps.setString(3, created_by);
                ps.setString(4, ip_add);
                
                i = ps.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return i;
    }

    public static List<Photo_gallery> getallrecordfrom_photo_gallery() {

        List<Photo_gallery> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link,title from photo_gallery");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Photo_gallery u = new Photo_gallery();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    public static Photo_gallery getRecordBy_photo_gallery_id(int id) {
        Photo_gallery u = null;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link,title from photo_gallery where id=?");
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    u = new Photo_gallery();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return u;
    }

    public static int update_photo_gallery(int id, String file_link, String title,String created_by, String ip_add) {
        int status = 0;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("update photo_gallery set file_link=?,title=?,created_by=?,ipadd=? where id=?");
                
                ps.setString(1, file_link);
                ps.setString(2, title);
                ps.setString(3, created_by);
                ps.setString(4, ip_add);
                ps.setInt(5, id);
                status = ps.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return status;
    }

    public static int delete_photo_gallery(String file_link) {
       int status = 0;
        String fileName = Paths.get(file_link).getFileName().toString();
        String file = "/home/unixon/Documents/bharam_shakti/web/images/" + fileName;
        boolean b = UserDao.deleteImage(file);

        try {

           try (Connection con = getConnection()) {
               PreparedStatement ps = con.prepareStatement("delete from photo_gallery where file_link=?");
               
               ps.setString(1, file_link);
               if (b) {
                   status = ps.executeUpdate();
               }
           }
        } catch (SQLException e) {
            System.out.println(e);
        }

        return status;
    }

    
    public static List<Photo_gallery> photo_gallery_Data() {

        List<Photo_gallery> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link,title from photo_gallery ");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Photo_gallery u = new Photo_gallery();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    u.setTitle(rs.getString("title"));
                    
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    // Photo Gallery Function Stop
    
    

 //video Gallery Function Start
public static int upload_video_gallery(String file_link,String created_by, String ip_add,java.sql.Timestamp date) throws SQLException {
        int i = 0;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("insert into video_gallery (file_link,created_by,ipadd,date) values(?,?,?,?) ");
                ps.setString(1, file_link);
                ps.setString(2, created_by);
                ps.setString(3, ip_add);
                ps.setTimestamp(4, date);
                
                i = ps.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return i;
    }

    public static List<Video_gallery> getallrecordfrom_video_gallery() {

        List<Video_gallery> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link from video_gallery");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Video_gallery u = new Video_gallery();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    public static Video_gallery getRecordBy_video_gallery_id(int id) {
        Video_gallery u = null;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link from video_gallery where id=?");
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    u = new Video_gallery();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return u;
    }

    public static int update_video_gallery(int id, String file_link,String created_by, String ip_add, java.sql.Timestamp date) {
        int status = 0;
        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("update video_gallery set file_link=?,created_by=?,ipadd=?,date=? where id=?");
                
                ps.setString(1, file_link);
                ps.setString(2, created_by);
                ps.setString(3, ip_add);
                ps.setTimestamp(4, date);
                ps.setInt(5, id);
                status = ps.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return status;
    }

    public static int delete_video_gallery(String file_link) {
       int status = 0;
        
        try {

           try (Connection con = getConnection()) {
               PreparedStatement ps = con.prepareStatement("delete from video_gallery where file_link=?");
               
               ps.setString(1, file_link);
               status = ps.executeUpdate();
           }
        } catch (SQLException e) {
            System.out.println(e);
        }

        return status;
    }

    
    public static List<Video_gallery> video_gallery_Data() {

        List<Video_gallery> list = new ArrayList<>();

        try {
            try (Connection con = getConnection()) {
                PreparedStatement ps = con.prepareStatement("select id,file_link from video_gallery ");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Video_gallery u = new Video_gallery();
                    u.setId(rs.getInt("id"));
                    u.setFile_link(rs.getString("file_link"));
                    
                    list.add(u);
                    
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    // video Gallery Function Stop
    
}    
