/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bharam_shakti.bean;

import java.sql.Timestamp;

/**
 *
 * @author unixon
 */
public class Services {
 
    protected int id;
    protected String file_link;
  protected  String title;
  protected  String child_link;
  protected  String content;
  protected  String created_by;
  protected String ipadd;
  protected String parent_link;
    protected java.sql.Timestamp date;
    

    public Timestamp getDate() {
        return date;
    }

    public void setDate(Timestamp date) {
        this.date = date;
    }
    
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFile_link() {
        return file_link;
    }

    public void setFile_link(String file_link) {
        this.file_link = file_link;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getChild_link() {
        return child_link;
    }

    public void setChild_link(String child_link) {
        this.child_link = child_link;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public String getIpadd() {
        return ipadd;
    }

    public void setIpadd(String ipadd) {
        this.ipadd = ipadd;
    }

    public String getParent_link() {
        return parent_link;
    }

    public void setParent_link(String parent_link) {
        this.parent_link = parent_link;
    }

  
}
