<?php

class ProductModel extends CI_Model
{
	function __construct() {
		parent::__construct();
	}
	
	function checkSKUExists($skunumber){
		
		$url = WEBSERVICE_URL . "account/checkSkuNumberExists?skuNumber=".$skunumber;
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callWebService($url,$header,'',"GET");		
		return $output;	
	}
        
	function getProductList($filters){
		
		$url = WEBSERVICE_URL . "account/getAllProducts";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$filters,"POST");		
		return $output;		
	}
	
	function getAccountById($accountId){
		
		$url = WEBSERVICE_URL . "account/findById/".$accountId;
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callWebService($url,$header,'',"GET");		
		return $output;		
	}
	
	function getAllLocations($filters){
		
		$url = WEBSERVICE_URL . "location/getAll";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$filters,"POST");		
		return $output;		
	}
	
	function getAccountList($filters){
		
		$url = WEBSERVICE_URL . "account/getAll";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$filters,"POST");		
		
		if($output["responseStatusCode"] == 403){
			redirect('Login/tokenExpire', 'refresh');
		}else{
			return $output;	
		}		
	}
	
	function getLocationById($locationId){
		///api/v1/location/findById/{id}
		$url = WEBSERVICE_URL . "location/findById/".$locationId;
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callWebService($url,$header,'',"GET");		
		return $output;		
	}
	
	function getProductDetailsById($productId){
		//api/v1/order/findById/{id}
		$url = WEBSERVICE_URL . "account/findProductById/".$productId;
		
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callWebService($url,$header,'',"GET");		
		return $output;		
	}
	
	function getAllSKUBySkuType($skuType,$accountId){
		//api/v1/order/findById/{id}
		$url = WEBSERVICE_URL . "account/findProductsBySkuType?skuType=".$skuType."&accountId=".$accountId;
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callWebService($url,$header,'',"GET");		
		return $output;		
	}
	
	function createProduct($data){
		
		$url = WEBSERVICE_URL . "account/addProduct?accountId=".$data["accountId"]."&skuType=".$data["skuType"];
		//$url = WEBSERVICE_URL . "account/addProduct?skuType=".$data["skuType"]."&accountId=".$data["accountId"];
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"POST");		
		return $output;		
	}
	
	function updateProduct($data){
		
		$url = WEBSERVICE_URL . "account/updateComponent/".$data["accountId"];
		//$url = WEBSERVICE_URL . "account/addProduct?skuType=".$data["skuType"]."&accountId=".$data["accountId"];
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"PUT");		
		return $output;		
	}
	
}