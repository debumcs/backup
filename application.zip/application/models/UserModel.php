<?php

class UserModel extends CI_Model
{
	function __construct() {
		parent::__construct();
	}
        
	function getUserById($userId){
		
		$url = WEBSERVICE_URL . "user/".$userId;
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callWebService($url,$header,'',"GET");		
		return $output;		
	}
	
	function checkUserNameExists($username){
		
		$url = WEBSERVICE_URL . "user/checkUserNameExists?userName=".$username;
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callWebService($url,$header,'',"GET");		
		return $output;	
	}
	
	function createUser($data){
		
		$url = WEBSERVICE_URL . "user/signUp";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"POST");		
		return $output;		
	}
	
	function updateUser($data){
		
		$url = WEBSERVICE_URL . "user/update";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"PUT");
		return $output;		
	}

	function getUserList($data){
		
		$url = WEBSERVICE_URL . "user/getAll";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"POST");		
		return $output;		
	}
	
	function createPassword($data){
		
		$url = WEBSERVICE_URL . "user/createPassword";
		$RequestToken = $data['requestToken'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"RequestToken:$RequestToken",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"POST");		
		return $output;		
	}
}