<?php

class LoginModel extends CI_Model
{
	function __construct() {
		parent::__construct();
	}
        
	function login($data){
		
		$url = WEBSERVICE_URL . "user/login";
		
		//$url = 'http://14.143.158.230/ezr/Users/login';
		
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"POST");		
		return $output;		
	}
	
	function logout(){
		
		$token = $this->session->userdata['token'];
		
		$url = WEBSERVICE_URL . "user/logoutUser?token=".$token;
		
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,'',"PUT");		
		return $output;
		
	}
	
	/*function updateOrder($data){
		
		$url = WEBSERVICE_URL . "order/updateOrder";
		$token = $this->session->userdata['token'];
		$header = array(
			"device-type: Web",
			"ver: 1.0",
			"auth-token:$token",
			"content-type: application/json"
		  );
		
		$output = callPostMethod($url,$header,$data,"PUT");		
		return $output;		
	}*/
}