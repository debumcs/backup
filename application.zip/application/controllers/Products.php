<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {

	function __construct() {
		parent::__construct();
		validateToken();
		$this->load->model('ProductModel','ProductModel');
	}
	
	public function getAllAccounts(){
		validateToken();
		$filters = array(
			array("key"=>"AccountId","value"=>$this->input->post('AccountId')),
			array("key"=>"AccountName","value"=>$this->input->post('AccountName')),
			array("key"=>"AccountNickName","value"=>$this->input->post('AccountNickName')),
			array("key"=>"AccountStatus","value"=>$this->input->post('AccountStatus'))
		);
		
		$out = $this->ProductModel->getAccountList($filters);
		echo json_encode($out);
	}
	
	public function checkSKUExists($skunumber){
		
		$out = $this->ProductModel->checkSKUExists($skunumber);
		echo json_encode($out);
	}
	
	public function addProduct()
	{
		$data1 = array();
		$data['body'] = $this->load->view('products/addProduct', $data1, true);
		$this->load->view('template', $data);
	}
	
	public function getAllSKUBySkuType($skuType,$accountId){
		$out = $this->ProductModel->getAllSKUBySkuType($skuType,$accountId);
		echo json_encode($out);
	}
	
	public function create_product(){
		$dataList = array();
		if($this->input->post('qty')){
			$productNumber = $this->input->post('productNumber');
			$skunumber = $this->input->post('skunumber');
			$skuTypes = $this->input->post('skuTypes');
			$qty = $this->input->post('qty');
			$wgt = $this->input->post('wgt');
			
			foreach ($qty as $key => $value){
				$dataList[] = array(
					"productId"=>$productNumber[$key],
					"skuNumber"=>$skunumber[$key],
					"quantity"=>intval($qty[$key]),
					"skuType"=>intval($skuTypes[$key]),
					"weight"=>intval($wgt[$key]),
					"extWeight"=>(intval($qty[$key])*intval($wgt[$key]))
				);
			}
		}
		
		$data = array(
			"accountId"=>$this->input->post('accountNumber'),
			"dataList"=>$dataList,
			"description"=>$this->input->post('description'),
			"height"=>intval($this->input->post('height')),
			"length"=>intval($this->input->post('length')),	
			"quantity"=>intval($this->input->post('quantity')),
			"sequence"=>$this->input->post('sequence'),
			"skuNumber"=>$this->input->post('skuNumber'),
			"skuType"=>intval($this->input->post('skuType')),
			"weight"=>intval($this->input->post('weight')),
			"width"=>intval($this->input->post('width')),
			"showInInventory"=>boolval($this->input->post('showInInventory')),
			"isSerialized"=>boolval($this->input->post('isSerialized'))
		);
		
		//$_SESSION["ORDERDATA"] = $data;
		//echo json_encode($data); exit;
		
		$out = $this->ProductModel->createProduct($data);
		echo json_encode($out);
	}
	
	public function update_product(){
		$dataList = array();
		if($this->input->post('qty')){
			$productNumber = $this->input->post('productNumber');
			$skunumber = $this->input->post('skunumber');
			$skuTypes = $this->input->post('skuTypes');
			$qty = $this->input->post('qty');
			$wgt = $this->input->post('wgt');
			$id = $this->input->post('id');
			
			foreach ($qty as $key => $value){
				//$idxyz = ''; $idxyz = intval($id[$key]) ? intval($id[$key]) : ;
				if(intval($qty[$key])>0){
					
					if(intval($id[$key])>0){
						$dataList[] = array(
							"id"=>intval($id[$key]),
							"productId"=>$productNumber[$key],
							"skuNumber"=>$this->input->post('skuNumber'),
							"quantity"=>intval($qty[$key]),
							"skuType"=>intval($skuTypes[$key]),
							"weight"=>intval($wgt[$key]),
							"extWeight"=>(intval($qty[$key])*intval($wgt[$key]))
						);
					}else{
						$dataList[] = array(
							"productId"=>$productNumber[$key],
							"skuNumber"=>$this->input->post('skuNumber'),
							"quantity"=>intval($qty[$key]),
							"skuType"=>intval($skuTypes[$key]),
							"weight"=>intval($wgt[$key]),
							"extWeight"=>(intval($qty[$key])*intval($wgt[$key]))
						);
					}
				}
				
			}
		}
		
		$data = array(
			"productId"=>$this->input->post('productId'),
			"accountId"=>$this->input->post('accountNumber'),
			"subComponents"=>$dataList,
			"description"=>$this->input->post('description'),
			"height"=>intval($this->input->post('height')),
			"length"=>intval($this->input->post('length')),	
			"quantity"=>intval($this->input->post('quantity')),
			"sequence"=>$this->input->post('sequence'),
			"skuNumber"=>$this->input->post('skuNumber'),
			"skuType"=>intval($this->input->post('skuType')),
			"weight"=>intval($this->input->post('weight')),
			"width"=>intval($this->input->post('width')),
			"showInInventory"=>boolval($this->input->post('showInInventory')),
			"isSerialized"=>boolval($this->input->post('isSerialized'))
		);
		
		//$_SESSION["ORDERDATA"] = $data;
		//echo json_encode($data); exit;
		
		$out = $this->ProductModel->updateProduct($data);
		echo json_encode($out);
	}
	
	public function product_confirm($productId){
		
		$data1['productDetails'] = $this->ProductModel->getProductDetailsById($productId);
		$data['body'] = $this->load->view('products/product_confirm', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function view_product($productId){
		
		$data1['productDetails'] = $this->ProductModel->getProductDetailsById($productId);
		$data['body'] = $this->load->view('products/view_product', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function edit_product($productId){
		
		$data1['productDetails'] = $this->ProductModel->getProductDetailsById($productId);
		$data['body'] = $this->load->view('products/editProduct', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function getOrderDetailsById($productId){
		
		$out = $this->ProductModel->getProductDetailsById($productId);
		echo json_encode($out);
	}
	
	public function viewAllProducts(){
		
		$data['body'] = $this->load->view('products/viewAllProducts', '', true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function getAllProducts(){
		$filters = array(
			array("key"=>"SKUNumber","value"=>$this->input->post('SKUNumber')),
			array("key"=>"SKUType","value"=>$this->input->post('SKUType')),
			array("key"=>"AccountName","value"=>$this->input->post('AccountName')),
			array("key"=>"AccountId","value"=>$this->input->post('AccountId'))
		);
		
		$out = $this->ProductModel->getProductList($filters);
		echo json_encode($out);
	}	
	
	public function getAccountById($acountId){
		
		$out = $this->ProductModel->getAccountById($acountId);
		echo json_encode($out);		
	}	
}
