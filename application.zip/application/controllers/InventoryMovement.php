<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class InventoryMovement extends CI_Controller {

	function __construct() {
		parent::__construct();
		//validateToken();
		$this->load->model('InventoryMovementModel');
	}
	
	public function index()
	{
		$data1 = array();
		$data['body'] = $this->load->view('inventoryMovement/sentToLocation', $data1, true);
		$this->load->view('template', $data);
	}
	
	public function sentToLocation()
	{
		$data1 = array();
		$data['body'] = $this->load->view('inventoryMovement/sentToLocationFileUpload', $data1, true);
		$this->load->view('template', $data);
	}
	
	public function sentToLocationFileUpload()
	{
		$filename = $_FILES['filename']['name'];
		$filedata = chunk_split(base64_encode(file_get_contents($_FILES['filename']['tmp_name'])));
		$filesize = $_FILES['filename']['size'];
		$filetype = $_FILES['filename']['type'];
		
		$data = array(
			"filename"=>$filename,
			"filedata"=>$filedata,
			"filesize"=>$filesize,
			"filetype"=>$filetype,
		);
		
		$out = $this->InventoryMovementModel->fileUpload($data);
		echo json_encode($out);
	}
	
	
}
