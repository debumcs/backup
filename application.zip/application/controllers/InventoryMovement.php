<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class InventoryMovement extends CI_Controller {

	function __construct() {
		parent::__construct();
		//validateToken();
		$this->load->model('InventoryMovementModel');
	}
	
	public function index()
	{
		$data1 = array();
		$data['body'] = $this->load->view('inventoryMovement/sentToLocation', $data1, true);
		$this->load->view('template', $data);
	}
	
	public function sentToLocationFileUpload()
	{
		$data1 = array();
		$data['body'] = $this->load->view('inventoryMovement/sentToLocationFileUpload', $data1, true);
		$this->load->view('template', $data);
	}
	
	
	
	
}
