<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	function __construct() {
		parent::__construct();
		validateToken();
		$this->load->model('UserModel');
	} 

	public function create(){
		$data1 = array();
		$data['body'] = $this->load->view('users/createUser', $data1, true);

		$this->load->view('template', $data);
	}

	public function create_user(){
		$data = array(
			"userName"=>$this->input->post('userName'),
			"employeeNumber"=>$this->input->post('employeeNumber'),
			"email"=>$this->input->post('email'),
			"firstName"=>$this->input->post('firstName'),
			"lastName"=>$this->input->post('lastName'),
			"phoneNumber"=>$this->input->post('phoneNumber'),
			"roleId"=>$this->input->post('roleId')
		);
		
		//echo json_encode($data);exit;
		
		$out = $this->UserModel->createUser($data);
		echo json_encode($out);
	}

	public function update_user(){
		$data = array(
			"userId"=>intval($this->input->post('userId')),
			"userName"=>$this->input->post('userName'),
			"employeeNumber"=>$this->input->post('employeeNumber'),
			"email"=>$this->input->post('email'),
			"firstName"=>$this->input->post('firstName'),
			"lastName"=>$this->input->post('lastName'),
			"phoneNumber"=>$this->input->post('phoneNumber'),
			"roleId"=>intval($this->input->post('roleId')),
			"userStatus"=>intval($this->input->post('userStatus')),
			"accountId"=>$this->input->post('accountId')
		);
		
		//echo json_encode($data);exit;
		
		$out = $this->UserModel->updateUser($data);
		echo json_encode($out);
	}

	public function user_confirm($userId){
		
		$data1['userDetails'] = $this->UserModel->getUserById($userId);
		$data['body'] = $this->load->view('users/confirmUser', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function view_user($userId){
		
		$data1['userDetails'] = $this->UserModel->getUserById($userId);
		$data['body'] = $this->load->view('users/viewUser', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function edit_user($userId){
		
		$data1['userDetails'] = $this->UserModel->getUserById($userId);
		$data['body'] = $this->load->view('users/editUser', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function getUserById($userId){
		
		$out = $this->UserModel->getUserById($userId);
		echo json_encode($out);
	}

	public function viewAllUsers(){
		$data1 = array();
		$data['body'] = $this->load->view('users/manageUser', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}

	public function getAllUsers(){
		$filters = array(
			array("key"=>"UserStatus","value"=>$this->input->post('UserStatus')),
			array("key"=>"FName","value"=>$this->input->post('FName')),
			array("key"=>"LName","value"=>$this->input->post('LName')),
			array("key"=>"UserName","value"=>$this->input->post('UserName'))
		);
		
		$out = $this->UserModel->getUserList($filters);
		echo json_encode($out);
	}
	
	public function checkUserNameExists($username){
		//$username = $this->input->post('username');
		
		$out = $this->UserModel->checkUserNameExists($username);
		echo json_encode($out);
	}
	
	//user/checkUserNameExists?userName=adil4583fsdfsdf
	
	public function login(){
		header("Access-Control-Allow-Origin: *");
		header("Access-Control-Allow-Headers: *");
		header("Access-Control-Allow-Methods: *");
		header("Access-Control-Allow-Credentials: true");
		
		//$userData = json_decode(file_get_contents('php://input'), true);
		
		$userData["userName"] = 'test';
		$userData["password"] = 'Advatix@123';
		
		$curl = curl_init();
		
		curl_setopt_array($curl, array(
		  CURLOPT_URL => "http://14.143.158.230/api/v1/user/login",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_CUSTOMREQUEST => "POST",
		  CURLOPT_POSTFIELDS => json_encode($userData),
		  CURLOPT_HTTPHEADER => array(
			"content-type: application/json",
			"device-type: Web",
			"ver: 1.0"
		  ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);
		
		if ($err) {
			echo "cURL Error #:" . $err;
			exit;
		} else {
			
			$res = json_decode($response,true);
			$session_data = array(  
				'token'=>$res["responseObject"]["webAuthToken"]
			);
			$this->session->set_userdata($session_data);
			echo rtrim($response,"1");
			exit;
		}
	}
	
	public function getToken()
	{
		echo $this->session->userdata('token');
		exit;		
	}
	
	public function logout(){
		
		$this->session->unset_userdata('token');
		$this->session->sess_destroy();
		
	}

}
