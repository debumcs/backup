<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accounts extends CI_Controller {

	function __construct(){
		parent::__construct();
		validateToken();
		$this->load->model('AccountModel','AccountModel');
	} 
	
	public function create_account()
	{
		$data1 = array();
		$data['body'] = $this->load->view('accounts/create_account', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}

	public function getAllLocations(){

		$filters = array(
			array("key"=>"LocationType","value"=>$this->input->post('locationSearchType')),
			array("key"=>"LocationId","value"=>$this->input->post('locationSearchID')),
			array("key"=>"LocationRef","value"=>$this->input->post('locationSearchCustRef')),
			array("key"=>"LocationName","value"=>$this->input->post('locationSearchCustomer')),
			array("key"=>"LocationUnit","value"=>$this->input->post('locationSearchUnit')),
			array("key"=>"LocationNickName","value"=>$this->input->post('locationSearchNickname'))
		);
		
		$out = $this->AccountModel->getAllLocations($filters);
		echo json_encode($out);
	}
	
	public function post_account(){
		
		$locationAssociationsIds = '';
		
		$adminDetails = array(
			"email"=>$this->input->post('email'),
			"employeeNumber"=>$this->input->post('employeeNumber'),
			"firstName"=>$this->input->post('firstName'),
			"lastName"=>$this->input->post('lastName'),
			"phoneNumber"=>$this->input->post('phoneNumber'),
			"userName"=>$this->input->post('userName')
		);
		
		$operationalHours = array();
		if($this->input->post('dayOpr') && $this->input->post('startTimeOpr') && $this->input->post('endTimeOpr')){
			$dayOpr 		= $this->input->post('dayOpr');
			$startTimeOpr 	= $this->input->post('startTimeOpr');
			$endTimeOpr 	= $this->input->post('endTimeOpr');
			foreach ($dayOpr as $key => $value){
				$startTime 	= '';
				$endTime	= '';
				
				$startTime 	= date("H:i:s", strtotime($startTimeOpr[$key]));
				$endTime 	= date("H:i:s", strtotime($endTimeOpr[$key]));
				
				$operationalHours[] = array(
					"day"=>$dayOpr[$key],
					"startTime"=>$startTime,
					"endTime"=>$endTime
				);
			}
		}
		
		$locationAssociationsIds = array();
		if($this->input->post('locationId')){
			$locationId 		= $this->input->post('locationId');
			$locationIds 	= $this->input->post('locationIds');
			
			foreach ($locationId as $key => $value){
				$locationAssociationsIds[] = $locationIds[$key];
			}
		}
		
		//$locationAssociationsIds = 

		$data = array(
			"accountType"=>intval($this->input->post('accountType')),
			"accountTypeShortCode"=>$this->input->post('accountTypeShortCode'),
			"addressLine1"=>$this->input->post('addressLine1'),
			"addressLine2"=>$this->input->post('addressLine2'),
			"adminDetails"=>$adminDetails,
			"businessPhone"=>$this->input->post('businessPhone'),
			"city"=>intval($this->input->post('city')),
			"companyName"=>$this->input->post('companyName'),
			"contactEmail"=>$this->input->post('contactEmail'),
			"contactName"=>$this->input->post('contactName'),
			"contactPhone"=>$this->input->post('contactPhone'),
			"country"=>intval($this->input->post('country')),
			"countryPhoneCode"=>intval($this->input->post('countryPhoneCode')),
			"fax"=>$this->input->post('fax'),
			"nickName"=>$this->input->post('nickName'),
			"referenceCode"=>$this->input->post('referenceCode'),
			"state"=>intval($this->input->post('state')),
			"zipCode"=>intval($this->input->post('zipCode')),
			"operationalHours"=>$operationalHours,
			"locationAssociationsIds"=>$locationAssociationsIds
		);
		
		//$_SESSION["ORDERDATA"] = $data;
		//echo json_encode($data);exit;
		
		$out = $this->AccountModel->createAccount($data);
		echo json_encode($out);
	}
	
	public function update_account(){
		
		$locationAssociationsIds = '';
		
		$adminDetails = array(
			"email"=>$this->input->post('email'),
			"employeeNumber"=>$this->input->post('employeeNumber'),
			"firstName"=>$this->input->post('firstName'),
			"lastName"=>$this->input->post('lastName'),
			"phoneNumber"=>$this->input->post('phoneNumber'),
			"userName"=>$this->input->post('userName'),
			"userId"=>intval($this->input->post('userId'))
		);
		
		$operationalHours = array();
		if($this->input->post('dayOpr') && $this->input->post('startTimeOpr') && $this->input->post('endTimeOpr')){
			$dayOpr 		= $this->input->post('dayOpr');
			$startTimeOpr 	= $this->input->post('startTimeOpr');
			$endTimeOpr 	= $this->input->post('endTimeOpr');
			foreach ($dayOpr as $key => $value){
				$startTime 	= '';
				$endTime	= '';
				
				$startTime 	= date("H:i:s", strtotime($startTimeOpr[$key]));
				$endTime 	= date("H:i:s", strtotime($endTimeOpr[$key]));
				
				$operationalHours[] = array(
					"day"=>$dayOpr[$key],
					"startTime"=>$startTime,
					"endTime"=>$endTime
				);
			}
		}
		
		$locationAssociationsIds = array();
		if($this->input->post('locationId')){
			$locationId 	= $this->input->post('locationId');
			$locationIds 	= $this->input->post('locationIds');
			
			foreach ($locationId as $key => $value){
				$locationAssociationsIds[] = $locationIds[$key];
			}
		}
		
		//$locationAssociationsIds = 

		$data = array(
			"accountId"=>$this->input->post('accountNumber'),
			"accountStatus"=>intval($this->input->post('accountStatus')),
			"accountType"=>intval($this->input->post('accountType')),
			"accountTypeShortCode"=>$this->input->post('accountTypeShortCode'),
			"addressLine1"=>$this->input->post('addressLine1'),
			"addressLine2"=>$this->input->post('addressLine2'),
			"adminDetails"=>$adminDetails,
			"businessPhone"=>$this->input->post('businessPhone'),
			"city"=>intval($this->input->post('city')),
			"companyName"=>$this->input->post('companyName'),
			"contactEmail"=>$this->input->post('contactEmail'),
			"contactName"=>$this->input->post('contactName'),
			"contactPhone"=>$this->input->post('contactPhone'),
			"country"=>intval($this->input->post('country')),
			"countryPhoneCode"=>intval($this->input->post('countryPhoneCode')),
			"fax"=>$this->input->post('fax'),
			"nickName"=>$this->input->post('nickName'),
			"referenceCode"=>$this->input->post('referenceCode'),
			"state"=>intval($this->input->post('state')),
			"zipCode"=>intval($this->input->post('zipCode')),
			"operationalHours"=>$operationalHours,
			"locationAssociationsIds"=>$locationAssociationsIds
		);
		
		//$_SESSION["ORDERDATA"] = $data;
		//echo json_encode($data);exit;
		
		$out = $this->AccountModel->updateAccount($data);
		echo json_encode($out);
	}
	
	public function account_confirm($accountId){
		
		$data1['accountDetails'] = $this->AccountModel->getAccountById($accountId);
		$data['body'] = $this->load->view('accounts/account_confirm', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function view_account($accountId){
		
		$data1['accountDetails'] = $this->AccountModel->getAccountById($accountId);
		$data['body'] = $this->load->view('accounts/view_account', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function getOrderDetailsById($orderno){
		
		$out = $this->AccountModel->getOrderDetailsById($orderno);
		echo json_encode($out);
	}
	
	public function getAllAccounts(){

		$filters = array(
			array("key"=>"AccountType","value"=>$this->input->post('AccountType')),
			array("key"=>"AccountId","value"=>$this->input->post('AccountId')),
			array("key"=>"AccountName","value"=>$this->input->post('AccountName')),
			array("key"=>"AccountNickName","value"=>$this->input->post('AccountNickName')),
			array("key"=>"AccountRef","value"=>$this->input->post('AccountRef')),
			array("key"=>"State","value"=>$this->input->post('State')),
			array("key"=>"City","value"=>$this->input->post('City')),
			array("key"=>"AccountStatus","value"=>$this->input->post('AccountStatus'))
		);
		
		$out = $this->AccountModel->getAccountList($filters);
		echo json_encode($out);
	}
	
	public function viewAllAccounts(){
		
		$data['body'] = $this->load->view('accounts/viewAllAccounts', '', true);
		
		$this->load->view('template', $data);
	}
	

	public function getAccountById($acountId){
		
		$out = $this->AccountModel->getAccountById($acountId);
		echo json_encode($out);		
	}
	
	public function getLocationById($locationId){
		
		$out = $this->AccountModel->getLocationById($locationId);
		echo json_encode($out);
		
	}
	
	public function edit_account($acountId)
	{
		
		$data1["accountId"] = $acountId;
		
		$data['body'] = $this->load->view('accounts/edit_account', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function update_order(){
		
		if($this->input->post('orderType') == '1'){
			$isRental = 1;
		}else{
			$isRental = 0;
		}
		
		if($this->input->post('requestedPickupDate')){

			$pickUpDate = date("Y-m-d", strtotime($this->input->post('requestedPickupDate'))); 
		}else{
			$pickUpDate = '';
		}
		
		if($this->input->post('pickUpDueDate')){
			$pickUpDueDate = date("Y-m-d", strtotime($this->input->post('pickUpDueDate'))); 
		}else{
			$pickUpDueDate = '';
		}
		
		if($this->input->post('requestedPickUpTime1') != ''){
			$pickUpTime = $this->input->post('requestedPickUpTime1');
		}else{			
			if($this->input->post('requestedPickUpTime2')){
				$pickUpTime = date("H:i:s", strtotime($this->input->post('requestedPickUpTime2'))); 
			}else{
				$pickUpTime = '';
			}
		}
		
		$orderComponents = array();
		
		if($this->input->post('qty')){
			$qty = $this->input->post('qty');
			$description = $this->input->post('description');
			$weight = $this->input->post('weight');
			$id = $this->input->post('id');
			foreach ($qty as $key => $value){
				$orderComponents[] = array(
					"description"=>$description[$key],
					"quantity"=>intval($value),
					"sku"=>$key,
					"weight"=>intval($weight[$key]),
					"id"=>intval($id[$key])
				);
			}
		}
		
		$data = array(
			"orderNumber"=>$this->input->post('orderNumber'),
			"accountId"=>$this->input->post('accountId'),
			"locationId"=>$this->input->post('locationId'),
			"billToLocation"=>$this->input->post('billToLocation'),
			"shipToLocation"=>$this->input->post('shipToLocation'),			
			"isRental"=>intval($isRental),
			"orderComponents"=>$orderComponents,
			"orderType"=>intval($this->input->post('orderType')),
			"pickUpDate"=>$pickUpDate,
			"pickUpDueDate"=>$pickUpDueDate,
			"pickUpTime"=>$pickUpTime,
			"poNumber"=>$this->input->post('poNumber'),
			"instructions"=>$this->input->post('instructions'),
			"referenceCol1"=>$this->input->post('refNumber1'),
			"referenceCol2"=>$this->input->post('refNumber2'),
		);
		
		//$_SESSION["ORDERDATA"] = $data;
		//echo json_encode($data);exit;
		
		$out = $this->AccountModel->updateOrder($data);
		echo json_encode($out);
	}	
}
