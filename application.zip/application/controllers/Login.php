<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
		
	function __construct() {
		parent::__construct();
		$this->load->model('LoginModel','LoginModel');
	}
		
	public function index($expire = ''){
		$data["message"] = $this->session->flashdata('msg');
		$this->load->view('login/login', $data);
	}
	
	public function login_action(){
		$data = array(
			"userName"=>$this->input->post('userName'),
			"password"=>$this->input->post('password')
		);
		
		//echo json_encode($data);exit;
		
		$out = $this->LoginModel->login($data);
		$name = $out["responseObject"]["firstName"];
		$session_data = array(  
			'token'=>$out["responseObject"]["webAuthToken"],
			'name'=>$name,
			'role'=>$out["responseObject"]["roleDetails"]["roleDesc"],
			'menus'=>$out["responseObject"]["roleDetails"]["menus"]
		);
		$this->session->set_userdata($session_data);
		
		echo json_encode($out);
	}
	
	public function tokenExpire()
	{
		$this->session->set_flashdata('msg', 'Token Expire');
		redirect('Login');
	}
	
	public function getToken()
	{
		echo $this->session->userdata('token');
		exit;		
	}
	
	public function getMenus()
	{
		echo '<pre>';
		print_r($this->session->userdata('menus'));
		echo '</pre>';
		exit;		
	}
	
	public function logout(){		
		$out = $this->LoginModel->logout();
		$this->session->unset_userdata('token');
		$this->session->unset_userdata('name');
		$this->session->unset_userdata('role');
		$this->session->sess_destroy();
		redirect('Login/');
	}
}
