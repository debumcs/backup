<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	function __construct() {
		parent::__construct();
		validateToken();
		//$this->load->model('DashboardModel','DashboardModel');
	} 
	
	public function index()
	{
		$data1 = array();
		$data['body'] = $this->load->view('dashboard/dashboard', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
}
