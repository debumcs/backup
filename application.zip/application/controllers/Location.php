<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Location extends CI_Controller {
	public $serverUrl = 'http://14.143.158.230/api/v1/';
	
	public $token;
	
	public function __construct() {
        parent::__construct();
		validateToken();
	}
	
	public function index()
	{
		$data['body'] = $this->load->view('pages/contact', '', true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function getCityList($id){
		$curl = curl_init();

		curl_setopt_array($curl, array(
		
		CURLOPT_URL => "http://14.143.158.230/api/v1/config/cities/".$id,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_HTTPHEADER => array(
			"device-type: Web",
			"ver: 1.0"
		),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
			echo "cURL Error #:" . $err;
		} else {
			echo $response; die();
		}
	}
	
	public function getCityListEdit($id){
		$curl = curl_init();

		curl_setopt_array($curl, array(
		
		CURLOPT_URL => "http://14.143.158.230/api/v1/config/cities/".$id,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_HTTPHEADER => array(
			"device-type: Web",
			"ver: 1.0"
		),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
			echo "cURL Error #:" . $err;
		} else {
			$res = json_decode($response);
			return $res->responseObject;
		}
	}
	
	
	public function getStateList($id){
		$curl = curl_init();

		curl_setopt_array($curl, array(
		
		CURLOPT_URL => "http://14.143.158.230/api/v1/config/states/".$id,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_HTTPHEADER => array(
			"device-type: Web",
			"ver: 1.0"
		),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
			echo "cURL Error #:" . $err;
		} else {
			//echo $response;
			//$res = json_decode($response);
			echo $response; die();
		}
	}
	
	public function getStateListEdit($id){
		$curl = curl_init();

		curl_setopt_array($curl, array(
		
		CURLOPT_URL => "http://14.143.158.230/api/v1/config/states/".$id,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_HTTPHEADER => array(
			"device-type: Web",
			"ver: 1.0"
		),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
			echo "cURL Error #:" . $err;
		} else {
			//echo $response;
			$res = json_decode($response);
			return $res->responseObject;
		}
	}
	
	public function getLocationTypes (){
		$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => $this->serverUrl."config/locationTypes",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_HTTPHEADER => array(
			"device-type: Web",
			"ver: 1.0"
		  ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		  $res = json_decode($response);
		  return $res->responseObject;
		}
	}
	
	public function getAccountTypes (){
		$curl = curl_init();

		curl_setopt_array($curl, array(
		  CURLOPT_URL => $this->serverUrl."config/accountTypes",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_HTTPHEADER => array(
			"device-type: Web",
			"ver: 1.0"
		  ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		  $res = json_decode($response);
		  return $res->responseObject;
		}
	}
	
	public function getLocationById($id){
		
		$token = $this->session->userdata['token'];
		
		$curl = curl_init();
		
		curl_setopt_array($curl, array(
		  CURLOPT_URL => $this->serverUrl."location/findById/".$id,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_HTTPHEADER => array(
			"auth-token:$token",
			"device-type: Web",
			"ver: 1.0"			
		  ),
		));

		$result = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		$response = json_decode($result,true);
		$data1['locationDetails'] = $response["responseObject"];
		$data['body'] = $this->load->view('pages/location/view_location', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
		
	}
	
	public function edit_location($id){
		
		$token = $this->session->userdata['token'];
		$curl = curl_init();
		
		curl_setopt_array($curl, array(
		  CURLOPT_URL => $this->serverUrl."location/findById/".$id,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_HTTPHEADER => array(
			"auth-token:$token",
			"device-type: Web",
			"ver: 1.0"			
		  ),
		));

		$result = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		$response = json_decode($result,true);
		$data1['locationDetails'] = $response["responseObject"];
		$data1['stateList'] = $this->getStateListEdit($response["responseObject"]["country"]);
		$data1['cityList'] = $this->getCityListEdit($response["responseObject"]["state"]);
		$data1['locationTypes'] = $this->getLocationTypes();
		$data1['accountTypes'] = $this->getAccountTypes();
		$data['body'] = $this->load->view('pages/location/edit_location', $data1, true);
		$this->load->view('template', $data);
		
	}
	
	public function post_update_location()
	{
		$weekdaysCollected = array();
		if($this->input->post('weekdays')){
			$weekdays = $this->input->post('weekdays');
			
			foreach($weekdays as $day){
				$weekdaysCollected[] = array(
					"day"=>$day,
					"startTime"=>$this->input->post('fromtime_'.$day).':00',
					"endTime"=>$this->input->post('totime_'.$day).':00'
				);
			}
		}
		
		
		$token = $this->session->userdata('token');
		
		$header = array(
			"device-type: Web",
			"ver: 1.0",	
			"Auth-Token: $token",
			"content-type: application/json"
		);
		
		$fieldValues = array(
          "locationType"=>intval($this->input->post('locationType')),
          "referenceCode" =>$this->input->post('referenceCode'),
          "unitNumber" => $this->input->post('unitNumber'),
          "locationName" => $this->input->post('locationName'),
          "nickName" => $this->input->post('nickName'),
          "addressLine1" => $this->input->post('addressLine1'),
          "addressLine2" => $this->input->post('addressLine2'),
          "zipCode" => intval($this->input->post('zipCode')),
          "country" => intval($this->input->post('country')),
          "state" => intval($this->input->post('state')),
          "city" => intval($this->input->post('city')),
          "businessPhone" => $this->input->post('businessPhone'),
		  "fax" => $this->input->post('fax'),
          "operationalHours" => $weekdaysCollected,
          "contactEmail" => $this->input->post('contactEmail'),
		  "contactName" => $this->input->post('contactName'),
		  "contactPhone" => $this->input->post('contactPhone'),
		  "locationAssociationsIds" => $this->input->post('assoAcounts'),
		  "locationId" => $this->input->post('locationId'),
		  "status" => $this->input->post('status')
        );
		
		/* echo '<pre>';
		print_r($fieldValues);die(); */

		$data_string = json_encode($fieldValues);
		
		$url = "http://14.143.158.230/api/v1/location/updateLocation";
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		curl_setopt($ch, CURLOPT_TIMEOUT, 15);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true );
		$result = curl_exec($ch);
		curl_close($ch);

		$response = json_decode($result,true);
		
		$data1['response'] = $response;
		$data['body'] = $this->load->view('pages/location/confirm_location', $data1, true);		
		$this->load->view('template', $data);
	}
	
	public function manage_locations()
	{
		$data1['locationTypes'] = $this->getLocationTypes();
		$data1['accountTypes'] = $this->getAccountTypes();
		$data['body'] = $this->load->view('pages/location/manage_location', $data1, true);
		
		$this->load->view('template', $data);
	}
	
	public function getAllLocations(){
		$curl = curl_init();
		
		$POSTFIELDS = '[
		{"key":"LocationType","value": "'.$_POST["LocationType"].'"},
		{"key":"LocationId","value": "'.$_POST["LocationId"].'"},
		{"key":"LocationRef","value": "'.$_POST["LocationRef"].'"},
		{"key":"LocationName","value": "'.$_POST["LocationName"].'"},
		{"key":"LocationStatus","value": "'.$_POST["LocationStatus"].'"}
		]';
		
		//$token = $_POST["token"];
		$token = $this->session->userdata('token');
		//echo $this->session->userdata['token'];
		curl_setopt_array($curl, array(
		  
		  CURLOPT_URL => "http://14.143.158.230/api/v1/location/getAll",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "POST",
		  CURLOPT_POSTFIELDS => $POSTFIELDS,
		  CURLOPT_HTTPHEADER => array(
			"auth-token:$token",
			"content-type: application/json",
			"device-type: Web",
			"ver: 1.0"
		  ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		  echo $response; exit;
		}
	}
	
	public function getAccountAssoc(){
		$curl = curl_init();
		$POSTFIELDS = '[
		{"key":"AccountType","value": "'.$_POST["assoAccounttype"].'"},
		{"key":"AccountId","value": "'.$_POST["assoAccountNo"].'"},
		{"key":"AccountName","value": "'.$_POST["assoAccountName"].'"},
		{"key":"AccountNickName","value": "'.$_POST["assoAccountNickname"].'"},
		{"key":"AccountRef","value": "'.$_POST["assoAccountRef"].'"},
		{"key":"State","value": "'.$_POST["assoAccountState"].'"}
		]';
		
		$token = $this->session->userdata('token');
		
		curl_setopt_array($curl, array(
		  
		  CURLOPT_URL => "http://14.143.158.230/api/v1/account/getAll",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "POST",
		  CURLOPT_POSTFIELDS => $POSTFIELDS,
		  CURLOPT_HTTPHEADER => array(
			"auth-token:$token",
			"content-type: application/json",
			"device-type: Web",
			"ver: 1.0"
		  ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		  echo $response; exit;
		}
	}
	
	
	public function create_location()
	{
		$data1['locationTypes'] = $this->getLocationTypes();
		$data1['accountTypes'] = $this->getAccountTypes();
		$data['body'] = $this->load->view('pages/location/create_location', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function post_create_location()
	{
		$weekdaysCollected = array();
		if($this->input->post('weekdays')){
			$weekdays = $this->input->post('weekdays');
			
			foreach($weekdays as $day){
				$weekdaysCollected[] = array(
					"day"=>$day,
					"startTime"=>$this->input->post('fromtime_'.$day).':00',
					"endTime"=>$this->input->post('totime_'.$day).':00'
				);
			}
		}
		
		
		$token = $this->session->userdata('token');
		
		$header = array(
			"device-type: Web",
			"ver: 1.0",	
			"Auth-Token: $token",
			"content-type: application/json"
		);
		
		$fieldValues = array(
          "locationType"=>intval($this->input->post('locationType')),
          "referenceCode" =>$this->input->post('referenceCode'),
          "unitNumber" => $this->input->post('unitNumber'),
          "locationName" => $this->input->post('locationName'),
          "nickName" => $this->input->post('nickName'),
          "addressLine1" => $this->input->post('addressLine1'),
          "addressLine2" => $this->input->post('addressLine2'),
          "zipCode" => intval($this->input->post('zipCode')),
          "country" => intval($this->input->post('country')),
          "state" => intval($this->input->post('state')),
          "city" => intval($this->input->post('city')),
          "businessPhone" => $this->input->post('businessPhone'),
		  "fax" => $this->input->post('fax'),
          "operationalHours" => $weekdaysCollected,
          "contactEmail" => $this->input->post('contactEmail'),
		  "contactName" => $this->input->post('contactName'),
		  "contactPhone" => $this->input->post('contactPhone'),
		  "locationAssociationsIds" => $this->input->post('assoAcounts')
        );

		$data_string = json_encode($fieldValues);
		
		$url = "http://14.143.158.230/api/v1/location/createLocation";
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		curl_setopt($ch, CURLOPT_TIMEOUT, 15);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true );
		$result = curl_exec($ch);
		curl_close($ch);

		$response = json_decode($result,true);
		
		$data1['response'] = $response;
		$data['body'] = $this->load->view('pages/location/confirm_location', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	
}