<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Location extends CI_Controller {
	
	public function __construct() {
        parent::__construct();
		validateToken();
		$this->load->model('LocationModel','LocationModel');
	}
	
	public function create_location()
	{
		$data1 = array();
		$data['body'] = $this->load->view('location/create_location', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function getAllAccounts(){
		validateToken();
		$filters = array(
			array("key"=>"AccountType","value"=>$this->input->post('accountType')),
			array("key"=>"AccountId","value"=>$this->input->post('accountId')),
			array("key"=>"AccountName","value"=>$this->input->post('accountName')),
			array("key"=>"AccountNickName","value"=>$this->input->post('accountNickName')),
			array("key"=>"AccountRef","value"=>$this->input->post('accountRef')),
			array("key"=>"State","value"=>$this->input->post('accountState'))
		);
		
		$out = $this->LocationModel->getAccountList($filters);
		echo json_encode($out);
	}

	public function post_location(){
		echo '<pre>'; 
		print_r($this->input->post('startTimeOpr')); 
		print_r($this->input->post('endTimeOpr')); 
		exit;
		echo $pickUpTime = date("H:i:s", strtotime($this->input->post('totime'))); exit;
		/*echo '<pre>';
		print_r($_POST);
		echo '</pre>';
		exit;*/
		$locationAssociationsIds = '';
		
		$adminDetails = array(
			"email"=>$this->input->post('email'),
			"employeeNumber"=>$this->input->post('employeeNumber'),
			"firstName"=>$this->input->post('firstName'),
			"lastName"=>$this->input->post('lastName'),
			"phoneNumber"=>$this->input->post('phoneNumber'),
			"userName"=>$this->input->post('userName')
		);
		
		$operationalHours = array();
		if($this->input->post('dayOpr') && $this->input->post('startTimeOpr') && $this->input->post('endTimeOpr')){
			$dayOpr 		= $this->input->post('dayOpr');
			$startTimeOpr 	= $this->input->post('startTimeOpr');
			$endTimeOpr 	= $this->input->post('endTimeOpr');
			foreach ($dayOpr as $key => $value){
				$startTime 	= '';
				$endTime	= '';
				
				$startTime 	= date("H:i:s", strtotime($startTimeOpr[$key]));
				$endTime 	= date("H:i:s", strtotime($endTimeOpr[$key]));
				
				$operationalHours[] = array(
					"day"=>$dayOpr[$key],
					"startTime"=>$startTime,
					"endTime"=>$endTime
				);
			}
		}
		
		$locationAssociationsIds = array();
		if($this->input->post('locationId')){
			$locationId 		= $this->input->post('locationId');
			$locationIds 	= $this->input->post('locationIds');
			
			foreach ($locationId as $key => $value){
				$locationAssociationsIds[] = $locationIds[$key];
			}
		}
		
		//$locationAssociationsIds = 

		$data = array(
			"accountType"=>intval($this->input->post('accountType')),
			"accountTypeShortCode"=>$this->input->post('accountTypeShortCode'),
			"addressLine1"=>$this->input->post('addressLine1'),
			"addressLine2"=>$this->input->post('addressLine2'),
			"adminDetails"=>$adminDetails,
			"businessPhone"=>$this->input->post('businessPhone'),
			"city"=>intval($this->input->post('city')),
			"companyName"=>$this->input->post('companyName'),
			"contactEmail"=>$this->input->post('contactEmail'),
			"contactName"=>$this->input->post('contactName'),
			"contactPhone"=>$this->input->post('contactPhone'),
			"country"=>intval($this->input->post('country')),
			"countryPhoneCode"=>intval($this->input->post('countryPhoneCode')),
			"fax"=>$this->input->post('fax'),
			"nickName"=>$this->input->post('nickName'),
			"referenceCode"=>$this->input->post('referenceCode'),
			"state"=>intval($this->input->post('state')),
			"zipCode"=>intval($this->input->post('zipCode')),
			"operationalHours"=>$operationalHours,
			"locationAssociationsIds"=>$locationAssociationsIds
		);
		
		//$_SESSION["ORDERDATA"] = $data;
		//echo json_encode($data);exit;
		
		$out = $this->AccountModel->createAccount($data);
		echo json_encode($out);
	}


	
	
}