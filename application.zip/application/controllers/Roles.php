<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Roles extends CI_Controller {

	function __construct() {
		parent::__construct();
		validateToken();
		$this->load->model('RoleModel');
	} 

	public function create_role(){
		$data1 = array();
		$data['body'] = $this->load->view('roles/createRole', $data1, true);
		$this->load->view('template', $data);
	}

	public function post_role(){
		$data = array(
			"roleName"=>$this->input->post('roleName'),
			"employeeNumber"=>$this->input->post('employeeNumber'),
			"email"=>$this->input->post('email'),
			"firstName"=>$this->input->post('firstName'),
			"lastName"=>$this->input->post('lastName'),
			"phoneNumber"=>$this->input->post('phoneNumber'),
			"roleId"=>$this->input->post('roleId')
		);
		
		$out = $this->RoleModel->createUser($data);
		echo json_encode($out);
	}

	public function update_role(){
		$data = array(
			"roleId"=>intval($this->input->post('roleId')),
			"roleName"=>$this->input->post('roleName'),
			"employeeNumber"=>$this->input->post('employeeNumber'),
			"email"=>$this->input->post('email'),
			"firstName"=>$this->input->post('firstName'),
			"lastName"=>$this->input->post('lastName'),
			"phoneNumber"=>$this->input->post('phoneNumber'),
			"roleId"=>intval($this->input->post('roleId')),
			"roleStatus"=>intval($this->input->post('roleStatus')),
			"accountId"=>$this->input->post('accountId')
		);
		
		//echo json_encode($data);exit;
		
		$out = $this->RoleModel->updateUser($data);
		echo json_encode($out);
	}

	public function role_confirm($roleId){
		
		$data1['roleDetails'] = $this->RoleModel->getUserById($roleId);
		$data['body'] = $this->load->view('roles/confirmUser', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function view_role($roleId){
		
		$data1['roleDetails'] = $this->RoleModel->getUserById($roleId);
		$data['body'] = $this->load->view('roles/viewUser', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function edit_role($roleId){
		
		$data1['roleDetails'] = $this->RoleModel->getUserById($roleId);
		$data['body'] = $this->load->view('roles/editUser', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}
	
	public function getRoleById($roleId){
		
		$out = $this->RoleModel->getUserById($roleId);
		echo json_encode($out);
	}

	public function viewAllRoles(){
		$data1 = array();
		$data['body'] = $this->load->view('roles/manageUser', $data1, true);
		//charge the view "contact" in the other view template
		$this->load->view('template', $data);
	}

	public function getAllUsers(){
		$filters = array(
			array("key"=>"UserStatus","value"=>$this->input->post('UserStatus')),
			array("key"=>"FName","value"=>$this->input->post('FName')),
			array("key"=>"LName","value"=>$this->input->post('LName')),
			array("key"=>"UserName","value"=>$this->input->post('UserName'))
		);
		
		$out = $this->RoleModel->getUserList($filters);
		echo json_encode($out);
	}
	
	public function checkUserNameExists($rolename){
		$out = $this->RoleModel->checkUserNameExists($rolename);
		echo json_encode($out);
	}
}
