<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Locations</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
        <li><a href="#">Locations</a></li>
        <li class="active">List of all Locations</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content form-page">
    	<div class="nav-tabs-custom">
    	<div class="pad20">
	      	<div class="row">
	        <div class="col-lg-12">
	          
	          <div class="box box-primary">
	            <div class="box-header with-border">
	            	<!-- <a href="create_location.html" class="pull-right btn btn-default">Create Location</a> -->
					<h3 class="box-title m10"><b>List of all Locations</b></h3>
				</div>
				
	            <!-- /.box-header -->
	            <div class="box-body">
					
					<div class="row">
						<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
							<div class="form-group">
								<label>Location Type</label>
								<select class="form-control input-md" name="searchLocationType" id="searchLocationType" onchange="getAllLocations();" width="100%">
								<option value="" selected>Select</option>
								<?php 
								foreach($locationTypes as $value){
									echo '<option value="'.$value->id.'">'.$value->locationType.'</option>';
								}
								?>
								</select>
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
							<div class="form-group">
								<label>Location #</label>
								<input type="text" placeholder="Enter Location#" name="searchLocationNo" id="searchLocationNo" onKeyup="getAllLocations();" class="form-control input-sm" value="">
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Status</label>
								<select class="form-control input-md" name="searchLocationStatus" id="searchLocationStatus" onchange="getAllLocations();" width="100%">
								<option value="" selected>Select</option>
								<option value="1">Active</option>
								<option value="0">Inactive</option>
								<option value="2">Pending</option>
								</select>
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
							<div class="form-group">
								<label>&nbsp;</label><br/>
								<button class="btn btn-success" type="button" onclick="filter_fields();">Advanced Search</button>
							</div>
						</div>
					</div>
						
					<div class="row" id="customfields">
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Customer Ref #</label>
								<input type="text" placeholder="Enter Customer Ref #" name="searchLocationRef" id="searchLocationRef" onkeyup="getAllLocations();" class="form-control input-sm" value="">
							</div>
						</div>
						
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Customer</label>
								<input type="text" placeholder="Enter Customer Name" name="searchLocationName" id="searchLocationName" onkeyup="getAllLocations();" class="form-control input-sm" value="">
							</div>
						</div>
						
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>City</label>
								<input type="text" placeholder="Enter City" name="searchLocationCity" id="searchLocationCity" onkeyup="getAllLocations();" class="form-control input-sm" value="">
							</div>
						</div>
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>State</label>
								<input type="text" placeholder="Enter State" name="searchLocationState" id="searchLocationState" onkeyup="getAllLocations();" class="form-control input-sm" value="">
							</div>
						</div>
						
					</div>
					
					
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">&nbsp;</div>
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<table id="example1" class="table table-bordered table-striped ">
								<thead>
									<tr>
										<th>Location#</th>
										<th>Location Type</th>
										<th>Customer Ref#</th>
										<th>Customer Name</th>
										<th>Unit#</th>
										<th>Nickname</th>
										<th>Address</th>
										<th>City</th>
										<th>State</th>
										<th>Status</th>
									</tr>
								</thead>
								<tbody id="allLocations" >
									
								</tbody>
							</table>
						</div>
					</div>
	            </div>
	            <!-- /.box-body -->
	          </div>
	          <!-- /.box -->
	        </div>
	        <!-- /.col -->
	      </div>
	    </div>
	    </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
<script>
function getAllLocations(){
	
	var allLocationList = [];
	var e = document.getElementById("searchLocationType");
	var LocationType = e.options[e.selectedIndex].value;
	var LocationId = document.getElementById("searchLocationNo").value;
	var LocationRef = document.getElementById("searchLocationRef").value;
	var LocationName = document.getElementById("searchLocationName").value;
	var LocationStatus = document.getElementById("searchLocationStatus").value;
	
	//alert(assoAccountState);searchLocationStatus, searchLocationCity, searchLocationState
	document.getElementById('allLocations').innerHTML = '';
	$.ajax({
		type: "POST",
		data:{LocationType:LocationType,LocationId:LocationId,LocationRef:LocationRef,LocationName:LocationName,LocationStatus:LocationStatus},
		url: "<?php echo base_url();?>index.php/Location/getAllLocations/",
		success: function(res){
			//console.log(res);
			var obj = JSON.parse(res);
			console.log(res);
			
			$.each(obj.responseObject, function(i, p) {
				var newOption = '<tr><td><a href="<?php echo base_url();?>index.php/Location/getLocationById/'+p.locationId+'">'+p.locationId+'</a></td><td>'+p.locationTypeDetails.locationType+'</td><td>'+p.referenceCode+'</td><td>'+p.locationName+'</td><td>'+p.unitNumber+'</td><td>'+p.nickName+'</td><td>'+p.addressLine1+' '+p.addressLine2+'</td><td>'+p.cityDetails.cityName+'</td><td>'+p.stateDetails.stateName+'</td><td>'+p.statusDetails.statusDesc+'</td></tr>';
				allLocationList.push(newOption);
			});
			
			document.getElementById('allLocations').innerHTML = allLocationList.join("");
		}
	});
}

function filter_fields(){
	$('#customfields').toggle();
}
</script>
  