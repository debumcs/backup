<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo base_url(); ?>asset/dist/img/profileimage.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo $this->session->userdata('name'); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      
		<ul class="sidebar-menu" data-widget="tree">
			<li class="header">MAIN NAVIGATION</li>
			<li class=""><a href="dashboard.html"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
			
			<li class="treeview">
				<a href="#">
				<i class="fa fa-folder"></i> <span>Order Management</span>
					<span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
				</a>			
				<ul class="treeview-menu">
					<li><a href="<?php echo base_url();?>Orders/create"><i class="fa fa-circle-o"></i>Create Order</a></li>
					<li><a href="<?php echo base_url();?>Orders/viewAllOrders"><i class="fa fa-circle-o"></i>View Orders</a></li>
					<li><a href="<?php echo base_url();?>AssignProvider/viewAllOrders"><i class="fa fa-circle-o"></i>Assign Provider</a></li>
					<li><a href="<?php echo base_url();?>AssignCarrier/viewAllOrders"><i class="fa fa-circle-o"></i>Assign Carrier</a></li>
				</ul>
			</li>
			
			<li class="treeview">
				<a href="#">
				<i class="fa fa-user"></i> <span>Account Management</span>
					<span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
				</a>
				
				<ul class="treeview-menu">
					<li><a href="<?php echo base_url();?>Accounts/create_account"><i class="fa fa-circle-o"></i> Create Account</a></li>
					<li><a href="<?php echo base_url();?>Accounts/viewAllAccounts"><i class="fa fa-circle-o"></i> Manage Account</a></li>
				</ul>
			</li>
			
			<li class="active treeview menu-open">
				<a href="#">
				<i class="fa fa-map-marker"></i> <span>Locations</span>
					<span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
				</a>
				
				<ul class="treeview-menu">
					<li><a href="<?php echo base_url();?>Location/create_location"><i class="fa fa-circle-o"></i> Create Location</a></li>
					<li><a href="<?php echo base_url();?>Location/manage_locations"><i class="fa fa-circle-o"></i> Manage Locations</a></li>
				</ul>
			</li>
			
			<li class="treeview">
				<a href="#">
				<i class="fa fa-user"></i> <span>User Management</span>
					<span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
				</a>
				
				<ul class="treeview-menu">
					<li><a href="<?php echo base_url();?>Users/create"><i class="fa fa-circle-o"></i> Create User</a></li>
					<li><a href="<?php echo base_url();?>Users/viewAllUsers"><i class="fa fa-circle-o"></i> Manage User</a></li>
				</ul>
			</li>
			
			<li class="treeview">
				<a href="#">
				<i class="fa fa-user"></i> <span>Inventory Management</span>
					<span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
				</a>
				
				<ul class="treeview-menu">
					<li><a href="<?php echo base_url();?>InventoryMovement/"><i class="fa fa-circle-o"></i> Sent to Location</a></li>
					<li><a href="<?php echo base_url();?>InventoryMovement/sentToLocationFileUpload"><i class="fa fa-circle-o"></i> Sent to Location(File Upload)</a></li>
				</ul>
			</li>
			
			<li class="treeview">
				<a href="#">
					<i class="fa fa fa-dollar"></i> <span> Configuration Management</span>
					<span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
				</a>
				<ul class="treeview-menu">
					<li><a href="<?php echo base_url();?>Products/addProduct"><i class="fa fa-circle-o"></i>Add Product</a></li>
					<li><a href="<?php echo base_url();?>Products/viewAllProducts"><i class="fa fa-circle-o"></i>View Products</a></li>
				</ul>
			</li>
		</ul>
    </section>
    <!-- /.sidebar -->
</aside>