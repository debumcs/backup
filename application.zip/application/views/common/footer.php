  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 0.0
    </div>
    <strong>&nbsp;Copyright &copy; 2018, Powered by <a href="https://www.advatix.com/" target="_blank">&nbsp;Advatix</a></strong>
  </footer>

  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- jQuery 3 -->


<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url(); ?>asset/angular/angular-datatables.min.js"></script>
<script src="<?php echo base_url(); ?>asset/kendo/js/kendo.all.min.js"></script>
<script src="<?php echo base_url(); ?>asset/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>asset/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/angularjs-datepicker/2.1.23/angular-datepicker.js"></script>
<script src="<?php echo base_url(); ?>asset/bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- date-range-picker -->
<script src="<?php echo base_url(); ?>asset/bower_components/moment/min/moment.min.js"></script>
<script src="<?php echo base_url(); ?>asset/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>

<!-- bootstrap color picker -->

<!-- SlimScroll -->
<script src="<?php echo base_url(); ?>asset/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="<?php echo base_url(); ?>asset/plugins/iCheck/icheck.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url(); ?>asset/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>asset/dist/js/adminlte.min.js"></script>

<script src="<?php echo base_url(); ?>asset/dist/js/accordion.js"></script>
<!-- Page script -->
<script>
$(function (){
    	
    $('.select2').select2();
    //Date picker
    $('.datepicker').datepicker({
      autoclose: true
    })
});

function showhidediv(val1){
	$('.showhidediv').hide(); 
	$('.customerdiv').show();
}

function showLocationTable(){
	$('#locationList').show();
}

function showDataGrid(){		
	$('#showhidetable').show();
}

$(document).on("click", ".child", function(){
	var select = $(this).parent().find('.day').val();
	
	$("#selectday").append('<option value="'+select+'">'+select+'</option>');
	
	var options = $('#selectday option');
	var values = $.map(options ,function(option) {
		return option.value;
	});
	
	if(values.length >= 7){
		$("#selectday").append('<option value="All">All</option>');
		var options = $('#selectday option');
		var values = $.map(options ,function(option){
			return option.value;
		});
	}
	
	order = { All: 0, Sunday: 1, Monday: 2, Tuesday: 3, Wednesday: 4, Thursday: 5, Friday: 6, Saturday: 7 };
	
	values.sort(function (a, b){
		return order[a] - order[b];
	});
	
	$('#selectday').empty();
	$.each(values, function(i, p) {
		$('#selectday').append($('<option></option>').val(p).html(p));
	});	
	
	$(this).parent().remove();
});
</script>