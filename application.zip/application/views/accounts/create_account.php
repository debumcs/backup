<div class="content-wrapper" ng-controller="createAccountCtrl">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Create Account</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Account Management</a></li>
        <li class="active">Create Account</li>
      </ol>
    </section>
    <section class="content form-page">
		<div class="box">
		<form autocomplete="off" novalidate name="accountForm" ng-submit="createAccount()" >
		<div class="box-body">
			<div class="padleftright20">
				<div class="accordion-option">
					<!-- <h3 class="title">Lorem Ipsum</h3> -->
					<!--a href="edit_savedorder.html" class="btn btn-primary">Edit</a-->
					<a href="javascript:void(0)" class="toggle-accordion active" accordion-id="#accordion"></a>
				</div>
				<div class="clearfix"></div>
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
								Account Details
								</a>
							</h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
							<div class="panel-body">
								<div class="row ">
									<div class="col-md-12 col-lg-12 col-sm-12">
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label>Account Type <span class="asterisk">*</span></label>
													<select class="form-control" ng-model="accountData.accountType" name="accountType" id="accountType" ng-change="appendShortName(accountData.accountType)" required>
													<option value="" selected>Select Account Type</option>
													<option  ng-repeat="accountType in accountTypes" value="{{accountType.id}}">{{accountType.accountType}}</option>
													</select>
													<div ng-if="submitted && accountForm.accountType.$invalid" class="invalid-feedback">
                            <span ng-if="accountForm.accountType.$error.required">Account Type required. </span>
                        </div>
												</div>
											</div>
											
											<div class="col-md-6 ordertyperefference">
												<div class="row">
												  <div class="col-md-6" ng-if="shortName">
													<div class="form-group">
													  <label>Asset Collection - Short Name</label>
													  <input type="text" ng-model="accountData.accountTypeShortCode" name="accountTypeShortCode" id="accountTypeShortCode" class="form-control" placeholder="Enter Short Name" />
													</div>
												  </div>
												  <div ng-class="shortName ? 'col-md-6' : 'col-md-12'">
													<div class="form-group">
													  <label>Reference Code</label>
													  <input type="text" ng-model="accountData.referenceCode" name="referenceCode" id="referenceCode" class="form-control" placeholder="Enter Reference Code">
													</div>
												  </div>
												</div>
											</div>
											
										</div>
										
										<div class="row">					
											<div class="col-md-6">
												<div class="form-group">
													<label>Company Name <span class="asterisk">*</span></label>
													<input type="text" ng-model="accountData.companyName" name="companyName" id="companyName" class="form-control" placeholder="Enter Company Name" ng-maxlength="45" required />
													<div ng-if="submitted && accountForm.companyName.$invalid" class="invalid-feedback">
                            <span ng-if="accountForm.companyName.$error.required">Company Name required. </span>
                            <span ng-if="accountForm.companyName.$error.maxlength">Maximum 45 characters allowed. </span>
                        </div>
												</div>
											</div>					
										<!-- /.form-group -->
													
											<div class="col-md-6">
												<div class="form-group">
													<label>Account Nickname</label>
													<input type="text" ng-model="accountData.nickName" name="nickName" id="nickName" class="form-control" placeholder="Enter account Nick Name" ng-maxlength="45" required />
													<div ng-if="submitted && accountForm.nickName.$invalid" class="invalid-feedback">
                            <span ng-if="accountForm.nickName.$error.maxlength">Maximum 45 characters allowed. </span>
                        </div>
												</div>
											</div>	
										</div>
										
										<div class="row">	
											<div class="col-md-6">
												<div class="form-group">
													<label>Address 1 <span class="asterisk">*</span></label>
													<input type="text" ng-model="accountData.addressLine1" name="addressLine1" id="addressLine1" class="form-control" placeholder="Enter Address" ng-maxlength="40" required />
													<div ng-if="submitted && accountForm.addressLine1.$invalid" class="invalid-feedback">
                            <span ng-if="accountForm.addressLine1.$error.required">Address required. </span>
                            <span ng-if="accountForm.addressLine1.$error.maxlength">Maximum 40 characters allowed. </span>
                        </div>
												</div>
											</div>
										
											<div class="col-md-6">
												<div class="form-group">
													<label>Address 2 <span class="asterisk">*</span></label>
													<input type="text" ng-model="accountData.addressLine2" name="addressLine2" id="addressLine2" class="form-control" placeholder="Enter Address" ng-maxlength="30" required />
													<div ng-if="submitted && accountForm.addressLine2.$invalid" class="invalid-feedback">
                            <span ng-if="accountForm.addressLine2.$error.required">Address required. </span>
                            <span ng-if="accountForm.addressLine2.$error.maxlength">Maximum 30 characters allowed. </span>
                        </div>
												</div>
											</div>	
										</div>
										
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label>Country <span class="asterisk">*</span></label>
													<select class="form-control" style="width: 100%;" ng-model="accountData.country" name="country" id="country"  ng-change="getStates(accountData.country)" required >
													<option selected="selected" value="">Select country</option>
													<option ng-repeat="country in allCountries" value="{{country.id}}">{{country.countryName}}</option>
													</select>
													<div ng-if="submitted && accountForm.city.$invalid" class="invalid-feedback">
							                            <span ng-if="accountForm.city.$error.required">City required. </span>
							                        </div>
												</div>
											</div>
											
											<div class="col-md-6">
												<div class="form-group">
													<label>State <span class="asterisk">*</span></label>
													<select class="form-control select2" ng-model="accountData.state" name="state" id="state" ng-change="getCities(accountData.state)" style="width: 100%;" required>
													<option selected="selected" value="">Select State</option>
													<option ng-repeat="state in allStates" value="{{state.id}}">{{state.stateName}}</option>
													</select>
													<div ng-if="submitted && accountForm.state.$invalid" class="invalid-feedback">
                            <span ng-if="accountForm.state.$error.required">State required. </span>
                        </div>
												</div>
											</div>
										</div>
										
										<div class="row">									
											<div class="col-md-6">
												<div class="form-group">
													<label>City <span class="asterisk">*</span></label>
													<select class="form-control select2" ng-model="accountData.city" name="city" id="city" style="width: 100%;" required>
													<option selected="selected" value="">Select City</option>
													<option ng-repeat="city in allCities" value="{{city.id}}">{{city.cityName}}</option>
													</select>
													<div ng-if="submitted && accountForm.city.$invalid" class="invalid-feedback">
                            <span ng-if="accountForm.city.$error.required">City required. </span>
                        </div>
												</div>
											</div>	
										
											<div class="col-md-6">
												<div class="form-group">
													<label>Zip Code <span class="asterisk">*</span></label>
													<input type="text" name="zip" id="zip" ng-model="accountData.zipCode" name="zipCode" id="zipCode" class="form-control" placeholder="Enter Zip Code" pattern="^[0-9_-]{5,9}$" required >
													<div ng-if="submitted && accountForm.accountType.$invalid" class="invalid-feedback">
                            <span ng-if="accountForm.zipCode.$error.required">Zip Code required. </span>
                            <span ng-if="accountForm.zipCode.$error.pattern">Enter 5-9 digits only. </span>
                        </div>
												</div>
											</div>
										</div>
										
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label>Business Phone</label>
													<div class="input-group">
														<span class="input-group-addon">+1</span>
														<input type="text" ng-model="accountData.businessPhone" name="businessPhone" id="businessPhone" class="form-control" placeholder="Enter Business Phone Number" pattern="^[0-9]{10}$" />
														<div ng-if="submitted && accountForm.businessPhone.$invalid" class="invalid-feedback">
                          <span ng-if="accountForm.businessPhone.$error.pattern">Enter 10 digit phone number. </span>
                      </div>
													</div>	
												</div>						
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<label>Fax</label>
													<div class="input-group">
														<span class="input-group-addon">+1</span>
														<input type="text" ng-model="accountData.fax" name="fax" id="fax" class="form-control" placeholder="Enter Fax Number" pattern="^[0-9]{10}$" />
														<div ng-if="submitted && accountForm.fax.$invalid" class="invalid-feedback">
                          <span ng-if="accountForm.fax.$error.pattern">Enter 10 digit fax number. </span>
                      </div>
													</div>
												</div>
											</div>	
										<!-- /.form-group -->
										</div>
										
										<div class="row">	
											<div class="col-md-6" id="time-range">
												<div class="row">
													<div class="col-md-3"><label>Days Open</label></div>
													<div class="col-md-9" style="text-align: center;"><label><center>Operational hours</center></label></div>
												</div>
												<div class="row">
													<div class="col-md-3"><label>&nbsp;</label></div>
													<div class="col-md-9">
														<div class="col-md-7"><label>From Time</label></div>
														<div class="col-md-5"><label>To Time</label></div>
													</div>
												</div>
												<div class="row">
													<div class="col-md-3">
<select class="form-control" ts-select-fix ng-init="accountData.selectdayAccnts='Select Day'" ng-model="accountData.selectdayAccnts" id="selectdayAccnts" name="selectdayAccnts">
	<option ng-selected="true" disabled="true" value="Select Day">Select Day</option>
	<option ng-repeat="wday in weekdaysviews" value="{{wday}}">{{wday}}</option>
</select>
													</div>
													<div class="col-md-3">
														<div class="input-group">
															<input type="time" ng-model="accountData.fromtimeAccnts" id="fromtimeAccnts" name="fromtimeAccnts" class="form-control" value="" />
														</div>
													</div>												
													<div class="col-md-1">&nbsp;</div>
													<div class="col-md-3">
														<div class="input-group">
															<input type="time" ng-model="accountData.totimeAccnts" name="totimeAccnts" id="totimeAccnts" class="form-control" value="" />
														</div>
													</div>
													<div class="col-md-2"><button type="button" ng-click="append_dayNg(accountData.selectdayAccnts, accountData.fromtimeAccnts, accountData.totimeAccnts)" class="btn btn-info btn-sm"><span class="glyphicon glyphicon-plus"></span></button></div>
												</div>
											<div ng-if="timeSelect" class="invalid-feedback">Please select day and time. </div>

<div class="row" id="example">
    <div class="" ng-repeat="opt in operationalHoursArr">
        <div class="col-md-3 weekday">
          <input type="text" readonly style="border: none;" ng-model="accountData.dayOpr[$index]" ng-init="accountData.dayOpr[$index] = opt.dayarray" class="day" />
        </div>
        <div class="col-md-3">
          <div class="input-group">
            <input type="time" ng-init="accountData.startTimeOpr[$index] = opt.fromtimearray" ng-model="accountData.startTimeOpr[$index]" class="form-control">
          </div>
        </div>
        <div class="col-md-1">&nbsp;</div>
        <div class="col-md-3">
          <div class="input-group">
            <input type="time" ng-init="accountData.endTimeOpr[$index] = opt.totimearray" ng-model="accountData.endTimeOpr[$index]" class="form-control">
          </div>
        </div>
        <span class="col-md-2">
          <button type="button" ng-click="deleteOperationalDayNg($index,opt.dayarray)" class="btn btn-danger btn-sm"><i class="glyphicon glyphicon-minus"></i></button>
        </span>
    </div>
</div>


											</div>
											
											<div class="col-md-6">
												<div class="form-group">
													<label>Contact Email <span class="asterisk">*</span></label>
													<input type="email" ng-model="accountData.contactEmail" name="contactEmail" id="contactEmail" class="form-control" placeholder="Enter Email" ng-maxlength="40"  required />
													<div ng-if="submitted && accountForm.contactEmail.$invalid" class="invalid-feedback">
                            <span ng-if="accountForm.contactEmail.$error.required">Email required. </span>
                            <span ng-if="accountForm.contactEmail.$error.email">Enter valid email id. </span>
                            <span ng-if="accountForm.contactEmail.$error.maxlength">Maximum 40 characters allowed. </span>
                        </div>
												</div>
												
												<div class="form-group">
													<label>Contact Name <span class="asterisk">*</span></label>
													<input type="text" ng-model="accountData.contactName" name="contactName" id="contactName" class="form-control" placeholder="Enter Contact Name" ng-maxlength="40" required />
													<div ng-if="submitted && accountForm.contactName.$invalid" class="invalid-feedback">
                            <span ng-if="accountForm.contactName.$error.required">Contact Name required. </span>
                            <span ng-if="accountForm.contactName.$error.maxlength">Maximum 40 characters allowed. </span>
                        </div>
												</div>
											
												<div class="form-group">
													<label>Contact Phone <span class="asterisk">*</span></label>
													<div class="input-group">
														<span class="input-group-addon">+1</span>
														<input type="text" ng-model="accountData.contactPhone" name="contactPhone" id="contactPhone" class="form-control" placeholder="Enter Contact Phone" pattern="^[0-9]{10}$" required />
													</div>
													<div ng-if="submitted && accountForm.contactPhone.$invalid" class="invalid-feedback" >
                          <span ng-if="accountForm.contactPhone.$error.required">Contact Phone required. </span>
                          <span ng-if="accountForm.contactPhone.$error.pattern">Enter digits only. </span>
                      </div><input type="hidden" ng-init="accountData.countryPhoneCode=1" ng-model="accountData.countryPhoneCode" name="countryPhoneCode" />
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
						
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingTwo">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
								Administrator Setup
								</a>
							</h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
							<div class="panel-body">
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>User Name <span class="asterisk">*</span></label>
											<input type="text" ng-model="accountData.userName" name="userName" id="userName" class="form-control" placeholder="Enter Username" ng-maxlength="30" required>
											<div ng-if="submitted && accountForm.userName.$invalid" class="invalid-feedback">
                      <span ng-if="accountForm.userName.$error.required">Username required. </span>
                      <span ng-if="accountForm.userName.$error.maxlength">Maximum 30 characters allowed. </span>
                    </div>
										</div>
									</div>	
									
									<div class="col-md-6">
										<div class="form-group">
											<label>Employee</label>
											<input type="text" ng-model="accountData.employeeNumber" name="employeeNumber" id="employeeNumber" class="form-control" placeholder="Enter Employee" ng-maxlength="25" required >
											<div ng-if="submitted && accountForm.employeeNumber.$invalid" class="invalid-feedback" >
                      <span ng-if="accountForm.employeeNumber.$error.maxlength">Maximum 25 characters allowed. </span>
                    </div>
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>First Name <span class="asterisk">*</span></label>
											<input type="text" ng-model="accountData.firstName" name="firstName" id="firstName" class="form-control" placeholder="Enter First Name" ng-maxlength="25" required >
											<div ng-if="submitted && accountForm.firstName.$invalid" class="invalid-feedback">
                      <span ng-if="accountForm.firstName.$error.required">First Name required. </span>
                      <span ng-if="accountForm.firstName.$error.maxlength">Maximum 20 characters allowed. </span>
                    </div>
										</div>
									</div>	
									
									<div class="col-md-6">
										<div class="form-group">
											<label>Last Name <span class="asterisk">*</span></label>
											<input type="text" ng-model="accountData.lastName" name="lastName" id="lastName" class="form-control" placeholder="Enter Last Name" ng-maxlength="25" required >
											<div ng-if="submitted && accountForm.lastName.$invalid" class="invalid-feedback">
                      <span ng-if="accountForm.lastName.$error.required">Last Name required. </span>
                    </div>
										</div>
									</div>
								</div>
							
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Email Address <span class="asterisk">*</span></label>
											<input type="email" ng-model="accountData.email" name="email" id="email" class="form-control" placeholder="Enter Email Address" ng-maxlength="40" required >
											<div ng-if="submitted && accountForm.email.$invalid" class="invalid-feedback">
                      <span ng-if="accountForm.email.$error.required">Email required. </span>
                      <span ng-if="accountForm.email.$error.email">Enter valid email id. </span>
                      <span ng-if="accountForm.email.$error.maxlength">Maximum 40 characters allowed. </span>
                    </div>
										</div>
									</div>	
									
									<div class="col-md-6">
										<div class="form-group">
											<label>Phone Number <span class="asterisk">*</span></label>
											<div class="input-group">
												<span class="input-group-addon">+1</span>
												<input type="text" ng-model="accountData.phoneNumber" name="phoneNumber" id="phoneNumber" class="form-control" placeholder="Enter Phone Number" pattern="^[0-9]{10}$" required />
											</div>
											<div ng-if="submitted && accountForm.phoneNumber.$invalid" class="invalid-feedback">
                      <span ng-if="accountForm.phoneNumber.$error.required">Phone Number required. </span>
                      <span ng-if="accountForm.phoneNumber.$error.pattern">Enter 10 digit phone number. </span>
                    </div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingThree">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
								Associations
								</a>
							</h4>
						</div>
						<div id="collapseThree" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingThree">
							<div class="panel-body">
								<div class="row">
									<div>										
										<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
											<div class="form-group">
												<label>Location Type:</label>
												<div class="input-group">
													<select class="form-control" ng-change="getLocationList()" ng-model="accountData.locationSearchType" name="locationSearchType" id="locationSearchType">
													<option selected="selected" value="">Select Location Type</option>
													<option ng-repeat='location in locationTypes' value="{{location.id}}">{{location.locationType}}</option>
													</select>
												</div>
											</div>
										</div>										
										<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
											<div class="form-group">
												<label>Location ID:</label>
												<div class="input-group">
													<input type="text" class="form-control pull-right" ng-model="accountData.locationSearchID" name="locationSearchID" id="locationSearchID" placeholder="Enter Location ID" ng-keyup="getLocationList()" />
												</div>
											</div>
										</div>
										<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
											<div class="form-group">
												<label>Customer Ref #:</label>
												<div class="input-group">
													<input type="text" class="form-control pull-right" ng-model="accountData.locationSearchCustRef" name="locationSearchCustRef" id="locationSearchCustRef" placeholder="Enter Reference Code" ng-keyup="getLocationList()" />
												</div>
											</div>
										</div>
										<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
											<div class="form-group">
												<label>Customer:</label>
												<div class="input-group">
													<input type="text" class="form-control pull-right" ng-model="accountData.locationSearchCustomer" name="locationSearchCustomer" id="locationSearchCustomer" placeholder="Enter Location Name" ng-keyup="getLocationList()" />
												</div>
											</div>
										</div>
										<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
											<div class="form-group">
												<label>Unit #:</label>
												<div class="input-group">
													<input type="text" class="form-control pull-right" ng-model="accountData.locationSearchUnit" name="locationSearchUnit" id="locationSearchUnit" placeholder="Enter Location Name" ng-keyup="getLocationList()" />
												</div>
											</div>
										</div>
										<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
											<div class="form-group">
												<label>Nickname:</label>
												<div class="input-group">
													<input type="text" class="form-control pull-right" ng-model="accountData.locationSearchNickname" name="locationSearchNickname" id="locationSearchNickname" placeholder="Enter Location Nickname" ng-keyup="getLocationList()" />
												</div>
											</div>
										</div>
										
									</div>
								</div>
								
								<div class="row">								
									<div class="col-lg-12">
										<table id="datatable" class="table table-bordered table-striped dataTable">
											<thead>
												<tr>
													<th>&nbsp;</th>
													<th>Location Id</th>
													<th>Location Type</th>
													<th>Customer Ref #</th>
													<th>Customer</th>
													<th>Unit #</th>
													<th>Customer Nickname</th>
													<th>Address</th>
													<th>City</th>
													<th>State</th>
													<th>Status</th>
												</tr>
											</thead>
											<tbody>
												<tr ng-repeat="location in allLocationList">
													<td><input type="checkbox" ng-model="accountData.locationId[location.locationId]" name="locationId" id="locationId" />
													<input type="hidden" ng-model="accountData.locationIds[location.locationId]" ng-init="accountData.locationIds[location.locationId] = location.locationId" name="locationIds" id="locationIds" /></td>
													<td>{{ location.locationId }}</td>
													<td>{{ location.locationTypeDetails.locationType }}</td>
													<td>{{ location.referenceCode }}</td>
													<td>{{ location.locationName }}</td>
													<td>{{ location.unitNumber }}</td>
													<td>{{ location.nickName }}</td>
													<td>{{ location.addressLine1 }} {{ location.addressLine2 }}</td>
													<td>{{ location.cityDetails.cityName }}</td>
													<td>{{ location.stateDetails.stateName }}</td>
													<td><span ng-if="location.status == '1'">Active</span> <span ng-if="location.status == '0'">Inactive</span></td>
												</tr>
											</tbody>
										</table>
									</div>
								</div>
								
								
								
							</div>
						</div>
						
					</div>
					
				</div>
				
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>
								<input type="button" class="btn btn-primary" ng-hide="editorEnabled" ng-click="accountSummary()" value="Continue" />
								<input type="submit" class="btn btn-primary" ng-show="editorEnabled" value="Submit" />
								<input type="button" class="btn btn-info" ng-show="editorEnabled" ng-click="accountCreateForm()" value="Edit" />
							</label>
							<label>
								<input type="button" ng-click="reset()" class="btn btn-danger" value="Cancel" />
							</label>
						</div>
					</div>
				</div>
				
				<div class="row">
					<div class="col-md-12" ng-show="errorMsg.length>0">
						{{errorMsg}}
					</div>
				</div>
			</div>
		</div>
		</div>
    </section>
    <!-- /.content -->
  </div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/accounts/createAccountCtrl.js"></script>