<div class="content-wrapper" ng-controller="viewAllAccounts">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>Account Management</h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
      <li><a href="#">Account Management</a></li>
      <li class="active">List of all accounts</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content form-page">
    <div class="nav-tabs-custom">
    <div class="pad20">
        <div class="row">
        <div class="col-lg-12">
          
          <div class="box box-primary">
            <div class="box-header with-border">
              <!-- <a href="create_account.html" class="pull-right btn btn-default">Create Account</a> -->
        <h3 class="box-title m10"><b>List of all Accounts</b></h3>
      </div>
      
            <!-- /.box-header -->
            <div class="box-body">
			  <form autocomplete="off" name="accountSearchForm">
              <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="form-group">
                  <label>Account Type</label>
                  <select class="form-control input-md" ng-model="accountData.AccountType" ng-change="getAccountdata()" width="100%" name="accounttype">
                  <option value="" selected>Select Account</option>
                  <option ng-repeat='accountType in accountTypes' value="{{accountType.id}}">{{accountType.accountType}}</option>
                  </select>
                </div>
              </div>
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="form-group">
                  <label>Account Name</label>
                  <input type="text" ng-model="accountData.AccountName" ng-keyup="getAccountdata()" class="form-control input-sm" value="">
                </div>
              </div>
              <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                <div class="form-group">
                  <label>Status</label>
                  <select class="form-control input-md" ng-model="accountData.AccountStatus" ng-change="getAccountdata()" width="100%">
                  <option value="" selected>Select</option>
                  <option ng-repeat='status in allAccountStatus' value="{{status.id}}">{{status.statusDesc}}</option>
                  </select>
                </div>
              </div>
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="form-group">
                  <label>&nbsp;</label><br/>
                  <button type="button" class="btn btn-success" ng-click="showAdvanceSearch = !showAdvanceSearch">Advanced Search</button>
                </div>
              </div>
            </div>						
          </div>
        </div>
        <div class="row" ng-if="showAdvanceSearch">
          <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
            <div class="form-group">
              <label>Account #</label>
              <input type="text" ng-model="accountData.AccountId" ng-keyup="getAccountdata()" class="form-control input-sm" value="">
            </div>
          </div>
          
          <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
            <div class="form-group">
              <label>Account Ref #</label>
              <input type="text" ng-model="accountData.AccountRef" ng-keyup="getAccountdata()" class="form-control input-sm" value="">
            </div>
          </div>
          
          <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
            <div class="form-group">
              <label>Account Nickname</label>
              <input type="text" ng-model="accountData.AccountNickName" ng-keyup="getAccountdata()" class="form-control input-sm" value="">
            </div>
          </div>
          
          <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
            <div class="form-group">
              <label>City</label>
              <input type="text" ng-model="accountData.City" ng-keyup="getAccountdata()" class="form-control input-sm" value="">
            </div>
          </div>
          <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
            <div class="form-group">
              <label>State</label>
              <input type="text" ng-model="accountData.State" ng-keyup="getAccountdata()" class="form-control input-sm" value="">
            </div>
          </div>
          
        </div>
        </form>
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">&nbsp;</div>
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <table datatable="ng" dt-options="dtOptions" class="table table-striped table-bordered">
              <thead>
                <tr>
                  <th>Account #</th>
                  <th>Account Name</th>
                  <th>Account Nickname</th>
                  <th>Account Ref #</th>
                  <th>Account Type</th>
                  <th>Address</th>
                  <th>City</th>
                  <th>State</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <tr ng-repeat="account in allAccountList">
                  <td><a href="<?php echo base_url(); ?>Accounts/view_account/{{ account.accountId }}">{{ account.accountId }}</a></td>
                  <td>{{ account.companyName }}</td>
                  <td>{{ account.nickName }}</td>
                  <td>{{ account.referenceCode }}</td>
                  <td>{{ account.accountTypeDetails.accountType }}</td>
                  <td>{{ account.addressLine1 }} {{ account.addressLine2 }}</td>
                  <td>{{ account.cityDetails.cityName }}</td>
                  <td>{{ account.stateDetails.stateName }}</td>
                  <td>{{ account.accountStatusDetails.statusDesc }} </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
    </div>
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
<script src="<?php echo base_url(); ?>asset/angular/controllers/accounts/viewAllAccounts.js"></script>