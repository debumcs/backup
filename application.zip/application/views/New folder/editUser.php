<section class="content-header">
    <h1>User Management</h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">User Management</a></li>
      <li class="active">Create User</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- SELECT2 EXAMPLE -->
    <div class="box box-primary">
      <div class="box-header with-border">
    <h3 class="box-title"><b>Edit User</b></h3>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
          <form [formGroup]="userForm" (ngSubmit)="onSubmit()">
              <div class="row">
                <div class="col-md-12 col-lg-12 col-sm-12">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Username</label>
                        <input type="text" formControlName="userName" readonly name="userName" id="userName" class="form-control" placeholder="Enter username">
                        <div *ngIf="submitted && f.userName.errors" class="invalid-feedback">
                          <span *ngIf="f.userName.errors.required">Username required</span>
                          <span *ngIf="f.userName.errors.pattern">Enter valid characters. </span>
                          
                        </div>
                      </div>
                    </div>
                  <!-- /.form-group -->
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Employee Number</label>
                        <input type="text" formControlName="employeeNumber" name="employeeNumber" id="employeeNumber" class="form-control" placeholder="Enter employee number">
                        <div *ngIf="submitted && f.employeeNumber.errors" class="invalid-feedback">
                          <span *ngIf="f.employeeNumber.errors.pattern">Enter valid characters. </span>
                        </div>
                      </div>
                    </div>					
                  <!-- /.form-group -->
                  </div>
                  
                  <div class="row">			
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>First Name</label>
                        <input type="text" formControlName="firstName" readonly name="firstName" id="firstName" class="form-control" placeholder="Enter first name">
                        <div *ngIf="submitted && f.firstName.errors" class="invalid-feedback">
                          <span *ngIf="f.firstName.errors.required">Last Name required. </span>
                          <span *ngIf="f.firstName.errors.pattern">Enter valid characters. </span>
                          </div>
                      </div>
                    </div>
                  <!-- /.form-group -->
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" formControlName="lastName" readonly name="lastName" id="lastName" class="form-control" placeholder="Enter last name">
                        <div *ngIf="submitted && f.lastName.errors" class="invalid-feedback">
                          <span *ngIf="f.lastName.errors.required">Last Name required. </span>
                          <span *ngIf="f.lastName.errors.pattern">Enter valid characters. </span>
                        </div>
                      </div>
                    </div>					
                  <!-- /.form-group -->
                  </div>
                  
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Email Address</label>
                        <input type="text" formControlName="email" readonly name="email" id="email" class="form-control" placeholder="Enter email">
                        <div *ngIf="submitted && f.email.errors" class="invalid-feedback">
                          <div *ngIf="f.email.errors.required">Email required</div>
                        </div>
                      </div>
                    </div>
                  <!-- /.form-group -->
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Phone Number</label>
                        <!-- <input type="text" name="address" id="address" class="form-control" placeholder="Enter phone number"> -->
                        <div class="input-group">
                          <span class="input-group-addon">+1</span>
                          <input type="text" formControlName="phoneNumber" required name="phoneNumber" id="phoneNumber" class="form-control" placeholder="Enter phone number">
                        </div>
                        <div *ngIf="submitted && f.phoneNumber.errors" class="invalid-feedback">
                          <span *ngIf="f.phoneNumber.errors.required">Phone Number required. </span>
                          <span *ngIf="f.phoneNumber.errors.minlength">Enter 10 digit phone number. </span>
                          <span *ngIf="f.phoneNumber.errors.maxlength">Enter 10 digit phone number. </span>
                          <span *ngIf="f.phoneNumber.errors.pattern">Enter digits only. </span>
                          </div>
                      </div>
                    </div>					
                  <!-- /.form-group -->
                  </div>
                  
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Role</label>
                        <select formControlName="roleId" required name="roleId" id="roleId" class="form-control">
                          <option value="" selected>Select Role</option>
                          <option *ngFor='let role of roleidList' value="{{role.roleId}}">{{role.roleDesc}}</option>
                        </select>
                        <div *ngIf="submitted && f.roleId.errors" class="invalid-feedback">
                            <div *ngIf="f.roleId.errors.required">Role required</div>
                          </div>
                      </div>
                    </div>

                    <div class="col-md-6" *ngIf="f.userStatus.value !=2">
                      <div class="form-group">
                        <label>Status</label>
                        <select formControlName="userStatus" required name="userStatus" id="userStatus" class="form-control">
                        <option value="0">Disabled</option>
                        <option value="1">Enabled</option>                        
                        </select>
                        <div *ngIf="submitted && f.userStatus.errors" class="invalid-feedback">
                            <div *ngIf="f.userStatus.errors.required">Status required</div>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>
                      <input type="hidden" formControlName="userId" name="userId" id="userId" />
                      <input type="hidden" formControlName="accountId" name="accountId" id="accountId" />
                      <button type="submit" [disabled]="loading" class="btn btn-primary">Update</button>
                      </label>&nbsp;&nbsp;&nbsp;
                      
                    <label><a [routerLink]="['/user-management/manage-user']" class="btn btn-danger">Cancel</a></label>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group" *ngIf="error">
                    <div class="row alert alert-danger">{{error}}</div>
                  </div>
                </div>
              </div>
              
            </form>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  <!-- /.row -->
</section>