<section class="content-header">
    <h1>User Management</h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">User Management</a></li>
      <li class="active">User Confirmation</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- SELECT2 EXAMPLE -->
    <div class="box box-primary">
      <div class="box-header with-border">
    <h3 class="box-title"><b>User Confirmation</b></h3>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
  
    <div class="row">
      <div class="col-md-12 col-lg-12 col-sm-12">
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label>Username : </label> {{ user?.userName }}
            </div>
          </div>
        <!-- /.form-group -->
          <div class="col-md-6">
            <div class="form-group">
              <label>Employee Number : </label> {{ user?.employeeNumber }}
            </div>
          </div>					
        <!-- /.form-group -->
        </div>
        
        <div class="row">			
          <div class="col-md-6">
            <div class="form-group">
              <label>First Name : </label> {{ user?.firstName }}
            </div>
          </div>
        <!-- /.form-group -->
          <div class="col-md-6">
            <div class="form-group">
              <label>Last Name : </label> {{ user?.lastName }}
            </div>
          </div>					
        <!-- /.form-group -->
        </div>
        
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label>Email Address : </label> {{ user?.email }}
            </div>
          </div>
        <!-- /.form-group -->
          <div class="col-md-6">
            <div class="form-group">
              <label>Phone Number : </label> +1{{ user?.phoneNumber }}
            </div>
          </div>					
        <!-- /.form-group -->
        </div>
        
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label>Role : </label> {{ user.roleDetails["roleDesc"] }}
            </div>
          </div>
          
          <div class="col-md-6" *ngIf="user.userStatus == 1 || user.userStatus == 0">
            <div class="form-group">
              <label>Status : </label> <span *ngIf="user?.userStatus == '1'">Enabled</span> <span *ngIf="user?.userStatus == '0'">Disabled</span>
                
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <a [routerLink]="['/user-management/manage-user']" class="btn btn-primary">View User List</a>
            </div>
          </div>
        </div>

      </div>
    </div>        
  
</div>
<!-- /.box-body -->
</div>
    <!-- /.box -->

    
    <!-- /.row -->

  </section>