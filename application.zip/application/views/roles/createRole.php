<div class="content-wrapper" ng-controller="createRoleCtrl">
  <!-- Content Header (Page header) -->
	<section class="content-header">
		<h1>Role Management</h1>
		<ol class="breadcrumb">
			<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
			<li><a href="#">Role Management</a></li>
			<li class="active">Create Role</li>
		</ol>
	</section>

	<!-- Main content -->
	<section class="content">

      <!-- SELECT2 EXAMPLE -->
      <div class="box box-primary">
        <div class="box-header with-border">
			<h3 class="box-title"><b>Create Role</b></h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
		<form autocomplete="off" novalidate name="roleForm" ng-submit="createUser()">
			<div class="row">
				<div class="col-md-12 col-lg-12 col-sm-12">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label>Account Type</label>
								<select name="accountType" ng-model="userData.accountType" id="accountType" class="form-control">
								<option>Select Type</option>
								<option>EZR</option>
								<option>Provider</option>
								<option>Customer</option>
								</select>
								<div ng-if="submitted && userForm.roleId.$invalid" class="invalid-feedback">
									<div ng-if="userForm.roleId.$error.required">Role required</div>
								</div>
							</div>
						</div>
					
						<div class="col-md-4">
							<div class="form-group">
								<label>Role Name</label>
								<input type="text" ng-model="userData.roleName" name="roleName" id="roleName" class="form-control" placeholder="Enter Role Name">
								<div ng-if="submitted && userForm.roleId.$invalid" class="invalid-feedback">
									<div ng-if="userForm.roleId.$error.required">Role required</div>
								</div>
							</div>
						</div>					
					
						<div class="col-md-4">
							<div class="form-group">
								<label>Role Description</label>
								<input type="text" ng-model="userData.roleDescription" name="roleDescription" id="roleDescription" class="form-control" placeholder="Enter Role Description">
								<div ng-if="submitted && userForm.roleId.$invalid" class="invalid-feedback">
									<div ng-if="userForm.roleId.$error.required">Role required</div>
								</div>
							</div>
						</div>
					</div>
										
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<h3 class="box-title"><b>List of Modules</b></h3>
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
							<ul class="treeview">
								<li>
									<input type="checkbox" ng-model="userData.roleDescription" name="roleDescription" id="roleDescription">
									<label for="Account" class="custom-unchecked">Account Management</label>
									
									<ul>
										 <li>
											 <input type="checkbox" name="Account-1" id="Account-1">
											 <label for="Account-1" class="custom-unchecked">Create Account</label>
										 </li>
										 <li class="last">
											 <input type="checkbox" name="Account-3" id="Account-3">
											 <label for="Account-3" class="custom-unchecked">Manage Account</label>
										 </li>
									</ul>
								</li>
								<li class="last">
									<input type="checkbox" name="order" id="order">
									<label for="order" class="custom-unchecked">Order Management</label>            
									<ul>
										 <li>
											 <input type="checkbox" name="order-1" id="order-1">
											 <label for="order-1" class="custom-unchecked">Create Order</label>
										 </li>
										 <li>
											 <input type="checkbox" name="order-2" id="order-2">
											 <label for="order-2" class="custom-unchecked">View Order</label>
										 </li>
										 <li>
											 <input type="checkbox" name="order-3" id="order-3">
											 <label for="order-3" class="custom-unchecked">Assign Provider</label>
										 </li>
										 <li class="last">
											 <input type="checkbox" name="order-4" id="order-4">
											 <label for="order-4" class="custom-unchecked">Assign Carrier</label>
										 </li>
									</ul>
								</li>
							</ul>
						</div>
						
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
							<ul class="treeview">
								<li>
									<input type="checkbox" name="User" id="User">
									<label for="User" class="custom-unchecked">User Management</label>
									
									<ul>
										 <li>
											 <input type="checkbox" name="User-1" id="User-1">
											 <label for="User-1" class="custom-unchecked">Create User</label>
										 </li>
										 <li class="last">
											 <input type="checkbox" name="User-3" id="User-3">
											 <label for="User-3" class="custom-unchecked">Manage User</label>
										 </li>
									</ul>
								</li>
								<li class="last">
									<input type="checkbox" name="Inventory" id="Inventory">
									<label for="Inventory" class="custom-unchecked">Inventory Management</label>            
									<ul>
										 <li>
											 <input type="checkbox" name="Inventory-1" id="Inventory-1">
											 <label for="Inventory-1" class="custom-unchecked">Sent to Location</label>
										 </li>
										 <li>
											 <input type="checkbox" name="Inventory-2" id="Inventory-2">
											 <label for="Inventory-2" class="custom-unchecked">Sent to Location(File Upload)</label>
										 </li>
										 <li>
											 <input type="checkbox" name="Inventory-3" id="Inventory-3">
											 <label for="Inventory-3" class="custom-unchecked">Inventory Aging Report</label>
										 </li>										 
									</ul>
								</li>
							</ul>
						</div>
						
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
							<ul class="treeview">
								<li>
									<input type="checkbox" name="Location" id="Location">
									<label for="Location" class="custom-unchecked">Location Management</label>            
									<ul>
										 <li>
											 <input type="checkbox" name="Location-1" id="Location-1">
											 <label for="Location-1" class="custom-unchecked">Create Location</label>
										 </li>
										 <li class="last">
											 <input type="checkbox" name="Location-3" id="Location-3">
											 <label for="Location-3" class="custom-unchecked">Manage Location</label>
										 </li>
									</ul>
								</li>
								
							</ul>
						</div>
						
						<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
							<ul class="treeview">
								<li>
									<input type="checkbox" name="Retailers" id="Retailers">
									<label for="Retailers" class="custom-unchecked">Configuration Management</label>            
									<ul>
										 <li>
											 <input type="checkbox" name="Retailers-1" id="Retailers-1">
											 <label for="Retailers-1" class="custom-unchecked">Add Product</label>
										 </li>
										 <li class="last">
											 <input type="checkbox" name="Retailers-3" id="Retailers-3">
											 <label for="Retailers-3" class="custom-unchecked">Manage Products</label>
										 </li>
									</ul>
								</li>
							</ul>
						</div>
						
					</div>
					
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label><button type="submit" class="btn btn-primary">Submit</button></label>&nbsp;&nbsp;&nbsp;
						<label><button type="button" ng-click="reset()" class="btn btn-danger">Cancel</button></label>
					</div>
				</div>
			</div>
		</form>
        </div>
        <!-- /.box-body -->
        
      </div>
      <!-- /.box -->

      
      <!-- /.row -->

    </section>
</div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/roles/createRoleCtrl.js"></script>