<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>EZR | OMS</title>
	  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/bower_components/Ionicons/css/ionicons.min.css">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/plugins/iCheck/all.css">
  <!-- Bootstrap time Picker -->
  <!-- Select2 -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/bower_components/select2/dist/css/select2.min.css">
  <!-- Theme style -->
  
  
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/dist/css/style.css">
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
<style>
.showhidediv, .showhidetable{
	display:none;
}

#locationList,#showhidetable{
	display:none;
}

.clear{
	clear:both;
}
</style>
  <!-- Google Font -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">


</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
  <header class="main-header">
    <!-- Logo -->
    <a href="dashboard.html" class="logo">
      <span class="logo-mini"><img src="<?php echo base_url(); ?>asset/dist/img/logo-dashboard-mini.png" style="width: 44px;" alt="logo-mini"></span>
      <span class="logo-lg"><img src="<?php echo base_url(); ?>asset/dist/img/logo-dashboard.png" class="logo-lg" style="width: 146px; margin: 5px;" alt="logo-lg"></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-bell-o"></i>
              <span class="label label-warning">10</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have 10 notifications</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li>
                    <a href="#">
                      <i class="fa fa-users text-aqua"></i> 2 new customer added
                    </a>
                  </li>
                  
                  <li>
                    <a href="#">
                      <i class="fa fa-users text-red"></i> 5 new repackagers joined
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa fa-shopping-cart text-green"></i> 5 new orders received
                    </a>
                  </li>                  
                </ul>
              </li>
              <li class="footer"><a href="#">View all</a></li>
            </ul>
          </li>

          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="<?php echo base_url(); ?>asset/dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs">Admin</span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="<?php echo base_url(); ?>asset/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
                <p>
                  Admin - System Administrator
                  <small>Member since Nov. 2012</small>
                </p>
              </li>
              
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="#" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>

        </ul>
      </div>
    </nav>
  </header>
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo base_url(); ?>asset/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Admin</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      
		<ul class="sidebar-menu" data-widget="tree">
			<li class="header">MAIN NAVIGATION</li>
			<li class=""><a href="dashboard.html"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
			
			<li class="treeview">
				<a href="#">
				<i class="fa fa-folder"></i> <span>Order Management</span>
					<span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
				</a>			
				<ul class="treeview-menu">
					<li class=""><a href="createorder.html"><i class="fa fa-circle-o"></i>Create Order</a></li>
					<li><a href="vieworder.html"><i class="fa fa-circle-o"></i>View Orders</a></li>
					<li><a href="assignrepackager.html"><i class="fa fa-circle-o"></i>Assign Provider</a></li>
					<li><a href="assigncarrierlist.html"><i class="fa fa-circle-o"></i>Assign Carrier</a></li>
				</ul>
			</li>
			
			<li class="treeview">
				<a href="#">
				<i class="fa fa-user"></i> <span>Account Management</span>
					<span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
				</a>
				
				<ul class="treeview-menu">
					<li class=""><a href="create_account.html"><i class="fa fa-circle-o"></i> Create Account</a></li>
					<li><a href="manage_account.html"><i class="fa fa-circle-o"></i> Manage Account</a></li>
				</ul>
			</li>
			
			<li class="active treeview menu-open">
				<a href="#">
				<i class="fa fa-map-marker"></i> <span>Locations</span>
					<span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
				</a>
				
				<ul class="treeview-menu">
					<li class="active"><a href="create_location.html"><i class="fa fa-circle-o"></i> Create Location</a></li>
					<li class=""><a href="manage_locations.html"><i class="fa fa-circle-o"></i> Manage Locations</a></li>
				</ul>
			</li>
			
			<li class="treeview">
				<a href="#">
				<i class="fa fa-user"></i> <span>User Management</span>
					<span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
				</a>
				
				<ul class="treeview-menu">
					<li><a href="create_user.html"><i class="fa fa-circle-o"></i> Create User</a></li><li><a href="manage_user.html"><i class="fa fa-circle-o"></i> Manage User</a></li>
				</ul>
			</li>
			
			<li class="treeview">
				<a href="#">
				<i class="fa fa-user"></i> <span>Inventory Management</span>
					<span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
				</a>
				
				<ul class="treeview-menu">
					<li><a href="ship_to_retailer.html"><i class="fa fa-circle-o"></i> Inventory Movement</a></li>
				</ul>
			</li>
			
			<li class="treeview">
				<a href="#">
					<i class="fa fa fa-dollar"></i> <span> Configuration Management</span>
					<span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
				</a>
				<ul class="treeview-menu">
					<li class=""><a href="add_product.html"><i class="fa fa-circle-o"></i>Add Product</a></li>
					<li class=""><a href="viewproducts.html"><i class="fa fa-circle-o"></i>View Products</a></li>
				</ul>
			</li>
		</ul>
    </section>
    <!-- /.sidebar -->
</aside>
	  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Create Location</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Location</a></li>
        <li class="active">Create Location</li>
      </ol>
    </section>
    <section class="content form-page">
		<div class="box">
		<div class="box-body">
			<div class="padleftright20">
				<div class="accordion-option">
					<a href="javascript:void(0)" class="toggle-accordion active" accordion-id="#accordion"></a>
				</div>
				<div class="clearfix"></div>
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
								Location Details
								</a>
							</h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
							<div class="panel-body">
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Location Type</label>
											<select class="form-control" id="accounttype" name="accounttype">
											<option>Dealership</option>
											<option>Distribution Center</option>
											<option>Library</option>
											<option>Nursery</option>
											<option>OEM</option>
											<option>Retail</option>
											<option>Provider Loc</option>
											</select>
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label>Ref#</label>
													<input type="text" name="reference_code" id="reference_code" class="form-control" placeholder="Enter Ref#">
												</div>
											</div>
											
											<div class="col-md-6">
												<div class="form-group">
													<label>Unit Number</label>
													<input type="text" name="reference_code" id="reference_code" class="form-control" placeholder="Enter Unit Number">
												</div>
											</div>
										</div>
									</div>
									
								</div>
								
								<div class="row">					
									<div class="col-md-6">
										<div class="form-group">
											<label>Location Name</label>
											<input type="text" name="company_name" id="company_name" class="form-control" placeholder="Enter Location Name">
										</div>
									</div>					
								<!-- /.form-group -->
											
									<div class="col-md-6">
										<div class="form-group">
											<label>Location Nickname</label>
											<input type="text" name="account_nickname" id="account_nickname" class="form-control" placeholder="Enter Location Nick Name">
										</div>
									</div>	
								</div>
								
								<div class="row">	
									<div class="col-md-6">
										<div class="form-group">
											<label>Address 1</label>
											<input type="text" name="address1" id="address1" class="form-control" placeholder="Enter Address">
										</div>
									</div>
								
									<div class="col-md-6">
										<div class="form-group">
											<label>Address 2</label>
											<input type="text" name="address2" id="address2" class="form-control" placeholder="Enter Address">
										</div>
									</div>	
								</div>
								
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Zip Code</label>
											<input type="text" name="zip" id="zip" class="form-control" placeholder="Enter Zip Code">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>City</label>
											<select class="form-control select2" style="width: 100%;">
											<option selected="selected">City 1</option>
											<option>City 2</option>
											<option>City 3</option>
											<option>City 4</option>
											<option>City 5</option>
											<option>City 6</option>
											<option>City 7</option>
											</select>
										</div>
									</div>	

									
								</div>
								
								<div class="row">										
									<div class="col-md-6">
										<div class="form-group">
											<label>State</label>
											<select class="form-control select2" style="width: 100%;">
											<option selected="selected">Alabama</option>
											<option>Alaska</option>
											<option>California</option>
											<option>Delaware</option>
											<option>Tennessee</option>
											<option>Texas</option>
											<option>Washington</option>
											</select>
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="form-group">
											<label>Country</label>
											<select class="form-control" style="width: 100%;">
											<option selected="selected">USA</option>
											</select>
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Business Phone</label>
											<div class="input-group">
												<span class="input-group-addon">+1</span>
												<input type="text" name="business_phone" id="business_phone" class="form-control" placeholder="Enter Business Phone Number">
											</div>	
										</div>						
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Fax</label>
											<div class="input-group">
												<span class="input-group-addon">+1</span>
												<input type="text" name="name" id="name" class="form-control" placeholder="Enter Fax" />
											</div>
										</div>
									</div>	
								<!-- /.form-group -->
								</div>
								
								<div class="row">					
									<div class="col-md-6" id="time-range">
										<div class="row">
											<div class="col-md-3"><label>Days Open</label></div>
											<div class="col-md-9" style="text-align: center;"><label><center>Operational hours</center></label></div>
										</div>
										<div class="row">
											<div class="col-md-3"><label>&nbsp;</label></div>
											<div class="col-md-9">
												<div class="col-md-7"><label>From Time</label></div>
												<div class="col-md-5"><label>To Time</label></div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-3">
												<select class="form-control" id="selectday">
													<option value="All">All</option>
													<option value="Monday">Monday</option>
													<option value="Tuesday">Tuesday</option>
													<option value="Wednesday">Wednesday</option>
													<option value="Thursday">Thursday</option>
													<option value="Friday">Friday</option>
													<option value="Saturday">Saturday</option>
													<option value="Sunday">Sunday</option>
												</select>
											</div>
											<div class="col-md-3">
												<div class="input-group">
													<input type="time" id="fromtime" class="form-control" value="" />
												</div>
											</div>												
											<div class="col-md-1">&nbsp;</div>
											<div class="col-md-3">
												<div class="input-group">
													<input type="time" id="totime" class="form-control" value="" />
												</div>
											</div>
											<div class="col-md-2"><button type="button" onclick="append_day()" class="btn btn-info btn-sm"><span class="glyphicon glyphicon-plus"></span></button></div>
										</div>
											
										<div class="row" id="example">											
											
										</div>
									</div>
									
									<div class="col-md-6">
										<div class="form-group">
											<label>Email</label>
											<input type="text" name="address" id="address" class="form-control" placeholder="Enter Email">
										</div>
										
										<div class="form-group">
											<label>Contact Name</label>
											<input type="text" name="contact_name" id="contact_name" class="form-control" placeholder="Enter Contact Name">
										</div>
									
										<div class="form-group">
											<label>Contact Phone</label>
											<div class="input-group">
												<span class="input-group-addon">+1</span>
												<input type="text" name="contact_phone" id="contact_phone" class="form-control" placeholder="Enter Contact Phone">
											</div>
											
										</div>
											
										
									</div>
								</div>								
							</div>
						</div>
					</div>
						
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingTwo">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
								Associations
								</a>
							</h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
							<div class="panel-body">
								<div class="row">
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account Type</label>
											<select class="form-control input-md" id="accounttype" onchange="showDataGrid();" width="100%" name="accounttype">
											<option value="" selected>Select Account</option>
											<option value="customer">Customer</option>
											<option value="provider">Provider</option>
											<option value="carrier">Carrier</option>
											<option value="retailer">Retailer</option>
											<option value="Supplier">Supplier</option>
											</select>
										</div>
									</div>
									
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account#</label>
											<input type="text" name="company_name" id="company_name" onkeypress="showDataGrid();" class="form-control input-sm" value="">
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account Name</label>
											<input type="text" name="company_name" id="company_name" onkeypress="showDataGrid();" class="form-control input-sm" value="">
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account Ref #</label>
											<input type="text" name="company_name" id="company_name" onkeypress="showDataGrid();" class="form-control input-sm" value="">
										</div>
									</div>	
									
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Account Nickname</label>
											<input type="text" name="company_name" id="company_name" onkeypress="showDataGrid();" class="form-control input-sm" value="">
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>State</label>
											<input type="text" name="company_name" id="company_name" onkeypress="showDataGrid();" class="form-control input-sm" value="">
										</div>
									</div>
								</div>
								
								<div class="row" id="showhidetable">								
									<div class="col-lg-12">
										<table id="example1" class="table table-bordered table-striped ">
											<thead>
												<tr>
													<th>#</th>
													<th>Account #</th>
													<th>Account Name</th>
													<th>Account Nickame</th>
													<th>Account Ref #</th>
													<th>Account Type</th>													
													<th>Address</th>
													<th>City</th>
													<th>State</th>
													<th>Status</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td align="center"><input type="checkbox" name="acounts" /></td>
													<td>ACCON001</td>
													<td>AccountName1</td>
													<td>Nickame1</td>
													<td>REF795</td>
													<td>Customer</td>
													<td>Address01, Address02</td>
													<td>City01</td>
													<td>State01</td>
													<td>Active</td>												
												</tr>
												<tr>
													<td align="center"><input type="checkbox" name="acounts" /></td>
													<td>ACCON002</td>
													<td>AccountName2</td>
													<td>Nickame2</td>
													<td>REF725</td>
													<td>Customer</td>
													<td>Address01, Address02</td>
													<td>City02</td>
													<td>State02</td>
													<td>Active</td>												
												</tr><tr>
													<td align="center"><input type="checkbox" name="acounts" /></td>
													<td>ACCON003</td>
													<td>AccountName3</td>
													<td>Nickame3</td>
													<td>REF735</td>
													<td>Customer</td>
													<td>Address01, Address02</td>
													<td>City03</td>
													<td>State03</td>
													<td>Active</td>												
												</tr><tr>
													<td align="center"><input type="checkbox" name="acounts" /></td>
													<td>ACCON004</td>
													<td>AccountName4</td>
													<td>Nickame4</td>
													<td>REF745</td>
													<td>Customer</td>
													<td>Address01, Address02</td>
													<td>City04</td>
													<td>State04</td>
													<td>Active</td>												
												</tr><tr>
													<td align="center"><input type="checkbox" name="acounts" /></td>
													<td>ACCON0055</td>
													<td>AccountName5</td>
													<td>Nickame5</td>
													<td>REF755</td>
													<td>Customer</td>
													<td>Address01, Address02</td>
													<td>City05</td>
													<td>State05</td>
													<td>Active</td>												
												</tr><tr>
													<td align="center"><input type="checkbox" name="acounts" /></td>
													<td>ACCON006</td>
													<td>AccountName6</td>
													<td>Nickame6</td>
													<td>REF765</td>
													<td>Customer</td>
													<td>Address01, Address02</td>
													<td>City06</td>
													<td>State06</td>
													<td>Active</td>												
												</tr>
											</tbody>
										</table>	
									</div>
								</div>								
							</div>
						</div>
					</div>					
				</div>
				
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>
								<a href="confirm_location.html" class="btn btn-primary">Submit</a>
							</label>
							<label>
								<a href="create_location.html" class="btn btn-danger">Cancel</a>
							</label>
						</div>
					</div>
				</div>
				
			</div>
		</div>
		</div>
    </section>
    <!-- /.content -->
  </div>
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 0.0
    </div>
    <strong>&nbsp;Copyright &copy; 2018, Powered by <a href="https://www.advatix.com/" target="_blank">&nbsp;Advatix</a></strong>
  </footer>

  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- jQuery 3 -->
<script src="<?php echo base_url(); ?>asset/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url(); ?>asset/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="<?php echo base_url(); ?>asset/bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- date-range-picker -->
<script src="<?php echo base_url(); ?>asset/bower_components/moment/min/moment.min.js"></script>
<script src="<?php echo base_url(); ?>asset/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<!-- bootstrap color picker -->

<!-- SlimScroll -->
<script src="<?php echo base_url(); ?>asset/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="<?php echo base_url(); ?>asset/plugins/iCheck/icheck.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url(); ?>asset/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>asset/dist/js/adminlte.min.js"></script>

<script src="<?php echo base_url(); ?>asset/dist/js/accordion.js"></script>
<!-- Page script -->
<script>
$(function (){
    //Initialize Select2 Elements
    $('.select2').select2();
    //Date picker
    $('#datepicker').datepicker({
      autoclose: true
    });
});

function showhidediv(val1){
	$('.showhidediv').hide(); 
	$('.customerdiv').show();
}

function showLocationTable(){
	$('#locationList').show();
}

function showDataGrid(){		
	$('#showhidetable').show();
}

function append_day() {

	var day = $('#selectday :selected').text();
	if(day !==''){
		var fromtime = $('#fromtime').val();
		var totime = $('#totime').val();
		
		weekdays = [ "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" ];
		
		if(day == 'All'){
			var i;
			for (i = 0; i < weekdays.length; i++) { 
				var text = '';
				var text = '<div class="parent"><div class="col-md-3 weekday"><input type="hidden" class="day" value="'+weekdays[i]+'" />'+weekdays[i]+'</div><div class="col-md-3"><div class="input-group"><input type="time" id="fromtime" value="'+fromtime+'" class="form-control"></div></div><div class="col-md-1">&nbsp;</div><div class="col-md-3"><div class="input-group"><input type="time"  id="totime" value="'+totime+'" class="form-control"></div></div><span class="child col-md-2"><button type="button" class="btn btn-danger btn-sm"><i class="glyphicon glyphicon-minus"></i></button></span></div>';
				$("#selectday option[value='"+weekdays[i]+"']").remove();
				$('#example').append(text);
			}
			$("#selectday option[value='All']").remove();
		}else{
			var text = '';
			text = '<div class="parent"><div class="col-md-3 weekday"><input type="hidden" class="day" value="'+day+'" />'+day+'</div><div class="col-md-3"><div class="input-group"><input type="time"  id="fromtime" value="'+fromtime+'" class="form-control"></div></div><div class="col-md-1">&nbsp;</div><div class="col-md-3"><div class="input-group"><input type="time"  id="totime" value="'+totime+'" class="form-control"></div></div><span class="child col-md-2"><button type="button" class="btn btn-danger btn-sm"><i class="glyphicon glyphicon-minus"></i></button></span></div>';
			$("#selectday option[value='"+day+"']").remove();
			$('#example').append(text);
		}
	}
}

$(document).on("click", ".child", function(){
	var select = $(this).parent().find('.day').val();
	
	$("#selectday").append('<option value="'+select+'">'+select+'</option>');
	
	var options = $('#selectday option');
	var values = $.map(options ,function(option) {
		return option.value;
	});
	
	if(values.length >= 7){
		$("#selectday").append('<option value="All">All</option>');
		var options = $('#selectday option');
		var values = $.map(options ,function(option){
			return option.value;
		});
	}
	
	order = { All: 0, Sunday: 1, Monday: 2, Tuesday: 3, Wednesday: 4, Thursday: 5, Friday: 6, Saturday: 7 };
	
	values.sort(function (a, b){
		return order[a] - order[b];
	});
	
	$('#selectday').empty();
	$.each(values, function(i, p) {
		$('#selectday').append($('<option></option>').val(p).html(p));
	});	
	
	$(this).parent().remove();
});
</script>
</body>
</html>