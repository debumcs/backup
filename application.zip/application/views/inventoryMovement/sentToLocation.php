<div class="content-wrapper" ng-controller="sentToLocationCtrl">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Inventory Movement</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Inventory Management</a></li>
        <li class="active">Inventory Movement</li>
      </ol>
    </section>
    <section class="content form-page">
    	
		<div class="box box-primary pad20">
        <div class="box-header with-border classBoxTitle" >
			<h3 class="box-title" id="shipFrom"><b>Ship From</b></h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
			
			<div class="row">
				
				<div class="col-md-2">
					<div class="form-group">
						<label>Account Type</label>
						<select class="form-control input-md" width="100%" id="accounttype" ng-model="fileUploadData.accountType" ng-change="getAllAccounts()" name="accounttype" >
							<option value="" selected>Select Account Type</option>
							<option ng-repeat="accountType in accountTypes" value="{{accountType.id}}">{{accountType.accountType}}</option>
						</select>
					</div>
				</div>
				
				<div class="col-md-2">
					<div class="form-group">
						<label>Location Type</label>
						<select class="form-control input-md" width="100%" ng-model="fileUploadData.locationType" id="locationType" name="locationType" ng-change="getAllAccounts()">
							<option value="" selected>Select Location</option>
							<option ng-repeat="loc in locationTypes" value="{{loc.id}}">{{loc.locationType}}</option>					
						</select>
					</div>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
					<div class="form-group">
						<label>Customer Name</label>
						<input type="text" placeholder="Enter Account Name" autocomplete="off" ng-model="fileUploadData.customerName" id="customerName" name="customerName" ng-keyup="getAllAccounts()" class="form-control input-sm" value="">
					</div>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
					<div class="form-group">
						<label>Customer#</label>
						<input type="text" placeholder="Enter Account#" autocomplete="off" ng-model="fileUploadData.customerNumber" id="customerNumber" name="customerNumber" ng-keyup="getAllAccounts()" class="form-control input-sm" value="">
					</div>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
					<div class="form-group">
						<label>Location Name</label>
						<input type="text" placeholder="Enter Locatoin Name" autocomplete="off" ng-model="fileUploadData.locationName" id="locationName" name="locationName" ng-keyup="getAllAccounts()" class="form-control input-sm" value="">
					</div>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
					<div class="form-group">
						<label>Location#</label>
						<input type="text" placeholder="Enter Location#" autocomplete="off" ng-model="fileUploadData.locationNumber" id="locationNumber" name="locationNumber" ng-keyup="getAllAccounts()" class="form-control input-sm" value="">
					</div>
				</div>
				
			</div>
			
			<div class="row">
				<div class="col-lg-12">
					<table datatable="ng" dt-options="accountOptions" class="table table-striped table-bordered">
						<thead>
							<tr>
								<th align="center"></th>
								<th>Account Name</th>
								<th>Location Type</th>
								<th>Customer</th>
								<th>Customer#</th>
								<th>Customer Nickname</th>
								<th>Customer Ref#</th>
								<th>City</th>
								<th>State</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
							<tr ng-repeat="account in allAccountList">
								<td align="center"><input type="radio" ng-disabled="account.accountStatus == 2" ng-click="selectAccountLocation(account)" ng-model="fileUploadData.location" name="location" id="location" value="" /></td>
								<td><a href="#" data-toggle="modal" data-target="#myAccount">{{account.companyName}}</a></td>
								<td>{{account.accountTypeDetails.accountType}}</td>
								<td>{{account.companyName}}</td>
								<td>LOC0054</td>
								<td>{{account.nickName}}</td>
								<td>{{account.referenceCode}}</td>
								<td>{{account.cityDetails.cityName}}</td>
								<td>{{account.stateDetails.stateName}}</td>
								<td>{{account.accountStatusDetails.statusDesc}}</td>
							</tr>
						</tbody>
					</table>					
				</div>
			</div>
			
			<div class="row">&nbsp;&nbsp;</div>
			
			<div class="row" ng-show="IsLocationDetailsVisible">
				<div class="col-md-12 col-lg-12">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Account Name</b></label> : {{ selectedAccount.companyName }}
							</div>
						</div>					
								
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Location Type</b></label> : {{ selectedAccount.companyName }}
							</div>
						</div>
						
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Customer</b></label> : {{ selectedAccount.companyName }}
							</div>
						</div>
						
					</div>
				</div>
				
				<div class="col-md-12 col-lg-12">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Customer#</b></label> : {{ selectedAccount.companyName }}
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Customer Nickname</b></label> : {{ selectedAccount.companyName }}
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Customer Ref#</b></label> : {{ selectedAccount.companyName }}
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-12 col-lg-12">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Address</b></label> : {{ selectedAccount.addressLine1 }} {{ selectedAccount.addressLine2 }}
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="box-header with-border showRetailerDiv">
				<h3 class="box-title" id="shipTo"><b>Ship To</b></h3>
			</div>
			<div class="row showRetailerDiv">				
				<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
					<div class="form-group">
						<label>Company Name:</label>
						<div class="input-group">
							<input type="text" placeholder="Enter Company Name" onkeyup="showRetailerList(this.value);" class="form-control pull-right" id="locationid">
						</div>
					</div>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
					<div class="form-group">
						<label>Ref Code:</label>
						<div class="input-group">
							<input type="text" placeholder="Enter Ref Code" onkeyup="showRetailerList(this.value);" class="form-control pull-right" id="referencecode">
						</div>
					</div>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
					<div class="form-group">
						<label>Nickname:</label>
						<div class="input-group">
							<input type="text" placeholder="Enter Nickname" onkeyup="showRetailerList(this.value);" class="form-control pull-right" id="referencecode">
						</div>
					</div>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
					<div class="form-group">
						<label>State:</label>
						<div class="input-group">
							<input type="text" placeholder="Enter State" onkeyup="showRetailerList(this.value);" class="form-control pull-right" id="referencecode">
						</div>
					</div>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
					&nbsp;
				</div>
				<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
					<div class="form-group"><br/>
						<button type="button" onclick="appendRetailerList();" class="btn btn-primary add-more-button pull-right" >Add More</button>
					</div>
				</div>
			</div>
			
			<div class="row" >
				<div class="col-lg-12" id="">
					<table id="datatable" class="table table-bordered table-striped dataTable">
						<thead>
							<tr>								
								<th>Dealership</th>
								<th>Name</th>
								<th>Store #</th>
								<th>Ref #</th>
								<th>Nickname</th>
								<th>City</th>
								<th>State</th>
								<th>BLU</th>
								<th>BLK</th>
								<th>MCM</th>
								<th>BRIZO</th>
								<th>Ship Date</th>
							</tr>
						</thead>
						<tbody>
							<tr>								
								<td>ComName1</td>
								<td>LocName1</td>
								<td>2456</td>
								<td>Ref0051</td>
								<td>LocNickName1</td>
								<td>City1</td>
								<td>State1</td>
								<td><input type="text" class="form-control input-sm " name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							<tr>								
								<td>ComName2</td>
								<td>LocName2</td>
								<td>2456</td>
								<td>Ref0052</td>
								<td>LocNickName2</td>
								<td>City2</td>
								<td>State2</td>
								<td><input type="text" class="form-control input-sm " name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							<tr>								
								<td>ComName3</td>
								<td>LocName3</td>
								<td>2456</td>
								<td>Ref0053</td>
								<td>LocNickName3</td>
								<td>City3</td>
								<td>State3</td>
								<td><input type="text" class="form-control input-sm " name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							<tr>								
								<td>ComName4</td>
								<td>LocName4</td>
								<td>2456</td>
								<td>Ref0054</td>
								<td>LocNickName</td>
								<td>City4</td>
								<td>State4</td>
								<td><input type="text" class="form-control input-sm " name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							
						</tbody>
					</table>					
				</div>
				
				
				<div class="col-lg-12" id="addedDestinationmmdiv">
					<div class="row">
						<div class="col-lg-12" id=""><h4><b>Ship in Process</b></h4></div>
					</div>
					<table class="table table-bordered table-striped dataTable">
						<thead>
							<tr>
								<th>Dealership</th>
								<th>Name</th>
								<th>Store #</th>
								<th>Ref #</th>
								<th>Nickname</th>
								<th>City</th>
								<th>State</th>
								<th>BLU</th>
								<th>BLK</th>
								<th>MCM</th>
								<th>BRIZO</th>
								<th>Ship Date</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody class="addedDestinationmm">
							
						</tbody>
					</table>					
				</div>
				
				<div class="col-lg-12">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>
									<a href="ship_to_retailer_summary_mm.html" class="btn btn-primary">Continue</a>
								</label>
								<label>
									<a href="ship_to_retailer.html" class="btn btn-danger">Cancel</a>
								</label>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			
			
        </div>
    </div>
    	
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 0.0
    </div>
    <strong>&nbsp;Copyright &copy; 2018, Powered by <a href="https://www.advatix.com/" target="_blank">&nbsp;Advatix</a></strong>
  </footer>

  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/inventoryMovement/sentToLocationCtrl.js"></script>