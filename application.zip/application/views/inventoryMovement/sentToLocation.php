<div class="content-wrapper" ng-controller="sentToLocationCtrl">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Inventory Movement</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Inventory Management</a></li>
        <li class="active">Inventory Movement</li>
      </ol>
    </section>
    <section class="content form-page">
    	
		<div class="box box-primary pad20">
        <div class="box-header with-border classBoxTitle" >
			<h3 class="box-title" id="shipFrom"><b>Ship From</b></h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
			
			<div class="row">
				
				<div class="col-md-2">
					<div class="form-group">
						<label>Account Type</label>
						<select class="form-control input-md" width="100%" id="accounttype" onchange="showDataGrid(1);" name="accounttype" >
							<option value="" selected>Select Account</option>
							<option value="customerGrower">Customer - Grower</option>
							<option value="customerBWB">Customer - BWB</option>
							<option value="customerTK">Customer - TK</option>
							<option value="customerMM">Customer - Mercury</option>
						</select>
					</div>
				</div>
				
				<div class="col-md-2">
					<div class="form-group">
						<label>Location Type</label>
						<select class="form-control input-md" width="100%" id="loctype" name="loctype" onchange="showDataGrid(2);">
							<option value="" selected>Select Account</option>
							<option>Dealership</option>
							<option>Distribution Center</option>
							<option>Library</option>
							<option>Nursery</option>
							<option>OEM</option>
							<option>Retail</option>
							<option>Provider Loc</option>						
						</select>
					</div>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
					<div class="form-group">
						<label>Customer Name</label>
						<input type="text" placeholder="Enter Account Name" onkeyup="showDataGrid(2);" class="form-control input-sm" value="">
					</div>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
					<div class="form-group">
						<label>Customer#</label>
						<input type="text" placeholder="Enter Account#" onkeyup="showDataGrid(2);" class="form-control input-sm" value="">
					</div>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
					<div class="form-group">
						<label>Location Name</label>
						<input type="text" placeholder="Enter Locatoin Name" onkeyup="showDataGrid(2);" class="form-control input-sm" value="">
					</div>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
					<div class="form-group">
						<label>Location#</label>
						<input type="text" placeholder="Enter Location#" onkeyup="showDataGrid(2);" class="form-control input-sm" value="">
					</div>
				</div>
				
			</div>
			
			<div class="row showhidetable">
				<div class="col-lg-12">
					<table id="datatable" class="table table-bordered table-striped dataTable">
						<thead>
							<tr>
								<th align="center"></th>
								<th>Account Name</th>
								<th>Location Type</th>
								<th>Customer</th>
								<th>Customer#</th>
								<th>Customer Nickname</th>
								<th>Customer Ref#</th>
								<th>City</th>
								<th>State</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td align="center"><input type="radio" onclick="showOrigin();" name="location" id="" value="" /></td>
								<td><a href="#" data-toggle="modal" data-target="#myAccount">Account Name 1</a></td>
								<td>Library</td>
								<td>Loc Name 1</td>
								<td>LOC0054</td>
								<td>Loc Nickname 1</td>
								<td>REF0041</td>
								<td>City1</td>
								<td>State1</td>
							</tr>
							<tr>
								<td align="center"><input type="radio" onclick="showOrigin();" name="location" id="" value="" /></td>
								<td><a href="#" data-toggle="modal" data-target="#myAccount">Account Name 1</a></td>
								<td>Library</td>
								<td>Loc Name 2</td>
								<td>LOC0054</td>
								<td>Loc Nickname 2</td>
								<td>REF0041</td>
								<td>City 2</td>
								<td>State 2</td>
							</tr>
							<tr>
								<td align="center"><input type="radio" onclick="showOrigin();" name="location" id="" value="" /></td>
								<td><a href="#" data-toggle="modal" data-target="#myAccount">Account Name 1</a></td>
								<td>Library</td>
								<td>Loc Name 3</td>
								<td>LOC0054</td>
								<td>Loc Nickname 3</td>
								<td>REF0041</td>
								<td>City3</td>
								<td>State3</td>
							</tr>
							<tr>
								<td align="center"><input type="radio" onclick="showOrigin();" name="location" id="" value="" /></td>
								<td><a href="#" data-toggle="modal" data-target="#myAccount">Account Name 1</a></td>
								<td>Library</td>
								<td>Loc Name 4</td>
								<td>LOC0054</td>
								<td>Loc Nickname 4</td>
								<td>REF0041</td>
								<td>City4</td>
								<td>State4</td>
							</tr>
						</tbody>
					</table>					
				</div>
			</div>
			<div class="row showRetailerDiv">
				<div class="col-md-12 col-lg-12">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Account Name</b></label> : Account Name 1
							</div>
						</div>					
								
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Location Type</b></label> : Library
							</div>
						</div>
						
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Customer</b></label> : Loc Name 1
							</div>
						</div>
						
					</div>
				</div>
				
				<div class="col-md-12 col-lg-12">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Customer#</b></label> : LOC0054
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Customer Nickname</b></label> : Loc Nickname 1
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Customer Ref#</b></label> : REF0041
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-12 col-lg-12">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label><b>Address</b></label> : Address1, City1, State1
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="box-header with-border showRetailerDiv">
				<h3 class="box-title" id="shipTo"><b>Ship To</b></h3>
			</div>
			<div class="row showRetailerDiv">				
				<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
					<div class="form-group">
						<label>Company Name:</label>
						<div class="input-group">
							<input type="text" placeholder="Enter Company Name" onkeyup="showRetailerList(this.value);" class="form-control pull-right" id="locationid">
						</div>
					</div>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
					<div class="form-group">
						<label>Ref Code:</label>
						<div class="input-group">
							<input type="text" placeholder="Enter Ref Code" onkeyup="showRetailerList(this.value);" class="form-control pull-right" id="referencecode">
						</div>
					</div>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
					<div class="form-group">
						<label>Nickname:</label>
						<div class="input-group">
							<input type="text" placeholder="Enter Nickname" onkeyup="showRetailerList(this.value);" class="form-control pull-right" id="referencecode">
						</div>
					</div>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
					<div class="form-group">
						<label>State:</label>
						<div class="input-group">
							<input type="text" placeholder="Enter State" onkeyup="showRetailerList(this.value);" class="form-control pull-right" id="referencecode">
						</div>
					</div>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
					&nbsp;
				</div>
				<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
					<div class="form-group"><br/>
						<button type="button" onclick="appendRetailerList();" class="btn btn-primary add-more-button pull-right" >Add More</button>
					</div>
				</div>
			</div>
			
			<div class="row showRetailerDivMM" >
				<div class="col-lg-12" id="showRetailerList">
					<table id="datatable" class="table table-bordered table-striped dataTable">
						<thead>
							<tr>								
								<th>Dealership</th>
								<th>Name</th>
								<th>Store #</th>
								<th>Ref #</th>
								<th>Nickname</th>
								<th>City</th>
								<th>State</th>
								<th>BLU</th>
								<th>BLK</th>
								<th>MCM</th>
								<th>BRIZO</th>
								<th>Ship Date</th>
							</tr>
						</thead>
						<tbody>
							<tr>								
								<td>ComName1</td>
								<td>LocName1</td>
								<td>2456</td>
								<td>Ref0051</td>
								<td>LocNickName1</td>
								<td>City1</td>
								<td>State1</td>
								<td><input type="text" class="form-control input-sm " name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							<tr>								
								<td>ComName2</td>
								<td>LocName2</td>
								<td>2456</td>
								<td>Ref0052</td>
								<td>LocNickName2</td>
								<td>City2</td>
								<td>State2</td>
								<td><input type="text" class="form-control input-sm " name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							<tr>								
								<td>ComName3</td>
								<td>LocName3</td>
								<td>2456</td>
								<td>Ref0053</td>
								<td>LocNickName3</td>
								<td>City3</td>
								<td>State3</td>
								<td><input type="text" class="form-control input-sm " name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							<tr>								
								<td>ComName4</td>
								<td>LocName4</td>
								<td>2456</td>
								<td>Ref0054</td>
								<td>LocNickName</td>
								<td>City4</td>
								<td>State4</td>
								<td><input type="text" class="form-control input-sm " name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							
						</tbody>
					</table>					
				</div>
				
				
				<div class="col-lg-12" id="addedDestinationmmdiv">
					<div class="row">
						<div class="col-lg-12" id=""><h4><b>Ship in Process</b></h4></div>
					</div>
					<table class="table table-bordered table-striped dataTable">
						<thead>
							<tr>
								<th>Dealership</th>
								<th>Name</th>
								<th>Store #</th>
								<th>Ref #</th>
								<th>Nickname</th>
								<th>City</th>
								<th>State</th>
								<th>BLU</th>
								<th>BLK</th>
								<th>MCM</th>
								<th>BRIZO</th>
								<th>Ship Date</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody class="addedDestinationmm">
							
						</tbody>
					</table>					
				</div>
				
				<div class="col-lg-12">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>
									<a href="ship_to_retailer_summary_mm.html" class="btn btn-primary">Continue</a>
								</label>
								<label>
									<a href="ship_to_retailer.html" class="btn btn-danger">Cancel</a>
								</label>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			<div class="row showRetailerDivTK" >
				<div class="col-lg-12" id="showRetailerList">
					<table id="datatable" class="table table-bordered table-striped dataTable">
						<thead>
							<tr>								
								<th>Dealership</th>
								<th>Name</th>
								<th>Store #</th>
								<th>Ref #</th>
								<th>Nickname</th>
								<th>City</th>
								<th>State</th>
								<th>APU TRI48</th>
								<th>APU TRI57</th>
								<th>SP TRUC</th>
								<th>Ship Date</th>
							</tr>
						</thead>
						<tbody>
							<tr>								
								<td>ComName1</td>
								<td>LocName1</td>
								<td>2456</td>
								<td>Ref0051</td>
								<td>LocNickName1</td>
								<td>City1</td>
								<td>State1</td>
								<td class="appentmore"><input type="text" class="addmore form-control input-sm " name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							<tr>								
								<td>ComName2</td>
								<td>LocName2</td>
								<td>2456</td>
								<td>Ref0052</td>
								<td>LocNickName2</td>
								<td>City2</td>
								<td>State2</td>
								<td class="appentmore2"><input type="text" class="addmore2 form-control input-sm " name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							<tr>								
								<td>ComName3</td>
								<td>LocName3</td>
								<td>2456</td>
								<td>Ref0053</td>
								<td>LocNickName3</td>
								<td>City3</td>
								<td>State3</td>
								<td class="appentmore3"><input type="text" class="addmore3 form-control input-sm " name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							<tr>								
								<td>ComName4</td>
								<td>LocName4</td>
								<td>2456</td>
								<td>Ref0054</td>
								<td>LocNickName</td>
								<td>City4</td>
								<td>State4</td>
								<td class="appentmore4"><input type="text" class="addmore4 form-control input-sm " name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							
						</tbody>
					</table>					
				</div>
				
				
				<div class="col-lg-12" id="addedDestinationtkdiv">
					<div class="row">
						<div class="col-lg-12" id=""><h4><b>Ship in Process</b></h4></div>
					</div>
					<table class="table table-bordered table-striped dataTable">
						<thead>
							<tr>
								<th>Dealership</th>
								<th>Name</th>
								<th>Store #</th>
								<th>Ref #</th>
								<th>Nickname</th>
								<th>City</th>
								<th>State</th>
								<th>APU TRI48</th>
								<th>APU TRI57</th>
								<th>SP TRUC</th>
								<th>Ship Date</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody class="addedDestinationtk">
							
						</tbody>
					</table>					
				</div>
				
				<div class="col-lg-12">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>
									<a href="ship_to_retailer_summary_tk.html" class="btn btn-primary">Continue</a>
								</label>
								<label>
									<a href="ship_to_retailer.html" class="btn btn-danger">Cancel</a>
								</label>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			
			<div class="row showRetailerDivBWB" >
				<div class="col-lg-12" id="showRetailerList">
					<table id="datatable" class="table table-bordered table-striped dataTable">
						<thead>
							<tr>
								<th>Library</th>
								<th>Name</th>
								<th>LIB #</th>
								<th>Ref #</th>
								<th>Nickname</th>
								<th>City</th>
								<th>State</th>
								<th>LC</th>
								<th>PC</th>
								<th>Gaylords</th>
								<th>Ship Date</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>ComName1</td>
								<td>LocName</td>
								<td>6482</td>
								<td>REF04211</td>								
								<td>LocNickname</td>								
								<td>City1</td>
								<td>State1</td>
								<td><input type="text" class="form-control input-sm " name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							<tr>
								<td>ComName2</td>
								<td>LocName2</td>
								<td>6482</td>
								<td>REF04212</td>								
								<td>LocNickname2</td>								
								<td>City2</td>
								<td>State2</td>
								<td><input type="text" class="form-control input-sm" name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							<tr>
								<td>ComName3</td>
								<td>LocName3</td>
								<td>6482</td>
								<td>REF04213</td>								
								<td>LocNickname</td>								
								<td>City3</td>
								<td>State3</td>
								<td><input type="text" class="form-control input-sm" name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							<tr>
								<td>ComName4</td>
								<td>LocName4</td>
								<td>6482</td>
								<td>REF04214</td>								
								<td>LocNickname</td>								
								<td>City4</td>
								<td>State4</td>
								<td><input type="text" class="form-control input-sm" name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							
						</tbody>
					</table>					
				</div>
				
				<div class="col-lg-12" id="addedDestinationBWBdiv">
					<div class="row">
						<div class="col-lg-12" id=""><h4><b>Ship in Process</b></h4></div>
					</div>
					<table class="table table-bordered table-striped dataTable">
						<thead>
							<tr>
								<th>Library</th>
								<th>Name</th>
								<th>LIB #</th>
								<th>Ref #</th>
								<th>Nickname</th>
								<th>City</th>
								<th>State</th>
								<th>LC</th>
								<th>PC</th>
								<th>Gaylords</th>
								<th>Ship Date</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody class="addedDestinationBWB">
							
						</tbody>
					</table>					
				</div>
				
				<div class="col-lg-12">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>
									<a href="ship_to_retailer_summary_bwb.html" class="btn btn-primary">Continue</a>
								</label>
								<label>
									<a href="ship_to_retailer.html" class="btn btn-danger">Cancel</a>
								</label>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			
			<div class="row showRetailerDivGrower" >
				<div class="col-lg-12" id="showRetailerList">
					<table id="datatable" class="table table-bordered table-striped dataTable">
						<thead>
							<tr>
								<th>Retailer</th>
								<th>Name</th>
								<th>Store #</th>
								<th>Ref #</th>
								<th>Nickname</th>
								<th>City</th>
								<th>State</th>
								<th>Racks</th>
								<th>Shelves</th>
								<th>Ship Date</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>ComName1</td>
								<td>LocName1</td>
								<td>9875</td>
								<td>REF0451</td>
								<td>LocNickname</td>
								<td>City1</td>
								<td>State1</td>
								<td><input type="text" class="form-control input-sm " name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td><div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div></td>
							</tr>
							<tr>
								
								<td>ComName2</td>
								<td>LocName2</td>
								<td>9872</td>
								<td>REF0452</td>
								<td>LocNickname2</td>
								<td>City2</td>
								<td>State2</td>
								<td><input type="text" class="form-control input-sm" name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							<tr>
								
								<td>ComName3</td>
								<td>LocName3</td>
								<td>9873</td>
								<td>REF0453</td>
								<td>LocNickname3</td>
								<td>City3</td>
								<td>State3</td>
								<td><input type="text" class="form-control input-sm" name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							<tr>								
								<td>ComName4</td>
								<td>LocName4</td>
								<td>9874</td>
								<td>REF0454</td>
								<td>LocNickname4</td>
								<td>City4</td>
								<td>State4</td>
								<td><input type="text" class="form-control input-sm" name="racks" style="width:70px;" value="" /></td>
								<td><input type="text" class="form-control input-sm" name="Shelves" style="width:70px;" value="" /></td>
								<td>
								<div class="input-group date" style="width:140px;">
									<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
									<input type="text" class="form-control input-sm pull-right datepicker" id="datefrom">
								</div>
								</td>
							</tr>
							
						</tbody>
					</table>					
				</div>
				
				<div class="col-lg-12" id="addedDestinationGrowerdiv">
					<div class="row">
						<div class="col-lg-12" id=""><h4><b>Ship in Process</b></h4></div>
					</div>
					<table class="table table-bordered table-striped dataTable">
						<thead>
							<tr>
								<th>Retailer</th>
								<th>Name</th>
								<th>Store #</th>
								<th>Ref #</th>
								<th>Nickname</th>
								<th>City</th>
								<th>State</th>
								<th>Racks</th>
								<th>Shelves</th>
								<th>Ship Date</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody class="addedDestinationGrower">
							
						</tbody>
					</table>					
				</div>
				
				<div class="col-lg-12">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>
									<a href="ship_to_retailer_summary.html" class="btn btn-primary">Continue</a>
								</label>
								<label>
									<a href="ship_to_retailer.html" class="btn btn-danger">Cancel</a>
								</label>
								
							</div>
						</div>
					</div>
				</div>
				
			</div>
			
			
        </div>
    </div>
    	
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 0.0
    </div>
    <strong>&nbsp;Copyright &copy; 2018, Powered by <a href="https://www.advatix.com/" target="_blank">&nbsp;Advatix</a></strong>
  </footer>

  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/accounts/createAccountCtrl.js"></script>