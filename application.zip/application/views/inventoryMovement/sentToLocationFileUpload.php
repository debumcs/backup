<div class="content-wrapper" ng-controller="sentToLocationUploadCtrl">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Sent to Location</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Inventory Management</a></li>
        <li class="active">Sent to Location</li>
      </ol>
    </section>
    <section class="content form-page">
    	
		<div class="box box-primary pad20">
        <div class="box-header with-border classBoxTitle" >
			<h3 class="box-title" id="shipFrom"><b>Ship From</b></h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
		<form autocomplete="off" novalidate name="fileUploadForm" ng-submit="uploadSentToFile()">
			<div class="row">					
				<div class="col-md-6">
					<div class="form-group">
						<label>File Upload <span class="asterisk">*</span></label>
						<input type="file" ng-model="fileUploadData.filename" name="filename" id="filename" class="form-control" required />
						<div ng-if="submitted && fileUploadForm.filename.$invalid" class="invalid-feedback">
							<span ng-if="fileUploadForm.filename.$error.required">File is required. </span>
						</div>
					</div>
				</div>
				<!-- /.form-group -->
				<div class="col-md-6">
					<div class="form-group">
						<p>&nbsp;<br/><br/></p>
						<a href="<?php echo base_url();?>asset/sentToLocationFileUpload.xlsx">Click here</a> to download file format.
					</div>
				</div>	
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<input type="submit" name="submit" id="submit" class="btn btn-primary" value="Submit" />
					</div>
				</div>
			</div>
		</form>
        </div>
    </div>
    	
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 0.0
    </div>
    <strong>&nbsp;Copyright &copy; 2018, Powered by <a href="https://www.advatix.com/" target="_blank">&nbsp;Advatix</a></strong>
  </footer>

  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/inventoryMovement/sentToLocationUploadCtrl.js"></script>