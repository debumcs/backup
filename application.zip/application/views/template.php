<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en" ng-app="ezrOmsApp">
<head>
	<meta charset="utf-8">
	<title>EZR | OMS</title>
<link rel="icon" type="image/x-icon" href="<?php echo base_url(); ?>favicon.ico">
<?php $this->load->view('common/css'); ?>
<script src="<?php echo base_url(); ?>asset/bower_components/jquery/dist/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>asset/angular/angular.min.js"></script>
<script src="<?php echo base_url(); ?>asset/angular/app.js"></script>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<?php $this->load->view('common/header'); ?>
<?php $this->load->view('common/sidebar'); ?>
	<?=$body?>
<?php $this->load->view('common/footer'); ?>
</body>
</html>