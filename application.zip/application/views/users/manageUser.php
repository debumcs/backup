<div class="content-wrapper" ng-controller="viewAllUsers">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>User Management</h1>
    <ol class="breadcrumb">
      <li><a href='#'><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href='#'>User Management</a></li>
      <li class="active">List of all users</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        
        <div class="box">
          
    <div class="box-header with-border">
      
      <h3 class="box-title m10"><b>List of all Users</b></h3>
    </div>
    
          <!-- /.box-header -->
          <div class="box-body">
      <div class="row">
        <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
          <form [formGroup]="userSearchForm">
          <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
              <div class="form-group">
                <label>Username</label>
                <input type="text" ng-model="userData.UserName" ng-keyup="getUserdata()" name="UserName" id="UserName" class="form-control input-sm" value="">
              </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
              <div class="form-group">
                <label>First Name</label>
                <input type="text" ng-model="userData.FName" ng-keyup="getUserdata()" name="FName" id="FName" class="form-control input-sm" value="">
              </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
              <div class="form-group">
                <label>Last Name</label>
                <input type="text" ng-model="userData.LName" ng-keyup="getUserdata()" name="LName" id="LName" class="form-control input-sm" value="">
              </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
              <div class="form-group">
                <label>Status</label>
                <select class="form-control input-md" ng-change="getUserdata()" ng-model="userData.UserStatus" name="UserStatus" id="UserStatus" >
                <option value="" selected>Select Status</option>
                <option ng-repeat="user in allUserStatus" value="{{user.id}}">{{user.statusDesc}}</option>
                </select>
              </div>
            </div>
          </div>
        </form>
        </div>
      </div>
      
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">&nbsp;</div>
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <table datatable="ng" dt-options="dtOptions" class="table table-striped table-bordered">
            <thead>
              <tr>
                <th>Username</th>
                <th>Employee Number</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Role</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              
              <tr ng-repeat="user in allUserList">
                <td><a href="<?php echo base_url(); ?>Users/view_user/{{ user.userId }}">{{ user.userName }}</a></td>
                <td>{{ user.employeeNumber }}</td>
                <td>{{ user.firstName }}</td>
                <td>{{ user.lastName }}</td>
                <td>{{ user.email }}</td>
                <td>{{ user.phoneNumber }}</td>
                <td>{{ user.roleDetails["roleDesc"] }}</td>
                <td>{{ user.statusDetails["statusDesc"] }}</td>
              </tr>              
            </tbody>
          </table>
        </div>
      </div>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/users/viewAllUsers.js"></script>