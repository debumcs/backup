<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Location</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Location</a></li>
        <li class="active">Create Location Confirmation </li>
      </ol>
    </section>
    <section class="content form-page">
	
		<div class="box">
		<div class="box-body">
			<div class="padleftright20">
				<div class="accordion-option">
					<!-- <h3 class="title">Lorem Ipsum</h3> -->
					<!--a href="edit_savedorder.html" class="btn btn-primary">Edit</a-->
					<a href="javascript:void(0)" class="toggle-accordion active" accordion-id="#accordion"></a>
				</div>
				<div class="clearfix"></div>
				<?php if($response["responseStatusCode"] != '200'){ ?>
					<div class="row">												
						<div class="col-md-12">
							<h4 class="panel-title">Location Details</h4>
						</div>						
					</div>
					<div class="row">												
						<div class="col-md-12">
							<?php echo $response["responseMessage"]; ?>
						</div>						
					</div>
				<?php } ?>
				
				<?php if($response["responseStatusCode"] == '200'){ ?>					
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
								Location Details
								</a>
							</h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
							<div class="panel-body">
								<div class="row ">
								<div class="col-md-12 col-lg-12 col-sm-12">
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<label>Location Type</label> : <?php echo $response["responseObject"]["locationType"]; ?>
											</div>
										</div>
										
										<div class="col-md-4">
											<div class="form-group">
												<label>Location#</label> : <?php echo $response["responseObject"]["locationId"]; ?>
											</div>
										</div>
										
										<div class="col-md-4">
											<div class="form-group">
												<label>Ref#</label> : <?php echo $response["responseObject"]["referenceCode"]; ?>
											</div>
										</div>
									</div>
									
									<div class="row">	
										<div class="col-md-4">
											<div class="form-group">
												<label>Unit Number</label> : <?php echo $response["responseObject"]["unitNumber"]; ?>
											</div>
										</div>
														
										<div class="col-md-4">
											<div class="form-group">
												<label>Location Name</label> : <?php echo $response["responseObject"]["locationName"]; ?>
											</div>
										</div>
										
										<div class="col-md-4">
											<div class="form-group">
												<label>Location Nickname</label> : <?php echo $response["responseObject"]["nickName"]; ?>
											</div>
										</div>
										
									</div>
									
									<div class="row">												
										<div class="col-md-4">
											<div class="form-group">
												<label>Address 1</label> : <?php echo $response["responseObject"]["addressLine1"]; ?>
											</div>
										</div>
									
										<div class="col-md-4">
											<div class="form-group">
												<label>Address 2</label> : <?php echo $response["responseObject"]["addressLine2"]; ?>
											</div>
										</div>	
										
										<div class="col-md-4">
											<div class="form-group">
												<label>Zip Code</label> : <?php echo $response["responseObject"]["zipCode"]; ?>
											</div>
										</div>
										
									</div>
									
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<label>City</label> : <?php echo $response["responseObject"]["city"]; ?>
											</div>
										</div>
										
										<div class="col-md-4">
											<div class="form-group">
												<label>State</label> : <?php echo $response["responseObject"]["state"]; ?>
											</div>
										</div>
										
										<div class="col-md-4">
											<div class="form-group">
												<label>Country</label> : <?php echo $response["responseObject"]["country"]; ?>
											</div>
										</div>
										
									</div>
									
									<div class="row">
										<div class="col-md-6" id="time-range">
											<table id="example1" class="table table-bordered table-striped ">
												<thead>
													<tr>
														<th align="center">&nbsp;</th>
														<th align="center" colspan="2">Operational hours</th>
													</tr>
													<tr>
														<th align="center">Open Days</th>
														<th align="center">From Time</th>
														<th align="center">To Time</th>
													</tr>
												</thead>
												<tbody>
												<?php foreach($response["responseObject"]["operationalHours"] as $value){ ?>
													<tr>												
														<td><?php echo $value["day"]; ?></td>
														<td><?php echo date("g:i a", strtotime($value["startTime"])); ?></td>
														<td><?php echo date("g:i a", strtotime($value["endTime"])); ?></td>
													</tr>
												<?php } ?>
												</tbody>
											</table>
										
										</div>
										
										<div class="col-md-6">
										
											<div class="row">
												<div class="col-md-6">
													<div class="form-group">
														<label>Email</label> : <?php echo $response["responseObject"]["contactEmail"]; ?>
													</div>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<label>Business Phone</label> : <?php echo $response["responseObject"]["businessPhone"]; ?>
													</div>
												</div>
											</div>
											
											<div class="row">
												<div class="col-md-6">
													<div class="form-group">
														<label>Contact Name</label> : <?php echo $response["responseObject"]["contactName"]; ?>
													</div>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<label>Contact Phone</label> : <?php echo $response["responseObject"]["contactPhone"]; ?>
													</div>
												</div>
											</div>
											
											<div class="row">
												<div class="col-md-6">
													<div class="form-group">
														<label>Fax</label> : <?php echo $response["responseObject"]["fax"]; ?>				
													</div>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<label>Status</label> : <?php echo $response["responseObject"]["status"]; ?>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							</div>
						</div>
					</div>
						
					<!--div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingTwo">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
								Associations
								</a>
							</h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
							<div class="panel-body">
								
								<div class="row" id="">								
									<div class="col-lg-12">
										<table id="example1" class="table table-bordered table-striped ">
											<thead>
												<tr>
													<th>Account #</th>
													<th>Account Name</th>
													<th>Account Nickame</th>
													<th>Account Ref #</th>
													<th>Account Type</th>													
													<th>Address</th>
													<th>City</th>
													<th>State</th>
													<th>Status</th>
												</tr>
											</thead>
											<tbody>
											
												<tr>
													<td>ACCON001</td>
													<td>AccountName1</td>
													<td>Nickame1</td>
													<td>REF795</td>
													<td>Customer</td>
													<td>Address01, Address02</td>
													<td>City01</td>
													<td>State01</td>
													<td>Active</td>												
												</tr>
												
											</tbody>
										</table>	
									</div>
								</div>
								
							</div>
						</div>
					</div-->
					
				</div>
				<?php } ?>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							
							<label>
								<a href="<?php echo base_url();?>index.php/Location/manage_locations" class="btn btn-primary">Manage Locations</a>
							</label>										
						</div>
					</div>
				</div>
				
			</div>
		</div>
		</div>    
    </section>
    <!-- /.content -->
  </div>