<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>EZR | Activate User</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="icon" type="image/x-icon" href="favicon.ico">
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/plugins/iCheck/square/blue.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset/dist/css/style.css">
  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <script src="<?php echo base_url(); ?>asset/bower_components/jquery/dist/jquery.min.js"></script>
  <script src="<?php echo base_url(); ?>asset/angular/angular.min.js"></script>
  <script src="<?php echo base_url(); ?>asset/angular/app.js"></script>
	
<style>
    font-size: 15px;
    color: darkgreen;
</style>

</head>
<body class="hold-transition login-page" ng-app="ezrOmsApp">
<div class="login-box" ng-controller="activateUserCtrl">
	<div class="login-logo">
		<span class="logo-lg"><img src="<?php echo base_url(); ?>asset/dist/img/logo-dashboard.png" class="logo-lg" style="width: 146px; margin: 5px;" alt="logo-lg"></span>
	</div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg" style="font-size: 20px;">Set password</p>

    <form autocomplete="off" novalidate name="activateUserForm" ng-submit="onSubmit()">
      <div class="form-group has-feedback">
        <input type="text" class="form-control" readonly name="username" value="<?php echo $username; ?>" />
        <span class="glyphicon glyphicon-user form-control-feedback"></span>
		<input type="hidden" name="urlToken" id="urlToken" value="<?php echo $requestToken; ?>" />
		<input type="hidden" ng-model="userActivate.requestToken" name="requestToken" />
      </div>
	  <div class="form-group has-feedback">
        <input type="password" class="form-control" placeholder="Password" pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,15}$" ng-model="userActivate.password" name="password" required />
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
		<div ng-if="submitted && activateUserForm.password.$invalid" class="invalid-feedback">
			<span ng-if="activateUserForm.password.$error.required">Password required</span>
			<span ng-if="activateUserForm.password.$error.pattern">Password must be minimum 8 and maximum 15 characters, at least one uppercase letter, one lowercase letter and one special character</span>
		</div>		
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" placeholder="Confirm password" ng-model="userActivate.confpassword" name="confpassword" password-verify="{{userActivate.password}}" />
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
		<div ng-if="submitted && activateUserForm.confpassword.$invalid" class="invalid-feedback">
			<span ng-if="activateUserForm.confpassword.$error.passwordVerify">Password not matched!</span>
		</div>
      </div>
      <div class="row">
        <div class="col-xs-8">
          &nbsp;
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" class="btn btn-primary btn-block btn-flat">Submit</button>
        </div>
      </div>
	  <div class="row">
        <div class="col-xs-8">
          &nbsp;
        </div>
      </div>
    </form>

    <!-- /.social-auth-links -->

  </div>
  <div class="row">
    <div class="col-xs-12" style="padding: 20px; border-top: 0;">
      <div  class="invalid-feedback">
        {{errorMsg}}
      </div>
    </div>
  </div>
  <div ng-if="responseStatusCode == 200" class="row alert alert-success"> Password created successfully. <a href="<?php echo base_url(); ?>">Click here</a> to login with new password.</div>
  <!-- /.login-box-body -->
</div>
<script src="<?php echo base_url(); ?>asset/angular/controllers/activateUser/activateUserCtrl.js"></script>
<script src="<?php echo base_url(); ?>asset/angular/angular-datatables.min.js"></script>
<script src="<?php echo base_url(); ?>asset/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>asset/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/angularjs-datepicker/2.1.23/angular-datepicker.js"></script>
<script>
localStorage.removeItem('token');
</script>
</body>
</html>