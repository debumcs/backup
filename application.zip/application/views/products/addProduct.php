<div class="content-wrapper" ng-controller="createProductCtrl">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Add Product</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Configuration Management</a></li>
        <li class="active">Add Product</li>
      </ol>
    </section>
    <section class="content form-page">
    	
	<div class="box box-primary pad20">
		<form autocomplete="off" name="productForm" ng-submit="addProduct()" >
        <div class="box-body">
			
			<div class="row" ng-hide="editorEnabled">
				<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
					<div class="form-group">
						<label>Account #</label>
						<input type="text" placeholder="Enter Account#" ng-keyup="getAllAccounts()" ng-model="productData.AccountId" name="AccountId" class="form-control input-sm" value="">
					</div>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
					<div class="form-group">
						<label>Account Name</label>
						<input type="text" placeholder="Enter Account Name" ng-keyup="getAllAccounts()" ng-model="productData.AccountName" name="AccountName"  class="form-control input-sm" value="">
					</div>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
					<div class="form-group">
						<label>Account Nick Name</label>
						<input type="text" placeholder="Enter Account Name" ng-keyup="getAllAccounts()" ng-model="productData.AccountNickName" name="AccountNickName" class="form-control input-sm" value="">
					</div>
				</div>
				
				<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
					<div class="form-group">
						<label>Status</label>
						<select class="form-control input-md" width="100%" ng-change="getAllAccounts()" ng-model="productData.AccountStatus" name="AccountStatus" >
						<option value="" selected>Select Status</option>
						<option  ng-repeat="status in allAccountStatus" value="{{status.id}}">{{status.statusDesc}}</option>
						</select>
					</div>
				</div>
				
			</div>
			
			<div class="row" ng-show="showAccountList">
				<div class="col-md-6 col-lg-6">
					<!--<table id="datatable" class="table table-bordered table-striped dataTable">-->
					<table datatable="ng" dt-options="dtOptions" class="table table-striped table-bordered">
						<thead>
							<tr>
								<th style="text-align: center;">#</th>
								<th>Account #</th>
								<th>Account Name</th>
								<th>Nick Name</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
							<tr ng-repeat="account in allAccountList" ng-if="account.accountType == 1">
								<td align="center"><input type="radio" ng-click="showAccountDetails(account.accountId)" ng-model="productData.accountId" name="accountId" value="{{account.accountId}}" /></td>
								<td><a href="#" data-toggle="modal" ng-click="showAccountDetailsModal(account.accountId)" data-target="#myAccount">{{account.accountId}}</a></td>
								<td>{{account.companyName}}</td>
								<td>{{account.nickName}}</td>
								<td>{{account.accountStatusDetails.statusDesc}}</td>
							</tr>
						</tbody>
					</table>
					<div ng-if="submitted && productForm.accountNumber.$error.required" class="invalid-feedback">Please select account</div>
				</div>
			</div>
			
			<div class="row proSKUType" style="margin-top:15px;" ng-show="proSKUType">
				<div class="col-lg-12 col-md-12">
					<div class="row">
						<div class="col-lg-6 col-md-6">
							<div class="form-group">
								<label>SKU Type</label>
								<select class="form-control input-md" ng-change="showSKUType(productData.skuTypeDrop)" ng-model="productData.skuTypeDrop" name="skuTypeDrop" >
								<option value="" disabled selected>Select SKU Type</option>
								<option  ng-repeat="skuType in allSKUTypes" value="{{skuType.id}}">{{skuType.skuType}}</option>
								</select>
							</div>
						</div>						
					</div>
				</div>
			</div>
			
			<div class="row" ng-show="proFormElement">
				<div class="col-lg-12 col-md-12">
					<div class="row">
						<div class="col-lg-4 col-md-4">
							<div class="form-group">
								<label>Account Type</label>
								<input type="text" readonly class="form-control input-sm" ng-hide="editorEnabled" ng-model="productData.accountType" name="accountType" />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.accountType }}</span>
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Account #</label>
								<input type="text" readonly class="form-control input-sm" ng-hide="editorEnabled" ng-model="productData.accountNumber" name="accountNumber" required />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.accountNumber }}</span>
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Account Name</label>
								<input type="text" readonly class="form-control input-sm" ng-hide="editorEnabled" ng-model="productData.accountName" name="accountName" />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.accountName }}</span>
							</div>
						</div>
					</div>
			
					<div class="row">	
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>SKU Type</label>
								<input type="text" readonly class="form-control input-sm" ng-hide="editorEnabled" ng-model="productData.skuTypeText" name="skuTypeText" value="" />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.skuTypeText }}</span>
								<input type="hidden" readonly class="form-control input-sm" ng-model="productData.skuType" name="skuType" value="" />
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4">
							<div class="form-group">
								<label>SKU Number</label>
								<input type="text" placeholder="Enter SKU Number" ng-hide="editorEnabled" class="form-control input-sm" ng-model="productData.skuNumber" name="skuNumber" value="" required unique-skunumber />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.skuNumber }}</span>
								<div ng-if="submitted && productForm.skuNumber.$invalid" class="invalid-feedback">
									<span ng-if="productForm.skuNumber.$error.required">SKU number required</span>
									<span ng-if="productForm.skuNumber.$error.uniqueField">SKU number already exists</span>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Description</label>
								<input type="text" placeholder="Enter SKU Description" ng-hide="editorEnabled" class="form-control input-sm" ng-model="productData.description" name="description" value="" required />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.description }}</span>
								<div ng-if="submitted && productForm.description.$error.required" class="invalid-feedback">Please enter description</div>
							</div>
						</div>
						<!--<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Serial Number</label>
								<input type="text" placeholder="Enter Serial Number" ng-hide="editorEnabled" class="form-control input-sm" ng-model="productData.serialNumber" name="serialNumber" value="" required />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.serialNumber }}</span>
								<div ng-if="submitted && productForm.serialNumber.$error.required" class="invalid-feedback">Please enter serial number</div>
							</div>
						</div>-->
						
					</div>
					
					<div class="row">							
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Length</label>
								<input type="text" placeholder="Enter Length" ng-hide="editorEnabled" class="form-control input-sm" ng-model="productData.length" name="length" value="" required />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.length }}</span>
								<div ng-if="submitted && productForm.length.$error.required" class="invalid-feedback">Please enter length</div>
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Width</label>
								<input type="text" placeholder="Enter Width" ng-hide="editorEnabled" class="form-control input-sm" ng-model="productData.width" name="width" value="" required />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.width }}</span>
								<div ng-if="submitted && productForm.width.$error.required" class="invalid-feedback">Please enter width</div>
							</div>
						</div>						
					</div>
					
					<div class="row" ng-show="showskulist">	
						<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
							<table class="table table-fixed ">
								<thead>
									<tr>
										<th class="col-xs-5 col-md-5 col-lg-5">{{ skuHeaderTitle }}</th>
										<th class="col-xs-2 col-md-2 col-lg-2">Quantity</th>
										<th class="col-xs-2 col-md-2 col-lg-2">Weight</th>
										<th class="col-xs-2 col-md-2 col-lg-2">Ext. Weight</th>
									</tr>
								</thead>
								<tbody class="tableheight">
									<tr ng-repeat="sku in allSKUBySkuType" ng-hide="!productData.qty[sku.productId] && editorEnabled">
										<td class="col-xs-5 col-md-5 col-lg-5">{{ sku.description }}
										<input type="hidden" ng-model="productData.productNumber[sku.productId]" name="productNumber[sku.productId]" ng-init="productData.productNumber[sku.productId] = sku.productId" />
										<input type="hidden" ng-model="productData.skuTypes[sku.productId]" name="skuTypes[sku.productId]" ng-init="productData.skuTypes[sku.productId] = sku.skuType" />
										<input type="hidden" ng-model="productData.skunumber[sku.productId]" name="skunumber[sku.productId]" ng-init="productData.skunumber[sku.productId] = sku.skuNumber" /></td>
										<td class="col-xs-2 col-md-2 col-lg-2">
										<input type="text" style="width:50px;" ng-hide="editorEnabled" ng-keyup="calculateNetWeight(productData.qty[sku.productId],sku.weight)" ng-model="productData.qty[sku.productId]" name="qty[sku.productId]" class="input-quantity" value="" />
										<span class="form-control-static" ng-show="editorEnabled">{{ productData.qty[sku.productId] }}</span>
										</td>
										<td class="col-xs-2 col-md-2 col-lg-2">{{sku.weight}}
										<input type="hidden" ng-model="productData.wgt[sku.productId]" name="wgt[sku.productId]" ng-init="productData.wgt[sku.productId] = sku.weight" />										
										</td>
										<td class="col-xs-2 col-md-2 col-lg-2">{{ +productData.qty[sku.productId] * sku.weight }}
										<!--{{ parseInt(productData.qty[sku.productId]) * sku.weight }}--></td>
									</tr>									
								</tbody>
							</table>
							<div ng-if="submitted && !skuqty && productForm.skuTypeDrop != '1'" class="invalid-feedback">Enter quantity for at least one SKU</div>
						</div>
					</div>
					
					<div class="row">	
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Height</label>
								<input type="text" placeholder="Enter Height" ng-hide="editorEnabled" class="form-control input-sm" ng-model="productData.height" name="height" value="" required />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.height }}</span>
								<div ng-if="submitted && productForm.height.$error.required" class="invalid-feedback">Please enter height</div>
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Weight in lbs</label>
								<input type="text" ng-model="productData.weight" ng-hide="editorEnabled" name="weight" placeholder="Enter Weight in lbs" class="form-control input-sm" required />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.weight }}</span>
								<div ng-if="submitted && productForm.weight.$error.required" class="invalid-feedback">Please enter weight</div>
							</div>
						</div>				
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Quantity</label>
								<input type="text" placeholder="Enter Quantity" ng-hide="editorEnabled" readonly ng-init="productData.quantity = 1" ng-model="productData.quantity" name="quantity" class="form-control input-sm" value="" required />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.quantity }}</span>
								<div ng-if="submitted && productForm.quantity.$error.required" class="invalid-feedback">Please enter serial number</div>
							</div>
						</div>
						
					</div>
					
					<div class="row">	
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Sequence</label>
								<input type="text" placeholder="Enter Sequence" ng-hide="editorEnabled" ng-model="productData.sequence" name="sequence" class="form-control input-sm" value="" required />
								<span class="form-control-static" ng-show="editorEnabled"> : {{ productData.sequence }}</span>
								<div ng-if="submitted && productForm.sequence.$error.required" class="invalid-feedback">Please enter sequence number</div>
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Show on Inventory Movement Page &nbsp;&nbsp;
								<span class="form-control-static" ng-show="editorEnabled"> : <span ng-if="productData.showInInventory">Yes</span><span ng-if="!productData.showInInventory">No</span></span>
								<br/><br/><input type="checkbox" ng-hide="editorEnabled" class="minimal" name="showInInventory" ng-model="productData.showInInventory"  /></label>
								
							</div>
						</div>
						
						<div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
							<div class="form-group">
								<label>Is Serialized ?&nbsp;&nbsp;
								<span class="form-control-static" ng-show="editorEnabled"> : <span ng-if="productData.isSerialized">Yes</span><span ng-if="!productData.isSerialized">No</span></span>
								<br/><br/><input type="checkbox" ng-hide="editorEnabled" class="minimal" name="isSerialized" ng-model="productData.isSerialized"  /></label>
								
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
							<div class="form-group">
								<label>
									<input type="button" class="btn btn-primary" ng-hide="editorEnabled" ng-click="productSummary()" value="Continue" />
									<input type="submit" class="btn btn-primary" ng-show="editorEnabled" value="Submit" />
									<input type="button" class="btn btn-info" ng-show="editorEnabled" ng-click="showProductForm()" value="Edit" />
								</label>
								<label>
									<input type="reset" class="btn btn-danger" value="Cancel" />
								</label>
							</div>
						</div>
					</div>
					
				</div>
			</div>	
			
			
			
        </div>
		</form>
    </div>
    	
    </section>
    <!-- /.content -->

	<div id="myAccount" class="modal fade" role="dialog">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title"><b>Accoount Details</b></h4>
			</div>
			<div class="modal-body">
				<div class="col-lg-12">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label><strong>Account Type:</strong> {{ accountDetailsModal.accountTypeDetails.accountType }}</label>
							</div>
						</div>										
						<div class="col-md-4">
							<div class="form-group">
								<label><strong>Reference Code:</strong> {{ accountDetailsModal.referenceCode }}</label>
							</div>
						</div>					
						<div class="col-md-4">
							<div class="form-group">
								<label><strong>Company Name:</strong> {{ accountDetailsModal.companyName }}</label>
							</div>
						</div>						
					</div>									
					<div class="row">														
						<div class="col-md-4">
							<div class="form-group">
								<label><strong>Account Nickname:</strong> {{ accountDetailsModal.nickName }}</label>
							</div>
						</div>		
						<div class="col-md-4">
							<div class="form-group">
								<label><strong>Address 1:</strong> {{ accountDetailsModal.addressLine1 }}</label>
							</div>
						</div>									
						<div class="col-md-4">
							<div class="form-group">
								<label><strong>Address 2:</strong> {{ accountDetailsModal.addressLine2 }}</label>
							</div>
						</div>	
					</div>
					
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label><strong>City:</strong> {{ accountDetailsModal.cityDetails.cityName }}</label>
							</div>
						</div>
															
						<div class="col-md-4">
							<div class="form-group">
								<label><strong>State:</strong> {{ accountDetailsModal.stateDetails.stateName }}</label>
							</div>
						</div>
						
						<div class="col-md-4">
							<div class="form-group">
								<label><strong>Country:</strong> {{ accountDetailsModal.countryDetails.countryName }}</label>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label><strong>Zip Code:</strong> {{ accountDetailsModal.zipCode }}</label>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label><strong>Business Phone:</strong> +1 {{ accountDetailsModal.businessPhone }}</label>
							</div>						
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label><strong>Fax:</strong> +1 {{ accountDetailsModal.fax }}</label>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label><strong>Email:</strong> {{ accountDetailsModal.contactEmail }}</label>
							</div>
						</div>										
						<div class="col-md-4">
							<div class="form-group">
								<label><strong>Contact Name:</strong> {{ accountDetailsModal.contactName }}</label>
							</div>
						</div>						
						<div class="col-md-4">
							<div class="form-group">
								<label><strong>Contact Phone:</strong> +1 {{ accountDetailsModal.contactPhone }}</label>
							</div>
						</div>												
					</div>
					
					<div class="row">				
						<div class="col-md-6" id="time-range">
							<table id="example1" class="table table-bordered table-striped ">
								<thead>
									<tr>
										<th align="center">&nbsp;</th>
										<th align="center" colspan="2">Operational hours</th>
									</tr>
									<tr>
										<th align="center">Open Days</th>
										<th align="center">From Time</th>
										<th align="center">To Time</th>
									</tr>
								</thead>
								<tbody>
									<tr ng-repeat="opr in accountDetailsModal.operationalHours">												
										<td>{{opr.day}}</td>
										<td>{{ opr.startTime | formatTime}}</td>
										<td>{{ opr.endTime | formatTime}}</td>
									</tr>									
								</tbody>
							</table>
						</div>
					</div>
					
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
</div>
  
  <script src="<?php echo base_url(); ?>asset/angular/controllers/products/createProductCtrl.js"></script>