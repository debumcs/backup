 <div class="content-wrapper" ng-controller="createOrderCtrl">
  <!-- Content Wrapper. Contains page content -->

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>{{pageTitle}}</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Order Management</a></li>
        <li class="active">Create Order</li>
      </ol>
    </section>
    
    <section class="content form-page">
	<form autocomplete="off" ng-submit="createOrder()" name="orderDataForm" >
		<div class="box">
		<div class="box-body">
			<div class="padleftright20">
				<div class="accordion-option">
					<!-- <h3 class="title">Lorem Ipsum</h3> -->
					<!--a href="edit_savedorder.html" class="btn btn-primary">Edit</a-->
					<a href="javascript:void(0)" class="toggle-accordion active" accordion-id="#accordion"></a>
				</div>
				<div class="clearfix"></div>
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
								Bill To
								</a>
							</h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
							<div class="panel-body">
								<div class="row ">
									<div class="col-md-12 col-lg-12 col-sm-12">
										<div class="row ">
											<div class="col-md-12 col-lg-12 col-sm-12">
												<div class="row">
										<div class="col-md-3">
											<div class="form-group">
												<label>Order Type</label>
												<select class="form-control input-md" width="100%" ng-init='orderData.orderType=""' ng-model="orderData.orderType" name="orderType">
													<option value="" >Select Order Type</option>
													<option ng-repeat="type in orderTypes" value="{{type.id}}">{{type.typeDesc}}</option>
												</select>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label>Account Type</label>
												<select class="form-control input-md" width="100%" ng-change="getAllAccounts()" ng-init='orderData.accountType=""' ng-model="orderData.accountType" name="accountType">
													<option value="" >Select Account Type</option>
													<option  ng-repeat="accountType in accountTypes" value="{{accountType.id}}">{{accountType.accountType}}</option>
												</select>
											</div>
										</div>
										
										<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
											<div class="form-group">
												<label>Status</label>
												<select class="form-control input-md" width="100%" ng-change="getAllAccounts()" ng-model="orderData.accountStatus" id="accountStatus" name="accountStatus">
												<option value="" selected>Select Status</option>
												<option ng-repeat="accountStatus in allAccountStatus" value="{{accountStatus.id}}">{{accountStatus.statusDesc}}</option>
												</select>
											</div>
										</div>
										
										<div class="col-md-3">
											<div class="form-group">
												<label>&nbsp;<br/></label>
												<div class="input-group">
													<button class="btn btn-success" type="button" ng-click="cust_search_fields()">Advanced Search</button>
												</div>
											</div>
										</div>					
									</div>
									
									<div class="row" ng-show="IsCustSearchFieldsVisible">
										<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
											<div class="form-group">
												<label>Account#</label>
												<input type="text" ng-model="orderData.accountId" ng-keyup="getAllAccounts()" id="accountId" name="accountId" class="form-control input-sm" value="">
											</div>
										</div>
										<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
											<div class="form-group">
												<label>Account Name</label>
												<input type="text" ng-model="orderData.accountName" ng-keyup="getAllAccounts()" id="accountName" name="accountName" class="form-control input-sm" value="">
											</div>
										</div>
										<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
											<div class="form-group">
												<label>Account Ref #</label>
												<input type="text" ng-model="orderData.accountRef" ng-keyup="getAllAccounts()" id="accountRef" name="accountRef" class="form-control input-sm" value="">
											</div>
										</div>
										<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
											<div class="form-group">
												<label>Nickname</label>
												<input type="text" ng-model="orderData.accountNickName" ng-keyup="getAllAccounts()" id="accountNickName" name="accountNickName" class="form-control input-sm" value="">
											</div>
										</div>
										<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
											<div class="form-group">
												<label>City</label>
												<input type="text" ng-model="orderData.accountCity" ng-keyup="getAllAccounts()" id="accountCity" name="accountCity" class="form-control input-sm" value="">
											</div>
										</div>
										<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
											<div class="form-group">
												<label>State</label>
												<input type="text" ng-model="orderData.accountState" ng-keyup="getAllAccounts()" id="accountState" name="accountState" class="form-control input-sm" value="">
											</div>
										</div>										
									</div>
												
												<div class="row" ng-show="IsCustDataVisible">
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<table id="example1" class="table table-bordered table-striped ">
															<thead>
																<tr>
																	<th width="40" align="center">#</th>
																	<th>Account#</th>
																	<th>Account Name</th>
																	<th>Account Nickname</th>
																	<th>Account Ref #</th>
																	<th>Account Type</th>
																	<th>Address</th>
																	<th>City</th>
																	<th>State</th>
																	<th>Status</th>
																</tr>
															</thead>
															<tbody>
																
																<tr ng-repeat="account in allAccountList">
																	<td align="center"><input type="radio" ng-click="showbilltodetails(account.accountId)" ng-model="orderData.billto" name="billto" id="billto" value="{{account.accountId}}" /></td>
																	<td>{{account.accountId}}</td>
																	<td>{{account.companyName}}</td>
																	<td>{{account.nickName}}</td>
																	<td>{{account.referenceCode}}</td>
																	<td>{{account.accountTypeDetails.accountType}}</td>
																	<td>{{account.addressLine1}} {{account.addressLine2}}</td>
																	<td>{{account.cityDetails.cityName}}</td>
																	<td>{{account.stateDetails.stateName}}</td>
																	<td>{{account.accountStatusDetails.statusDesc}}</td>
																</tr>
																
															</tbody>
														</table>
													</div>
												</div>
												
												<div class="row" ng-show="IsBillDetailsVisible">
													<div class="col-md-12 col-lg-12">
														<h4><b>Bill To<br/><br/></b></h4>
													</div>
													
													<div class="col-md-12 col-lg-12">
														<div class="row">
															<div class="col-md-4">
																<div class="form-group">
																	<label><b>Account#</b></label> : {{billDetails.accountId}}
																</div>
															</div>					
																	
															<div class="col-md-4">
																<div class="form-group">
																	<label><b>Account Name</b></label> : {{billDetails.companyName}}
																</div>
															</div>
															
															<div class="col-md-4">
																<div class="form-group">
																	<label><b>Address</b></label> : <span>{{billDetails.addressLine1}} {{billDetails.addressLine2}} {{billDetails.cityDetails.cityName}}</span>
																	<input type="hidden" ng-model="orderData.billToLocation" />
																</div>
															</div>
															
														</div>
													</div>
													
													<div class="col-md-12 col-lg-12">
														<div class="row">
															
															
															<div class="col-md-4">
																<div class="form-group">
																	<label><b>Business Phone</b></label> : +1 {{billDetails.businessPhone}}
																</div>
															</div>
															<div class="col-md-4">
																<div class="form-group">
																	<label><b>Email</b></label> : {{billDetails.contactEmail}}
																</div>
															</div>
														</div>
													</div>
													
												</div>
												
											</div>
										</div>	
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingTwo">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
								Ship From
								</a>
							</h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
							<div class="panel-body">
								<div class="row">
									<div class="col-md-2">
										<div class="form-group">
											<label>Location Type</label>
											<select class="form-control input-md" width="100%" ng-change="getLocationList()" ng-init='orderData.locationType=""' ng-model="orderData.locationType" name="locationType">
												<option value="" >Select Location Type</option>
												<option ng-repeat="loc in locationTypes" value="{{loc.id}}">{{loc.locationType}}</option>
											</select>
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
										<div class="form-group">
											<label>Location #</label>
											<div class="input-group">
												<input type="text" class="form-control pull-right" ng-keyup="getLocationList()" ng-model="orderData.locationid" name="locationid">
											</div>
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
										<div class="form-group">
											<label>Customer </label>
											<div class="input-group">
												<input type="text" class="form-control pull-right" ng-keyup="getLocationList()" ng-model="orderData.locname" name="locname">
											</div>
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
										<div class="form-group">
											<label>Status </label>
											<div class="input-group">
												<select class="form-control" ng-change="getLocationList()" ng-model="orderData.locStatus" name="locStatus">
												<option value="" >Select Status</option>
												<option ng-repeat="loc in locationTypes" value="{{loc.id}}">{{loc.locationType}}</option>
												</select>
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label>&nbsp;<br/></label>
											<div class="input-group">
												<button class="btn btn-success" type="button" ng-click="customLocField()">Advanced Search</button>
											</div>
										</div>
									</div>
								</div>
								
								<div class="row" ng-show="IsCustomLocFields">
									<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
										<div class="form-group">
											<label>Customer Ref #</label>
											<input type="text" ng-model="orderData.locRef" name="locRef" ng-keyup="getLocationList()" class="form-control input-sm" value="">
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
										<div class="form-group">
											<label>Unit #</label>
											<input type="text" ng-model="orderData.unit" name="unit" ng-keyup="getLocationList()" class="form-control input-sm" value="">
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
										<div class="form-group">
											<label>Customer Nickname</label>
											<input type="text" ng-model="orderData.locNickName" name="locNickName" ng-keyup="getLocationList()" class="form-control input-sm" value="">
										</div>
									</div>
									
									<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
										<div class="form-group">
											<label>City</label>
											<input type="text" ng-model="orderData.locCity" name="locCity" ng-keyup="getLocationList()" class="form-control input-sm" value="">
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
										<div class="form-group">
											<label>State</label>
											<input type="text" ng-model="orderData.locState" name="locState" ng-keyup="getLocationList()" class="form-control input-sm" value="">
										</div>
									</div>
									
								</div>
								
								<div class="row" ng-show="IsLocationDataVisible">
									<div class="col-lg-12">
										<table id="datatable" class="table table-bordered table-striped dataTable">
											<thead>
												<tr>
													<th>&nbsp;</th>
													<th>Location#</th>
													<th>Location Type</th>
													<th>Customer Ref #</th>
													<th>Customer</th>
													<th>Unit #</th>
													<th>Customer Nickname</th>
													<th>Address</th>
													<th>City</th>
													<th>State</th>
													<th>Status</th>
												</tr>
											</thead>
											<tbody>
												<tr ng-repeat="location in allLocationList">
													<td align="center"><input type="radio" ng-click="shippingDetails(location.locationId);" ng-model="orderData.locationId" name="locationId" value="{{location.locationId}}" /></td>
													<td>{{location.locationId}}</td>
													<td>{{location.locationTypeDetails.locationType}}</td>
													<td>{{location.referenceCode}}</td>
													<td>{{location.locationName}}</td>
													<td>{{location.unitNumber}}</td>
													<td>{{location.nickName}}</td>
													<td>{{location.addressLine1}} {{location.addressLine1}}</td>
													<td>{{location.cityDetails.cityName}}</td>
													<td>{{location.stateDetails.stateName}}</td>
													<td>{{location.statusDetails.statusDesc}}</td>
												</tr>												
											</tbody>
										</table>
									</div>
								</div>
								
									<div class="row" ng-show="shiptodetails">
										<div class="col-md-12 col-lg-12">
											<h4><b>Ship From<br/><br/></b></h4>
										</div>
										
										<div class="col-md-12 col-lg-12">
											<div class="row">
												<div class="col-md-4">
													<div class="form-group">
														<label><b>Location#</b></label> : {{shipDetails.locationId}}
													</div>
												</div>					
														
												<div class="col-md-4">
													<div class="form-group">
														<label><b>Customer </b></label> : {{shipDetails.locationName}}
													</div>
												</div>
												
												<div class="col-md-4">
													<div class="form-group">
														<label><b>Address</b></label> : {{shipDetails.addressLine1}} {{shipDetails.addressLine2}}
														<input type="hidden" ng-model="orderData.shipToLocation" />
													</div>
												</div>
												
											</div>
										</div>
										
										<div class="col-md-12 col-lg-12">
											<div class="row">
												<div class="col-md-4">
													<div class="form-group">
														<label><b>Business Phone </b></label> : +1 {{shipDetails.locationId}}
													</div>
												</div>
												
												<div class="col-md-4">
													<div class="form-group">
														<label><b>Email</b></label> : {{shipDetails.locationId}}
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					
					
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingThree">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
								Order
								</a>
							</h4>
						</div>
						<div id="collapseThree" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingThree">
							<div class="panel-body">
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label>PO Number</label>
										<input type="text" ng-model="orderData.poNumber" name="poNumber" class="form-control" placeholder="Enter PO Number">
									</div>
								</div>	
								
								<div class="col-md-6">
									<div class="form-group">
										<label>Reference Number 1</label>
										<input type="text" ng-model="orderData.refNumber1" name="refNumber1" class="form-control" placeholder="Enter Reference Number 1 ">
									</div>
								</div>
							</div>
							
							<div class="row">
								<div class="col-md-6">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label>Pick up Due Date</label>
												<div class="input-group date">
													<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
													<input type="text" ng-model="orderData.pickUpDueDate" class="form-control pull-right" id="mainDdatePicker" />
													<!--<input type="text" ng-model="orderData.pickUpDueDate" name="pickUpDueDate" id="angDdatePicker" />-->
												</div>
 
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Requested Pickup Date</label>
												<div class="input-group date">
													<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
													<input type="date" ng-model="orderData.requestedPickupDate" name="requestedPickupDate" class="form-control pull-right" />
												</div>
											</div>
										</div>										
									</div>
								</div>	
								
								<div class="col-md-6">
									<div class="form-group">
										<label>Reference Number 2</label>
										<input type="text" ng-model="orderData.refNumber2" name="refNumber2" class="form-control" placeholder="Enter Reference Number 2">
									</div>
								</div>
							</div>
						
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label>Requested Pick up Time</label>
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<div class="input-group">
														<select class="form-control pull-right" ng-model="orderData.requestedPickUpTime1" name="requestedPickUpTime1">
															<option value="" selected>Select</option>
															<option value="Morning">Morning</option>
															<option value="Afternoon">Afternoon</option>
														</select>
													</div>
												</div>
											</div>
											<div class="col-md-2">
												<div class="form-group" style="padding-top:10px;">
													<label>OR</label>
												</div>
											</div>
											<div class="col-md-6">
												<div class="bootstrap-timepicker">
													<div class="form-group">
													  <div class="input-group">
														<input type="time" class="form-control" ng-model="orderData.requestedPickUpTime2" name="requestedPickUpTime2" id="timepicker2">
													  </div>
													  <!-- /.input group -->
													</div>
													<!-- /.form group -->
												  </div>
											</div>										
										</div>
									</div>
								</div>
								
								<div class="col-md-6">
									<div class="form-group">
										<label>Special Instructions</label>
										<input type="text" ng-model="orderData.instructions" name="instructions" class="form-control" placeholder="Enter Special Instructions">
									</div>
								</div>
								
							</div>	

						</div>
					</div>					
				</div>
				
				
				<div class="panel panel-default">
					<div class="panel-heading" role="tab" id="headingFour">
						<h4 class="panel-title">
							<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
							Order Details
							</a>
						</h4>
					</div>
					<div id="collapseFour" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingFour">
						<div class="panel-body">
							<div class="row">
								
								<div class="col-lg-6 col-md-12">
									<div class="col-md-12 col-lg-12">
										<div class="row"><h5><b>Pickup</b></h5></div>
									</div>
									<table class="display table table-bordered table-striped dataTable no-footer" width="100%">
										<thead>
											<tr>
												<th width="75">SKU</th>
												<th width="195">Description</th>
												<th width="120">Quantity</th>
											</tr>
										</thead>
										<tbody>
											<tr ng-repeat="pro in billDetails.products">
												<td width="30">{{ pro.skuNumber }}</td>
												<td width="170">{{ pro.description }}</td>
												<td width="120">
												<input type="text" class="form-control" ng-model="orderData.qty[pro.skuNumber]" value="" style="width:100px;" />
												</td>
											</tr>
										</tbody>
									</table>
								</div>
								
							</div>
						</div>
					</div>					
				</div>
				
				</div>
				
				<div class="row">
					<div class="col-md-12 col-lg-12">
						&nbsp;
					</div>
				</div>
				
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>
								<input type="submit" class="btn btn-primary" value="Continue" />
							</label>
							<label>
								<input type="reset" class="btn btn-danger" value="Cancel" />
							</label>
						</div>
					</div>
				</div>
				
				<div class="row">
					<div class="col-md-12" ng-show="errorMsg.length>0">
						{{errorMsg}}
					</div>
				</div>
				
			</div>
		</div>
		</div>
		</form>
    </section>




    <!-- /.content -->
  </div>
 <script src="<?php echo base_url(); ?>asset/angular/controllers/orders/createOrderCtrl.js"></script>