<div class="content-wrapper" ng-controller="createOrderCtrl">
  <!-- Content Wrapper. Contains page content -->

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>{{pageTitle}}</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Order Management</a></li>
        <li class="active">Create Order</li>
      </ol>
    </section>
    
    <section class="content form-page">
	<form autocomplete="off" name="orderDataForm" ng-submit="createOrder()" >
		<div class="box">
		<div class="box-body">
			<div class="padleftright20">
				<div class="accordion-option">
					<!-- <h3 class="title">Lorem Ipsum</h3> -->
					<!--a href="edit_savedorder.html" class="btn btn-primary">Edit</a-->
					<a href="javascript:void(0)" class="toggle-accordion active" accordion-id="#accordion"></a>
				</div>
				<div class="clearfix"></div>
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
								Bill To
								</a>
							</h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
							<div class="panel-body">
								<div class="row ">
									<div class="col-md-12 col-lg-12 col-sm-12">
										<div class="row ">
											<div class="col-md-12 col-lg-12 col-sm-12">
												<div class="row" ng-hide="editorEnabled">
													<div class="col-md-3">
														<div class="form-group">
															<label>Order Type</label>
															<select class="form-control input-md" width="100%" ng-init='orderData.orderType=""' ng-model="orderData.orderType" name="orderType" id="orderType" required>
																<option value="" >Select Order Type</option>
																<option ng-repeat="type in orderTypes" value="{{type.id}}">{{type.typeDesc}}</option>
															</select>
															<div ng-if="(orderDataForm.orderType.$dirty && orderDataForm.orderType.$error.required) || (submitted && orderDataForm.orderType.$error.required)" class="invalid-feedback">Order Type is required</div>
														</div>
													</div>
													<div class="col-md-3">
														<div class="form-group">
															<label>Account Type</label>
															<select class="form-control input-md" width="100%" ng-change="getAllAccounts()" ng-init='orderData.accountType=""' ng-model="orderData.accountType" name="accountType">
																<option value="" >Select Account Type</option>
																<option  ng-repeat="accountType in accountTypes" value="{{accountType.id}}">{{accountType.accountType}}</option>
															</select>
														</div>
													</div>
										
													<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
														<div class="form-group">
															<label>Status</label>
															<select class="form-control input-md" width="100%" ng-change="getAllAccounts()" ng-model="orderData.accountStatus" id="accountStatus" name="accountStatus">
															<option value="" selected>Select Status</option>
															<option ng-repeat="accountStatus in allAccountStatus" value="{{accountStatus.id}}">{{accountStatus.statusDesc}}</option>
															</select>
														</div>
													</div>
										
													<div class="col-md-3">
														<div class="form-group">
															<label>&nbsp;<br/></label>
															<div class="input-group">
																<button class="btn btn-success" type="button" ng-click="cust_search_fields()">Advanced Search</button>
															</div>
														</div>
													</div>					
												</div>
									
												<div class="row" ng-show="IsCustSearchFieldsVisible">
													<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
														<div class="form-group">
															<label>Account#</label>
															<input type="text" ng-model="orderData.accountId" ng-keyup="getAllAccounts()" id="accountId" name="accountId" class="form-control input-sm" value="">
														</div>
													</div>
													<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
														<div class="form-group">
															<label>Account Name</label>
															<input type="text" ng-model="orderData.accountName" ng-keyup="getAllAccounts()" id="accountName" name="accountName" class="form-control input-sm" value="">
														</div>
													</div>
													<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
														<div class="form-group">
															<label>Account Ref #</label>
															<input type="text" ng-model="orderData.accountRef" ng-keyup="getAllAccounts()" id="accountRef" name="accountRef" class="form-control input-sm" value="">
														</div>
													</div>
													<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
														<div class="form-group">
															<label>Nickname</label>
															<input type="text" ng-model="orderData.accountNickName" ng-keyup="getAllAccounts()" id="accountNickName" name="accountNickName" class="form-control input-sm" value="">
														</div>
													</div>
													<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
														<div class="form-group">
															<label>City</label>
															<input type="text" ng-model="orderData.accountCity" ng-keyup="getAllAccounts()" id="accountCity" name="accountCity" class="form-control input-sm" value="">
														</div>
													</div>
													<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
														<div class="form-group">
															<label>State</label>
															<input type="text" ng-model="orderData.accountState" ng-keyup="getAllAccounts()" id="accountState" name="accountState" class="form-control input-sm" value="">
														</div>
													</div>										
												</div>
												
												<div class="row" ng-show="IsCustDataVisible">
													<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
														<table datatable="ng" dt-options="accountOptions" class="table table-striped table-bordered">
															<thead>
																<tr>
																	<th width="40" align="center">#</th>
																	<th>Account#</th>
																	<th>Account Name</th>
																	<th>Account Nickname</th>
																	<th>Account Ref #</th>
																	<th>Account Type</th>
																	<th>Address</th>
																	<th>City</th>
																	<th>State</th>
																	<th>Status</th>
																</tr>
															</thead>
															<tbody>
																
																<tr ng-repeat="account in allAccountList">
																	<td align="center"><input type="radio" ng-click="showbilltodetails(account.accountId)" ng-model="orderData.billto" ng-disabled="account.accountStatus == 2" name="billto" id="billto" value="{{account.accountId}}" /></td>
																	<td>{{account.accountId}}</td>
																	<td>{{account.companyName}}</td>
																	<td>{{account.nickName}}</td>
																	<td>{{account.referenceCode}}</td>
																	<td>{{account.accountTypeDetails.accountType}}</td>
																	<td>{{account.addressLine1}} {{account.addressLine2}}</td>
																	<td>{{account.cityDetails.cityName}}</td>
																	<td>{{account.stateDetails.stateName}}</td>
																	<td>{{account.accountStatusDetails.statusDesc}}</td>
																</tr>
																
															</tbody>
														</table>
													</div>
												</div>
												
												<div class="row" ng-show="IsBillDetailsVisible">
													<div class="col-md-12 col-lg-12" ng-hide="editorEnabled">
														<h4><b>Bill To<br/><br/></b></h4>
													</div>
													
													<div class="col-md-12 col-lg-12">
														<div class="row">
															<div class="col-md-4">
																<div class="form-group">
																	<label><b>Account#</b></label> : {{billDetails.accountId}}
																</div>
															</div>					
																	
															<div class="col-md-4">
																<div class="form-group">
																	<label><b>Account Name</b></label> : {{billDetails.companyName}}
																</div>
															</div>
															
															<div class="col-md-4">
																<div class="form-group">
																	<label><b>Address</b></label> : <span>{{billDetails.addressLine1}} {{billDetails.addressLine2}} {{billDetails.cityDetails.cityName}}</span>
																	<input type="hidden" ng-model="orderData.billToLocation" name="billToLocation" required />
																</div>
															</div>
															
														</div>
													</div>
													
													<div class="col-md-12 col-lg-12">
														<div class="row">
															
															
															<div class="col-md-4">
																<div class="form-group">
																	<label><b>Business Phone</b></label> : +1 {{billDetails.businessPhone}}
																</div>
															</div>
															<div class="col-md-4">
																<div class="form-group">
																	<label><b>Email</b></label> : {{billDetails.contactEmail}}
																</div>
															</div>
														</div>
													</div>
													
												</div>
												
												<div ng-if="submitted && orderDataForm.billToLocation.$error.required && !orderDataForm.orderType.$error.required" class="invalid-feedback">Bill to location is required</div>
												
												
											</div>
										</div>	
									</div>
								</div>
								
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingTwo">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
								Ship From
								</a>
							</h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
							<div class="panel-body">
								<div class="row" ng-hide="editorEnabled">
									<div class="col-md-2">
										<div class="form-group">
											<label>Location Type</label>
											<select class="form-control input-md" width="100%" ng-change="getLocationList()" ng-init='orderData.locationType=""' ng-model="orderData.locationType" name="locationType">
												<option value="" >Select Location Type</option>
												<option ng-repeat="loc in locationTypes" value="{{loc.id}}">{{loc.locationType}}</option>
											</select>
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
										<div class="form-group">
											<label>Location #</label>
											<div class="input-group">
												<input type="text" class="form-control pull-right" ng-keyup="getLocationList()" ng-model="orderData.locationid" name="locationid">
											</div>
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
										<div class="form-group">
											<label>Customer </label>
											<div class="input-group">
												<input type="text" class="form-control pull-right" ng-keyup="getLocationList()" ng-model="orderData.locname" name="locname">
											</div>
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-4 col-xs-4">
										<div class="form-group">
											<label>Status </label>
											<div class="input-group">
												<select class="form-control" ng-change="getLocationList()" ng-model="orderData.locStatus" name="locStatus">
												<option value="" >Select Status</option>
												<option ng-repeat="loc in allLocationStatus" value="{{loc.id}}">{{loc.statusDesc}}</option>
												</select>
											</div>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label>&nbsp;<br/></label>
											<div class="input-group">
												<button class="btn btn-success" type="button" ng-click="customLocField()">Advanced Search</button>
											</div>
										</div>
									</div>
								</div>
								
								<div class="row" ng-show="IsCustomLocFields">
									<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
										<div class="form-group">
											<label>Customer Ref #</label>
											<input type="text" ng-model="orderData.locRef" name="locRef" ng-keyup="getLocationList()" class="form-control input-sm" value="">
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
										<div class="form-group">
											<label>Unit #</label>
											<input type="text" ng-model="orderData.unit" name="unit" ng-keyup="getLocationList()" class="form-control input-sm" value="">
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
										<div class="form-group">
											<label>Customer Nickname</label>
											<input type="text" ng-model="orderData.locNickName" name="locNickName" ng-keyup="getLocationList()" class="form-control input-sm" value="">
										</div>
									</div>
									
									<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
										<div class="form-group">
											<label>City</label>
											<input type="text" ng-model="orderData.locCity" name="locCity" ng-keyup="getLocationList()" class="form-control input-sm" value="">
										</div>
									</div>
									<div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
										<div class="form-group">
											<label>State</label>
											<input type="text" ng-model="orderData.locState" name="locState" ng-keyup="getLocationList()" class="form-control input-sm" value="">
										</div>
									</div>
									
								</div>
								
								<div class="row" ng-show="IsLocationDataVisible">
									<div class="col-lg-12">
										<table datatable="ng" dt-options="locationOptions" class="table table-striped table-bordered">
											<thead>
												<tr>
													<th>&nbsp;</th>
													<th>Location#</th>
													<th>Location Type</th>
													<th>Customer Ref #</th>
													<th>Customer</th>
													<th>Unit #</th>
													<th>Customer Nickname</th>
													<th>Address</th>
													<th>City</th>
													<th>State</th>
													<th>Status</th>
												</tr>
											</thead>
											<tbody>
												<tr ng-repeat="location in allLocationList">
													<td align="center"><input type="radio" ng-click="shippingDetails(location.locationId);" ng-model="orderData.locationId" name="locationId" value="{{location.locationId}}" /></td>
													<td>{{location.locationId}}</td>
													<td>{{location.locationTypeDetails.locationType}}</td>
													<td>{{location.referenceCode}}</td>
													<td>{{location.locationName}}</td>
													<td>{{location.unitNumber}}</td>
													<td>{{location.nickName}}</td>
													<td>{{location.addressLine1}} {{location.addressLine1}}</td>
													<td>{{location.cityDetails.cityName}}</td>
													<td>{{location.stateDetails.stateName}}</td>
													<td>{{location.statusDetails.statusDesc}}</td>
												</tr>												
											</tbody>
										</table>
									</div>
								</div>
								
									<div class="row" ng-show="shiptodetails">
										<div class="col-md-12 col-lg-12" ng-hide="editorEnabled">
											<h4><b>Ship From<br/><br/></b></h4>
										</div>
										
										<div class="col-md-12 col-lg-12">
											<div class="row">
												<div class="col-md-4">
													<div class="form-group">
														<label><b>Location#</b></label> : {{shipDetails.locationId}}
													</div>
												</div>					
														
												<div class="col-md-4">
													<div class="form-group">
														<label><b>Customer </b></label> : {{shipDetails.locationName}}
													</div>
												</div>
												
												<div class="col-md-4">
													<div class="form-group">
														<label><b>Address</b></label> : {{shipDetails.addressLine1}} {{shipDetails.addressLine2}}
														<input type="hidden" ng-model="orderData.shipToLocation" name="shipToLocation" required />
													</div>
												</div>
												
											</div>
										</div>
										
										<div class="col-md-12 col-lg-12">
											<div class="row">
												<div class="col-md-4">
													<div class="form-group">
														<label><b>Business Phone </b></label> : +1 {{shipDetails.businessPhone}}
													</div>
												</div>
												
												<div class="col-md-4">
													<div class="form-group">
														<label><b>Email</b></label> : {{shipDetails.contactEmail}}
													</div>
												</div>
											</div>
										</div>
									</div>
								
								<div ng-if="submitted && orderDataForm.shipToLocation.$error.required && !orderDataForm.orderType.$error.required" class="invalid-feedback">Ship from location is required</div>
								</div>
							</div>
						</div>
					
					
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingThree">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
								Order
								</a>
							</h4>
						</div>
						<div id="collapseThree" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingThree">
							<div class="panel-body">
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label>PO Number</label>
										<input type="text" ng-model="orderData.poNumber" ng-hide="editorEnabled" name="poNumber" class="form-control" placeholder="Enter PO Number" required />
										<span class="form-control-static" ng-show="editorEnabled"> : {{ orderData.poNumber }}</span>
										<div ng-if="submitted && orderDataForm.poNumber.$error.required" class="invalid-feedback">PO Number is required</div>
									</div>
								</div>	
								
								<div class="col-md-6">
									<div class="form-group">
										<label>Reference Number 1</label>
										<input type="text" ng-model="orderData.refNumber1" ng-hide="editorEnabled" name="refNumber1" class="form-control" placeholder="Enter Reference Number 1 " required />
										<span class="form-control-static" ng-show="editorEnabled"> : {{ orderData.refNumber1 }}</span>
										<div ng-if="submitted && orderDataForm.refNumber1.$error.required" class="invalid-feedback">Reference number is required</div>
									</div>
								</div>
							</div>
							
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label>Pick up Due Date</label>
										<span class="form-control-static" ng-show="editorEnabled"> : {{ orderData.pickUpDueDate | date:'MM/dd/yyyy' }}</span>
										<div class="input-group date" ng-hide="editorEnabled">
											<datepicker  date-format="MM/dd/yyyy">
											<input type="text" ng-model="orderData.pickUpDueDate" name="pickUpDueDate" placeholder="Click here to select date" class="form-control" required />
											</datepicker>
										</div>
										<div ng-if="submitted && orderDataForm.pickUpDueDate.$error.required" class="invalid-feedback">Pick up due date is required</div>
									</div>
								</div>	
								
								<div class="col-md-6">
									<div class="form-group">
										<label>Reference Number 2</label>
										<input type="text" ng-model="orderData.refNumber2" ng-hide="editorEnabled" name="refNumber2" class="form-control" placeholder="Enter Reference Number 2">
										<span class="form-control-static" ng-show="editorEnabled"> : {{ orderData.refNumber2 }}</span>
									</div>
								</div>
							</div>
							
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label>Requested Pickup Date</label>
										<span class="form-control-static" ng-show="editorEnabled"> : {{ orderData.requestedPickupDate | date:'MM/dd/yyyy' }}</span>
										<div class="input-group date" ng-hide="editorEnabled">
											<datepicker  date-format="MM/dd/yyyy">
											<input type="text" ng-model="orderData.requestedPickupDate" placeholder="Click here to select date" name="requestedPickupDate" class="form-control" required />
											</datepicker>
										</div>
										<div ng-if="submitted && orderDataForm.requestedPickupDate.$error.required" class="invalid-feedback">Requested pick up date is required</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label>Requested Pick up Time</label>
										<span class="form-control-static" ng-show="editorEnabled"> : 
										<span ng-if="orderData.requestedPickUpTime1 != ''">{{ orderData.requestedPickUpTime1 }}</span>
										<span ng-if="orderData.requestedPickUpTime2 != ''">{{ orderData.requestedPickUpTime2 | date: "hh:mm a" }}</span>
										</span>
										
										<div class="row" ng-hide="editorEnabled">
											<div class="col-md-4">
												<div class="form-group">
													<div class="input-group">
														<select class="form-control pull-right" ng-change="setTimePicker()" ng-model="orderData.requestedPickUpTime1" name="requestedPickUpTime1" >
															<option value="" selected>Select</option>
															<option value="Morning">Morning</option>
															<option value="Afternoon">Afternoon</option>
														</select>
													</div>
												</div>
											</div>
											<div class="col-md-2">
												<div class="form-group" style="padding-top:10px;">
													<label>OR</label>
												</div>
											</div>
											<div class="col-md-6">
												<div class="bootstrap-timepicker">
													<div class="form-group">
													  <div class="input-group">
														<input type="time" class="form-control" ng-keyup="setTimePickerDropDown()" ng-model="orderData.requestedPickUpTime2" name="requestedPickUpTime2" id="timepicker2"  />
													  </div>
													  <!-- /.input group -->
													</div>
													<!-- /.form group -->
													<datepicker  date-format="h:mm a">
													<input type="text" ng-model="orderData.pickUpDueDate222" name="pickUpDueDate222" placeholder="Click here to select date" class="form-control" required />
													</datepicker>
												  </div>
											</div>										
										</div>
										<div ng-if="(submitted && orderDataForm.requestedPickUpTime2.$error.required) || (submitted && orderDataForm.requestedPickUpTime1.$error.required)" class="invalid-feedback">Pick up time is required</div>
									</div>
								</div>								
							</div>	
							
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label>Special Instructions</label>
										<input type="text" ng-model="orderData.instructions" ng-hide="editorEnabled" name="instructions" class="form-control" placeholder="Enter Special Instructions">
										<span class="form-control-static" ng-show="editorEnabled"> : {{ orderData.instructions }}</span>
									</div>
								</div>										
							</div>

						</div>
					</div>					
				</div>
				
				
				<div class="panel panel-default">
					<div class="panel-heading" role="tab" id="headingFour">
						<h4 class="panel-title">
							<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
							Order Details
							</a>
						</h4>
					</div>
					<div id="collapseFour" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingFour">
						<div class="panel-body">
							<div class="row">
								
								<div class="col-lg-6 col-md-12">
									<div class="col-md-12 col-lg-12">
										<div class="row"><h5><b>Pickup</b></h5></div>
									</div>
									<table class="table table-fixed" width="100%">
										<thead>
											<tr>
												<th class="col-xs-3 col-md-3 col-lg-3">SKU</th>
												<th class="col-xs-6 col-md-6 col-lg-6">Description</th>
												<th class="col-xs-3 col-md-3 col-lg-3">Quantity</th>
											</tr>
										</thead>
										<tbody ng-class="{tableheight: billDetails.products}">
											<tr ng-repeat="pro in billDetails.products" ng-hide="!orderData.qty[pro.skuNumber] && editorEnabled">
												<td class="col-xs-3 col-md-3 col-lg-3">{{ pro.skuNumber }}</td>
												<td class="col-xs-6 col-md-6 col-lg-6">{{ pro.description }}
												<input type="hidden" ng-init="orderData.description[pro.skuNumber] = pro.description" ng-model="orderData.description[pro.skuNumber]" />
												<input type="hidden" ng-init="orderData.skutypeord[pro.skuNumber] = pro.skuType" ng-model="orderData.skutypeord[pro.skuNumber]" />
												<input type="hidden" class="form-control" ng-hide="editorEnabled" ng-init="orderData.weight[pro.skuNumber] =pro.weight" ng-model="orderData.weight[pro.skuNumber]" />
												</td>
												<td class="col-xs-3 col-md-3 col-lg-3">
												<input type="text" class="input-quantity" ng-keyup="checkQuantity()" only-numbers ng-hide="editorEnabled" ng-model="orderData.qty[pro.skuNumber]" value="" style="width:100px;" />
												<span class="form-control-static" ng-show="editorEnabled">{{ orderData.qty[pro.skuNumber] }}</span>
												</td>
											</tr>											
										</tbody>
									</table>
									<div ng-if="submitted && !skuqty" class="invalid-feedback">Enter quantity for at least one SKU</div>
								</div>
								
							</div>
						</div>
					</div>					
				</div>
				
				</div>
				
				<div class="row">
					<div class="col-md-12 col-lg-12">
						&nbsp;
					</div>
				</div>
				
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>
								<input type="button" class="btn btn-primary" ng-hide="editorEnabled" ng-click="orderSummary()" value="Continue" />
								<input type="submit" class="btn btn-primary" ng-show="editorEnabled" value="Submit" />
								<input type="button" class="btn btn-info" ng-show="editorEnabled" ng-click="orderCreateForm()" value="Edit" />
							</label>
							<label>
								<input type="reset" class="btn btn-danger" value="Cancel" />
							</label>
						</div>
					</div>
				</div>
				
				<div class="row">
					<div class="col-md-12 invalid-feedback" ng-show="errorMsg.length>0">
						{{errorMsg}}
					</div>
				</div>
				
			</div>
		</div>
		</div>
		</form>
    </section>
    <!-- /.content -->
  </div>
 <script src="<?php echo base_url(); ?>asset/angular/controllers/orders/createOrderCtrl.js"></script>