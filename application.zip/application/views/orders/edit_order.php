 <div class="content-wrapper" ng-controller="editOrderCtrl" >
  <!-- Content Wrapper. Contains page content -->

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>{{pageTitle}}</h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Order Management</a></li>
        <li class="active">Create Order</li>
      </ol>
    </section>
    
    <section class="content form-page">
	<form autocomplete="off" ng-submit="updateOrder()" name="orderDataForm" >
		
		<div class="box">
		<div class="box-body">
			<div class="padleftright20">
				<div class="accordion-option">
					<!-- <h3 class="title">Lorem Ipsum</h3> -->
					<!--a href="edit_savedorder.html" class="btn btn-primary">Edit</a-->
					<a href="javascript:void(0)" class="toggle-accordion active" accordion-id="#accordion"></a>
				</div>
				<div class="clearfix"></div>
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
								Bill To
								</a>
							</h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
							<div class="panel-body">
								
								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<label><strong>Order#</strong> </label>
											<input type="hidden" id="orderNo" name="orderNo" value="<?php echo $orderno; ?>" />
											<input type="text" ng-model="orderData.orderNumber" class="form-control" readonly="true" id="orderNumber" name="orderNumber" />
											
										</div>
									</div>
									
									<div class="col-md-4">
										<div class="form-group">
											<label><strong>Order Type</strong></label>
											<input type="text" ng-model="orderData.orderTypeDetails" class="form-control" readonly="true" id="orderTypeDetails" name="orderTypeDetails" />
											<input type="hidden" ng-model="orderData.orderType" id="orderType" name="orderType" />
											<input type="hidden" ng-model="orderData.isRental" id="isRental" name="isRental" />
										</div>
									</div>
									
									<div class="col-md-4">
										<div class="form-group">
											<label><strong>Account Type</strong></label>
											<input type="text" ng-model="orderData.accountTypeDetails" class="form-control" readonly="true" id="accountTypeDetails" name="accountTypeDetails" />
										</div>
									</div>
									
								</div>
								<div class="row">
									<div class="col-lg-4">
										<div class="form-group">
											<label><strong>Account #</strong> </label>
											<input type="text" ng-model="orderData.accountId" class="form-control" readonly="true" id="accountId" name="accountId" />
										</div>
									</div>
									<div class="col-lg-4">
										<div class="form-group">
											<label><strong>Account Name</strong> </label>
											<input type="text" ng-model="orderData.companyName" class="form-control" readonly="true" id="companyName" name="companyName" />
										</div>
									</div>
									<div class="col-lg-4">
										<div class="form-group">
											<label><strong>Address</strong></label>
											<input type="text" ng-model="orderData.billToLocation" class="form-control" readonly="true" id="billToLocation" name="billToLocation" />
										</div>
									</div>
									
								</div>
								<div class="row">
									<div class="col-lg-4">
										<div class="form-group">
											<label><strong>Business Phone</strong> </label>
											<input type="text" ng-model="orderData.businessPhone" class="form-control" readonly="true" id="businessPhone" name="businessPhone" />
										</div>
									</div>
									
									<div class="col-lg-4">
										<div class="form-group">
											<label><strong>Email Address</strong> </label>
											<input type="text" ng-model="orderData.contactEmail" class="form-control" readonly="true" id="contactEmail" name="contactEmail" />
										</div>
									</div>					
								</div>
								
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingTwo">
							<h4 class="panel-title">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
								Ship From
								</a>
							</h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
							<div class="panel-body">
								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<label><b>Location# </b> </label>
											<input type="text" ng-model="orderData.locationId" class="form-control" readonly="true" id="locationId" name="locationId" />
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label><b>Customer </b> </label>
											<input type="text" ng-model="orderData.locationName" class="form-control" readonly="true" id="locationName" name="locationName" />
										</div>
									</div>		
									<div class="col-md-4">
										<div class="form-group">
											<label><b>Address</b></label>
											<input type="text" ng-model="orderData.shipToLocation" class="form-control" readonly="true" id="shipToLocation" name="shipToLocation" />
										</div>
									</div>								
								</div>
								<div class="row">										
									<div class="col-md-4">
										<div class="form-group">
											<label><b>Business Phone </b> </label>
											<input type="text" ng-model="orderData.locBusinessPhone" class="form-control" readonly="true" id="locBusinessPhone" name="locBusinessPhone" />
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label><b>Email </b> </label>
											<input type="text" ng-model="orderData.locContactEmail" class="form-control" readonly="true" id="locContactEmail" name="locContactEmail" />
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					
					<div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingThree">
							<h4 class="panel-title">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
								Order
								</a>
							</h4>
						</div>
						<div id="collapseThree" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingThree">
							<div class="panel-body">
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label>PO Number</label>
										<input type="text" ng-model="orderData.poNumber" ng-hide="editorEnabled" name="poNumber" class="form-control" placeholder="Enter PO Number">
										<span class="form-control-static" ng-show="editorEnabled"> : {{ orderData.poNumber }}</span>
									</div>
								</div>	
								
								<div class="col-md-6">
									<div class="form-group">
										<label>Reference Number 1</label>
										<input type="text" ng-model="orderData.refNumber1" ng-hide="editorEnabled" name="refNumber1" class="form-control" placeholder="Enter Reference Number 1 ">
										<span class="form-control-static" ng-show="editorEnabled"> : {{ orderData.refNumber1 }}</span>
									</div>
								</div>
							</div>
							
							<div class="row">
								<div class="col-md-6">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label>Pick up Due Date</label>
												<span class="form-control-static" ng-show="editorEnabled"> : {{ orderData.pickUpDueDate | date:'MM/dd/yyyy' }}</span>
												<!--<div class="input-group date">
													<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
													<input type="text" ng-model="orderData.pickUpDueDate" class="form-control pull-right" id="mainDdatePicker" />
												</div>-->												
												<datepicker  date-format="MM/dd/yyyy" ng-hide="editorEnabled">
												<input type="text" ng-model="orderData.pickUpDueDate" placeholder="Click here to select date" class="form-control pull-right" />
												</datepicker>
 
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Requested Pickup Date</label>
												<span class="form-control-static" ng-show="editorEnabled"> : {{ orderData.requestedPickupDate | date:'MM/dd/yyyy' }}</span>
												<!--<div class="input-group date">
													<div class="input-group-addon"><i class="fa fa-calendar"></i></div>
													<input type="date" ng-model="orderData.requestedPickupDate" name="requestedPickupDate" class="form-control pull-right" />
												</div>-->
												<datepicker  date-format="MM/dd/yyyy" ng-hide="editorEnabled">
												<input type="text" ng-model="orderData.requestedPickupDate" placeholder="Click here to select date" name="requestedPickupDate" class="form-control pull-right" />
												</datepicker>
											</div>
										</div>										
									</div>
								</div>	
								
								<div class="col-md-6">
									<div class="form-group">
										<label>Reference Number 2</label>
										<input type="text" ng-model="orderData.refNumber2" ng-hide="editorEnabled" name="refNumber2" class="form-control" placeholder="Enter Reference Number 2">
										<span class="form-control-static" ng-show="editorEnabled"> : {{ orderData.refNumber2 }}</span>
									</div>
								</div>
							</div>
						
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label>Requested Pick up Time</label>
										<span class="form-control-static" ng-show="editorEnabled"> : 
										<span ng-if="orderData.requestedPickUpTime1 != ''">{{ orderData.requestedPickUpTime1 }}</span>
										<!--<span ng-if="orderData.requestedPickUpTime2 != ''">{{ orderData.requestedPickUpTime2 | date: "hh:mm a" }}</span>-->
										</span>
										<div class="row" ng-hide="editorEnabled">
											<div class="col-md-4">
												<div class="form-group">
													<div class="input-group">
														<select class="form-control pull-right" ng-model="orderData.requestedPickUpTime1" name="requestedPickUpTime1">
															<option value="" selected>Select</option>
															<option value="Morning">Morning</option>
															<option value="Afternoon">Afternoon</option>
														</select>
													</div>
												</div>
											</div>
											<div class="col-md-2">
												<div class="form-group" style="padding-top:10px;">
													<label>OR</label>
												</div>
											</div>
											<div class="col-md-6">
												<div class="bootstrap-timepicker">
													<div class="form-group">
													  <div class="input-group">
														<input type="time" class="form-control" ng-model="orderData.requestedPickUpTime2" name="requestedPickUpTime2" id="timepicker2">
													  </div>
													  <!-- /.input group -->
													</div>
													<!-- /.form group -->
												  </div>
											</div>										
										</div>
									</div>
								</div>
								
								<div class="col-md-6">
									<div class="form-group">
										<label>Special Instructions</label>
										<input type="text" ng-model="orderData.instructions" ng-hide="editorEnabled" name="instructions" class="form-control" placeholder="Enter Special Instructions">
										<span class="form-control-static" ng-show="editorEnabled"> : {{ orderData.instructions }}</span>
									</div>
								</div>
								
							</div>	

						</div>
					</div>					
				</div>
				
				
				<div class="panel panel-default">
					<div class="panel-heading" role="tab" id="headingFour">
						<h4 class="panel-title">
							<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
							Order Details
							</a>
						</h4>
					</div>
					<div id="collapseFour" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingFour">
						<div class="panel-body">
							<div class="row">
								
								<div class="col-lg-6 col-md-12">
									<div class="col-md-12 col-lg-12">
										<div class="row"><h5><b>Pickup</b></h5></div>
									</div>
									<table class="display table table-bordered table-striped dataTable no-footer" width="100%">
										<thead>
											<tr>
												<th width="75">SKU</th>
												<th width="195">Description</th>
												<th width="120">Quantity</th>
											</tr>
										</thead>
										<tbody>
											<tr ng-repeat="pro in billDetails.products" ng-hide="orderData.qty[pro.sku]<=0 && editorEnabled">
												<td width="30">{{ pro.sku }}</td>
												<td width="170">{{ pro.description }}
												<input type="hidden" ng-init="orderData.description[pro.sku] =pro.description" ng-model="orderData.description[pro.sku]" />
												<input type="hidden" ng-init="orderData.weight[pro.sku] =pro.weight" ng-model="orderData.weight[pro.sku]" />
												<input type="hidden" ng-init="orderData.id[pro.sku] =pro.id" ng-model="orderData.id[pro.sku]" />
												</td>
												<td width="120">
												<input type="text" class="form-control" ng-hide="editorEnabled" ng-model="orderData.qty[pro.sku]"  ng-init="orderData.qty[pro.sku]=pro.quantity" style="width:100px;" />
												<span class="form-control-static" ng-show="editorEnabled">{{ orderData.qty[pro.sku] }}</span>
												</td>
											</tr>
										</tbody>
									</table>
								</div>
								
							</div>
						</div>
					</div>					
				</div>
				
				</div>
				
				<div class="row">
					<div class="col-md-12 col-lg-12">
						&nbsp;
					</div>
				</div>
				
				<div class="row">
					<div class="col-md-6">
						<!--<div class="form-group">
							<label>
								<input type="submit" class="btn btn-primary" value="Submit" />
							</label>
							<label>
								<input type="reset" class="btn btn-danger" value="Cancel" />
							</label>
						</div>-->
						
						<div class="form-group">
							<label>
								<input type="button" class="btn btn-primary" ng-hide="editorEnabled" ng-click="orderSummary()" value="Continue" />
								<input type="submit" class="btn btn-primary" ng-show="editorEnabled" value="Update" />
								<input type="button" class="btn btn-info" ng-show="editorEnabled" ng-click="orderCreateForm()" value="Edit" />
							</label>
							<label>
								<input type="reset" class="btn btn-danger" value="Cancel" />
							</label>
						</div>
						
					</div>
				</div>
				
				<div class="row">
					<div class="col-md-12" ng-show="errorMsg.length>0">
						{{errorMsg}}
					</div>
				</div>
				
			</div>
		</div>
		</div>
		</form>
    </section>




    <!-- /.content -->
  </div>
 <script src="<?php echo base_url(); ?>asset/angular/controllers/orders/editOrderCtrl.js"></script>