<?php
defined('BASEPATH') OR exit('No direct script access allowed');

function callWebService($url=null,$header=array(),$requestData = array(), $method="GET"){
	$curl = curl_init();
	curl_setopt_array($curl, array(
		  CURLOPT_URL => $url,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => $method,
		  CURLOPT_HTTPHEADER => $header,
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);
		
		if ($err) {
		  return $err;
		} else {
		  $res = json_decode($response,true);
		  //checkResponse($res);
		  return $res;
		}
	
}

function getControllerName($index){

	$array = array(
		"1"=>"Dashboard",
		"2"=>"Orders",
		"3"=>"Accounts",
		"4"=>"Location",
		"5"=>"Users",
		"6"=>"Roles",
		"7"=>"ReverseLogistics",
		"8"=>"InventoryMovement",
		"9"=>"Products",
		"10"=>"PriceSettings",
		"11"=>"Reports"
	);
	
	return $array[$index];
	
}

function getFunctionName($index){

	$array = array(
		"1"=>"create",
		"2"=>"viewAllOrders",
		"3"=>"viewAllProOrders",
		"4"=>"viewAllCarOrders",
		"5"=>"create_account",
		"6"=>"viewAllAccounts",
		"7"=>"create_location",
		"8"=>"manage_locations",
		"9"=>"create",
		"10"=>"viewAllUsers",
		"11"=>"create_role",
		"12"=>"viewAllRoles",
		"13"=>"assetSearch",
		"14"=>"index",
		"15"=>"sentToLocation",
		"16"=>"addProduct",
		"17"=>"viewAllProducts"
	);
	
	return $array[$index];	
}

function getURL($ciindex,$fnindex){
	$arrayCI = array(
		"1"=>"Dashboard",
		"2"=>"Orders",
		"3"=>"Accounts",
		"4"=>"Location",
		"5"=>"Users",
		"6"=>"Roles",
		"7"=>"ReverseLogistics",
		"8"=>"InventoryMovement",
		"9"=>"Products",
		"10"=>"PriceSettings",
		"11"=>"Reports"
	);
	
	$arrayFN = array(
		"1"=>"create",
		"2"=>"viewAllOrders",
		"3"=>"viewAllProOrders",
		"4"=>"viewAllCarOrders",
		"5"=>"create_account",
		"6"=>"viewAllAccounts",
		"7"=>"create_location",
		"8"=>"manage_locations",
		"9"=>"create",
		"10"=>"viewAllUsers",
		"11"=>"create_role",
		"12"=>"viewAllRoles",
		"13"=>"assetSearch",
		"14"=>"index",
		"15"=>"sentToLocation",
		"16"=>"addProduct",
		"17"=>"viewAllProducts"
	);
	
	return base_url().$arrayCI[$ciindex].'/'.$arrayFN[$fnindex];
}

function callPostMethod($url=null,$header=array(),$requestData = array(), $method="POST"){
	$curl = curl_init();
	curl_setopt_array($curl, array(
		  CURLOPT_URL => $url,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => $method,
		  CURLOPT_POSTFIELDS => json_encode($requestData),
		  CURLOPT_HTTPHEADER => $header,
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);
		
		if ($err) {
		  echo "cURL Error #:" . $err;
		  exit;
		} else {
		  $res = json_decode($response,true);
		  //checkResponse($res);
		  return $res;
		}
}
/*
curl_setopt_array($curl, array(
  CURLOPT_URL => "http://localhost/test/upload.php",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"filename\"; filename=\"angular-kendo.js\"\r\nContent-Type: application/javascript\r\n\r\n\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
    "postman-token: 26e55a04-327f-1f1e-0d9c-bc458edd1072"
  ),
));
*/
function callWebServiceFileUpload($url=null,$header=array(),$requestData = array(), $method="POST"){
	$curl = curl_init();
	curl_setopt_array($curl, array(
		  CURLOPT_URL => $url,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => $method,
		  CURLOPT_POSTFIELDS => $requestData,
		  CURLOPT_HTTPHEADER => $header,
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);
		
		if ($err) {
		  echo "cURL Error #:" . $err;
		  exit;
		} else {
		  $res = json_decode($response,true);
		  return $res;
		}
	
}

function checkResponse($out){
	$ci = &get_instance();
	$ci->load->library('session');
	
	if($out["responseStatusCode"] == 403){
		$ci->session->unset_userdata('token');
		$ci->session->unset_userdata('name');
		$ci->session->unset_userdata('role');
		$ci->session->sess_destroy();
		redirect('Login/tokenExpire', 'refresh');
	}else{
		return true;
	}
}

function validateToken(){
	
	$ci = &get_instance();
	$ci->load->library('session');
	
	if(isset($ci->session->userdata['token'])){
		$token = $ci->session->userdata['token'];
	}else{
		$token = NULL;
	}
	
	$url = WEBSERVICE_URL . "user/validateToken?token=".$token;
	
	$header = array(
		"device-type: Web",
		"ver: 1.0",
		"content-type: application/json"
	);
	
	$out = callWebService($url,$header,'',"GET");
	
	if(($out["responseObject"] == 1) && ($out["responseStatusCode"] == 200)){
		return true;
	}else{
		$ci->session->unset_userdata('token');
		$ci->session->unset_userdata('name');
		$ci->session->unset_userdata('role');
		$ci->session->sess_destroy();
		redirect('Login/tokenExpire', 'refresh');
	}
}