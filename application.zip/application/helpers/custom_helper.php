<?php
defined('BASEPATH') OR exit('No direct script access allowed');



function callWebService($url=null,$header=array(),$requestData = array(), $method="GET"){
	$curl = curl_init();
	curl_setopt_array($curl, array(
		  CURLOPT_URL => $url,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => $method,
		  CURLOPT_HTTPHEADER => $header,
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);
		
		if ($err) {
		  return $err;
		} else {
		  $res = json_decode($response,true);
		  //checkResponse($res);
		  return $res;
		}
	
}

function callPostMethod($url=null,$header=array(),$requestData = array(), $method="POST"){
	$curl = curl_init();
	curl_setopt_array($curl, array(
		  CURLOPT_URL => $url,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => $method,
		  CURLOPT_POSTFIELDS => json_encode($requestData),
		  CURLOPT_HTTPHEADER => $header,
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);
		
		if ($err) {
		  echo "cURL Error #:" . $err;
		  exit;
		} else {
		  $res = json_decode($response,true);
		  //checkResponse($res);
		  return $res;
		}
}

function checkResponse($out){
	$ci = &get_instance();
	$ci->load->library('session');
	
	if($out["responseStatusCode"] == 403){
		$ci->session->unset_userdata('token');
		$ci->session->unset_userdata('name');
		$ci->session->unset_userdata('role');
		$ci->session->sess_destroy();
		redirect('Login/tokenExpire', 'refresh');
	}else{
		return true;
	}
}

function validateToken(){
	
	$ci = &get_instance();
	$ci->load->library('session');
	
	if(isset($ci->session->userdata['token'])){
		$token = $ci->session->userdata['token'];
	}else{
		$token = NULL;
	}
	
	$url = WEBSERVICE_URL . "user/validateToken?token=".$token;
	
	$header = array(
		"device-type: Web",
		"ver: 1.0",
		"content-type: application/json"
	);
	
	$out = callWebService($url,$header,'',"GET");
	
	if(($out["responseObject"] == 1) && ($out["responseStatusCode"] == 200)){
		return true;
	}else{
		$ci->session->unset_userdata('token');
		$ci->session->unset_userdata('name');
		$ci->session->unset_userdata('role');
		$ci->session->sess_destroy();
		redirect('Login/tokenExpire', 'refresh');
	}
}