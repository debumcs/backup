myApp.controller('createUserCtrl', function($scope,$http) {
	
	$scope.pageTitle = "Create User";
	$scope.errorMsg = '';
	$scope.roleTypes = null;
	$scope.allStatus = null;
	$scope.userForm = {};
	$scope.resetUserForm = {};
	$scope.submitted = false;
	
	$scope.editorEnabled = false;
	
	$http.get(appBaseUrl + '/Common/get_role_list').success(function(response){
		$scope.roleTypes = response.responseObject;
		console.log(response.responseObject);

	});
	
	$http.get(appBaseUrl + '/Common/get_user_status').success(function(response){
		$scope.allStatus = response.responseObject;
	});

	$scope.reset = function(){
		$scope.userData = {};
	}
	
	$scope.createUser = function(){
		$scope.submitted = true;
		
		if($scope.userForm.$valid) {
			$http({
				method : 'POST',
				url : appBaseUrl + '/Users/create_user',
				data : $.param($scope.userData),
				headers: {'Content-Type': 'application/x-www-form-urlencoded'}
			}).success(function(response) {	
				
				if(response.responseStatusCode == 200){
					window.location = appBaseUrl + '/Users/user_confirm/' + response.responseObject.userId;
				}else{
					$scope.errorMsg = response.responseMessage;
				}			
			});
		}
	};
	
});