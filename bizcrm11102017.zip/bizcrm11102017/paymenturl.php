<?php 
	//require_once('include/auth.php');
	require_once('class/class.orderdetails.php');
	
	$objord = new Orderdetails();
	
	$customer_id = $_GET["customer_id"];
	$orderno = $_GET["orderno"];
	
	$msgD = '';
	
	if(isset($_POST['savePayment'])){
		//print_r($_POST);die();
		$objord->savePaymentDetails();
		$objord->redirect('payment.php?orderno='.$_POST['orderno']);
		unset($_POST);
	}
	
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>BIZCRM | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Bootstrap time Picker -->
    <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
    <!-- Date Picker -->
    <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />
	<link rel="stylesheet" href="date/jquery-ui.css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<script>
	
	function isDecimalNumber(evt, element) {
		
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode!=46)
		{
			status = "This field accepts numbers only.";
			return false;
		}else {
			var len = $(element).val().length;
			var index = $(element).val().indexOf('.');
			if (index > 0 && charCode == 46) {
				return false;
			}
			if (index > 0) {
				var CharAfterdot = (len + 1) - index;
				if (CharAfterdot > 3) {
					return false;
				}
			}

		}
		return true;
	}
	
	function validatepayment(){
		if(document.getElementById('payment_date').value =='' )
		{
			alert('Please Enter date!');
			document.getElementById('payment_date').focus();
			return false;
		}
		else if(document.getElementById('payment_mode').value =='' )
		{
			alert('Please Select paymentmode !');
			document.getElementById('payment_mode').focus();
			return false;
		}
		else if((document.getElementById('received_amount').value =='') || parseFloat(document.getElementById('received_amount').value == 0))
		{
			alert('Please Enter received amount!');
			document.getElementById('received_amount').focus();
			return false;
		}
		else{
			return true;
		}
	}
	
	</script>
  </head>
  <body class="hold-transition skin-blue sidebar-mini" onload="startTime()">
     
   <div class="wrapper">
			<!-- add payment -->
	  
		  <div class="modal-dialog" role="document">
			<form action="paymenturl.php" method="post" name="payment" id="payment">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Payment Detail</h4>
			  </div>
			  <div class="modal-body">
				<div class="row">
                              <div class="col-lg-12">
                              		<div class="form-group">
                                      <label for="name">Payment Date</label>
                                      <input type="text" class="form-control datepicker" id="payment_date" name="payment_date" placeholder="Enter payment date">
									  <input type="hidden" id="orderno" name="orderno" value="<?php echo $orderno; ?>">
									<input type="hidden" id="customer_id" name="customer_id" value="<?php echo $customer_id; ?>">
                                    </div>
                                    
                                    <div class="form-group">
                                      <label for="name">Payment Mode</label>
                                      <select name="payment_mode" class="form-control" id="payment_mode">
									  <option value="">Select Payment Mode</option>
									  <option value="Cash">Cash</option>
									  <option value="CreditCard">CreditCard</option>
									  <option value="Cheque">Cheque</option>
									  <option value="MobileWallet">MobileWallet</option>
									  </select>
                                    </div>
                                    
                                     <div class="form-group">
                                      <label for="name">Received Amount</label>
                                      <input type="text" class="form-control" id="received_amount" onKeyPress="return isDecimalNumber(event,this);" name="received_amount" placeholder="Enter received_amount">
                                    </div>
                                    
                                    <div class="form-group">
                                      <label for="name">Remarks</label>
                                      <input type="text" class="form-control" id="remarks" name="remarks" placeholder="Enter remarks">
                                    </div>
                                    
                              </div><!-- /.col -->                             
                              
                           </div><!-- /.row -->
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<input type="submit" class="btn btn-primary" name="savePayment" id="savePayment" onclick="return validatepayment();" value="Save" />
			  </div>
			</div>
			</form>
		  </div>
		
		
		<!-- Add Payment -->
	
      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->
	
	<script src="date/jquery-1.9.1.js"></script>
	<script src="date/jquery-ui.js"></script>
	<script>
	$(function() {
		$( ".datepicker" ).datepicker();
	});
	</script>
    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
    
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js"></script>
    
   
  </body>
</html>