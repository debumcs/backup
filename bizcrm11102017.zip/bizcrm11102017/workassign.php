<?php 
	require_once('include/auth.php');

	require_once('class/class.statusmaster.php');
	require_once('class/class.items.php');
	$objitem 		= new item();
	
	require_once('class/class.agencymaster.php');
	$objagency 	= new Agencymaster();
	$allagency 	= $objagency->getAll();

	$objStatus 	= new Statusmaster();
	$allStatus 	= $objStatus->getAll();
	
	if(isset($_POST['assignwork'])){
		$objitem->updateWork();
		//$referer_page 	= $_SERVER['HTTP_REFERER'];
		//$objitem->redirect($referer_page);
		exit;
	}
	$page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);
	$limit = 50;
	$startpoint = ($page * $limit) - $limit;
	$order = ''; $suborder = ''; $orderstatus = ''; $Search = '';
		
	if(isset($_GET['Search'])){
		if(isset($_GET['order'])){$order = $_GET['order'];}else{$order='';}
		if(isset($_GET['suborder'])){$suborder = $_GET['suborder'];}else{$suborder='';}
		$orderstatus = $_GET['orderstatus'];
		$Search = $_GET['Search'];
		$allitems = $objitem->allworkassignitems($order,$suborder,$orderstatus,$startpoint,$limit);
	}else{
		$allitems = $objitem->allworkassignitems('','','',$startpoint,$limit);
	}
	$total = $objitem->numberworkassignitems($order,$suborder,$orderstatus);
	
	$url = "?order=".$order."&suborder=".$suborder."&orderstatus=".$orderstatus."&Search=".$Search;
	
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title><?php echo $PRO_TITLE; ?> | Created Items or Assign Pending Items</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
	<link rel="stylesheet" href="bootstrap/css/datepicker.css" />
    <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css" />
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css" />
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css" />
    <!-- DataTables -->
    <link rel="stylesheet" href="dist/css/dataTables.bootstrap.css" />
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css" />
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css" />
   
	<link rel="stylesheet/less" type="text/css" href="side.less" />
	<link rel="stylesheet" href="date/jquery-ui.css" />
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<style>
		.datepicker-dropdown{z-index:1151 !important;}
		.initiald{ visibility: hidden;}
	</style>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
 <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objitem->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objitem->pssidebar(); ?>

		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
			<h1>Created Items or Assign Pending Items</h1>
            <ol class="breadcrumb">
				<li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
				<li>Order</li>
				<li class="active">Created Items or Assign Pending Items</li>
			</ol>
        </section>
        
          <!-- Main content -->
		<?php ?>
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
						<div class="col-md-12">
							<form class="form-inline">
								<div class="input-group mb-2 mr-sm-2 mb-sm-0">
									<div class="input-group-addon">Order</div>
									<input type="text" class="form-control input-sm" id="order" name="order" placeholder="Order" value="<?php if(isset($_GET['order'])){echo $_GET['order'];} ?>">
								</div>
								<div class="input-group mb-2 mr-sm-2 mb-sm-0">
									<div class="input-group-addon">Sub-order</div>
									<input type="text" class="form-control input-sm" id="suborder" name="suborder" placeholder="Sub-Order" value="<?php if(isset($_GET['suborder'])){echo $_GET['suborder'];} ?>">
								</div>
								<div class="input-group mb-2 mr-sm-2 mb-sm-0">
									<div class="input-group-addon">Status</div>
									<select id="orderstatus" class="form-control input-sm" name="orderstatus" >
									<option value="" selected="selected" >Select None</option>
									<option value="0" <?php if(isset($_GET['orderstatus']) && $_GET['orderstatus'] == '0'){echo 'selected';} ?> >No Work Done</option>
									<?php foreach($allStatus as $orderstatus){ ?>
									<option value="<?php echo $orderstatus['id']; ?>" <?php if(isset($_GET['orderstatus']) && $orderstatus['id'] == $_GET['orderstatus']){echo 'selected';} ?>><?php echo $orderstatus['statusname']; ?></option>
									<?php } ?>
									</select>
								</div>
								<div class="input-group mb-2 mr-sm-2 mb-sm-0">
									<input type="submit" class="btn btn-primary btn-sm" id="Search" name="Search" value="Search">
								</div>

							</form>
						</div>
					
                        <div class='box-body table-responsive'>
						<form class="form-inline" method="post">
                            <table id="example111" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th><input type="checkbox" style="display:block;" id="select_all" /></th>
                        <th>Order No</th>
                        <th>Suborder No</th>
                        <th>Items</th>
						<th>Fabric</th>
						<th>Units</th>
						<th>Status</th>
						<th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
					<?php for($i=0; $i<count($allitems); $i++) { ?>	
						<tr>
                            <td><input type="checkbox" style="display:block;" name="worklist[]" class="checkbox" value="<?php print $allitems[$i]['id'];?>"/></td>
							<td><?php print $allitems[$i]['orderno']; ?></td>
							<td><?php print $allitems[$i]['suborderno']; ?></td>
							<td><?php print $allitems[$i]['itemname']; ?></td>
							<td><?php print $allitems[$i]['fabricname']; ?></td>
							<td><?php print $allitems[$i]['value'].' ('.$allitems[$i]['units'].')'; ?></td>
							<td><?php if($allitems[$i]['status_id'] == '0'){echo 'No work done.';}else{print $objitem->getStatusName($allitems[$i]['status_id']);} ?></td>
							<td><a href="#" data-toggle="modal" data-target="#editassignedwork" onclick='editassignedwork("<?php print $allitems[$i]['id'];?>");'>Update Status</a></td>
						</tr>
                    <?php } ?>						
                    </tbody>
                    
                  </table>
							
							<div class="col-lg-12">
								<div class="col-lg-12">
									<label for="name">&nbsp;</label>
								</div>
							</div>
							<div class="col-lg-12">
								<div class="col-lg-12">
									<label for="name">Assign Work</label>
								</div>
							</div>
							
							<div class="col-md-12 col-lg-12">							
								<div class="input-group mb-3 mr-sm-3 mb-sm-0">
									<div class="input-group-addon">Status</div>
									<select id="assignstatus" class="form-control input-sm" name="assignstatus" onchange="getAgency(this.value);" >
									<option value="0" selected="selected" disabled >No Work Done</option>
									<?php foreach($allStatus as $orderstatus){ ?>
									<option value="<?php echo $orderstatus['id'].':'.$orderstatus['status_type']; ?>"><?php echo $orderstatus['statusname']; ?></option>
									<?php } ?>
									</select>
									<input type="hidden" id="checkstatustype" name="checkstatustype" value="None" />
								</div>
								
								<div class="input-group mb-3 mr-sm-3 mb-sm-0 initiald">
									<div class="input-group-addon">Agency</div>
									<div id="agencyidbox"><select id="agencyid" class="form-control input-sm" name="agencyid"></select></div>
								</div>
								<div class="input-group mb-3 mr-sm-3 mb-sm-0 initiald">
									<div class="input-group-addon">Challan No</div>
									<input type="text" class="form-control input-sm" id="challanno" name="challanno" placeholder="Challan Number" />
								</div>
								
								
							</div>
							<div class="col-md-12 col-lg-12">
								<div class="input-group mb-3 mr-sm-3 mb-sm-0">
									<div class="input-group-addon">Status Date</div>
									<input type="text" class="form-control input-sm datepicker" id="status_date" name="status_date" placeholder="Status Date" />
								</div>
								
								<div class="input-group mb-3 mr-sm-3 mb-sm-0 initiald">
									<div class="input-group-addon">Expected Date</div>
									<input type="text" class="form-control input-sm datepicker" id="expected_date" name="expected_date" placeholder="Expected Date" />
								</div>							
							</div>
							<div class="col-md-12 col-lg-12">
								
								<div class="input-group col-md-3 col-lg-3">
									<div class="input-group-addon">Remark</div>
									<textarea cols="45" rows="1" class="form-control" id="remark" name="remark" placeholder="Remark" ></textarea>
								</div>
								
								<div class="input-group mb-2 mr-sm-2 mb-sm-0">
									<input type="submit" class="btn btn-primary btn-sm" id="assignwork" name="assignwork" onclick="return validateassignwork();" value="Update" />
								</div>								
							</div>
							
						</form>
						</div><!-- /.box-body--> 
					</div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
			  <div class="row">
				<div class="col-md-12">
				<?php echo $objitem->pagination($total,$limit,$page,$url); ?>
				</div>
			  </div>
        </section><!--CONTENT-->
		
      </div><!-- /.content-wrapper -->
      
 <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->
	
<!-- Assigned Work -->
<div class="modal fade" id="editassignedwork" tabindex="-1" role="dialog" aria-labelledby="editassignedworkLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Update Assigned Work</h4>
			</div>
			
			<div class="modal-body">
				<div class="row">
					<div id="getAssignedWorkData">

					</div><!-- /.col -->
				</div><!-- /.row -->
			</div>
			
			<div class="modal-footer">
				<input type="submit" class="btn btn-primary btn-sm" id="assignwork" name="assignwork" onclick="updateassignedwork();" value="Set Next Status">
				<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
			</div>		
		</div>
	</div>
</div>
<!-- Assigned Work -->

<!-- jQuery 2.1.4 -->
<script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="dist/js/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.5 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="plugins/select2/select2.js"></script>
<!-- DataTables -->
<script src="dist/js/jquery.dataTables.js"></script>
<script src="dist/js/dataTables.bootstrap.min.js"></script>
<script src="bootstrap/js/bootstrap-datepicker.js"></script>
<script type="text/javascript">
// When the document is ready
$(document).ready(function () {	
	$('.datepicker').datepicker({
		format: "dd/mm/yyyy",
		autoclose: true,
		parseForce:false
	});
		
	$("#order_type").on("change", function () {
		if ($(this).val() === "ALT") {
			$('#alt_order_no').prop('readonly',false);
		}else{
			$('#alt_order_no').prop('readonly',true);
			$("#alt_order_no").val('');
		}
	});
	
});

function validateassignwork(){
	var count_checked = $("[name='worklist[]']:checked").length; // count the checked rows
	if($("#checkstatustype").val() == 'Initial'){
		if(count_checked == 0){
			alert("Please check atleast one checkbox!");
			return false;
		}else if(document.getElementById("assignstatus").value == '0'){
			document.getElementById("assignstatus").focus();
			alert("Please select status of work!");
			return false;
		}else if(document.getElementById("agencyid").value == ''){
			document.getElementById("agencyid").focus();
			alert("Please select agency.");
			return false;
		}else if(document.getElementById("challanno").value == ''){
			document.getElementById("challanno").focus();
			alert("Please enter challan number");
			return false;
		}else if(document.getElementById("status_date").value == ''){
			document.getElementById("status_date").focus();
			alert("Please select status date.");
			return false;
		}else if(document.getElementById("expected_date").value == ''){
			document.getElementById("expected_date").focus();
			alert("Please select expected date.");
			return false;
		}else if(document.getElementById("remark").value == ''){
			document.getElementById("remark").focus();
			alert("Please enter remark");
			return false;
		}else{
			return true;
		}
	}
	else{
		if(count_checked == 0){
			alert("Please check atleast one checkbox!");
			return false;
		}else if(document.getElementById("assignstatus").value == '0'){
			document.getElementById("assignstatus").focus();
			alert("Please select status of work!");
			return false;
		}else if(document.getElementById("status_date").value == ''){
			document.getElementById("status_date").focus();
			alert("Please select status date.");
			return false;
		}else if(document.getElementById("remark").value == ''){
			document.getElementById("remark").focus();
			alert("Please enter remark");
			return false;
		}else{
			return true;
		}
	}
}

function addnotes(cid){
	var note = $("#cus_note"+cid).val();
	var cust_id = cid;
	var agent_id = $("#agent_id").val();
	var ipaddress = $("#ipaddress").val();

	if(note == ''){
		alert('Please enter notes!');
		return false;
	}

	var task = 'cus_notes';
	$.ajax({
		type: "GET",
		url: "ajax.php",
		data: {cus_note:note,task:task,cust_id:cust_id,agent_id:agent_id,ipaddress:ipaddress},

		success: function(data){
			console.log(data);
			$("#cus_note_tbl"+cust_id).html('');
			$("#cus_note"+cust_id).val('');

			$("#cus_note_tbl"+cust_id).html(data);
			return false;
		}
	});

	return false;
}

function updateassignedwork(){

	var assigned_id		= $("#aw_assigned_id").val();
	var challanno 		= $("#aw_challanno").val();
	var agencyid 		= $("#aw_agencyid").val();
	var status_date 	= $("#aw_status_date").val();
	var assignstatus 	= $("#aw_assignstatus").val();
	
	var task = 'updateAssignedWork';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data:{task:task, id:assigned_id, challanno:challanno, agencyid:agencyid, status_date:status_date, assignstatus:assignstatus},
		success: function(data){
			console.log(data);
			if(data == 'OK'){
				alert('Data Updated Successfully.');
			}else{
				alert('Error Message: '+data);
			}
			window.location.reload(true);
			return false;
		}
	});
	
}

function checkchallanno(){
	var task = 'getAutoNumber';
	var assignstatus1 = $("#assignstatus option:selected").val();
	var agencyid1 = $("#agencyid option:selected").val();
	
	if(agencyid1 === ''){
		$("#challanno").val('');
		$("#challanno").prop("readonly", false);
	}else{
		$.ajax({
			type:"POST",
			url: "ajax_suborder.php",
			data:{task:task,assignstatus:assignstatus1,agencyid:agencyid1},
			success:function(data){
				console.log(data);
				if(data != 'No'){
					$("#challanno").val(data);
					$("#challanno").prop("readonly", true);
				}else{
					$("#challanno").val('');
					$("#challanno").prop("readonly", false);
				}
				return false;
			}
		});
	}

}

function getAgency(statusarr){
	/*$("#challanno").val('');
	$("#challanno").prop("readonly", false);*/
	
	var arr = statusarr.split(':');
	var statusid = arr[0];
	var status_type = arr[1];
	
	//alert(statusid+':'+status_type);
	
	if(status_type == 'Initial'){
		$(".initiald").css("visibility", "visible");
		$("#checkstatustype").val("Initial");
		
	}else{
		$(".initiald").css("visibility", "hidden");
		$("#checkstatustype").val("None");
	}
	var task = 'getAgencyByStatus';
	$.ajax({
		type:"POST",
		url: "ajax_suborder.php",
		data:{task:task,statusid:statusid},
		success:function(data){
			$("#agencyidbox").html('');
			$("#agencyidbox").html(data);
			return false;
		}
	});
}

function getAgencyByAssignedID(statusid){
	
	var task = 'getAgencyByStatus';
	$.ajax({
		type:"POST",
		url: "ajax_suborder.php",
		data:{task:task,statusid:statusid},
		success:function(data){
			$("#aw_agencyid").html('');
			$("#aw_agencyid").html(data);
			return false;
		}
	});
}

function editassignedwork(assignedid){
	
	var task = 'getAssignedWorkData';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data:{task:task,assignedid:assignedid},
		success: function(data){
			$("#getAssignedWorkData").html('');
			$("#getAssignedWorkData").html(data);
			$('.datepicker').datepicker({format: "yyyy-mm-dd",autoclose: true});
			return false;
		}
	});
	return false;
}
	
$(document).ready(function(){
    $('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
            });
        }
    });
    
    $('.checkbox').on('click',function(){
        if($('.checkbox:checked').length == $('.checkbox').length){
            $('#select_all').prop('checked',true);
        }else{
            $('#select_all').prop('checked',false);
        }
    });
});
	
	$("#message").fadeIn('slow').delay(2000).fadeOut('slow');
    </script> 
    
    <!-- daterangepicker -->
    <script src="dist/js/moment.min.js"></script>
    <!-- iCheck 1.0.1 -->
    <script src="plugins/iCheck/icheck.min.js"></script>
    
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    
    <script type="text/javascript" src="dist/js/date.js"></script>
    
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    
	
</body>
</html>