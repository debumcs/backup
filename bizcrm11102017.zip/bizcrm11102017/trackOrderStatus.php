<?php 
	require_once('include/auth.php');
	require_once('class/class.report.php');
	$objrpt = new Report();
	
	$allCustomer = $objrpt->getAllCustomer();
	
	$action = "";
	$action = $_GET["action"];
	$id = $_GET["id"];
	$msgD = '';
	$allTrackOrder = NULL;
	$order_id = $objrpt->sanitize($_POST['order_id']);
	$customer_id = $objrpt->sanitize($_POST['customer_id']);
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>BIZCRM | Track Order Status</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Bootstrap time Picker -->
    <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
    <!-- Date Picker -->
    <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<script type="text/javascript" language="javascript">

		function validatereport(){
            
            if(document.getElementById('customer_id').value =='' )
            {
				alert('Please select customer id!');
				document.getElementById('customer_id').focus();
				return false;
			}
			else{
				return true;
			}
			
      	}
	
	</script>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
     
   <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objrpt->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objrpt->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>Track Order Status</h1>
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
            <li>Report</li>
            <li class="active">Track Order Status</li><li class="active"><?php echo $action; ?></li>
          </ol>
        </section><!--CONTENT HEADER-->
        
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title">Search</h3>
                        </div><!-- /.box-header -->
                        <?php  ?><div class='box-body'>
                            <form action="" name="Sourcemaster" id="Sourcemaster" method="post" >
							<div class="row">
								<div class="col-lg-12">	
									<div class="col-lg-4">
										<div class="form-group">
											<select class="form-control select2" id="customer_id" name="customer_id" style="width:100%;">
												<option value="" selected disabled>Select Customer Id</option>
												<?php for($i=0; $i<count($allCustomer); $i++){ ?>
												<option value="<?php echo $allCustomer[$i]['cust_id']; ?>" <?php if($customer_id == $allCustomer[$i]['cust_id']){echo 'selected';}?>><?php echo $allCustomer[$i]['salutation'].' '.$allCustomer[$i]['name_first'].' '.$allCustomer[$i]['name_last'].' ( '.$allCustomer[$i]['cust_id'].' )'; ?></option>
												<?php }?>
											</select>
										</div><!-- /.form-group -->
									</div><!-- /.col -->
								  
									<div class="col-lg-4">
										<div class="form-group">
											<input type="text" class="form-control" id="order_id" name="order_id" placeholder="Enter Order Number" value="<?php echo $order_id; ?>">
										</div>										
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
											<input type="submit" name="submit" id="submit" class="btn btn-warning left-10" onclick="return validatereport();" value="Submit" />
										</div>										
									</div><!-- /.col -->
									
								</div><!-- /.col -->								
								
                           </div><!-- /.row -->
                           </form>
                        </div><!-- /.box-body--> <?php  ?>
						<?php 
							if($_POST['submit'] == 'Submit'){
								$allTrackOrder = $objrpt->getAllTrackOrder();
								if(count($allTrackOrder)){
						?>
						<div class='box-body table-responsive'>
							<table id="example111" class="table table-bordered table-striped">
								<thead>
									<tr>
										<th></th>
										<th>Order Number</th>
										<th>Customer ID</th>
										<th>Order Date</th>
										<th>Sale Amount</th>
										<th>Discount Amount</th>
										<th>Net Payable</th>
										<th>Received Amount</th>
									</tr>
								</thead>
								<tbody>
								<?php for($i=0; $i<count($allTrackOrder); $i++) { ?>	
									<tr>
										<td style='display: inline-block;position: relative;top: 0px;left: 0px;' class="accordion-toggle" data-toggle="collapse" data-parent="#OrderPackages" data-target=".packageDetails<?php echo $allTrackOrder[$i]['orderno']; ?>"><i class="indicator glyphicon pull-right glyphicon-chevron-down"></i></td>
										<td><?php print $allTrackOrder[$i]['orderno']; ?></td>
										<td><?php print $allTrackOrder[$i]['custname']; ?></td>
										<td><?php print $allTrackOrder[$i]['order_date']; ?></td>
										<td><?php print $allTrackOrder[$i]['sale_amount1']; ?></td>
										<td><?php print $allTrackOrder[$i]['discount_amount1']; ?></td>
										<td><?php print $allTrackOrder[$i]['netamount']; ?></td>								
										<td><?php print $allTrackOrder[$i]['received_amount']; ?></td>
									</tr>
									
							<?php
							$suborderdata = $objrpt->getSuborderDetails($allTrackOrder[$i]['orderno']);
							if(count($suborderdata) > 0)
							{													
							?>
								<tr><td colspan='10' style="padding:0!important;background-color: #f1e9de;">
                                                       <div id="OrderPackages1" class="packageDetails<?php echo $allTrackOrder[$i]['orderno']; ?> collapse" style="width: 91%; margin: 1% 4%; background: rgb(221, 221, 221) none repeat scroll 0% 0%; height: 0px;">
									<table class="table table-bordered table-striped inner-table1" width='100%'>
									<thead>
									<tr>
										<th>&nbsp;</th>
										<th><b>Sub Order No</b></th>
										<th><b>Style Ref</b></th>
										<th><b>Trial Date</b></th>
										<th><b>Delivery Date</b></th>
										<th><b>Sale Amount</b></th>
										<th><b>Discount</b></th>
										<th><b>Net Payable</b></th>
									</tr>	
									</thead>
									<tbody>
									<?php 									
									foreach($suborderdata as $subdata)
									{
										?>
										<tr>
											<td style='display: inline-block;position: relative;top: 1px;left: 5px;' class="accordion-toggle" data-toggle="collapse" data-target="#packageDetails<?php print $subdata['suborderno']; ?>" onclick="getItemBySO('<?php print $subdata['suborderno']; ?>');"><i class="indicator glyphicon pull-right glyphicon-chevron-down"></i></td>
											<td><?php echo $subdata['suborderno']; ?></td>
											<td><?php echo $subdata['style_ref']; ?></td>
											<td><?php echo $subdata['trial_date']; ?></td>
											<td><?php echo $subdata['delivery_due_date']; ?></td>
											<td><?php echo $subdata['sale_amount']; ?></td>
											<td><?php echo $subdata['discount_amount']; ?></td>
											<td><?php echo $subdata['netamount']; ?></td>
										</tr>
										<tr>
											<td colspan="8" style="padding: 0px !important;">
                                                                      <div id="packageDetails<?php print $subdata['suborderno']; ?>" class="accordian-body collapse" style="width: 91%; margin: 1% 4%; background: rgb(221, 221, 221) none repeat scroll 0% 0%; height: 0px;"></div>
                                                                  </td>
										</tr>
										<?php } ?>
									</tbody>
									</table>
                                                       </div>
								</td>
							</tr>
									
						<?php } else { ?>
								<tr><td colspan='6' style="padding: 0px !important;" >
									<table class="table table-bordered table-striped packageDetails<?php echo $allTrackOrder[$i]['orderno']; ?> collapse" width='100%'>
										<tr style="background-color:#D4AE87;">
											<th colspan="6">No Records Found</th>
										</tr>
									</table>
								</td></tr>
								
								<?php	}	?>
								<?php } ?>						
								</tbody>
							</table>                           
						</div><!-- /.box-body--> 
						<?php }else{ echo 'No record found.';}} ?>
						
						
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
		
		
    </div><!-- /.content-wrapper -->
      
    <?php include('footer.php'); ?>

    <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->
	
<div class="modal fade" id="viewhistory" tabindex="-1" role="dialog" aria-labelledby="viewhistoryLabel">
	<div class="modal-dialog" role="document">	
	<div class="modal-content">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Work Status History</h4>
		</div>
		<div class="modal-body">
			<div class="row" id="workstatusdatabyassignedid">
				
			</div><!-- /.row -->
		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		</div>
	</div>	
	</div>
</div>
	
	<div class="modal fade" id="orderStatusDetails" tabindex="-1" role="dialog" aria-labelledby="orderdetailsLabel">
		<div class="modal-dialog" role="document">	
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Order Details </h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-lg-12" id="orderStatusData">


					</div><!-- /.col -->
				</div><!-- /.row -->
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>	
		</div>
	</div>
    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
    
    <!-- daterangepicker -->
    <script src="dist/js/moment.min.js"></script>
    <!-- iCheck 1.0.1 -->
    <script src="plugins/iCheck/icheck.min.js"></script>
    <!-- datepicker -->
    <script src="plugins/datepicker/bootstrap-datepicker.js"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js"></script>
    
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <script>
		$("#message").fadeIn('slow').delay(5000).fadeOut('slow');
		$(".select2").select2();
		
	function getStatusByOrderNo(order_no){
		var  order_id = order_no;
		var task = 'getStatusByOrderNo';
		$.ajax({
			type: "GET",
			url: "ajax.php",
			data: {task:task,order_id:order_id},

			success: function(data){
				console.log(data);
				$("#orderStatusData").html('');
				$("#orderStatusData").html(data);
				return false;
			}
		});
		return false;
	}

function gethistorybyassignedid(assignedid){
	
	var task = 'history_assigned_id';
	$.ajax({
		type: "POST",
		url: "ajax_suborder.php",
		data:{task:task,assignedid:assignedid},
		success: function(data){
			//console.log(data);
			$("#workstatusdatabyassignedid").html('');
			$("#workstatusdatabyassignedid").html(data);			
			return false;
		}
	});
	return false;
}
	
	function getItemBySO(suborderno){
	
		var task = 'getItemBySO';
		$.ajax({
			type: "POST",
			url: "ajax_suborder.php",
			data:{task:task,suborderno:suborderno},
			success: function(response){
				console.log(response);
				$("#packageDetails"+suborderno).html('');
				$("#packageDetails"+suborderno).html(response);
				return false;
			}
		});
		return false;
	}
	
	</script>
  </body>
</html>