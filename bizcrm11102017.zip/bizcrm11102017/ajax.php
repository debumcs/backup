<?php
	error_reporting(-1);
	require_once('class/class.search.php');
	$objsrc = new Search();
	
	if($_REQUEST['task'] == 'addsubordernotes')
	{
		$notes = $objsrc->addsubordernotes($_REQUEST['suborder_note'],trim($_REQUEST['suborder_id']),trim($_REQUEST['suborderagent_id']),trim($_REQUEST['suborderipaddress']),trim($_REQUEST['suborder_status']));

		foreach($notes as $n)
		{			
			$html.=  "<div class='row'>			
			<div class='col-lg-12'><b> Note :-  </b>".$n['suborder_notes']."</div>
			<div class='col-lg-12'><b>  Added By:-  </b><span class='ofont'>".$n['name']." (".$n['agent_id'].")</span> &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;  <b>Note Date: </b><span class='ofont'>".$n['subnotes_date']."</span></div>
			</div> <hr />";
		}
		echo $html;
		exit;
		
	}
	
	if($_REQUEST['task'] == 'getSubOrderNotes')
	{	
		//task:getSubOrderNotes,suborder_id:suborder_id
		
		$notes = $objsrc->getSubOrderNotes(trim($_REQUEST['suborder_id']));

		foreach($notes as $n)
		{
			/*if($n['status'] =='1')
				$status= " Incomplete";
			else if($n['status'] =='2')
				$status= " Pending";	
			else if($n['status'] =='3')
				$status= " Processed";
			else if($n[' status'] =='4')
				$status= " Partially Shipped";	
			else if($n['status'] =='5')
				$status= " Shipping";	
			else if($n['status'] =='6')
				$status= " Shipped";	
			else if($n['status'] =='7')
				$status= " Partially Returned";
			else if($n['status'] =='8')
				$status= " Returned";
			else if($n['status'] =='9')
				$status= " Cancelled";*/

			$html.=  "<div class='row'>
			
			<div class='col-lg-12'><b> Note :-  </b>".$n['suborder_notes']."</div>
			<div class='col-lg-12'><b>  Added By: </b><span class='ofont'>".$n['name']." (".$n['agent_id'].")</span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Note Date: </b><span class='ofont'>".$n['subnotes_date']."</span></div>
			
			</div><hr />";							
		}
		echo $html;
		exit;		
	}
	/* ------------------- */
	if($_REQUEST['task'] == 'cus_notes')
	{
		$notes = $objsrc->addCustomernote($_REQUEST['cus_note'],trim($_REQUEST['cust_id']),trim($_REQUEST['agent_id']),trim($_REQUEST['ipaddress']));
		foreach($notes as $n)
		{
			$html.=  "<div class='row'><div class='col-lg-12'><b> Note :-  </b>".$n['notes']."</div><div class='col-lg-6'><b>  Date:-  </b>".$n['notes_date']."</div><div class='col-lg-6'><b>  Added By:-  </b>".$n['agent_id']."</div></div>  
			<hr />";
		}
		echo $html;
		exit;		
	}
	else if($_REQUEST['task'] == 'addOrdernotes')
	{
		$notes = $objsrc->addOrdernote($_REQUEST['order_note'],trim($_REQUEST['order_id']),trim($_REQUEST['agent_id']),trim($_REQUEST['ipaddress']));

		foreach($notes as $n)
		{
			/*if($n['status'] =='1')
				$status= "Incomplete";
			else if($n['status'] =='2')
				$status= "Pending";	
			else if($n['status'] =='3')
				$status= "Processed";
			else if($n['status'] =='4')
				$status= "Partially Shipped";	
			else if($n['status'] =='5')
				$status= "Shipping";	
			else if($n['status'] =='6')
				$status= "Shipped";	
			else if($n['status'] =='7')
				$status= "Partially Returned";
			else if($n['status'] =='8')
				$status= "Returned";
			else if($n['status'] =='9')
				$status= "Cancelled";*/
			
			$html.=  "<div class='row'>
			
			<div class='col-lg-12'><b> Note :-  </b>".$n['order_notes']."</div>
			<div class='col-lg-12'><b>  Added By: </b><span class='ofont'>".$n['name']." (".$n['agent_id'].")</span> &nbsp;&nbsp;&nbsp;&nbsp; <b>Note Date: </b> <span class='ofont'>".$n['notes_date']."</span></div>			
			</div> <hr />";
		}
		echo $html;
		exit;
		
	}else if($_REQUEST['task'] == 'getnotes')
	{
	
		$notes = $objsrc->getorderNotes(trim($_REQUEST['order_id']));

		foreach($notes as $n)
		{
			/*if($n['status'] =='1')
				$status= " Incomplete";
			else if($n['status'] =='2')
				$status= " Pending";	
			else if($n['status'] =='3')
				$status= " Processed";
			else if($n[' status'] =='4')
				$status= " Partially Shipped";	
			else if($n['status'] =='5')
				$status= " Shipping";	
			else if($n['status'] =='6')
				$status= " Shipped";	
			else if($n['status'] =='7')
				$status= " Partially Returned";
			else if($n['status'] =='8')
				$status= " Returned";
			else if($n['status'] =='9')
				$status= " Cancelled";*/

			$html.=  "<div class='row'>
			
			<div class='col-lg-12'><b> Note :-  </b>".$n['order_notes']."</div>
			<div class='col-lg-12'><b>  Added By: </b><span class='ofont'>".$n['name']." (".$n['agent_id'].")</span> &nbsp;&nbsp;&nbsp;&nbsp; <b>Note Date: </b> <span class='ofont'>".$n['notes_date']."</span></div>
			
		
			
			</div><hr />";							
		}
		echo $html;
		exit;		
	}
	else if($_REQUEST['task'] == 'delOrderbyno')
	{
		$order = $objsrc->getorderDetailByorderID(trim($_REQUEST['order_id']));

		foreach($order as $n)
		{
			 if($n['order_type'] == "ALT")
			 {	$order_type = 'Alteration';	
				$alt='<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Alt Order No</label>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="form-group">'.$n['alt_order_no'].'
						</div>
					</div>
					';
			}
		 
		 if($n['order_type'] == "RMO")
			 {	$order_type = 'stitching and Ready Made Order';	}
		 
		 if($n['order_type'] == "PD")
			 {	$order_type = 'Only for Stitching';	}
				 
				$html.='<div class="row">							
				<div class="col-lg-12">
					<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Customer ID</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['customer_id'].'
							<input type="hidden" name="delorderno" id="delorderno" value="'.$_REQUEST['order_id'].'" />
						</div>
					</div><!-- /.col -->
					
					<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Order Number</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['orderno'].'
						</div>
					</div><!-- /.col -->
				</div>
				
				<div class="col-lg-12">
				<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Order Type</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$order_type.'
						</div>
					</div><!-- /.col -->
					
					<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Quantity</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['quantity'].'
						</div>
					</div><!-- /.col -->
				</div>
				
				
				<div class="col-lg-12">
				<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Total Amount</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['total_amount'].'
						</div>
					</div><!-- /.col -->
					
					<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Amount Received</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['amount_received'].'
						</div>
					</div><!-- /.col -->
				</div>
				
				
				<div class="col-lg-12">
				<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Payment Type</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['payment_type'].'
						</div>
					</div><!-- /.col -->
					
					<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Sale Person</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['sale_person'].'
						</div>
					</div><!-- /.col -->
				</div>
				
				<div class="col-lg-12">
				<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Bill No</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['billno'].'
						</div>
					</div><!-- /.col -->
					
					<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Order Date</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['order_date'].'
						</div>
					</div><!-- /.col -->
				</div>
				
				
				<div class="col-lg-12">
				<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Trial Date</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['trial_date'].'
						</div>
					</div><!-- /.col -->
					
					<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Delivery Due Date</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['delivery_due_date'].'
						</div>
					</div><!-- /.col -->
				</div>
				'.$alt.'
				<div class="col-lg-12">
				<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Order Detail</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-9">
						<div class="form-group">
							'.$n['order_detail'].'
						</div>
					</div><!-- /.col -->
				
				</div>
				';
		}		  
		echo $html;
		exit;
		
	}
	
	else if($_REQUEST['task'] == 'getOrderbyno')
	{
	

	
		$order = $objsrc->getorderDetailByorderID(trim($_REQUEST['order_id']));

		foreach($order as $n)
		{
			 if($n['order_type'] == "ALT")
			 {	$order_type = 'Alteration';	
				$alt='<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Alt Order No</label>
						</div>
					</div>
					<div class="col-lg-3">
						<div class="form-group">'.$n['alt_order_no'].'
						</div>
					</div>
					';
			}
		 
		 if($n['order_type'] == "RMO")
			 {	$order_type = 'stitching and Ready Made Order';	}
		 
		 if($n['order_type'] == "PD")
			 {	$order_type = 'Only for Stitching';	}
				 
				$html.='<div class="row">							
				<div class="col-lg-12">
					<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Customer ID</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['customer_id'].'
						</div>
					</div><!-- /.col -->
					
					<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Order Number</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['orderno'].'
						</div>
					</div><!-- /.col -->
				</div>
				
				<div class="col-lg-12">
				<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Order Type</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$order_type.'
						</div>
					</div><!-- /.col -->
					
					<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Quantity</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['quantity'].'
						</div>
					</div><!-- /.col -->
				</div>
				
				
				<div class="col-lg-12">
				<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Total Amount</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['total_amount'].'
						</div>
					</div><!-- /.col -->
					
					<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Amount Received</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['amount_received'].'
						</div>
					</div><!-- /.col -->
				</div>
				
				
				<div class="col-lg-12">
				<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Payment Type</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['payment_type'].'
						</div>
					</div><!-- /.col -->
					
					<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Sale Person</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['sale_person'].'
						</div>
					</div><!-- /.col -->
				</div>
				
				<div class="col-lg-12">
				<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Bill No</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['billno'].'
						</div>
					</div><!-- /.col -->
					
					<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Order Date</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['order_date'].'
						</div>
					</div><!-- /.col -->
				</div>
				
				
				<div class="col-lg-12">
				<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Trial Date</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['trial_date'].'
						</div>
					</div><!-- /.col -->
					
					<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Delivery Due Date</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-3">
						<div class="form-group">
							'.$n['delivery_due_date'].'
						</div>
					</div><!-- /.col -->
				</div>
				'.$alt.'
				<div class="col-lg-12">
				<div class="col-lg-3">
						<div class="form-group">
						  <label for="name">Order Detail</label>
						</div>
					</div><!-- /.col -->

					<div class="col-lg-9">
						<div class="form-group">
							'.$n['order_detail'].'
						</div>
					</div><!-- /.col -->
				
				</div>
				';
	}		  
	echo $html;
		exit;
		
	}else if($_REQUEST['task'] == 'getpaymentstaticsByCudtid')
	{
		
		$cust = $objsrc->getpaymentstaticsByCudtid(trim($_REQUEST['cust_id']));
		$html.='<table class="table" style="border: 1px solid #9E9E9E;">
				<tr>
				<th  align="left">Year</th>
				<th  align="left">Custid</th>
				<th  align="center">Total Amt</th>
				<th  align="center">Total Dis Amt</th>
				<th  align="center">Cleared Amt</th>
				<th  align="center">Balance Amt</th>
				</tr>';
										
		foreach($cust as $n)
		{
			$html.='<tr><td  align="left">'.$n["orderyear"].'</td>
			<td  align="left">'.$n["customer_id"].'</td>
			<td  align="center">'.$n["TotalSaleAmt"].'</td>
			<td  align="center">'.$n["TotalDisAmt"].'</td>
			<td  align="center">'.$n["ClearedAmt"].'</td>
			<td  align="center">'.$n["BalanceAmt"].'</td></tr>';
		}

		$html.='</table>';

		echo $html;
		exit;
		
	}else if($_REQUEST['task'] == 'getPaymentDetailsByOrderNo')
	{
		$cust = $objsrc->getPaymentDetailsByOrderNo(trim($_GET['orderno']));

		$html.='<table class="table table-bordered table-striped" style=" border: 1px solid #9E9E9E;">
		<tr>
			<th align="center">SL. No.</th>
			<th align="center">Payment Date</th>
			<th align="center">Payment Mode </th>
			<th align="center">Received Amount</th>	
			<th align="center">Remark</th>														
		</tr>';
		$j= 1;
		foreach($cust as $n)
		{
			$html.='<tr>
			<td align="center">'.$j.'</td>
			<td align="center">'.$n["payment_date"].'</td>
			<td align="center">'.$n["payment_mode"].'</td>
			<td align="center">'.$n["received_amount"].'</td>
			<td align="left">'.$n["remarks"].'</td></tr>';
			$j++;
		}

		$html.='</table>';
		echo $html;
		exit;
	}
		
