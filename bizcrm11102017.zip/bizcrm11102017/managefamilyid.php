<?php 
	require_once('include/auth.php');
	require_once('class/class.familyid.php');
	$objfamilyid = new Familyid();

	$action = "";
	$action = $_GET["action"];
	$id = $_GET["id"];
	$msgD = '';
	
		
	if($action=="Edit")
	{
	    
		$btnvalue = "UPDATE";
		$data = $objfamilyid->getById($id);
		
	}elseif($action=="Add")
	{
		
		$familyid = $objfamilyid->getFamilyID();
		$btnvalue = "SAVE";
		
	}else{
		$btnvalue = "";
		$alldata = $objfamilyid->getAll();
	}
	
	if(isset($_POST['submit']))
	{
		$objfamilyid->save();
		exit();
	}

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Bootstrap time Picker -->
    <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
    <!-- Date Picker -->
    <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<script type="text/javascript" language="javascript">

		function validatefamilyid(){
            
            if(document.getElementById('familyid').value =='' )
            {
				alert('Please enter familyid name!');
				document.getElementById('familyid').focus();
				return false;
			}else if(document.getElementById('shortname').value =='' )
            {
				alert('Please enter shortname!');
				document.getElementById('shortname').focus();
				return false;
			}
			else{
				return true;
			}
			
      	}
	
	</script>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
     
   <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objfamilyid->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objfamilyid->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Family ID Master
          </h1>
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
            <li>Control Panel</li>
            <li class="active">Family ID Master</li><li class="active"><?php echo $action; ?></li>
          </ol>
        </section><!--CONTENT HEADER-->
        <?php if($action == 'Add' || $action == 'Edit'){?>
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title"><?php echo $action; ?> Source Text</h3><span style='float:right'>Fields marked with a asterisk (<font color='red'>*</font>) are mandatory.</span>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <form action="" name="Sourcemaster" id="Sourcemaster" method="post" >
							<div class="row">
								<div class="col-lg-12">	
									<div class="col-lg-6">
										<div class="form-group">
											<label>Family ID<font color='red'>*</font></label>
											<input type="text" class="form-control" id="familyid" readonly name="familyid" placeholder="Enter familyid" value="<?php if($action=="Edit"){echo $data['familyid'];}else{echo $familyid['fmi_id'];} ?>">
										</div><!-- /.form-group -->
									</div><!-- /.col -->
								  
									<div class="col-lg-6">
										<div class="form-group">
											<label for="name">Short Name<font color='red'>*</font> </label>
											<input type="text" class="form-control" id="shortname" name="shortname" placeholder="Enter shortname" value="<?php echo $data['shortname']; ?>">
											<input type="hidden" id="id" name="id" value="<?php echo $data['id']; ?>" />
										</div>
										
									</div><!-- /.col -->
								</div><!-- /.col -->

								<div class="col-lg-12">	
									<div class="col-lg-6">
										<div class="form-group">
											<label>Long Name</label>
											<input type="text" class="form-control" id="longname"  name="longname" placeholder="Enter longname" value="<?php echo $data['longname']; ?>">
										</div><!-- /.form-group -->
									</div><!-- /.col -->
								  
									<div class="col-lg-6">
										<div class="form-group">
											<label for="name">Address</label>
											<input type="text" class="form-control" id="address" name="address" placeholder="Enter address" value="<?php echo $data['address']; ?>">
										</div>										
									</div><!-- /.col -->
								</div><!-- /.col -->
								
								<div class="col-lg-12">	
									<div class="col-lg-6">
										<div class="form-group">
											<label>Contact Number</label>
											<input type="text" class="form-control" id="contactno"  name="contactno" placeholder="Enter contact no" value="<?php echo $data['contactno']; ?>">
										</div><!-- /.form-group -->
									</div><!-- /.col -->
								
									<div class="col-lg-6">
										<div class="form-group">
											<label for="name">Email</label>
											<input type="text" class="form-control" id="email" name="email" placeholder="Enter email" value="<?php echo $data['email']; ?>">
										</div>										
									</div><!-- /.col -->
								</div><!-- /.col -->
								
                           </div><!-- /.row -->
                           
                           <div class="row">
                              <div class="col-lg-12">
                                   <div class="form-group center">
                                      <input type="submit" name="submit" id="submit" class="btn btn-warning left-10" value="<?php echo $btnvalue; ?>" onclick="return validatefamilyid();" />
									  <a href="managefamilyid.php" class="btn btn-warning left-10">View All</a>
                                   </div>
                               </div><!-- /.col -->
             				 </div><!-- /.row -->
                           </form>
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
		<?php }else{ ?>
		
		<section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title pull-right"><a href="managefamilyid.php?action=Add&id=">Add New</a></h3>
                        </div><!-- /.box-header -->
                        <div class='box-body table-responsive'>
                            <table id="example111" class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>Familyid</th>
									<th>Short Name</th>
									<th>Long Name</th>
									<th>Action</th>							
								</tr>
							</thead>
							<tbody>
							<?php for($i=0; $i<count($alldata); $i++) { ?>	
								<tr>
									<td><?php print $alldata[$i]['familyid']; ?></td>
									<td><?php print $alldata[$i]['shortname']; ?></td>
									<td><?php print $alldata[$i]['longname']; ?></td>
									<td><a href="managefamilyid.php?action=Edit&id=<?php print $alldata[$i]['id']; ?>">Edit</a></td>
								</tr>
							<?php } ?>						
							</tbody>
                    
                  </table>
                           
                          </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
            </div><!-- /.row -->
        </section><!--CONTENT-->		
		<?php } ?>
		
      </div><!-- /.content-wrapper -->
      
      
      <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
    
    <!-- daterangepicker -->
    <script src="dist/js/moment.min.js"></script>
    <!-- bootstrap time picker -->
    <script src="plugins/timepicker/bootstrap-timepicker.js"></script>
    <!-- iCheck 1.0.1 -->
    <script src="plugins/iCheck/icheck.min.js"></script>
    <script src="plugins/daterangepicker/daterangepicker.js"></script>
    <!-- datepicker -->
    <script src="plugins/datepicker/bootstrap-datepicker.js"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js"></script>
    
    <script type="text/javascript" src="plugins/datepicker/bootstrap-clockpicker.min.js"></script>
    
    <script type="text/javascript" src="dist/js/date.js"></script>
    
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <script>
		$("#message").fadeIn('slow').delay(5000).fadeOut('slow');
		$(".select2").select2();
		  //Date range picker
        $('#reservation').daterangepicker();
		
		//Date range picker with time picker
        $('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 1, format: 'MM/DD/YYYY h:mm A'});
		
		//iCheck for checkbox and radio inputs
        $('input[type="radio"].minimal').iCheck({
           radioClass: 'iradio_minimal-orange'
        });
		
		var input = $('#input-a');
		input.clockpicker({
		autoclose: true
		});
		
		//check all
		$("#id_0").click(function () {
        if ($("#id_0").is(':checked')) {
            $("input[type=checkbox]").each(function () {
                $(this).prop("checked", true);
            });

        } else {
            $("input[type=checkbox]").each(function () {
                $(this).prop("checked", false);
            });
        }
    });
	
	
	</script>
  </body>
</html>