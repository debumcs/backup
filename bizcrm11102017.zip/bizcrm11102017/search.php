<?php 
session_start();

error_reporting(-1);
require_once('class/class.search.php');
$objcus = new Search();

if($_POST['task'] == 'search')
{	
	$search	= trim($_POST["search"]);
	$option	= trim($_POST["option"]);
	
	if($option)
	{	
		$Custdataa = $objcus->getSearchDetail($option,$search);		
	}
}

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>BIZCRM | Search</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Bootstrap time Picker -->
    <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
    <!-- Date Picker -->
    <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
<style type="text/css">
    @media screen and (min-width: 768px) {
        .modal-dialog {
          width: 770px; /* New width for default modal */
        }
        .modal-sm {
          width: 350px; /* New width for small modal */
        }
    }
    @media screen and (min-width: 992px) {
        .modal-lg {
          width: 950px; /* New width for large modal */
        }
    }
	
	
	.modal-title {
  margin: 0;
  line-height: 1.42857143;
  
  
   padding:9px 15px;
    border-bottom:1px solid #eee;
    background-color: #2A3F54;
	color: #fff;
	float : center;
    -webkit-border-top-left-radius: 5px;
    -webkit-border-top-right-radius: 5px;
    -moz-border-radius-topleft: 5px;
    -moz-border-radius-topright: 5px;
     border-top-left-radius: 5px;
     border-top-right-radius: 5px;
	 
}

</style>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
     
   <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objcus->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objcus->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
           Search
          </h1><br />
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <!--li>Search</li-->
            
          </ol>
        </section><!--CONTENT HEADER-->
        
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
					<?php if(($Custdataa)) 
					{ ?>
							<div class='box-header'><h3 class="box-title">Customer Details</h3></div>
							<div class='box-body table-responsive'>
							<table id="OrderPackages" class="table table-bordered table-striped">
							<thead>
                                              <tr>
                                                  <th></th>
                                                  <th>Customer Id </th>
                                                  <th>Full Name</th>
                                                  <th>Email</th>
                                                  <th>Contact No.</th>
                                                  <th>Address</th>
                                                  <th>Notes</th>
                                              </tr>
                                          </thead>
							<?php  foreach($Custdataa as $Custdata){ ?>
								<tr> 	
									<td style='display: inline-block;position: relative;top: 1px;left: 5px;' class="accordion-toggle" data-toggle="collapse" data-parent="#OrderPackages" data-target=".packageDetails<?php echo $Custdata['cust_id']; ?>"><i class="indicator glyphicon pull-right glyphicon-chevron-down"></i></td>
									<td><a href="#" id="addpayment" data-toggle="modal" data-target="#getCutomerbyId" onclick='getCutomerbyId("<?php echo $Custdata['cust_id']; ?>")'><?php print $Custdata['cust_id']; ?></a></td>
									<td><?php print $Custdata['salutation'].' '.$Custdata['name_first'].' '.$Custdata['name_last']; ?></td>
									<td><?php print $Custdata['email_1']; if($Custdata['email_2']!='') { echo "<br>".$Custdata['email_2']; } ?></td>
									<td><?php print $Custdata['contact_no1']; if($Custdata['contact_no2']!='') { echo "<br>".$Custdata['contact_no2']; } ?></td>
									<td><?php print $Custdata['address1']; if($Custdata['address1']!='') { echo "<br>".$Custdata['address1']; } ?></td>
									<td><a href="#" id="addpayment" data-toggle="modal" data-target="#cusnotes<?php echo $Custdata['cust_id']; ?>">Notes</a> | <a href="#" id="addpayment" data-toggle="modal" data-target="#getPayment" onclick='getpaymentstaticsByCudtid("<?php echo $Custdata['cust_id']; ?>")'>Payment Statistics</a>
									</td>
								</tr>
								<?php 
								$Orderdata = $objcus->getorderDetail($Custdata['cust_id']);
								
								if(count($Orderdata)) 
								{ ?>
								<tr><td colspan='7' style="padding:0!important;background-color: #f1e9de;">
                                                        <div id="OrderPackages1" class="packageDetails<?php echo $Custdata['cust_id']; ?> collapse" style="width: 91%; margin: 1% 4%; background: rgb(221, 221, 221) none repeat scroll 0% 0%; height: 0px;">
								<table  class="table table-bordered table-striped inner-table" width='100%'>
							    <thead>
								<tr style="background-color:#D4AE87;">
									<th><b>Order No</b></th>
									<th><b>Order Detail</b></th>
									<th><b>Quantity</b></th>
									<th><b>Order Date</b></th>
									<th><b>Sale Amount</b></th>
									<th><b>Dilevery Status</b></th>
									<th colspan="2"><b>Action</b></th>
								</tr>	
								</thead>
								<tbody>
								<?php	
								
								foreach($Orderdata as $Orderdata)
                                { ?>	
									<tr>
										<td><a href="#" id="addpayment" data-toggle="modal" data-target="#orderdetails" onclick='getOrderbyno("<?php echo $Orderdata['orderno'];?>")'><?php echo $Orderdata['orderno']; ?></a></td>
										<td width="36%"><?php echo $Orderdata['order_detail']; ?></td>
										<td><?php echo $Orderdata['quantity']; ?></td>
										<td><?php echo $Orderdata['order_date']; ?></td>
										<td><?php echo $Orderdata['sale_amount']; ?></td>
							
										<td><a href="#" data-toggle="modal" data-target="#getPaymentDetails" onclick='getPaymentDetailsByOrderno("<?php echo $Orderdata['orderno']; ?>")'>Payment Details</a></td>
										<td><a href="#" id="addpayment" data-toggle="modal" data-target="#ordernotes<?php echo $Orderdata['id']; ?>" onclick='getnotes("<?php echo $Orderdata['id']; ?>","<?php echo $Orderdata['orderno']; ?>")'>Order Notes</a></td>
									</tr>
							
		<div class="modal fade" id="ordernotes<?php echo $Orderdata['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="addMyPaymentLabel">
		  <div class="modal-dialog" role="document">
			<form action="search.php" method="post" name="payment" id="payment" data-toggle="validator" role="form" novalidate="true">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Order Notes</h4>
			  </div>
			  <div class="modal-body">
				<div class="row">
					<div class="col-lg-12">
						<div class='table table-bordered table-striped' >
							<div id='dordernotes<?php echo $Orderdata['id']; ?>' class='orderdiv '></div>
						</div>
					</div>
							  
							  <br /><br />
							  <div class="col-lg-12">
                              		<div class="form-group">
                                      <label for="name">Enter Notes</label>
                                      <textarea  class="form-control" id="order_note<?php echo $Orderdata['id']; ?>" name="order_note" placeholder="Enter Notes" required></textarea>
                                    </div> 
									
									</div>
                                    
                                   
                                    
                              </div><!-- /.col -->                             
                              
                           </div><!-- /.row -->
			  </div>
			  <div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<input type="hidden" name="order_id"  id="order_id<?php echo $Orderdata['id']; ?>" class="btn btn-warning left-10" value="<?php echo  $Orderdata['orderno']; ?>" />
					<input type="hidden" name="agent_id"  id="agent_id<?php echo $Orderdata['id']; ?>" class="btn btn-warning left-10" value="<?php echo  $_SESSION['ADMIN_NAME']; ?>" />
					<input name="ipaddress" type="hidden" id="ipaddress" value="<?php echo $_SERVER['REMOTE_ADDR'];?>" >				 
					<input type="button" class="btn btn-primary" name="savePayment" id="savePayment" value="Save" onclick='addOrdernotes("<?php echo $Orderdata['id']; ?>");' />
			  </div>
			</div>
			</form>
		  </div>
		</div>
									
								<?php } 
								
								
								
								?>
										</tbody>
									</table>
                                                        </div>
						</td>
							 </tr>
								<?php
								}else{ ?> 
								
							<tr>
								<td colspan='7' style="padding: 0px !important;">
									<table id="OrderPackages1" class="table table-bordered table-striped packageDetails<?php echo $Custdata['cust_id']; ?> collapse" width='100%'>
										<tr style="background-color:#D4AE87;" ><th><b>No record found</b></th></tr>
									</table>
								</td>
							</tr>								
								<?php }?>	
								
		<div class="modal fade" id="cusnotes<?php echo $Custdata['cust_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="addMyPaymentLabel">
		  <div class="modal-dialog" role="document">
			<form method="post" name="payment" id="payment">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Customer Notes</h4>
			  </div>
			  <div class="modal-body">
				<div class="row">
                              <div class="col-lg-12">
							  <?php 
							  
							    $notes = $objcus->getCustomerNotes($Custdata['cust_id']);	
			
                                ?> 
							  
							   <div>

							  <div id="cus_note_tbl<?php echo  $Custdata['cust_id']; ?>" class="orderdiv">
							    <?php
							  foreach($notes as $n)
							  {
								  ?>
							  <div class="row">  
							  <div class="col-lg-12">
							    <b> Note :-  </b>
							    <?php echo $n['notes']; ?>
							
							  </div>
							 
							  <div class="col-lg-6">
							   <b>  Date:-  </b> 
							  <?php echo $objcus->date_ymd_dmy($n['notes_date']); ?>
							  
							  </div>
							   <div class="col-lg-6">
							    <b>  Added By:-  </b> 
							  <?php echo $n['name'].' ('.$n['agent_id'].')'; ?>
							  
							  </div>
							  
							 </div>  
							<hr />
						    <?php		  
							  }?>
                                    
                              </div>
							 
                                    
                              </div><!-- /.col -->  
                              <div class="form-group">
                                      <label for="name">Enter Notes</label>
                                      <textarea  class="form-control" id="cus_note<?php echo  $Custdata['cust_id']; ?>" name="cus_note" placeholder="Enter Notes"></textarea>
                                    </div>
                                    
                                   
                                    
                              </div><!-- /.col -->                             
                              
                           </div><!-- /.row -->
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				 <input type="hidden" name="task"  class="btn btn-warning left-10" value="cus_notes" />
				 <input type="hidden" name="cust_id" id ='cust_id'  value="<?php echo  $Custdata['cust_id']; ?>" />
				 <input type="hidden" name="agent_id"  id="agent_id"  value="<?php echo  $_SESSION['ADMIN_NAME']; ?>" />
				  <input name="ipaddress" type="hidden" id="ipaddress" value="<?php echo $_SERVER['REMOTE_ADDR'];?>" >
				<input type="button" class="btn btn-primary" name="savePayment" id="savePayment" value="Save" onclick='addnotes("<?php echo  $Custdata['cust_id']; ?>")'/>
			  </div>
			</div>
			</form>
		  </div>
		</div>
		
		 
		
		 
						<?php } ?>
								</tbody>									
							</table>
							</div>
							
							
							
			<?php 	} 
					else { ?>
					<div class='box-header'><h3 class="box-title">Search Result</h3></div>
							<div class='box-body'>
							<table class="table table-bordered table-striped">
							<thead>
							  <tr><th>Search result not found.</th></tr>
							</thead>
						
							</table>
							</div>
					<?php } ?>
						
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
		
		
		
		
      </div><!-- /.content-wrapper -->

      
      <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->

<!-- modal start -->

<div class="modal fade" id="getCutomerbyId" tabindex="-1" role="dialog" aria-labelledby="getCutomerbyIdLabel"  >
	<div class="modal-dialog" role="document">
		<div class="modal-content" >
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Customer Details </h4>
			</div>
			
			<div class="modal-body" >
				<div class="row">
					<div id="getCustomer">

					</div><!-- /.col -->
				</div><!-- /.row -->
			</div>
			
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>		
		</div>
	</div>
</div>

	
<div class="modal fade" id="orderdetails" tabindex="-1" role="dialog" aria-labelledby="orderdetailsLabel">
	<div class="modal-dialog" role="document">	
	<div class="modal-content">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">Order Details </h4>
		</div>
		<div class="modal-body">
			<div class="row">
				<div class="col-lg-12" id="orderdata">


				</div><!-- /.col -->
			</div><!-- /.row -->
		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		</div>
	</div>	
	</div>
</div>

<div class="modal fade" id="getPaymentDetails" tabindex="-1" role="dialog" aria-labelledby="getPaymentDetailsLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Pyament Details</h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-lg-12" id="getPaymentDetailsByOrderNo">
						<!-- Get data here through ajax -->
					</div><!-- /.col -->
				</div><!-- /.row -->
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>				
			</div>
		</div>
	</div>
</div>
      	
<div class="modal fade" id="getPayment" tabindex="-1" role="dialog" aria-labelledby="addMyPaymentLabel">
	<div class="modal-dialog" role="document">
	<form method="post" name="payment" id="payment">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Payment Statistics </h4>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-lg-121">
						<div id="getpaymentstaticsByCudtid">

						</div>
					</div><!-- /.col -->
				</div><!-- /.row -->
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>				
			</div>
		</div>
	</form>
	</div>
</div>

<!-- modal end -->
	
    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
    
    <!-- daterangepicker -->
    <script src="dist/js/moment.min.js"></script>
    <!-- bootstrap time picker -->
    <script src="plugins/timepicker/bootstrap-timepicker.js"></script>
    <!-- iCheck 1.0.1 -->
    <script src="plugins/iCheck/icheck.min.js"></script>
    <script src="plugins/daterangepicker/daterangepicker.js"></script>
    <!-- datepicker -->
    <script src="plugins/datepicker/bootstrap-datepicker.js"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <!--script src="dist/js/pages/dashboard.js"></script-->
    
    <script type="text/javascript" src="plugins/datepicker/bootstrap-clockpicker.min.js"></script>
    
    <script type="text/javascript" src="dist/js/date.js"></script>
    
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <script>
		$("#message").fadeIn('slow').delay(5000).fadeOut('slow');
		$(".select2").select2();
		
function addnotes(cid){
	
	var note = $("#cus_note"+cid).val();
	var cust_id = cid;
	var agent_id = $("#agent_id").val();
	var ipaddress = $("#ipaddress").val();

	if(note == ''){
		alert('Please enter notes!');
		return false;
	}

	var task = 'cus_notes';
	$.ajax({
		type: "GET",
		url: "ajax.php",
		data: {cus_note:note,task:task,cust_id:cust_id,agent_id:agent_id,ipaddress:ipaddress},

		success: function(data){
			console.log(data);
			$("#cus_note_tbl"+cust_id).html('');
			$("#cus_note"+cust_id).val('');
			$("#cus_note_tbl"+cust_id).html(data);
			return false;
		}
	});

	return false;
}

function addOrdernotes(id){
	var  order_id= $("#order_id"+id).val();
	//var  status= $("#status"+id).val();
	var agent_id = $("#agent_id"+id).val();
	var  ipaddress= $("#ipaddress").val();
	var note = $("#order_note"+id).val();
	if(note == ''){
		alert("Please enter note!");
		return false;
	}
	var task = 'addOrdernotes';
	$.ajax({
		type: "GET",
		url: "ajax.php",
		data: {order_note:note,task:task,order_id:order_id,agent_id:agent_id,ipaddress:ipaddress},
		success: function(data){
			console.log(data);
			$("#dordernotes"+id).html('');
			$("#order_note"+id).val('');
			$("#dordernotes"+id).html(data);
			return false;
		}
	});
	
	return false;
}


function getnotes(id,order_no){
	var  order_id = order_no;
	var task = 'getnotes';
	$.ajax({
		type: "GET",
		url: "ajax.php",
		data: {task:task,order_id:order_id},

		success: function(data){
			console.log(data);
			$("#dordernotes"+id).html('');
			$("#order_note"+id).val('');
			$("#dordernotes"+id).html(data);
			return false;
		}
	});
	return false;
}

function getOrderbyno(order_no){
	var  order_id = order_no;
	var task = 'getOrderbyno';
	$.ajax({
		type: "GET",
		url: "ajax.php",
		data: {task:task,order_id:order_id},

		success: function(data){
			console.log(data);
			$("#orderdata").html('');
			$("#orderdata").html(data);
			return false;
		}
	});

	return false;
}

function getCutomerbyId(cust_id){
	var task = 'getCustomer';
	$.ajax({
		type: "GET",
		url: "ajax.php",
		data: {task:task,cust_id:cust_id},
		success: function(data){
			console.log(data);
			$("#getCustomer").html('');
			$("#getCustomer").html(data);
			return false;
		}
	});
	return false;
}

function getPaymentDetailsByOrderno(orderno){
	var task = 'getPaymentDetailsByOrderNo';
	$.ajax({
		type: "GET",
		url: "ajax.php",
		data: {task:task,orderno:orderno},
		success: function(data){
			console.log(data);
			$("#getPaymentDetailsByOrderNo").html('');
			$("#getPaymentDetailsByOrderNo").html(data);
			return false;
		}
	});
	return false;
}

function getpaymentstaticsByCudtid(cust_id){
	var task = 'getpaymentstaticsByCudtid';
	$.ajax({
		type: "GET",
		url: "ajax.php",
		data: {task:task,cust_id:cust_id},

		success: function(data){
			console.log(data);
			$("#getpaymentstaticsByCudtid").html('');
			$("#getpaymentstaticsByCudtid").html(data);
			return false;
		}
	});
	return false;
}
</script>
  </body>
</html>