<?php 
echo "<footer class='main-footer'><strong>Copyright &copy; ".date('Y')." ".$PRO_TITLE." </strong> All rights reserved.</footer>";
?>
