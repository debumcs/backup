<?php
	session_start();
	include_once("class/class.postlogin2.php");
	//error_reporting(E_ALL);  
	
	$objpostlogin=new postlogin();  
	$username = $objpostlogin->sanitize($_POST['username']);
	$password = $objpostlogin->sanitize($_POST['password']);
	$ipaddress =$objpostlogin->sanitize($_POST['ipaddress']);
	
	$errmsg_arr = array();

	//Validation error flag
	$errflag = false;
	
	//Input Validations
	if($username == '') {
		$errmsg_arr[] = 'Login ID missing';
		$errflag = true;
	}
	
	if($password == '') {
		$errmsg_arr[] = 'Password missing';
		$errflag = true;
	}
	
	//echo $username.' '.$password.'<br>';	
	//die();
	
	//If there are input validations, redirect back to the login form
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();
		header("location: index.php");
		exit();
	}
	$objpostlogin->getuserlogin($username,$password,$ipaddress);
	
?>