<?php  
	require_once('include/auth.php');
	require_once('class/class.customer.php');
	require_once('class/class.category.php');
	require_once('class/class.familyid.php');
	require_once('class/class.source.php');
	require_once('class/class.salutation.php');
	require_once('class/class.relation.php');
	
	$objcategory 	= new Category();
	
	$objfamilyid 	= new Familyid();
	$allfamilyid	= $objfamilyid->getAll();
	
	$objrelation 	= new Relation();
	$allrelation 	= $objrelation->getAll();
	
	$objsalutation 	= new Salutation();
	$allsalutation	= $objsalutation->getAll();
	
	$objsource 		= new Source();
	$allsource 		= $objsource->getAll();
	
	$objcus 		= new Customer();	
	$allcountry 	= $objcus->getCountry();
	
	$config			= $objcus->getConfig();
	
	
	//die();
	$action = $_GET["action"];
	$id 	= $_GET["id"];

	$msgD = '';//checkCustomerID:'checkCustomerID'

	if($_REQUEST['checkCustomerID']=='checkCustomerID')
	{
		$cust_id = $_POST['cust_id'];
		$objsta = new Customer();
		$data 	= $objsta->checkCustomerCode($cust_id);
		
		if($data['total'] < 1){
			echo "1";
		}else{
			echo "0";
		}
		exit;
	}
	
	if($_REQUEST['getReferal']=='checkReferal')
	{
		$referal_id = $_POST['referal_id'];
		$objsta = new Customer();
		$data 	= $objsta->checkReferalCode($referal_id);
		
		if($data['rstatus'] == 1){
			echo "<span class='refferal_success'>Valid Code, referrer name is ".$data['referrer_name']."</span>";
		}else{
			echo "0";
		}		
		exit;
	}
	
	if($_REQUEST['getState']=='ajaxState')
	{
		$id = $_POST['id'];
		$objsta = new Customer();
		$allstate = $objsta->getState($id);
		
		echo '<select class="form-control select2" tabindex="9" id="state" name="state" style="width:100%;" onchange="getCity(this.value);"><option value="">Select</option>';
		for($si=0; $si<count($allstate); $si++) {
			echo "<option value='".$allstate[$si]['id']."' $selected >".$allstate[$si]['name']."</option>"; 
		}
		echo '</select>';		
		exit;
	}
	
	if($_REQUEST['getCity']=='ajaxCity')
	{
		$id = $_POST['id'];
		$objcity = new Customer();
		$allcity = $objcity->getCity($id);
		
		echo '<select class="form-control select2" tabindex="10" id="city" name="city" style="width:100%;"><option value="">Select</option>';
		for($cti=0; $cti<count($allcity); $cti++) {			
			echo "<option value='".$allcity[$cti]['id']."' >".$allcity[$cti]['name']."</option>"; 
		}
		echo '</select>';		
		exit;
	}
	
	if($action=="edit")
	{  
		$data = $objcus->getById($id);  
        $btnvalue = "UPDATE";
	}
	else
	{
		if($config['customerid'] == '1'){
			$CustomerID = $objcus->getCustomerID();
		}
		$btnvalue = "SAVE";
	}
		
	
if(isset($_POST['submit']))
{
	$objcus->save();
	exit();
}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css"></link>
	<link rel="stylesheet" href="bootstrap/css/datepicker.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    
	<!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	
	
	<script type="text/javascript" language="javascript">
	
	
	
	function check_customer_id(cust_id){
		if(cust_id != ''){
			$.ajax({
				url: "customer.php",
				type: 'POST',
				context: this,
				data: {checkCustomerID:'checkCustomerID',cust_id:cust_id},
				success: function(response){
					if(response == '1'){
						var check_referel = "<span class='refferal_success'>Valid ID!</span>";
					}else{
						var check_referel = "<span class='refferal_failure'>Customer ID '"+cust_id+"' is already exist!</span>";
						$('#cust_id').val('');
					}
					$('#customer_id_html').html(check_referel);					
				}
			});
		}else{
			$('#customer_id_html').html('');
		}		
	}
	
	function check_referal_id(referal_id){
		if(referal_id != ''){
			$.ajax({
				url: "customer.php",
				type: 'POST',
				context: this,
				data: {getReferal:'checkReferal',referal_id:referal_id},
				success: function(response){
					if(response == '0'){
						var check_referel = "<span class='refferal_failure'>Invalid ID!</span>";
					}else{
						var check_referel = response;
						$('#cust_id').val('');
					}
					
					$('#refferal_id_html').html(check_referel);
				}
			});
		}else{
			$('#refferal_id_html').html('');
		}		
	}
		
	function getState(stateid){
		
		$.ajax({
			url: "customer.php",
			type: 'POST',
			context: this,
			data: {getState:'ajaxState',id:stateid},
			success: function(response){
				$('#ajaxstate').html(response);
			}
		});			
	}
		
	function checkIt(evt)
	{
		evt = (evt) ? evt : window.event
		var charCode = (evt.which) ? evt.which : evt.keyCode
		if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode != 43)
		{
			status = "This field accepts numbers only.";
			return false;
		}
		status = "";
		return true ;
	}
	
	function checkalphanumeric(evt)
	{
		evt = (evt) ? evt : event;
		var charCode = (evt.charCode) ? evt.charCode : ((evt.keyCode) ? evt.keyCode :((evt.which) ? evt.which : 0));
		if (charCode == 8) {
			return true;
		} else if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 122)) {
			// alert("Enter letters only.");
			return false;
		}
		return true;
	}

	
	function getCity(cityid){
	
		$.ajax({
			url: "customer.php",
			type: 'POST',
			context: this,
			data: {getCity:'ajaxCity',id:cityid},
			success: function(response){
				$('#ajaxcity').html(response);
			}
		});
		
	}
	
	function validateEmail(email) {
		var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		return re.test(email);
	}
	  
	function validateuser(){
		var DOB 		    	= $("#dob").val();
		var Anniversarydate	    = $("#anniversary").val();

		if(document.getElementById("cust_id").value=="")
		{
			alert("Please enter customer id.");
			document.getElementById("cust_id").focus();
			return false;
		}else if(document.getElementById("salutation").value=="")
		{
			alert("Please Select Salutation.");
			document.getElementById("salutation").focus();
			return false;
		}else if(document.getElementById("name_first").value=="")
		{
			alert("Please Enter First Name.");
			document.getElementById("name_first").focus();
			return false;
		}else if(document.getElementById("name_last").value=="")
		{
			alert("Please Enter Last Name.");
			document.getElementById("name_last").focus();
			return false;
		/*}else if(document.getElementById("address2").value=="")
		{
			alert("Please Enter Address");
			document.getElementById("address2").focus();
			return false;
		}else if(document.getElementById("country").value=="")
		{
			alert("Please Select Country.");
			document.getElementById("country").focus();
			return false;
		}else if(document.getElementById("state").value=="")
		{
			alert("Please Select State.");
			document.getElementById("state").focus();
			return false;
		}else if(document.getElementById("city").value=="")
		{
			alert("Please Select City.");
			document.getElementById("city").focus();
			return false;
		}else if(document.getElementById("pin").value=="")
		{
			alert("Please Enter Pin Code.");
			document.getElementById("pin").focus();
			return false;
            */
		}else if(document.getElementById("contact_no1").value.length < 10)
		{
			alert("Please enter 10 digit mobile number.");
			document.getElementById("contact_no1").focus();
			return false;
        }/*else if(document.getElementById("email_1").value==""){
			alert("Please Enter email id.");
			document.getElementById("email_1").focus();
			return false;
            }else if(document.getElementById("email_1").value!=""){
                var isValid = validateEmail(document.getElementById("email_1").value);
                if(isValid==false){
                    alert("Please Enter email id.");
                    document.getElementById("email_1").focus();
                    return false;
                }
		}*/
		else{
			return true;
		}
	}
</script>
<style>
.form-control2 {
    display: block;
    width: 100%;
    height: 34px;
    font-size: 14px;
    line-height: 1.42857;
    color: #555;
    background-color: #FFF;
    background-image: none;
}
.refferal_failure{
	color:#f37c12;
}
.refferal_success{
	color:#00a65a;
}
.alt-phone{
	width:42%;
	float:left;
	margin-right:5px;
}

.addremove{
	padding:5px;
	float:left;
}

.ptest {
    clear: both;
    padding-top: 2px;
}
.connecting_preference_checkbox{
	display:block !important; 
	float:left; 
	width:20px;
}
.connecting_preference_box{
	display: block;
	float: left;
	width: 30%;
}

</style>
  </head>
  <body class="hold-transition skin-blue sidebar-mini" >
     
  <!-- <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?> -->
   <div class="wrapper">
		<?php $objcus->psheader(); ?>
		<?php $objcus->pssidebar(); ?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
           <?php if($action=="edit") { ?> Edit Customer <?php }else { ?> Add Customer<?php } ?>
          </h1>
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Control Panel</li>
            <li class="active">Add Customer</li>
          </ol>
        </section><!--CONTENT HEADER-->
        
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title">Customer Details</h3> <?php echo $MAND_INSTRUCTION;?>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <form action="" name="userCreate" id="userCreate" method="post" >
							<div class="row">
							
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Customer ID</label><?php echo $MANDATORY;?>
											<?php if($config['customerid'] == '1'){	?>
												<input type="text" tabindex="1" class="form-control" id="cust_id" name="cust_id" readonly value="<?php echo $CustomerID['cus_id']; ?>">
											<?php }else{ ?>
												<input type="text" tabindex="1" class="form-control" id="cust_id" name="cust_id" <?php if($action=="edit"){echo 'readonly';}else{echo 'onblur="check_customer_id(this.value);"';}?> placeholder="Enter Customer ID" value="<?php if($action=="edit"){echo $data['cust_id'];}else{echo $customerId['cus_id'];} ?>">
											<?php } ?>
											
											<p id="customer_id_html"></p>
											<input type="hidden" id="id" name="id" value="<?php echo $data['id']; ?>" />
											<input type="hidden" name="registrationfrom" value="admin" />
										</div>
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Salutation</label><?php echo $MANDATORY;?>
											<select class="form-control select2" id="salutation" name="salutation" tabindex="2"  style="width:100%;">
											<option value="" <?php if($data['salutation']=="") echo "selected";?>>Select</option>
											<?php 				
											for($sli=0; $sli<count($allsalutation); $sli++) {
												if($data['salutation'] == $allsalutation[$sli]['salutation']){$selected="selected";}else{$selected="";}
												echo "<option value='".$allsalutation[$sli]['salutation']."' $selected >".$allsalutation[$sli]['salutation']."</option>"; 
											}
											?>
											</select>
										</div>										  
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">First Name</label><?php echo $MANDATORY;?>
										  <input type="text" class="form-control" tabindex="3"  id="name_first" name="name_first" placeholder="Enter First Name" value="<?php echo $data['name_first']; ?>">
										</div>
									</div><!-- /.col -->									
								</div>
								
								<div class="col-lg-12">
									
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Last Name</label>
										  <input type="text" class="form-control" tabindex="4"  id="name_last" name="name_last" placeholder="Enter Last Name" value="<?php echo $data['name_last']; ?>">
										</div>									  
									</div><!-- /.col -->									
									
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">DOB</label>
										  <input type="text" tabindex="5" class="form-control datepicker" id="dob" name="dob" placeholder="Enter DOB(Format: DD/MM/YYYY)" value="<?php if($action=="edit"){echo date("d/m/Y",strtotime($data['dob']));} ?>">
										</div>	
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
										<label for="name">Marital Status</label>
										<div style="width:100%;"><input tabindex="6" type="radio" id="marital_status1" name="marital_status" value="Married">Married
										<input type="radio" id="marital_status2" name="marital_status" value="UnMarried">UnMarried</div>
										</div>
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Aniv. Date</label>
										  <input type="text" tabindex="7" class="form-control datepicker" id="anniversary" name="anniversary" placeholder="Format: DD/MM/YYYY" value="<?php if($action=="edit"){echo date("d/m/Y",strtotime($data['anniversary']));} ?>">
										</div>	
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Address</label>
										  <input type="text" class="form-control" id="address2" name="address2" tabindex="8"  placeholder="Enter Address" value="<?php echo $data['address2']; ?>">
										</div>									  
									</div><!-- /.col -->	
									
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Country</label>
											<select class="form-control select2" id="country" name="country" style="width:100%;" tabindex="9" onchange="getState(this.value);">
											<option value="" selected>Select</option>
											<?php 				
											for($ci=0; $ci<count($allcountry); $ci++) {
												if($data['country']==$allcountry[$ci]['id']){$selected="selected";}
												else if($allcountry[$ci]['id'] == '101'){$selected="selected";}
												else{$selected="";} 				 
												echo "<option value='".$allcountry[$ci]['id']."' $selected >".$allcountry[$ci]['name']."</option>"; 
											}
											?>
											</select>
										</div>
									</div><!-- /.col -->
									
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">						
										<div class="form-group">
										  <label for="name">State</label>
										  <div id="ajaxstate" style="width:100%;">
												<?php
												if(isset($data['country']))
												{
													$allstate = $objcus->getState($data['country']);
													echo '<select class="form-control select2" tabindex="10" id="state" name="state" style="width:100%;" onchange="getCity(this.value);"><option value="">Select</option>';
													for($si=0; $si<count($allstate); $si++)
													{
														if($data['state']==$allstate[$si]['id']){$selected="selected";}else{$selected="";}
														echo "<option value='".$allstate[$si]['id']."' $selected >".$allstate[$si]['name']."</option>";
													}
													echo '</select>';
												}
												else{
													echo '<select class="form-control select2" tabindex="10" id="state" name="state" style="width:100%;">
													<option value="" selected>Select</option>
													</select>';
												}
												?>
											</select>
											</div>
										</div>									  
									</div><!-- /.col -->
									
									
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">City</label>
										  <div id="ajaxcity" style="width:100%;">
                     					<?php 
											if(isset($data['state'])){
												$allcity = $objcus->getCity($data['state']);

												echo '<select class="form-control select2" id="city" tabindex="11" name="city" style="width:100%;"><option value="">Select</option>';
												for($cti=0; $cti<count($allcity); $cti++) {
													if($data['city']==$allcity[$cti]['id']){$selected="selected";}else{$selected="";}  			
													echo "<option value='".$allcity[$cti]['id']."' $selected >".$allcity[$cti]['name']."</option>"; 
												}
												echo '</select>';	
												}else
												{
												echo '<select class="form-control select2" tabindex="11" id="city" name="city" style="width:100%;">
												<option value="" selected>Select</option>
												</select>';
											}
										?>				
 
											</div>
										</div>
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Pin Code</label>
										  <input type="text" class="form-control" id="pin" name="pin" onKeyPress="return checkalphanumeric(event);" placeholder="Enter Pin Code" tabindex="12" maxlength="8" value="<?php echo $data['pin']; ?>">
										</div>			  
									</div><!-- /.col -->
									
								</div>
								
								<div class="col-lg-12">
									
									<div class="col-lg-4">
										<div class="form-group">
										<label for="name">Mobile</label><?php echo $MANDATORY;?>
										<div class="form-control2" >
										<input type="text"  name="contact_no1" id="contact_no1" tabindex="13" maxlength="13" placeholder="Primary Contact No" class="form-control" onKeyPress="return checkIt(event);" value="<?php echo $data['contact_no1']; ?>"/>&nbsp;										
										</div>
										</div>	
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group" id="addinput">
										<label for="name">Mobile (Office)</label>										
										
										<input type="text" class="form-control" tabindex="14" id="contact_no2" name="contact_no2" placeholder="Mobile (Office)" onKeyPress="return checkIt(event);" maxlength="13" value="">
										
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Email</label><?php echo $MANDATORY;?>
										  <input type="text" tabindex="15" class="form-control" id="email_1" name="email_1" placeholder="Enter Email" value="<?php echo $data['email_1']; ?>">
										</div>	
									</div><!-- /.col -->
									
								</div>
																
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Connecting Preference</label>
										  <select class="form-control" id="contact_preference" name="contact_preference" tabindex="16">
											<option value="" >Select</option>
											<option value="SMS" >SMS</option>
											<option value="CALL" >CALL</option>
											<option value="EMAIL" >EMAIL</option>
											</select>
										</div>	
									</div><!-- /.col -->
								</div><!-- /.col -->	
								
								<div class="col-lg-12">
									<div class="col-lg-12">
										<div class="form-group">
											<label for="name">Remarks</label>
											<textarea class="form-control" tabindex="17" id="notes" name="notes" placeholder="Enter Notes"><?php echo $data['notes']; ?></textarea>
										</div>	
									</div>
								</div>
                           </div><!-- /.row -->
                           
                           <div class="row">
                              <div class="col-lg-12">
                                   <div class="form-group center">
                                      <input type="submit" name="submit" tabindex="18" onclick="return validateuser();" id="submit" class="btn btn-warning left-10" value="<?php echo $btnvalue; ?>"/>
									  <a href="customerManage.php" class="btn btn-warning left-10">View All</a>
                                   </div>
                               </div><!-- /.col -->
             				 </div><!-- /.row -->
                           </form>
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
      </div><!-- /.content-wrapper -->
      
      
 <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->
	<!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
	<script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<script src="bootstrap/js/bootstrap-datepicker.js"></script>
	<script type="text/javascript">
	// When the document is ready
	$(document).ready(function () {		
		$('.datepicker').datepicker({
			format: "dd/mm/yyyy",
			autoclose: true
		});
		
		$.ajax({
			url: "customer.php",
			type: 'POST',
			context: this,
			data: {getState:'ajaxState',id:'101'},
			success: function(response){
				$('#ajaxstate').html(response);
			}
		});
	});	
	
	$(document).ready(function () {
		//Disable full page
		$("body").on("contextmenu",function(e){
			return false;
		});
		
	});
	</script>
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
    <script src="dist/js/app.min.js"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
	<script>
	$('#notes').wysihtml5();
	</script>
   
</body>
</html>
