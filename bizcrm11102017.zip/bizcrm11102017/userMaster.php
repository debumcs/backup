<?php 
	require_once('include/auth.php');
	//require_once('include/functions.php'); 
		
	//require_once('class/database.class.php'); 
	require_once('class/class.user.php');

	
	//$objdb = new Database();	
	$objuser = new User();
	
	$action = $_GET["action"];
	$id = $_GET["id"];
	$msgD = '';
	
	$allGroupInfo = $objuser->getGroupInfo();
		
	if($action=="edit")
	{
		$data = $objuser->getById($id);
        $btnvalue = "UPDATE";
	}
	else
	{
		$btnvalue = "SAVE";
	}
	
	
	
if(isset($_POST['submit']))
{
	$objuser->save();
	exit();
}

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | Add User</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Bootstrap time Picker -->
    <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
    <!-- Date Picker -->
    <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<script type="text/javascript" language="javascript">

		function checkIt(evt)
		   {
		    evt = (evt) ? evt : window.event
		    var charCode = (evt.which) ? evt.which : evt.keyCode
		    if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode!=46)
		    {
		        status = "This field accepts numbers only.";
		        return false;
		    }
		    status = "";
		    return true ;
		   }

		function validateuser(){
            var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            if(document.getElementById('username').value =='' )
            {
				alert('Please Enter Userid!');
				document.getElementById('username').focus();
				return false;
			}
			else if(document.getElementById('role').value =='' )
			{
				alert('Please Select User Type!');
				document.getElementById('role').focus();
				return false;
			}
			else if(document.getElementById('name').value =='' )
			{
				alert('Please Enter Name!');
				document.getElementById('name').focus();
				return false;
			}
			else if(!filter.test(document.getElementById('email').value))
			{
				alert('Please enter valid Employee email id!');
				document.getElementById('email').focus();
				return false;
			}
			
			else{
				return true;
			}
      	}
	
	</script>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
     
   <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objuser->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objuser->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            User Master
          </h1>
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Control Panel</li>
            <li class="active">User Master</li><li class="active">Add User</li>
          </ol>
        </section><!--CONTENT HEADER-->
        
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title">Add User</h3><span style='float:right'>Fields marked with a asterisk (<font color='red'>*</font>) are mandatory.</span>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <form action="" name="userCreate" id="userCreate" method="post" >
							<div class="row">
                              <div class="col-lg-6">
                              		<div class="form-group">
                                      <label for="name">User ID<font color='red'>*</font> </label>
                                      <input type="text" class="form-control" id="username" name="username" placeholder="Enter User ID" value="<?php echo $data['username']; ?>">
									  <input type="hidden" id="psuid" name="psuid" value="<?php echo $data['psuid']; ?>" />
                                    </div>
									
                                    <div class="form-group">
                                      <label for="name">Name<font color='red'>*</font> </label>
                                      <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name" value="<?php echo $data['name']; ?>">
                                    </div>
                                    
                                    <div class="form-group">
                                      <label for="name">E-mail ID <font color='red'>*</font></label>
                                      <input type="text" class="form-control" id="email" name="email" placeholder="Enter E-mail ID" value="<?php echo $data['email']; ?>">
                                    </div>
                                                                        
                              </div><!-- /.col -->
                              
								<div class="col-lg-6">
                              		<div class="form-group">
                                        <label>User Type <font color='red'>*</font></label>
										<select class="form-control select2" id="role" name="role" style="width:100%;">
											<option value="<?php echo $data['role']; ?>" selected><?php echo $data['groupname']; ?></option>
											<?php for($i=0; $i<count($allGroupInfo); $i++){ if($allGroupInfo[$i]['groupid'] != '1'){?>
											<option value="<?php echo $allGroupInfo[$i]['groupid']; ?>"><?php echo $allGroupInfo[$i]['groupname']; ?></option>
											<?php } }?>
                                        </select>
                                    </div><!-- /.form-group -->
									
									<div class="form-group">
                                      <label for="name">Contact Number</label>
                                      <input type="text" class="form-control" id="contact" name="contact" maxlength="12" onKeyPress="return checkIt(event);" placeholder="Contact Number" value="<?php echo $data['contact']; ?>">
                                    </div>
									
									<div class="form-group">
										<label for="name">Login type</label>
                                        <div style="width:100%;">
											<input type="radio" id="logintype1" name="logintype" value="Normal" <?php if($data['logintype'] == 'Normal')echo 'checked'; ?>>Normal &nbsp; &nbsp; &nbsp;
											<input type="radio" id="logintype2" name="logintype" value="Gmail" <?php if($data['logintype'] == 'Gmail') echo 'checked'; ?>>Gmail
										</div>										
                                    </div>
                                      
                                    
                              	<?php if($action=="edit") { ?>	
                                    <div class="form-group">
                                      	<label>User Visibility</label>
                                          <ul class="columns">
                                            <li>
                                            <input type="checkbox" id="u1" name="status" <?php if($data['status'] == 1){echo 'checked';}else{echo '';} ?> value="1" />
                                            <label class="toggle <?php if($data['status'] == 1){echo 'custom-checked';}else{echo '';} ?>" for="u1"></label>
                                            Active
                                            </li>
                                          </ul>
                                       </div><!-- /.form-group -->
                                <?php } ?>
                              		
                              </div><!-- /.col -->
                              
                           </div><!-- /.row -->
                           
                           <div class="row">
								<div class="col-lg-12">
                                   <div class="form-group center">
                                      <input type="submit" name="submit" id="submit" class="btn btn-warning left-10" value="<?php echo $btnvalue; ?>" onclick="return validateuser();" />
									  <a href="manageUserMaster.php" class="btn btn-warning left-10">View All</a>
                                   </div>
								</div><!-- /.col -->
             				 </div><!-- /.row -->
                           </form>
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
      </div><!-- /.content-wrapper -->
      
      
      <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>    
    <!-- daterangepicker -->
    <script src="dist/js/moment.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <script>
		$("#message").fadeIn('slow').delay(5000).fadeOut('slow');
		$(".select2").select2();
		//iCheck for checkbox and radio inputs
        $('input[type="radio"].minimal').iCheck({
           radioClass: 'iradio_minimal-orange'
        });
	
	</script>
  </body>
</html>