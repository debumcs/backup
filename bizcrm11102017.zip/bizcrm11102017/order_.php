<?php 
	//require_once('include/auth.php');
	require_once('class/class.stylemaster.php');
	$objstyle = new Stylemaster();
	$allstyle = $objstyle->getAll();
	
	require_once('class/class.orderdetails.php');
	
	$objord = new Orderdetails();
	$cust_id = $_GET["cust_id"];
	$action = $_GET["action"];
	$orderno = $_GET["orderno"];
	$msgD = '';
	// :''
	
	if($action=="edit")
	{
		$data = $objord->getById($orderno);
        $btnvalue = "UPDATE";
	}
	else
	{
		$btnvalue = "SAVE";
		$orderId  =	$objord->getOrderID();
	}
		
	
if(isset($_POST['submit']))
{
	$objord->save();
	exit();
}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="bootstrap/css/datepicker.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
    <link rel="stylesheet" type="text/css" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css"></link>
	
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />
	
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<script type="text/javascript" language="javascript">
		function calculateSaleAmount() {		
			var original_amount 	= parseFloat($("#original_amount").val());
			var discount 			= parseFloat($("#discount").val());
			
			if((original_amount != '' && discount != '') && (original_amount < discount )){
				alert('Discounted amount should be less than original amount!');
				document.getElementById('discount').value = '';
				document.getElementById('discount').focus();
				return false;
			}else{
				document.getElementById('sale_amount').value = original_amount - discount;
			}
		}	
		
		function getState(stateid){
			//alert(stateid);
			$.ajax({
				url: "customer.php",
				type: 'POST',
				context: this,
				data: {getState:'ajaxState',id:stateid},
				success: function(response){
					$('#ajaxstate').html(response);
				}
			});
			
		}
		
		function getCity(cityid){
		
			$.ajax({
				url: "customer.php",
				type: 'POST',
				context: this,
				data: {getCity:'ajaxCity',id:cityid},
				success: function(response){
					$('#ajaxcity').html(response);
				}
			});
			
		}
		
		function isDecimalNumber(evt, element) {
			
			evt = (evt) ? evt : window.event;
			var charCode = (evt.which) ? evt.which : evt.keyCode;
			if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode!=46)
			{
				status = "This field accepts numbers only.";
				return false;
			}else {
				var len = $(element).val().length;
				var index = $(element).val().indexOf('.');
				if (index > 0 && charCode == 46) {
					return false;
				}
				if (index > 0) {
					var CharAfterdot = (len + 1) - index;
					if (CharAfterdot > 3) {
						return false;
					}
				}

			}
			return true;
		}
		
		function checkIt(evt)
		{
			evt = (evt) ? evt : window.event;
			var charCode = (evt.which) ? evt.which : evt.keyCode;
			if (charCode > 31 && (charCode < 48 || charCode > 57))
			{
				status = "This field accepts numbers only.";
				return false;
			}
			status = "";
			return true ;
		}		
		
		function validateorderform(){
			var order_date 			= $("#order_date").val();
			var trial_date 			= $("#trial_date").val();
			var delivery_due_date 	= $("#delivery_due_date").val();
			var indate 				= $("#indate").val();
			var outdate 			= $("#outdate").val();
			var bundle_date 		= $("#bundle_date").val();
			var delivery_date 		= $("#delivery_date").val();
			
			var original_amount 	= $("#original_amount").val();
			var discount 			= $("#discount").val();
			
			if(document.getElementById('order_detail').value =='' ){
				alert('Please enter order detail!');
				document.getElementById('order_detail').focus();
				return false;
			}else if(document.getElementById('quantity').value =='' ){
				alert('Please enter quantity!');
				document.getElementById('quantity').focus();
				return false;
			}else if(document.getElementById('order_date').value =='' ){
				alert('Please select order date!');
				document.getElementById('order_date').focus();
				return false;
			}else if(document.getElementById('trial_date').value =='' ){
				alert('Please select trial date!');
				document.getElementById('trial_date').focus();
				return false;
			}else if((document.getElementById('trial_date').value !='') && (Date.parse(order_date) > Date.parse(trial_date))){
				alert('Trial date should be greater than order date!');
				document.getElementById('trial_date').focus();
				return false;
			}else if(document.getElementById('delivery_due_date').value =='' ){
				alert('Please select delivery due date!');
				document.getElementById('delivery_due_date').focus();
				return false;
			}else if((document.getElementById('delivery_due_date').value !='') && (Date.parse(order_date) > Date.parse(delivery_due_date))){
				alert('Delivery due date should be greater than order date!');
				document.getElementById('delivery_due_date').focus();
				return false;
			}else if(document.getElementById('indate').value =='' ){
				alert('Please select indate!');
				document.getElementById('indate').focus();
				return false;
			}else if((document.getElementById('indate').value !='') && (Date.parse(order_date) > Date.parse(indate))){
				alert('Indate should be greater than order date!');
				document.getElementById('indate').focus();
				return false;
			}else if(document.getElementById('outdate').value =='' ){
				alert('Please select outdate!');
				document.getElementById('outdate').focus();
				return false;
			}else if((document.getElementById('outdate').value !='') && (Date.parse(order_date) > Date.parse(outdate))){
				alert('Outdate should be greater than order date!');
				document.getElementById('outdate').focus();
				return false;
			}else if((document.getElementById('outdate').value !='') && (Date.parse(indate) > Date.parse(outdate))){
				alert('Outdate should be greater than indate!');
				document.getElementById('outdate').focus();
				return false;
			}else if(document.getElementById('original_amount').value =='' ){
				alert('Please enter original amount!');
				document.getElementById('original_amount').focus();
				return false;
			}else if(document.getElementById('discount').value =='' ){
				alert('Please enter discount amount or enter zero if no discount!');
				document.getElementById('discount').focus();
				return false;
			}else if(document.getElementById('bundle_date').value =='' ){
				alert('Please select bundle date!');
				document.getElementById('bundle_date').focus();
				return false;
			}else if((document.getElementById('bundle_date').value !='') && (Date.parse(order_date) > Date.parse(bundle_date))){
				alert('Bundle date should be greater than order date!');
				document.getElementById('bundle_date').focus();
				return false;
			}else if(document.getElementById('delivery_status').value =='' ){
				alert('Please select delivery status!');
				document.getElementById('delivery_status').focus();
				return false;
			}else if(document.getElementById('delivery_date').value =='' ){
				alert('Please select delivery date!');
				document.getElementById('delivery_date').focus();
				return false;
			}else if((document.getElementById('delivery_date').value !='') && (Date.parse(order_date) > Date.parse(delivery_date))){
				alert('Delivery date should be greater than order date!');
				document.getElementById('delivery_date').focus();
				return false;
			}else{
				return true;
			}
		}		
	
	</script>
  </head>
  <body class="hold-transition skin-blue sidebar-mini" onload="startTime()">
     
   <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objord->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objord->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <!--h1>
            Add Customer
          </h1>
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Control Panel</li>
            <li class="active">Add Customer</li>
          </ol>
        </section><!--CONTENT HEADER-->
        
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
						<div class="col-md-12">
                          <h3 class="box-title">New Order </h3>
						  <p><br />(Customer ID : <strong><?php if($action=="edit"){	echo $data['customer_id'];}else{echo $cust_id;} ?></strong>&nbsp;&nbsp;&nbsp;&nbsp;orderno :<strong> <?php if($action=="edit"){	echo $data['orderno'];}else{echo 'XX-'.$orderId;} ?></strong>)</p>
						                          </div>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <form action="" name="userCreate" id="userCreate" method="post" >
							<div class="row">
							<input type="hidden" id="id" name="id" value="<?php echo $data['id']; ?>" />
								<!--div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Customer ID</label-->
										  <input type="hidden" class="form-control" readonly="true" id="customer_id" name="customer_id" placeholder="Enter User ID" value="<?php if($action=="edit"){	echo $data['customer_id'];}else{echo $cust_id;} ?>">
										  
										<!--/div>
									</div><!-- /.col -->

									<!--div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Order ID</label-->
										  <input type="hidden" class="form-control" readonly="true" id="orderno" name="orderno" placeholder="Enter orderno" value="XX-<?php if($action=="edit"){	echo $data['orderno'];}else{echo $orderId;} ?>">
										<!--/div>									  
									</div--><!-- /.col -->
									<div class="col-lg-12">
									<div class="col-lg-12">
										<div class="form-group">
										  <label for="name">Order Detail</label>
										    <textarea class="form-control" id="order_detail" name="order_detail" placeholder="Enter order detail" ><?php echo $data['order_detail']; ?></textarea>
										</div>
									</div><!-- /.col -->									
									</div><!-- /.col -->
								
								<div class="col-lg-12">
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Quantity</label>
										  <input type="text" class="form-control" onKeyPress="return checkIt(event);" id="quantity" name="quantity" placeholder="Enter quantity" value="<?php echo $data['quantity']; ?>">
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Order Date</label>
											<input type="text" name="order_date" id="order_date" placeholder="click here for order date" value="<?php echo $data['order_date']; ?>" class="form-control datepicker" readonly="true"/>
										</div><!-- /.form-group -->
									
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Trial Date</label>
										  <input type="text" class="form-control datepicker" readonly="true" id="trial_date" name="trial_date" placeholder="click here for trial date" value="<?php echo $data['trial_date']; ?>">
										</div>							  
										
										
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Delivery Due Date</label>
										  <input type="text" class="form-control datepicker" readonly="true" id="delivery_due_date" name="delivery_due_date" placeholder="click here for delivery due date" value="<?php echo $data['delivery_due_date']; ?>">
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">In Date</label>
										  <input type="text" class="form-control datepicker" readonly="true" id="indate" name="indate" placeholder="click here for indate" value="<?php echo $data['indate']; ?>">
										</div>
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Out Date</label>
										  <input type="text" class="form-control datepicker" readonly="true" id="outdate" name="outdate" placeholder="click here for outdate" value="<?php echo $data['outdate']; ?>">
										</div>									  
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
								
									
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Original Amount</label>
										  <input type="text" class="form-control" onKeyPress="return isDecimalNumber(event,this);" id="original_amount" name="original_amount" placeholder="Enter original amount" value="<?php echo $data['original_amount']; ?>">
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Discount</label>
										  <input type="text" class="form-control" onkeydown="calculateSaleAmount();" onKeyPress="return isDecimalNumber(event,this);" id="discount" name="discount" placeholder="Enter discount" value="<?php echo $data['discount']; ?>">
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Sale Amount</label>
										  <input type="text" class="form-control" readonly="true" id="sale_amount" name="sale_amount" placeholder="" value="<?php echo $data['sale_amount']; ?>">
										</div>	
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									
	<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Bundle Date</label>
										  <input type="text" class="form-control datepicker" readonly="true" id="bundle_date" name="bundle_date" placeholder="click here for bundle date" value="<?php echo $data['bundle_date']; ?>">
										</div>			  
									</div><!-- /.col -->
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Delivery Status</label>
											<select id="delivery_status" class="form-control" name="delivery_status">
											<option value="" selected="selected">Select Delivery Status</option>
											<option value="1" <?php if($data['delivery_status']== '1'){echo 'selected';} ?>>Incomplete</option>
											<option value="2" <?php if($data['delivery_status']== '2'){echo 'selected';} ?>>Pending</option>
											<option value="3" <?php if($data['delivery_status']== '3'){echo 'selected';} ?>>Processed</option>
											<option value="4" <?php if($data['delivery_status']== '4'){echo 'selected';} ?>>Partially Shipped</option>
											<option value="5" <?php if($data['delivery_status']== '5'){echo 'selected';} ?>>Shipping</option>
											<option value="6" <?php if($data['delivery_status']== '6'){echo 'selected';} ?>>Shipped</option>
											<option value="7" <?php if($data['delivery_status']== '7'){echo 'selected';} ?>>Partially Returned</option>
											<option value="8" <?php if($data['delivery_status']== '8'){echo 'selected';} ?>>Returned</option>
											<option value="9" <?php if($data['delivery_status']== '9'){echo 'selected';} ?>>Canceled</option>             
											</select>
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Delivery Date</label>
										  <input type="text" class="form-control datepicker" readonly="true" id="delivery_date" name="delivery_date" placeholder="click here for delivery date" value="<?php echo $data['delivery_date']; ?>">
										</div>	
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
							
									
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Style Ref</label>
										  <select id="style_ref" class="form-control" name="style_ref">
											<option value="" selected="selected">Select Style Ref</option>
											<?php for($si = 0; $si < count($allstyle); $si++){ ?>
											<option value="<?php echo $allstyle[$si]['style_code']; ?>" <?php if($data['style_ref'] == $allstyle[$si]['style_code']){echo 'selected';} ?>><?php echo $allstyle[$si]['style_code']; ?></option>
											<?php } ?>
											</select>
										</div>	
									</div><!-- /.col -->

								</div>
								
								
									<div class="col-lg-12">
									<div class="col-lg-12">										
										<div class="form-group">
										  <label for="name">Delivery Remarks</label>
										  <textarea class="form-control" id="delivery_remarks" name="delivery_remarks" placeholder="Enter delivery remarks" ><?php echo $data['delivery_remarks']; ?></textarea>
										</div>			  
									</div><!-- /.col -->
									
										</div>
								
                           </div><!-- /.row -->
                           
                           <div class="row">
                              <div class="col-lg-12">
                                   <div class="form-group center">
                                      <input type="submit" name="submit" id="submit" onclick="return validateorderform();" class="btn btn-warning left-10" value="<?php echo $btnvalue; ?>" />
                                   </div>
                               </div><!-- /.col -->
             				 </div><!-- /.row -->
                           </form>
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
      </div><!-- /.content-wrapper -->
      
      
      <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->
	
    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<script src="bootstrap/js/bootstrap-datepicker.js"></script>
	<script type="text/javascript">
	// When the document is ready
	$(document).ready(function () {		
		$('.datepicker').datepicker({
			format: "yyyy-mm-dd",
			autoclose: true
		});
	});		
	</script>
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>

    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
	<script>
	//$('#order_detail').wysihtml5();
	//$('#delivery_remarks').wysihtml5();
	</script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js"></script>
    <!-- AdminLTE for demo purposes -->
	
  </body>
</html>