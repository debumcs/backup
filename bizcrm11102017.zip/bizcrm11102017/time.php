<?php 
echo date('Y-m-d H:i:s'); 
echo $sys_timestamp = strtotime(exec("date"));

?>