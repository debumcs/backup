<?php 
	require_once('include/auth.php');
	require_once('class/class.items.php');
	$objitem = new item();
	
	$action = "";
	$action = $_GET["action"];
	$id = $_GET["id"];
	$msgD = '';
	
		
	if($action=="Edit")
	{
	    $btnvalue = "UPDATE";
		$data = $objitem->getById($id);
		
	}elseif($action=="Add")
	{
		$btnvalue = "SAVE";
		
	}else{
		$btnvalue = "";
		$alldata = $objitem->getAll();
	}
	
	if(isset($_POST['submit']))
	{
		$objitem->save();
		exit();
	}

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | Add Category</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Bootstrap time Picker -->
    <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
    <!-- Date Picker -->
    <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<script type="text/javascript" language="javascript">

		function validateitem(){
            
            if(document.getElementById('itemname').value =='' )
            {
				alert('Please enter item name!');
				document.getElementById('itemname').focus();
				return false;
			}
			else{
				return true;
			}
			
      	}
	
	</script>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
     
   <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objitem->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objitem->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Item Master
          </h1>
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Control Panel</li>
            <li class="active">Item Master</li><li class="active"><?php echo $action; ?></li>
          </ol>
        </section><!--CONTENT HEADER-->
        <?php if($action == 'Add' || $action == 'Edit'){?>
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title"><?php echo $action; ?> Item Text</h3><span style='float:right'>Fields marked with a asterisk (<font color='red'>*</font>) are mandatory.</span>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <form action="" name="Itemmaster" id="Itemmaster" method="post" >
							<div class="row">
								<div class="col-lg-12">	
									<div class="col-lg-6">
										<div class="form-group">
											<label>Item<font color='red'>*</font></label>
											<input type="text" class="form-control" id="itemname"  name="itemname" placeholder="Enter item name" value="<?php echo $data['itemname']; ?>">
										</div><!-- /.form-group -->
									</div><!-- /.col -->
								  
									<div class="col-lg-6">
										<div class="form-group">
											<label for="name">Description<font color='red'>*</font> </label>
											<input type="text" class="form-control" id="description" name="description" placeholder="Enter Description" value="<?php echo $data['description']; ?>">
											<input type="hidden" id="id" name="id" value="<?php echo $data['id']; ?>" />
										</div>
										
									</div><!-- /.col -->
								</div><!-- /.col -->								
								
                           </div><!-- /.row -->
                           
                           <div class="row">
                              <div class="col-lg-12">
                                   <div class="form-group center">
                                      <input type="submit" name="submit" id="submit" class="btn btn-warning left-10" value="<?php echo $btnvalue; ?>" onclick="return validateitem();" />
									  <a href="manageitems.php" class="btn btn-warning left-10">View All</a>
                                   </div>
                               </div><!-- /.col -->
             				 </div><!-- /.row -->
                           </form>
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
		<?php }else{ ?>
		
		<section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
                          <h3 class="box-title pull-right"><a href="manageitems.php?action=Add&id=">Add New</a></h3>
                        </div><!-- /.box-header -->
                        <div class='box-body table-responsive'>
                            <table id="example111" class="table table-bordered table-striped">
							<thead>
							  <tr>
								<th>Item</th>
								<th>Description</th>                   
								<th>Action</th>							
							  </tr>
							</thead>
                    <tbody>
					<?php for($i=0; $i<count($alldata); $i++) { ?>	
						<tr>
                            <td><?php print $alldata[$i]['itemname']; ?></td>
							<td><?php print $alldata[$i]['description']; ?></td>
							<td><a href="manageitems.php?action=Edit&id=<?php print $alldata[$i]['id']; ?>">Edit</a></td>							
				        	</tr>
                    <?php } ?>						
                    </tbody>
                    
                  </table>
                           
                          </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
            </div><!-- /.row -->
        </section><!--CONTENT-->		
		<?php } ?>
		
      </div><!-- /.content-wrapper -->
      
      
      <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
    
   <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js"></script>
    <script type="text/javascript" src="dist/js/date.js"></script>
    
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <script>
		$("#message").fadeIn('slow').delay(5000).fadeOut('slow');
		$(".select2").select2();
	</script>
  </body>
</html>