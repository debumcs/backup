<?php 
error_reporting(E_ERROR);
ini_set('display_errors', 1);
include_once("database.class.php");
include_once("class.config.php");

class item extends config{
	
	//public $database;
	
	function __construct() {
		if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
		{
			$this->redirect('index.php');
			exit();
		}
	}
	
	function __destruct() {
		//parent::__construct();
		//$database->close;
	}
	
	public function getAll() {
		$database = new Database();	
		
		$sql = "SELECT * FROM items ORDER BY modifiedon DESC";
		
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getById($id){
		$database = new Database();
	
		// Initialize result array
		$result = array();
		$proAction = 'SRCGET';			
		$psuid = $this->sanitize($id);
		$sql = "SELECT * FROM items WHERE id = '".$psuid."'";
		
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}	
	
	public function save(){
		$database = new Database();
		
		$admin_name 	= $_SESSION['ADMIN_NAME'];
		$submit 		= $this->sanitize($_POST["submit"]);
		
		$id 			= $this->sanitize($_POST["id"]);
		$itemname 		= $this->sanitize($_POST["itemname"]);
        $description 	= $this->sanitize($_POST["description"]);
		$createdon 		= date('Y-m-d H:i:s');
		$createdby 		= $admin_name? $admin_name: '';
		$modifiedon 	= date('Y-m-d H:i:s');
		$modifiedby 	= $admin_name? $admin_name: '';
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		if($submit == 'SAVE'){
			$sql = "INSERT INTO items(itemname, description, createdby, createdon, modifiedby, modifiedon, ipaddress) VALUES('".$itemname."', '".$description."', '".$createdby."', '".$createdon."', '".$modifiedby."', '".$modifiedon."', '".$ipaddress."')";
		}
		if($submit == 'UPDATE'){
			$sql_log = "INSERT INTO items_log SELECT id, itemname, description, createdby, createdon, '".$modifiedby."', '".$modifiedon."', '".$ipaddress."' FROM items WHERE id = '".$id."'";
			$result_log = $database->query($sql_log);
			
			$sql = "UPDATE items SET itemname='".$itemname."', description='".$description."', modifiedby='".$modifiedby."', modifiedon='".$modifiedon."', ipaddress='".$ipaddress."' WHERE id = '".$id."'";
		}
		
		$result = $database->prepare($sql);
		if($result->execute()){
			if($submit == 'SAVE'){
				$_SESSION['msgD'] = 'Item Data Inserted Successfully';
			}else{
				$_SESSION['msgD'] = 'Item Data Updated Successfully';
			}			
		}else{
			$_SESSION['msgD'] = 'Error while executing query.';
		}
		$result->close();
		$database->close();
		$this->redirect('manageitems.php');
	}
	
	public function getItemBySONO($id){
		$database = new Database();	
		
		$sql = "SELECT s.id, s.orderno, s.suborderno, s.items, s.fabric, s.meters FROM suborder_items s WHERE s.id = '".$id."'";
		
		$result = $database->query($sql);
		$alldata = array();
		
		$field = $result->fetch_assoc();
		$database->close();
		return $field;
	}
	
	public function itemsbysuborderno($suborder) {
		$database = new Database();	
		
		$sql = "SELECT s.id, s.orderno, s.suborderno, s.items, s.fabric, s.units, s.value, i.itemname, f.fabricname, s.status_date, s.expected_date, s.status_id, sm.statusname FROM suborder_items s LEFT JOIN items i ON s.items = i.id LEFT JOIN status_master sm ON sm.id = s.status_id LEFT JOIN fabric f ON s.fabric = f.id WHERE s.suborderno = '".$suborder."'";
		
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function saveItemFab(){
		
		$database = new Database();
		
		$check = 0;
		$admin_name 	= $_SESSION['ADMIN_NAME'];
		$orderno		= $this->sanitize($_POST["orderno"]);
		$suborderno		= $this->sanitize($_POST["suborderno"]);
		$items			= $this->sanitize($_POST["items"]);
        $fabric 		= $this->sanitize($_POST["fabric"]);
		$fabric 		= $this->sanitize($_POST["fabric"]);
		$units 			= $this->sanitize($_POST["units"]);
		$value 			= $this->sanitize($_POST["unitsvalue"]);
		$totalrow		= $this->sanitize($_POST["totalrow"]);
		$createdon 		= date('Y-m-d H:i:s');
		$createdby 		= $admin_name? $admin_name: '';
		$modifiedon 	= date('Y-m-d H:i:s');
		$modifiedby 	= $admin_name? $admin_name: '';
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		for($i=0; $i<$totalrow; $i++){
			$sql = "INSERT INTO suborder_items(orderno, suborderno, items, fabric, units, value, createdby, createdon, modifiedby, modifiedon, ipaddress) VALUES ('".$orderno."', '".$suborderno."', '".$items."', '".$fabric[$i]."', '".$units[$i]."', '".$value[$i]."', '".$createdby."', '".$createdon."', '".$modifiedby."', '".$modifiedon."', '".$ipaddress."')";
			//;
			$result = $database->prepare($sql);
			if($result->execute()){
				$check = 1;
			}else{
				$check = 0;
			}
			$result->close();
		}
			
		$database->close();
		return $check;
	}
	
	
	public function saveItemBySONO(){
		$database = new Database();
		
		$admin_name 	= $_SESSION['ADMIN_NAME'];
		$task 			= $this->sanitize($_POST["task"]);
		$id 			= $this->sanitize($_POST["id"]);
		$orderno		= $this->sanitize($_POST["orderno"]);
		$suborderno		= $this->sanitize($_POST["suborderno"]);
		$items 			= $this->sanitize($_POST["items"]);
        $fabric 		= $this->sanitize($_POST["fabricid"]);
		$meters 		= $this->sanitize($_POST["quantity"]);
		$createdon 		= date('Y-m-d H:i:s');
		$createdby 		= $admin_name? $admin_name: '';
		$modifiedon 	= date('Y-m-d H:i:s');
		$modifiedby 	= $admin_name? $admin_name: '';
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		if($task == 'saveItem'){
			$sql = "INSERT INTO suborder_items(orderno, suborderno, items, fabric, meters, createdby, createdon, modifiedby, modifiedon, ipaddress) VALUES ('".$orderno."', '".$suborderno."', '".$items."', '".$fabric."', '".$meters."', '".$createdby."', '".$createdon."', '".$modifiedby."', '".$modifiedon."', '".$ipaddress."')";
		}
		if($task == 'updateItem'){
			$sql = "UPDATE suborder_items SET orderno='".$orderno."', suborderno='".$suborderno."', items='".$items."', fabric='".$fabric."', meters='".$meters."', createdby='".$createdby."', createdon='".$createdon."', modifiedby='".$modifiedby."', modifiedon='".$modifiedon."', ipaddress='".$ipaddress."' WHERE id='".$id."'";
		}
		
		$result = $database->prepare($sql);
		if($result->execute()){
			echo 'OK';		
		}else{
			echo $database->error;
		}
		$result->close();
		$database->close();
		exit;
	}
	
	public function deleteItemBySONO(){
		$database = new Database();
		
		$task 	= $this->sanitize($_POST["task"]);
		$id 	= $this->sanitize($_POST["id"]);
		
		$sql = "DELETE FROM suborder_items WHERE id='".$id."'";
		
		$result = $database->prepare($sql);
		if($result->execute()){
			echo 'OK';		
		}else{
			echo $database->error;
		}
		$result->close();
		$database->close();
		exit;
	}
	
	public function numberworkassignitems($order,$suborder,$status_id){
		
		$database = new Database();
		
		$order 			= $this->sanitize($order);
		$suborder		= $this->sanitize($suborder);
		$status_id		= $this->sanitize($status_id);
		
		$wheres = array();
		if (!empty($order)) {
			$wheres[] = "s.orderno = '".$order."'";
		}
		if (!empty($suborder)) {
			$wheres[] = "s.suborderno = '".$suborder."'";
		}
		if ($status_id != '') {
			$wheres[] = "s.status_id = '".$status_id."'";
		}
		
		$sql = "SELECT s.id, s.orderno, s.suborderno, s.items, s.fabric, s.units, s.value, s.challanno, s.agencyid, a.agencyname, s.assign_date, s.expected_date, s.return_date, s.status_id, i.itemname, f.fabricname FROM suborder_items s LEFT JOIN items i ON s.items = i.id LEFT JOIN fabric f ON s.fabric = f.id LEFT JOIN agencymaster a ON a.id = s.agencyid";
		
		if (!empty($wheres)) {
			$sql .= " WHERE " . implode(' AND ', $wheres);
		}
		
		$result = $database->query($sql);
		$total=$result->num_rows;
		$database->close();
		return $total;
	}
	
	public function getallitemsbyagency($order,$suborder,$status_id,$startpoint,$limit){
		
		$database = new Database();
		
		$order 			= $this->sanitize($order);
		$suborder		= $this->sanitize($suborder);
		$status_id		= $this->sanitize($status_id);
		
		$wheres = array();
		if (!empty($order)) {
			$wheres[] = "s.orderno = '".$order."'";
		}
		if (!empty($suborder)) {
			$wheres[] = "s.suborderno = '".$suborder."'";
		}
		//if ($status_id != '') {
			$wheres[] = "s.status_id != '0'";
		//}
		
		$username = $_SESSION['ADMIN_NAME'];
		
		$sql = "SELECT s.id, s.orderno, s.suborderno, s.items, s.fabric, s.value, s.units, s.challanno, s.agencyid, a.agencyname, s.status_date, s.expected_date, s.status_id, i.itemname, f.fabricname, sm.status_type FROM suborder_items s LEFT JOIN items i ON s.items = i.id LEFT JOIN fabric f ON s.fabric = f.id INNER JOIN status_master sm ON s.status_id = sm.id  INNER JOIN agencymaster a ON a.id = s.agencyid AND a.email = '".$username."'";
		
		if (!empty($wheres)) {
			$sql .= " WHERE " . implode(' AND ', $wheres);
		}
		$sql .= " ORDER BY s.createdon DESC ";
		$sql .=" LIMIT {$startpoint} , {$limit}";
		//echo $sql; die();
		
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function allassigneditems($order,$suborder,$status_id,$startpoint,$limit){
		
		$database = new Database();
		
		$order 			= $this->sanitize($order);
		$suborder		= $this->sanitize($suborder);
		$status_id		= $this->sanitize($status_id);
		
		$wheres = array();
		if (!empty($order)) {
			$wheres[] = "s.orderno = '".$order."'";
		}
		if (!empty($suborder)) {
			$wheres[] = "s.suborderno = '".$suborder."'";
		}
		if ($status_id != '') {
			$wheres[] = "s.status_id = '".$status_id."'";
		}else{
			$wheres[] = "s.status_id != '0'";
		}
		
		$sql = "SELECT s.id, s.orderno, s.suborderno, s.items, s.fabric, s.value, s.units, s.challanno, s.agencyid, a.agencyname, s.status_date, s.expected_date, s.status_id, i.itemname, f.fabricname FROM suborder_items s LEFT JOIN items i ON s.items = i.id LEFT JOIN fabric f ON s.fabric = f.id LEFT JOIN agencymaster a ON a.id = s.agencyid";
		
		if (!empty($wheres)) {
			$sql .= " WHERE " . implode(' AND ', $wheres);
		}
		$sql .= " ORDER BY s.createdon DESC ";
		$sql .=" LIMIT {$startpoint} , {$limit}";
		
		
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function allworkassignitems($order,$suborder,$status_id,$startpoint,$limit){
		
		$database = new Database();
		
		$order 			= $this->sanitize($order);
		$suborder		= $this->sanitize($suborder);
		$status_id		= $this->sanitize($status_id);
		
		$wheres = array();
		if (!empty($order)) {
			$wheres[] = "s.orderno = '".$order."'";
		}
		if (!empty($suborder)) {
			$wheres[] = "s.suborderno = '".$suborder."'";
		}
		if ($status_id != '') {
			$wheres[] = "s.status_id = '".$status_id."'";
		}
		
		$sql = "SELECT s.id, s.orderno, s.suborderno, s.items, s.fabric, s.value, s.units, s.challanno, s.agencyid, a.agencyname, s.status_date, s.expected_date, s.status_id, i.itemname, f.fabricname FROM suborder_items s LEFT JOIN items i ON s.items = i.id LEFT JOIN fabric f ON s.fabric = f.id LEFT JOIN agencymaster a ON a.id = s.agencyid";
		
		if (!empty($wheres)) {
			$sql .= " WHERE " . implode(' AND ', $wheres);
		}
		$sql .= " ORDER BY s.createdon DESC ";
		$sql .=" LIMIT {$startpoint} , {$limit}";
		
		
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function updateWorkAgency(){
		$database = new Database();
		
		$worklist 		= $this->sanitize($_POST["worklist"]);
		$status_id 		= $this->sanitize($_POST["assignstatus"]);
		$status_date 	= $this->sanitize($_POST["status_date"]);
		$remark 		= $this->sanitize($_POST["remark"]);
		
		$array = $this->workliststatus($worklist);
		
		if($array[1] == '1'){
			foreach($worklist as $id){
				$sql = "UPDATE suborder_items SET status_date = '".$status_date."', status_id='".$status_id."' WHERE id='".$id."'";
				$result = $database->prepare($sql);
				if($result->execute()){
					$this->workStatusEntry($id, $status_id, $status_date, $remark);
				}else{
					$success = $database->error;
				}
				$result->close();
			}
		}else{
			echo '<script>alert("Selected item must have same status!");</script>';
		}
		$this->redirect('agencyassigneditems.php');
		$database->close();
	}
	
	public function updateWork(){
		$database = new Database();
		
		$worklist 			= $this->sanitize($_POST["worklist"]);
		$assignstatus		= $this->sanitize($_POST["assignstatus"]);
		$assignstatus2		= explode(":",$assignstatus);
		$status_id			= $assignstatus2[0];
		$checkstatustype	= $this->sanitize($_POST["checkstatustype"]);
		$agencyid 			= $this->sanitize($_POST["agencyid"]);
		$challanno 			= $this->sanitize($_POST["challanno"]);
		$status_date 		= $this->date_dmy_ymd($this->sanitize($_POST["status_date"]));
		$expected_date 		= $this->date_dmy_ymd($this->sanitize($_POST["expected_date"]));
		$remark 			= $this->sanitize($_POST["remark"]);
		
		if($checkstatustype == 'Initial'){
			$array = $this->workliststatus($worklist);
			if(($array[1] == '0') || ($array[0] == 'End' && $array[1] == '1')){
				foreach($worklist as $id){
					$sql = "UPDATE suborder_items SET agencyid='".$agencyid."', status_date = '".$status_date."', expected_date = '".$expected_date."', status_id='".$status_id."' WHERE id='".$id."'";
					$result = $database->prepare($sql);
					if($result->execute()){
						$this->workStatusEntryAssign($id, $status_id, $status_date, $expected_date, $agencyid, $challanno, $remark);
					}else{
						$success = $database->error;
					}
					$result->close();
				}
			}else{
				echo '<script>alert("Selected item not allow to assign!");</script>';
			}			
		}else{
			$array = $this->workliststatus($worklist);
			if($array[1] == 1){
				foreach($worklist as $id){
					$sql = "UPDATE suborder_items SET status_date = '".$status_date."', status_id='".$status_id."' WHERE id='".$id."'";
					$result = $database->prepare($sql);
					if($result->execute()){
						$this->workStatusEntry($id, $status_id, $status_date, $remark);
					}else{
						$success = $database->error;
					}
					$result->close();
				}
			}else{
				echo '<script>alert("Selected item must have same status!");</script>';
			}
		}
		
		$database->close();		
	}
	
	public function workliststatus($worklist){
		$database = new Database();
		$array = array();
		$itemids = implode($worklist,',');
		$sql = "SELECT a.status_type as status_type FROM status_master a INNER JOIN suborder_items b ON a.id = b.status_id WHERE FIND_IN_SET(b.id,'".$itemids."') GROUP BY a.status_type";
		$result = $database->query($sql);
		$row_cnt = $result->num_rows;
		$field = $result->fetch_assoc();
		$array = array($field['status_type'],$row_cnt);		
		$result->close();
		$database->close();
		return $array;
	}
	
	public function updateAssignWork($id, $status_id, $status_date, $expected_date, $agencyid, $challanno, $remark){
		$database = new Database();
		
		$sql = "UPDATE suborder_items SET  challanno='".$challanno."',  agencyid='".$agencyid."', expected_date='".$expected_date."', status_date = '".$status_date."', status_id='".$status_id."' WHERE id='".$id."'";
		
		$result = $database->prepare($sql);
		if($result->execute()){
			$this->workStatusEntryAssign($id, $status_id, $status_date, $expected_date, $agencyid, $challanno, $remark);
		}else{
			$success = $database->error;
		}
		$result->close();
		$database->close();
	}
	
	public function workStatusEntry($id, $status_id, $status_date, $remark){
		$database = new Database();
		
		$id				= $this->sanitize($id);
		$status_id		= $this->sanitize($status_id);
		$status_date 	= $status_date;
		$remark			= $this->sanitize($remark);		
		
		$entrydate 		= date('Y-m-d H:i:s');
		$createdby 		= $_SESSION['ADMIN_NAME'];
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		
		$sql = "INSERT INTO work_status(assigned_id, challanno, orderno, suborderno, agencyid, expected_date, status_date, status_id, remark, entrydate, createdby, ipaddress) SELECT id, challanno, orderno, suborderno, agencyid, expected_date, '".$status_date."', '".$status_id."', '".$remark."', '".$entrydate."', '".$createdby."', '".$ipaddress."' FROM suborder_items WHERE id = '".$id."'";
		
		$result = $database->prepare($sql);
		$result->execute();
		$result->close();
		$database->close();
	}
	
	public function workStatusEntryAssign($id, $status_id, $status_date, $expected_date, $agencyid, $challanno, $remark){
		$database = new Database();
		
		$entrydate 		= date('Y-m-d H:i:s');
		$createdby 		= $_SESSION['ADMIN_NAME'];
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		$sql = "INSERT INTO work_status(assigned_id, challanno, orderno, suborderno, agencyid, expected_date, status_date, status_id, remark, entrydate, createdby, ipaddress) SELECT id, '".$challanno."', orderno, suborderno, '".$agencyid."', '".$expected_date."', '".$status_date."', '".$status_id."', '".$remark."', '".$entrydate."', '".$createdby."', '".$ipaddress."' FROM suborder_items WHERE id = '".$id."'";
		//;
		$result = $database->prepare($sql);
		$result->execute();
		$result->close();
		$database->close();
	}
	
	public function getStatusName($status_id){
		$database = new Database();
		
		$status_id	= $this->sanitize($status_id);
		$sql = "SELECT statusname FROM status_master WHERE id ='".$status_id."'";
		$result = $database->query($sql);
		
		$field = $result->fetch_assoc();
		$database->close();
		
		return $field['statusname'];
	}
	
	public function getAssignedWorkData($assignedid) {
		$database 		= new Database();	
		$assignedid		= $this->sanitize($assignedid);
		
		$sql = "SELECT * FROM work_status WHERE assigned_id = '".$assignedid."'";
		
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc()){
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getOrderNotes($orderno) {
		$database 		= new Database();	
		$orderno		= $this->sanitize($orderno);
		
		$sql = "SELECT orderno, suborderno, agencyname, agencyid, status_date, status_id, statusname, remark FROM `work_status` w INNER JOIN `status_master` s ON s.id = w.status_id LEFT JOIN `agencymaster` a ON a.id = w.agencyid WHERE w.orderno = '".$orderno."' order by entrydate desc";
		//;
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc()){
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function addOrdernotes(){
		$database = new Database();
		//$this->date_dmy_ymd($this->sanitize($_POST["order_date"]))
		$entrydate 				= date('Y-m-d H:i:s');
		$createdby 				= $_SESSION['ADMIN_NAME'];
        $ipaddress				= $this->sanitize($_SERVER['REMOTE_ADDR']);
		$status_date			= $this->date_dmy_ymd($this->sanitize($_POST["ordernotestatusdate"]));
		$status_id				= $this->sanitize($_POST["ordernotestatus"]);
		$remark					= $this->sanitize($_POST["order_note"]);
		$orderno				= $this->sanitize($_POST["order_id"]);
		
		$sql = "INSERT INTO work_status(orderno, status_date, status_id, remark, entrydate, createdby, ipaddress) values('".$orderno."', '".$status_date."', '".$status_id."', '".$remark."', '".$entrydate."', '".$createdby."', '".$ipaddress."')";
		//;
		$result = $database->prepare($sql);
		$result->execute();
		$result->close();
		$database->close();
		
		return $this->getOrderNotes($orderno);
	}
	
	public function getSubOrderNotes($suborderno) {
		$database 		= new Database();	
		$suborderno		= $this->sanitize($suborderno);
		
		$sql = "SELECT orderno, suborderno, agencyname, agencyid, status_date, status_id, statusname, remark FROM `work_status` w INNER JOIN `status_master` s ON s.id = w.status_id LEFT JOIN `agencymaster` a ON a.id = w.agencyid WHERE w.suborderno = '".$suborderno."' order by entrydate desc";
		//;
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc()){
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function addsubordernotes(){
		$database = new Database();
		//suborder_note:suborder_note,suborder_id:suborder_id,subordernotestatusdate:subordernotestatusdate,subordernotestatus:subordernotestatus
		$entrydate 				= date('Y-m-d H:i:s');
		$createdby 				= $_SESSION['ADMIN_NAME'];
        $ipaddress				= $this->sanitize($_SERVER['REMOTE_ADDR']);
		$status_date			= $this->date_dmy_ymd($this->sanitize($_POST["subordernotestatusdate"]));
		$status_id				= $this->sanitize($_POST["subordernotestatus"]);
		$remark					= $this->sanitize($_POST["suborder_note"]);
		$suborderno				= $this->sanitize($_POST["suborder_id"]);
		$orderno				= $this->sanitize($_POST["order_id"]);
		
		$sql = "INSERT INTO work_status(orderno, suborderno, status_date, status_id, remark, entrydate, createdby, ipaddress) values('".$orderno."','".$suborderno."', '".$status_date."', '".$status_id."', '".$remark."', '".$entrydate."', '".$createdby."', '".$ipaddress."')";
		//;
		$result = $database->prepare($sql);
		$result->execute();
		$result->close();
		$database->close();
		
		return $this->getSubOrderNotes($suborderno);
	}
	
	
	public function getWorkStatusAssignedId($assignedid){
		$database 		= new Database();	
		$assignedid		= $this->sanitize($assignedid);
		
		$sql = "SELECT s.statusname, DATE_FORMAT(w.status_date,'%b %d %Y') AS status_entry_date, a.agencyname, w.challanno, w.remark FROM work_status w INNER JOIN status_master s ON w.status_id = s.id INNER JOIN agencymaster a ON w.agencyid = a.id WHERE w.assigned_id = '".$assignedid."'";
		//;
		$result = $database->query($sql);
		
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function updateAgencyAssignedWork(){
		$database = new Database();
		//id, remark, status_date, assignstatus
		$id 			= $this->sanitize($_POST["id"]);
		$remark 		= $this->sanitize($_POST["remark"]);
		$status_date 	= $this->date_dmy_ymd($this->sanitize($_POST["status_date"]));
        $assignstatus 	= $this->sanitize($_POST["assignstatus"]);
		
		$sql = "UPDATE suborder_items SET status_date='".$status_date."', status_id='".$assignstatus."' WHERE id='".$id."'";
		// echo 
		$result = $database->prepare($sql);
		if($result->execute()){
			$success = 'OK';
			$this->workStatusEntry($id, $status_id, $status_date, $remark);
		}else{
			$success = $database->error;
		}
		$result->close();
		$database->close();
		return $success;
	}
	
	public function updateAssignedWork(){
		$database = new Database();
		
		$id 			= $this->sanitize($_POST["id"]);
		
		$remark 		= $this->sanitize($_POST["remark"]);
        $agencyid 		= $this->sanitize($_POST["agencyid"]);
		$status_date 	= $this->sanitize($_POST["status_date"]);
        $assignstatus 	= $this->sanitize($_POST["assignstatus"]);
		
		$createdon 		= date('Y-m-d H:i:s');
		$createdby 		= $admin_name? $admin_name: '';
		$modifiedon 	= date('Y-m-d H:i:s');
		$modifiedby 	= $admin_name? $admin_name: '';
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		$sql = "UPDATE suborder_items SET status_date='".$status_date."', status_id='".$assignstatus."' WHERE id='".$id."'";
		
		$result = $database->prepare($sql);
		if($result->execute()){
			$success = 'OK';
			//$this->workStatusEntryAssign($id, $assignstatus, $status_date, $agencyid, $remark);
			$this->workStatusEntryAssign($id, $assignstatus, $status_date, $agencyid, $challanno, $remark);
		}else{
			$success = $database->error;
		}
		$result->close();
		$database->close();
		return $success;
	}
	
	public function getallitemsbychallan($challanno){
		$database 		= new Database();	
		$challanno		= $this->sanitize($challanno);
		if($challanno == ''){
			$sql = "SELECT w.assigned_id, w.challanno, w.orderno, w.suborderno, w.agencyid, w.status_date, w.status_id, s.units, s.value, a.agencyname, i.itemname, f.fabricname FROM work_status w left join suborder_items s on w.assigned_id = s.id LEFT JOIN items i ON s.items = i.id LEFT JOIN fabric f ON s.fabric = f.id LEFT JOIN agencymaster a ON a.id = s.agencyid";
		}else{
			$sql = "SELECT w.assigned_id, w.challanno, w.orderno, w.suborderno, w.agencyid, w.status_date, w.status_id, s.units, s.value, a.agencyname, i.itemname, f.fabricname FROM work_status w left join suborder_items s on w.assigned_id = s.id LEFT JOIN items i ON s.items = i.id LEFT JOIN fabric f ON s.fabric = f.id LEFT JOIN agencymaster a ON a.id = s.agencyid WHERE w.challanno = '".$challanno."' ";
		}
		$result = $database->query($sql);
		
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getLastIDSuborderItems(){
		$database 		= new Database();
		
		$sql = "SELECT id FROM suborder_items order by id desc limit 1";
		$result = $database->query($sql);
		
		$field = $result->fetch_assoc();
		$result->close();
		$database->close();
		return $field;
	}
}

?>