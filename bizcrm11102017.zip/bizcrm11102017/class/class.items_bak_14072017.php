<?php 
error_reporting(E_ERROR);
ini_set('display_errors', 1);
include_once("database.class.php");
include_once("class.config.php");

class item extends config{
	
	//public $database;
	
	function __construct() {
		if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
		{
			$this->redirect('index.php');
			exit();
		}
	}
	
	function __destruct() {
		//parent::__construct();
		//$database->close;
	}
	
	public function getAll() {
		$database = new Database();	
		
		$sql = "SELECT * FROM items ORDER BY modifiedon DESC";
		
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getById($id){
		$database = new Database();
	
		// Initialize result array
		$result = array();
		$proAction = 'SRCGET';			
		$psuid = $this->sanitize($id);
		$sql = "SELECT * FROM items WHERE id = '".$psuid."'";
		
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}	
	
	public function save(){
		$database = new Database();
		
		$admin_name 	= $_SESSION['ADMIN_NAME'];
		$submit 		= $this->sanitize($_POST["submit"]);
		
		$id 			= $this->sanitize($_POST["id"]);
		$itemname 		= $this->sanitize($_POST["itemname"]);
        $description 	= $this->sanitize($_POST["description"]);
		$createdon 		= date('Y-m-d H:i:s');
		$createdby 		= $admin_name? $admin_name: '';
		$modifiedon 	= date('Y-m-d H:i:s');
		$modifiedby 	= $admin_name? $admin_name: '';
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		if($submit == 'SAVE'){
			$sql = "INSERT INTO items(itemname, description, createdby, createdon, modifiedby, modifiedon, ipaddress) VALUES ('".$itemname."', '".$description."', '".$createdby."', '".$createdon."', '".$modifiedby."', '".$modifiedon."', '".$ipaddress."')";
		}
		if($submit == 'UPDATE'){
			$sql_log = "INSERT INTO items_log SELECT id, itemname, description, createdby, createdon, '".$modifiedby."', '".$modifiedon."', '".$ipaddress."' FROM items WHERE id = '".$id."'";
			$result_log = $database->query($sql_log);
			
			$sql = "UPDATE items SET itemname='".$itemname."', description='".$description."', modifiedby='".$modifiedby."', modifiedon='".$modifiedon."', ipaddress='".$ipaddress."' WHERE id = '".$id."'";
		}
		
		$result = $database->prepare($sql);
		if($result->execute()){
			if($submit == 'SAVE'){
				$_SESSION['msgD'] = 'Item Data Inserted Successfully';
			}else{
				$_SESSION['msgD'] = 'Item Data Updated Successfully';
			}			
		}else{
			$_SESSION['msgD'] = 'Error while executing query.';
		}
		$result->close();
		$database->close();
		$this->redirect('manageitems.php');
	}
	
	public function getItemBySONO($id){
		$database = new Database();	
		
		$sql = "SELECT s.id, s.orderno, s.suborderno, s.items, s.fabric, s.meters FROM suborder_items s WHERE s.id = '".$id."'";
		
		$result = $database->query($sql);
		$alldata = array();
		
		$field = $result->fetch_assoc();
		$database->close();
		return $field;
	}
	
	public function itemsbysuborderno($suborder) {
		$database = new Database();	
		
		$sql = "SELECT s.id, s.orderno, s.suborderno, s.items, s.fabric, s.units, s.value, i.itemname, f.fabricname, s.assign_date, s.expected_date, s.status_id FROM suborder_items s INNER JOIN items i ON s.items = i.id INNER JOIN fabric f ON s.fabric = f.id WHERE s.suborderno = '".$suborder."' AND s.status_id = '0'";
		
		
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function saveItemFab(){
		
		$database = new Database();
		/*echo '<pre>';
		print_r($_POST);
		echo '</pre>';die();*/
		$check = 0;
		$admin_name 	= $_SESSION['ADMIN_NAME'];
		$orderno		= $this->sanitize($_POST["orderno"]);
		$suborderno		= $this->sanitize($_POST["suborderno"]);
		$items			= $this->sanitize($_POST["items"]);
        $fabric 		= $this->sanitize($_POST["fabric"]);
		$fabric 		= $this->sanitize($_POST["fabric"]);
		$units 			= $this->sanitize($_POST["units"]);
		$value 			= $this->sanitize($_POST["unitsvalue"]);
		$totalrow		= $this->sanitize($_POST["totalrow"]);
		$createdon 		= date('Y-m-d H:i:s');
		$createdby 		= $admin_name? $admin_name: '';
		$modifiedon 	= date('Y-m-d H:i:s');
		$modifiedby 	= $admin_name? $admin_name: '';
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		for($i=0; $i<$totalrow; $i++){
			$sql = "INSERT INTO suborder_items(orderno, suborderno, items, fabric, units, value, createdby, createdon, modifiedby, modifiedon, ipaddress) VALUES ('".$orderno."', '".$suborderno."', '".$items."', '".$fabric[$i]."', '".$units[$i]."', '".$value[$i]."', '".$createdby."', '".$createdon."', '".$modifiedby."', '".$modifiedon."', '".$ipaddress."')";
			//echo $sql;die();
			$result = $database->prepare($sql);
			if($result->execute()){
				$check = 1;
			}else{
				$check = 0;
			}
			$result->close();
		}
			
		$database->close();
		return $check;
	}
	
	
	public function saveItemBySONO(){
		$database = new Database();
		
		$admin_name 	= $_SESSION['ADMIN_NAME'];
		$task 			= $this->sanitize($_POST["task"]);
		$id 			= $this->sanitize($_POST["id"]);
		$orderno		= $this->sanitize($_POST["orderno"]);
		$suborderno		= $this->sanitize($_POST["suborderno"]);
		$items 			= $this->sanitize($_POST["items"]);
        $fabric 		= $this->sanitize($_POST["fabricid"]);
		$meters 		= $this->sanitize($_POST["quantity"]);
		$createdon 		= date('Y-m-d H:i:s');
		$createdby 		= $admin_name? $admin_name: '';
		$modifiedon 	= date('Y-m-d H:i:s');
		$modifiedby 	= $admin_name? $admin_name: '';
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		if($task == 'saveItem'){
			$sql = "INSERT INTO suborder_items(orderno, suborderno, items, fabric, meters, createdby, createdon, modifiedby, modifiedon, ipaddress) VALUES ('".$orderno."', '".$suborderno."', '".$items."', '".$fabric."', '".$meters."', '".$createdby."', '".$createdon."', '".$modifiedby."', '".$modifiedon."', '".$ipaddress."')";
		}
		if($task == 'updateItem'){
			$sql = "UPDATE suborder_items SET orderno='".$orderno."', suborderno='".$suborderno."', items='".$items."', fabric='".$fabric."', meters='".$meters."', createdby='".$createdby."', createdon='".$createdon."', modifiedby='".$modifiedby."', modifiedon='".$modifiedon."', ipaddress='".$ipaddress."' WHERE id='".$id."'";
		}
		
		$result = $database->prepare($sql);
		if($result->execute()){
			echo 'OK';		
		}else{
			echo $database->error;
		}
		$result->close();
		$database->close();
		exit;
	}
	
	public function deleteItemBySONO(){
		$database = new Database();
		
		$task 	= $this->sanitize($_POST["task"]);
		$id 	= $this->sanitize($_POST["id"]);
		
		$sql = "DELETE FROM suborder_items WHERE id='".$id."'";
		
		$result = $database->prepare($sql);
		if($result->execute()){
			echo 'OK';		
		}else{
			echo $database->error;
		}
		$result->close();
		$database->close();
		exit;
	}
	
	public function numberworkassignitems($order,$suborder,$status_id){
		
		$database = new Database();
		
		$order 			= $this->sanitize($order);
		$suborder		= $this->sanitize($suborder);
		$status_id		= $this->sanitize($status_id);
		
		$wheres = array();
		if (!empty($order)) {
			$wheres[] = "s.orderno = '".$order."'";
		}
		if (!empty($suborder)) {
			$wheres[] = "s.suborderno = '".$suborder."'";
		}
		if ($status_id != '') {
			$wheres[] = "s.status_id = '".$status_id."'";
		}
		
		$sql = "SELECT s.id, s.orderno, s.suborderno, s.items, s.fabric, s.units, s.value, s.challanno, s.agencyid, a.agencyname, s.assign_date, s.expected_date, s.return_date, s.status_id, i.itemname, f.fabricname FROM suborder_items s LEFT JOIN items i ON s.items = i.id LEFT JOIN fabric f ON s.fabric = f.id LEFT JOIN agencymaster a ON a.id = s.agencyid";
		
		if (!empty($wheres)) {
			$sql .= " WHERE " . implode(' AND ', $wheres);
		}
		
		$result = $database->query($sql);
		$total=$result->num_rows;
		$database->close();
		return $total;
	}
	
	public function allworkassignitems($order,$suborder,$status_id,$startpoint,$limit){
		
		$database = new Database();
		
		$order 			= $this->sanitize($order);
		$suborder		= $this->sanitize($suborder);
		$status_id		= $this->sanitize($status_id);
		
		$wheres = array();
		if (!empty($order)) {
			$wheres[] = "s.orderno = '".$order."'";
		}
		if (!empty($suborder)) {
			$wheres[] = "s.suborderno = '".$suborder."'";
		}
		if ($status_id != '') {
			$wheres[] = "s.status_id = '".$status_id."'";
		}
		
		$sql = "SELECT s.id, s.orderno, s.suborderno, s.items, s.fabric, s.value, s.units, s.challanno, s.agencyid, a.agencyname, s.assign_date, s.expected_date, s.return_date, s.status_id, i.itemname, f.fabricname FROM suborder_items s LEFT JOIN items i ON s.items = i.id LEFT JOIN fabric f ON s.fabric = f.id LEFT JOIN agencymaster a ON a.id = s.agencyid";
		
		if (!empty($wheres)) {
			$sql .= " WHERE " . implode(' AND ', $wheres);
		}
		$sql .= " ORDER BY s.createdon DESC ";
		$sql .=" LIMIT {$startpoint} , {$limit}";
		//echo $sql; die();
		
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function assignWork(){
		$database = new Database();
		
		$worklist 		= $this->sanitize($_POST["worklist"]);
		/*echo '<pre>';
		print_r($_POST);
		echo '</pre>';
		die();*/
		$assignstatus 	= $this->sanitize($_POST["assignstatus"]);
		$status_date 	= $this->sanitize($_POST["status_date"]);
		$agencyid 		= $this->sanitize($_POST["agencyid"]);
		$challanno 		= $this->sanitize($_POST["challanno"]);
		$remark 		= $this->sanitize($_POST["remark"]);
		
		foreach($worklist as $list){
			$this->updateAssignWork($list, $assignstatus, $status_date, $agencyid, $challanno, $remark);
		}
		
		$database->close();
	}
	
	public function updateAssignWork($id, $status_id, $status_date, $agencyid, $challanno, $remark){
		$database = new Database();
		
		$sql = "UPDATE suborder_items SET status_id='".$status_id."' WHERE id='".$id."'";
		//echo $sql;die();
		$result = $database->prepare($sql);
		if($result->execute()){
			$this->workStatusEntry($id, $status_id, $status_date, $agencyid, $challanno, $remark);
		}else{
			$success = $database->error;
		}
		$result->close();
		$database->close();
	}
	
	public function workStatusEntry($id, $status_id, $status_date, $agencyid, $challanno, $remark){
		$database = new Database();
		
		$entrydate 		= date('Y-m-d H:i:s');
		$createdby 		= $_SESSION['ADMIN_NAME'];
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		$sql = "INSERT INTO work_status(assigned_id, challanno, orderno, suborderno, agencyid, status_date, status_id, remark, entrydate, createdby, ipaddress) SELECT id, '".$challanno."', orderno, suborderno, '".$agencyid."', '".$status_date."', '".$status_id."', '".$remark."', '".$entrydate."', '".$createdby."', '".$ipaddress."' FROM suborder_items WHERE id = '".$id."'";
		//echo $sql; die();
		$result = $database->prepare($sql);
		$result->execute();
		$result->close();
		$database->close();
	}
	
	public function getStatusName($status_id){
		$database = new Database();
		
		$status_id	= $this->sanitize($status_id);
		$sql = "SELECT statusname FROM status_master WHERE id ='".$status_id."'";
		$result = $database->query($sql);
		
		$field = $result->fetch_assoc();
		$database->close();
		
		return $field['statusname'];
	}
	
	public function getAssignedWorkData($assignedid) {
		$database 		= new Database();	
		$assignedid		= $this->sanitize($assignedid);
		
		$sql = "SELECT * FROM work_status WHERE assigned_id = '".$assignedid."'";
		
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc()){
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getWorkStatusAssignedId($assignedid){
		$database 		= new Database();	
		$assignedid		= $this->sanitize($assignedid);
		
		$sql = "SELECT s.statusname, DATE_FORMAT(w.status_date,'%b %d %Y') AS status_entry_date, a.agencyname, w.challanno FROM work_status w INNER JOIN status_master s ON w.status_id = s.id INNER JOIN agencymaster a ON w.agencyid = a.id WHERE w.assigned_id = '".$assignedid."'";
		
		$result = $database->query($sql);
		
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function updateAssignedWork(){
		$database = new Database();
		
		$id 			= $this->sanitize($_POST["id"]);
		
		$challanno 		= $this->sanitize($_POST["challanno"]);
        $agencyid 		= $this->sanitize($_POST["agencyid"]);
		$status_date 	= $this->sanitize($_POST["status_date"]);
        $assignstatus 	= $this->sanitize($_POST["assignstatus"]);
		
		$createdon 		= date('Y-m-d H:i:s');
		$createdby 		= $admin_name? $admin_name: '';
		$modifiedon 	= date('Y-m-d H:i:s');
		$modifiedby 	= $admin_name? $admin_name: '';
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		$sql = "UPDATE suborder_items SET status_id='".$assignstatus."' WHERE id='".$id."'";
		
		$result = $database->prepare($sql);
		if($result->execute()){
			$success = 'OK';
			$this->workStatusEntry($id, $assignstatus, $status_date, $agencyid, $challanno);
		}else{
			$success = $database->error;
		}
		$result->close();
		$database->close();
		return $success;
	}
	
	public function getallitemsbychallan($challanno){
		$database 		= new Database();	
		$challanno		= $this->sanitize($challanno);
		if($challanno == ''){
			$sql = "SELECT w.assigned_id, w.challanno, w.orderno, w.suborderno, w.agencyid, w.status_date, w.status_id, s.units, s.value, a.agencyname, i.itemname, f.fabricname FROM work_status w left join suborder_items s on w.assigned_id = s.id LEFT JOIN items i ON s.items = i.id LEFT JOIN fabric f ON s.fabric = f.id LEFT JOIN agencymaster a ON a.id = s.agencyid";
		}else{
			$sql = "SELECT w.assigned_id, w.challanno, w.orderno, w.suborderno, w.agencyid, w.status_date, w.status_id, s.units, s.value, a.agencyname, i.itemname, f.fabricname FROM work_status w left join suborder_items s on w.assigned_id = s.id LEFT JOIN items i ON s.items = i.id LEFT JOIN fabric f ON s.fabric = f.id LEFT JOIN agencymaster a ON a.id = s.agencyid WHERE w.challanno = '".$challanno."' ";
		}
		$result = $database->query($sql);
		
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getLastIDSuborderItems(){
		$database 		= new Database();
		
		$sql = "SELECT id FROM suborder_items order by id desc limit 1";
		$result = $database->query($sql);
		
		$field = $result->fetch_assoc();
		$result->close();
		$database->close();
		return $field;
	}
}

?>