<?php 
error_reporting(E_ERROR);
ini_set('display_errors', 1);
include_once("database.class.php");
include_once("class.config.php");

class Group extends config{
	
	//public $database;
	
	function __construct(){
		//parent::__construct();
		//$database = new Database(); 
		if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
		{
			$this->redirect('index.php');
			exit();
		}
	}
	
	function __destruct() {
		//parent::__construct();
		//$database->close;
	}
	
	public function getAll() {
		$database = new Database();
		
		$proAction = 'GROUPGETALL';	
		
		$sql = "CALL spsGroup('$proAction', '$groupid', '$groupname', '$groupdesc', '$menu', '$activestatus', '$createdby', '$createddate', '$modifiedby', '$modifiedon')";
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getById($id) {
		$database = new Database();
	
		// Initialize result array
		$result = array();
		$proAction = 'GROUPGET';
		$groupid = $this->sanitize($id);
		
		$sql = "CALL spsGroup('$proAction', '$groupid', '$groupname', '$groupdesc', '$menu', '$activestatus', '$createdby', '$createddate', '$modifiedby', '$modifiedon')";
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}	

	public function save() {
		$database = new Database();
			
		$menu 				= $this->sanitize($_POST['tall']);
		$menu 				= implode(",",$menu);
		
		$submit 			= $this->sanitize($_POST["submit"]);
		$ipadd 				= $this->sanitize($_SERVER['REMOTE_ADDR']);
		$admin_name 		= $this->sanitize($_SESSION['ADMIN_NAME']);

		$groupid 			= $this->sanitize($_POST["groupid"]);
              
		$groupname 			= $this->sanitize($_POST["groupname"]);
		$groupdesc 			= $this->sanitize($_POST["groupdesc"]);
		$activestatus 		= $this->sanitize($_POST["activestatus"]);
		$createddate 		= date('Y-m-d H:i:s');
		$createdby 			= $admin_name;
		$modifiedon 		= date('Y-m-d H:i:s');
		$modifiedby 		= $admin_name;
		
		if($submit == 'SAVE'){
			$proAction = 'GROUPINSERT';			
		}
		if($submit == 'UPDATE'){
			$proAction = 'GROUPUPDATE';	
		}
           
		$sql = "CALL spsGroup('$proAction', '$groupid', '$groupname', '$groupdesc', '$menu', '$activestatus', '$createdby', '$createddate', '$modifiedby', '$modifiedon')";
		$result = $database->prepare($sql);
		$result->execute();
		$result->bind_result($errorFlag, $errorDescription);
		$result->fetch();
		$_SESSION['msgD'] = $errorDescription;
		$result->close();
		$database->close();
		$this->redirect('manageGroupMaster.php');
	}
	
}

?>