<?php 
error_reporting(E_ERROR);
ini_set('display_errors', 1);
include_once("database.class.php");
include_once("class.config.php");

class User extends config{
	
	//public $database;
	
	function __construct() {
		//parent::__construct(); 
		//$database = new Database();
		if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
		{
			$this->redirect('index.php');
			exit();
		}
	}
	
	function __destruct() {
		//parent::__construct();
		//$database->close;
	}
	
	public function getAll() {
		$database = new Database();
		$proAction = 'USERALL';			
		
		$sql = "CALL spsUserMaster('$proAction', '$psuid', '$username', '$password', '$name', '$email', '$role', '$contact', '$ipadd', '$status',  '$logintype', '$createddate', '$createdby', '$modifiedby', '$modifiedon')";
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getGroupInfo() {
		$database = new Database();

		$proAction = 'USERGROUPINFO';			
		
		$sql = "CALL spsUserMaster('$proAction', '$psuid', '$username', '$password', '$name', '$email', '$role', '$contact', '$ipadd', '$status',  '$logintype', '$createddate', '$createdby', '$modifiedby', '$modifiedon')";
		//echo $sql;die();
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}

	public function getById($id){
		$database = new Database();
	
		// Initialize result array
		$result = array();
		$proAction = 'USERGET';			
		$psuid = $this->sanitize($id);
		$sql = "CALL spsUserMaster('$proAction', '$psuid', '$username', '$password', '$name', '$email', '$role', '$contact', '$ipadd', '$status',  '$logintype', '$createddate', '$createdby', '$modifiedby', '$modifiedon')";
		//echo $sql; die();
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}	

	public function save() {
		$database = new Database();
	
		$submit = $this->sanitize($_POST["submit"]);
		$ipadd = $this->sanitize($_SERVER['REMOTE_ADDR']);
		$admin_name = $this->sanitize($_SESSION['ADMIN_NAME']);
		$action_date = date('Y-m-d H:i:s');
		
		$psuid = $this->sanitize($_POST["psuid"]);
	       
        $username 	= $this->sanitize($_POST["username"]);
		$name 		= $this->sanitize($_POST["name"]);
		$email 		= $this->sanitize($_POST["email"]);
		$role 		= $this->sanitize($_POST["role"]);
		$contact 	= $this->sanitize($_POST["contact"]);
		$status 	= $this->sanitize($_POST["status"]);
		$logintype 	= $this->sanitize($_POST["logintype"]);
		
        $createddate = date('Y-m-d H:i:s');
        $createdby 	= $admin_name? $admin_name: '';
        $modifiedon = date('Y-m-d H:i:s');
        $modifiedby = $admin_name? $admin_name: '';
 
		if($submit == 'SAVE'){
			$proAction = 'USERINSERT';			
		}
		if($submit == 'UPDATE'){
			$proAction = 'USERUPDATE';	
		}
		
		$sql = "CALL spsUserMaster('$proAction', '$psuid', '$username', '$password', '$name', '$email', '$role', '$contact', '$ipadd', '$status',  '$logintype', '$createddate', '$createdby', '$modifiedby', '$modifiedon')";
		//echo $sql; die();
		$result = $database->prepare($sql);
		$result->execute();
        $result->bind_result($errorFlag, $errorDescription);
		$result->fetch();
        $_SESSION['msgD'] = $errorDescription;
		$result->close();
		
		$database->close();
		$this->redirect('manageUserMaster.php');
				
	}	
}

?>
