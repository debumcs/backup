<?php
session_start();
error_reporting(E_ERROR);
ini_set('display_errors', 0);
$PRO_TITLE = 'BIZCRM';
include_once("database.class.php");
 
class config{
    
	public function __construct() {
		//parent::__construct();
		//$database = new Database(); 
	}
	
	public function __destruct() {
		//parent::__construct();
		//$database->close;
	}
	
	public function updateConfig(){
		$database = new Database();	
		
		
		$customerid     	= $this->sanitize($_POST["customerid"]);
		$orderid			= $this->sanitize($_POST["orderid"]);
		//$familyid			= $this->sanitize($_POST["familyid"]);
		
		//$sql = "UPDATE config SET customerid='".$customerid."',orderid='".$orderid."',familyid='".$familyid."' WHERE id='1'";
		$sql = "UPDATE config SET customerid='".$customerid."', orderid='".$orderid."' WHERE id='1'";
		$result = $database->prepare($sql);
		if($result->execute()){
			$msgD = 'Query updated successfully.';						
		}else{
			$msgD = 'Error while executing query.';
		}
		$database->close();
		return $msgD;		
	}
	
	public function getConfig(){
		
		$database = new Database();	
		$sql = "SELECT * FROM config LIMIT 1";
		$query = $database->query($sql);

		$data = $query->fetch_assoc();
		$database->close();
		return $data;
	}
	
	function date_dmy_ymd($date){
		$dmy_date = explode('/',$date);
		$ymd_date = $dmy_date[2].'-'.$dmy_date[1].'-'.$dmy_date[0];
		return $ymd_date;
	}

	function date_ymd_dmy($date){
		$ymd_date = explode('-',$date);
		$dmy_date = $ymd_date[2].'/'.$ymd_date[1].'/'.$ymd_date[0];
		return $dmy_date;
	}
	
	public function getStatus($status){
		if($status == 1){
			return 'Incomplete';
		}else if($status == 2){
			return 'Pending';
		}else if($status == 3){
			return 'Processed';
		}else if($status == 4){
			return 'Partially Shipped';
		}else if($status == 5){
			return 'Shipping';
		}else if($status == 6){
			return 'Shipped';
		}else if($status == 7){
			return 'Partially Returned';
		}else if($status == 8){
			return 'Returned';
		}else{return 'Canceled';}
	}
	
	function pagination($total, $per_page = 10,$page = 1, $url = '?'){
    	$adjacents = "2";

    	$page = ($page == 0 ? 1 : $page);  
    	$start = ($page - 1) * $per_page;								
		
    	$prev = $page - 1;							
    	$next = $page + 1;
        $lastpage = ceil($total/$per_page);
    	$lpm1 = $lastpage - 1;
    	
    	$pagination = "";
    	if($lastpage > 1)
    	{	
    		$pagination .= "<div class='pagination'><ul>";
                    $pagination .= "<li class='details'>Page $page of $lastpage</li>";
    		if ($lastpage < 7 + ($adjacents * 2))
    		{	
    			for ($counter = 1; $counter <= $lastpage; $counter++)
    			{
    				if ($counter == $page)
    					$pagination.= "<li><a class='active'>$counter</a></li>";
    				else
    					$pagination.= "<li><a href='{$url}&page=$counter'>$counter</a></li>";					
    			}
    		}
    		elseif($lastpage > 5 + ($adjacents * 2))
    		{
    			if($page < 1 + ($adjacents * 2))		
    			{
    				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
    				{
    					if ($counter == $page)
    						$pagination.= "<li><a class='active'>$counter</a></li>";
    					else
    						$pagination.= "<li><a href='{$url}&page=$counter'>$counter</a></li>";					
    				}
    				$pagination.= "<li class='dot'>...</li>";
    				$pagination.= "<li><a href='{$url}&page=$lpm1'>$lpm1</a></li>";
    				$pagination.= "<li><a href='{$url}&page=$lastpage'>$lastpage</a></li>";		
    			}
    			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
    			{
    				$pagination.= "<li><a href='{$url}&page=1'>1</a></li>";
    				$pagination.= "<li><a href='{$url}&page=2'>2</a></li>";
    				$pagination.= "<li><span class='delimeter'>...</span></li>";
    				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
    				{
    					if ($counter == $page)
    						$pagination.= "<li><a class='active'>$counter</a></li>";
    					else
    						$pagination.= "<li><a href='{$url}&page=$counter'>$counter</a></li>";					
    				}
    				$pagination.= "<li><span class='delimeter'>...</span></li>";
    				$pagination.= "<li><a href='{$url}&page=$lpm1'>$lpm1</a></li>";
    				$pagination.= "<li><a href='{$url}&page=$lastpage'>$lastpage</a></li>";		
    			}
    			else
    			{
    				$pagination.= "<li><a href='{$url}&page=1'>1</a></li>";
    				$pagination.= "<li><a href='{$url}&page=2'>2</a></li>";
    				$pagination.= "<li><span class='delimeter'>...</span></li>";
    				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
    				{
    					if ($counter == $page)
    						$pagination.= "<li><a class='active'>$counter</a></li>";
    					else
    						$pagination.= "<li><a href='{$url}&page=$counter'>$counter</a></li>";					
    				}
    			}
    		}
    		
    		if ($page < $counter - 1){
    			$pagination.= "<li><a href='{$url}&page=$next'>Next</a></li>";
                $pagination.= "<li><a href='{$url}&page=$lastpage'>Last</a></li>";
    		}else{
    			$pagination.= "<li><a class='active'>Next</a></li>";
                $pagination.= "<li><a class='active'>Last</a></li>";
            }
    		$pagination.= "</ul></div>\n";		
    	}
    
    
        return $pagination;
    }
	
	function initials($string) {
        if(!(empty($string))) {
            if(strpos($string, " ")) {
                $string = explode(" ", $string);
                $count = count($string);
                $new_string = '';
                for($i = 0; $i < $count; $i++) {
                $first_letter = substr(ucwords($string[$i]), 0, 1);
                $new_string .= $first_letter;
            }
            return $new_string;
            } else {
                $first_letter = substr(ucwords($string), 0, 1);
                $string = $first_letter;
                return $string;
            }
        } else {
            return "empty string!";
        }
    }
	
	public function fetchAssoc($sql){
		$database = new Database();
		$alldata = array();
		$result = $database->query($sql);

		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
    
    public function getCountry(){
		$sql = "SELECT * FROM countries";
		$result = $this->fetchAssoc($sql);
		
		return $result;
	}
        
    public function getState($id) {
		$sql = "SELECT * FROM states WHERE country_id = '".$id."'";
		$result = $this->fetchAssoc($sql);
		
		return $result;
	}
        
    public function getCity($id) {
		$sql = "SELECT * FROM cities WHERE state_id = '".$id."'";
		$result = $this->fetchAssoc($sql);
		
		return $result;
	}
        
    public function base_url(){
		$base_url = 'http://10.100.8.37/bizcrm/';
		return $base_url;
    }    
        
    public function all_menu_list(){
	
		$database = new Database();	
		$sql = "SELECT menuid, header, parent_menuid, pagename FROM menuitem";
		$query = $database->query($sql);

		$refs = array();
		// create and array to hold the list
		$list = array();

		while($data = $query->fetch_assoc())
		{
			$thisref = &$refs[ $data['menuid'] ];
			$thisref['parent_menuid'] = $data['parent_menuid'];
			$thisref['header'] = $data['header'];
			$thisref['pagename'] = $data['pagename'];
			$thisref['menuid'] = $data['menuid'];

			if ($data['parent_menuid'] == 0)
			{
				$list[ $data['menuid'] ] = &$thisref;
			}
			else
			{
				$refs[ $data['parent_menuid'] ]['children'][ $data['menuid'] ] = &$thisref;
			}
		}	
		$database->close();
		return $list;
	}

    public function create_all_menu_list( $arr, $explode_menu )
    {
		$html = "<ul>";
		foreach ($arr as $key=>$v)
		{
			$html .= '<li>';
			$html .= '<input type="checkbox" name="tall[]" id="tall-'.$v['menuid'].'" '.$this->checkarray($v['menuid'],$explode_menu).' value="'.$v['menuid'].'">';
			$html .= '<label for="tall-'.$v['menuid'].'" class="custom-'.$this->checkarray($v['menuid'],$explode_menu).'">'.$v['header'].'</label>';
			if (array_key_exists('children', $v))
			{
				$html .= $this->create_all_menu_list($v['children'], $explode_menu);
			}
			else{}
			$html .= "</li>";
		}
		$html .= "</ul>";
		
		return $html;
    }
	
	public function hasChild($id){	
		$database = new Database();
		$sql = "SELECT COUNT(*) AS total FROM menuitem WHERE parent_menuid = ? ";
		$result = $database->prepare($sql);
		$result->bind_param('i',$id);
		$result->execute();
		$result->bind_result($total);
		$result->fetch();
		$database->close();

		return $total;	
    }

    public function getUserDetails($id){	
		$database = new Database();
		$sql = "SELECT username, name, email, role FROM adminuser WHERE username = ? LIMIT 1";
		$result = $database->prepare($sql);
		$result->bind_param('s',$id);
		$result->execute();
		$result->bind_result($username, $name, $email, $role);
		$result->fetch();
		$database->close();
		$data = array(
			'username' => $username, 
			'name' => $name,
			'email' => $email,
			'managerid' => $managerid,
			'role' => $role
		);
		return $data;	
    }

    public function menu_items(){
		$user_details = $this->getUserDetails($_SESSION['ADMIN_NAME']);
		$database = new Database();	
		$sql = "SELECT m.menuid, m.header, m.parent_menuid, m.pagename FROM grouprole g INNER JOIN menuitem m ON FIND_IN_SET(m.menuid, g.menu) WHERE g.groupid = '".$user_details['role']."' ORDER BY m.menuorder ASC";
		//echo $sql;
		$query = $database->query($sql);

		$refs = array();
		// create and array to hold the list
		$list = array();

		while($data = $query->fetch_assoc())
		{
			$thisref = &$refs[ $data['menuid'] ];
			$thisref['parent_menuid'] = $data['parent_menuid'];
			$thisref['header'] = $data['header'];
			$thisref['pagename'] = $data['pagename'];
			$thisref['menuid'] = $data['menuid'];

			if ($data['parent_menuid'] == 0)
			{
				$list[ $data['menuid'] ] = &$thisref;
			}
			else
			{
				$refs[ $data['parent_menuid'] ]['children'][ $data['menuid'] ] = &$thisref;
			}
		}
		$database->close();
		return $list;
	}
	
	public function getURLstatus($pagename){	
		$database = new Database();
		$sql = "SELECT parent_menuid FROM `menuitem` WHERE pagename = ? ";
		$result = $database->prepare($sql);
		$result->bind_param('s',$pagename);
		$result->execute();
		$result->bind_result($parent_menuid);
		$result->fetch();
		$database->close();

		return $parent_menuid;	
    }

    public function create_menu( $arr, $class )
    {
		$urlpagename = basename($_SERVER['PHP_SELF']);
		$parent_menuid = $this->getURLstatus($urlpagename);
		
		if($class == 0){
			$ulclass = 'sidebar-menu';
			$liclass = "treeview";
			
			$istart = '<i class="fa fa-table"></i>';		
		}
		
		if($class == 1){
			$ulclass = 'treeview-menu';
			$liclass = '';
			$istart = '<i class="fa fa-circle-o"></i>';		
		}	
		
		$html = "<ul class=".$ulclass.">";
		foreach ($arr as $key=>$v) 
		{
			$child1 = $this->hasChild($v['menuid']);
			
			if($urlpagename == $v['pagename']){$urlactive = ' active';}else{$urlactive = '';}
			if($parent_menuid == $v['menuid']){$expandactive = ' active';}else{$expandactive = '';}
			$html .= '<li class="'.$liclass.$urlactive.$expandactive.'" ><a href='.$v['pagename'].'>'.$istart.'<span>'.$v['header'].'</span>';
			if($child1>0){
				$html .= '<i class="fa fa-angle-left pull-right"></i>';
			}
			$html .='</a>';
			
			
			if (array_key_exists('children', $v))
			{
				$html .= $this->create_menu($v['children'], 1);
			}
			else{}
			$html .= "</li>";
		}
		$html .= "</ul>";
		return $html;
    }
    
    public function pssidebar(){
	
    ?>	      
		<aside class="main-sidebar">
		<!-- sidebar: style can be found in sidebar.less -->
		<script>
		function validate(){
			if(document.getElementById('search').value ==''){
				alert('Please enter search value!');
				document.getElementById('search').focus();
				return false;
			}else{
				return true;
			}
		}
		</script>
			<section class="sidebar">
			<!-- Sidebar user panel -->
				<form action="search.php" name="userCreate" id="userCreate" method="post" class="sidebar-form">
				<div class="input-group" style="width:100%;">
					<select class="form-control" id="option" name="option" style="width:100%;">
					<option <?php if(isset($_POST['option']) and $_POST['option'] == 'name'){echo 'selected';} ?> value='name'>Customer Name</option>
					<option <?php if(isset($_POST['option']) and $_POST['option'] == 'email'){echo 'selected';} ?> value='email'>Customer Email</option>
					<option <?php if(isset($_POST['option']) and $_POST['option'] == 'custid'){echo 'selected';} ?> value='custid'>Customer Id</option>
					<option <?php if(isset($_POST['option']) and $_POST['option'] == 'phone'){echo 'selected';} ?> value='phone'>Customer Phone</option>
					<option <?php if(isset($_POST['option']) and $_POST['option'] == 'order'){echo 'selected';} ?> value='order'>Order No</option>
					</select>
				</div>
				<div class="input-group">
					<input type="text" id="search" name="search" class="form-control" value="<?php  if(isset($_POST['option'])){echo $_POST['search'];}  ?>" placeholder="Search...">
					<input type="hidden" name="task" class="btn btn-warning left-10" value="search" />
					<span class="input-group-btn">
						<button type="submit" id="search-btn" onclick="return validate();" name="submit" id="submit" class="btn btn-flat"><i class="fa fa-search"></i></button>
					</span>
				</div>
				</form>
			<!-- sidebar menu: : style can be found in sidebar.less -->
			<?php 
				$menu_items = $this->menu_items();
				echo $this->create_menu( $menu_items,0);
			?>
			</section>
		<!-- /.sidebar -->
		</aside>	
    <?php
    }

    public function psheader(){ ?>
    <header class="main-header">
            <!-- Logo -->
			<?php  ?>
            <a href="home.php" class="logo" style="padding-left:1px;">
              <!-- mini logo for sidebar mini 50x50 pixels -->
              <span class="logo-mini"><img src="dist/img/logo-icon.png"/></span>
              <!-- logo for regular state and mobile devices -->
              <span class="logo-lg"><img src="dist/img/logo3.jpg" width="235px" height="40px"/></span>
            </a><?php  ?>

		<!-- Script for watchs -->
		
           
		<!-- Script for watchs -->

            <!-- Header Navbar: style can be found in header.less -->
            <nav class="navbar navbar-static-top" role="navigation">
              <!-- Sidebar toggle button-->

			  <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                <span class="sr-only">Toggle navigation</span>
              </a>
			             
							 
			  <div class="navbar-custom-menu">
			    <ul class="nav navbar-nav">
			      <!-- User Account: style can be found in dropdown.less -->
                  <li class="dropdown user user-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                      <img src="dist/img/user3.png" class="user-image" alt="User Image">
                      <span class="hidden-xs"></span>
                    </a>
                    <ul class="dropdown-menu">
                      <!-- User image -->
                      <li class="user-header">
                        <img src="dist/img/user3.png" class="img-circle" alt="User Image">
                        <p>
                          <?php echo $_SESSION['NAME'];?>
                          <small>Member since <?php echo date("d-M-Y", strtotime($_SESSION['createddate']));?></small>
                        </p>
                      </li>
                      <!-- Menu Body -->

                      <!-- Menu Footer-->
                      <li class="user-footer">
                        <div style="text-align:center;">
                          <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                        </div>
                      </li>
                    </ul>
                  </li>
                  <!-- Control Sidebar Toggle Button -->

                </ul>
              </div>
            </nav>
          </header>	
    <?php
    }

    public function checkarray($item,$array){
		if(in_array($item,$array)){
				return 'checked';
		}else{
				return 'unchecked';
		}
    }
	
	public function ConvertTimezoneToAnotherTimezone($time, $currentTimezone) {

        $userTimezone = ''; 
		switch ($currentTimezone) 
		{ 
			case 'PST':  $userTimezone = 'America/Los_Angeles'; break; 
			case 'CST':  $userTimezone = 'America/Chicago'; break; 
			case 'MST':  $userTimezone = 'US/Mountain'; break; 
			case 'EST':  $userTimezone = 'US/Eastern'; break;                 
			case 'IST':  $userTimezone = 'Asia/Kolkata'; break;    
		} 
		//if($userTimezone!='') 
		//date_default_timezone_set($userTimezone);

        $dayLightFlag = false;
		$dayLgtSecCurrent = $dayLgtSecReq = 0;
		$system_timezone = date_default_timezone_get();
		$local_timezone = $userTimezone;
		date_default_timezone_set($local_timezone);
		$local = date("Y-m-d H:i:s");
		date_default_timezone_set("GMT");
		$gmt = date("Y-m-d H:i:s ");

		$require_timezone = 'Asia/Kolkata';
		date_default_timezone_set($require_timezone);
		$required = date("Y-m-d H:i:s ");

		date_default_timezone_set($system_timezone);

		$diff1 = (strtotime($gmt) - strtotime($local));
		$diff2 = (strtotime($required) - strtotime($gmt));

		$date = new DateTime($time);

		$date->modify("+$diff1 seconds");
		$date->modify("+$diff2 seconds");

		if ($dayLightFlag) {
			$final_diff = $dayLgtSecCurrent + $dayLgtSecReq;
			$date->modify("$final_diff seconds");
		}

		$timestamp = $date->format("Y-m-d H:i:s ");

		return $timestamp;
    }

    public function TimeZoneCastNew($currentdatetime,$zonetime) 
    { 
		$myDateTime = new DateTime($currentdatetime); 
		switch ($zonetime) 
		{ 
			case 'PST': 
				$myDateTime->setTimezone(new DateTimeZone('America/Los_Angeles')); 
				$finaldatetime = $myDateTime->format("Y-m-d H:i:s"); 
				break;

			case 'CST': 
				$myDateTime->setTimezone(new DateTimeZone('America/Chicago')); 
				$finaldatetime = $myDateTime->format("Y-m-d H:i:s"); 
				break;

			case 'MST': 
				$myDateTime->setTimezone(new DateTimeZone('US/Mountain')); 
				$finaldatetime = $myDateTime->format("Y-m-d H:i:s"); 
				break;

			case 'EST':    
				$myDateTime->setTimezone(new DateTimeZone('US/Eastern')); 
				$finaldatetime = $myDateTime->format("Y-m-d H:i:s"); 
				break;

			case 'IST':    
				$myDateTime->setTimezone(new DateTimeZone('Asia/Kolkata')); 
				$finaldatetime = $myDateTime->format("Y-m-d H:i:s"); 
				break;

			default : 
				$finaldatetime = $currentdatetime; 
				break;
		} 
		return $finaldatetime;
    }

    public function sanitize($input)
    {  //global $conn;
		$object = new Database();
		if (is_array($input)) {
			foreach($input as $var=>$val) {
					$output[$var] = $this->sanitize($val);
			}
		}
		else {
			if (get_magic_quotes_gpc()) {
				$input = stripslashes($input);
			}
			$input  = $this->cleanInput($input);
			$output = $object->real_escape_string($input);
		}
		
		return $output;
    }
	
    public function cleanInput($input) {  
       
        $input = str_replace("'",'',$input);   // replaces single quotes
		//die();
		//$input= preg_replace('/\'/', '&apos;', $input);
        
        $search = array(
            '@<script[^>]*?>.*?</script>@si',   // Strip out javascript
            '@<[\/\!]*?[^<>]*?>@si',            // Strip out HTML tags
            '@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
            '@<![\s\S]*?--[ \t\n\r]*>@'         // Strip multi-line comments
        );
        $output = preg_replace($search, '', $input);
        return $output;
    }
	
	public function redirect($url) {
		if (isset($url)) {
			header("Location: " . $url);
		}
	}

	public function sanitize_output($string) {
		return htmlspecialchars($string);
	}
 
}
