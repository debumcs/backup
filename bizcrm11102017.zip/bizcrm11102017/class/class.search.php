<?php 
error_reporting(E_ERROR);
ini_set('display_errors', 1);
include_once("database.class.php");
include_once("class.config.php");

class Search extends config{
	
	//public $database;
	
	function __construct() {
		//parent::__construct(); 
		//$database = new Database();
		if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
		{
			$this->redirect('index.php');
			exit();
		}
	}
	
	function __destruct() {
		//parent::__construct();
		//$database->close;
	}
		
	public function getSearchDetail($option,$search) {
		$database = new Database();
		//print $option.' '.$search; exit;
		//if($_SESSION['ROLE'] == '1' || $_SESSION['ROLE'] == '2'){
			if($option =='name')
			{
				$sql = "select * from customer where name_first like '%$search%' || name_last like '%$search%'"; 
			}
			else if($option =='email' && $search !=='')
			{
				$sql = "select * from customer where email_1 like '%$search%' || email_2 like '%$search%'";
			}
			else if($option == 'order')
			{
				$sql = "select a.* from customer AS a, orderdetails AS b WHERE a.cust_id = b.customer_id AND b.orderno like '%$search%'";
			}
			else if($option =='custid' && $search !=='')
			{
				$sql = "select * from customer where cust_id like '%$search%'";
			}
			else if($option =='phone' && $search !=='')
			{
				$sql = "select * from customer where contact_no1 like '%$search%'";
			}
		/*}
		else{
			if($option =='name')
			{
				 $sql = "SELECT * FROM customer c INNER JOIN orderdetails a ON c.cust_id = a.customer_id 
						INNER JOIN order_mapping b ON a.orderno = b.orderno 
						WHERE (c.name_first LIKE '%$search%' || c.name_last LIKE '%$search%') AND (b.agent_id = '".$_SESSION['ADMIN_NAME']."' AND b.status = '1') group by c.cust_id";
				//print $sql;	exit;
			}
			else if($option =='email' && $search !=='')
			{
				$sql = "SELECT * FROM customer c INNER JOIN orderdetails a ON c.cust_id = a.customer_id 
						INNER JOIN order_mapping b ON a.orderno = b.orderno 
						WHERE (c.email_1 LIKE '%$search%' || c.email_2 LIKE '%$search%') AND (b.agent_id = '".$_SESSION['ADMIN_NAME']."' AND b.status = '1')";
			}
			else if(trim($option) == 'order')
			{
				$sql = "SELECT * FROM customer c INNER JOIN orderdetails a ON c.cust_id = a.customer_id 
						INNER JOIN order_mapping b ON a.orderno = b.orderno 
						WHERE (a.orderno LIKE '%$search%') AND (b.agent_id = 'QUA07859' AND b.status = '1')";
			}
			else if($option =='custid' && $search !=='')
			{
				$sql = "SELECT * FROM customer c INNER JOIN orderdetails a ON c.cust_id = a.customer_id 
						INNER JOIN order_mapping b ON a.orderno = b.orderno 
						WHERE (c.cust_id LIKE '%$search%') AND (b.agent_id = '".$_SESSION['ADMIN_NAME']."' AND b.status = '1')";
			}
			else if($option =='phone' && $search !=='')
			{
				$sql = "SELECT * FROM customer c INNER JOIN orderdetails a ON c.cust_id = a.customer_id 
						INNER JOIN order_mapping b ON a.orderno = b.orderno 
						WHERE (c.contact_no1 LIKE '%$search%' || c.contact_no2 LIKE '%$search%') AND (b.agent_id = '".$_SESSION['ADMIN_NAME']."' AND b.status = '1')";
			}
		}*/

		if($sql)
		{
			$result = $database->query($sql);
			$alldata = array();
			while($field = $result->fetch_array(MYSQLI_ASSOC))
			{
				$alldata[] = $field;
			}
		}

		$database->close();
		return $alldata;
	}
	
	
	public function getorderDetail($cust_id) {
		$database = new Database();
		if($cust_id){
			$sql = "select * from orderdetails where customer_id='".$cust_id."'"; 
			$result = $database->query($sql);
			$alldata = array();
			while($field = $result->fetch_array(MYSQLI_ASSOC))
			{
				$alldata[] = $field;
			}
		}
		$database->close();
		return $alldata;
	}

	public function getorderDetailByorderID($order_id) {
		$database = new Database();
		//print '---------------------------------------------------'; 
		 //$sql = "CALL spsSearch('$option', '$search')"; 
		 
		 
        if($order_id){
			
			$sql = "select * from orderdetails where orderno='".$order_id."'"; 
	  
		$result = $database->query($sql);
		$alldata = array();
		
		
		while($field = $result->fetch_array(MYSQLI_ASSOC))
		{
			$alldata[] = $field;
		}
		
			
		}
	    
		
		
		
		$database->close();
		
		//return $field = $result->fetch_assoc();
		return $alldata;
	}
	
	
	    public function addCustomernote($notes,$custid,$agent_id,$ip)  
	    {
				$database = new Database();
				
		  
                //$notes = mysql_real_escape_string ($notes);
		

	            $timestamp = date('Y-m-d H:i:s');
		
				$sql="insert into notes(customer_id,notes,notes_date,status,agent_id,ipaddr) VALUES('".$custid."','".$notes."','".$timestamp."','1','".$agent_id."','".$ip."')";
	
				$res = $database->query($sql);
				
				
				return $result = $this->getCustomerNotes($custid);
				
				
				$database->close();

      }
	  
	  	public function getCustomerNotes($cust_id) {
			
				$database = new Database();
				//print '---------------------------------------------------'; 
				 //$sql = "CALL spsSearch('$option', '$search')"; 
				 
				 
				if($cust_id){
					
					$sql = "SELECT a.*, b.name FROM notes a LEFT JOIN adminuser b ON a.agent_id = b.username WHERE a.customer_id ='".$cust_id."' ORDER BY id DESC"; 
			  
				$result = $database->query($sql);
				$alldata = array();
				
				
				while($field = $result->fetch_array(MYSQLI_ASSOC))
				{
					$alldata[] = $field;
				}
				
					
				}
				
				
				
				
				$database->close();
				
				//return $field = $result->fetch_assoc();
				return $alldata;
	}
	
	public function addsubordernotes($suborder_notes,$suborderno,$agent_id,$ipaddr,$status)  
	{
		$database = new Database();
		$subnotes_date = date('Y-m-d H:i:s');
		$createdby = $_SESSION['ADMIN_NAME'];
		$sql="INSERT INTO suborder_notes(suborderno, suborder_notes, subnotes_date, status, agent_id, ipaddr, createdby) VALUES ('$suborderno', '$suborder_notes', '$subnotes_date', '$status', '$agent_id', '$ipaddr', '$createdby')";
		
		$res = $database->query($sql);
		$database->close();
		$limit = 5;
		return $result = $this->getSubOrderNotes($suborderno);
	}
	  
	public function getSubOrderNotes($suborderno) {

		$database = new Database();
		
		if($suborderno){

			$sql = "SELECT a.*, b.name FROM suborder_notes a LEFT JOIN adminuser b ON a.agent_id = b.username WHERE a.suborderno ='".$suborderno."' ORDER BY a.subnotes_date DESC  "; 

			$result = $database->query($sql);
			$alldata = array();

			while($field = $result->fetch_array(MYSQLI_ASSOC))
			{
				$alldata[] = $field;
			}
		}
		$database->close();
		return $alldata;
	}
	
	public function addOrdernote($notes,$orderid,$agent_id,$ip,$status)  
	{
		$database = new Database();
		$timestamp = date('Y-m-d H:i:s');
		$createdby = $_SESSION['ADMIN_NAME'];
		$sql="insert into order_notes(orderno,order_notes,notes_date,status,agent_id,ipaddr,createdby) VALUES('".$orderid."', '".$notes."', '".$timestamp."', '".$status."', '".$agent_id."', '".$ip."', '".$createdby."')";
		//echo $sql;die();
		$res = $database->query($sql);
		$database->close();
		$limit = 5;
		return $result = $this->getorderNotes($orderid);
	}
	  
	public function getorderNotes($orderid) {

		$database = new Database();
		
		if($orderid){

			$sql = "SELECT a.*, b.name FROM order_notes a LEFT JOIN adminuser b ON a.agent_id = b.username WHERE a.orderno ='".$orderid."' ORDER BY id DESC  "; 

			$result = $database->query($sql);
			$alldata = array();

			while($field = $result->fetch_array(MYSQLI_ASSOC))
			{
				$alldata[] = $field;
			}
		}
		$database->close();
		return $alldata;
	}
	
	
	public function getpaymentstaticsByCudtid($custid) {

		$database = new Database();

		if($custid){
			/*$sql = "SELECT LEFT(A.order_date,4) AS orderyear, SUM(A.sale_amount) AS TotalSaleAmt, SUM(A.discount) AS TotalDisAmt ,A.customer_id,
			SUM(IFNULL(B.received_amount,0)) AS ClearedAmt, (SUM(A.sale_amount) - SUM(IFNULL(B.received_amount,0))) AS BalanceAmt
			FROM orderdetails A LEFT JOIN payment B
			ON A.orderno = B.orderno
			WHERE A.customer_id='".$custid."'
			GROUP BY LEFT(A.order_date,4),A.customer_id
			ORDER BY LEFT(A.order_date,4) DESC LIMIT 10";*/
			
			
			/*$sql = "SELECT LEFT(A.order_date,4) AS orderyear, SUM(A.total_amount) AS TotalSaleAmt, SUM(A.amount_received) AS TotalDisAmt , SUM(IFNULL(B.received_amount,0)) AS ClearedAmt, (SUM(A.total_amount) - SUM(IFNULL(B.received_amount,0))) AS BalanceAmt , A.customer_id,
concat(cu.name_first, ' ', cu.name_middle, ' ', cu.name_last) cust_name
 FROM orderdetails A LEFT JOIN payment B ON A.orderno = B.orderno 
inner join customer cu on cu.cust_id=A.customer_id
			WHERE A.customer_id='".$custid."'
			GROUP BY LEFT(A.order_date,4),A.customer_id
			ORDER BY LEFT(A.order_date,4) DESC LIMIT 10";
			*/
			//Added by Brijesh
			
			$sql = "SELECT 
					LEFT(o.order_date,4) AS orderyear, s.TotalSaleAmt,s.TotalDisAmt,
					CONCAT(c.name_first,' ',c.name_last) AS cust_name,   
					o.customer_id, o.orderno, (s.netamount - p.received_amount) AS BalanceAmt, p.received_amount AS ClearedAmt
					FROM orderdetails o 
					INNER JOIN customer c ON o.customer_id = c.cust_id 
					LEFT JOIN (SELECT orderno, CONVERT(SUM(IFNULL(sale_amount,0)), DECIMAL(17,2)) AS TotalSaleAmt, 
					CONVERT(SUM(CASE WHEN discount_type = 'Percentage' THEN (IFNULL(sale_amount,0) * IFNULL(discount_amount,0)/100) 
					ELSE IFNULL(discount_amount,0) END), DECIMAL(17,2)) AS TotalDisAmt, 
					CONVERT(SUM(CASE WHEN discount_type = 'Percentage' THEN IFNULL(sale_amount,0) - (IFNULL(sale_amount,0) * IFNULL(discount_amount,0)/100) 
					ELSE IFNULL(sale_amount,0) - IFNULL(discount_amount,0) END), DECIMAL(17,2)) AS netamount 
					FROM suborder GROUP BY orderno) s ON s.orderno = o.orderno 
					LEFT JOIN (SELECT SUM(received_amount) AS received_amount, orderno FROM `payment` 
					GROUP BY orderno) p ON p.orderno = o.orderno 
					WHERE o.customer_id='".$custid."' GROUP BY o.customer_id 
					ORDER BY LEFT(o.order_date,4) DESC LIMIT 10";
					
//print $sql; exit;
			$result = $database->query($sql);
			$alldata = array();

			while($field = $result->fetch_array(MYSQLI_ASSOC))
			{
				$alldata[] = $field;
			}
		}

		$database->close();

		return $alldata;
	}
	
	public function getPaymentDetailsByOrderNo($orderno) {

		$database = new Database();
		if($orderno){
			$sql = "SELECT * FROM payment WHERE orderno = '".$orderno."' order by id desc";
			$result = $database->query($sql);
			$alldata = array();
			
			while($field = $result->fetch_assoc())
			{
				$alldata[] = $field;
			}
		}
		$database->close();
		return $alldata;
	}
	
}

?>