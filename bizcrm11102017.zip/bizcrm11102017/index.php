<?php 
session_start(); 
include_once("config.php");
include_once("class/class.postlogin2.php");
$objpostlogin=new postlogin();  
	
//print_r($_GET);die;

if(isset($_REQUEST['code'])){
	$gClient->authenticate();
	$_SESSION['token'] = $gClient->getAccessToken();
}

if (isset($_SESSION['token'])) {
	$gClient->setAccessToken($_SESSION['token']);
}

if ($gClient->getAccessToken()) {
	$userProfile = $google_oauthV2->userinfo->get();
	//$_SESSION['google_data'] = $userProfile; // Storing Google User Data in Session
	//header("location: account.php");
	$_SESSION['token'] = $gClient->getAccessToken();
	$objpostlogin->getuserlogin($userProfile['email'],'','');
} else {
	$authUrl = $gClient->createAuthUrl();
}

?>
<!DOCTYPE html>
<html lang="en">
 
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>BIZCRM</title>

    <!-- Bootstrap core CSS -->

    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styling plus plugins -->
    <link href="dist/css/form.css" rel="stylesheet">
    
    <style>
	body {
		color: #73879C;
		background:url(dist/img/bg8.jpg) no-repeat center center fixed;
		-webkit-background-size: cover;
		-moz-background-size: cover;
		-o-background-size: cover;
		background-size: cover;
    }
	.register{
		background: #e3e3e3;
		border: 1px solid #ccc;
		color: #333 !important;
		font-size: 14px !important;
		font-weight: bold;
		padding: 8px 0 8px !important;
		text-align: center !important;
		width: 160px;
		cursor: pointer;
		float: right;
		margin: 15px 8px 10px 10px;
		text-shadow: 0px 0px 0px #fff !important;
		-moz-border-radius: 4px;
		-webkit-border-radius: 4px;
		border-radius: 4px;
		-moz-box-shadow: 0px 0px 2px #fff inset;
		-webkit-box-shadow: 0px 0px 2px #fff inset;
		box-shadow: 0px 0px 2px #fff inset;
	}
	</style>
<script type="text/javascript">

function gmaillocalCheck() {
    if (document.getElementById('logintype1').checked) {
        document.getElementById('normal').style.display = 'block';
		document.getElementById('glogin').style.display = 'none';
    }
    else{
		document.getElementById('glogin').style.display = 'block';
		document.getElementById('normal').style.display = 'none';
	} 

}


	function encode64(data){

		var b64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
		var o1, o2, o3, h1, h2, h3, h4, bits, i = 0,
		ac = 0,
		enc = "",
		tmp_arr = [];

		if (!data) {
		return data;
		}

		do { // pack three octets into four hexets
			o1 = data.charCodeAt(i++);
			o2 = data.charCodeAt(i++);
			o3 = data.charCodeAt(i++);

			bits = o1 << 16 | o2 << 8 | o3;

			h1 = bits >> 18 & 0x3f;
			h2 = bits >> 12 & 0x3f;
			h3 = bits >> 6 & 0x3f;
			h4 = bits & 0x3f;

			// use hexets to index into b64, and append result to encoded string
			tmp_arr[ac++] = b64.charAt(h1) + b64.charAt(h2) + b64.charAt(h3) + b64.charAt(h4);
		} while (i < data.length);

		enc = tmp_arr.join('');

		var r = data.length % 3;

		return (r ? enc.slice(0, r - 3) : enc) + '==='.slice(r || 3);

	}
	
	function validation(){
		if(document.getElementById('username').value == ''){
			alert('Please enter username!');
			document.getElementById('username').focus();
			return false;
		}else if(document.getElementById('password').value == ''){
			alert('Please enter password!');
			document.getElementById('password').focus();
			return false;
		}else{
			//alert('return true!');
			return true;
		}
	}

</script>
    
</head>

<body>

	<nav class="navbar navbar-default lognav" role="navigation">
    	<a class="lognav-brand" href="#"><img src="dist/img/logo3.jpg" /></a>
    <!-- Collect the nav links, forms, and other content for toggling -->
    </nav>
    
    <div class="wrapper">
			
			<div class="content">
				<div id="form_wrapper" class="form_wrapper">
					
					<form class="login active" name="bizcrmlogin" id="bizcrmlogin" method="post" action="postlogin.php" >
						<h4>Login</h4>
						<?php if($_GET['flag']=="I") { ?><div><label style='color:red'>Incorrect Login ID or Password</label></div><?php } ?>
						
						<div style="padding-bottom: 30px;">
							<div class="col-lg-2">&nbsp;</div><div class="col-lg-3"><input type="radio" checked="true" onclick="javascript:gmaillocalCheck();" name="logintype" id="logintype1" value="Normal" /> Local</div>
							<div class="col-lg-2">&nbsp;</div><div class="col-lg-3"><input type="radio" onclick="javascript:gmaillocalCheck();" name="logintype" id="logintype2" value="Gmail" /> Gmail</div>
						</div>
						
						<div id="glogin" style="display:none; text-align:center; height:210px; padding-top:75px;">
							<?php 
							
							if(isset($authUrl)) {
								echo '<a href="'.$authUrl.'"><img src="images/glogin.png" alt=""/></a>';
							}
							
							?>&nbsp;
						</div>
						
						<div id="normal">
							<div>
								<label>Username:</label>
								<input type="text" name="username" class="form-control" id="username" autocomplete="off" value="" />
								<span class="error">This is an error</span>
							</div>
							<div>
								<label>Password: </label>
								<input type="password" name="password" class="form-control" id="password" autocomplete="off" value="" />
								<input name="ipaddress" type="hidden" class="form-control" id="ipaddress" value="<?php echo $_SERVER['REMOTE_ADDR'];?>" >
								<span class="error">This is an error</span>
							</div>
							<div class="bottom">
								<div style="width:100%;">
									<div style="width:48%; float:left;"><input type="submit" name="submit" id="submit" onclick="return validation();" value="Login" style="float:left" /></div>
									<div style="width:48%; float:right;"><a class="register" href="../bizcrm_customer/index.php">Customer Registration</a></div>
								</div>
								<div class="clear"></div>
							</div>
						</div>
					</form>
					
				</div>
				<div class="clear"></div>
			</div>
			
		</div>
        
<script language="javascript" type="text/javascript">
	document.bizcrmlogin.username.focus();
</script>    
</body>

</html>