<?php 
    require_once('class/class.invoice.php');
    $objInv = new invoice();
	
	if(isset($_POST['submit'])){
		$objInv->save();
		exit;
	}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | View All Invoice</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="dist/css/dataTables.bootstrap.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
   
   <link rel="stylesheet/less" type="text/css" href="side.less" />
	<link rel="stylesheet" href="date/jquery-ui.css">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
         <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
 <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objInv->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objInv->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Add Invoice
          </h1>
            <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Invoice</li>
            <li class="active">View All Invoice</li>
          </ol>
        </section><!--CONTENT HEADER-->
        
          <!-- Main content -->

        <section class="content">
            <div class="row">
            	<div class="col-md-12">
                    <div class="box box-warning">
                        <div class="box-header with-border">
                            <h3 class="box-title pull-right"><a href="viewallinvoice.php">View All</a></h3>
                        </div>
                        <div class='box-body table-responsive'>
                            <form action="" method="post">
                           <div class="row">
                            <div class="col-xs-4">
                             <div class="form-group">
                             <label for="email">GSTIN No:</label>
                             <input type="text" class="form-control" id="gstin_no" name = "gstin_no">
                           </div>
                            </div>
                            <div class="col-xs-4">
                             <div class="form-group">
                             <label for="email">Mobile No:</label>
                             <input type="text" class="form-control" id="mob_no" name = "mob_no">
                              </div>
                                  </div>
                                     <div class="col-xs-4">
                                        <div class="form-group">
                                   <label for="email">Email Id:</label>
                                   <input type="text" class="form-control" id="email" name = "email">
                                    </div>
                                    </div>
                          </div>  
                            <div class="row">
                                <div class="col-xs-4">
                                <div class="form-group">
                                    <label for="email">Name:</label>
                                <input type="text" class="form-control" id="firm_name" name = "firm_name" placeholder="Name of the Firm">
                                 </div>
                                  </div>
                                 <div class="col-xs-4">
                                 <div class="form-group">
                                     <label for="email">Address:</label>
                                <input type="text" class="form-control" id="firm_address" name = "firm_address" placeholder="Address of the Firm">
                                 </div>
                                  </div>
                                         <div class="col-xs-4">
                                  <div class="form-group">
                                      <label for="email">Main Product:</label>
                                <input type="text" class="form-control" id="products" name = "products" placeholder="Main Products in which Dealing">
                                 </div>
                                </div>
                         </div> 
                                <div class="row">
                                    <div class="col-xs-6">
                                     <div class="form-group">
                                     <label for="email">Date of Invoice:</label>
                                     <input type="date" class="form-control" id="invoice_date" name = "invoice_date">
                                   </div>
                                    </div>
                                    <div class="col-xs-6">
                                     <div class="form-group">
                                     <label for="email">Serial No of Invoice:</label>
                                     <input type="text" class="form-control" id="invoice_serialno" name = "invoice_serialno">
                                      </div>

                                    </div>

                                  </div>
                                <hr/>
 
 
  
                    <div class="row">
                       <div class="col-xs-6">
                           <h4> Details of Receiver(Billed to)</h4>
                       <div class="col-xs-6">
                        <div class="form-group">
                        <label for="email">Name:</label>
                        <input type="text" class="form-control" id="biller_name" name = "biller_name">
                      </div>
                        </div>
                              <div class="col-xs-6">
                      <div class="form-group">
                        <label for="email">Address:</label>
                            <textarea class="form-control" id="bill_to_address" name = "bill_to_address"></textarea>

                        </div>
                            </div>
                             <div class="col-xs-6">
                            <div class="form-group">
                        <label for="email">State:</label>
                        <input type="text" class="form-control" id="bill_to_state" name = "bill_to_state">
                      </div>
                      </div>
                      <div class="col-xs-6">
                      <div class="form-group">
                        <label for="email">State Code:</label>
                        <input type="text" class="form-control" id="bill_to_state_code" name = "bill_to_state_code">
                      </div>
                      </div>
                        <div class="col-xs-6">
                       <div class="form-group">
                        <label for="email">Mob No:</label>
                        <input type="text" class="form-control" id="bill_to_mob_no" name = "bill_to_mob_no">
                      </div>
                       </div>
                         <div class="col-xs-6">
                       <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="text" class="form-control" id="bill_to_email" name = "bill_to_email">
                      </div>
                        </div>


                       <div class="col-xs-6">
                        <div class="form-group">
                        <label for="email">GSTIN/Unique ID:</label>
                        <input type="text" class="form-control" id="bill_gstin_id" name = "bill_gstin_id">
                      </div>

                        </div>


                       </div>
                       <div class="col-xs-6">
                         <h4> Details of Consignee(Shipped to)</h4>
                      
                         <div class="col-xs-6">
                        <div class="form-group">
                        <label for="email">Name:</label>
                        <input type="text" class="form-control" id="ship_name" name = "ship_name">
                      </div>
                        </div>
                              <div class="col-xs-6">
                      <div class="form-group">
                        <label for="email">Address:</label>
                            <textarea class="form-control" id="ship_to_address" name = "ship_to_address"></textarea>

                        </div>
                             </div>
                              <div class="col-xs-6">
                            <div class="form-group">
                        <label for="email">State:</label>
                        <input type="text" class="form-control" id="ship_to_state" name = "ship_to_state">
                      </div>
                       </div>
                        <div class="col-xs-6">
                      <div class="form-group">
                        <label for="email">State Code:</label>
                        <input type="text" class="form-control" id="ship_to_state_code" name = "ship_to_state_code">
                      </div>
                      </div>
                         <div class="col-xs-6">
                       <div class="form-group">
                        <label for="email">Mob No:</label>
                        <input type="text" class="form-control" id="ship_to_mob_no" name = "ship_to_mob_no">
                      </div>
                        </div>
                            <div class="col-xs-6">
                       <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="text" class="form-control" id="ship_to_email" name = "ship_to_email">
                      </div>
                      </div>
                      <div class="col-xs-6">
                        <div class="form-group">
                        <label for="email">GSTIN/Unique ID:</label>
                        <input type="text" class="form-control" id="ship_gstin_id" name = "ship_gstin_id">
                      </div>
                       </div>

                       </div>

                     </div>
                                <hr />
 <div class="row">
   <div class="col-xs-12 main" >
   <div class="row">
       <button type="button" id="add" class="btn btn-warning pull-right">Add New</button>
   <h4 class="text-center yellow1"> Add Product Detail</h4>
   <div class="row">
   
 
  <div class="col-xs-4">
    <div class="form-group">
    <label for="email">Sr No:</label>
    <input type="text" class="form-control" id="sr_no" name = "sr_no[]">
  </div>
  </div>
   <div class="col-xs-4">
  <div class="form-group">
    <label for="email">Description of Goods:</label>
	<textarea class="form-control" id="Description" name = "Description[]"></textarea>
   
   </div>
     </div>
	 
	 <div class="col-xs-4">
	<div class="form-group">
    <label for="email">HSN Code:</label>
    <input type="text" class="form-control" id="hsn_code" name = "hsn_code[]">
  </div>
   </div>
   
   </div>
    <div class="row">
  
    <div class="col-xs-2">
  <div class="form-group">
    <label for="email">Qty:</label>
    <input type="text" class="form-control" id="qty" name = "qty[]">
  </div>
   </div>
    <div class="col-xs-2">
    <div class="form-group">
    <label for="email">Unit:</label>
    <input type="text" class="form-control" id="unit" name = "unit[]">
  </div>
   </div>
   <div class="col-xs-2">
   <div class="form-group">
    <label for="email">Rate per Item:</label>
    <input type="text" class="form-control" id="rate" name = "rate[]">
  </div>
   </div>
  
  
   <div class="col-xs-2">
   <div class="form-group">
    <label for="email">Total:</label>
    <input type="text" class="form-control" id="total" name = "total[]">
  </div>
  </div>
   <div class="col-xs-2">
    <div class="form-group">
    <label for="email">Discount:</label>
    <input type="text" class="form-control" id="discount" name = "discount[]">
  </div>
   </div>
   
     <div class="col-xs-2">
    <div class="form-group">
    <label for="email">Taxsable Value:</label>
    <input type="text" class="form-control" id="taxable_value" name = "taxable_value[]">
  </div>
   </div>
   
    
      </div>
	  
	<div class="row">
   <div class="col-xs-4">
  <div class="form-group text-center head">
    <label for="email">CGST</label>
	 </div>
   <div class="col-xs-6">
    <div class="form-group">
    <label for="email">Rate:</label>
    <input type="text" class="form-control" id="cgst_rate" name = "cgst_rate[]">
  </div>
   </div>
   <div class="col-xs-6">
    <div class="form-group">
    <label for="email">Amt:</label>
    <input type="text" class="form-control" id="cgst_amt" name = "cgst_amt[]">
  </div>
   </div>
   </div>
 
   <div class="col-xs-4">
  <div class="form-group text-center head">
    <label for="email">SGST</label>
	 </div>
   <div class="col-xs-6">
    <div class="form-group">
    <label for="email">Rate:</label>
    <input type="text" class="form-control" id="sgst_rate" name = "sgst_rate[]">
  </div>
   </div>
   <div class="col-xs-6">
    <div class="form-group">
    <label for="email">Amt:</label>
    <input type="text" class="form-control" id="sgst_amt" name = "sgst_amt[]">
  </div>
   </div>
   </div>

   <div class="col-xs-4">
  <div class="form-group text-center head">
    <label for="email">IGST</label>
	 </div>
   <div class="col-xs-6">
    <div class="form-group">
    <label for="email">Rate:</label>
    <input type="text" class="form-control" id="igst_rate" name = "igst_rate[]">
  </div>
   </div>
   <div class="col-xs-6">
    <div class="form-group">
    <label for="email">Amt:</label>
    <input type="text" class="form-control" id="igst_amt" name = "igst_amt[]">
  </div>
   </div>
   </div>
   </div>
     </div>
   
     
   
   </div>
    </div>
 <hr /> 
 
 <div class="row">
        <h4>Freight</h4>
        <div class="col-xs-4">
            <div class="form-group">
                <label for="email">Total:</label>
                <input type="text" class="form-control" id="freight_total" name = "freight_total">
            </div>
        </div>
        <div class="col-xs-4">
            <div class="form-group">
                <label for="email">Discount:</label>
                <input type="text" class="form-control" id="freight_discount" name = "freight_discount">
            </div>
        </div>
        <div class="col-xs-4">
            <div class="form-group">
                <label for="email">Taxable Value:</label>
                <input type="text" class="form-control" id="freight_taxable" name = "freight_taxable">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">CGST Rate:</label>
                <input type="text" class="form-control" id="freight_cgstRate" name = "freight_cgstRate">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">CGST Amount:</label>
                <input type="text" class="form-control" id="freight_cgstAmt" name = "freight_cgstAmt">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">SGST Rate:</label>
                <input type="text" class="form-control" id="freight_sgstRate" name = "freight_sgstRate">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">SGST Amount:</label>
                <input type="text" class="form-control" id="freight_sgstAmt" name = "freight_sgstAmt">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">IGST Rate:</label>
                <input type="text" class="form-control" id="freight_igstRate" name = "freight_igstRate">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">IGST Amount:</label>
                <input type="text" class="form-control" id="freight_igstAmt" name = "freight_igstAmt">
            </div>
        </div>
 
 </div>
 <hr />
 
 
 <div class="row">
        <h4>Insaurance</h4>
        <div class="col-xs-4">
            <div class="form-group">
                <label for="email">Total:</label>
                <input type="text" class="form-control" id="insaurancet_total" name = "insaurance_total">
            </div>
        </div>
        <div class="col-xs-4">
            <div class="form-group">
                <label for="email">Discount:</label>
                <input type="text" class="form-control" id="insaurance_discount" name = "insaurance_discount">
            </div>
        </div>
        <div class="col-xs-4">
            <div class="form-group">
                <label for="email">Taxable Value:</label>
                <input type="text" class="form-control" id="insaurance_taxable" name = "insaurance_taxable">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">CGST Rate:</label>
                <input type="text" class="form-control" id="insaurance_cgstRate" name = "insaurance_cgstRate">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">CGST Amount:</label>
                <input type="text" class="form-control" id="insaurance_cgstAmt" name = "insaurance_cgstAmt">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">SGST Rate:</label>
                <input type="text" class="form-control" id="insaurance_sgstRate" name = "insaurance_sgstRate">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">SGST Amount:</label>
                <input type="text" class="form-control" id="insaurance_sgstAmt" name = "insaurance_sgstAmt">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">IGST Rate:</label>
                <input type="text" class="form-control" id="insaurance_igstRate" name = "insaurance_igstRate">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">IGST Amount:</label>
                <input type="text" class="form-control" id="insaurance_igstAmt" name = "insaurance_igstAmt">
            </div>
        </div>
 
 </div>
 <hr />
 
 
 <div class="row">
        <h4>Packing and Forwarding Charges</h4>
        <div class="col-xs-4">
            <div class="form-group">
                <label for="email">Total:</label>
                <input type="text" class="form-control" id="pack_total" name = "pack_total">
            </div>
        </div>
        <div class="col-xs-4">
            <div class="form-group">
                <label for="email">Discount:</label>
                <input type="text" class="form-control" id="pack_discount" name = "pack_discount">
            </div>
        </div>
        <div class="col-xs-4">
            <div class="form-group">
                <label for="email">Taxable Value:</label>
                <input type="text" class="form-control" id="pack_taxable" name = "pack_taxable">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">CGST Rate:</label>
                <input type="text" class="form-control" id="pack_cgstRate" name = "pack_cgstRate">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">CGST Amount:</label>
                <input type="text" class="form-control" id="pack_cgstAmt" name = "pack_cgstAmt">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">SGST Rate:</label>
                <input type="text" class="form-control" id="pack_sgstRate" name = "pack_sgstRate">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">SGST Amount:</label>
                <input type="text" class="form-control" id="pack_sgstAmt" name = "pack_sgstAmt">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">IGST Rate:</label>
                <input type="text" class="form-control" id="pack_igstRate" name = "pack_igstRate">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">IGST Amount:</label>
                <input type="text" class="form-control" id="pack_igstAmt" name = "pack_igstAmt">
            </div>
        </div>
 
 </div>
 <hr />
 <div class="row">
        <h4>Total</h4>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">Total:</label>
                <input type="text" class="form-control" id="total_total" name = "total_total">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">Total Discount:</label>
                <input type="text" class="form-control" id="total_discount" name = "total_discount">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">Total Taxable Value:</label>
                <input type="text" class="form-control" id="total_taxable_value" name = "total_taxable_value">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">Total CGST:</label>
                <input type="text" class="form-control" id="total_cgst" name = "total_cgst">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">Total SGST:</label>
                <input type="text" class="form-control" id="total_sgst" name = "total_sgst">
            </div>
        </div>
        
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">Total IGST:</label>
                <input type="text" class="form-control" id="total_igst" name = "total_igst">
            </div>
        </div>
        
 </div>
 <hr />
     
      <div class="row">
  <div class="col-xs-4">
    <div class="form-group">
    <label for="email">Total Invoice Value(in figure)  :</label>
    <input type="text" class="form-control" id="total_in_figure" name = "total_in_figure">
  </div>
  </div>
   <div class="col-xs-4">
  <div class="form-group">
    <label for="email">Total Invoice Value(in Words):</label>
	<input type="text" class="form-control" id="total_in_words" name = "total_in_words">

   
   </div>
     </div>
	   <div class="col-xs-4">
  <div class="form-group">
    <label for="email">Electronic Reference No.:</label>
	<input type="text" class="form-control" id="electronic_ref_no" name = "electronic_ref_no">

   
   </div>
     </div>

   </div>
 <hr />
  <div class="row">
  <div class="col-xs-6">
    <div class="form-group">
    <label for="email">Amount of Tax subject to Reverse Charge:</label>
    Yes<input type="radio" class="form-control1" id="yes" name = "rev_tax_amt" value="Yes">
	No<input type="radio" class="form-control1" id="no" name = "rev_tax_amt" value="No" checked>
  </div>
  </div>
      <div class="col-xs-2">
            <div class="form-group">
                <label for="email">IGST Tax Reverse:</label>
                <input type="text" class="form-control" id="tax_reverse_cgst" name = "tax_reverse_cgst">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">IGST Tax Reverse:</label>
                <input type="text" class="form-control" id="tax_reverse_sgst" name = "tax_reverse_sgst">
            </div>
        </div>
        <div class="col-xs-2">
            <div class="form-group">
                <label for="email">IGST Tax Reverse:</label>
                <input type="text" class="form-control" id="tax_reverse_igst" name = "tax_reverse_igst">
            </div>
        </div>
    </div>
	  
  <input type="submit" class="btn btn-warning left-10" id="save" name="submit"/>
</form>
                                
                          </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
		<?php  ?>
      </div><!-- /.content-wrapper -->
      
 <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->
	
	<!-- Customer Popup Info-->

	<!-- Customer Popup Info-->
	
    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!-- DataTables -->
    <script src="dist/js/jquery.dataTables.js"></script>
    <script src="dist/js/dataTables.bootstrap.min.js"></script>
    <script>
$(document).ready(function(){
    $('#add').click(function(){
        $(".main").append('<div class="row" style="background-color:#F6F6F6;"> <hr/>  <h4 class="text-center yellow1"> Add Product Detail</h4>   <div class="row"><div class="col-xs-4"><div class="form-group"><label for="email">Sr No:</label><input type="text" class="form-control" id="sr_no" name = "sr_no[]"></div></div><div class="col-xs-4"><div class="form-group"><label for="email">Description of Goods:</label><textarea class="form-control" id="Description" name = "Description[]"></textarea></div></div><div class="col-xs-4"><div class="form-group"><label for="email">HSN Code:</label><input type="text" class="form-control" id="hsn_code" name = "hsn_code[]"></div></div></div><div class="row"><div class="col-xs-2"><div class="form-group"><label for="email">Qty:</label><input type="text" class="form-control" id="qty" name = "qty[]"></div></div><div class="col-xs-2"><div class="form-group"><label for="email">Unit:</label><input type="text" class="form-control" id="rate" name = "unit[]"></div></div><div class="col-xs-2"><div class="form-group"><label for="email">Rate per Item:</label><input type="text" class="form-control" id="rate" name = "rate[]"></div></div><div class="col-xs-2"><div class="form-group"><label for="email">Total:</label><input type="text" class="form-control" id="total" name = "total[]"></div></div><div class="col-xs-2"><div class="form-group"><label for="email">Discount:</label><input type="text" class="form-control" id="discount" name = "discount[]"></div></div><div class="col-xs-2"><div class="form-group"><label for="email">Taxsable Value:</label><input type="text" class="form-control" id="taxable_value" name = "taxable_value[]"></div></div></div><div class="row"><div class="col-xs-4"><div class="form-group text-center head"><label for="email">CGST</label></div><div class="col-xs-6"><div class="form-group"><label for="email">Rate:</label><input type="text" class="form-control" id="cgst_rate" name = "cgst_rate[]"></div></div><div class="col-xs-6"><div class="form-group"><label for="email">Amt:</label><input type="text" class="form-control" id="cgst_amt" name = "cgst_amt[]"></div></div></div><div class="col-xs-4"><div class="form-group text-center head"><label for="email">SGST</label></div><div class="col-xs-6"><div class="form-group"><label for="email">Rate:</label><input type="text" class="form-control" id="sgst_rate" name = "sgst_rate[]"></div></div><div class="col-xs-6"><div class="form-group"><label for="email">Amt:</label><input type="text" class="form-control" id="sgst_amt" name = "sgst_amt[]"></div></div></div><div class="col-xs-4"><div class="form-group text-center head"><label for="email">IGST</label></div><div class="col-xs-6"><div class="form-group"><label for="email">Rate:</label><input type="text" class="form-control" id="igst_rate" name = "igst_rate[]"></div></div><div class="col-xs-6"><div class="form-group"><label for="email">Amt:</label><input type="text" class="form-control" id="igst_amt" name = "igst_amt[]"></div></div></div></div><button type="button" class="btn btn-warning pull-right delete">Delete</button></div>');
    });
    $(document).on('click', '.delete', function () {
       $(this).closest(".row").remove(); 
    });
    document.getElementById('invoice_date').valueAsDate = new Date();
});
$("#message").fadeIn('slow').delay(5000).fadeOut('slow');
    </script> 
    
    <!-- daterangepicker -->
    <script src="dist/js/moment.min.js"></script>
    <!-- bootstrap time picker -->
    <!-- iCheck 1.0.1 -->
    <script src="plugins/iCheck/icheck.min.js"></script>
    <!-- datepicker -->
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes)
    <script src="dist/js/pages/dashboard.js"></script> -->
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    
  </body>
</html>