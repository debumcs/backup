<?php
	//Start session
	require_once('adminconfig_new.php');
	session_start(); 
	$proAction = 'LOGOUT';
	$sql_insert = "CALL spslogin('$proAction', '".$_SESSION['ADMIN_NAME']."', '$logintime', '".$_SESSION['SES_ID']."', '$ipaddress')";
	$result_insert = $coni->query($sql_insert);		
	$fields = $result_insert->fetch_array(MYSQLI_ASSOC);
	
	//Unset the variables stored in session
	
	unset($_SESSION['ADMIN_NAME']);
	unset($_SESSION['ROLE']);
	unset($_SESSION['NAME']);
	unset($_SESSION['EMAILID']);
	unset($_SESSION['SES_ID']);
	session_destroy();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>BIZCRM </title>

    <!-- Bootstrap core CSS -->

    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styling plus plugins -->
    <link href="dist/css/form.css" rel="stylesheet">
    
    <style>
	body {
		color: #73879C;
		background:url(dist/img/bg8.jpg) no-repeat center center fixed;
		-webkit-background-size: cover;
		-moz-background-size: cover;
		-o-background-size: cover;
		background-size: cover;
    }
	</style>
<script>
	function timer(){
		document.getElementById('tm').value = document.getElementById('tm').value-1;
		document.getElementById('tm1').innerHTML = document.getElementById('tm').value-1;
		if(document.getElementById('tm').value == 0)
		{
		self.close();
		window.location.href='index.php';
		}
	}
	setInterval("timer()",1000);
</script>
</head>

<body>

	<nav class="navbar navbar-default lognav" role="navigation">
    	<a class="lognav-brand" href="#"><img src="dist/img/logo3.jpg" /></a>
    <!-- Collect the nav links, forms, and other content for toggling -->
    </nav>
    
    <div class="wrapper">
			
		<div class="content">
			<div id="form_wrapper" class="form_wrapper">
                <h4 align="center">You have been logged out.</h4>
				<p><br/></p>
				<p align="center"><a href="index.php" style='text-decoration:none;'><font size='4'>Click Here to Login	</font></a></p>
				<p align="center" style="color:red;">Window will close in <span id="tm1">5</span><input type="hidden" name="tm" id="tm" value="5" /> seconds...</p>
				<br/>
			</div>
			<div class="clear"></div>
		</div>
		
	</div>
</body>
</html>