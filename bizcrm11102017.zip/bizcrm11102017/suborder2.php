<?php 
require_once('class/class.agencymaster.php');
require_once('class/class.orderdetails.php');
$objord = new Orderdetails();
$objagency 		= new Agencymaster();
$allagent 		= $objagency->getAll();

$action = $_GET["action"];
$orderno = $_GET["orderno"];

if(isset($_GET["orderno"])){
	$orderno = $_GET["orderno"];
}else{
	$orderno ='';
	$allorderno = $objord->getAll();
}

$msgD = '';

if($action=="edit")
{
	$data = $objord->getById($orderno);
	$btnvalue = "UPDATE";
}
else
{
	$btnvalue = "SAVE";
}

if(isset($_POST['submit']))
{
	$objord->savesuborder();
	exit();
}

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $PRO_TITLE;?> | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="bootstrap/css/datepicker.css">
     <!-- Font Awesome -->
    <link rel="stylesheet" href="dist/css/font-awesome.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="dist/css/ionicons.min.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/minimal/orange.css">
    <link rel="stylesheet" type="text/css" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css"></link>
	
   
    <link rel="stylesheet/less" type="text/css" href="side.less" />
	
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="dist/js/html5shiv.min.js"></script>
        <script src="dist/js/respond.min.js"></script>
    <![endif]-->
	<script type="text/javascript" language="javascript">
		function calculateSaleAmount() {		
			var original_amount 	= parseFloat($("#original_amount").val());
			var discount 			= parseFloat($("#discount").val());
			
			if((original_amount != '' && discount != '') && (original_amount < discount )){
				alert('Discounted amount should be less than original amount!');
				document.getElementById('discount').value = '';
				document.getElementById('discount').focus();
				return false;
			}else{
				document.getElementById('sale_amount').value = original_amount - discount;
			}
		}	
		
		function isDecimalNumber(evt, element) {
			
			evt = (evt) ? evt : window.event;
			var charCode = (evt.which) ? evt.which : evt.keyCode;
			if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode!=46)
			{
				status = "This field accepts numbers only.";
				return false;
			}else {
				var len = $(element).val().length;
				var index = $(element).val().indexOf('.');
				if (index > 0 && charCode == 46) {
					return false;
				}
				if (index > 0) {
					var CharAfterdot = (len + 1) - index;
					if (CharAfterdot > 3) {
						return false;
					}
				}

			}
			return true;
		}
		
		function checkIt(evt)
		{
			evt = (evt) ? evt : window.event;
			var charCode = (evt.which) ? evt.which : evt.keyCode;
			if (charCode > 31 && (charCode < 48 || charCode > 57))
			{
				status = "This field accepts numbers only.";
				return false;
			}
			status = "";
			return true ;
		}		
		
		function validatesuborder(){
			
			if(document.getElementById('orderno').value =='' ){
				alert('Please enter order number!');
				document.getElementById('orderno').focus();
				return false;
			}else if(document.getElementById('sub_orderno').value =='' ){
				alert('Please enter sub order no!');
				document.getElementById('sub_orderno').focus();
				return false;
			}else if(document.getElementById('order_detail').value =='' ){
				alert('Please enter order detail!');
				document.getElementById('order_detail').focus();
				return false;
			}else if(document.getElementById('original_amount').value =='' ){
				alert('Please enter original amount!');
				document.getElementById('original_amount').focus();
				return false;
			}else if((document.getElementById("dying").checked == true) && (document.getElementById('dychallanno').value =='')){
				alert('Please enter challan number!');
				document.getElementById('dychallanno').focus();
				return false;
			}else if((document.getElementById("dying").checked == true) && (document.getElementById('dydetails').value =='')){
				alert('Please enter details!');
				document.getElementById('dydetails').focus();
				return false;
			}else if((document.getElementById("dying").checked == true) && (document.getElementById('dyerid').value =='')){
				alert('Please select dyer name!');
				document.getElementById('dyerid').focus();
				return false;
			}else if((document.getElementById("dying").checked == true) && (document.getElementById('dyfabricid').value =='')){
				alert('Please select dyer fabric id!');
				document.getElementById('dyfabricid').focus();
				return false;
			}else if((document.getElementById("dying").checked == true) && (document.getElementById('dyquantity').value =='')){
				alert('Please enter quantity in meter!');
				document.getElementById('dyquantity').focus();
				return false;
			}else if((document.getElementById("dying").checked == true) && (document.getElementById('dying_color').value =='')){
				alert('Please enter challan number!');
				document.getElementById('dying_color').focus();
				return false;
			}else if((document.getElementById("dying").checked == true) && (document.getElementById('dyassign_date').value =='')){
				alert('Please enter assign date!');
				document.getElementById('dyassign_date').focus();
				return false;
			}else if((document.getElementById("dying").checked == true) && (document.getElementById('dydue_date').value =='')){
				alert('Please enter due date!');
				document.getElementById('dydue_date').focus();
				return false;
			}else if((document.getElementById("dying").checked == true) && (document.getElementById('dyreceiving_date').value =='')){
				alert('Please enter receiving date!');
				document.getElementById('dyreceiving_date').focus();
				return false;
			}else if((document.getElementById("dying").checked == true) && (document.getElementById('dying_notes').value =='')){
				alert('Please enter notes!');
				document.getElementById('dying_notes').focus();
				return false;
			}else if((document.getElementById("embroidery").checked == true) && (document.getElementById('emchallanno').value =='')){
				alert('Please enter challan number!');
				document.getElementById('dychallanno').focus();
				return false;
			}else if((document.getElementById("embroidery").checked == true) && (document.getElementById('emdetails').value =='')){
				alert('Please enter details!');
				document.getElementById('emdetails').focus();
				return false;
			}else if((document.getElementById("embroidery").checked == true) && (document.getElementById('embroiderid').value =='')){
				alert('Please select embroider id!');
				document.getElementById('embroiderid').focus();
				return false;
			}else if((document.getElementById("embroidery").checked == true) && (document.getElementById('emassign_date').value =='')){
				alert('Please enter assign date!');
				document.getElementById('emassign_date').focus();
				return false;
			}else if((document.getElementById("embroidery").checked == true) && (document.getElementById('emdue_date').value =='')){
				alert('Please enter due date!');
				document.getElementById('emdue_date').focus();
				return false;
			}else if((document.getElementById("embroidery").checked == true) && (document.getElementById('emreceiving_date').value =='')){
				alert('Please enter receiving date!');
				document.getElementById('emreceiving_date').focus();
				return false;
			}else if((document.getElementById("embroidery").checked == true) && (document.getElementById('embroidery_notes').value =='')){
				alert('Please enter notes!');
				document.getElementById('embroidery_notes').focus();
				return false;
			}else if((document.getElementById("cutting").checked == true) && (document.getElementById('cuchallanno').value =='')){
				alert('Please enter challan number!');
				document.getElementById('cuchallanno').focus();
				return false;
			}else if((document.getElementById("cutting").checked == true) && (document.getElementById('cudetails').value =='')){
				alert('Please enter details!');
				document.getElementById('cudetails').focus();
				return false;
			}else if((document.getElementById("cutting").checked == true) && (document.getElementById('cutterid').value =='')){
				alert('Please enter cutter id!');
				document.getElementById('cutterid').focus();
				return false;
			}else if((document.getElementById("cutting").checked == true) && (document.getElementById('cuassign_date').value =='')){
				alert('Please enter assign date!');
				document.getElementById('cuassign_date').focus();
				return false;
			}else if((document.getElementById("cutting").checked == true) && (document.getElementById('cudue_date').value =='')){
				alert('Please enter due date!');
				document.getElementById('cudue_date').focus();
				return false;
			}else if((document.getElementById("cutting").checked == true) && (document.getElementById('cureceiving_date').value =='')){
				alert('Please enter receiving date!');
				document.getElementById('cureceiving_date').focus();
				return false;
			}else if((document.getElementById("cutting").checked == true) && (document.getElementById('cutting_notes').value =='')){
				alert('Please enter notes!');
				document.getElementById('cutting_notes').focus();
				return false;
			}else if((document.getElementById("tailor").checked == true) && (document.getElementById('tachallanno').value =='')){
				alert('Please enter challan number!');
				document.getElementById('tachallanno').focus();
				return false;
			}else if((document.getElementById("tailor").checked == true) && (document.getElementById('tadetails').value =='')){
				alert('Please enter details!');
				document.getElementById('tadetails').focus();
				return false;
			}else if((document.getElementById("tailor").checked == true) && (document.getElementById('tailorid').value =='')){
				alert('Please enter tailor id!');
				document.getElementById('tailorid').focus();
				return false;
			}else if((document.getElementById("tailor").checked == true) && (document.getElementById('taassigndate').value =='')){
				alert('Please enter assign date!');
				document.getElementById('taassigndate').focus();
				return false;
			}else if((document.getElementById("tailor").checked == true) && (document.getElementById('taduedate').value =='')){
				alert('Please enter due date!');
				document.getElementById('taduedate').focus();
				return false;
			}else if((document.getElementById("tailor").checked == true) && (document.getElementById('tareceivingdate').value =='')){
				alert('Please enter receiving date!');
				document.getElementById('tareceivingdate').focus();
				return false;
			}else if((document.getElementById("tailor").checked == true) && (document.getElementById('tailor_notes').value =='')){
				alert('Please enter tailor notes!');
				document.getElementById('tailor_notes').focus();
				return false;
			}else{
				return true;
			}
		}		
	
	</script>
	<style>
	.connecting_preference_checkbox{
		display:block !important; float:left; width:20px;
	}
	.connecting_preference_box{
		display: block;float: left;width: 25%;
	}
	</style>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
     
   <?php if(isset($_SESSION['msgD']) and $_SESSION['msgD'] != ''){echo '<div id="message">'.$_SESSION['msgD'].'</div>';} unset($_SESSION['msgD']);?>
   <div class="wrapper">

		<?php $objord->psheader(); ?>
		<!-- Left side column. contains the logo and sidebar -->
		<?php $objord->pssidebar(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <!--h1>
            Add Customer
          </h1>
             <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li>Control Panel</li>
            <li class="active">Add Customer</li>
          </ol>
        </section><!--CONTENT HEADER-->
        
        <!-- Main content -->
        <section class="content">
            <div class="row">
            	<div class="col-md-12">
              		<div class="box box-warning">
                        <div class='box-header with-border'>
							<div class="col-md-12">
								<h3 class="box-title">New Sub-Order </h3>
							</div>
                        </div><!-- /.box-header -->
                        <div class='box-body'>
                            <form action="" name="userCreate" id="userCreate" method="post" >
							<div class="row">
							<input type="hidden" id="id" name="id" value="<?php echo $data['id']; ?>" />
							
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Order No</label>
											<?php if(isset($orderno) and !empty($orderno)){?>
											<input type="text" id="orderno" name="orderno" class="form-control" value="<?php if($action=="edit"){echo $data['orderno'];}else{echo $cust_id;} ?>" />
											<?php }else{ ?>
											<select id="orderno" class="form-control select2" name="orderno">
											<option value="" selected="selected">Select Order No</option>
											<?php foreach($allorderno as $orderno){ ?>
											<option value="<?php echo $orderno['orderno']; ?>"><?php echo $orderno['orderno']; ?></option>
											<?php } ?>
											</select>
											<?php } ?>
										</div>
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Sub-Order No</label>
										  <input type="text" class="form-control" <?php if($action == "edit"){ echo 'readonly="true"';} ?> id="sub_orderno" name="sub_orderno" placeholder="Enter sub orderno" value="" />
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Order Detail</label>
										  <input type="text" class="form-control" id="order_detail" name="order_detail" placeholder="Enter order detail" value="<?php echo $data['order_detail']; ?>" />
										</div>									  
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Original Amount</label>
										  <input type="text" class="form-control" onKeyPress="return isDecimalNumber(event,this);" id="original_amount" name="original_amount" placeholder="Enter Original Amount" value="<?php echo $data['original_amount']; ?>">
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Discount Amount</label>
											<input type="text" class="form-control" onKeyPress="return isDecimalNumber(event,this);" id="discount_amount" name="discount_amount" placeholder="Enter Discount Amount" value="<?php echo $data['discount_amount']; ?>">
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Sale Amount</label>
											<input type="text" class="form-control" onKeyPress="return isDecimalNumber(event,this);" id="sale_amount" name="sale_amount" placeholder="Enter Sale Amount" value="<?php echo $data['sale_amount']; ?>">
										</div>			  
									</div><!-- /.col -->
									
								</div>
								
								
								<div class="col-lg-12">
									<div class="col-lg-6">
										<div class="form-group">
											<label for="name">Agency : </label>
											<div style="width:100%;">											
												<div class="connecting_preference_box">
													<input class="connecting_preference_checkbox" type="checkbox" id="dying" name="agency[]" value="Dying" />Dying
												</div>
												<div class="connecting_preference_box">
													<input class="connecting_preference_checkbox" type="checkbox" id="embroidery" name="agency[]" value="Embroidery" />Embroidery
												</div>
												<div class="connecting_preference_box">
													<input class="connecting_preference_checkbox" type="checkbox" id="cutting" name="agency[]" value="Cutting" />Cutting
												</div>
												<div class="connecting_preference_box">
													<input class="connecting_preference_checkbox" type="checkbox" id="tailor" name="agency[]" value="Tailor" />Tailor
												</div>
											</div>
										</div>	
									</div><!-- /.col -->
								</div><!-- /.col -->
								
							</div><!-- /.row -->
							
							<div class="row" id="dying_row" style="display:none;">
								<br/>
								<div class="col-lg-12">
									<div class="col-lg-12">
										<h4>Dying : </h4>
									</div>
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Challan No</label>											
											<input type="text" id="dychallanno" name="dychallanno" class="form-control" value="<?php echo $data['dychallanno']; ?>" />
										</div>
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Details</label>
										  <input type="text" class="form-control" id="dydetails" name="dydetails" placeholder="Enter details" value="<?php echo $data['dydetails']; ?>">
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Dyer ID</label>
											<select class="form-control select2" id="dyerid" name="dyerid" style="width:100%;">
											<option value="" selected>Select</option>
											<?php 				
											for($dyi=0; $dyi<count($allagent); $dyi++) {
												if($allagent[$dyi]['type'] == 'Dying'){ 				 
												echo "<option value='".$allagent[$dyi]['id']."'>".$allagent[$dyi]['agencyname']."</option>"; 
												}
											}
											?>
											</select>
										</div>									  
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Fabric ID</label>
										  <input type="text" class="form-control" id="dyfabricid" name="dyfabricid" placeholder="Enter fabric id" value="<?php echo $data['dyfabricid']; ?>">
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Quantity(in Metre)</label>
											<input type="text" class="form-control" onKeyPress="return isDecimalNumber(event,this);" id="dyquantity" name="dyquantity" placeholder="Enter quantity" value="<?php echo $data['dyquantity']; ?>">
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Dying Color</label>
											<input type="text" class="form-control" id="dying_color" name="dying_color" placeholder="Enter dying color" value="<?php echo $data['dying_color']; ?>">
										</div>			  
									</div><!-- /.col -->									
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Assign Date</label>
										  <input type="text" class="form-control datepicker" id="dyassign_date" name="dyassign_date" placeholder="Enter assign date" value="<?php echo $data['dyassign_date']; ?>">
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Due Date</label>
											<input type="text" class="form-control datepicker" id="dydue_date" name="dydue_date" placeholder="Enter due date" value="<?php echo $data['dydue_date']; ?>">
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Receiving Date</label>
											<input type="text" class="form-control datepicker" id="dyreceiving_date" name="dyreceiving_date" placeholder="Enter receiving date" value="<?php echo $data['dyreceiving_date']; ?>">
										</div>			  
									</div><!-- /.col -->									
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-8">
										<div class="form-group">
										  <label for="name">Notes</label>
										  <input type="text" class="form-control" id="dying_notes" name="dying_notes" placeholder="Enter notes" value="<?php echo $data['dying_notes']; ?>">
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Status</label>
											<select class="form-control select2" id="dystatus" name="dystatus" style="width:100%;">
											<option value="" selected>Select Status</option>
											<option value="1">Incomplete</option>
											<option value="2">Pending</option>
											<option value="3">Processed</option>
											<option value="4">Partially Shipped</option>
											<option value="5">Shipping</option>
											<option value="6">Shipped</option>
											<option value="7">Partially Returned</option>
											<option value="8">Returned</option>
											<option value="9">Cancelled</option>
											</select>
										</div>			  
									</div><!-- /.col -->									
								</div>
								
							</div><!-- /.row -->
							
							<div class="row" id="embroidery_row" style="display:none;">
								<br/>
								<div class="col-lg-12">
									<div class="col-lg-12">
										<h4>Embroidery : </h4>
									</div>
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Challan No</label>											
											<input type="text" id="emchallanno" name="emchallanno" class="form-control" value="<?php echo $data['emchallanno']; ?>" />
										</div>
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Details</label>
										  <input type="text" class="form-control" id="emdetails" name="emdetails" placeholder="Enter details" value="<?php echo $data['emdetails']; ?>">
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Embroider ID</label>
										  <select class="form-control select2" id="embroiderid" name="embroiderid" style="width:100%;">
											<option value="" selected>Select</option>
											<?php 				
											for($emi=0; $emi<count($allagent); $emi++) {
												if($allagent[$emi]['type'] == 'Embroidery'){ 				 
												echo "<option value='".$allagent[$emi]['id']."'>".$allagent[$emi]['agencyname']."</option>"; 
												}
											}
											?>
											</select>
										</div>									  
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Assign Date</label>
										  <input type="text" class="form-control datepicker" id="emassign_date" name="emassign_date" placeholder="Enter assign date" value="<?php echo $data['emassign_date']; ?>">
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Due Date</label>
											<input type="text" class="form-control datepicker" id="emdue_date" name="emdue_date" placeholder="Enter due date" value="<?php echo $data['emdue_date']; ?>">
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Receiving Date</label>
											<input type="text" class="form-control datepicker" id="emreceiving_date" name="emreceiving_date" placeholder="Enter receiving date" value="<?php echo $data['emreceiving_date']; ?>">
										</div>			  
									</div><!-- /.col -->									
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-8">
										<div class="form-group">
										  <label for="name">Notes</label>
										  <input type="text" class="form-control" id="embroidery_notes" name="embroidery_notes" placeholder="Enter assign date" value="<?php echo $data['embroidery_notes']; ?>">
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Status</label>
											<select class="form-control select2" id="emstatus" name="emstatus" style="width:100%;">
											<option value="" selected>Select Status</option>
											<option value="1">Incomplete</option>
											<option value="2">Pending</option>
											<option value="3">Processed</option>
											<option value="4">Partially Shipped</option>
											<option value="5">Shipping</option>
											<option value="6">Shipped</option>
											<option value="7">Partially Returned</option>
											<option value="8">Returned</option>
											<option value="9">Cancelled</option>
											</select>
										</div>			  
									</div><!-- /.col -->									
								</div>
								
							</div><!-- /.row -->
							
							<div class="row" id="cutting_row" style="display:none;">
								<br/>
								<div class="col-lg-12">
									<div class="col-lg-12">
										<h4>Cutting : </h4>
									</div>
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Challan No</label>											
											<input type="text" id="cuchallanno" name="cuchallanno" class="form-control" value="<?php echo $data['cuchallanno']; ?>" />
										</div>
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Details</label>
										  <input type="text" class="form-control" id="cudetails" name="cudetails" placeholder="Enter details" value="<?php echo $data['cudetails']; ?>">
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Cutter ID</label>
										  <select class="form-control select2" id="cutterid" name="cutterid" style="width:100%;">
											<option value="" selected>Select</option>
											<?php 				
											for($cui=0; $cui<count($allagent); $cui++) {
												if($allagent[$cui]['type'] == 'Cutting'){ 				 
												echo "<option value='".$allagent[$cui]['id']."'>".$allagent[$cui]['agencyname']."</option>"; 
												}
											}
											?>
											</select>
										</div>									  
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Assign Date</label>
										  <input type="text" class="form-control datepicker" id="cuassign_date" name="cuassign_date" placeholder="Enter assign date" value="<?php echo $data['cuassign_date']; ?>">
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Due Date</label>
											<input type="text" class="form-control datepicker" id="cudue_date" name="cudue_date" placeholder="Enter due date" value="<?php echo $data['cudue_date']; ?>">
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Receving Date</label>
											<input type="text" class="form-control datepicker" id="cureceiving_date" name="cureceiving_date" placeholder="Enter receiving date" value="<?php echo $data['cureceiving_date']; ?>">
										</div>			  
									</div><!-- /.col -->									
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-8">
										<div class="form-group">
										  <label for="name">Notes</label>
										  <input type="text" class="form-control" id="cutting_notes" name="cutting_notes" placeholder="Enter assign date" value="<?php echo $data['cutting_notes']; ?>">
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Status</label>
											<select class="form-control select2" id="custatus" name="custatus" style="width:100%;">
											<option value="" selected>Select Status</option>
											<option value="1">Incomplete</option>
											<option value="2">Pending</option>
											<option value="3">Processed</option>
											<option value="4">Partially Shipped</option>
											<option value="5">Shipping</option>
											<option value="6">Shipped</option>
											<option value="7">Partially Returned</option>
											<option value="8">Returned</option>
											<option value="9">Cancelled</option>
											</select>
										</div>			  
									</div><!-- /.col -->									
								</div>
								
							</div><!-- /.row -->
							
							<div class="row" id="tailor_row" style="display:none;">
								<br/>
								<div class="col-lg-12">
									<div class="col-lg-12">
										<h4>Tailor : </h4>
									</div>
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Challan No</label>											
											<input type="text" id="tachallanno" name="tachallanno" class="form-control" value="<?php echo $data['tachallanno']; ?>" />
										</div>
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Details</label>
										  <input type="text" class="form-control" id="tadetails" name="tadetails" placeholder="Enter details" value="<?php echo $data['tadetails']; ?>">
										</div>									  
									</div><!-- /.col -->
									
									<div class="col-lg-4">										
										<div class="form-group">
										  <label for="name">Tailor ID</label>
										  <select class="form-control select2" id="tailorid" name="tailorid" style="width:100%;">
											<option value="" selected>Select</option>
											<?php 				
											for($tai=0; $tai<count($allagent); $tai++) {
												if($allagent[$tai]['type'] == 'Tailor'){ 				 
												echo "<option value='".$allagent[$tai]['id']."' >".$allagent[$tai]['agencyname']."</option>"; 
												}
											}
											?>
											</select>
										</div>									  
									</div><!-- /.col -->
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-4">
										<div class="form-group">
										  <label for="name">Assign Date</label>
										  <input type="text" class="form-control datepicker" id="taassigndate" name="taassigndate" placeholder="Enter assign date" value="<?php echo $data['taassigndate']; ?>">
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Due Date</label>
											<input type="text" class="form-control datepicker" id="taduedate" name="taduedate" placeholder="Enter due date" value="<?php echo $data['taduedate']; ?>">
										</div>			  
									</div><!-- /.col -->
									
									<div class="col-lg-4">
										<div class="form-group">
											<label for="name">Receiving Date</label>
											<input type="text" class="form-control datepicker" id="tareceivingdate" name="tareceivingdate" placeholder="Enter receiving date" value="<?php echo $data['tareceivingdate']; ?>">
										</div>			  
									</div><!-- /.col -->									
								</div>
								
								<div class="col-lg-12">
									<div class="col-lg-8">
										<div class="form-group">
										  <label for="name">Notes</label>
										  <input type="text" class="form-control" id="tailor_notes" name="tailor_notes" placeholder="Enter notes" value="<?php echo $data['tailor_notes']; ?>">
										</div>	
									</div><!-- /.col -->

									<div class="col-lg-4">										
										<div class="form-group">
											<label for="name">Status</label>
											<select class="form-control select2" id="tastatus" name="tastatus" style="width:100%;">
											<option value="" selected>Select Status</option>
											<option value="1">Incomplete</option>
											<option value="2">Pending</option>
											<option value="3">Processed</option>
											<option value="4">Partially Shipped</option>
											<option value="5">Shipping</option>
											<option value="6">Shipped</option>
											<option value="7">Partially Returned</option>
											<option value="8">Returned</option>
											<option value="9">Cancelled</option>
											</select>
										</div>			  
									</div><!-- /.col -->									
								</div>
								
							</div><!-- /.row -->
                           
							<div class="row">
                              <div class="col-lg-12">
                                   <div class="form-group center">
                                      <input type="submit" name="submit" id="submit" onclick="return validatesuborder();" class="btn btn-warning left-10" value="<?php echo $btnvalue; ?>" />
                                   </div>
                               </div><!-- /.col -->
             				 </div><!-- /.row -->
                           </form>
                        </div><!-- /.box-body--> 
                     </div><!-- /.box--> 
                        
                </div><!-- /.col -->
              </div><!-- /.row -->
        </section><!--CONTENT-->
      </div><!-- /.content-wrapper -->
      
      
      <?php include('footer.php'); ?>

      <!-- Control Sidebar -->
      
    </div><!-- ./wrapper -->
	
    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="dist/js/jquery-ui.min.js"></script>
	
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<script src="bootstrap/js/bootstrap-datepicker.js"></script>
	<script type="text/javascript">
	// When the document is ready
	$(document).ready(function (){
		
		$('#dying').change(function(){
			if(this.checked)
				$('#dying_row').css('display','block');
			else
				$('#dying_row').css('display','none');
		});
		
		$('#embroidery').change(function(){
			if(this.checked)
				$('#embroidery_row').css('display','block');
			else
				$('#embroidery_row').css('display','none');
		});
		
		$('#cutting').change(function(){
			if(this.checked)
				$('#cutting_row').css('display','block');
			else
				$('#cutting_row').css('display','none');
		});
		
		$('#tailor').change(function(){
			if(this.checked)
				$('#tailor_row').css('display','block');
			else
				$('#tailor_row').css('display','none');
		});
	
		
		$('.datepicker').datepicker({
			format: "yyyy-mm-dd",
			autoclose: true
		});
	});		
	</script>
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/select2/select2.js"></script>
	
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
	<script>
	//$('#order_detail').wysihtml5();
	//$('#delivery_remarks').wysihtml5();
	</script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
   
    <!-- AdminLTE for demo purposes -->
	
  </body>
</html>