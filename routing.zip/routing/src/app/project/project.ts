export class Project {
    id: number;
    name: string;
    createdBy: string;
    created: Date
}