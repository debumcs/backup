<?php 
error_reporting(E_ERROR);
ini_set('display_errors', 1);
include_once("database.class.php");
include_once("class.config.php");

class Menu extends config{
	
	function __construct() {
		//parent::__construct();
		//$database = new Database();
		if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
		{
			$this->redirect('index.php');
			exit();
		}
	}
	
	function __destruct() {
		//parent::__construct();
		//$database->close;
	}
	
	public function getAll() {
		$database = new Database();
		$proAction = 'MENUGETALL';			
		
		$sql = "CALL spsMenu('$proAction', '$menuid', '$header', '$description', '$parent_menuid', '$pagename', '$menuorder', '$mstatus', '$createddate', '$createdby', '$modifieddate', '$modifiedby')";
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}	

	public function getById($id) {
		$database = new Database();
	
		// Initialize result array
		$result = array();
		$proAction = 'MENUGET';		
		$menuid = $this->sanitize($id);
		$sql = "CALL spsMenu('$proAction', '$menuid', '$header', '$description', '$parent_menuid', '$pagename', '$menuorder', '$mstatus', '$createddate', '$createdby', '$modifieddate', '$modifiedby')";
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}	

	public function save() {
		$database = new Database();
	
		$submit = $this->sanitize($_POST["submit"]);
		$ipadd = $this->sanitize($_SERVER['REMOTE_ADDR']);
		$admin_name = $this->sanitize($_SESSION['ADMIN_NAME']);
        $menuid = $this->sanitize($_POST["menuid"])? $this->sanitize($_POST["menuid"]) : '';
		$header = $this->sanitize($_POST["header"]);
		$status = $this->sanitize($_POST["status"]);
		$description = $this->sanitize($_POST["description"]);
		$menuheader = $this->sanitize($_POST["menuheader"])? $this->sanitize($_POST["menuheader"]) : '';
		$parent_menuid = $this->sanitize($_POST["parent_menuid"]);
		$pagename = $this->sanitize($_POST["pagename"]);
		$menuorder = $this->sanitize($_POST["menuorder"]);

		$createddate = date('Y-m-d H:i:s');
		$createdby = $admin_name? $admin_name: '';
		$modifieddate = date('Y-m-d H:i:s');
		$modifiedby = $admin_name? $admin_name: '';
		
		if($submit == 'SAVE'){
			$proAction = 'MENUINSERT';			
		}
		if($submit == 'UPDATE'){
			$proAction = 'MENUUPDATE';	
		}
			
		$sql = "CALL spsMenu('$proAction', '$menuid', '$header', '$description', '$parent_menuid', '$pagename', '$menuorder', '$mstatus', '$createddate', '$createdby', '$modifieddate', '$modifiedby')";
		//echo $sql; die();
		$result = $database->prepare($sql);
		$result->execute();
		$result->bind_result($errorFlag, $errorDescription);
		$result->fetch();
		$_SESSION['msgD'] = $errorDescription;
		$result->close();
		$database->close();
		$this->redirect('manageMenuMaster.php');				
	}	
}

?>
