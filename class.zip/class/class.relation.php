<?php 
error_reporting(E_ERROR);
ini_set('display_errors', 1);
include_once("database.class.php");
include_once("class.config.php");

class Relation extends config{
	
	//public $database;
	
	function __construct() {
		if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
		{
			$this->redirect('index.php');
			exit();
		}
	}
	
	function __destruct() {
		//parent::__construct();
		//$database->close;
	}
	
	public function getAll() {
		$database = new Database();	
		
		$sql = "SELECT * FROM relation ORDER BY modifiedon DESC";
		
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getById($id){
		$database = new Database();
	
		$result = array();
		
		$psuid = $this->sanitize($id);
		$sql = "SELECT * FROM relation WHERE id = '".$psuid."'";
		
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}	
	
	public function save(){
		$database = new Database();
		
		$admin_name = $_SESSION['ADMIN_NAME'];
		$submit = $this->sanitize($_POST["submit"]);
		
		$id 			= $this->sanitize($_POST["id"]);
		$rname 			= $this->sanitize($_POST["rname"]);
        $description 	= $this->sanitize($_POST["description"]);
		$createdon 		= date('Y-m-d H:i:s');
		$createdby 		= $admin_name? $admin_name: '';
		$modifiedon 	= date('Y-m-d H:i:s');
		$modifiedby 	= $admin_name? $admin_name: '';
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		if($submit == 'SAVE'){
			$sql = "INSERT INTO relation(rname, description, createdby, createdon, modifiedby, modifiedon, ipaddress) 
		VALUES ('".$rname."', '".$description."', '".$createdby."', '".$createdon."', '".$modifiedby."', '".$modifiedon."', '".$ipaddress."')";
		}
		if($submit == 'UPDATE'){
			$sql_log = "INSERT INTO relation_log SELECT id, rname, description, createdby, createdon,'".$modifiedby."','".$modifiedon."','".$ipaddress."' FROM  relation WHERE id = '".$id."'";
			$result_log = $database->query($sql_log);			
			
			$sql = "UPDATE relation SET rname='".$rname."', description='".$description."', modifiedby='".$modifiedby."', modifiedon='".$modifiedon."', ipaddress='".$ipaddress."' WHERE id = '".$id."'";	
		}
		
		$result = $database->prepare($sql);
		if($result->execute()){
			if($submit == 'SAVE'){
				$_SESSION['msgD'] = 'Family Data Inserted Successfully.';
			}else{
				$_SESSION['msgD'] = 'Family Data Updated Successfully.';
			}			
		}else{
			$_SESSION['msgD'] = 'Error while executing query.';
		}
		
		$result->close();
		$database->close();
		$this->redirect('managerelation.php');
	}	
}

?>
