<?php 
error_reporting(E_ERROR);
ini_set('display_errors', 1);
include_once("database.class.php");
include_once("class.config.php");

class Agencymaster extends config{
	
	//public $database;
	
	function __construct() {
		if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
		{
			$this->redirect('index.php');
			exit();
		}
	}
	
	function __destruct() {
		//parent::__construct();
		//$database->close;
	}

	public function checkAgencyEmailID($emailid){
		$database = new Database();
		
		$emailid = $this->sanitize($emailid);
		
		$sql = "SELECT COUNT(*) AS total FROM (SELECT email FROM adminuser UNION ALL SELECT email FROM agencymaster) a WHERE email LIKE '%".$emailid."%' ";
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		
		return $data;
	}
	
	function getInitials($string = null) {
		$string = preg_replace('/[^A-Za-z0-9\s]/', '', $string);
		$string = strtoupper($string);
		$username = implode('', array_map(function($v) { return $v[0]; }, explode(' ', $string)));
		if(strlen($username)<8){
			$random_number='';
			$count=0;
			$size = 8 - strlen($username);
			while ($count < $size ) 
			{
				$random_digit = mt_rand(0, 9);
				$random_number .= $random_digit;
				$count++;
			}
			$username = $username.$random_number;
		}
		return $username;
	}
	
	public function getAll() {
		
		$sql = "SELECT * FROM agencymaster";
		$result = $this->fetchAssoc($sql);
		return $result;
	}
	
	public function getAgencyByStatus($statusid){
		$database = new Database();
		$alldata = array();
		$id = $this->sanitize($id);
		$sql = "SELECT a.id, a.agencyname FROM agencymaster a INNER JOIN status_master b ON a.type = b.type WHERE b.id='".$statusid."'";
		$result = $database->query($sql);
		while($row = $result->fetch_assoc()){
			$alldata[] = $row;
		}
		$database->close();
		return $alldata;
	}
	
	/*public function allmappedstatus($id){
		$database = new Database();
		$alldata = array();
		$id = $this->sanitize($id);
		$sql = "select agencyid from agencystatusmapping where statusid='".$id."'";
		$result = $database->query($sql);
		while($row = $result->fetch_assoc()){
			$alldata[] = $row['agencyid'];
		}
		$database->close();
		return $alldata;
	}
	
	public function deleteMappingAgencyStatus($id){
		$database = new Database();
		
		$id = $this->sanitize($id);
		$sql = "DELETE FROM agencystatusmapping where statusid='".$id."'";
		$result = $database->query($sql);
		$database->close();
		return $result;
	}
	
	public function mappingAgencyStatus(){
		$database = new Database();
		
		$statusid 		= $this->sanitize($_POST["statusid"]);
		$agency_type 	= $this->sanitize($_POST["agency_type"]);
		$type 			= $this->sanitize($_POST["type"]);
		$mappinglist 	= $this->sanitize($_POST["mappinglist"]);
		
		$this->deleteMappingAgencyStatus($statusid);
		
		foreach($mappinglist as $list){
			$sql = "INSERT INTO agencystatusmapping(statusid, agencyid) VALUES ('".$statusid."','".$list."')";
			$result = $database->prepare($sql);
			$result->execute();
			$result->close();
		}
		$database->close();
	}*/
	
	public function getAllAgencyByType($agencyVal,$typeVal){
		$agencyVal 	= trim($this->sanitize($agencyVal));
		$typeVal 	= trim($this->sanitize($typeVal));
		
		if(($agencyVal != '') && ($typeVal != '')){
			$sql = "SELECT * FROM agencymaster where agency_type= '".$agencyVal."' and type = '".$typeVal."' ";
		}else if(($agencyVal != '') && ($typeVal == '')){
			$sql = "SELECT * FROM agencymaster where agency_type='".$agencyVal."'";
		}else if(($agencyVal == '') && ($typeVal != '')){
			$sql = "SELECT * FROM agencymaster where type = '".$typeVal."' ";
		}else{
			$sql = "SELECT * FROM agencymaster";
		}
		
		$result = $this->fetchAssoc($sql);
		return $result;
	}
	
	public function getById($id){
		$database = new Database();
		
		$id = $this->sanitize($id);
		$sql = "SELECT * FROM agencymaster where id='".$id."'";
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}
	
	
	
	public function save(){
		$database 		= new Database();
		
		$admin_name 	= $_SESSION['ADMIN_NAME'];
		$submit 		= $this->sanitize($_POST["submit"]);
		
		$id 			= $this->sanitize($_POST["id"]);
		$agency_type	= $this->sanitize($_POST["agency_type"]);
		$type 			= $this->sanitize($_POST["type"]);
        $agencyname 	= $this->sanitize($_POST["agencyname"]);
		$address 		= $this->sanitize($_POST["address"]);
        $city 			= $this->sanitize($_POST["city"]);
		$state 			= $this->sanitize($_POST["state"]);
        $country 		= $this->sanitize($_POST["country"]);
		$pincode 		= $this->sanitize($_POST["pincode"]);
        $contactno 		= $this->sanitize($_POST["contactno"]);
		$email 			= $this->sanitize($_POST["email"]);
		
		//$username		= $this->getInitials($agencyname);
		
		$createdon 		= date('Y-m-d H:i:s');
		$createdby 		= $admin_name? $admin_name: '';
		$modifiedon 	= date('Y-m-d H:i:s');
		$modifiedby 	= $admin_name? $admin_name: '';
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		if($submit == 'UPDATE'){
			$agencystatus 	= $this->sanitize($_POST["agencystatus"]);
		}
		
		if($submit == 'SAVE'){
			$sql = "INSERT INTO agencymaster(agency_type, type, agencyname, address, city, state, country, pincode, contactno, email, createdby, createdon, modifiedby, modifiedon, ipaddress) VALUES ('$agency_type','$type', '$agencyname', '$address', '$city', '$state', '$country', '$pincode', '$contactno', '$email', '$createdby', '$createdon', '$modifiedby', '$modifiedon', '$ipaddress')";
		}
		if($submit == 'UPDATE'){
			$sql_log = "INSERT INTO agencymaster_log SELECT id, agency_type, type, agencyname, address, city, state, country, pincode, contactno, email, agencystatus, createdby, createdon, '".$modifiedby."', '".$modifiedon."', '".$ipaddress."' FROM agencymaster WHERE id = '".$id."'";
			//$sql_log; die();
			$result_log = $database->query($sql_log);
			
			$sql = "UPDATE agencymaster SET agency_type = '".$agency_type."', type='".$type."', agencyname='".$agencyname."', address='".$address."', city='".$city."', state='".$state."', country='".$country."', pincode='".$pincode."', contactno='".$contactno."', email='".$email."', agencystatus = '".$agencystatus."', modifiedby='".$modifiedby."', modifiedon='".$modifiedon."', ipaddress='".$ipaddress."' WHERE id='".$id."'";
		}
		
		$result = $database->prepare($sql);
		if($result->execute()){
			$result->close();
			
			if($submit == 'SAVE'){
				$_SESSION['msgD'] = 'Agency master data inserted successfully.';
				$sql_user = "INSERT INTO adminuser(username, name, email, role, contact, logintype, ipadd, createddate, createdby, modifiedby, modifiedon) VALUES ('".$email."', '".$agencyname."', '".$email."', '16', '".$contactno."', 'Normal', '".$ipaddress."', '".$createdon."', '".$createdby."', '".$modifiedby."', '".$modifiedon."')";
				$result_user = $database->query($sql_user);
			}else{
				$_SESSION['msgD'] = 'Agency master data updated successfully.';
			}			
			
		}else{
			$_SESSION['msgD'] = 'Error while executing query.';
			$result->close();
		}
        
		
		$database->close();
		$this->redirect('manageagencymaster.php');
	}	
}

?>
