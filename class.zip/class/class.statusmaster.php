<?php 
error_reporting(E_ERROR);
ini_set('display_errors', 1);
include_once("database.class.php");
include_once("class.config.php");

class Statusmaster extends config{
	
	//public $database;
	
	function __construct() {
		if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
		{
			$this->redirect('index.php');
			exit();
		}
	}
	
	function __destruct() {
		//parent::__construct();
		//$database->close;
	}
	
	public function getAllAgencyStatus($username) {
		$database = new Database();	
		
		$sql = "SELECT a.id, a.statusname, b.id AS agencyid, b.agencyname FROM status_master a INNER JOIN agencymaster b ON a.type = b.type AND b.username = '".$username."' WHERE a.status_type = 'End'";
		
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getAllInitialStatus() {
		$database = new Database();	
		
		$sql = "SELECT * FROM status_master where status_type = 'Initial' ORDER BY modifiedon DESC";
		
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getAll() {
		$database = new Database();	
		
		$sql = "SELECT * FROM status_master ORDER BY modifiedon DESC";
		
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		$database->close();
		return $alldata;
	}
	
	public function getById($id){
		$database = new Database();
	
		$result = array();
		
		$psuid = $this->sanitize($id);
		$sql = "SELECT * FROM status_master WHERE id = '".$psuid."'";
		
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}	
	
	public function save(){
		$database = new Database();
		
		$admin_name = $_SESSION['ADMIN_NAME'];
		$submit = $this->sanitize($_POST["submit"]);
		
		$id 			= $this->sanitize($_POST["id"]);
		$statusname 	= $this->sanitize($_POST["statusname"]);
        $description 	= $this->sanitize($_POST["description"]);
		$autochallan 	= $this->sanitize($_POST["autochallan"]);
		$type 			= $this->sanitize($_POST["type"]);
		$status_type	= $this->sanitize($_POST["status_type"]);
		$createdon 		= date('Y-m-d H:i:s');
		$createdby 		= $admin_name? $admin_name: '';
		$modifiedon 	= date('Y-m-d H:i:s');
		$modifiedby 	= $admin_name? $admin_name: '';
        $ipaddress		= $this->sanitize($_SERVER['REMOTE_ADDR']);
		
		if($submit == 'SAVE'){
			$sql = "INSERT INTO status_master(statusname, description, type, status_type, autochallan, createdby, createdon, modifiedby, modifiedon, ipaddress) VALUES ('".$statusname."', '".$description."', '".$type."', '".$status_type."', '".$autochallan."', '".$createdby."', '".$createdon."', '".$modifiedby."', '".$modifiedon."', '".$ipaddress."')";
		}
		if($submit == 'UPDATE'){
			$sql_log = "INSERT INTO status_master_log SELECT id, statusname, description, type, status_type, autochallan, createdby, createdon, '".$modifiedby."', '".$modifiedon."', '".$ipaddress."' FROM status_master WHERE id = '".$id."'";
			$result_log = $database->query($sql_log);
						
			$sql = "UPDATE status_master SET statusname='".$statusname."', description='".$description."', type='".$type."', status_type='".$status_type."', autochallan='".$autochallan."', modifiedby='".$modifiedby."', modifiedon='".$modifiedon."', ipaddress='".$ipaddress."' WHERE id = '".$id."'";	
		}
		
		$result = $database->prepare($sql);
		if($result->execute()){
			if($submit == 'SAVE'){
				$_SESSION['msgD'] = 'Status Master Data Inserted Successfully.';
			}else{
				$_SESSION['msgD'] = 'Status Master Updated Successfully.';
			}			
		}else{
			$_SESSION['msgD'] = 'Error while executing query.';
		}
		
		$result->close();
		$database->close();
		$this->redirect('managestatusmaster.php');
	}	
}

?>
