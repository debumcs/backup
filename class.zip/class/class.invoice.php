<?php 
include_once("class.config.php");
class invoice extends config{
	
	//public $database;
	
	function __construct() {
		
		if(!isset($_SESSION['ADMIN_NAME']) || (trim($_SESSION['ADMIN_NAME']) == '')) 
		{
			$this->redirect('index.php');
			exit();
		}
	}
	
	function __destruct(){
		//parent::__construct();
		//$database->close;
	}
	
		
	public function getAll() {
		$database = new Database();
		
		$sql = "SELECT * FROM taxinvoice ORDER BY id DESC";
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		
		$database->close();
		return $alldata;
	}
	
	public function getById($id) {
		$database = new Database();
	
		// Initialize result array
		$result = array();
		$id = $this->sanitize($id);
		$sql = "SELECT * FROM taxinvoice where id = '".$id."'";
		
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data;
	}
	
	public function getAllGoodsByInvoiceId($id) {
		$database = new Database();
	
		$id = $this->sanitize($id);
		$sql = "SELECT * FROM goods_details where invoice_id = '".$id."'";
		
		$result = $database->query($sql);
		$alldata = array();
		
		while($field = $result->fetch_assoc())
		{
			$alldata[] = $field;
		}
		
		$database->close();
		return $alldata;
	}
	
	public function save() {
		
		$database = new Database();
		$gstin_no	= $this->sanitize($_POST["gstin_no"]);
		$mob_no	= $this->sanitize($_POST["mob_no"]);
		$email	= $this->sanitize($_POST["email"]);
		$firm_name	= $this->sanitize($_POST["firm_name"]);
		$firm_address	= $this->sanitize($_POST["firm_address"]);
		$products	= $this->sanitize($_POST["products"]);
		$invoice_date	= $this->sanitize($_POST["invoice_date"]);
		$invoice_serialno	= $this->sanitize($_POST["invoice_serialno"]);
		$biller_name	= $this->sanitize($_POST["biller_name"]);
		$bill_to_address = $this->sanitize($_POST["bill_to_address"]);
		
		$bill_to_state = $this->sanitize($_POST["bill_to_state"]);
		$bill_to_state_code = $this->sanitize($_POST["bill_to_state_code"]);
		$bill_to_mob_no = $this->sanitize($_POST["bill_to_mob_no"]);
		$bill_to_email = $this->sanitize($_POST["bill_to_email"]);
		$bill_gstin_id = $this->sanitize($_POST["bill_gstin_id"]);
		$ship_name = $this->sanitize($_POST["ship_name"]);
		$ship_to_address = $this->sanitize($_POST["ship_to_address"]);
		$ship_to_state = $this->sanitize($_POST["ship_to_state"]);
		$ship_to_state_code = $this->sanitize($_POST["ship_to_state_code"]);
		$ship_to_mob_no = $this->sanitize($_POST["ship_to_mob_no"]);
		$ship_to_email = $this->sanitize($_POST["ship_to_email"]);
		$ship_gstin_id = $this->sanitize($_POST["ship_gstin_id"]);
		
		
		$freight_total = $this->sanitize($_POST["freight_total"]);
		$freight_discount = $this->sanitize($_POST["freight_discount"]);
		$freight_taxable = $this->sanitize($_POST["freight_taxable"]);
		$freight_cgstRate = $this->sanitize($_POST["freight_cgstRate"]);
		$freight_cgstAmt = $this->sanitize($_POST["freight_cgstAmt"]);
		$freight_sgstRate = $this->sanitize($_POST["freight_sgstRate"]);
		$freight_sgstAmt = $this->sanitize($_POST["freight_sgstAmt"]);
		$freight_igstRate = $this->sanitize($_POST["freight_igstRate"]);
		$freight_igstAmt = $this->sanitize($_POST["freight_igstAmt"]);
		$insaurance_total = $this->sanitize($_POST["insaurance_total"]);
		$insaurance_discount = $this->sanitize($_POST["insaurance_discount"]);
		$insaurance_taxable = $this->sanitize($_POST["insaurance_taxable"]);
		$insaurance_cgstRate = $this->sanitize($_POST["insaurance_cgstRate"]);
		$insaurance_cgstAmt = $this->sanitize($_POST["insaurance_cgstAmt"]);
		$insaurance_sgstRate = $this->sanitize($_POST["insaurance_sgstRate"]);
		$insaurance_sgstAmt = $this->sanitize($_POST["insaurance_sgstAmt"]);
		$insaurance_igstRate = $this->sanitize($_POST["insaurance_igstRate"]);
		$insaurance_igstAmt = $this->sanitize($_POST["insaurance_igstAmt"]);
		$pack_total = $this->sanitize($_POST["pack_total"]);
		$pack_discount = $this->sanitize($_POST["pack_discount"]);
		$pack_taxable = $this->sanitize($_POST["pack_taxable"]);
		$pack_cgstRate = $this->sanitize($_POST["pack_cgstRate"]);
		$pack_cgstAmt = $this->sanitize($_POST["pack_cgstAmt"]);
		$pack_sgstRate = $this->sanitize($_POST["pack_sgstRate"]);
		$pack_sgstAmt = $this->sanitize($_POST["pack_sgstAmt"]);
		$pack_igstRate = $this->sanitize($_POST["pack_igstRate"]);
		$pack_igstAmt = $this->sanitize($_POST["pack_igstAmt"]);
		
		$total_total = $this->sanitize($_POST["total_total"]);
		$total_discount = $this->sanitize($_POST["total_discount"]);
		$total_taxable_value = $this->sanitize($_POST["total_taxable_value"]);
		$total_cgst = $this->sanitize($_POST["total_cgst"]);
		$total_sgst = $this->sanitize($_POST["total_sgst"]);
		$total_igst = $this->sanitize($_POST["total_igst"]);
		$tax_reverse_cgst = $this->sanitize($_POST["tax_reverse_cgst"]);
		$tax_reverse_sgst = $this->sanitize($_POST["tax_reverse_sgst"]);
		$tax_reverse_igst = $this->sanitize($_POST["tax_reverse_igst"]);
		
		$total_in_figure = $this->sanitize($_POST["total_in_figure"]);
		$total_in_words = $this->sanitize($_POST["total_in_words"]);
		$electronic_ref_no = $this->sanitize($_POST["electronic_ref_no"]);
		$rev_tax_amt = $this->sanitize($_POST["rev_tax_amt"]);
		$submit = $this->sanitize($_POST["submit"]);
		
			
		$sql = "INSERT INTO taxinvoice(gstin_no, mob_no, email, firm_name, firm_address, products, invoice_date, invoice_serialno, biller_name, bill_to_address, bill_to_state, bill_to_state_code, bill_to_mob_no, bill_to_email, bill_gstin_id, ship_name, ship_to_address, ship_to_state, ship_to_state_code, ship_to_mob_no, ship_to_email, ship_gstin_id, rev_tax_amt, freight_total, freight_discount, freight_taxable, freight_cgstRate, freight_cgstAmt, freight_sgstRate, freight_sgstAmt, freight_igstRate, freight_igstAmt, insaurance_total, insaurance_discount, insaurance_taxable, insaurance_cgstRate, insaurance_cgstAmt, insaurance_sgstRate, insaurance_sgstAmt, insaurance_igstRate, insaurance_igstAmt, pack_total, pack_discount, pack_taxable, pack_cgstRate, pack_cgstAmt, pack_sgstRate, pack_sgstAmt, pack_igstRate, pack_igstAmt, total_total, total_discount, total_taxable_value, total_cgst, total_sgst, total_igst, tax_reverse_cgst, tax_reverse_sgst, tax_reverse_igst, total_in_figure, total_in_words, electronic_ref_no) VALUES ('".$gstin_no."', '".$mob_no."', '".$email."', '".$firm_name."', '".$firm_address."', '".$products."', '".$invoice_date."', '".$invoice_serialno."', '".$biller_name."', '".$bill_to_address."', '".$bill_to_state."', '".$bill_to_state_code."', '".$bill_to_mob_no."', '".$bill_to_email."', '".$bill_gstin_id."', '".$ship_name."', '".$ship_to_address."', '".$ship_to_state."', '".$ship_to_state_code."', '".$ship_to_mob_no."', '".$ship_to_email."', '".$ship_gstin_id."', '".$rev_tax_amt."', '".$freight_total."', '".$freight_discount."', '".$freight_taxable."', '".$freight_cgstRate."', '".$freight_cgstAmt."', '".$freight_sgstRate."', '".$freight_sgstAmt."', '".$freight_igstRate."', '".$freight_igstAmt."', '".$insaurance_total."', '".$insaurance_discount."', '".$insaurance_taxable."', '".$insaurance_cgstRate."', '".$insaurance_cgstAmt."', '".$insaurance_sgstRate."', '".$insaurance_sgstAmt."', '".$insaurance_igstRate."', '".$insaurance_igstAmt."', '".$pack_total."', '".$pack_discount."', '".$pack_taxable."', '".$pack_cgstRate."', '".$pack_cgstAmt."', '".$pack_sgstRate."', '".$pack_sgstAmt."', '".$pack_igstRate."', '".$pack_igstAmt."', '".$total_total."', '".$total_discount."', '".$total_taxable_value."', '".$total_cgst."', '".$total_sgst."', '".$total_igst."', '".$tax_reverse_cgst."', '".$tax_reverse_sgst."', '".$tax_reverse_igst."', '".$total_in_figure."', '".$total_in_words."', '".$electronic_ref_no."');";
		$result = $database->prepare($sql);
		//echo $sql; die();
		if($result->execute()){
			$_SESSION['msgD'] = "Customer Data Created Successfully";
			$last_id = $database->insert_id;
			$this->save_goods_details($last_id);
		}else{
			$_SESSION['msgD'] = "Error found on customer data creation.";
		}
		
		$result->close();		
		$database->close();		
		$this->redirect('viewallinvoice.php');			
	}
	
	public function save_goods_details($last_id) {
		
		$database = new Database();
			
		$sr_no = $this->sanitize($_POST["sr_no"]);
		$Description = $this->sanitize($_POST["Description"]);
		$hsn_code = $this->sanitize($_POST["hsn_code"]);
		$qty = $this->sanitize($_POST["qty"]);
		$unit = $this->sanitize($_POST["unit"]);
		$rate = $this->sanitize($_POST["rate"]);
		$total = $this->sanitize($_POST["total"]);
		$discount = $this->sanitize($_POST["discount"]);
		$taxable_value = $this->sanitize($_POST["taxable_value"]);
		$cgst_rate = $this->sanitize($_POST["cgst_rate"]);
		$cgst_amt = $this->sanitize($_POST["cgst_amt"]);
		$sgst_rate = $this->sanitize($_POST["sgst_rate"]);
		$sgst_amt = $this->sanitize($_POST["sgst_amt"]);
		$igst_rate = $this->sanitize($_POST["igst_rate"]);
		$igst_amt = $this->sanitize($_POST["igst_amt"]);
		$invoice_id = $last_id;
		
		
		for($i=0;$i<count($sr_no);$i++)	{
			$sql = "INSERT INTO goods_details(sr_no, Description, hsn_code, qty, unit, rate, total, discount, taxable_value, cgst_rate, cgst_amt, sgst_rate, sgst_amt, igst_rate, igst_amt, invoice_id) VALUES ('".$sr_no[$i]."', '".$Description[$i]."', '".$hsn_code[$i]."', '".$qty[$i]."', '".$unit[$i]."', '".$rate[$i]."', '".$total[$i]."', '".$discount[$i]."', '".$taxable_value[$i]."', '".$cgst_rate[$i]."', '".$cgst_amt[$i]."', '".$sgst_rate[$i]."', '".$sgst_amt[$i]."', '".$igst_rate[$i]."', '".$igst_amt[$i]."', '".$invoice_id."');";
			$result = $database->prepare($sql);
			$result->execute();
			$result->close();
		}		
		$database->close();				
	}
	
	public function last_insert_id(){
		$database = new Database();
	
		$result = array();
		$sql = "SELECT id FROM taxinvoice ORDER BY id DESC LIMIT 1";		
		$result = $database->query($sql);
		$data = $result->fetch_assoc();
		$database->close();
		return $data['id'];
	}
}

?>
