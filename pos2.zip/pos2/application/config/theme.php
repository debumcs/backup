<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| theme name
|--------------------------------------------------------------------------
|
| the theme folder name. If the folder doesn't exist it will use default theme
|
| The default theme for OSPOS is flatly: http://bootswatch.com/flatly/
|
|
*/

//$config['theme_name'] = 'spacelab';
