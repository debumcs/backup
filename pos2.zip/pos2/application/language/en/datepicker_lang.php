<?php 

$lang["datepicker_today"] = "Today";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_all_time"] = "All Time";
$lang["datepicker_last_7"] = "Last 7 Days";
$lang["datepicker_last_30"] = "Last 30 Days";
$lang["datepicker_last_month"] = "Last Month";
$lang["datepicker_last_year"] = "Last Year";
$lang["datepicker_this_month"] = "This Month";
$lang["datepicker_this_month_last_year"] = "This Month Last Year";
$lang["datepicker_this_month_to_today"] = "This Month To Today";
$lang["datepicker_this_month_to_today_last_year"] = "This Month To Today Last Year";
$lang["datepicker_this_year"] = "This Year";
$lang["datepicker_today_last_year"] = "Today Last Year";
$lang["datepicker_yesterday"] = "Yesterday";
$lang["datepicker_apply"] = "Apply";
$lang["datepicker_cancel"] = "Cancel";
$lang["datepicker_from"] = "From";
$lang["datepicker_to"] = "To";
$lang["datepicker_custom"] = "Custom";
