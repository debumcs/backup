<?php 

$lang["tables_loading"] = "正在努力地加载数据中，请稍候……";
$lang["tables_rows_per_page"] = "每页显示 {0} 条记录";
$lang["tables_page_from_to"] = "显示第 {0} 到第 {1} 条记录，总共 {2} 条记录";
$lang["tables_hide_show_pagination"] = "隐藏/显示分页";
$lang["tables_refresh"] = "刷新";
$lang["tables_toggle"] = "切换";
$lang["tables_columns"] = "列";
$lang["tables_all"] = "All";
