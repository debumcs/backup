<?php 

$lang["datepicker_today"] = "今天";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_all_time"] = "全部";
$lang["datepicker_last_7"] = "過去七天";
$lang["datepicker_last_30"] = "過去七天";
$lang["datepicker_last_month"] = "上個月";
$lang["datepicker_last_year"] = "去年";
$lang["datepicker_this_month"] = "這個月";
$lang["datepicker_this_month_last_year"] = "This Month Last Year";
$lang["datepicker_this_month_to_today"] = "This Month To Today";
$lang["datepicker_this_month_to_today_last_year"] = "This Month To Today Last Year";
$lang["datepicker_this_year"] = "今年";
$lang["datepicker_today_last_year"] = "Today Last Year";
$lang["datepicker_yesterday"] = "昨天";
$lang["datepicker_apply"] = "Apply";
$lang["datepicker_cancel"] = "Cancel";
$lang["datepicker_from"] = "From";
$lang["datepicker_to"] = "To";
$lang["datepicker_custom"] = "Custom";
