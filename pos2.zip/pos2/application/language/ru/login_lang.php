<?php 

$lang["login_go"] = "ходите";
$lang["login_invalid_username_and_password"] = "Неправелная Имя/Пароль";
$lang["login_login"] = "Вход";
$lang["login_password"] = "Пароль";
$lang["login_username"] = "Имя";
