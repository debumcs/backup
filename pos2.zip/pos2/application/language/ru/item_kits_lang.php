<?php 

$lang["item_kits_add_item"] = "Добавить товар";
$lang["item_kits_cannot_be_deleted"] = "Не могу удалить Товара комплект (ы)";
$lang["item_kits_confirm_delete"] = "Вы уверены, что хотите удалить выбранные товар? комплекты";
$lang["item_kits_description"] = "Описание товара Комплект";
$lang["item_kits_error_adding_updating"] = "Ошибка при добавлении/обновлении товара комплекта";
$lang["item_kits_info"] = "Информация о товаре комплекта";
$lang["item_kits_item"] = "товар";
$lang["item_kits_items"] = "товары";
$lang["item_kits_kit"] = "Kit Id";
$lang["item_kits_name"] = "Наименование товара комплект";
$lang["item_kits_new"] = "Новый товар комплект";
$lang["item_kits_no_item_kits_to_display"] = "Нет товара комплекты для отображения";
$lang["item_kits_none_selected"] = "Вы не выбрали ни одной товар комплекты";
$lang["item_kits_one_or_multiple"] = "Товара комплект (ы)";
$lang["item_kits_quantity"] = "количество";
$lang["item_kits_successful_adding"] = "Вы успешно добавлен товар комплекта";
$lang["item_kits_successful_deleted"] = "Вы успешно удален";
$lang["item_kits_successful_updating"] = "Вы успешно обновленного товар комплекта";
$lang["item_kits_update"] = "Обновить товар комплекта";
