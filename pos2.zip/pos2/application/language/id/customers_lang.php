<?php 

$lang["customers_account_number"] = "No.Pelanggan";
$lang["customers_account_number_duplicate"] = "This account number is already present in the database";
$lang["customers_cannot_be_deleted"] = "pelanggan terpilih tidak bisa dihapus. satu atau lebih dari pelanggan yang dipilih memiliki penjualan.";
$lang["customers_company_name"] = "Company";
$lang["customers_confirm_delete"] = "Apakah Anda yakin ingin menghapus pelanggan yang dipilih?";
$lang["customers_customer"] = "Pelanggan";
$lang["customers_discount"] = "Discount";
$lang["customers_error_adding_updating"] = "Menambah / Memperbarui Pelanggan Salah";
$lang["customers_new"] = "Pelanggan Baru";
$lang["customers_none_selected"] = "Anda belum memilih pelanggan untuk dihapus";
$lang["customers_one_or_multiple"] = "pelanggan";
$lang["customers_successful_adding"] = "Anda telah berhasil menambah pelanggan";
$lang["customers_successful_deleted"] = "Anda telah berhasil menghapus pelanggan";
$lang["customers_successful_updating"] = "Anda telah berhasil memperbarui pelanggan";
$lang["customers_taxable"] = "Dapat dikenakan pajak";
$lang["customers_total"] = "Total";
$lang["customers_update"] = "Ubah Pelanggan";
$lang["customers_import_items_excel"] = "Import customers from Excel sheet";
$lang["customers_excel_import_failed"] = "Impor dari Excel tidak berhasil dilakukan";
$lang["customers_excel_import_nodata_wrongformat"] = "Your uploaded file has no data or wrong format";
$lang["customers_excel_import_success"] = "Import of Customers successful";
$lang["customers_excel_import_partially_failed"] = "Most Customers imported. But some were not, here is the list";
