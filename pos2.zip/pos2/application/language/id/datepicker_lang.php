<?php 

$lang["datepicker_today"] = "Hari ini";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_all_time"] = "Semua Waktu";
$lang["datepicker_last_7"] = "7 Hari Terakhir";
$lang["datepicker_last_30"] = "30 Hari Terakhir";
$lang["datepicker_last_month"] = "Bulan lalu";
$lang["datepicker_last_year"] = "Tahun lalu";
$lang["datepicker_this_month"] = "Bulan ini";
$lang["datepicker_this_month_last_year"] = "This Month Last Year";
$lang["datepicker_this_month_to_today"] = "This Month To Today";
$lang["datepicker_this_month_to_today_last_year"] = "This Month To Today Last Year";
$lang["datepicker_this_year"] = "Tahun ini";
$lang["datepicker_today_last_year"] = "Today Last Year";
$lang["datepicker_yesterday"] = "Kemarin";
$lang["datepicker_apply"] = "Apply";
$lang["datepicker_cancel"] = "Cancel";
$lang["datepicker_from"] = "From";
$lang["datepicker_to"] = "To";
$lang["datepicker_custom"] = "Custom";
