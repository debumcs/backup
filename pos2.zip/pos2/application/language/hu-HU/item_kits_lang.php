<?php 

$lang["item_kits_add_item"] = "Termék hozzáadása";
$lang["item_kits_cannot_be_deleted"] = "Termékcsomag(ok) nem törölhető(ek)";
$lang["item_kits_confirm_delete"] = "Biztos, hogy törli a kiválasztott csomagokat?";
$lang["item_kits_description"] = "Termékcsomag leírás";
$lang["item_kits_error_adding_updating"] = "Hiba a termékcsomag hozzáadásánál/módosításánál";
$lang["item_kits_info"] = "Termékcsomag info";
$lang["item_kits_item"] = "Termék";
$lang["item_kits_items"] = "Termékek";
$lang["item_kits_kit"] = "Csomag ID";
$lang["item_kits_name"] = "Termékcsomag neve";
$lang["item_kits_new"] = "Új termékcsomag";
$lang["item_kits_no_item_kits_to_display"] = "Nincsenek megjeleníthető termékcsomagok";
$lang["item_kits_none_selected"] = "Nem választott ki termékcsomagot";
$lang["item_kits_one_or_multiple"] = "Termékcsomag(ok)";
$lang["item_kits_quantity"] = "Mennyiség";
$lang["item_kits_successful_adding"] = "Sikeresen hozzáadta a termékcsomagot";
$lang["item_kits_successful_deleted"] = "Sikeresen törölte a termékcsomagot";
$lang["item_kits_successful_updating"] = "Sikeresen módosította a termékcsomagot";
$lang["item_kits_update"] = "Termékcsomag módosítása";
