<?php 

$lang["module_config"] = "Einstellungen";
$lang["module_config_desc"] = "Einstellungen ändern";
$lang["module_customers"] = "Kunden";
$lang["module_customers_desc"] = "Hinzufügen, Ändern, Löschen und Suchen";
$lang["module_employees"] = "Mitarbeiter";
$lang["module_employees_desc"] = "Hinzufügen, Ändern, Löschen und Suchen";
$lang["module_giftcards"] = "Gutscheine";
$lang["module_giftcards_desc"] = "Hinzufügen, Ändern, Löschen und Suchen";
$lang["module_home"] = "Home";
$lang["module_item_kits"] = "Artikel-Sets";
$lang["module_item_kits_desc"] = "Hinzufügen, Ändern, Löschen und Suchen";
$lang["module_items"] = "Artikel";
$lang["module_items_desc"] = "Hinzufügen, Ändern, Löschen und Suchen";
$lang["module_receivings"] = "Eingänge";
$lang["module_receivings_desc"] = "Hinzufügen, Ändern, Löschen und Suchen";
$lang["module_reports"] = "Berichte";
$lang["module_reports_desc"] = "Hinzufügen, Ändern, Löschen und Suchen";
$lang["module_sales"] = "Verkauf";
$lang["module_sales_desc"] = "Hinzufügen, Ändern, Löschen und Suchen";
$lang["module_suppliers"] = "Lieferanten";
$lang["module_suppliers_desc"] = "Hinzufügen, Ändern, Löschen und Suchen";
$lang["module_messages"] = "Messages";
$lang["module_messages_desc"] = "Send Messages to Customers, Suppliers, Employees et al.";
