<?php 

$lang["suppliers_account_number"] = "Cuenta #";
$lang["suppliers_cannot_be_deleted"] = "No se pudo borrar los proveedores seleccionados. Uno o más de los seleccionados tiene ventas.";
$lang["suppliers_company_name"] = "Nombre de la Compañía";
$lang["suppliers_company_name_required"] = "Nombre de la Compañía es requerido";
$lang["suppliers_agency_name"] = "Nombre de la Agency";
$lang["suppliers_confirm_delete"] = "¿Seguro(a) de querer borrar los proveedores seleccionados?";
$lang["suppliers_error_adding_updating"] = "Error agregando/actualizando proveedor";
$lang["suppliers_new"] = "Nuevo Proveedor";
$lang["suppliers_none_selected"] = "No has seleccionado proveedores para borrar";
$lang["suppliers_one_or_multiple"] = "proveedor(es)";
$lang["suppliers_successful_adding"] = "Has agregado el proveedor satisfactoriamente";
$lang["suppliers_successful_deleted"] = "Has borrado satisfactoriamente a";
$lang["suppliers_successful_updating"] = "Has actualizado el proveedor satisfactoriamente";
$lang["suppliers_supplier"] = "Proveedor";
$lang["suppliers_supplier_id"] = "Id";
$lang["suppliers_update"] = "Actualizar Proveedor";
