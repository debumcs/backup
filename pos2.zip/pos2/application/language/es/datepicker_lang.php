<?php 

$lang["datepicker_today"] = "Hoy";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_all_time"] = "Todos";
$lang["datepicker_last_7"] = "Últimos 7 Días";
$lang["datepicker_last_30"] = "Últimos 30 Días";
$lang["datepicker_last_month"] = "Último Mes";
$lang["datepicker_last_year"] = "Último Año";
$lang["datepicker_this_month"] = "Este Mes";
$lang["datepicker_this_month_last_year"] = "Este Mes ace un año";
$lang["datepicker_this_month_to_today"] = "Este Mes hasta hoy";
$lang["datepicker_this_month_to_today_last_year"] = "Este mes hasta hoy, del año pasado";
$lang["datepicker_this_year"] = "Este Año";
$lang["datepicker_today_last_year"] = "Hoy el año pasado";
$lang["datepicker_yesterday"] = "Ayer";
$lang["datepicker_apply"] = "Aplicar";
$lang["datepicker_cancel"] = "Cancelar";
$lang["datepicker_from"] = "Desde";
$lang["datepicker_to"] = "Hasta";
$lang["datepicker_custom"] = "Personalizar";
