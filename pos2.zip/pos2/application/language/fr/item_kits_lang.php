<?php 

$lang["item_kits_add_item"] = "Ajouter Item";
$lang["item_kits_cannot_be_deleted"] = "Impossible de supprimer";
$lang["item_kits_confirm_delete"] = "Ètes vous sûr(e) de vouloir supprimer le(s) Kits sélectionnés?";
$lang["item_kits_description"] = "Description du Kit";
$lang["item_kits_error_adding_updating"] = "Érreur d'ajout/édition de Kit";
$lang["item_kits_info"] = "Détails du Kit";
$lang["item_kits_item"] = "Item";
$lang["item_kits_items"] = "Items";
$lang["item_kits_kit"] = "Kit Id";
$lang["item_kits_name"] = "Nom du Kit";
$lang["item_kits_new"] = "Nouveau Kit";
$lang["item_kits_no_item_kits_to_display"] = "Aucun kit à afficher";
$lang["item_kits_none_selected"] = "Vous n'avez sélectionné aucun kit";
$lang["item_kits_one_or_multiple"] = "Kit(s)";
$lang["item_kits_quantity"] = "Quantité";
$lang["item_kits_successful_adding"] = "Vous avez ajouté un Kit";
$lang["item_kits_successful_deleted"] = "Suppréssion réussie";
$lang["item_kits_successful_updating"] = "Vous avez édité un Kit";
$lang["item_kits_update"] = "Éditer Kit";
