<?php 

$lang["datepicker_today"] = "Aujourd'hui";
$lang["datepicker_weekstart"] = "1";
$lang["datepicker_all_time"] = "Depuis le début";
$lang["datepicker_last_7"] = "Ces 7 derniers jours";
$lang["datepicker_last_30"] = "Ces 30 derniers jours";
$lang["datepicker_last_month"] = "Le mois dernier";
$lang["datepicker_last_year"] = "L'année passée";
$lang["datepicker_this_month"] = "Ce mois";
$lang["datepicker_this_month_last_year"] = "This Month Last Year";
$lang["datepicker_this_month_to_today"] = "This Month To Today";
$lang["datepicker_this_month_to_today_last_year"] = "This Month To Today Last Year";
$lang["datepicker_this_year"] = "Cette Année";
$lang["datepicker_today_last_year"] = "Today Last Year";
$lang["datepicker_yesterday"] = "Hier";
$lang["datepicker_apply"] = "Apply";
$lang["datepicker_cancel"] = "Cancel";
$lang["datepicker_from"] = "From";
$lang["datepicker_to"] = "To";
$lang["datepicker_custom"] = "Custom";
