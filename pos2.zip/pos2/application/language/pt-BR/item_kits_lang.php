<?php 

$lang["item_kits_add_item"] = "Adicionar Item";
$lang["item_kits_cannot_be_deleted"] = "Não foi possível eliminar conjunto de itens";
$lang["item_kits_confirm_delete"] = "Tem certeza de que deseja excluir os conjuntos de itens selecionados?";
$lang["item_kits_description"] = "Descrição do conjunto de Itens";
$lang["item_kits_error_adding_updating"] = "Erro ao adicionar/atualizar conjunto de item";
$lang["item_kits_info"] = "Informação do conjunto de Itens";
$lang["item_kits_item"] = "Item";
$lang["item_kits_items"] = "Itens";
$lang["item_kits_kit"] = "Conjunto Id";
$lang["item_kits_name"] = "Nome conjunto de Itens";
$lang["item_kits_new"] = "Novo conjunto de Itens";
$lang["item_kits_no_item_kits_to_display"] = "Não há conjuntos de itens para exibir";
$lang["item_kits_none_selected"] = "Você não selecionou nenhum conjunto de itens";
$lang["item_kits_one_or_multiple"] = "Conjunto de Itens";
$lang["item_kits_quantity"] = "Quantidade";
$lang["item_kits_successful_adding"] = "Você adicionou com sucesso conjunto de item";
$lang["item_kits_successful_deleted"] = "Você excluiu com sucesso";
$lang["item_kits_successful_updating"] = "Você atualizou com sucesso conjunto de item";
$lang["item_kits_update"] = "Atualizar Item no conjunto";
