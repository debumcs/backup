<?php 

$lang["login_go"] = "Entrar";
$lang["login_invalid_username_and_password"] = "Usuário ou senha inválido";
$lang["login_login"] = "Login";
$lang["login_password"] = "Senha";
$lang["login_username"] = "Usuário";
