<?php 

$lang["module_config"] = "Configurações";
$lang["module_config_desc"] = "Alterar configurações do sistema";
$lang["module_customers"] = "Clientes";
$lang["module_customers_desc"] = "Adicionar, atualizar,  excluir e Pesquisar clientes";
$lang["module_employees"] = "Funcionários";
$lang["module_employees_desc"] = "Adicionar , atualizar,  excluir e Pesquisar funcionários";
$lang["module_giftcards"] = "Cartões Presente";
$lang["module_giftcards_desc"] = "Adicionar,  atualizar, excluir e Pesquisar cartões presente";
$lang["module_home"] = "Início";
$lang["module_item_kits"] = "Conjuntos";
$lang["module_item_kits_desc"] = "Adicionar , atualizar, excluir e Pesquisar conjunto de itens";
$lang["module_items"] = "Itens";
$lang["module_items_desc"] = "Adicionar,  atualizar,  excluir e Pesquisar itens";
$lang["module_receivings"] = "Recebimento";
$lang["module_receivings_desc"] = "Processar ordens";
$lang["module_reports"] = "Relatórios";
$lang["module_reports_desc"] = "Gerar relatórios";
$lang["module_sales"] = "Vendas";
$lang["module_sales_desc"] = "Processar vendas e devoluções";
$lang["module_suppliers"] = "Fornecedores";
$lang["module_suppliers_desc"] = "Adicionar,  atualizar,  excluir e Pesquisar fornecedores";
$lang["module_messages"] = "Mensagens";
$lang["module_messages_desc"] = "Enviar mensagens para os clientes, fornecedores, colaboradores etc.";
