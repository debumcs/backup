<?php 

$lang["datepicker_today"] = "Vandaag";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_all_time"] = "Alle";
$lang["datepicker_last_7"] = "Vorige 7 Dagen";
$lang["datepicker_last_30"] = "Vorige 30 Dagen";
$lang["datepicker_last_month"] = "Vorige Maand";
$lang["datepicker_last_year"] = "Vorig Jaar";
$lang["datepicker_this_month"] = "Deze Maand";
$lang["datepicker_this_month_last_year"] = "This Month Last Year";
$lang["datepicker_this_month_to_today"] = "This Month To Today";
$lang["datepicker_this_month_to_today_last_year"] = "This Month To Today Last Year";
$lang["datepicker_this_year"] = "Dit Jaar";
$lang["datepicker_today_last_year"] = "Today Last Year";
$lang["datepicker_yesterday"] = "Gisteren";
$lang["datepicker_apply"] = "Apply";
$lang["datepicker_cancel"] = "Cancel";
$lang["datepicker_from"] = "From";
$lang["datepicker_to"] = "To";
$lang["datepicker_custom"] = "Custom";
