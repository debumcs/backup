<?php 

$lang["login_go"] = "Ulaz";
$lang["login_invalid_username_and_password"] = "Neispravno ime/lozinka";
$lang["login_login"] = "Prijava";
$lang["login_password"] = "Lozinka";
$lang["login_username"] = "Korisničko ime";
