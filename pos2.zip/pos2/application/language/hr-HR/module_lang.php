<?php 

$lang["module_config"] = "Postavke";
$lang["module_config_desc"] = "Promijeni postavke";
$lang["module_customers"] = "Kupci";
$lang["module_customers_desc"] = "Dodaj, ažuriraj, obriši ili traži kupce";
$lang["module_employees"] = "Radnici";
$lang["module_employees_desc"] = "Dodaj, ažuriraj, obriši ili traži radnike";
$lang["module_giftcards"] = "Poklon bon";
$lang["module_giftcards_desc"] = "Dodaj, ažuriraj, obriši ili traži poklon bon";
$lang["module_home"] = "Početna";
$lang["module_item_kits"] = "Normativi";
$lang["module_item_kits_desc"] = "Dodaj, ažuriraj, obriši ili traži normative";
$lang["module_items"] = "Artikli";
$lang["module_items_desc"] = "Dodaj, ažuriraj, obriši ili traži artikle";
$lang["module_receivings"] = "Primka";
$lang["module_receivings_desc"] = "Dodaj, ažuriraj, obriši ili traži primke";
$lang["module_reports"] = "Izvještaji";
$lang["module_reports_desc"] = "Pogledaj i generiraj izvještaje";
$lang["module_sales"] = "Prodaja";
$lang["module_sales_desc"] = "Procesi prodaje i povrata";
$lang["module_suppliers"] = "Dobavljači";
$lang["module_suppliers_desc"] = "Dodaj, ažuriraj, obriši ili traži dobavljače";
$lang["module_messages"] = "Messages";
$lang["module_messages_desc"] = "Send Messages to Customers, Suppliers, Employees et al.";
