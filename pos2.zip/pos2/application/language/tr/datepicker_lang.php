<?php 

$lang["datepicker_today"] = "Bugün";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_all_time"] = "Tüm Zamanlar";
$lang["datepicker_last_7"] = "Son 7 Gün";
$lang["datepicker_last_30"] = "Son 30 Gün";
$lang["datepicker_last_month"] = "Geçen Ay";
$lang["datepicker_last_year"] = "Geçen Yıl";
$lang["datepicker_this_month"] = "Bu Ay";
$lang["datepicker_this_month_last_year"] = "This Month Last Year";
$lang["datepicker_this_month_to_today"] = "This Month To Today";
$lang["datepicker_this_month_to_today_last_year"] = "This Month To Today Last Year";
$lang["datepicker_this_year"] = "Bu Yıl";
$lang["datepicker_today_last_year"] = "Today Last Year";
$lang["datepicker_yesterday"] = "Dün";
$lang["datepicker_apply"] = "Apply";
$lang["datepicker_cancel"] = "Cancel";
$lang["datepicker_from"] = "From";
$lang["datepicker_to"] = "To";
$lang["datepicker_custom"] = "Custom";
