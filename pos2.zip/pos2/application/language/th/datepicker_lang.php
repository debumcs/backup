<?php 

$lang["datepicker_today"] = "วันนี้";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_all_time"] = "เวลาทั้งหมด";
$lang["datepicker_last_7"] = "7 วันสุดท้าย";
$lang["datepicker_last_30"] = "30 วันสุดท้าย";
$lang["datepicker_last_month"] = "เดือนที่แล้ว";
$lang["datepicker_last_year"] = "ปีที่แล้ว";
$lang["datepicker_this_month"] = "เดือนนี้";
$lang["datepicker_this_month_last_year"] = "This Month Last Year";
$lang["datepicker_this_month_to_today"] = "This Month To Today";
$lang["datepicker_this_month_to_today_last_year"] = "This Month To Today Last Year";
$lang["datepicker_this_year"] = "ปีนี้";
$lang["datepicker_today_last_year"] = "Today Last Year";
$lang["datepicker_yesterday"] = "เมื่อวานนี้";
$lang["datepicker_apply"] = "Apply";
$lang["datepicker_cancel"] = "Cancel";
$lang["datepicker_from"] = "From";
$lang["datepicker_to"] = "To";
$lang["datepicker_custom"] = "Custom";
