<?php
echo $this->lang->line('error_no_permission_module').' '.$module_name; 
?> 