<?php
$lang['config_info']='Informasi Konfigurasi Toko';
$lang['config_company']='Nama Perusahaan';
$lang['config_address']='Alamat Perusahaan';
$lang['config_phone']='Telepon Perusahaan';
$lang['config_website']='Situs Perusahaan';
$lang['config_fax']='Fax';
$lang['config_default_tax_rate']='Tarif Pajak Biasa%';
$lang['config_default_tax_rate_1']='Tarif Pajak 1';
$lang['config_default_tax_rate_2']='Tarif Pajak 2';
$lang['config_company_required']='Nama Perusahaan wajib diisi';
$lang['config_address_required']='Alamat Perusahaan wajib diisi';
$lang['config_phone_required']='Telepon Perusahaan wajib diisi';
$lang['config_default_tax_rate_required']='Tarif Pajak Biasa wajib diisi';
$lang['config_default_tax_rate_number']='Tarif Pajak Biasa harus angka';
$lang['config_company_website_url']='Situs Perusahaan bukan URL yang benar(http://...)';
$lang['config_saved_successfully']='Konfigurasi berhasil disimpan';
$lang['config_saved_unsuccessfully']='Konfigurasi tidak berhasil disimpan';
$lang['config_return_policy_required']='Kebiajak retur wajib diisi';
$lang['config_print_after_sale']='Cetak bon setelah penjualan';
$lang['config_language'] = 'Language';
$lang['config_timezone'] = 'Timezone';
?>