How to Install
-------------------------
1. Create/locate a new mysql database to install php point of sale into
2. Execute the file database/database.sql to create the tables needed
3. unzip and upload PHP Point Of Sale files to web server
4. Copy application/config/database.php.tmpl to application/config/database.php
5. Modify application/config/database.php to connect to your database
6. Go to your point of sale install via the browser
7. LOGIN using
username: admin 
password:pointofsale
8. Enjoy