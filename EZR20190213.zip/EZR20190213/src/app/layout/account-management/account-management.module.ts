import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccountManagementRoutingModule } from './account-management-routing.module';
import { AccountManagementComponent } from './account-management.component';

@NgModule({
  imports: [
    CommonModule,
    AccountManagementRoutingModule
  ],
  declarations: [AccountManagementComponent]
})
export class AccountManagementModule { }
