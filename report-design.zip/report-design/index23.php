<?php

require_once('tcpdf/config/lang/eng.php');
require_once('tcpdf/tcpdf.php');

class MYPDF extends TCPDF {

	//Page header
	public function Header() {
		// Logo

		$header = '';
		$this->writeHTMLCell($w=0, $h=0, $x='', $y='', $header, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
	}

	//Page header
	public function Footer() {
		// Logo

		$footer = '';
		$this->writeHTMLCell($w=0, $h=0, $x='', $y='', $footer, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
	}
}

// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Dr. Kyjuan H Brown');
$pdf->SetTitle('North Shore Medical & Aesthetics Center');
$pdf->SetSubject('Encounter Form');
$pdf->SetKeywords('North Shore Medical & Aesthetics Center');

// set default header data
//$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 061', PDF_HEADER_STRING);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

//set margins
/*$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);*/

//set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

//set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

//set some language-dependent strings
$pdf->setLanguageArray($l);

// ---------------------------------------------------------

// set font
$pdf->SetFont('helvetica', '', 10);

// add a page
$pdf->AddPage();

/* NOTE:
 * *********************************************************
 * You can load external XHTML using :
 *
 * $html = file_get_contents('/path/to/your/file.html');
 *
 * External CSS files will be automatically loaded.    style="border: .75pt dotted #CCC; border-collapse: collapse;  "
 * Sometimes you need to fix the path of the external CSS.
 * *********************************************************
 */
//$html = file_get_contents('inline-report-2.html');
//$html = <<<EOD

$html = $_POST['report'];


//echo $html;
//die();

//EOD;

$pdf->writeHTMLCell($w=0, $h=0, $x='', $y='', $html, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
// add a page
$pdf->AddPage();

$html_terms = '
<table style="float: left; font-family: Arial; height: auto; left: 0pt; top: 0pt; width: 700;">
	<tbody>
	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0">
				<tbody><tr>
					<td scope="row" style="font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt; text-align: left;background-color: #041423; width: 266.5pt;"><img alt="" src="nmac-logo.jpg"></td>
					<td scope="row" style="background-color: #2ca8e1; width: 266.5pt; text-align: right;"><img alt="" src="nmac-addess.jpg"></td>
				</tr>
			</tbody></table>
		</td>
	</tr>

	<tr>
		<td colspan="4"></td>
	</tr>	
	</tbody>
</table>
<table bgcolor="#F8F8F8" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center; font-size: 14pt; font-weight:bold;" align="center" bgcolor="#2ca8e1" valign="middle" height="28">What is Body Mass Index ( BMI )</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="font-weight: 600; font-size:8pt; text-align: center;">Body mass indexÂ&nbsp;(BMI) is a measure of body fat based on your weight in relation to your height, and applies to most adult men and women aged 20 and over.</th>
						</tr>
					</tbody></table>
					</td>
				</tr>
			</tbody></table>
			
			<table bgcolor="#e3f4e2" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color:#fff; text-align:center; font-size:14pt; font-weight:bold;" align="center" bgcolor="#F90303" valign="middle" height="28">Blood Pressure</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="font-weight: 400; font-size:8pt; text-align: center;">Blood pressure is typically recorded as two numbers, written as a ratio like this:</th>
						</tr>
					</tbody></table>
					</td>
				</tr>
			</tbody></table>    
		
			<table bgcolor="#e3f4e2" border="0" cellpadding="0" cellspacing="0" width="667">
				<tbody><tr>
					<th rowspan="2" bgcolor="#E3F4E2" width="136">
					<table border="0" cellpadding="0" cellspacing="0" width="130">
						<tbody>
						<tr>
							<th scope="col" align="center"><img width="106" height="47" src="inline-report3_clip_image001_0002.jpg" alt="117 slash 76 mm Hg"></th>
						</tr>
						</tbody>
					</table>
					<br>
					<span style="text-align: center; font-weight: 600; font-size:8pt;">Read as "117 over 76 millimeters of mercury" </span></th>
					<th rowspan="2" width="15"><p align="center">&nbsp;</p></th>
					<th style="font-weight: 600; font-size:8pt;" align="left" valign="top" width="516" height="30"><p><strong>Systolic</strong><br>
					The top number, which    is also the higher of the two numbers, measures the pressure in the arteries    when the heart beats (when the heart muscle contracts).<br>
					</p></th>
				</tr>
				<tr>
					<th style="font-weight: 600; font-size:8pt;" align="left" valign="top" height="40"><p><strong>Diastolic</strong><br>
					  The bottom number, which is also the lower of the two numbers, measures the pressure in the arteries between heartbeats (when the heart muscle is resting between beats and refilling with blood).</p></th>
				</tr>
			</tbody></table>
		
			<table bgcolor="#F8F8F8" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#F90303" valign="middle" height="28">Cholesterol</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="font-weight: 300; font-size:8pt; text-align:left">
                            <strong>Total Cholesterol - </strong> Your total blood cholesterol is a measure of the cholesterol components LDL (low-density lipoprotein) cholesterol, HDL (high-density lipoprotein) cholesterol, and VLDL (very low-density lipoprotein, which is the triglyceride-carrying component of lipids).<br><br>
                            <strong>LDL -  </strong> (low-density lipoprotein cholesterol, also called "bad" cholesterol), LDL cholesterol can build up in the walls of the arteries and increase your chances of getting heart disease.<br><br>
                            <strong>HDL - </strong>(high-density lipoprotein cholesterol, also called "good" cholesterol) â€“ a higher number means lower risk. This is because HDL cholesterol protects against heart disease by taking the â€œbadâ€ cholesterol out of your blood and keeping it from building up in your arteries.<br><br>
                            <strong>Triglycerides - </strong> (fats carried in the blood from the food we eat. Excess calories, alcohol, or sugar in the body are converted into triglycerides and stored in fat cells throughout the body.)<br></th>
						</tr>
					</tbody></table>
					</td>
				</tr>
			</tbody></table>
		
			<table bgcolor="#e3f4e2" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#B81193" valign="middle" height="28">HbA1c</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="font-weight: 400; font-size:8pt; text-align: left;">
                            Blood pressure is typically recorded as two numbers, written as a ratio like this:
                            <p>The term HbA1c refers to glycated haemoglobin. It develops when haemoglobin, a protein within red blood cells that carries oxygen throughout your body, joins with glucose in the blood, becoming "glycated".</p>
<p>By measuring glycated haemoglobin (HbA1c), clinicians are able to get an overall picture of what our average blood sugar levels have been over a period of weeks/months.</p>
For people with diabetes this is important as the higher the HbA1c, the greater the risk of developing diabetes-related complications. 
                            </th>
						</tr>
					</tbody></table>
					</td>
				</tr>
			</tbody></table>
		
			<table bgcolor="#e3f4e2" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#36AC06" valign="middle" height="28">eGFR</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="font-weight: 400; font-size:8pt; text-align: left;">
                            <strong>eGFR</strong> is short for <strong>estimated glomerular filtration rate</strong>. Your <strong>eGFR</strong> is a number based on your blood test for creatinine, a waste product in your blood. It tells how well your kidneys are working. The <strong>eGFR</strong> is a good test, but it is not right for everyone
                            </th>
						</tr>
					</tbody></table>
					</td>
				</tr>
			</tbody></table>
			<table border="0" cellpadding="0" cellspacing="0" width="700">
				<tbody>
					<tr>
						<th height="50"></th>
					</tr>
				
					<tr>
						<td align="center" valign="middle" height="30"><h2 style="color:#000; font-size: 14pt; margin-bottom: 2pt;">For An appointment : (441)293-5476</h2></td>
					</tr>
				</tbody>
			</table>';
// output the HTML content
//$pdf->writeHTML($html_terms, true, false, true, false, '');
$pdf->writeHTMLCell($w=0, $h=0, $x='', $y='', $html_terms, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// reset pointer to the last page
$pdf->lastPage();

// ---------------------------------------------------------

//Close and output PDF document
//$pdf_file_name = 'custom_header_footer.pdf';
//$pdf->Output($pdf_file_name, 'I');

ob_start();
$pdf->Output('report.pdf', 'I');
ob_end_flush();
//$pdf->Output('report.pdf', 'I');

//============================================================+
// END OF FILE                                                
//============================================================+
