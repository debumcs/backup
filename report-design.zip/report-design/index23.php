<?php

require_once('tcpdf/config/lang/eng.php');
require_once('tcpdf/tcpdf.php');

class MYPDF extends TCPDF {

	//Page header
	public function Header() {
		// Logo

		$header = '';
		$this->writeHTMLCell($w=0, $h=0, $x='', $y='', $header, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
	}

	//Page header
	public function Footer() {
		// Logo

		$footer = '';
		$this->writeHTMLCell($w=0, $h=0, $x='', $y='', $footer, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
	}
}

// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Dr. Kyjuan H Brown');
$pdf->SetTitle('North Shore Medical & Aesthetics Center');
$pdf->SetSubject('Encounter Form');
$pdf->SetKeywords('North Shore Medical & Aesthetics Center');

// set default header data
//$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 061', PDF_HEADER_STRING);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

//set margins
/*$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);*/

//set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

//set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

//set some language-dependent strings
$pdf->setLanguageArray($l);

// ---------------------------------------------------------

// set font
$pdf->SetFont('helvetica', '', 10);

// add a page
$pdf->AddPage('L','Letter');

/* NOTE:
 * *********************************************************
 * You can load external XHTML using :
 *
 * $html = file_get_contents('/path/to/your/file.html');
 *
 * External CSS files will be automatically loaded.    style="border: .75pt dotted #CCC; border-collapse: collapse;  "
 * Sometimes you need to fix the path of the external CSS.
 * *********************************************************
 */
//$html = file_get_contents('inline-report-2.html');
//$html = <<<EOD

//$html = $_POST['report'];


//echo $html;
//die();

//EOD;

//$pdf->writeHTMLCell($w=0, $h=0, $x='', $y='', $html, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
// add a page
//$pdf->AddPage();

$html_terms = <<<EOF
<!-- EXAMPLE OF CSS STYLE -->
<style>
	table.first {
		color: #0030;
		font-family: helvetica;
		font-size: 9pt;
		border: 2pt solid #8d8d8d;
		width:100%;
	}
	td.parent{
		border: 1px solid #7b9899;
	}
	
	.innerbody{
		border: 12pt solid #c5d1d7;
		border-top: 0pt;
		padding: 10pt;
	}
	td.taxinvoicetext{
		font-weight: bold;
		line-height: 30pt;
		font-size: 11pt;
		border-bottom: 2pt solid #8d8d8d;
		padding: 5pt;
	}
	td.farmnametext{
		line-height: 15pt;
		font-size: 9pt;
		font-style: italic;
		font-weight: bold;
		border-bottom: 2pt solid #8d8d8d;
		padding: 5pt;
	}
	td.second {
		border-bottom: 2pt solid #8d8d8d;
		padding: 5pt;
	}
	td.secondright{
		border-bottom: 2pt solid #8d8d8d;
		padding-left: 54pt;
	}
	td.third {
		border-top: 2pt solid #8d8d8d;
		border-right: 2pt solid #8d8d8d;
		border-bottom: 2pt solid #8d8d8d;
		padding: 5pt;
		line-height: 14pt;
	}
	td.fourth {
		border-top: 2pt solid #8d8d8d;
		border-left: 2pt solid #8d8d8d;
		border-bottom: 2pt solid #8d8d8d;
		padding: 5pt;
		line-height: 14pt;
	}

</style>
<table style="float: left; font-family: Arial; height: auto; left: 0pt; top: 0pt; width:621pt;">
	<tr>
		<td class="parent">
			<table cellpadding="0" cellspacing="0" border-collapse="collapse">
				<tbody>
					<tr bgcolor="#c5d1d7">
						<td style="width: 621pt;"><img alt="" src="header4.png"></td>				
					</tr>
					<tr >
						<td class="innerbody" valign="top">
							<table class="first" cellpadding="0" cellspacing="0">
							<tr>
								<td width="" class="second">GSTN No.</td>
								<td width="" class="second">&nbsp;</td>
								<td width="" class="secondright">Mobile No.</td>
							</tr>
							<tr>
								<td width="" class="second">&nbsp;</td>
								<td width="" class="second">&nbsp;</td>
								<td width="" class="secondright">e-mail id</td>
							</tr>
							<tr>
								<td width="" colspan="3" align="center" class="taxinvoicetext">TAX INVOICE</td>
							</tr>
							<tr>
								<td width="" colspan="3" align="center" class="farmnametext">Name of the Firm<br />Address of the Firm<br />Main Products in which dealing</td>
							</tr>
							<tr>
								<td width="" class="second">Date of Invoice</td>
								<td width="40" class="second">&nbsp;</td>
								<td width="" class="secondright">Serial No. of Invoice</td>
							</tr>
							<tr>
								<td width="" colspan="3">&nbsp;</td>
							</tr>
							<tr>
								<td width="" class="third">Details of Receiver(Billed to)<br />Name<br />Address<br />State<br />State Code<br />Mobile No. & E-Mail ID<br />GSTIN/Unique ID</td>
								<td width="">&nbsp;</td>
								<td width="" class="fourth">Details of Consignee (Shipped to )<br />Name<br />Address<br />State<br />State Code<br />Mobile No. & E-Mail ID<br />GSTIN/Unique ID</td>
							</tr>
							<tr>
								<td width="" colspan="3">&nbsp;</td>
							</tr>
							</table>
						</td>
					</tr>
				</tbody>
			</table>
		</td>
	</tr>
</table>
EOF;
// output the HTML content
//$pdf->writeHTML($html_terms, true, false, true, false, '');
$pdf->writeHTMLCell($w=0, $h=0, $x='', $y='', $html_terms, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// reset pointer to the last page
$pdf->lastPage();

// ---------------------------------------------------------

//Close and output PDF document
//$pdf_file_name = 'custom_header_footer.pdf';
//$pdf->Output($pdf_file_name, 'I');

ob_start();
$pdf->Output('report.pdf', 'I');
ob_end_flush();
//$pdf->Output('report.pdf', 'I');

//============================================================+
// END OF FILE                                                
//============================================================+
