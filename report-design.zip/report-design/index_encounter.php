<?php

require_once('tcpdf/config/lang/eng.php');
require_once('tcpdf/tcpdf.php');

class MYPDF extends TCPDF {

	//Page header
	public function Header() {
		// Logo

		$header = '';
		$this->writeHTMLCell($w=0, $h=0, $x='', $y='', $header, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
	}

	//Page header
	public function Footer() {
		// Logo

		$footer = '';
		$this->writeHTMLCell($w=0, $h=0, $x='', $y='', $footer, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
	}
}

// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Nicola Asuni');
$pdf->SetTitle('TCPDF Example 061');
$pdf->SetSubject('TCPDF Tutorial');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set default header data
//$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 061', PDF_HEADER_STRING);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

//set margins
/*$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);*/

//set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

//set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

//set some language-dependent strings
$pdf->setLanguageArray($l);

// ---------------------------------------------------------

// set font
$pdf->SetFont('helvetica', '', 10);

// add a page
$pdf->AddPage();

/* NOTE:
 * *********************************************************
 * You can load external XHTML using :
 *
 * $html = file_get_contents('/path/to/your/file.html');
 *
 * External CSS files will be automatically loaded.    style="border: .75pt dotted #CCC; border-collapse: collapse;  "
 * Sometimes you need to fix the path of the external CSS.
 * *********************************************************
 */
//$html = file_get_contents('inline-report-2.html');
//$html = <<<EOD

$html = $_POST['report'];


//echo $html;
//die();

//EOD;

$pdf->writeHTMLCell($w=0, $h=0, $x='', $y='', $html, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);

// add a page
$pdf->AddPage();
$html2 = $_POST['report2'];
$pdf->writeHTMLCell($w=0, $h=0, $x='', $y='', $html2, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);

$pdf->lastPage();

// ---------------------------------------------------------

//Close and output PDF document
//$pdf_file_name = 'custom_header_footer.pdf';
//$pdf->Output($pdf_file_name, 'I');

ob_start();
$pdf->Output('report_encounter.pdf', 'D');
ob_end_flush();
//$pdf->Output('report.pdf', 'I');

//============================================================+
// END OF FILE                                                
//============================================================+
