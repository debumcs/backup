<?php
//============================================================+
// File name   : example_061.php
// Begin       : 2010-05-24
// Last Update : 2010-08-08
//
// Description : Example 061 for TCPDF class
//               XHTML + CSS
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               Manor Coach House, Church Hill
//               Aldershot, Hants, GU12 4RQ
//               UK
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

/**
 * Creates an example PDF TEST document using TCPDF
 * @package com.tecnick.tcpdf
 * @abstract TCPDF - Example: XHTML + CSS
 * @author Nicola Asuni
 * @since 2010-05-25
 */

require_once('tcpdf/config/lang/eng.php');
require_once('tcpdf/tcpdf.php');

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Nicola Asuni');
$pdf->SetTitle('TCPDF Example 061');
$pdf->SetSubject('TCPDF Tutorial');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 061', PDF_HEADER_STRING);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

//set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

//set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

//set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

//set some language-dependent strings
$pdf->setLanguageArray($l);

// ---------------------------------------------------------

// set font
$pdf->SetFont('helvetica', '', 10);

// add a page
$pdf->AddPage();

/* NOTE:
 * *********************************************************
 * You can load external XHTML using :
 *
 * $html = file_get_contents('/path/to/your/file.html');
 *
 * External CSS files will be automatically loaded.
 * Sometimes you need to fix the path of the external CSS.
 * *********************************************************
 */
$html = <<<EOF
<!-- EXAMPLE OF CSS STYLE -->
<style>
	h1 {
		color: navy;
		font-family: times;
		font-size: 24pt;
		text-decoration: underline;
	}
	p.first {
		color: #003300;
		font-family: helvetica;
		font-size: 12pt;
	}
	p.first span {
		color: #006600;
		font-style: italic;
	}
	p#second {
		color: rgb(00,63,127);
		font-family: times;
		font-size: 12pt;
		text-align: justify;
	}
	p#second > span {
		background-color: #FFFFAA;
	}
	table.first {
		color: #003300;
		font-family: helvetica;
		font-size: 8pt;
		border-left: 3px solid red;
		border-right: 3px solid #FF00FF;
		border-top: 3px solid green;
		border-bottom: 3px solid blue;
		background-color: #ccffcc;
	}
	td {
		border: 2px solid blue;
		background-color: #ffffee;
	}
	td.second {
		border: 2px dashed green;
	}
	div.test {
		color: #CC0000;
		background-color: #FFFF66;
		font-family: helvetica;
		font-size: 10pt;
		border-style: solid solid solid solid;
		border-width: 2px 2px 2px 2px;
		border-color: green #FF00FF blue red;
		text-align: center;
	}
</style>

<h1 class="title">Example of <i style="color:#990000">XHTML + CSS</i></h1>

<p class="first">Example of paragraph with class selector. <span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sed imperdiet lectus. Phasellus quis velit velit, non condimentum quam. Sed neque urna, ultrices ac volutpat vel, laoreet vitae augue. Sed vel velit erat. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Cras eget velit nulla, eu sagittis elit. Nunc ac arcu est, in lobortis tellus. Praesent condimentum rhoncus sodales. In hac habitasse platea dictumst. Proin porta eros pharetra enim tincidunt dignissim nec vel dolor. Cras sapien elit, ornare ac dignissim eu, ultricies ac eros. Maecenas augue magna, ultrices a congue in, mollis eu nulla. Nunc venenatis massa at est eleifend faucibus. Vivamus sed risus lectus, nec interdum nunc.</span></p>

<p id="second">Example of paragraph with ID selector. <span>Fusce et felis vitae diam lobortis sollicitudin. Aenean tincidunt accumsan nisi, id vehicula quam laoreet elementum. Phasellus egestas interdum erat, et viverra ipsum ultricies ac. Praesent sagittis augue at augue volutpat eleifend. Cras nec orci neque. Mauris bibendum posuere blandit. Donec feugiat mollis dui sit amet pellentesque. Sed a enim justo. Donec tincidunt, nisl eget elementum aliquam, odio ipsum ultrices quam, eu porttitor ligula urna at lorem. Donec varius, eros et convallis laoreet, ligula tellus consequat felis, ut ornare metus tellus sodales velit. Duis sed diam ante. Ut rutrum malesuada massa, vitae consectetur ipsum rhoncus sed. Suspendisse potenti. Pellentesque a congue massa.</span></p>

<div class="test">example of DIV with border and fill.<br />Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sed imperdiet lectus.</div>

<br />

<table class="first" cellpadding="4" cellspacing="6">
 <tr>
  <td width="30" align="center"><b>No.</b></td>
  <td width="140" align="center" bgcolor="#FFFF00"><b>XXXX</b></td>
  <td width="140" align="center"><b>XXXX</b></td>
  <td width="80" align="center"> <b>XXXX</b></td>
  <td width="80" align="center"><b>XXXX</b></td>
  <td width="45" align="center"><b>XXXX</b></td>
 </tr>
 <tr>
  <td width="30" align="center">1.</td>
  <td width="140" rowspan="6" class="second">XXXX<br />XXXX<br />XXXX<br />XXXX<br />XXXX<br />XXXX<br />XXXX<br />XXXX</td>
  <td width="140">XXXX<br />XXXX</td>
  <td width="80">XXXX<br />XXXX</td>
  <td width="80">XXXX</td>
  <td align="center" width="45">XXXX<br />XXXX</td>
 </tr>
 <tr>
  <td width="30" align="center" rowspan="3">2.</td>
  <td width="140" rowspan="3">XXXX<br />XXXX</td>
  <td width="80">XXXX<br />XXXX</td>
  <td width="80">XXXX<br />XXXX</td>
  <td align="center" width="45">XXXX<br />XXXX</td>
 </tr>
 <tr>
  <td width="80">XXXX<br />XXXX<br />XXXX<br />XXXX</td>
  <td width="80">XXXX<br />XXXX</td>
  <td align="center" width="45">XXXX<br />XXXX</td>
 </tr>
 <tr>
  <td width="80" rowspan="2" >XXXX<br />XXXX<br />XXXX<br />XXXX<br />XXXX<br />XXXX<br />XXXX<br />XXXX</td>
  <td width="80">XXXX<br />XXXX</td>
  <td align="center" width="45">XXXX<br />XXXX</td>
 </tr>
 <tr>
  <td width="30" align="center">3.</td>
  <td width="140">XXXX<br />XXXX</td>
  <td width="80">XXXX<br />XXXX</td>
  <td align="center" width="45">XXXX<br />XXXX</td>
 </tr>
 <tr bgcolor="#FFFF80">
  <td width="30" align="center">4.</td>
  <td width="140" bgcolor="#00CC00" color="#FFFF00">XXXX<br />XXXX</td>
  <td width="80">XXXX<br />XXXX</td>
  <td width="80">XXXX<br />XXXX</td>
  <td align="center" width="45">XXXX<br />XXXX</td>
 </tr>
</table>
EOF;
// define some HTML content with style
$html2 = <<<EOF
<table style="float: left; font-family: Arial; height: auto; left: 0pt; top: 0pt; width: 700;">
	<tbody><tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0">
				<tbody><tr>
					<td scope="row" style="font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt; text-align: left;background-color: #041423; width: 266.5pt;"><img alt="" src="nmac-logo.jpg"></td>
					<td scope="row" style="background-color: #2ca8e1; width: 266.5pt; text-align: right;"><img alt="" src="nmac-addess.jpg"></td>
				</tr>
			</tbody></table>
		</td>
	</tr>

	<tr>
		<td colspan="4"></td>
	</tr>	

	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0" width="666">
				<tbody><tr>
					<td align="center" valign="middle" height="30"><h2 style="color: #000; font-size: 14pt; margin-bottom: 1.75pt;">PATIENT INFORMATION</h2></td>
				</tr>

				<tr>
					<td width="200">
						<table border="0" cellpadding="0" cellspacing="0" width="100%">
							<tbody><tr>
								<td style="font-family: Arial; font-size: 7.5pt; letter-spacing: 0.75pt; text-align: center;" height="147"><img alt="" src="../img/default.png" width="128" height="129"></td>
							</tr>

							<tr>
								<td style=" style=" font-family:="" arial;="" font-size:="" 7.5pt;="" letter-spacing:="" 0.75pt;="" line-height:="" 10pt;="" text-align:="" left;""="" height="80">
								<span align="center" style="margin: 0px; padding: 0px; font-size: 10.5pt; font-weight: 600; left: 0pt; right: 0pt;">test-2016-03-25-1</span><br>
								<span align="center" style="margin: 0px;	padding: 0px; font-size: 8pt; font-weight: 300; left: 0pt; right: 0pt;">Age 51</span><br>
								<span align="center" style="margin: 0px;	padding: 0px; font-size: 8pt; font-weight: 300; left: 0pt; right: 0pt;"> D.O.B : 1965-02-15</span>
								</td>
							</tr>
						</tbody></table>					
					</td>

					<td valign="top" width="500">
						<table border="0" cellpadding="0" cellspacing="0" width="700">
							<tbody><tr>
								<td scope="col" style="font-size: 8pt; font-weight:300; font-family: Arial;" align="left" valign="top" width="240" height="15">
									<h3 style="margin: 0px;	padding: 0px;">Calculation on First Visit</h3>
							    </td>

                                <td style="font-size: 8pt; font-weight:300; font-family: Arial;" scope="col" align="left" valign="top" width="240">
									<h3 style="margin: 0px;	padding: 0px;">Reported By</h3>
								</td>
							</tr>

							<tr>
								<td scope="col" style="font-size: 7.5pt; font-weight:300; font-family: Arial;" align="left" valign="top">Weight : 200<br>Height : 5.8<br>Race : American<br>Health Status : Diabetes</td>
								<td style="font-size: 7.5pt; font-weight:300; font-family: Arial;" scope="col" align="left" valign="top" width="240">Date of Admission : 2015-01-01<br>Reported By : test-2016-03-25-1<br>Received on " 2016-05-07</td>
							</tr>

							<tr>
								<th scope="col" height="12"></th>
							</tr>                            

							<tr>
								<td scope="col" style="font-size: 8pt; font-weight:300; font-family: Arial;" align="left" valign="top" width="240" height="15">
								<h3 style="margin: 0px;	padding: 0px;">Location</h3></td>
								<td scope="col" style="font-size: 8pt; font-weight:300; font-family: Arial;" align="left" valign="top" width="240" height="15">
								<h3 style="margin: 0px;	padding: 0px;">Contact Details</h3>
								</td>
                            </tr>

							<tr>
								<td style="font-size: 7.5pt; font-weight:300; font-family: Arial;" scope="col" align="left" valign="top" width="240">testaddress</td>
								<td style="font-size: 7.5pt; font-weight:300; font-family: Arial;" scope="col" align="left" valign="top" width="240">Phone No. : 1234567890<br>Email Id : test@test.com</td>
							</tr>

							<tr>
								<th scope="col" height="12"></th>
							</tr>

							<tr>
								<td colspan="2" scope="col" style="font-size: 8pt; font-weight:300; font-family: Arial;" align="left" valign="top">
									<h3 style="margin: 0px;	padding: 0px;">Medical History</h3>
									test
								</td>
							</tr>
						</tbody></table>
					</td>
				</tr>
			</tbody></table>		
		</td>
	</tr>

	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0" width="666">
				<tbody><tr>
					<th height="22"><h2 style="color: #000; font-size: 15pt; margin-bottom: 3.75pt; text-align: center; vertical-align:middle">SCORE CARD KEY</h2></th>
				</tr>

				<tr>
					<td colspan="4"></td>
				</tr>

				<tr>
					<td style="font-size:7.5pt" align="center" width="174"><img src="img/zone.jpg" width="25" height="25"><p style="color: black; text-align: center;">You are at risk extreem danger of developing major health problems! ( Seek Urgent Medical Attention )</p></td>
					<td style="font-size:7.5pt" align="center" width="174"><img src="img/red.png" width="25" height="25"><p style="color: black; text-align: center;">You are at risk of having major health problems!</p></td>
					<td style="font-size:7.5pt" align="center" width="174"><img src="img/yellow.png" width="25" height="25"><p style="color: black; text-align: center;">You are at moderate risk of having major health problems!</p></td>
					<td style="font-size:7.5pt" align="center" width="174"><img src="img/green.png" width="25" height="25"><p style="color: black; text-align: center;">Excellant Result</p></td>
				</tr>
			</tbody></table>		
		</td>
	</tr>

    <tr>
		<td colspan="4"></td>
	</tr>

    <tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color:#000; text-align:center; font-size: 15pt; font-weight:bold;" align="center" valign="middle">BODY COMPOSITION</th>
				</tr>
			</tbody></table>
		</td>
    </tr>

	<tr>
		<td>
			<table bgcolor="#F8F8F8" border="0" cellpadding="5" cellspacing="0" width="667">
                <tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#2ca8e1" valign="middle" height="28">BMI</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><p style="color: black; "><span style="color: orange;">Underweight (&lt; 18.5)</span> | <span style="color: #56BB4D;">Normal (18.5 â€“ 24.9)</span> | <span style="color: #ef705b;">Overweight (25 â€“ 29.9)</span> | <span style="color: #FF0000;">Obese (&gt; 30)</span></p></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="526">Comments</th>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-02-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">12<br><img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">now entered value</td>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-01-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">23<br><img src="img/small-green.png" alt="Excellent Result" width="20" height="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">bmi test descriptio</td>
						</tr></tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>

	<tr>
		<td>
			<table bgcolor="#F8F8F8" border="0" cellpadding="5" cellspacing="0" width="667">
                <tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#2ca8e1" valign="middle" height="28">Body Fat</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="526">Comments</th>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-02-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">465</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">Body Fat</td>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-01-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">401</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">401 Comments</td>
						</tr></tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>

	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0" width="667">
                <tbody><tr>
					<th style="color:#000; text-align:center; font-size: 15pt; font-weight:bold;" align="center" valign="middle">HEART DISEASE</th>
				</tr>
			</tbody></table>
		</td>
    </tr>

	<tr>
		<td>
			<table bgcolor="#F8F8F8" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#F90303" valign="middle" height="28">BLOOD PRESSURE</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><span style="color: #56BB4D;">Normal (&lt;129)</span> | <span style="color: orange;">Borderline (130-139) </span> | <span style="color: #ef705b;">Hypertension 1 (140-159)</span> | <span style="color: #FF0000;">Hypertension 2 (&gt;160)</span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="526">Comments</th>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-02-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">136/87<br><img src="img/small-green.png" alt="Excellent Result" width="20" height="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">120/90desc</td>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-01-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">124/78<br><img src="img/small-green.png" alt="Excellent Result" width="20" height="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">Excellent Result</td>
						</tr>	</tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>

	<tr>
		<td>
			<table bgcolor="#F8F8F8" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#F90303" valign="middle" height="28">TOTAL CHOLESTEROL</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><span style="color: #56BB4D;">Desirable (&lt;200) </span> | <span style="color: orange;">Borderline (200 â€“ 239)</span> | <span style="color: #ef705b;">High (&gt;=240)</span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="526">Comments</th>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-02-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">430<br><img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">89</td>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-01-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">230<br><img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">You are at moderate ris</td>
						</tr></tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>

	<tr>
		<td>
			<table bgcolor="#F8F8F8" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#F90303" valign="middle" height="28">HDL</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><span style="color: #56BB4D;">Normal (&gt;=50) </span> | <span style="color: #F00;">Low (&lt; 50)</span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="526">Comments</th>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-02-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">345<br><img src="img/small-green.png" alt="Excellent Result" width="20" height="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">89</td>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-01-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">45<br><img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">You are at high risk of</td>
						</tr></tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table bgcolor="#F8F8F8" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#F90303" valign="middle" height="28">LDL</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><span style="color: #56BB4D;">Optimal (&lt;100) </span> | <span style="color: #40de32;">Near Optimal (100-129) </span> | <span style="color: orange;">Borderline (130 â€“ 159) </span> | <span style="color: #ef705b;">High (200 â€“ 499) </span> | <span style="color: #FF0000;">Very High (&gt;=500)</span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="526">Comments</th>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-02-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">5.6<br><img src="img/small-green.png" alt="Excellent Result" width="20" height="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">89</td>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-01-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">489<br><img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">You are at high risk of</td>
						</tr></tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table bgcolor="#F8F8F8" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#F90303" valign="middle" height="28">TRIGLYCERIDES</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><span style="color: #56BB4D;">Optimal (&lt;150) </span> | <span style="color: orange;">Borderline (150 â€“ 199) </span> | <span style="color: #ef705b;">High (200 â€“ 499)</span> | <span style="color: #FF0000;">Very High (&gt;=500)</span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="526">Comments</th>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-02-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">89<br><img src="img/small-green.png" alt="Excellent Result" width="20" height="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">now entered value</td>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-01-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">189<br><img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">You are at moderate ris</td>
						</tr></tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>

	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0" width="667">
                <tbody><tr>
					<th style="color:#000; text-align:center; font-size: 15pt; font-weight:bold;" align="center" valign="middle">DIABETES</th>
				</tr>
			</tbody></table>
		</td>
    </tr>

	<tr>
		<td>
			<table bgcolor="#F8F8F8" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#B81193" valign="middle" height="28">HBa1c</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;">  <span style="color: #56BB4D;">Normal (&lt; 5.6) </span> | <span style="color: orange;">Prediabetes (5.7 ¯ 6.4)</span> | <span style="color: #F00;">Diabetes (&gt;= 6.5) </span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="526">Comments</th>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-02-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">23<br><img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">now entered value</td>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-01-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">7<br><img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">You are at high risk of</td>
						</tr></tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>

	<tr>
		<td>
			<table bgcolor="#F8F8F8" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#B81193" valign="middle" height="28">FASTING BLOOD SUGAR</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;">Fasting : <span style="color: #56BB4D;">Normal (&lt; 100) </span> | <span style="color: orange;">Prediabetes (100 â€“ 125)</span> | <span style="color: #F00;">Diabetes (&gt;= 126) </span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="526">Comments</th>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-02-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">123<br><img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">89</td>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-01-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">140<br><img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">You are at high risk of having major health problems!</td>
						</tr></tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>

	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0" width="667">
                <tbody><tr>
					<th style="color:#000; text-align:center; font-size: 15pt; font-weight:bold;" align="center" valign="middle">KIDNEY DISEASE</th>
				</tr>
			</tbody></table>
		</td>
    </tr>

	<tr>
		<td>
			<table bgcolor="#F8F8F8" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#36AC06" valign="middle" height="28">eGRF</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><span style="color: #56BB4D;">Normal (60 to 120) </span> | <span style="color: orange;">16 to 59</span> |  <span style="color: #F00;">Danger (0 to 15) </span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="526">Comments</th>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-02-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">25<br><img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">now entered value</td>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-01-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">23<br><img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">You are at moderate ris</td>
						</tr></tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>

	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0" width="667">
                <tbody><tr>
					<th style="color:#000; text-align:center; font-size: 15pt; font-weight:bold;" align="center" valign="middle">OTHERS</th>
				</tr>
			</tbody></table>
		</td>
    </tr>
	
	<tr>
		<td>
			<table bgcolor="#F8F8F8" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#36AC06" valign="middle" height="28">Gas Score</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="526">Comments</th>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-02-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">325</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">now entered value</td>
						</tr><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-01-01</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">301</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">301 Comments</td>
						</tr></tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table bgcolor="#F8F8F8" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#36AC06" valign="middle" height="28">PHQ</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="526">Comments</th>
						</tr><tr>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-02-01</th>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">434</th>
								<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">PHQ</td>
							</tr><tr>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-01-01</th>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">201</th>
								<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">201 Comment</td>
							</tr></tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>

	<tr>
		<td>
			<table bgcolor="#F8F8F8" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#36AC06" valign="middle" height="28">Metabolic Age</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="526">Comments</th>
						</tr><tr>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-02-01</th>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">89</th>
								<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">Metabolic Age</td>
							</tr><tr>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-01-01</th>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">101</th>
								<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">101 Coment</td>
							</tr></tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>

	<tr>
		<td>
			<table bgcolor="#F8F8F8" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#36AC06" valign="middle" height="28">Others Details</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Smoking Cessation</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">From</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">To</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">ER Visit</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="321">Asthma/ COPD Action Plan</th>
						</tr><tr>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-02-01</th>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Yes</th>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2011-09-12</th>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2013-09-12</th>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Yes</th>
								<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="321">Asthma/ COPD Action Plan 2</td>
							</tr><tr>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2015-01-01</th>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Yes</th>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2011-01-01</th>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2011-06-01</th>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">No</th>
								<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="321">Asthma/ COPD Action Plan</td>
							</tr></tbody></table>
					</td></tr></tbody></table>
					</td>
				</tr>
			</tbody></table>
		
	

	
		&nbsp;
	

	
		
			<table border="0" cellpadding="0" cellspacing="0" width="700">
				<tbody>
					<tr>
						<td align="center" valign="middle" height="30"><h2 style="color:#000; font-size: 14pt; margin-bottom: 2pt;">For An appointment : (441)293-5476</h2></td>
					</tr>
				</tbody>
			</table>
		
	

		
		
	

	
		
			<table bgcolor="#F8F8F8" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center; font-size: 14pt; font-weight:bold;" align="center" bgcolor="#2ca8e1" valign="middle" height="28">What is Body Mass Index ( BMI )</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="font-weight: 600; font-size:8pt; text-align: center;">Body mass indexÂ&nbsp;(BMI) is a measure of body fat based on your weight in relation to your height, and applies to most adult men and women aged 20 and over.</th>
						</tr>
					</tbody></table>
					</td>
				</tr>
			</tbody></table>
		
	

    
		
			<table bgcolor="#e3f4e2" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#F90303" valign="middle" height="28">Blood Pressure</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="font-weight: 400; font-size:8pt; text-align: center;">Blood pressure is typically recorded as two numbers, written as a ratio like this:</th>
						</tr>
					</tbody></table>
					</td>
				</tr>
			</tbody></table>
		
	

    
		
			<table bgcolor="#e3f4e2" border="0" cellpadding="0" cellspacing="0" width="667">
				<tbody><tr>
					<th rowspan="2" bgcolor="#E3F4E2" width="136">
					<table border="0" cellpadding="0" cellspacing="0" width="130">
						<tbody>
						<tr>
							<th scope="col" align="center"><img src="inline-report3_clip_image001_0002.jpg" alt="117 slash 76 mm Hg" width="106" height="47"></th>
						</tr>
						</tbody>
					</table>
					<br>
					<span style="text-align: center; font-weight: 600; font-size:8pt;">Read as "117 over 76 millimeters of mercury" </span></th>
					<th rowspan="2" width="15"><p align="center">&nbsp;</p></th>
					<th style="font-weight: 600; font-size:8pt;" align="left" valign="top" width="516" height="30"><p><strong>Systolic</strong><br>
					The top number, which    is also the higher of the two numbers, measures the pressure in the arteries    when the heart beats (when the heart muscle contracts).<br>
					</p></th>
				</tr>
				<tr>
					<th style="font-weight: 600; font-size:8pt;" align="left" valign="top" height="40"><p><strong>Diastolic</strong><br>
					  The bottom number, which is also the lower of the two numbers, measures the pressure in the arteries between heartbeats (when the heart muscle is resting between beats and refilling with blood).</p></th>
				</tr>
			</tbody></table>
		
	

	
		
			<table bgcolor="#F8F8F8" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#F90303" valign="middle" height="28">Cholesterol</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="font-weight: 300; font-size:8pt; text-align:left">
                            <strong>Total Cholesterol - </strong> Your total blood cholesterol is a measure of the cholesterol components LDL (low-density lipoprotein) cholesterol, HDL (high-density lipoprotein) cholesterol, and VLDL (very low-density lipoprotein, which is the triglyceride-carrying component of lipids).<br><br>
                            <strong>LDL -  </strong> (low-density lipoprotein cholesterol, also called "bad" cholesterol), LDL cholesterol can build up in the walls of the arteries and increase your chances of getting heart disease.<br><br>
                            <strong>HDL - </strong>(high-density lipoprotein cholesterol, also called "good" cholesterol) â€“ a higher number means lower risk. This is because HDL cholesterol protects against heart disease by taking the â€œbadâ€ cholesterol out of your blood and keeping it from building up in your arteries.<br><br>
                            <strong>Triglycerides - </strong> (fats carried in the blood from the food we eat. Excess calories, alcohol, or sugar in the body are converted into triglycerides and stored in fat cells throughout the body.)<br></th>
						</tr>
					</tbody></table>
					</td>
				</tr>
			</tbody></table>
		
	

    
		
			<table bgcolor="#e3f4e2" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#B81193" valign="middle" height="28">HbA1c</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="font-weight: 400; font-size:8pt; text-align: left;">
                            Blood pressure is typically recorded as two numbers, written as a ratio like this:
                            <p>The term HbA1c refers to glycated haemoglobin. It develops when haemoglobin, a protein within red blood cells that carries oxygen throughout your body, joins with glucose in the blood, becoming "glycated".</p>
<p>By measuring glycated haemoglobin (HbA1c), clinicians are able to get an overall picture of what our average blood sugar levels have been over a period of weeks/months.</p>
For people with diabetes this is important as the higher the HbA1c, the greater the risk of developing diabetes-related complications. 
                            </th>
						</tr>
					</tbody></table>
					</td>
				</tr>
			</tbody></table>
		
	

	
		
			<table bgcolor="#e3f4e2" border="0" cellpadding="5" cellspacing="0" width="667">
				<tbody><tr>
					<th style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;" align="center" bgcolor="#36AC06" valign="middle" height="28">eGFR</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="font-weight: 400; font-size:8pt; text-align: left;">
                            <strong>eGFR</strong> is short for <strong>estimated glomerular filtration rate</strong>. Your <strong>eGFR</strong> is a number based on your blood test for creatinine, a waste product in your blood. It tells how well your kidneys are working. The <strong>eGFR</strong> is a good test, but it is not right for everyone
                            </th>
						</tr>
					</tbody></table>
					</td>
				</tr>
			</tbody></table>
EOF;

// output the HTML content
$pdf->writeHTML($html2, true, false, true, false, '');

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// *******************************************************************
// HTML TIPS & TRICKS
// *******************************************************************

// REMOVE CELL PADDING
//
// $pdf->SetCellPadding(0);
// 
// This is used to remove any additional vertical space inside a 
// single cell of text.

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// REMOVE TAG TOP AND BOTTOM MARGINS
//
// $tagvs = array('p' => array(0 => array('h' => 0, 'n' => 0), 1 => array('h' => 0, 'n' => 0)));
// $pdf->setHtmlVSpace($tagvs);
// 
// Since the CSS margin command is not yet implemented on TCPDF, you
// need to set the spacing of block tags using the following method.

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// SET LINE HEIGHT
//
// $pdf->setCellHeightRatio(1.25);
// 
// You can use the following method to fine tune the line height
// (the number is a percentage relative to font height).

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// CHANGE THE PIXEL CONVERSION RATIO
//
// $pdf->setImageScale(0.47);
// 
// This is used to adjust the conversion ratio between pixels and 
// document units. Increase the value to get smaller objects.
// Since you are using pixel unit, this method is important to set the
// right zoom factor.
// 
// Suppose that you want to print a web page larger 1024 pixels to 
// fill all the available page width.
// An A4 page is larger 210mm equivalent to 8.268 inches, if you 
// subtract 13mm (0.512") of margins for each side, the remaining 
// space is 184mm (7.244 inches).
// The default resolution for a PDF document is 300 DPI (dots per 
// inch), so you have 7.244 * 300 = 2173.2 dots (this is the maximum 
// number of points you can print at 300 DPI for the given width).
// The conversion ratio is approximatively 1024 / 2173.2 = 0.47 px/dots
// If the web page is larger 1280 pixels, on the same A4 page the 
// conversion ratio to use is 1280 / 2173.2 = 0.59 pixels/dots

// *******************************************************************

// reset pointer to the last page
$pdf->lastPage();

// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output('example_061.pdf', 'I');

//============================================================+
// END OF FILE                                                
//============================================================+
