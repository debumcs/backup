<?php
//============================================================+
// File name   : example_061.php
// Begin       : 2010-05-24
// Last Update : 2010-08-08
//
// Description : Example 061 for TCPDF class
//               XHTML + CSS
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               Manor Coach House, Church Hill
//               Aldershot, Hants, GU12 4RQ
//               UK
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

/**
 * Creates an example PDF TEST document using TCPDF
 * @package com.tecnick.tcpdf
 * @abstract TCPDF - Example: XHTML + CSS
 * @author Nicola Asuni
 * @since 2010-05-25
 */

require_once('tcpdf/config/lang/eng.php');
require_once('tcpdf/tcpdf.php');

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Nicola Asuni');
$pdf->SetTitle('TCPDF Example 061');
$pdf->SetSubject('TCPDF Tutorial');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 061', PDF_HEADER_STRING);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

//set margins
//$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

//set auto page breaks
//$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

//set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

//set some language-dependent strings
$pdf->setLanguageArray($l);

// ---------------------------------------------------------

// set font
$pdf->SetFont('helvetica', '', 10);
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);
// add a page
$pdf->AddPage('L','Letter');

/* NOTE:
 * *********************************************************
 * You can load external XHTML using :
 *
 * $html = file_get_contents('/path/to/your/file.html');
 *
 * External CSS files will be automatically loaded.
 * Sometimes you need to fix the path of the external CSS.
 * *********************************************************
 */

// define some HTML content with style
$html = <<<EOF
<!-- EXAMPLE OF CSS STYLE -->
<style>
td.parent{
	border: 1px solid #7b9899;
}
table.first {
	font-size: 8pt;
	border: 1pt solid #8d8d8d;
	width:100%;
}
.innerbody{
background-color: #c5d1d7;
}
td.taxinvoicetext{
	font-weight: bold;
	line-height: 1pt;
	font-size: 9pt;
	border-bottom: 1pt solid #8d8d8d;
}
td.farmnametext{
	font-style: italic;
	border-bottom: 1pt solid #8d8d8d;
}
td.second {
	border-bottom: 1pt solid #8d8d8d;
}
td.third {
	border-top: 1pt solid #8d8d8d;
	border-right: 1pt solid #8d8d8d;
	border-bottom: 1pt solid #8d8d8d;
	line-height: 1pt;
}
td.fourth {
	border-top: 1pt solid #8d8d8d;
	border-left: 1pt solid #8d8d8d;
	border-bottom: 1pt solid #8d8d8d;
	line-height: 1pt;
}
td.fifth{
	border-bottom: 1pt solid #8d8d8d;
	border-right: 1pt solid #8d8d8d;
	text-align:center;
}
td.sixth{
	border-right: 1pt solid #8d8d8d;
}
td.seventh{
	border-right: 0pt solid #8d8d8d;
	border-top: 1pt solid #8d8d8d;
	border-bottom: 1pt solid #8d8d8d;
}

</style>

<table cellpadding="0" cellspacing="0" border-collapse="collapse" width="916">
	<tr>
		<td class="parent">
			<table cellpadding="1" cellspacing="0" border-collapse="collapse" width="915">
				<tbody>
					<tr bgcolor="#c5d1d7">
						<td ><img alt="" src="header8.png"></td>				
					</tr>
					<tr >
						<td valign="top">
							<table cellpadding="0" cellspacing="0">
							<tr >
								<td width="12" class="innerbody">&nbsp;</td>
								<td width="890" >
									<table cellpadding="0" cellspacing="0">
										<tr>
											<td width="12">&nbsp;</td>
											<td width="866">&nbsp;</td>
											<td width="12">&nbsp;</td>
										</tr>
										<tr >
											<td width="12">&nbsp;</td>
											<td width="866" >
												<table cellpadding="2" class="first" cellspacing="0">
													<tr>
														<td class="second" width="400">GSTIN No.</td>
														<td class="second" width="66">&nbsp;</td>
														<td class="second" width="400">Mobile No.</td>
													</tr>
													<tr >
														<td class="second" width="400">&nbsp;</td>
														<td class="second" width="66" >&nbsp;</td>
														<td class="second" width="400">e-mail id</td>
													</tr>
													<tr>
														<td width="864" colspan="3" align="center" class="taxinvoicetext">TAX INVOICE</td>
													</tr>
													<tr>
														<td width="864" colspan="3" align="center" class="farmnametext">Name of the Firm<br />Address of the Firm<br />Main Products in which dealing</td>
													</tr>
													<tr>
														<td width="400" class="second">Date of Invoice</td>
														<td width="66" class="second">&nbsp;</td>
														<td width="400" class="second">Serial No. of Invoice</td>
													</tr>
													<tr>
														<td width="864" colspan="3">&nbsp;</td>
													</tr>
													<tr>
														<td width="400" class="third">Details of Receiver(Billed to)<br />Name<br />Address<br />State<br />State Code<br />Mobile No. & E-Mail ID<br />GSTIN/Unique ID</td>
														<td width="66">&nbsp;</td>
														<td width="400" class="fourth">Details of Consignee (Shipped to )<br />Name<br />Address<br />State<br />State Code<br />Mobile No. & E-Mail ID<br />GSTIN/Unique ID</td>
													</tr>
													<tr>
														<td width="864" colspan="3">&nbsp;</td>
													</tr>
													<tr>														
														<td width="866"  colspan="3" style="border-top: 1pt solid #8d8d8d;">
															<table cellpadding="0" cellspacing="0">
																<tr>
																	<td class="fifth" rowspan="2" width="30">Sr. No.</td>
																	<td class="fifth" rowspan="2" width="128">Description Of Goods</td>
																	<td class="fifth" rowspan="2" width="47">HSN Code</td>
																	<td class="fifth" rowspan="2" width="40">Qty</td>
																	<td class="fifth" rowspan="2" width="40">Unit</td>
																	<td class="fifth" rowspan="2" width="65">Rate (per Item)</td>
																	<td class="fifth" rowspan="2" width="65">Total</td>
																	<td class="fifth" rowspan="2" width="65">Discount</td>
																	<td class="fifth" rowspan="2" width="65">Taxable Value</td>
																	<td class="fifth" width="105">CGST</td>
																	<td class="fifth" width="105">SGST</td>
																	<td class="second" width="108">IGST</td>
																</tr>
																<tr>
																	<td class="fifth" width="52">Rate</td>
																	<td class="fifth" width="53">Amt.</td>
																	<td class="fifth" width="52">Rate</td>
																	<td class="fifth" width="53">Amt.</td>
																	<td class="fifth" width="52">Rate</td>
																	<td class="second" width="56">Amt.</td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="sixth" width="128"></td>
																	<td class="sixth" width="47"></td>
																	<td class="sixth" width="40" align="right"></td>
																	<td class="sixth" width="40" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="" width="56" align="right"></td>
																</tr>
																
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="sixth" width="128"></td>
																	<td class="sixth" width="47"></td>
																	<td class="sixth" width="40" align="right"></td>
																	<td class="sixth" width="40" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="" width="53" align="right"></td>
																</tr>
																
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="sixth" width="128"></td>
																	<td class="sixth" width="47"></td>
																	<td class="sixth" width="40" align="right"></td>
																	<td class="sixth" width="40" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="" width="53" align="right"></td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="sixth" width="128"></td>
																	<td class="sixth" width="47"></td>
																	<td class="sixth" width="40" align="right"></td>
																	<td class="sixth" width="40" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="" width="53" align="right"></td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="sixth" width="128"></td>
																	<td class="sixth" width="47"></td>
																	<td class="sixth" width="40" align="right"></td>
																	<td class="sixth" width="40" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="" width="53" align="right"></td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="sixth" width="128"></td>
																	<td class="sixth" width="47"></td>
																	<td class="sixth" width="40" align="right"></td>
																	<td class="sixth" width="40" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="" width="53" align="right"></td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="sixth" width="128"></td>
																	<td class="sixth" width="47"></td>
																	<td class="sixth" width="40" align="right"></td>
																	<td class="sixth" width="40" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="" width="53" align="right"></td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td style="border-right:1pt solid #8d8d8d;border-top:1pt solid #8d8d8d;" width="320">&nbsp;Freight</td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="" width="53" align="right"></td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="sixth" width="320">&nbsp;Insurance</td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="" width="53" align="right"></td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="sixth" width="320">&nbsp;Packing and Forwarding Charges</td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="65" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="sixth" width="53" align="right"></td>
																	<td class="sixth" width="52" align="right"></td>
																	<td class="" width="53" align="right"></td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="seventh" colspan="5" width="320">&nbsp;Total</td>
																	<td class="seventh" width="65" align="right"></td>
																	<td class="seventh" width="65" align="right"></td>
																	<td class="seventh" width="65" align="right"></td>
																	<td class="seventh" colspan="2" width="105" align="right"></td>
																	<td class="seventh" colspan="2" width="105" align="right"></td>
																	<td class="seventh" colspan="2" width="108" align="right"></td>
																</tr>
																<tr>
																	<td class="sixth" rowspan="3" width="30"></td>
																	<td class="seventh" rowspan="3" colspan="8" width="515">&nbsp;Total Invoice Value (In figure)<br />&nbsp;Total Invoice Value (In Words)<br />&nbsp;Amount of Tax subject to Reverse Charges &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yes/No&nbsp;&nbsp;&nbsp;</td>
																	<td class="seventh" colspan="6" width="318" align="left"></td>
																</tr>
																<tr>
																	<td class="seventh" colspan="6" width="318" align="left"></td>
																</tr>													
																<tr>
																	<td class="seventh" colspan="2" width="105" align="right"></td>
																	<td class="seventh" colspan="2" width="105" align="right"></td>
																	<td class="seventh" colspan="2" width="108" align="right"></td>
																</tr>
																<tr>
																	<td class="sixth" width="30" ></td>
																	<td class="" colspan="8" width="515">&nbsp;Electronic Reference Number</td>
																	<td class="" colspan="6" width="318"></td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="" colspan="8" width="515"></td>
																	<td class="" colspan="6" width="315">&nbsp;Signature</td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="" colspan="8" width="515"></td>
																	<td class="" colspan="6" width="315">&nbsp;Name of the Signatory</td>
																</tr>
																<tr>
																	<td class="sixth" width="30"></td>
																	<td class="" colspan="8" width="515"></td>
																	<td class="" colspan="6" width="315">&nbsp;Designation/Status</td>
																</tr>
															</table>
														</td>
													</tr>
												</table>
											</td>
											<td width="12">&nbsp;</td>
										</tr>
										<tr>
											<td width="12">&nbsp;</td>
											<td width="866">&nbsp;</td>
											<td width="12">&nbsp;</td>
										</tr>
									</table>
								</td>
								<td width="12" class="innerbody">&nbsp;</td>
							</tr>
							<tr>
								<td width="12" class="innerbody">&nbsp;</td>
								<td width="890" class="innerbody">&nbsp;</td>
								<td width="12" class="innerbody">&nbsp;</td>
							</tr>
							</table>
						</td>
					</tr>
				</tbody>
			</table>
		</td>
	</tr>
</table>
EOF;

// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

//$pdf->AddPage('L','Letter');

/* NOTE:
 * *********************************************************
 * You can load external XHTML using :
 *
 * $html = file_get_contents('/path/to/your/file.html');
 *
 * External CSS files will be automatically loaded.
 * Sometimes you need to fix the path of the external CSS.
 * *********************************************************
 */

// define some HTML content with style
$html2 = '<style>
td.parent{
	border: 1px solid #7b9899;
}
table.first {
	font-size: 10pt;
	border: 1pt solid #8d8d8d;
	width:100%;
	font-size:9pt;
}
.innerbody{
background-color: #c5d1d7;
}
td.fifth{
	border-bottom: 1pt solid #8d8d8d;
	border-right: 1pt solid #8d8d8d;
	text-align:center;
}
td.sixth{
	border-right: 1pt solid #8d8d8d;
}
td.seventh{
	border-right: 1pt solid #8d8d8d;
	border-top: 1pt solid #8d8d8d;
	border-bottom: 1pt solid #8d8d8d;
}
td.second {
	border-bottom: 1pt solid #8d8d8d;
	text-align:center;
}
</style>

<table cellpadding="0" cellspacing="0" border-collapse="collapse" width="916">
	<tr>
		<td class="parent">
			<table cellpadding="1" cellspacing="0" border-collapse="collapse" width="915">
				<tbody>
					<tr bgcolor="#c5d1d7">
						<td ><img alt="" src="header6.png"></td>				
					</tr>
					<tr >
						<td valign="top">
							<table cellpadding="0" cellspacing="0">
							<tr >
								<td width="12" class="innerbody">&nbsp;</td>
								<td width="890" >
									<table cellpadding="0" cellspacing="0">
										<tr>
											<td width="12">&nbsp;</td>
											<td width="866">&nbsp;</td>
											<td width="12">&nbsp;</td>
										</tr>
										<tr >
											<td width="12">&nbsp;</td>
											<td width="866" >
												<table cellpadding="1" class="first" cellspacing="0">
													<tr>
														<td class="fifth" rowspan="2" width="30">Sr. No.</td>
														<td class="fifth" rowspan="2" width="128">Description Of Goods</td>
														<td class="fifth" rowspan="2" width="47">HSN Code</td>
														<td class="fifth" rowspan="2" width="40">Qty</td>
														<td class="fifth" rowspan="2" width="40">Unit</td>
														<td class="fifth" rowspan="2" width="65">Rate (per Item)</td>
														<td class="fifth" rowspan="2" width="65">Total</td>
														<td class="fifth" rowspan="2" width="65">Discount</td>
														<td class="fifth" rowspan="2" width="65">Taxable Value</td>
														<td class="fifth" width="105">CGST</td>
														<td class="fifth" width="105">SGST</td>
														<td class="second" width="105">IGST</td>
													</tr>
													<tr>
														<td class="fifth" width="52">Rate</td>
														<td class="fifth" width="53">Amt.</td>
														<td class="fifth" width="52">Rate</td>
														<td class="fifth" width="53">Amt.</td>
														<td class="fifth" width="52">Rate</td>
														<td class="second" width="53">Amt.</td>
													</tr>';
									for($ijk = 0; $ijk<10;$ijk++){
											$html2.='<tr>
														<td class="sixth" width="30"></td>
														<td class="sixth" width="128"></td>
														<td class="sixth" width="47"></td>
														<td class="sixth" width="40" align="right"></td>
														<td class="sixth" width="40" align="right"></td>
														<td class="sixth" width="65" align="right"></td>
														<td class="sixth" width="65" align="right"></td>
														<td class="sixth" width="65" align="right"></td>
														<td class="sixth" width="65" align="right"></td>
														<td class="sixth" width="52" align="right"></td>
														<td class="sixth" width="53" align="right"></td>
														<td class="sixth" width="52" align="right"></td>
														<td class="sixth" width="53" align="right"></td>
														<td class="sixth" width="52" align="right"></td>
														<td class="" width="53" align="right"></td>
													</tr>';
									}				
										$html2.='<tr>
														<td class="sixth" width="30"></td>
														<td class="seventh" width="320">Freight<br />Insurance<br />Packing and Forwarding Charges</td>
														<td class="sixth" width="65" align="right"></td>
														<td class="sixth" width="65" align="right"></td>
														<td class="sixth" width="65" align="right"></td>
														<td class="sixth" width="52" align="right"></td>
														<td class="sixth" width="53" align="right"></td>
														<td class="sixth" width="52" align="right"></td>
														<td class="sixth" width="53" align="right"></td>
														<td class="sixth" width="52" align="right"></td>
														<td class="" width="53" align="right"></td>
													</tr>
													<tr>
														<td class="sixth" width="30"></td>
														<td class="seventh" colspan="5" width="320">Total</td>
														<td class="seventh" width="65" align="right"></td>
														<td class="seventh" width="65" align="right"></td>
														<td class="seventh" width="65" align="right"></td>
														<td class="seventh" colspan="2" width="105" align="right"></td>
														<td class="seventh" colspan="2" width="105" align="right"></td>
														<td class="seventh" colspan="2" width="105" align="right"></td>
													</tr>
													<tr>
														<td class="sixth" rowspan="3" width="30"></td>
														<td class="seventh" rowspan="3" colspan="8" width="515">Total Invoice Value (In figure)<br />Total Invoice Value (In Words)<br />Amount of Tax subject to Reverse Charges&nbsp ;&nbsp;&nbsp;&nbsp;&nbsp;Yes/No&nbsp;&nbsp;&nbsp;</td>
														<td class="seventh" colspan="6" width="315" align="left"></td>
													</tr>
													<tr>
														<td class="seventh" colspan="6" width="315" align="left"></td>
													</tr>													
													<tr>
														<td class="seventh" colspan="2" width="105" align="right"></td>
														<td class="seventh" colspan="2" width="105" align="right"></td>
														<td class="seventh" colspan="2" width="105" align="right"></td>
													</tr>
													<tr>
														<td class="sixth" width="30" ></td>
														<td class="" colspan="8" style="line-height:3pt;" width="515">&nbsp;Electronic Reference Number</td>
														<td class="" colspan="6" width="315"></td>
													</tr>
													<tr>
														<td class="sixth" width="30"></td>
														<td class="" colspan="8" width="515"></td>
														<td class="" colspan="6" width="315">&nbsp;Signature</td>
													</tr>
													<tr>
														<td class="sixth" width="30"></td>
														<td class="" colspan="8" width="515"></td>
														<td class="" colspan="6" width="315">&nbsp;Name of the Signatory</td>
													</tr>
													<tr>
														<td class="sixth" width="30"></td>
														<td class="" colspan="8" width="515"></td>
														<td class="" colspan="6" width="315">&nbsp;Designation/Status</td>
													</tr>
												</table>
											</td>
											<td width="12">&nbsp;</td>
										</tr>
										<tr>
											<td width="12">&nbsp;</td>
											<td width="866">&nbsp;</td>
											<td width="12">&nbsp;</td>
										</tr>
									</table>
								</td>
								<td width="12" class="innerbody">&nbsp;</td>
							</tr>
							<tr>
								<td width="12" class="innerbody">&nbsp;</td>
								<td width="890" class="innerbody">&nbsp;</td>
								<td width="12" class="innerbody">&nbsp;</td>
							</tr>
							</table>
						</td>
					</tr>
				</tbody>
			</table>
		</td>
	</tr>
</table>';

// output the HTML content
//$pdf->writeHTML($html2, true, false, true, false, '');
// *******************************************************************
// HTML TIPS & TRICKS
// *******************************************************************

// REMOVE CELL PADDING
//
// $pdf->SetCellPadding(0);
// 
// This is used to remove any additional vertical space inside a 
// single cell of text.

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// REMOVE TAG TOP AND BOTTOM MARGINS
//
// $tagvs = array('p' => array(0 => array('h' => 0, 'n' => 0), 1 => array('h' => 0, 'n' => 0)));
// $pdf->setHtmlVSpace($tagvs);
// 
// Since the CSS margin command is not yet implemented on TCPDF, you
// need to set the spacing of block tags using the following method.

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// SET LINE HEIGHT
//
// $pdf->setCellHeightRatio(1.25);
// 
// You can use the following method to fine tune the line height
// (the number is a percentage relative to font height).

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// CHANGE THE PIXEL CONVERSION RATIO
//
// $pdf->setImageScale(0.47);
// 
// This is used to adjust the conversion ratio between pixels and 
// document units. Increase the value to get smaller objects.
// Since you are using pixel unit, this method is important to set the
// right zoom factor.
// 
// Suppose that you want to print a web page larger 1024 pixels to 
// fill all the available page width.
// An A4 page is larger 210mm equivalent to 8.268 inches, if you 
// subtract 13mm (0.512") of margins for each side, the remaining 
// space is 184mm (7.244 inches).
// The default resolution for a PDF document is 300 DPI (dots per 
// inch), so you have 7.244 * 300 = 2173.2 dots (this is the maximum 
// number of points you can print at 300 DPI for the given width).
// The conversion ratio is approximatively 1024 / 2173.2 = 0.47 px/dots
// If the web page is larger 1280 pixels, on the same A4 page the 
// conversion ratio to use is 1280 / 2173.2 = 0.59 pixels/dots

// *******************************************************************

// reset pointer to the last page
$pdf->lastPage();

// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output('example_061.pdf', 'I');

//============================================================+
// END OF FILE                                                
//============================================================+
