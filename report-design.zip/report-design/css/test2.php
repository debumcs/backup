<?php

ini_set("display_errors", 1);

// Include the main TCPDF library (search for installation path).
require_once('tcpdf/config/lang/eng.php');
require_once('tcpdf/tcpdf.php');

class MYPDF extends TCPDF {

	//Page header
	public function Header() {
		// Logo

		$header = '<div id="wrapper" style="float: left; height: auto; left: 0px; top: 0px; width: 700px;">
   <div id="header" style="float: left; height: 88px; left: 0px; top: 0px; width: 700px;">
    <div class="nmac-Logo" style="background-color: #041423; float: left; height: 88px; left: 0px; top: 0px; width: 350px;">
     <table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tbody>
       <tr>
        <th scope="row" style="font-family: Raleway, sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: left;"><img alt="" height="88" src="nmac-logo.jpg" width="350" /></th>
       </tr>
      </tbody>
     </table>
    </div>
    <div class="details-address" style="background-color: #2ca8e1; float: right; height: 88px; width: 350px;"><img alt="" height="88" src="nmac-addess.jpg" width="350" /></div>
   </div>';
		$this->writeHTMLCell($w=0, $h=0, $x='', $y='', $header, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
	}

	//Page header
	public function Footer() {
		// Logo

		$footer = '<div class="box" style="float: left; height: auto; left: 0px; margin-bottom: 15px; margin-left: 12px; margin-right: 12px; margin-top: 15px; right: 0px; width: 676px;">
    <div style="width: 676;">
     <h3 style="color: #000; font-size: 20px; margin-bottom: 5px; text-align: center;">For An appointment : (441)293-5476</h3>
    </div>
    <div style="float: left; line-height: 0.5px; width: 676px;">
     <p style="color: black; font-size: 11px; font-weight: 600; line-height: 15.5px; text-align: center;">&nbsp;</p>
    </div>
    <div style="float: left; line-height: 0.5px; text-align: center; width: 676px;"><img alt="" height="97" src="partners-logos.jpg" width="433" /></div>
   </div>
</div>';
		$this->writeHTMLCell($w=0, $h=0, $x='', $y='', $footer, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
	}
}

// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Reverse Mortgage');
$pdf->SetTitle('Reverse Mortgage Specialists');
$pdf->SetSubject('Reverse Mortgage');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set default header data
$pdf->SetHeaderData('', '', 'Reverse Mortgage Specialists', 'Reverse Mortgage', array(0,64,255), array(0,64,128));
$pdf->setFooterData($tc=array(0,64,0), $lc=array(0,64,128));

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

//set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

//set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

//set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

//set some language-dependent strings
$pdf->setLanguageArray($l);

// ---------------------------------------------------------

// set default font subsetting mode
$pdf->setFontSubsetting(true);

// Set font
// dejavusans is a UTF-8 Unicode font, if you only need to
// print standard ASCII chars, you can use core fonts like
// helvetica or times to reduce file size.
$pdf->SetFont('dejavusans', '', 9, '', true);

// Add a page
// This method has several options, check the source code documentation for more information.
$pdf->AddPage();

// set text shadow effect
//$pdf->setTextShadow(array('enabled'=>true, 'depth_w'=>0.2, 'depth_h'=>0.2, 'color'=>array(196,196,196), 'opacity'=>1, 'blend_mode'=>'Normal'));

// Set some content to print

$html = <<<EOD
  <div class="box" style="float: left; height: auto; left: 0px; margin-bottom: 15px; margin-left: 12px; margin-right: 12px; margin-top: 15px; right: 0px; width: 676px;">
    <div style="margin-top: 15px; width: 676px;">
     <h2 style="color: #000; font-size: 25px; margin-bottom: 5px; text-align: center;">PATIENT INFORMATION</h2>
    </div>
    <div class="patient-mid" style="height: auto; left: 0px; right: 0px; width: 676px;">
     <div class="patient-pateint" style="float: left; height: 230px; line-height: 0.5px; width: 200px;">
      <table border="0" cellpadding="0" cellspacing="0" width="100%">
       <tbody>
        <tr>
         <td height="147" style="font-family: Raleway, sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;"><img alt="" height="129" src="after-sumit.png" width="128" /></td>
        </tr>
        <tr>
         <td height="62" style="font-family: Raleway, sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: left;">
          <p>
           <h2 align="center" style="font-size: 14px; font-weight: 600; left: 0px; line-height: 0.5px; right: 0px;">After Sumit</h2>
          </p>
          <h3 align="center" style="font-size: 12px; font-weight: 300; left: 0px; line-height: 0.5px; right: 0px;">Age 32</h3>
          <h3 align="center" style="font-size: 12px; font-weight: 300; left: 0px; line-height: 0.5px; right: 0px;"> D.O.B : 15-01-1992</h3>
         </td>
        </tr>
       </tbody>
      </table>
     </div>
     <div class="patient-info" style="float: right; height: auto; left: 0px; line-height: 0.5px; right: 0px; width: 450px;">
      <div style="float: left; line-height: 0.5; margin-right: 30px; text-align: left; width: 190px;">
       <h3 style="color: black;">Calculation on First Visit</h3>
       <p>Weight : 82kg</p>
       <p>Height : 178cm</p>
       <p>Race : African</p>
       <p>Health Status : Diabetes</p>
      </div>
      <div style="float: right; line-height: 0.5; text-align: left; width: 220px;">
       <h3 style="color: black;">Reported By</h3>
       <p>Date of Admission : 30 jan, 2016</p>
       <p>Reported By : Dr. Kyjuan Brown</p>
       <p>Generated Report &quot; 31 Jan 2016</p>
      </div>
     </div>
     <div class="patient-info" style="float: right; height: auto; left: 0px; line-height: 0.5px; right: 0px; width: 450px;">
      <div style="float: left; line-height: 0.5; margin-right: 30px; width: 190px;">
       <h3 style="color: black;">Location</h3>
       <p>723, North Shore Road</p>
       <p>Devonshire DV123 Bermuda</p>
      </div>
      <div style="float: right; line-height: 0.5; width: 220px;">
       <h3 style="color: black;">Contact Details</h3>
       <p>Phone No. : +91 00 00 0000 00</p>
       <p>Email Id : xyz@gmail.com</p>
      </div>
     </div>
     <div class="patient-info" style="float: right; height: auto; left: 0px; line-height: 0.5px; right: 0px; width: 450px;">
      <div style="float: right; line-height: 0.5; width: 450px;">
       <h3 style="color: black;">Medical History</h3>
       <p style="color: black; line-height: 15.5px;">lorem ipsum will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
      </div>
     </div>
    </div>
   </div>
EOD;

// Print text using writeHTMLCell()
$pdf->writeHTMLCell($w=0, $h=0, $x='', $y='', $html, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);

// ---------------------------------------------------------
$pdf->lastPage();
// Close and output PDF document
// This method has several options, check the source code documentation for more information.
$pdf->Output('test23.pdf', 'I');

?>