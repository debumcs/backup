<!-- Start core Card -->
<table width="700" border="0" cellspacing="0" cellpadding="0">
        <tbody>
          <tr>
            <td height="30" align="center" valign="middle"><h2 style="color: #000; font-size: 18.75pt; margin-bottom: 2pt;">BODY COMPOSITION</h2></td>
          </tr>
          <tr>
            <td height="17" align="center" valign="top" style="line-height: 10pt; font-weight:700; font-size: 8pt"><span style="color: black;">BMI : <span style="color: #0F3;">Underweight (< 18.5)</span> | <span style="color: #060;">Normal (18.5 – 24.9)</span> | <span style="color: #FF0;">Overweight (25 – 29.9)</span> | <span style="color: #F00;">Obese (> 30)</span></span></td>
          </tr>
          <tr>
            <td>
            
            </td>
          </tr>
          <tr>
            <td height="5" align="center" valign="top"><table width="676" border="0" cellspacing="0" cellpadding="0" style="margin-left: 9pt; margin-right: 9pt; ">
              <tbody>
                <tr>
                  <th align="left" valign="top" scope="col"><table class="tabl" style="border: 0.75pt dotted #CCC; border-collapse: collapse; width: 100%;">
                    <tr>
                      <th class="tabl" style="border: 0.75pt dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: 0.75pt; line-height: 15pt; text-align: center; width: 63.75pt;" width="65">Date</th>
                      <th class="tabl" style="border: 0.75pt dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: 0.75pt; line-height: 15pt; text-align: center; width: 63.75pt;" width="65">Score</th>
                      <th class="tabl" style="border: 0.75pt dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: 0.75pt; line-height: 15pt; text-align: center;" width="514">Comments</th>
                    </tr>
                    <tr>
                      <td class="tabl" style="border: 0.75pt dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: 0.75pt; line-height: 15pt; text-align: left;"><table border="0" cellpadding="0" cellspacing="0" width="100%">
                        <tbody>
                          <tr>
                            <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: 0.75pt; line-height: 15pt; text-align: center;" width="63">10-01-16</th>
                          </tr>
                        </tbody>
                      </table></td>
                      <td class="tabl" style="border: 0.75pt dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: 0.75pt; line-height: 15pt; text-align: left;"><table border="0" cellpadding="0" cellspacing="0" width="100%">
                        <tbody>
                          <tr>
                            <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: 0.75pt; line-height: 15pt; text-align: center;" width="100%">220/98</th>
                          </tr>
                          <tr>
                            <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: 0.75pt; line-height: 15pt; text-align: center;"><img alt="" height="20" src="red-small.png" width="20" /></th>
                          </tr>
                        </tbody>
                      </table></td>
                      <td align="justify" class="tabl " style="border: 0.75pt dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 8pt; letter-spacing: 0.75pt; line-height: 12pt; text-align: left; width: 315pt;"><p class="tabl-text" style="margin-left: 4pt; margin-right: 4pt; font-weight:300;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p></td>
                    </tr>
                    <tr>
                      <td class="tabl" style="border: 0.75pt dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: 0.75pt; line-height: 15pt; text-align: left;"><table border="0" cellpadding="0" cellspacing="0" width="100%">
                        <tbody>
                          <tr>
                            <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: 0.75pt; line-height: 15pt; text-align: center;" width="63">10-01-16</th>
                          </tr>
                        </tbody>
                      </table></td>
                      <td class="tabl" style="border: 0.75pt dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: 0.75pt; line-height: 15pt; text-align: left;"><table border="0" cellpadding="0" cellspacing="0" width="100%">
                        <tbody>
                          <tr>
                            <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: 0.75pt; line-height: 15pt; text-align: center;" width="100%">180/67</th>
                          </tr>
                          <tr>
                            <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: 0.75pt; line-height: 15pt; text-align: center;"><img alt="" height="20" src="small-green.png" width="20" /></th>
                          </tr>
                        </tbody>
                      </table></td>
                      <td align="justify" class="tabl " style="border: 0.75pt dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 8pt; letter-spacing: 0.75pt; line-height: 12pt; text-align: left; width: 315pt;"><p class="tabl-text" style="margin-left: 4pt; margin-right: 4pt; font-weight:300;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p></td>
                    </tr>
                  </table></th>
                  </tr>
              </tbody>
            </table></td>
          </tr>
          <tr>
            <td height="20" align="center" valign="top">&nbsp;</td>
          </tr>
          
        </tbody>
      </table>
   <!-- End Score Card -->



<table border="0" cellpadding="0" cellspacing="0" width="700">
	<tr>
		<th><h2 style="color: #000; font-size: 18.75pt; margin-bottom: 3.75pt; text-align: center;">BODY COMPOSITION</h2></th>
	</tr>
	<tr>
		<th style="font-weight: 600; line-height: 0.37pt; text-align: center;" width="676"><p style="color: black; font-size: 11px; line-height: 15.5px;">BMI : <span style="color: #0F3;">Underweight (< 18.5)</span> | <span style="color: #060;">Normal (18.5 – 24.9)</span> | <span style="color: #FF0;">Overweight (25 – 29.9)</span> | <span style="color: #F00;">Obese (> 30)</span></p></th>
	</tr>
	<tr>
		<td>
		
		
		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: .75pt; line-height: 15pt; text-align: center;" width="65">Date</th>
				<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: .75pt; line-height: 15pt; text-align: center;" width="65">Score</th>
				<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: .75pt; line-height: 15pt; text-align: center;" width="514">Comments</th>
			</tr>

			<tr>
				<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: .75pt; line-height: 15pt; text-align: center;" width="65">10-01-16</th>
				<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: .75pt; line-height: 15pt; text-align: center;" width="65">180/67<br><img alt="" height="20" src="small-green.png" width="20" /></th>
				<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: .75pt; line-height: 15pt; text-align: left;" width="514">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</td>
			</tr>
			
		</table>
		
		
		</td>
	</tr>
</table>