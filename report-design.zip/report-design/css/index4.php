<?php
//============================================================+
// File name   : example_061.php
// Begin       : 2010-05-24
// Last Update : 2010-08-08
//
// Description : Example 061 for TCPDF class
//               XHTML + CSS
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               Manor Coach House, Church Hill
//               Aldershot, Hants, GU12 4RQ
//               UK
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

/**
 * Creates an example PDF TEST document using TCPDF
 * @package com.tecnick.tcpdf
 * @abstract TCPDF - Example: XHTML + CSS
 * @author Nicola Asuni
 * @since 2010-05-25
 */

require_once('tcpdf/config/lang/eng.php');
require_once('tcpdf/tcpdf.php');

class MYPDF extends TCPDF {

	//Page header
	public function Header() {
		// Logo

		$header = '';
		$this->writeHTMLCell($w=0, $h=0, $x='', $y='', $header, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
	}

	//Page header
	public function Footer() {
		// Logo

		$footer = '';
		$this->writeHTMLCell($w=0, $h=0, $x='', $y='', $footer, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
	}
}

// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Nicola Asuni');
$pdf->SetTitle('TCPDF Example 061');
$pdf->SetSubject('TCPDF Tutorial');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set default header data
//$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 061', PDF_HEADER_STRING);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

//set margins
/*$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);*/

//set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

//set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

//set some language-dependent strings
$pdf->setLanguageArray($l);

// ---------------------------------------------------------

// set font
$pdf->SetFont('helvetica', '', 10);

// add a page
$pdf->AddPage();

/* NOTE:
 * *********************************************************
 * You can load external XHTML using :
 *
 * $html = file_get_contents('/path/to/your/file.html');
 *
 * External CSS files will be automatically loaded.
 * Sometimes you need to fix the path of the external CSS.
 * *********************************************************
 */
//$html = file_get_contents('inline-report-2.html');
$html = <<<EOD
<table width="700" border="0" cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td><table width="700" border="0" cellspacing="0" cellpadding="0">
        <tbody>
          <tr>
            <td width="351" align="left" valign="top"><span style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: left;"><img alt="" height="88" src="http://urips.co.in/nmac-health/report-design/new/nmac-logo.jpg" width="350" /></span></td>
            <td width="350" align="left" valign="top"><span class="details-address" style="background-color: #2ca8e1; float: right; height: 88px; width: 350px;"><img alt="" height="88" src="http://urips.co.in/nmac-health/report-design/new/nmac-addess.jpg" width="350" /></span></td>
          </tr>
        </tbody>
      </table></td>
    </tr>
    <tr>
      <td height="5"></td>
    </tr>
    
    <tr>
      <td align="center" valign="top"><table width="700" border="0" cellspacing="0" cellpadding="0">
        <tbody>
          <tr>
            <td height="43" align="center" valign="middle"><h2 style="color: #000; font-size: 18.75pt; margin-bottom: 3.75pt;">PATIENT INFORMATION</h2></td>
          </tr>
          <tr>
            <td height="37" align="center" valign="top"><table width="676" border="0" cellspacing="0" cellpadding="0" style="margin-left: 9pt; margin-right: 9pt; ">
              <tbody>
                <tr>
                  <th width="185" align="left" valign="top" scope="col"><table border="0" cellpadding="0" cellspacing="0" width="185">
                    <tbody>
                      <tr>
                        <td height="110.25pt" style="font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: 0.75pt; line-height: 15pt; text-align: center;"><img alt="" height="96.75pt" src="after-sumit.png" width="96pt" /></td>
                      </tr>
                      <tr>
                        <td height="46.5pt;" style="font-family: 'Raleway', sans-serif; font-size: 7.5pt; letter-spacing: 0.75pt; line-height: 15pt; text-align: left;"><h2 align="center" style="font-size: 10.5pt; font-weight: 600; left: 0pt; line-height: 3.75pt; right: 0pt;">After Sumit</h2>
                          <h3 align="center" style="font-size: 9pt; font-weight: 300; left: 0pt; line-height: 3.75pt; right: 0pt;">Age 32</h3>
                          <h3 align="center" style="font-size: 9pt; font-weight: 300; left: 0pt; line-height: 3.75pt; right: 0pt;"> D.O.B : 15-01-1992</h3></td>
                      </tr>
                    </tbody>
                  </table></th>
                  <th width="491" align="right" valign="top" scope="col"><table width="491" border="0" cellspacing="0" cellpadding="0">
                    <tbody>
                      <tr>
                        <th width="245" align="right" valign="top" scope="col"><table width="245" border="0" cellspacing="0" cellpadding="0" style="margin-top:5pt">
                          <tbody>
                            <tr>
                              <th align="left" valign="top" scope="col" style="font-size:10pt">Calculation on First Visit</th>
                            </tr>
                            <tr>
                              <th align="left" valign="top" scope="col" style="font-weight:300; line-height: 10pt">Weight : 82kg<br>
                                Height : 178cm<br>
                                Race : African<br>
                                Health Status : Diabetes</th>
                            </tr>
                          </tbody>
                        </table></th>
                        <th width="246" align="left" valign="top" scope="col"><table width="245" border="0" cellspacing="0" cellpadding="0" style="margin-top:5pt">
                          <tbody>
                            <tr>
                              <th align="left" valign="top" scope="col" style="font-size:10pt">Reported By</th>
                            </tr>
                            <tr>
                              <th align="left" valign="top" scope="col" style="font-weight:300; line-height: 10pt">Date of Admission : 30 jan, 2016 <br>
                                Reported By : Dr. Kyjuan Brown<br>
                                Generated on : 31 Jan 2016 </th>
                            </tr>
                          </tbody>
                        </table></th>
                      </tr>
                      <tr>
                        <th align="left" valign="top" scope="col"><table width="245" border="0" cellspacing="0" cellpadding="0" style="margin-top:5pt">
                          <tbody>
                            <tr>
                              <th align="left" valign="top" scope="col" style="font-size:10pt">Location</th>
                            </tr>
                            <tr>
                              <th align="left" valign="top" scope="col" style="font-weight:300; line-height: 10pt">723, North Shore Road<br>
                                Devonshire DV123 Bermuda</th>
                            </tr>
                          </tbody>
                        </table></th>
                        <th align="left" valign="top" scope="col"><table width="245" border="0" cellspacing="0" cellpadding="0" style="margin-top:5pt">
                          <tbody>
                            <tr>
                              <th align="left" valign="top" scope="col" style="font-size:10pt">Contact Details</th>
                            </tr>
                            <tr>
                              <th align="left" valign="top" scope="col" style="font-weight:300; line-height: 10pt">Phone No. : +91 00 00 0000 00 <br>
                                Email Id : xyz@gmail.com </th>
                            </tr>
                          </tbody>
                        </table></th>
                      </tr>
                      <tr>
                        <th colspan="2" align="left" valign="top" scope="col"><table width="491" border="0" cellspacing="0" cellpadding="0" style="margin-top:5pt">
                          <tbody>
                            <tr>
                              <th align="left" valign="top" scope="col" style="font-size:10pt">Medical History</th>
                            </tr>
                            <tr>
                              <th align="left" valign="top" scope="col" style="font-weight: 300; line-height: 10pt; text-align: justify;">lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</th>
                            </tr>
                          </tbody>
                        </table></th>
                      </tr>
                    </tbody>
                  </table></th>
                </tr>
              </tbody>
            </table></td>
          </tr>
          <tr>
            <td height="31">&nbsp;</td>
          </tr>
        </tbody>
      </table></td>
    </tr>
    <tr>
      <td align="center" valign="top"><table width="700" border="0" cellspacing="0" cellpadding="0">
        <tbody>
          <tr>
            <td height="43" align="center" valign="middle"><h2 style="color: #000; font-size: 18.75pt; margin-bottom: 6pt;">SCORE CARD KEY</h2></td>
          </tr>
          <tr>
            <td height="37" align="center" valign="top"><table width="676" border="0" cellspacing="0" cellpadding="0" style="margin-left: 9pt; margin-right: 9pt; ">
              <tbody>
                <tr>
                  <th width="135" align="left" valign="top" scope="col"><table width="125" border="0" cellspacing="0" cellpadding="0" style="margin-top:5pt">
                    <tbody>
                      <tr>
                        <th width="125" height="56" align="center" valign="top" style="font-size:10pt" scope="col"><img src="danger.png" width="45" height="46" alt=""/></th>
                      </tr>
                      <tr>
                        <th align="left" valign="top" scope="col" style="font-weight: 300; line-height: 10pt; text-align: center;">Your at risk extreem dranger of developing major health problems! ( Seek Urgent Medical Attention )</th>
                      </tr>
                    </tbody>
                  </table></th>
                  <th width="135" align="center" valign="top" scope="col"><table width="125" border="0" cellspacing="0" cellpadding="0" style="margin-top:5pt">
                    <tbody>
                      <tr>
                        <th width="125" height="56" align="center" valign="top" style="font-size:10pt" scope="col"><img src="red.png" width="45" height="45" alt=""/></th>
                      </tr>
                      <tr>
                        <th align="left" valign="top" scope="col" style="font-weight: 300; line-height: 10pt; text-align: center;">Your at risk of having major health problems!</th>
                      </tr>
                    </tbody>
                  </table></th>
                  <th width="135" align="center" valign="top" scope="col"><table width="125" border="0" cellspacing="0" cellpadding="0" style="margin-top:5pt">
                    <tbody>
                      <tr>
                        <th width="125" height="56" align="center" valign="top" style="font-size:10pt" scope="col"><img src="yellow.png" width="45" height="45" alt=""/></th>
                      </tr>
                      <tr>
                        <th align="left" valign="top" scope="col" style="font-weight: 300; line-height: 10pt; text-align: center;">Your at moderate risk of having major health problems!</th>
                      </tr>
                    </tbody>
                  </table></th>
                  <th width="135" align="center" valign="top" scope="col"><table width="125" border="0" cellspacing="0" cellpadding="0" style="margin-top:5pt">
                    <tbody>
                      <tr>
                        <th width="125" height="56" align="center" valign="top" style="font-size:10pt" scope="col"><img src="green.png" width="46" height="46" alt=""/></th>
                      </tr>
                      <tr>
                        <th align="left" valign="top" scope="col" style="font-weight: 300; line-height: 10pt; text-align: center;">Excellent Result</th>
                      </tr>
                    </tbody>
                  </table></th>
                  <th width="135" align="right" valign="top" scope="col"><table width="125" border="0" cellspacing="0" cellpadding="0" style="margin-top:5pt; border: 0.75pt solid #333; ">
                    <tbody>
                      <tr>
                        <th width="125" height="30" align="center" valign="top" style="font-size:10pt" scope="col">Current Status</th>
                      </tr>
                      <tr>
                        <th align="left" valign="top" scope="col" style="font-weight: 300; line-height: 10pt; text-align: left;"> <span style="color: black; margin-left: 9pt; text-align: left;">
                          <input type="checkbox" />
                          Excellant</span> </th>
                      </tr>
                      <tr>
                        <th align="left" valign="top" scope="col" style="font-weight: 300; line-height: 10pt; text-align: left;"> <span style="color: black; margin-left: 9pt;  text-align: left;" >
                          <input type="checkbox" />
                          Very Good</span> </th>
                      </tr>
                      <tr>
                        <th align="left" valign="top" scope="col" style="font-weight: 300; line-height: 10pt; text-align: left;"> <span style="color: black; margin-left: 9pt; text-align: left;">
                          <input type="checkbox" />
                          Good</th>
                      </tr>
                      <tr>
                        <th align="left" valign="top" scope="col" style="font-weight: 300; line-height: 10pt; text-align: left;"> <span style="color: black; margin-left: 9pt; text-align: left;">
                          <input type="checkbox" />
                          Average</th>
                      </tr>
                      <tr>
                        <th align="left" valign="top" scope="col" style="font-weight: 300; line-height: 10pt; text-align: left;"> <span style="color: black; margin-left: 9pt; text-align: left;">
                          <input type="checkbox" />
                          Poor</th>
                      </tr>
                      <tr>
                        <th align="left" valign="top" scope="col" style="font-weight: 300; line-height: 10pt; text-align: left;">&nbsp;</th>
                      </tr>
                    </tbody>
                  </table></th>
                </tr>
              </tbody>
            </table></td>
          </tr>
          <tr>
            <td height="31">&nbsp;</td>
          </tr>
          
        </tbody>
      </table></td>
    </tr>
    
	<tr>
      <td align="center" valign="top"><table width="700" border="0" cellspacing="0" cellpadding="0">
        <tbody>
          <tr>
            <td height="30" align="center" valign="middle"><h2 style="color:#000; font-size: 18.75pt; margin-bottom: 2pt;">For An appointment : (441)293-5476</h2></td>
          </tr>
          
          <tr>
            <td height="5" align="center" valign="top"><img src="partners-logos.jpg" width="439" height="97" alt=""/></td>
          </tr>
          
        </tbody>
      </table></td>
    </tr>
    <tr>
      <td align="center" valign="top">&nbsp;</td>
    </tr>
  </tbody>
</table>

EOD;

// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// *******************************************************************
// HTML TIPS & TRICKS
// *******************************************************************

// REMOVE CELL PADDING
//
// $pdf->SetCellPadding(0);
// 
// This is used to remove any additional vertical space inside a 
// single cell of text.

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// REMOVE TAG TOP AND BOTTOM MARGINS
//
// $tagvs = array('p' => array(0 => array('h' => 0, 'n' => 0), 1 => array('h' => 0, 'n' => 0)));
// $pdf->setHtmlVSpace($tagvs);
// 
// Since the CSS margin command is not yet implemented on TCPDF, you
// need to set the spacing of block tags using the following method.

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// SET LINE HEIGHT
//
// $pdf->setCellHeightRatio(1.25);
// 
// You can use the following method to fine tune the line height
// (the number is a percentage relative to font height).

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// CHANGE THE PIXEL CONVERSION RATIO
//
// $pdf->setImageScale(0.47);
// 
// This is used to adjust the conversion ratio between pixels and 
// document units. Increase the value to get smaller objects.
// Since you are using pixel unit, this method is important to set the
// right zoom factor.
// 
// Suppose that you want to print a web page larger 1024 pixels to 
// fill all the available page width.
// An A4 page is larger 210mm equivalent to 8.268 inches, if you 
// subtract 13mm (0.512") of margins for each side, the remaining 
// space is 184mm (7.244 inches).
// The default resolution for a PDF document is 300 DPI (dots per 
// inch), so you have 7.244 * 300 = 2173.2 dots (this is the maximum 
// number of points you can print at 300 DPI for the given width).
// The conversion ratio is approximatively 1024 / 2173.2 = 0.47 pt/dots
// If the web page is larger 1280 pixels, on the same A4 page the 
// conversion ratio to use is 1280 / 2173.2 = 0.59 pixels/dots

// *******************************************************************

// reset pointer to the last page
$pdf->lastPage();

// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output('example_061.pdf', 'I');

//============================================================+
// END OF FILE                                                
//============================================================+
