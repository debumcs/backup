<?php
include_once('../dbconnection.php');
$con = new dbconnection();
$con->setConnection();

$id = $_GET['id'];

//$id = 2;

$sql = "select * from patient where id = '".$id."'";
$result = $con->runQuery($sql);

$sqlbmi = "select max(bmi.id), bmi.* from bmi where patient_id = '".$id."' group by bmi.patient_id order by bmi.id desc limit 1";
$resultbmi = $con->runQuery($sqlbmi);

$sqlbp = "select max(blood_pressure.id), blood_pressure.* from blood_pressure where patient_id = '".$id."' group by blood_pressure.patient_id order by blood_pressure.id desc limit 1";
$resultbp = $con->runQuery($sqlbp);

$sqlcholesterol = "select max(cholesterol.id), cholesterol.* from cholesterol where patient_id = '".$id."' group by cholesterol.patient_id order by cholesterol.id desc limit 1";
$resultcholesterol = $con->runQuery($sqlcholesterol);

$sqlegfr = "select max(egfr.id), egfr.* from egfr where patient_id = '".$id."' group by egfr.patient_id order by egfr.id desc limit 1";
$resultegfr = $con->runQuery($sqlegfr);

$sqlhba1c = "select max(hba1c.id), hba1c.* from hba1c where patient_id = '".$id."' group by hba1c.patient_id order by hba1c.id desc limit 1";
$resulthba1c = $con->runQuery($sqlhba1c);

$sqlhdl = "select max(hdl.id), hdl.* from hdl where patient_id = '".$id."' group by hdl.patient_id order by hdl.id desc limit 1";
$resulthdl = $con->runQuery($sqlhdl);

$sqlldl = "select max(ldl.id), ldl.* from ldl where patient_id = '".$id."' group by ldl.patient_id order by ldl.id desc limit 1";
$resultldl = $con->runQuery($sqlldl);

$sqltri = "select max(triglycerides.id), triglycerides.* from triglycerides where patient_id = '".$id."' group by triglycerides.patient_id order by triglycerides.id desc limit 1";
$resulttri = $con->runQuery($sqltri);

require_once('tcpdf/config/lang/eng.php');
require_once('tcpdf/tcpdf.php');

class MYPDF extends TCPDF {

	//Page header
	public function Header() {
		// Logo

		$header = '';
		$this->writeHTMLCell($w=0, $h=0, $x='', $y='', $header, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
	}

	//Page header
	public function Footer() {
		// Logo

		$footer = '';
		$this->writeHTMLCell($w=0, $h=0, $x='', $y='', $footer, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
	}
}

// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Nicola Asuni');
$pdf->SetTitle('TCPDF Example 061');
$pdf->SetSubject('TCPDF Tutorial');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set default header data
//$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 061', PDF_HEADER_STRING);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

//set margins
/*$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);*/

//set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

//set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

//set some language-dependent strings
$pdf->setLanguageArray($l);

// ---------------------------------------------------------

// set font
$pdf->SetFont('helvetica', '', 10);

// add a page
$pdf->AddPage();

/* NOTE:
 * *********************************************************
 * You can load external XHTML using :
 *
 * $html = file_get_contents('/path/to/your/file.html');
 *
 * External CSS files will be automatically loaded.
 * Sometimes you need to fix the path of the external CSS.
 * *********************************************************
 */
//$html = file_get_contents('inline-report-2.html');
//$html = <<<EOD
$html = '';
$html .= '<table style="float: left; height: auto; left: 0pt; top: 0pt; width: 525pt;">
	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td scope="row" style="font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt; text-align: left;background-color: #041423; width: 262.5pt;"><img alt="" src="nmac-logo.jpg" /></td>
					<td scope="row" style="background-color: #2ca8e1; width: 262.5pt;"><img alt="" src="nmac-addess.jpg" /></td>
				</tr>
			</table>
		
		</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>	
	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0" width="700">
				<tr>
					<td height="43" align="center" valign="middle"><h2 style="color: #000; font-size: 18.75pt; margin-bottom: 3.75pt;">PATIENT INFORMATION</h2></td>
				</tr>
				<tr>
					<td width="200">
						<table border="0" cellpadding="0" cellspacing="0" width="100%">
							<tr>
								<td height="147" style="font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: 0.75pt; text-align: center;"><img alt="" height="129" src="../'.$result[0]['photo'].'" width="128" /></td>
							</tr>
							<tr>
								<td height="62" style=" style="font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: 0.75pt; line-height: 15pt; text-align: left;"">
								<h2 align="center" style="font-size: 10.5pt; font-weight: 600; left: 0pt; right: 0pt;">'.$result[0]['name'].'</h2>
								<h3 align="center" style="font-size: 9pt; font-weight: 300; left: 0pt; right: 0pt;">Age '.$result[0]['age'].'</h3>
								<h3 align="center" style="font-size: 9pt; font-weight: 300; left: 0pt; right: 0pt;"> D.O.B : '.$result[0]['dob'].'</h3>
								</td>
							</tr>
						</table>					
					</td>
					<td width="500" valign="top">
					
						<table border="0" cellpadding="0" cellspacing="0" width="475">
							<tr>
								<td valign="top">&nbsp;</td>
							</tr>
							<tr>
								<td width="220" align="left" valign="top" scope="col" style="font-weight:300; font-family: Raleway, sans-serif;">
									<h3>Calculation on First Visit</h3>
									Weight : '.$result[0]['weight'].'<br>
									Height : '.$result[0]['height'].'<br>
									
								</td>
								<td width="220" align="left" valign="top" scope="col" style="font-weight:300; font-family: Raleway, sans-serif;">
									<h3>Reported By</h3>
									Date of Admission : '.$result[0]['date_time'].'<br>
									Reported By : '.$result[0]['reportedby'].'<br>
									Generated on &quot; '.date('Y-m-d').'
								</td>
							</tr>
							<tr>
								<td valign="top">&nbsp;</td>
							</tr>
							<tr>
								<td width="220" align="left" valign="top" scope="col" style="font-weight:300; font-family: Raleway, sans-serif;">
									<h3>Location</h3>
									'.$result[0]['address'].'
								</td>
								<td width="220" align="left" valign="top" scope="col" style="font-weight:300; font-family: Raleway, sans-serif;">
									<h3>Contact Details</h3>
									Phone No. : '.$result[0]['phoneno'].'<br>
									Email Id : '.$result[0]['email'].'
								</td>
							</tr>
							<tr>
								<td valign="top">&nbsp;</td>
							</tr>
							<tr>
								<td colspan="2" align="left" valign="top" scope="col" style="font-weight:300; font-family: Raleway, sans-serif;">
									<h3>Medical History</h3>
									'.$result[0]['medical_history'].'
								</td>
							</tr>
						</table>
					
					</td>
				</tr>
			</table>		
		</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0" width="700">
				<tr>
					<th colspan="5"><h2 style="color: #000; font-size: 18.75pt; margin-bottom: 3.75pt; text-align: center;">SCORE CARD KEY</h2></th>
				</tr>
				<tr>
					<td colspan="5">&nbsp;</td>
				</tr>
				<tr>
					<td width="130" align="center"><img src="danger.png" width="24" height="24" /><p style="color: black; text-align: center;">Your at risk extreem dranger of developing major health problems! ( Seek Urgent Medical Attention )</p></td>
					<td width="130" align="center"><img src="red.png" width="25" height="25" /><p style="color: black; text-align: center;">Your at risk of having major health problems!</p></td>
					<td width="130" align="center"><img src="yellow.png" width="25" height="25" /><p style="color: black; text-align: center;">Your at moderate risk of having major health problems!</p></td>
					<td width="130" align="center"><img src="green.png" width="26" height="26" /><p style="color: black; text-align: center;">Excellant Result</p></td>
					<td width="150" align="center">
						&nbsp;
					</td>
				</tr>
			</table>		
		</td>
	</tr>
	
	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0">
				<tr>
					<th><h2 style="color: #000; font-size: 18.75pt; text-align: center;">BODY COMPOSITION</h2></th>
				</tr>
				<tr>
					<th style="font-weight: 600; text-align: center;"><p style="color: black; ">BMI : <span style="color: #0F3;">Underweight (&lt; 18.5)</span> | <span style="color: #060;">Normal (18.5 – 24.9)</span> | <span style="color: #FF0;">Overweight (25 – 29.9)</span> | <span style="color: #F00;">Obese (&gt; 30)</span></p></th>
				</tr>
				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="514">Comments</th>
						</tr>
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">'.$resultbmi[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">'.$resultbmi[0]['bmi'].'<br>';
if(floatval($resultbmi[0]['bmi'])<18.5){ 
	$html .='<img alt="" height="20" src="small-green.png" width="20" />';
}elseif(floatval($resultbmi[0]['bmi'])>=18.5 and floatval($resultbmi[0]['bmi'])<25){ 
	$html .='<img alt="" height="20" src="small-green.png" width="20" />';
}elseif(floatval($resultbmi[0]['bmi'])>=25 and floatval($resultbmi[0]['bmi'])<30){ 
	$html .='<img alt="" height="20" src="small-yellow.png" width="20" />';
}elseif(floatval($resultbmi[0]['bmi'])>30){ 
	$html .='<img alt="" height="20" src="red-small.png" width="20" />';
}
$html .='						</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resultbmi[0]['bmi_description'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0">
				<tr>
					<th><h2 style="color: #000; font-size: 18.75pt; text-align: center;">BLOOD PRESSURE</h2></th>
				</tr>
				<tr>
					<th style="font-weight: 600; text-align: center;"><span style="color: #0F3;">Normal</span> | <span style="color: #FF0;">Borderline (120-139) </span> | <span style="color: #F00;">Hypertension 1 (140-159)</span> | <span style="color: #F00;">Hypertension 2 (&gt;160)</span></th>
				</tr>
				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="514">Comments</th>
						</tr>
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">'.$resultbp[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">'.$resultbp[0]['blood_pressure'].'<br>';
			
							$bpSystolic = explode("/",$resultbp[0]['blood_pressure']);
								
							if(floatval($bpSystolic[1])<=80 and floatval($bpSystolic[0])<=120){
								$html .= '<img alt="" height="20" src="small-green.png" width="20" />';
							}elseif((floatval($bpSystolic[0]) >= 120 and floatval($bpSystolic[0]) <= 139) and (floatval($bpSystolic[1]) >= 80 and floatval($bpSystolic[1]) <= 89)){
								$html .= '<img alt="" height="20" src="small-yellow.png" width="20" />';
							}elseif((floatval($bpSystolic[0]) >= 140 and floatval($bpSystolic[0]) <= 159) and (floatval($bpSystolic[1]) >=90 and floatval($bpSystolic[1]) <= 99)){
								$html .= '<img alt="" height="20" src="small-yellow.png" width="20" />';
							}elseif((floatval($bpSystolic[0]) >= 160) and (floatval($bpSystolic[1])>= 100)){
								$html .= '<img alt="" height="20" src="red-small.png" width="20" />';
							}
							
							
		$html .= '			</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resultbp[0]['blood_pressure_description'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0">
				<tr>
					<th><h2 style="color: #000; font-size: 18.75pt; text-align: center;">TOTAL CHOLESTEROL</h2></th>
				</tr>
				<tr>
					<th style="font-weight: 600; text-align: center;"><span style="color: #0F3;">Desirable (&lt;200) </span> | <span style="color: #FF0;">Borderline (200 – 239)</span> | <span style="color: #F00;">High (&gt;=240)</span></th>
				</tr>
				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="514">Comments</th>
						</tr>
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">'.$resultcholesterol[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">'.$resultcholesterol[0]['cholesterol'].'<br>';
							
							if(floatval($resultcholesterol[0]['cholesterol'])<200){ 
								$html .='<img alt="" height="20" src="small-green.png" width="20" />';
							}elseif(floatval($resultcholesterol[0]['cholesterol'])>=200 and floatval($resultcholesterol[0]['cholesterol'])<=239){ 
								$html .='<img alt="" height="20" src="small-yellow.png" width="20" />';
							}elseif(floatval($resultcholesterol[0]['cholesterol'])>=240){
								$html .='<img alt="" height="20" src="red-small.png" width="20" />';
							}
							
					$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resultcholesterol[0]['cholesterol_description'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0">
				<tr>
					<th><h2 style="color: #000; font-size: 18.75pt; text-align: center;">HDL</h2></th>
				</tr>
				<tr>
					<th style="font-weight: 600; text-align: center;"><span style="color: #0F3;">Normal (&gt;=50) </span> | <span style="color: #F00;">Low (&lt; 50)</span></th>
				</tr>
				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="514">Comments</th>
						</tr>
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">'.$resulthdl[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">'.$resulthdl[0]['hdl'].'<br>';
							if(floatval($resulthdl[0]['hdl'])>=50){ 
								$html .='<img alt="" height="20" src="small-green.png" width="20" />';
							}elseif(floatval($resulthdl[0]['hdl'])<50){ 
								$html .='<img alt="" height="20" src="red-small.png" width="20" />';
							}
							
							
						$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resulthdl[0]['hdl_description'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0">
				<tr>
					<th><h2 style="color: #000; font-size: 18.75pt; text-align: center;">LDL</h2></th>
				</tr>
				<tr>
					<th style="font-weight: 600; text-align: center;"><span style="color: #0F3;">Optimal (&lt;100) </span> | <span style="color: #060;">Near Optimal (100-129) </span> | <span style="color: #FF0;">Borderline (130 – 159) </span> | <span style="color: #F00;">High (200 – 499) </span> | <span style="color: #F00;">Very High (&gt;=500)</span></th>
				</tr>
				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="514">Comments</th>
						</tr>
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">'.$resultldl[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">'.$resultldl[0]['ldl'].'<br>';
							
							if(floatval($resultldl[0]['ldl'])<100){ 
								$html .='<img alt="" height="20" src="small-green.png" width="20" />';
							}elseif(floatval($resultldl[0]['ldl'])>=100 and floatval($resultldl[0]['ldl'])<200){ 
								$html .='<img alt="" height="20" src="small-yellow.png" width="20" />';
							}elseif(floatval($resultldl[0]['ldl'])>=200 and floatval($resultldl[0]['ldl'])<500){
								$html .='<img alt="" height="20" src="red-small.png" width="20" />';
							}elseif(floatval($resultldl[0]['ldl'])>500){
								$html .='<img alt="" height="20" src="red-small.png" width="20" />';
							}
							
							
						$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resultldl[0]['ldl_description'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0">
				<tr>
					<th><h2 style="color: #000; font-size: 18.75pt; text-align: center;">TRIGLYCERIDES</h2></th>
				</tr>
				<tr>
					<th style="font-weight: 600; text-align: center;"><span style="color: #0F3;">Optimal (&lt;150) </span> | <span style="color: #060;">Borderline (150 – 199) </span> | <span style="color: #FF0;">High (200 – 499)</span> | <span style="color: #F00;">Very High (&gt;=500)</span></th>
				</tr>
				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="514">Comments</th>
						</tr>
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">'.$resulttri[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">'.$resulttri[0]['triglycerides'].'<br>';
							
						if(floatval($resulttri[0]['triglycerides'])<150){ 
							$html .='<img alt="" height="20" src="small-green.png" width="20" />';
						}elseif(floatval($resulttri[0]['triglycerides'])>=150 and floatval($resulttri[0]['triglycerides'])<200){ 
							$html .='<img alt="" height="20" src="small-yellow.png" width="20" />';
						}elseif(floatval($resulttri[0]['triglycerides'])>=200 and floatval($resulttri[0]['triglycerides'])<500){ 
							$html .='<img alt="" height="20" src="red-small.png" width="20" />';
						}elseif(floatval($resulttri[0]['triglycerides'])>500){ 
							$html .='<img alt="" height="20" src="red-small.png" width="20" />';
						}
							
							
						$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resulttri[0]['triglycerides_description'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0">
				<tr>
					<th><h2 style="color: #000; font-size: 18.75pt; text-align: center;">DIABETES</h2></th>
				</tr>
				<tr>
					<th style="font-weight: 600; text-align: center;">HBa1c : <span style="color: #0F3;">Normal (&lt; 5.6) </span> | <span style="color: #FF0;">Prediabetes (5.7 – 6.4)</span> | <span style="color: #F00;">Diabetes (&gt;= 6.5) </span></th>
				</tr>
				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="514">Comments</th>
						</tr>
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">'.$resulthba1c[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">'.$resulthba1c[0]['hba1c'].'<br>';
							
							
						if(floatval($resulthba1c[0]['hba1c'])<5.6){
							$html .='<img alt="" height="20" src="small-green.png" width="20" />';
						}elseif(floatval($resulthba1c[0]['hba1c'])>=5.6 and floatval($resulthba1c[0]['hba1c'])<6.5){ 
							$html .='<img alt="" height="20" src="small-yellow.png" width="20" />';
						}elseif(floatval($resulthba1c[0]['hba1c'])>=6.5){ 
							$html .='<img alt="" height="20" src="red-small.png" width="20" />';
						}
		
						$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resulthba1c[0]['hba1c_description'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0">
				<tr>
					<th><h2 style="color: #000; font-size: 18.75pt; text-align: center;">KIDNEY DISEASE</h2></th>
				</tr>
				<tr>
					<th style="font-weight: 600; text-align: center;"><span style="color: #0F3;">Normal (60 to 120) </span> | <span style="color: #FF0;">16 to 59</span> |  <span style="color: #F00;">Danger (0 to 15) </span></th>
				</tr>
				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="514">Comments</th>
						</tr>
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">'.$resultegfr[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">'.$resultegfr[0]['egfr'].'<br>';
							
							
		if(floatval($resultegfr[0]['egfr'])>=60.1 and floatval($resultegfr[0]['egfr'])<120){
			$html .= '<img alt="" height="20" src="small-green.png" width="20" />';
		}elseif(floatval($resultegfr[0]['egfr'])>=15.1 and floatval($resultegfr[0]['egfr'])<=60){
			$html .= '<img alt="" height="20" src="small-yellow.png" width="20" />';
		}elseif(floatval($resultegfr[0]['egfr'])<=15){ 
			$html .= '<img alt="" height="20" src="red-small.png" width="20" />';
		}
							
							
						$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resultegfr[0]['egfr_description'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<td height="20">&nbsp;</td>
	</tr>
	<tr>
		<td>
			<table width="700" border="0" cellspacing="0" cellpadding="0">
				<tbody>
					<tr>
						<td height="30" align="center" valign="middle"><h2 style="color:#000; font-size: 18.75pt; margin-bottom: 2pt;">For An appointment : (441)293-5476</h2></td>
					</tr>
					<tr>
						<td height="5" align="center" valign="top"><img src="partners-logos.jpg" width="439" height="97" alt=""/></td>
					</tr>
				</tbody>
			</table>
		</td>
	</tr>
	
</table>';

//EOD;

// output the HTML content
//$pdf->writeHTML($html, true, false, true, false, '');
echo $html; die();
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// *******************************************************************
// HTML TIPS & TRICKS
// *******************************************************************

// REMOVE CELL PADDING
//
// $pdf->SetCellPadding(0);
// 
// This is used to remove any additional vertical space inside a 
// single cell of text.

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// REMOVE TAG TOP AND BOTTOM MARGINS
//
// $tagvs = array('p' => array(0 => array('h' => 0, 'n' => 0), 1 => array('h' => 0, 'n' => 0)));
// $pdf->setHtmlVSpace($tagvs);
// 
// Since the CSS margin command is not yet implemented on TCPDF, you
// need to set the spacing of block tags using the following method.

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// SET LINE HEIGHT
//
// $pdf->setCellHeightRatio(1.25);
// 
// You can use the following method to fine tune the line height
// (the number is a percentage relative to font height).

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// CHANGE THE PIXEL CONVERSION RATIO
//
// $pdf->setImageScale(0.47);
// 
// This is used to adjust the conversion ratio between pixels and 
// document units. Increase the value to get smaller objects.
// Since you are using pixel unit, this method is important to set the
// right zoom factor.
// 
// Suppose that you want to print a web page larger 1024 pixels to 
// fill all the available page width.
// An A4 page is larger 210mm equivalent to 8.268 inches, if you 
// subtract 13mm (0.512") of margins for each side, the remaining 
// space is 184mm (7.244 inches).
// The default resolution for a PDF document is 300 DPI (dots per 
// inch), so you have 7.244 * 300 = 2173.2 dots (this is the maximum 
// number of points you can print at 300 DPI for the given width).
// The conversion ratio is approximatively 1024 / 2173.2 = 0.47 pt/dots
// If the web page is larger 1280 pixels, on the same A4 page the 
// conversion ratio to use is 1280 / 2173.2 = 0.59 pixels/dots

// *******************************************************************

// reset pointer to the last page
$pdf->lastPage();

// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output('report.pdf', 'I');

//============================================================+
// END OF FILE                                                
//============================================================+
