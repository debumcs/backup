<?php
include_once('dbconnection.php');
$con = new dbconnection();
$con->setConnection();

$id = $_GET['id'];

$sql = "select * from patient where id = '".$_GET['id']."'";
$result = $con->runQuery($sql);

$sqlbmi = "select max(bmi.id), bmi.* from bmi where patient_id = '".$_GET['id']."' group by bmi.patient_id order by bmi.id desc limit 1";
$resultbmi = $con->runQuery($sqlbmi);

$sqlascvd = "select max(ascvd.id), ascvd.* from ascvd where patient_id = '".$_GET['id']."' group by ascvd.patient_id order by ascvd.id desc limit 1 ";
$resultascvd = $con->runQuery($sqlascvd);

$sqlbp = "select max(blood_pressure.id), blood_pressure.* from blood_pressure where patient_id = '".$_GET['id']."' group by blood_pressure.patient_id order by blood_pressure.id desc limit 1";
$resultbp = $con->runQuery($sqlbp);

$sqlcholesterol = "select max(cholesterol.id), cholesterol.* from cholesterol where patient_id = '".$_GET['id']."' group by cholesterol.patient_id order by cholesterol.id desc limit 1";
$resultcholesterol = $con->runQuery($sqlcholesterol);

$sqlegfr = "select max(egfr.id), egfr.* from egfr where patient_id = '".$_GET['id']."' group by egfr.patient_id order by egfr.id desc limit 1";
$resultegfr = $con->runQuery($sqlegfr);

$sqlhba1c = "select max(hba1c.id), hba1c.* from hba1c where patient_id = '".$_GET['id']."' group by hba1c.patient_id order by hba1c.id desc limit 1";
$resulthba1c = $con->runQuery($sqlhba1c);

$sqlhdl = "select max(hdl.id), hdl.* from hdl where patient_id = '".$_GET['id']."' group by hdl.patient_id order by hdl.id desc limit 1";
$resulthdl = $con->runQuery($sqlhdl);

$sqlldl = "select max(ldl.id), ldl.* from ldl where patient_id = '".$_GET['id']."' group by ldl.patient_id order by ldl.id desc limit 1";
$resultldl = $con->runQuery($sqlldl);

$sqltri = "select max(triglycerides.id), triglycerides.* from triglycerides where patient_id = '".$_GET['id']."' group by triglycerides.patient_id order by triglycerides.id desc limit 1";
$resulttri = $con->runQuery($sqltri);



?>
<style rel="stylesheet" type="text/css">@charset "utf-8";
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}

body,td,th {
	line-height: 20px;
	font-family: 'Raleway', sans-serif;
	letter-spacing: 1px;
	text-align: justify;
	font-size: 10px;

}

a {
	text-decoration: none;
	}

a:hover {
	text-decoration: none;
}

#wrapper {
	float: left;
	left: 0px;
	top: 0px;
	width: 700px;
	height: auto;
}
#header {
	float: left;
	left: 0px;
	top: 0px;
	width: 700px;
	height: 88px;
}
.nmac-Logo {
	float: left;
	left: 0px;
	top: 0px;
	width: 350px;
	height: 88px;
	background-color:#041423;
}
.details-address {
	float: right;
	width: 350px;
	height: 88px;
	background-color: #2ca8e1;
}
.details-address-report {
	float: right;
	width: 300px;
	height: 25px;
	color: #fff;
	padding-top: 14px;
	padding-right: 12px;
	padding-bottom: 5px;
}
.details-address-health {
	float: right;
	left: 0px;
	top: 0px;
	width: 250px;
	height: 22px;
}
.details-address-health h1 {
	float: right;
	font-size: 21px;
	font-weight: 800;
	text-decoration: none;
	padding: 0px;
	margin: 0px;
	color: #FFF;
}
.details-contact {
	float: right;
	left: 0px;
	right: 0px;
	width: 125px;
	height: 30px;
}
.details-contact-icon {
	float: left;
	left: 0px;
	right: 0px;
	width: 11px;
	height: 11px;
	margin-top: 5px;
	margin-right: 5px;
	margin-bottom: 2px;
}
.details-contact-text-box {
	float: left;
	left: 0px;
	right: 0px;
	width: 125px;
	height: 11px;
	margin-bottom: 2px;
	color: #fff;
}
.details-contact-text {
	float: left;
	left: 0px;
	right: 0px;
	width: 92px;
	height: 11px;
	margin-bottom: 2px;
	color: #fff;
}

.details-address-info{
	left: 0px;
	right: 0px;
	width: 110px;
	height: 30px;
	float: left;
	margin-left: 51px;
	line-height: 0.5px;
	font-size: 9px;
}
.box {
	left: 0px;
	right: 0px;
	width: 700px;
	height: auto;
	float: left;
	margin-bottom: 30px;
}</style>
  <style rel="stylesheet" type="text/css">@font-face {
font-family: 'Raleway';
font-style: normal;
font-weight: 100;
src: local('Raleway Thin'), local('Raleway-Thin'), url(https://fonts.gstatic.com/s/raleway/v9/RJMlAoFXXQEzZoMSUteGWD8E0i7KZn-EPnyo3HZu7kw.woff) format('woff');
}
@font-face {
font-family: 'Raleway';
font-style: normal;
font-weight: 200;
src: local('Raleway ExtraLight'), local('Raleway-ExtraLight'), url(https://fonts.gstatic.com/s/raleway/v9/8KhZd3VQBtXTAznvKjw-kxsxEYwM7FgeyaSgU71cLG0.woff) format('woff');
}
@font-face {
font-family: 'Raleway';
font-style: normal;
font-weight: 300;
src: local('Raleway Light'), local('Raleway-Light'), url(https://fonts.gstatic.com/s/raleway/v9/-_Ctzj9b56b8RgXW8FAriRsxEYwM7FgeyaSgU71cLG0.woff) format('woff');
}
@font-face {
font-family: 'Raleway';
font-style: normal;
font-weight: 400;
src: local('Raleway'), url(https://fonts.gstatic.com/s/raleway/v9/IczWvq5y_Cwwv_rBjOtT0w.woff) format('woff');
}
@font-face {
font-family: 'Raleway';
font-style: normal;
font-weight: 500;
src: local('Raleway Medium'), local('Raleway-Medium'), url(https://fonts.gstatic.com/s/raleway/v9/CcKI4k9un7TZVWzRVT-T8xsxEYwM7FgeyaSgU71cLG0.woff) format('woff');
}
@font-face {
font-family: 'Raleway';
font-style: normal;
font-weight: 600;
src: local('Raleway SemiBold'), local('Raleway-SemiBold'), url(https://fonts.gstatic.com/s/raleway/v9/xkvoNo9fC8O2RDydKj12bxsxEYwM7FgeyaSgU71cLG0.woff) format('woff');
}
@font-face {
font-family: 'Raleway';
font-style: normal;
font-weight: 700;
src: local('Raleway Bold'), local('Raleway-Bold'), url(https://fonts.gstatic.com/s/raleway/v9/JbtMzqLaYbbbCL9X6EvaIxsxEYwM7FgeyaSgU71cLG0.woff) format('woff');
}
@font-face {
font-family: 'Raleway';
font-style: normal;
font-weight: 800;
src: local('Raleway ExtraBold'), local('Raleway-ExtraBold'), url(https://fonts.gstatic.com/s/raleway/v9/1ImRNPx4870-D9a1EBUdPBsxEYwM7FgeyaSgU71cLG0.woff) format('woff');
}
@font-face {
font-family: 'Raleway';
font-style: normal;
font-weight: 900;
src: local('Raleway Heavy'), local('Raleway-Heavy'), url(https://fonts.gstatic.com/s/raleway/v9/PKCRbVvRfd5n7BTjtGiFZBsxEYwM7FgeyaSgU71cLG0.woff) format('woff');
}
</style>
  <style rel="stylesheet" type="text/css">
<!--

.tabl-text{
margin-left:10px;
margin-right:10px;
}
.tabl-div{margin-top: -50px;}
.tabl{
  border: 1px dotted #CCC;
  border-collapse: collapse;
	
}



-->
</style>
 </head>
 <body style="background-color: #FFFFFF; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px; text-align: justify;">
  <div id="wrapper" style="float: left; height: auto; left: 0px; top: 0px; width: 700px;">
   <div style="float: left; height: 88px; margin-bottom: 20px; width: 700px;">
    <div class="nmac-Logo" style="background-color: #041423; float: left; height: 88px; left: 0px; top: 0px; width: 350px;"><img alt="NMAC Logo" height="88" src="http://urips.co.in/nmac-health/report-design/new/Nmac-Logo.png" width="281" /></div>
    <div class="details-address" style="background-color: #2ca8e1; float: right; height: 88px; width: 350px;">
     <div class="details-address-report" style="color: #fff; float: right; height: 25px; padding-bottom: 5px; padding-right: 12px; padding-top: 14px; width: 300px;">
      <div class="details-address-health" style="float: right; height: 22px; left: 0px; top: 0px; width: 250px;">
       <h1 style="color: #FFF; float: right; font-size: 21px; font-weight: 800; margin: 0px; padding: 0px; text-decoration: none;">HEALTH REPORT CARD</h1>
      </div>
      <div class="details-address-info" style="float: left; font-size: 9px; height: 30px; left: 0px; line-height: 0.5px; margin-left: 51px; right: 0px; width: 110px;">
       <p>7 North Shore Road,</p>
       <p>Devonshire, DV01, </p> Bermuda </div>
      <div class="details-contact" style="float: right; height: 30px; left: 0px; right: 0px; width: 125px;">
       <div class="details-contact-text-box" style="color: #fff; float: left; height: 11px; left: 0px; margin-bottom: 2px; right: 0px; width: 125px;">
        <div class="details-contact-icon" style="float: left; height: 11px; left: 0px; margin-bottom: 2px; margin-right: 5px; margin-top: 5px; right: 0px; width: 11px;"><img alt="mail" height="12" src="http://urips.co.in/nmac-health/report-design/new/mail.png" width="11" /></div>
        <div class="details-contact-text" style="color: #fff; float: left; height: 11px; left: 0px; margin-bottom: 2px; right: 0px; width: 92px;">manager@nmac.bm</div>
       </div>
       <div class="details-contact-text-box" style="color: #fff; float: left; height: 11px; left: 0px; margin-bottom: 2px; right: 0px; width: 125px;">
        <div class="details-contact-icon" style="float: left; height: 11px; left: 0px; margin-bottom: 2px; margin-right: 5px; margin-top: 5px; right: 0px; width: 11px;"><img alt="mail" height="12" src="http://urips.co.in/nmac-health/report-design/new/phone.png" width="11" /></div>
        <div class="details-contact-text" style="color: #fff; float: left; height: 11px; left: 0px; margin-bottom: 2px; right: 0px; width: 92px;">(441) 293-5476</div>
       </div>
       <div class="details-contact-text-box" style="color: #fff; float: left; height: 11px; left: 0px; margin-bottom: 2px; right: 0px; width: 125px;">
        <div class="details-contact-icon" style="float: left; height: 11px; left: 0px; margin-bottom: 2px; margin-right: 5px; margin-top: 5px; right: 0px; width: 11px;"><img alt="mail" height="12" src="http://urips.co.in/nmac-health/report-design/new/web.png" width="11" /></div>
        <div class="details-contact-text" style="color: #fff; float: left; height: 11px; left: 0px; margin-bottom: 2px; right: 0px; width: 92px;">www.nmac.bm</div>
       </div>
      </div>
     </div>
    </div>
   </div>
   <div style="background-color: rgba(245, 245, 245, 0.47); border-bottom: 1px solid #CCC; height: 380px; margin-top: 26px; width: 700px;">
    <div style="width: 688px;">
     <h2 style="color: #000; font-size: 25px; margin-bottom: 5px; text-align: center;">PATIENT INFORMATION</h2>
    </div>
    <div style="float: left; height: 230px; line-height: 0.5px; margin-left: 10px; width: 175px;">
     <h2 align="center">After Sumit</h2>
     <h4 align="center">Age 32</h4>
     <h4 align="center">D.O.B : 15-01-1992 </h4>
    </div>
    <div style="float: right; margin-left: 10px; width: 450px;">
     <div style="float: left; line-height: 0.5; margin-right: 30px; width: 190px;">
      <h3 style="color: black;">Calculation on First Visit</h3>
      <p>Weight : 82kg</p>
      <p>Height : 178cm</p>
      <p>Race : African</p>
      <p>Health Status : Diabetes</p>
     </div>
     <div style="float: right; line-height: 0.5; width: 220px;">
      <h3 style="color: black;">Reported By</h3>
      <p>Date of Admission : 30 jan, 2016</p>
      <p>Reported By : Dr. Kyjuan Brown</p>
      <p>Generated Report &quot; 31 Jan 2016</p>
     </div>
    </div>
    <div style="float: right; margin-left: 10px; width: 450px;">
     <div style="float: left; line-height: 0.5; margin-right: 30px; width: 190px;">
      <h3 style="color: black;">Location</h3>
      <p>723, North Shore Road</p>
      <p>Devonshire DV123 Bermuda</p>
     </div>
     <div style="float: right; line-height: 0.5; width: 220px;">
      <h3 style="color: black;">Contact Details</h3>
      <p>Phone No. : +91 00 00 0000 00</p>
      <p>Email Id : xyz@gmail.com</p>
     </div>
    </div>
    <div style="float: left; margin-right: 16px; width: 450px;">
     <div style="float: right; line-height: 0.5; width: 450px;">
      <h3 style="color: black;">Medical History</h3>
      <p style="color: black; line-height: 15.5px;">lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
     </div>
    </div>
   </div>
   <div style="border-bottom: 1px solid #CCC; height: 250px; width: 700px;">
    <div style="width: 688px;">
     <h2 style="color: #000; font-size: 25px; margin-bottom: 5px; text-align: center;">SCORE CARD KEY</h2>
    </div>
    <div style="float: left; line-height: 0.5px; margin-left: 30px; margin-top: 16px; width: 120px;"><img src="http://urips.co.in/nmac-health/report-design/new/danger.png" style="margin-left: 20px;" /><p style="color: black; line-height: 15.5px; text-align: center;">Your at risk extreem dranger of developing major health problems! ( Seek Urgent Medical Attention )</p>
    </div>
    <div style="float: left; line-height: 0.5px; margin-left: 10px; margin-top: 16px; width: 120px;"><img src="http://urips.co.in/nmac-health/report-design/new/red.png" style="margin-left: 20px;" /><p style="color: black; line-height: 15.5px; text-align: center;">Your at risk of having major health problems!</p>
    </div>
    <div style="float: left; line-height: 0.5px; margin-left: 10px; margin-top: 16px; width: 120px;"><img src="http://urips.co.in/nmac-health/report-design/new/yellow.png" style="margin-left: 20px;" /><p style="color: black; line-height: 15.5px; text-align: center;">Your at moderate risk of having major health problems!</p>
    </div>
    <div style="float: left; line-height: 0.5px; margin-left: 10px; margin-top: 16px; width: 120px;"><img src="http://urips.co.in/nmac-health/report-design/new/green.png" style="margin-left: 20px;" /><p style="color: black; line-height: 15.5px; text-align: center;">Excellant Result</p>
    </div>
    <div style="border: 1px solid #333; float: left; line-height: 0.5px; margin-left: 10px; margin-top: 16px; width: 140px;">
     <h3 align="center">Current Status</h3>
     <p style="color: black; line-height: 15.5px; text-align: center;"><input type="checkbox" /> Excellant</p>
     <p style="color: black; line-height: 15.5px; text-align: center;"><input type="checkbox" /> Very Good</p>
     <p style="color: black; line-height: 15.5px; text-align: center;"><input type="checkbox" /> Good</p>
     <p style="color: black; line-height: 15.5px; text-align: center;"><input type="checkbox" /> Average</p>
     <p style="color: black; line-height: 15.5px; text-align: center;"><input type="checkbox" /> Poor</p>
    </div>
   </div>
   <div style="background-color: #fff; height: auto; marginborder-bottom: 1px solid #CCC; width: 700px;">
    <div style="width: 688px;">
     <h2 style="color: #000; font-size: 25px; margin-bottom: 5px; text-align: center;">BODY COMPOSITION</h2>
    </div>
    <div style="float: left; font-weight: 600; line-height: 0.5px; margin-top: 0px; text-align: center; width: 688px;">
     <p style="color: black; font-size: 11px; line-height: 15.5px;">BMI : <span style="color: #0F3;">Underweight (< 18.5)</span> | <span style="color: #060;">Normal (18.5 – 24.9)</span> | <span style="color: #FF0;">Overweight (25 – 29.9)</span> | <span style="color: #F00;">Obese (> 30)</span></p>
    </div>
    <div style="margin-left: 12px; margin-right: 12px; padding-bottom: 20px;">
     <table class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; width: 100%;">
      <tr>
       <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center; width: 65px;" width="65">Date</th>
       <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center; width: 65px;" width="65">Score</th>
       <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="545">Comments</th>
      </tr>
      <tr>
       <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
        <table border="0" cellpadding="0" cellspacing="0" width="100%">
         <tbody>
          <tr>
           <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="63">10-01-16</th>
          </tr>
         </tbody>
        </table>
       </td>
       <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
        <table border="0" cellpadding="0" cellspacing="0" width="100%">
         <tbody>
          <tr>
           <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="100%">22</th>
          </tr>
          <tr>
           <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;"><img alt="" height="20" src="http://urips.co.in/nmac-health/report-design/new/red-small.png" width="20" /></th>
          </tr>
         </tbody>
        </table>
       </td>
       <td align="justify" class="tabl " style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify; width: 320px;">
        <p class="tabl-text" style="margin-left: 10px; margin-right: 10px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
       </td>
      </tr>
      <tr>
       <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
        <table border="0" cellpadding="0" cellspacing="0" width="100%">
         <tbody>
          <tr>
           <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="63">10-01-16</th>
          </tr>
         </tbody>
        </table>
       </td>
       <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
        <table border="0" cellpadding="0" cellspacing="0" width="100%">
         <tbody>
          <tr>
           <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="100%">22</th>
          </tr>
          <tr>
           <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;"><img alt="" height="20" src="http://urips.co.in/nmac-health/report-design/new/small-yellow.png" width="20" /></th>
          </tr>
         </tbody>
        </table>
       </td>
       <td align="justify" class="tabl " style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify; width: 320px;">
        <p class="tabl-text" style="margin-left: 10px; margin-right: 10px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
       </td>
      </tr>
     </table>
    </div>
    <div style="margin-top: 20px; width: 700px;">
     <div style="width: 100%;">
      <h2 style="color: #2ca8e1; font-size: 30px; margin-bottom: 5px; text-align: center;">HEART DISEASE</h2>
     </div>
     <div class="box" style="float: left; height: auto; left: 0px; margin-bottom: 30px; right: 0px; width: 700px;">
      <div style="width: 688;">
       <h3 style="color: #000; font-size: 20px; margin-bottom: 5px; text-align: center;">BLOOD PRESSURE</h3>
      </div>
      <div style="float: left; line-height: 0.5px; width: 688px;">
       <p style="color: black; font-size: 11px; font-weight: 600; line-height: 15.5px; text-align: center;">BMI : <span style="color: #0F3;">Desirable (< 200) </span> | <span style="color: #060;"> Borderline (200 – 239)</span> | <span style="color: #F00;">High (>=240)</span></p>
      </div>
      <div style="margin-left: 12px; margin-right: 12px;">
       <table class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; width: 100%;">
        <tr>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center; width: 65px;" width="65">Date</th>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center; width: 65px;" width="65">Score</th>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="514">Comments</th>
        </tr>
        <tr>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="63">10-01-16</th>
            </tr>
           </tbody>
          </table>
         </td>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="100%">220/98</th>
            </tr>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;"><img alt="" height="20" src="http://urips.co.in/nmac-health/report-design/new/red-small.png" width="20" /></th>
            </tr>
           </tbody>
          </table>
         </td>
         <td align="justify" class="tabl " style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify; width: 320px;">
          <p class="tabl-text" style="margin-left: 10px; margin-right: 10px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
         </td>
        </tr>
        <tr>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="63">10-01-16</th>
            </tr>
           </tbody>
          </table>
         </td>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="100%">180/67</th>
            </tr>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;"><img alt="" height="20" src="http://urips.co.in/nmac-health/report-design/new/small-green.png" width="20" /></th>
            </tr>
           </tbody>
          </table>
         </td>
         <td align="justify" class="tabl " style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify; width: 320px;">
          <p class="tabl-text" style="margin-left: 10px; margin-right: 10px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
         </td>
        </tr>
       </table>
      </div>
     </div>
     <div class="box" style="float: left; height: auto; left: 0px; margin-bottom: 30px; right: 0px; width: 700px;">
      <div style="width: 688;">
       <h3 style="color: #000; font-size: 20px; margin-bottom: 5px; text-align: center;">TOTAL CHOLESTEROL</h3>
      </div>
      <div style="float: left; line-height: 0.5px; width: 688px;">
       <p style="color: black; font-size: 11px; font-weight: 600; line-height: 15.5px; text-align: center;">BMI : <span style="color: #0F3;">Desirable (< 200) </span> | <span style="color: #060;"> Borderline (200 – 239)</span> | <span style="color: #F00;">High (>=240)</span></p>
      </div>
      <div style="margin-left: 12px; margin-right: 12px;">
       <table class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; width: 100%;">
        <tr>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center; width: 65px;" width="65">Date</th>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center; width: 65px;" width="65">Score</th>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="514">Comments</th>
        </tr>
        <tr>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="63">10-01-16</th>
            </tr>
           </tbody>
          </table>
         </td>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="100%">220/98</th>
            </tr>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;"><img alt="" height="20" src="http://urips.co.in/nmac-health/report-design/new/red-small.png" width="20" /></th>
            </tr>
           </tbody>
          </table>
         </td>
         <td align="justify" class="tabl " style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify; width: 320px;">
          <p class="tabl-text" style="margin-left: 10px; margin-right: 10px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
         </td>
        </tr>
        <tr>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="63">10-01-16</th>
            </tr>
           </tbody>
          </table>
         </td>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="100%">180/67</th>
            </tr>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;"><img alt="" height="20" src="http://urips.co.in/nmac-health/report-design/new/small-green.png" width="20" /></th>
            </tr>
           </tbody>
          </table>
         </td>
         <td align="justify" class="tabl " style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify; width: 320px;">
          <p class="tabl-text" style="margin-left: 10px; margin-right: 10px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
         </td>
        </tr>
       </table>
      </div>
     </div>
     <div class="box" style="float: left; height: auto; left: 0px; margin-bottom: 30px; right: 0px; width: 700px;">
      <div style="width: 688;">
       <h3 style="color: #000; font-size: 20px; margin-bottom: 5px; text-align: center;">HDL</h3>
      </div>
      <div style="float: left; line-height: 0.5px; width: 688px;">
       <p style="color: black; font-size: 11px; font-weight: 600; line-height: 15.5px; text-align: center;">BMI : <span style="color: #0F3;">Desirable (< 200) </span> | <span style="color: #060;"> Borderline (200 – 239)</span> | <span style="color: #F00;">High (>=240)</span></p>
      </div>
      <div style="margin-left: 12px; margin-right: 12px;">
       <table class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; width: 100%;">
        <tr>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center; width: 65px;" width="65">Date</th>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center; width: 65px;" width="65">Score</th>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="514">Comments</th>
        </tr>
        <tr>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="63">10-01-16</th>
            </tr>
           </tbody>
          </table>
         </td>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="100%">220/98</th>
            </tr>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;"><img alt="" height="20" src="http://urips.co.in/nmac-health/report-design/new/red-small.png" width="20" /></th>
            </tr>
           </tbody>
          </table>
         </td>
         <td align="justify" class="tabl " style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify; width: 320px;">
          <p class="tabl-text" style="margin-left: 10px; margin-right: 10px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
         </td>
        </tr>
        <tr>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="63">10-01-16</th>
            </tr>
           </tbody>
          </table>
         </td>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="100%">180/67</th>
            </tr>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;"><img alt="" height="20" src="http://urips.co.in/nmac-health/report-design/new/small-green.png" width="20" /></th>
            </tr>
           </tbody>
          </table>
         </td>
         <td align="justify" class="tabl " style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify; width: 320px;">
          <p class="tabl-text" style="margin-left: 10px; margin-right: 10px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
         </td>
        </tr>
       </table>
      </div>
     </div>
     <div class="box" style="float: left; height: auto; left: 0px; margin-bottom: 30px; right: 0px; width: 700px;">
      <div style="width: 688;">
       <h3 style="color: #000; font-size: 20px; margin-bottom: 5px; text-align: center;">LDL</h3>
      </div>
      <div style="float: left; line-height: 0.5px; width: 688px;">
       <p style="color: black; font-size: 11px; font-weight: 600; line-height: 15.5px; text-align: center;">BMI : <span style="color: #0F3;">Desirable (< 200) </span> | <span style="color: #060;"> Borderline (200 – 239)</span> | <span style="color: #F00;">High (>=240)</span></p>
      </div>
      <div style="margin-left: 12px; margin-right: 12px;">
       <table class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; width: 100%;">
        <tr>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center; width: 65px;" width="65">Date</th>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center; width: 65px;" width="65">Score</th>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="514">Comments</th>
        </tr>
        <tr>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="63">10-01-16</th>
            </tr>
           </tbody>
          </table>
         </td>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="100%">220/98</th>
            </tr>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;"><img alt="" height="20" src="http://urips.co.in/nmac-health/report-design/new/red-small.png" width="20" /></th>
            </tr>
           </tbody>
          </table>
         </td>
         <td align="justify" class="tabl " style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify; width: 320px;">
          <p class="tabl-text" style="margin-left: 10px; margin-right: 10px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
         </td>
        </tr>
        <tr>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="63">10-01-16</th>
            </tr>
           </tbody>
          </table>
         </td>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="100%">180/67</th>
            </tr>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;"><img alt="" height="20" src="http://urips.co.in/nmac-health/report-design/new/small-green.png" width="20" /></th>
            </tr>
           </tbody>
          </table>
         </td>
         <td align="justify" class="tabl " style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify; width: 320px;">
          <p class="tabl-text" style="margin-left: 10px; margin-right: 10px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
         </td>
        </tr>
       </table>
      </div>
     </div>
     <div class="box" style="float: left; height: auto; left: 0px; margin-bottom: 30px; right: 0px; width: 700px;">
      <div style="width: 688;">
       <h3 style="color: #000; font-size: 20px; margin-bottom: 5px; text-align: center;">TRIGLYCERIDES</h3>
      </div>
      <div style="float: left; line-height: 0.5px; width: 688px;">
       <p style="color: black; font-size: 11px; font-weight: 600; line-height: 15.5px; text-align: center;">BMI : <span style="color: #0F3;">Desirable (< 200) </span> | <span style="color: #060;"> Borderline (200 – 239)</span> | <span style="color: #F00;">High (>=240)</span></p>
      </div>
      <div style="margin-left: 12px; margin-right: 12px;">
       <table class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; width: 100%;">
        <tr>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center; width: 65px;" width="65">Date</th>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center; width: 65px;" width="65">Score</th>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="514">Comments</th>
        </tr>
        <tr>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="63">10-01-16</th>
            </tr>
           </tbody>
          </table>
         </td>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="100%">220/98</th>
            </tr>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;"><img alt="" height="20" src="http://urips.co.in/nmac-health/report-design/new/red-small.png" width="20" /></th>
            </tr>
           </tbody>
          </table>
         </td>
         <td align="justify" class="tabl " style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify; width: 320px;">
          <p class="tabl-text" style="margin-left: 10px; margin-right: 10px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
         </td>
        </tr>
        <tr>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="63">10-01-16</th>
            </tr>
           </tbody>
          </table>
         </td>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="100%">180/67</th>
            </tr>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;"><img alt="" height="20" src="http://urips.co.in/nmac-health/report-design/new/small-green.png" width="20" /></th>
            </tr>
           </tbody>
          </table>
         </td>
         <td align="justify" class="tabl " style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify; width: 320px;">
          <p class="tabl-text" style="margin-left: 10px; margin-right: 10px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
         </td>
        </tr>
       </table>
      </div>
     </div>
     <div class="box" style="float: left; height: auto; left: 0px; margin-bottom: 30px; right: 0px; width: 700px;">
      <div style="width: 688;">
       <h3 style="color: #000; font-size: 20px; margin-bottom: 5px; text-align: center;">DIABETES</h3>
      </div>
      <div style="float: left; line-height: 0.5px; width: 688px;">
       <p style="color: black; font-size: 11px; font-weight: 600; line-height: 15.5px; text-align: center;">BMI : <span style="color: #0F3;">Desirable (< 200) </span> | <span style="color: #060;"> Borderline (200 – 239)</span> | <span style="color: #F00;">High (>=240)</span></p>
      </div>
      <div style="margin-left: 12px; margin-right: 12px;">
       <table class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; width: 100%;">
        <tr>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center; width: 65px;" width="65">Date</th>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center; width: 65px;" width="65">Score</th>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="514">Comments</th>
        </tr>
        <tr>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="63">10-01-16</th>
            </tr>
           </tbody>
          </table>
         </td>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="100%">220/98</th>
            </tr>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;"><img alt="" height="20" src="http://urips.co.in/nmac-health/report-design/new/red-small.png" width="20" /></th>
            </tr>
           </tbody>
          </table>
         </td>
         <td align="justify" class="tabl " style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify; width: 320px;">
          <p class="tabl-text" style="margin-left: 10px; margin-right: 10px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
         </td>
        </tr>
        <tr>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="63">10-01-16</th>
            </tr>
           </tbody>
          </table>
         </td>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="100%">180/67</th>
            </tr>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;"><img alt="" height="20" src="http://urips.co.in/nmac-health/report-design/new/small-green.png" width="20" /></th>
            </tr>
           </tbody>
          </table>
         </td>
         <td align="justify" class="tabl " style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify; width: 320px;">
          <p class="tabl-text" style="margin-left: 10px; margin-right: 10px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
         </td>
        </tr>
       </table>
      </div>
     </div>
     <div class="box" style="float: left; height: auto; left: 0px; margin-bottom: 30px; right: 0px; width: 700px;">
      <div style="width: 688;">
       <h3 style="color: #000; font-size: 20px; margin-bottom: 5px; text-align: center;">KIDNEY DISEASE</h3>
      </div>
      <div style="float: left; line-height: 0.5px; width: 688px;">
       <p style="color: black; font-size: 11px; font-weight: 600; line-height: 15.5px; text-align: center;">BMI : <span style="color: #0F3;">Desirable (< 200) </span> | <span style="color: #060;"> Borderline (200 – 239)</span> | <span style="color: #F00;">High (>=240)</span></p>
      </div>
      <div style="margin-left: 12px; margin-right: 12px;">
       <table class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; width: 100%;">
        <tr>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center; width: 65px;" width="65">Date</th>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center; width: 65px;" width="65">Score</th>
         <th class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="514">Comments</th>
        </tr>
        <tr>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="63">10-01-16</th>
            </tr>
           </tbody>
          </table>
         </td>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="100%">220/98</th>
            </tr>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;"><img alt="" height="20" src="http://urips.co.in/nmac-health/report-design/new/red-small.png" width="20" /></th>
            </tr>
           </tbody>
          </table>
         </td>
         <td align="justify" class="tabl " style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify; width: 320px;">
          <p class="tabl-text" style="margin-left: 10px; margin-right: 10px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
         </td>
        </tr>
        <tr>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="63">10-01-16</th>
            </tr>
           </tbody>
          </table>
         </td>
         <td class="tabl" style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify;">
          <table border="0" cellpadding="0" cellspacing="0" width="100%">
           <tbody>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;" width="100%">180/67</th>
            </tr>
            <tr>
             <th scope="row" style="font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: center;"><img alt="" height="20" src="http://urips.co.in/nmac-health/report-design/new/small-green.png" width="20" /></th>
            </tr>
           </tbody>
          </table>
         </td>
         <td align="justify" class="tabl " style="border: 1px dotted #CCC; border-collapse: collapse; font-family: 'Raleway', sans-serif; font-size: 10px; letter-spacing: 1px; line-height: 20px; text-align: justify; width: 320px;">
          <p class="tabl-text" style="margin-left: 10px; margin-right: 10px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
         </td>
        </tr>
       </table>
      </div>
     </div>
    </div>
   </div>
  </div>