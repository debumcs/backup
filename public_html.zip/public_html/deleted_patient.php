<?php

include_once('functions.php');

$con = new dbconnection();

$con->setConnection();



	$sql = "select a.*, b.fasting, c.blood_pressure, d.bmi,e.cholesterol,f.egfr,g.hba1c,h.hdl,i.ldl, j.triglycerides from patient a 

left join (select * from fasting WHERE id IN (SELECT MAX(id) FROM fasting GROUP BY patient_id) ) b on b.patient_id = a.id 

left join (select * from blood_pressure WHERE id IN (SELECT MAX(id) FROM blood_pressure GROUP BY patient_id) ) c on c.patient_id = a.id 

left join (SELECT * FROM bmi WHERE id IN (SELECT MAX(id) FROM bmi GROUP BY patient_id) ) d on d.patient_id = a.id 

left join (select * from cholesterol WHERE id IN (SELECT MAX(id) FROM cholesterol GROUP BY patient_id)) e on e.patient_id = a.id 

left join (select * from egfr WHERE id IN (SELECT MAX(id) FROM egfr GROUP BY patient_id)) f on f.patient_id = a.id 

left join (select * from hba1c WHERE id IN (SELECT MAX(id) FROM hba1c GROUP BY patient_id) ) g on g.patient_id = a.id 

left join (select * from hdl WHERE id IN (SELECT MAX(id) FROM hdl GROUP BY patient_id) ) h on h.patient_id = a.id 

left join (select * from ldl WHERE id IN (SELECT MAX(id) FROM ldl GROUP BY patient_id) ) i on i.patient_id = a.id 

left join (select * from triglycerides WHERE id IN (SELECT MAX(id) FROM ldl GROUP BY patient_id) ) j on j.patient_id = a.id 

where a.status = '0'";

	$result = $con->runQuery($sql);

	

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />

<title>NMAC Health Report Card</title>

<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />

<!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->

<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>



<script type="text/javascript" src="js/ajax/libs/jquery/1.7.2/jquery.min.js"></script>

<script type="text/javascript" src="js/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script>

<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDY0kkJiTPVd2U7aTOAwhc9ySH6oHxOIYM&amp;sensor=false"></script>



<script type="text/javascript" src="js/plugins/charts/excanvas.min.js"></script>

<script type="text/javascript" src="js/plugins/charts/jquery.flot.js"></script>

<script type="text/javascript" src="js/plugins/charts/jquery.flot.resize.js"></script>

<script type="text/javascript" src="js/plugins/charts/jquery.sparkline.min.js"></script>



<script type="text/javascript" src="js/plugins/ui/jquery.easytabs.min.js"></script>

<script type="text/javascript" src="js/plugins/ui/jquery.collapsible.min.js"></script>

<script type="text/javascript" src="js/plugins/ui/prettify.js"></script>

<script type="text/javascript" src="js/plugins/ui/jquery.colorpicker.js"></script>

<script type="text/javascript" src="js/plugins/ui/jquery.timepicker.min.js"></script>

<script type="text/javascript" src="js/plugins/ui/jquery.fancybox.js"></script>

<script type="text/javascript" src="js/plugins/ui/jquery.fullcalendar.min.js"></script>



<script type="text/javascript" src="js/plugins/forms/jquery.uniform.min.js"></script>

<script type="text/javascript" src="js/plugins/forms/jquery.tagsinput.min.js"></script>



<script type="text/javascript" src="js/plugins/tables/jquery.dataTables.min.js"></script>



<script type="text/javascript" src="js/files/bootstrap.min.js"></script>



<script type="text/javascript" src="js/functions/index.js"></script>





</head>



<body>



	<!-- Fixed top -->

	<div id="top">

		<div class="fixed">

			<a href="dashboard.php" title="" class="logo"><img src="img/logo.png" alt="" /></a>

			<ul class="top-menu">

				<li><a class="fullview"></a></li>

				<li><a class="showmenu"></a></li>

				<!--<li><a href="#" title="" class="messages"><i class="new-message"></i></a></li>-->

				<li class="dropdown">

					<a class="user-menu" data-toggle="dropdown"><img src="img/userpic.png" alt="" /><span>Howdy, Admin! <b class="caret"></b></span></a>

					<ul class="dropdown-menu">

						<li><a href="#" title="" data-toggle="modal" data-target="#ProfileView"><i class="icon-user"></i>Profile</a></li>

						<li><a href="logout.php" title=""><i class="icon-remove"></i>Logout</a></li>

					</ul>

				</li>

			</ul>

		</div>

	</div>

	<!-- /fixed top -->





	<!-- Content container -->

	<div id="container">



		<!-- Sidebar -->

		<div id="sidebar">



			<div class="sidebar-tabs">

		        <ul class="tabs-nav two-items">

		            <li><a href="#general" title=""><i class="icon-reorder"></i></a></li>

		            <li><a href="#stuff" title=""><i class="icon-cogs"></i></a></li>

		        </ul>



		        <div id="general">



			        <!-- Sidebar user -->

			        <div class="sidebar-user widget">

						<div class="navbar"><div class="navbar-inner"><h6>Wazzup, Admin!</h6></div></div>

			            

			        </div>

			        <!-- /sidebar user -->





				    <!-- Main navigation -->

			        <?php 

						get_menu();

					?>

			        <!-- /main navigation -->



		        </div>



		        <div id="stuff">



			        <!-- Social stats -->

			        <div class="widget">

			        	<h6 class="widget-name"><i class="icon-user"></i>Urgent Call</h6>

			        	<ul class="social-stats">

			        		<?php urgent_call(); ?>			        	

			        	</ul>

			        </div>

			        <!-- /social stats -->

                   



		        </div>



		    </div>

		</div>

		<!-- /sidebar -->





		<!-- Content -->

		<div id="content">



		    <!-- Content wrapper -->

		    <div class="wrapper">



			    <!-- Breadcrumbs line -->

			    <div class="crumbs">

		            <ul id="breadcrumbs" class="breadcrumb"> 

		                <li><a href="dashboard.php">Dashboard</a></li>

						<li class="active"><a title="" href="#">Deleted Patient</a></li>

		            </ul>

			        

			    </div>

			    <!-- /breadcrumbs line -->



			    <!-- Page header -->

			    <div class="page-header">

			    	<div class="page-title">

				    	<h5><strong>Deleted Patient</strong></h5>

				    	<span>Welcome, Admin!</span>

			    	</div>



			    	<ul class="page-stats">

			    		<!--<li>

			    			<div class="showcase">

			    				<span>New Patient</span>

			    				<h2><?php echo get_newtotal(); ?></h2>

			    			</div>

			    			<div id="total-visits" class="chart"><?php echo get_newbars(); ?></div>

			    		</li>-->

			    		<li>

			    			<div class="showcase">

			    				<span>Total Patient</span>

			    				<h2><?php echo get_total(); ?></h2>

			    			</div>

			    			<div id="balance" class="chart"><?php echo get_bars(); ?></div>

			    		</li>

			    	</ul>

			    </div>

			    <!-- /page header -->





		    	<!--<h5 class="widget-name"><i class="icon-th"></i>Deleted Patient</h5>-->

                

                <!-- Media datatable -->

                <div class="widget">

                	<!--<div class="navbar">

                    	<div class="navbar-inner">

                        	<h6>Deleted Patient Chart</h6>

                            <div class="nav pull-right">

                                <a data-toggle="dropdown" class="dropdown-toggle navbar-icon" href="#"><i class="icon-print"></i></a>

                            </div>

                        </div>

                    </div>-->

                    <div class="table-overflow">

                        <table class="table table-striped table-bordered table-checks media-table">

                            <thead>

                                <tr>

                                <th width="106">Date</th>

                                    <th width="71">Image</th>

                                    <th width="122">Patient Name</th>

                                    <th width="58">Age</th>

                                    <th width="88">Location</th>

                                    <th width="60">BMI</th>

                                    <th width="74">BP</th>

                                    <th width="130">Cholesterol</th>

                                    <th width="60">HDL</th>

                                    <th width="58">LDL</th>

                                    <th width="97">Triglycerides</th>

                                    <th width="85">HBa1c</th>

                                    <th width="65">eGFR</th>

                                    <th width="128" class="actions-column">Actions</th>

                                </tr>

                            </thead>

                            <tbody>

                                

								

								<?php $slno =  1; for($i=0; $i<count($result); $i++ ) { ?>

								

								<tr>

									<td><?php  echo $result[$i]['date_time']; ?></td>

			                        <td><a href="<?php  echo $result[$i]['photo']; ?>" title="" class="lightbox"><img width="37" height="36" src="<?php  echo $result[$i]['photo']; ?>" alt="" /></a></td>

			                        <td><a href="#" title=""><?php  echo $result[$i]['name']; ?></a></td>

                                    <td><?php  echo $result[$i]['age']; ?></td>

                                    <td><?php  echo substr($result[$i]['address'], 0, 5).'...'; ?></td>

			                        <td style="background: <?php  $colorbmi = get_bmi($result[$i]['bmi'],''); echo $colorbmi['color']; ?>"><?php  echo $result[$i]['bmi']; ?></td>

                                    <td style="background: <?php  $colorbp = get_bp($result[$i]['blood_pressure'],'',$result[$i]['age'],$result[$i]['health_status']); echo $colorbp['color']; ?>"><?php  echo $result[$i]['blood_pressure']; ?></td>

                                    <td style="background: <?php  $colorcholesterol = get_cholesterol($result[$i]['cholesterol'],''); echo $colorcholesterol['color']; ?>"><?php  echo $result[$i]['cholesterol']; ?></td>

                                    <td style="background: <?php  $colorhdl = get_hdl($result[$i]['hdl'],''); echo $colorhdl['color']; ?>"><?php  echo $result[$i]['hdl']; ?></td>

                                    <td style="background: <?php  $colorldl = get_ldl($result[$i]['ldl'],''); echo $colorldl['color']; ?>"><?php  echo $result[$i]['ldl']; ?></td>

                                    <td style="background: <?php  $colortriglycerides = get_triglycerides($result[$i]['triglycerides'],''); echo $colortriglycerides['color']; ?>"><?php  echo $result[$i]['triglycerides']; ?></td>

                                    <td style="background: <?php  $colorhba1c = get_hba1c($result[$i]['hba1c'],''); echo $colorhba1c['color']; ?>"><?php  echo $result[$i]['hba1c']; ?></td>

                                    <td style="background: <?php  $coloregfr = get_egfr($result[$i]['egfr'],''); echo $coloregfr['color']; ?>"><?php  echo $result[$i]['egfr']; ?></td>

			                        <td>

		                                <ul class="navbar-icons">

		                                    <li><a href="delete.php?status=reactive&id=<?php  echo $result[$i]['id']; ?>" class="tip" title="Reactive"><i class="icon-info-sign"></i></a></li>

		                                </ul>

			                        </td>

                                </tr>

                                

                                <?php } ?>

								

                                

                            </tbody>

                        </table>

                    </div>

                </div>

                <!-- /media datatable -->





		    </div>

		    <!-- /content wrapper -->



		</div>

		<!-- /content -->



	</div>

	<!-- /content container -->

    

<!--ProfileDeleted patient Modal -->

<div id="ProfileView" class="modal fade" role="dialog">

  <div class="modal-dialog">



    <!-- Modal content-->

    <div class="modal-content nmac_tracker">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal">&times;</button>

        <h4 class="modal-title widget-name"><i class="icon-edit"></i>Profile</h4>

      </div>

      <div class="modal-body">

<form class="form-horizontal search widget" action="#">

    <div class="control-group">

                                        <label class="control-label">Date of Creation</label>

                                        <div class="controls"><input type="text" name="regular" class="span12" placeholder="20/10/2015" /></div>

                                    </div>

     <div class="control-group">

						            <label class="control-label">Name</label>

						            <div class="controls"><input type="text" name="regular" class="span12" placeholder="Admin" /></div>

						        </div>  

    

    

    <div class="control-group">

						            <label class="control-label">Age</label>

						            <div class="controls"><input type="text" value="" name="" class="span12" placeholder="38" /></div>

						        </div>  

    <div class="control-group">

						            <label class="control-label">Location</label>

						            <div class="controls"><input type="text" value="" name="" class="span12" placeholder="New York" /></div>

						        </div>                                                        

    <div class="control-group">

						            <label class="control-label">Phone no</label>

						            <div class="controls"><input type="text" value="" name="" class="span12" placeholder="9999887585" /></div>

						        </div>

     <div class="control-group">

						            <label class="control-label">Email Id</label>

						            <div class="controls"><input type="email" value="" name="" class="span12" placeholder="eudgene5@yahoo.com" /></div>

						        </div>                           

                                                          

    <div class="control-group">

	                                <label class="control-label">Specialization:</label>

	                                <div class="controls">

	                                    <textarea rows="5" cols="5" name="textarea" class="span12"> Medicine, Main Specialist</textarea>

	                                </div>

	                            </div>

    </form>





      </div>

    </div>



  </div>

</div>

 <!-- End Modal -->

 

	<!-- Footer -->

	<div id="footer">

		<div class="copyrights">&copy; <a class="" target="_blank" href="http://www.designdot.co.in">Designdot Technologies Pvt. Ltd.</a> All rights reserved.</div>

		<ul class="footer-links">

			<li><a href="#" title=""><i class="icon-cogs"></i>Contact admin</a></li>

			<li><a href="#" title=""><i class="icon-screenshot"></i>Report bug</a></li>

		</ul>

	</div>

	<!-- /footer -->



</body>

</html>