<?php
	session_start();
	include_once('dbconnection.php');	
	
	if (!(isset($_SESSION['USER']) && $_SESSION['USER'] != '')) {
		echo "<script>window.location = 'index.php?flag=S';</script>";
	}
	
	function get_bmi($score,$comment = ''){
		
		if($comment == ''){
			if( floatval($score)< 18.4){
				$data = array('comment'=>'Your at moderate risk of having major health problems!',
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
			} elseif(floatval($score)>=18.5 and floatval($score)<=24.9){ 
				$data = array('comment'=>'Excellent Result',
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
			} elseif(floatval($score)>=25 and floatval($score)<=29.9){ 
				$data = array('comment'=>'You are at high risk of having major health problems!',
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
			} elseif(floatval($score)>=30){ 
				$data = array('comment'=>'You are at extreme danger of developing major health problems! (Seek Urgent Medical Attention)',
							'image'=>'<img src="img/zone.jpg" alt="You are at extreme danger of developing major health problems! (Seek Urgent Medical Attention)" width="20" height="20" />',
							'color'=>'#FF0000 !important;');
			} 
		}else{
			if( floatval($score)< 18.4){
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
			} elseif(floatval($score)>=18.5 and floatval($score)<=24.9){ 
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
			} elseif(floatval($score)>=25 and floatval($score)<=29.9){ 
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
			} elseif(floatval($score)>=30){ 
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/zone.jpg" alt="You are at extreme danger of developing major health problems! (Seek Urgent Medical Attention)" width="20" height="20" />',
							'color'=>'#FF0000 !important;');
			} 
		}
		return $data;
	}
	
	
	
	function get_bp($score,$comment = '',$age,$health_status){
		
		if($comment == ''){
			if($age > 60 and $health_status == 'None'){	
		
				$bpSystolic = explode("/",$score); 
				if(floatval($bpSystolic[0])<=129){ 
					$data = array('comment'=>'Excellent Result',
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
				} elseif(floatval($bpSystolic[0]) >= 130 and floatval($bpSystolic[0]) <= 149){ 
					$data = array('comment'=>'You are at moderate risk of having major health problems!',
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
				} elseif(floatval($bpSystolic[0]) >= 150 and floatval($bpSystolic[0]) <= 159){ 
					$data = array('comment'=>'You are at high risk of having major health problems!',
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
				} elseif(floatval($bpSystolic[0]) >= 160){
					$data = array('comment'=>'You are at extreme danger of developing major health problems! (Seek Urgent Medical Attention)',
							'image'=>'<img src="img/zone.jpg" alt="You are at extreme danger of developing major health problems! (Seek Urgent Medical Attention)" width="20" height="20" />',
							'color'=>'#FF0000 !important;');
				}
			}elseif($age < 60 and $health_status == 'None'){	
			
				$bpSystolic = explode("/",$score); 
				if(floatval($bpSystolic[0])<=129){ 
					$data = array('comment'=>'Excellent Result',
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
				} elseif(floatval($bpSystolic[0]) >= 130 and floatval($bpSystolic[0]) <= 139){ 
					$data = array('comment'=>'You are at moderate risk of having major health problems!',
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
				} elseif(floatval($bpSystolic[0]) >= 140 and floatval($bpSystolic[0]) <= 159){ 
					$data = array('comment'=>'You are at high risk of having major health problems!',
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
				} elseif(floatval($bpSystolic[0]) >= 160){
					$data = array('comment'=>'You are at extreme danger of developing major health problems! (Seek Urgent Medical Attention)',
							'image'=>'<img src="img/zone.jpg" alt="You are at extreme danger of developing major health problems! (Seek Urgent Medical Attention)" width="20" height="20" />',
							'color'=>'#FF0000 !important;');
				}
			}elseif($age > 18 and ($health_status == 'CKD' || $health_status == 'Diabetes')){	
			
				$bpSystolic = explode("/",$score); 
				if(floatval($bpSystolic[0])<=139){ 
					$data = array('comment'=>'Excellent Result',
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
				} elseif(floatval($bpSystolic[0]) >= 140 and floatval($bpSystolic[0]) <= 149){ 
					$data = array('comment'=>'You are at moderate risk of having major health problems!',
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
				} elseif(floatval($bpSystolic[0]) >= 150 and floatval($bpSystolic[0]) <= 159){ 
					$data = array('comment'=>'You are at high risk of having major health problems!',
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
				} elseif(floatval($bpSystolic[0]) >= 160){
					$data = array('comment'=>'You are at extreme danger of developing major health problems! (Seek Urgent Medical Attention)',
							'image'=>'<img src="img/zone.jpg" alt="You are at extreme danger of developing major health problems! (Seek Urgent Medical Attention)" width="20" height="20" />',
							'color'=>'#FF0000 !important;');
				}
			}
		}else{
			if($age > 60 and $health_status == 'None'){	
		
				$bpSystolic = explode("/",$score); 
				if(floatval($bpSystolic[0])<=129){ 
					$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
				} elseif(floatval($bpSystolic[0]) >= 130 and floatval($bpSystolic[0]) <= 149){ 
					$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
				} elseif(floatval($bpSystolic[0]) >= 150 and floatval($bpSystolic[0]) <= 159){ 
					$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
				} elseif(floatval($bpSystolic[0]) >= 160){
					$data = array('comment'=>$comment,
							'image'=>'<img src="img/zone.jpg" alt="You are at extreme danger of developing major health problems! (Seek Urgent Medical Attention)" width="20" height="20" />',
							'color'=>'#FF0000 !important;');
				}
			}elseif($age < 60 and $health_status == 'None'){	
			
				$bpSystolic = explode("/",$score); 
				if(floatval($bpSystolic[0])<=129){ 
					$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
				} elseif(floatval($bpSystolic[0]) >= 130 and floatval($bpSystolic[0]) <= 139){ 
					$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
				} elseif(floatval($bpSystolic[0]) >= 140 and floatval($bpSystolic[0]) <= 159){ 
					$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
				} elseif(floatval($bpSystolic[0]) >= 160){
					$data = array('comment'=>$comment,
							'image'=>'<img src="img/zone.jpg" alt="You are at extreme danger of developing major health problems! (Seek Urgent Medical Attention)" width="20" height="20" />',
							'color'=>'#FF0000 !important;');
				}
			}elseif($age > 18 and ($health_status == 'CKD' || $health_status == 'Diabetes')){	
			
				$bpSystolic = explode("/",$score); 
				if(floatval($bpSystolic[0])<=139){ 
					$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
				} elseif(floatval($bpSystolic[0]) >= 140 and floatval($bpSystolic[0]) <= 149){ 
					$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
				} elseif(floatval($bpSystolic[0]) >= 150 and floatval($bpSystolic[0]) <= 159){ 
					$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
				} elseif(floatval($bpSystolic[0]) >= 160){
					$data = array('comment'=>$comment,
							'image'=>'<img src="img/zone.jpg" alt="You are at extreme danger of developing major health problems! (Seek Urgent Medical Attention)" width="20" height="20" />',
							'color'=>'#FF0000 !important;');
				}
			}
		}
		return $data;
	}
	
	function get_cholesterol($score,$comment = ''){
	
		if($comment == ''){
			if(floatval($score)<200){ 
				$data = array('comment'=>'Excellent Result',
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
			} elseif(floatval($score)>=200 and floatval($score)<=239){ 
				$data = array('comment'=>'You are at moderate risk of having major health problems!',
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
			} elseif(floatval($score)>=240){ 
				$data = array('comment'=>'You are at high risk of having major health problems!',
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
			}
		}else{
			if(floatval($score)<200){ 
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
			} elseif(floatval($score)>=200 and floatval($score)<=239){ 
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
			} elseif(floatval($score)>=240){ 
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
			}
		}
		return $data;
	}
	
	function get_hdl($score,$comment = ''){
	
		if($comment == ''){
			if(floatval($score)>=50){
				$data = array('comment'=>'Excellent Result',
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
			} elseif(floatval($score)<50){ 
				$data = array('comment'=>'You are at high risk of having major health problems!',
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
			}
		}else{
			if(floatval($score)>=50){
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
			} elseif(floatval($score)<50){ 
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
			}
		}
		return $data;
	}
	
	function get_ldl($score,$comment = ''){
		
		if($comment == ''){
			if( floatval($score)<100){
				$data = array('comment'=>'Excellent Result',
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
			}elseif(floatval($score)>=100 and floatval($score)<=129){ 
				$data = array('comment'=>'Excellent Result',
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#40de32 !important;');
			} elseif(floatval($score)>=130 and floatval($score)<=159){ 
				$data = array('comment'=>'You are at moderate risk of having major health problems!',
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
			} elseif(floatval($score)>159 and floatval($score)<=499){ 
				$data = array('comment'=>'You are at high risk of having major health problems!',
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
			} elseif(floatval($score)>=500){ 
				$data = array('comment'=>'You are at extreme danger of developing major health problems! (Seek Urgent Medical Attention)',
							'image'=>'<img src="img/zone.jpg" alt="You are at extreme danger of developing major health problems! (Seek Urgent Medical Attention)" width="20" height="20" />',
							'color'=>'#FF0000 !important;');
			} 
		}else{
			if( floatval($score)<100){
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
			}elseif(floatval($score)>=100 and floatval($score)<=129){ 
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#40de32 !important;');
			} elseif(floatval($score)>=130 and floatval($score)<=159){
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
			} elseif(floatval($score)>159 and floatval($score)<=499){ 
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
			} elseif(floatval($score)>=500){
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/zone.jpg" alt="You are at extreme danger of developing major health problems! (Seek Urgent Medical Attention)" width="20" height="20" />',
							'color'=>'#FF0000 !important;');
			} 
		}
		return $data;
	}
	
	function get_triglycerides($score,$comment = ''){
		
		if($comment == ''){
			if(floatval($score)<150){ 
				$data = array('comment'=>'Excellent Result',
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
			} elseif(floatval($score)>=150 and floatval($score)<=199){ 
				$data = array('comment'=>'You are at moderate risk of having major health problems!',
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
			} elseif(floatval($score)>200 and floatval($score)<=499){ 
				$data = array('comment'=>'You are at high risk of having major health problems!',
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
			} elseif(floatval($score)>500){ 
				$data = array('comment'=>'You are at extreme danger of developing major health problems! (Seek Urgent Medical Attention)',
							'image'=>'<img src="img/zone.jpg" alt="You are at extreme danger of developing major health problems! (Seek Urgent Medical Attention)" width="20" height="20" />',
							'color'=>'#FF0000 !important;');
			} 
		}else{
			if(floatval($score)<150){ 
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
			} elseif(floatval($score)>=150 and floatval($score)<=199){ 
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
			} elseif(floatval($score)>200 and floatval($score)<=499){ 
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
			} elseif(floatval($score)>500){
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/zone.jpg" alt="You are at extreme danger of developing major health problems! (Seek Urgent Medical Attention)" width="20" height="20" />',
							'color'=>'#FF0000 !important;');
			} 
		}
		return $data;
	}
	
	function get_hba1c($score,$comment = ''){
	
		if($comment == ''){
			if(floatval($score)<=5.6){ 
				$data = array('comment'=>'Excellent Result',
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
			} elseif(floatval($score)>5.6 and floatval($score)<=6.4){ 
				$data = array('comment'=>'You are at moderate risk of having major health problems!',
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
			} elseif(floatval($score)>= 6.5){ 
				$data = array('comment'=>'You are at high risk of having major health problems!',
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
			}
		}else{
			if(floatval($score)<=5.6){ 
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
			} elseif(floatval($score)>5.6 and floatval($score)<=6.4){ 
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
			} elseif(floatval($score)>= 6.5){ 
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
			}
		}
		return $data;
	}
	
	function get_fasting($score,$comment = ''){
	
		if($comment == ''){
			if(floatval($score)<100){ 
				$data = array('comment'=>'Excellent Result',
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
			} elseif(floatval($score)>=100 and floatval($score)<=125){ 
				$data = array('comment'=>'You are at moderate risk of having major health problems!',
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
			} elseif(floatval($score)>= 126){ 
				$data = array('comment'=>'You are at high risk of having major health problems!',
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
			}
		}else{
			if(floatval($score)<100){ 
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
			} elseif(floatval($score)>=100 and floatval($score)<=125){ 
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
			} elseif(floatval($score)>= 126){ 
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-red.png" alt="You are at high risk of having major health problems!" width="20" height="20" />',
							'color'=>'#ef705b !important;');
			}
		}
		return $data;
	}
	
	function get_egfr($score,$comment = ''){
	
		if($comment == ''){
			if(floatval($score)>=60 and floatval($score)<=120){
				$data = array('comment'=>'Excellent Result',
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
			} elseif(floatval($score)>15 and floatval($score)<=60){
				$data = array('comment'=>'You are at moderate risk of having major health problems!',
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
			} elseif(floatval($score)>=0 and floatval($score)<=15){
				$data = array('comment'=>'You are at risk extreem danger of developing major health problems! ( Seek Urgent Medical Attention )',
							'image'=>'<img src="img/zone.jpg" alt="You are at risk extreem danger of developing major health problems! ( Seek Urgent Medical Attention )" width="20" height="20" />',
							'color'=>'#FF0000 !important;');
			}
		}else{
			if(floatval($score)>=60 and floatval($score)<=120){
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-green.png" alt="Excellent Result" width="20" height="20" />',
							'color'=>'#56BB4D !important;');
			} elseif(floatval($score)>15 and floatval($score)<=60){
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/small-yellow.png" alt="Your at moderate risk of having major health problems!" width="20" height="20" />',
							'color'=>'orange !important;');
			} elseif(floatval($score)>=0 and floatval($score)<=15){
				$data = array('comment'=>$comment,
							'image'=>'<img src="img/zone.jpg" alt="You are at risk extreem danger of developing major health problems! ( Seek Urgent Medical Attention )" width="20" height="20" />',
							'color'=>'#FF0000 !important;');
			}
		}
		return $data;
	}
	
	
	function urgent_call(){
		$con = new dbconnection();
		$con->setConnection();

		$sqlstats = "select a.*, c.blood_pressure, f.egfr, i.ldl, j.triglycerides from patient a, 
		(select * from blood_pressure WHERE id IN (SELECT MAX(id) FROM blood_pressure GROUP BY patient_id) ) c,
		(select * from egfr WHERE id IN (SELECT MAX(id) FROM egfr GROUP BY patient_id)) f,
		(select * from ldl WHERE id IN (SELECT MAX(id) FROM ldl GROUP BY patient_id) ) i,
		(select * from triglycerides WHERE id IN (SELECT MAX(id) FROM ldl GROUP BY patient_id) ) j
		where a.id = c.patient_id 
		and a.id = f.patient_id 
		and a.id = i.patient_id 
		and a.id = j.patient_id and a.status = '1'";
		$resultstats = $con->runQuery($sqlstats);						
		
		for($s=0; $s<count($resultstats); $s++ ) { 
			$bpSystolic = explode("/",$resultstats[$s]['blood_pressure']); 
			
			if(floatval($bpSystolic[0]) >= 160){
				$score = $bpSystolic[0];
			}elseif(floatval($resultstats[$s]['egfr']) < 16){
				$score = $resultstats[$s]['egfr'];
			}elseif(floatval($resultstats[$s]['ldl']) > 500){
				$score = $resultstats[$s]['ldl'];
			}elseif(floatval($resultstats[$s]['triglycerides']) > 500){
				$score = $resultstats[$s]['triglycerides'];
			}
			
			if((floatval($bpSystolic[0]) >= 160) || (floatval($resultstats[$s]['egfr']) < 16) || (floatval($resultstats[$s]['ldl']) > 500) || (floatval($resultstats[$s]['triglycerides']) > 500)){
		?>
			<li>
				<a href="edit_patient.php?id=<?php  echo $resultstats[$s]['id']; ?>" title="Get Information"><img alt="" width="36" height="37" src="<?php  echo $resultstats[$s]['photo']; ?>"></a>
				<div>
					<h4><?php echo $score; ?></h4>
					<span><?php  echo $resultstats[$s]['name']; ?></span>
				</div>
			</li>
		<?php 
			} 
		} 
		
	}
	
	
	function get_newbars(){
		//SELECT DATE_FORMAT(date_time, '%b, %Y') as 'year', COUNT(id) as 'total' FROM patient GROUP BY DATE_FORMAT(date_time, '%Y%m') order by date_time desc limit 12 
		
		$con = new dbconnection();
		$con->setConnection();

		$sqlbars = "SELECT COUNT(id) as 'total' FROM patient  where status = '1'
		GROUP BY DATE_FORMAT(date_time, '%Y%m%d') order by date_time desc limit 15";
		$resultbars = $con->runQuery($sqlbars);						
		
		$bars = array();
		
		for($s=0; $s<count($resultbars); $s++ ) { 
			
			$bars[] = $resultbars[$s]['total'];
			
		} 
		
		return implode(",",$bars);
		
	}
	
	function get_bars(){
		
		$con = new dbconnection();
		$con->setConnection();

		$sqlbars = "SELECT DATE_FORMAT(date_time, '%b, %Y') as 'year', COUNT(id) as 'total' FROM patient  where status = '1'
		GROUP BY DATE_FORMAT(date_time, '%Y%m') order by date_time desc limit 12";
		$resultbars = $con->runQuery($sqlbars);						
		
		$bars = array();
		
		for($s=0; $s<count($resultbars); $s++ ) { 
			
			$bars[] = $resultbars[$s]['total'];
			
		} 
		
		return implode(",",$bars);
		
	}
	
	function get_total(){
		
		$con = new dbconnection();
		$con->setConnection();

		$sqlbars = "SELECT COUNT(id) as 'total' FROM patient where status = '1'";
		$resultbars = $con->runQuery($sqlbars);						
		
		return $resultbars[0]['total'];
		
	}
	
	function get_newtotal(){
		$con = new dbconnection();
		$con->setConnection();

		$sqlbars = "SELECT COALESCE(COUNT(*), 0) AS total FROM patient AS a WHERE (a.date_time >= DATE_SUB(CURDATE(), INTERVAL 15 DAY)) and status = '1'";
		$resultbars = $con->runQuery($sqlbars);						
		
		return $resultbars[0]['total'];
	}
	
	function get_menu(){ 			$basename = basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']);		?>
		<ul class="navigation widget">
			<li <?php if($basename == 'dashboard.php'){echo 'class="active"';}?>><a href="dashboard.php" title=""><i class="icon-home"></i>Dashboard</a></li>
			<li <?php if($basename == 'add_patient.php'){echo 'class="active"';}?>><a title="" href="add_patient.php">Add Patient</a></li>
			<li><a title="" href="view_patient_track.php">New Encounter</a></li>
			<li <?php if($basename == 'view_patient_track.php'){echo 'class="active"';}?>><a href="#" class="expand" title=""><i class="icon-group"></i>Tracking Patient <strong>1</strong></a>
				<ul>                        
					<li <?php if($basename == 'view_patient_track.php'){echo 'class="active"';}?>><a title="" href="view_patient_track.php">View Patient</a></li>
					
				</ul>
			</li>
			
			<li <?php if($basename == 'view_action_type.php'){echo 'class="active"';}?>><a href="#" class="expand" title=""><i class="icon-group"></i>All Parameters <strong>15</strong></a>
				<ul>                        
					<li <?php if($basename == 'view_action_type.php'){echo 'class="active"';}?>><a title="" href="view_action_type.php?action=BP">Blood Pressure</a></li>
					<li <?php if($basename == 'view_action_type.php'){echo 'class="active"';}?>><a title="" href="view_action_type.php?action=BMI">BMI</a></li>
					<li <?php if($basename == 'view_action_type.php'){echo 'class="active"';}?>><a title="" href="view_action_type.php?action=BDF">Body Fat</a></li>
					<li <?php if($basename == 'view_action_type.php'){echo 'class="active"';}?>><a title="" href="view_action_type.php?action=CHR">Cholesterol</a></li>
					<li <?php if($basename == 'view_action_type.php'){echo 'class="active"';}?>><a title="" href="view_action_type.php?action=GFR">eGFR</a></li>
					<li <?php if($basename == 'view_action_type.php'){echo 'class="active"';}?>><a title="" href="view_action_type.php?action=FAST">Fasting</a></li>
					<li <?php if($basename == 'view_action_type.php'){echo 'class="active"';}?>><a title="" href="view_action_type.php?action=GAS">Gas Score</a></li>
					<li <?php if($basename == 'view_action_type.php'){echo 'class="active"';}?>><a title="" href="view_action_type.php?action=GCS">Glucose</a></li>
					<li <?php if($basename == 'view_action_type.php'){echo 'class="active"';}?>><a title="" href="view_action_type.php?action=HBA">HbA1c</a></li>
					<li <?php if($basename == 'view_action_type.php'){echo 'class="active"';}?>><a title="" href="view_action_type.php?action=HDL">HDL</a></li>
					<li <?php if($basename == 'view_action_type.php'){echo 'class="active"';}?>><a title="" href="view_action_type.php?action=LDL">LDL</a></li>
					<li <?php if($basename == 'view_action_type.php'){echo 'class="active"';}?>><a title="" href="view_action_type.php?action=MAG">Metabolic Age</a></li>
					<li <?php if($basename == 'view_action_type.php'){echo 'class="active"';}?>><a title="" href="view_action_type.php?action=PHQ">PHQ</a></li>
					<li <?php if($basename == 'view_action_type.php'){echo 'class="active"';}?>><a title="" href="view_action_type.php?action=TRI">Triglycerides</a></li>
				</ul>
			</li>
			
			<li <?php if($basename == 'view_patient.php'){echo 'class="active"';}?>><a href="#" class="expand" title=""><i class="icon-group"></i>Report Card <strong>1</strong></a>
				<ul>                        
					<li <?php if($basename == 'view_patient.php'){echo 'class="active"';}?>><a title="" href="view_patient.php">View Patient</a></li>
				</ul>
			</li>
			<li <?php if($basename == 'deleted_patient.php'){echo 'class="active"';}?>><a title="" href="deleted_patient.php">Deleted Patient</a></li>
		</ul>
		<ul class="navigation widget">			
			<li <?php if($basename == 'compose.php'){echo 'class="active"';}?>><a href="compose.php" title=""><i class="icon-edit"></i>Compose</a></li>
			<li <?php if($basename == 'draft.php'){echo 'class="active"';}?>><a href="draft.php" title=""><i class="icon-folder-open-alt"></i>Draft</a></li>
			<li <?php if($basename == 'sent.php'){echo 'class="active"';}?>><a href="sent.php" title=""><i class="icon-envelope"></i>Sent Items</a></li>
			<li <?php if($basename == 'delete_items.php'){echo 'class="active"';}?>><a href="delete_items.php" title=""><i class="icon-trash"></i>Deleted</a></li>
		</ul>
	<?php
	}
	function test_input($data) {	$data = trim($data);	$data = stripslashes($data);	$data = htmlspecialchars($data);	return $data;}function reArrayFiles($file){    $file_ary = array();    $file_count = count($file['name']);    $file_key = array_keys($file);       for($i=0;$i<$file_count;$i++)    {        foreach($file_key as $val)        {            $file_ary[$i][$val] = $file[$val][$i];        }    }    return $file_ary;}
	
?> 