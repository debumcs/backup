<?php
include_once('functions.php');
$con = new dbconnection();
$con->setConnection();

$sql = "SELECT * FROM mail where id = '".$_GET['ID']."'";
$result = $con->runQuery($sql);

require 'PHPMailer/PHPMailerAutoload.php';
$mail = new PHPMailer;

$message = $result[0]['message'];
$to = $result[0]['toemails'];
$cc = $result[0]['ccemails'];
$subject = $result[0]['subject'];
$uploaded_files = $result[0]['attachfiles'];

$toErr = $ccErr = $subjectErr = $messageErr = $msg = "";
$errorFlag = 0;
         
         
         if ($_SERVER["REQUEST_METHOD"] == "POST") {
			$submit = $_POST["submit"];
			//die();
            
			if (empty($_POST["to"])) {
               $toErr = "Email is required";
			   $errorFlag = 1;
            }else {
               $to = $_POST["to"];
			   $multipleTo = explode(',',$to);
               
               // check if e-mail address is well-formed
			   foreach($multipleTo as $toemail){
				   if (!filter_var(test_input($toemail), FILTER_VALIDATE_EMAIL)) {
					  $toErr = "Invalid email format"; 
					  $errorFlag = 1;
				   }
			   }
				   
            }
			
			if (empty($_POST["cc"])) {
               $cc = "";
            }
            else {
               $cc = $_POST["cc"];
               $multipleCC = explode(',',$cc);
               
               // check if e-mail address is well-formed
			   foreach($multipleCC as $ccemail){
				   if (!filter_var(test_input($ccemail), FILTER_VALIDATE_EMAIL)) {
					  $ccErr = "Invalid email format"; 
					  $errorFlag = 1;
				   }
			   }
            }
            
            if (empty($_POST["subject"])) {
				$subject = "";
				$subjectErr = "Subject is required"; 
				$errorFlag = 1;
            }
            else {
               $subject = test_input($_POST["subject"]);
            }
            
            if (empty($_POST["message"])) {
				$message = "";
			    $messageErr = "Message is required"; 
				$errorFlag = 1;
            }else {
				$message = test_input($_POST["message"]);
            }
			
			//$errorFlag = 1;
			if($errorFlag === 0){
				
				if($submit == 'Send Mail'){
					
					foreach($multipleTo as $toemail){
						$mail->addAddress($toemail);
					}
					foreach($multipleCC as $ccemail){
						$mail->addCC($ccemail);
					}
					$mail->setFrom('donotreply@nmaclab.org', 'NMAC LAB');
					$mail->Subject = $subject;
					$mail->msgHTML(htmlspecialchars_decode($message));
					//Attach multiple files one by one  htmlspecialchars_decode($str);
					foreach($uploaded_files as $val)
					{
						$mail->addAttachment($val);
					}
					
					if (!$mail->send()) {
						$msg .= "Mailer Error: " . $mail->ErrorInfo;
					} else {
						$msg .= "Message sent!";
						$message = $to = $cc = $subject = "";
						
						$sql = "UPDATE mail SET ";
						$sql .= " toemails = '".$to."', ";
						$sql .= " ccemails = '".$cc."', ";
						$sql .= " subject = '".$subject."', ";
						$sql .= " message = '".$message."', ";
						$sql .= " attachfiles = '".$uploaded_files."', ";
						$sql .= " status = '2', ";
						$sql .= " sentdate = '".date('Y-m-d H:i:s')."', ";
						$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' where id = '".$last_id."'";

						$result=$con->UpdateQuery($sql);
						
					}
				}
			}		   
        }

?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.kopyov.com/pannonia/ by HTTrack Website Copier/3.x [XR&CO'2010], Sat, 27 Jul 2013 15:36:51 GMT -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<title>NMAC Patient Tracker | Compose</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>

<script type="text/javascript" src="js/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="js/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDY0kkJiTPVd2U7aTOAwhc9ySH6oHxOIYM&amp;sensor=false"></script>

<script type="text/javascript" src="js/plugins/charts/excanvas.min.js"></script>
<script type="text/javascript" src="js/plugins/charts/jquery.flot.js"></script>
<script type="text/javascript" src="js/plugins/charts/jquery.flot.resize.js"></script>
<script type="text/javascript" src="js/plugins/charts/jquery.sparkline.min.js"></script>

<script type="text/javascript" src="js/plugins/ui/jquery.easytabs.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.collapsible.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/prettify.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.colorpicker.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.timepicker.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.fullcalendar.min.js"></script>

<script type="text/javascript" src="js/plugins/forms/jquery.uniform.min.js"></script>
<script type="text/javascript" src="js/plugins/forms/jquery.tagsinput.min.js"></script>

<script type="text/javascript" src="js/plugins/tables/jquery.dataTables.min.js"></script>

<script type="text/javascript" src="js/files/bootstrap.min.js"></script>

<script type="text/javascript" src="js/functions/index.js"></script>
<style>
.form-horizontal .controls {
    *display: inline-block;
    *padding-left: 20px;
    position: relative;
    margin-left: 0%;
    *margin-left: 0;
}
.error {color: #FF0000;}
</style>
<script src="tinymce/tinymce.min.js"></script>
  <script>
  tinymce.init({
 selector: 'textarea',
  height: 200,
  theme: 'modern',
  plugins: [
    'advlist autolink lists link anchor',
    'searchreplace wordcount',
    'table contextmenu directionality',
    'emoticons paste textcolor colorpicker textpattern'
  ],
  toolbar1: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link | forecolor backcolor emoticons',
  image_advtab: true,
   content_css: [
    '//fast.fonts.net/cssapi/e6dc9b99-64fe-4292-ad98-6974f93cd2a2.css',
    '//www.tinymce.com/css/codepen.min.css'
  ]
});</script>
</head>

<body>

	<!-- Fixed top -->
	<div id="top">
		<div class="fixed">
			<a href="dashboard.html" title="" class="logo"><img src="img/logo.png" alt="" /></a>
			<ul class="top-menu">
				<li><a class="fullview"></a></li>
				<li class="dropdown">
					<a class="user-menu" data-toggle="dropdown"><img src="img/userpic.png" alt="" /><span>Howdy, Eugene! <b class="caret"></b></span></a>
					<ul class="dropdown-menu">
						<li><a href="#" title="" data-toggle="modal" data-target="#ProfileView"><i class="icon-user"></i>Profile</a></li>
						<li><a href="logout.php" title=""><i class="icon-remove"></i>Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
	<!-- /fixed top -->


	<!-- Content container -->
	<div id="container">

		<!-- Sidebar -->
		<div id="sidebar">

			<div class="sidebar-tabs">
		        <ul class="tabs-nav two-items">
		            <li><a href="#general" title=""><i class="icon-reorder"></i></a></li>
		            <li><a href="#stuff" title=""><i class="icon-cogs"></i></a></li>
		        </ul>

		        <div id="general">

			        <!-- Sidebar user -->
			        <div class="sidebar-user widget">
						<div class="navbar"><div class="navbar-inner"><h6>Wazzup, Eugene!</h6></div></div>
			            
			        </div>
			        <!-- /sidebar user -->


				    <!-- Main navigation -->
			        <?php 
						get_menu();
					?>
			        <!-- /main navigation -->

		        </div>

		        <div id="stuff">

			        <!-- Social stats -->
			        <div class="widget">
			        	<h6 class="widget-name"><i class="icon-user"></i>Urgent Call</h6>
			        	<ul class="social-stats">
			        		<?php urgent_call(); ?>				        	
			        	</ul>
			        </div>
			        <!-- /social stats -->
                   

		        </div>

		    </div>
		</div>
		<!-- /sidebar -->


		<!-- Content -->
		<div id="content">

		    <!-- Content wrapper -->
		    <div class="wrapper">

			    <!-- Breadcrumbs line -->
			    <div class="crumbs">
		            <ul id="breadcrumbs" class="breadcrumb"> 
		                <li><a href="dashboard.html">Dashboard</a></li>
                        <li ><a title="" href="#">Messages</a></li>
                        <li class="active"><a title="" href="#">Edit Compose</a></li>
		            </ul>
			        
		            
			    </div>
			    <!-- /breadcrumbs line -->

			    <!-- Page header -->
			    <div class="page-header">
			    	<div class="page-title">
				    	<h5>Edit Compose</h5>
				    	<span>Welcome, Eugene!</span>
			    	</div>	
			    </div>
				<div class="page-header">
			    	<p class = "error"><?php echo $msg; ?></p>
			    </div>
			    <!-- /page header -->
 


		    	<!-- Search widget -->
		    	
		    	<!-- /search widget -->
                
                <!-- Advance Search widget -->
                  <div class="advance_search">
                <form class="form-horizontal search widget" method="post" action=""  enctype="multipart/form-data" name="email" id="email" >
    <div class="control-group">
                                        
                                        <div class="controls"><input type="text" placeholder="To : add multiple email separated by commas(,)" name="to" id="to" class="span12" value="<?php echo $to; ?>" /></div>
										<span class = "error"><?php echo $toErr; ?></span>
                                    </div>
     <div class="control-group">    
						            <div class="controls"><input type="text" placeholder="Cc : add multiple email separated by commas(,)" name="cc" id="cc" class="span12" value="<?php echo $cc; ?>" /></div>
									<span class = "error"><?php echo $ccErr; ?></span>
						        </div>  
       
      
    
    <div class="control-group">
						         
						            <div class="controls"><input type="text" placeholder="Subject :" value="<?php echo $subject; ?>" name="subject" id="subject" class="span12" /></div>
									<span class = "error"><?php echo $subjectErr; ?></span>
						        </div>        
     
     <div class="control-group">
	                                        
	                                        <div class="controls">
	                                            <input class="styled" name="userfile[]" type="file" multiple="multiple">
	                                        </div>
	                                    </div>    
                                        <div class="control-group">
	                                
	                                <div class="controls">
	                                    <textarea placeholder="---" rows="20" cols="5" name="message" id="message" class="span12"><?php echo $message; ?></textarea>
	                                </div>
									<span class = "error"><?php echo $messageErr;?></span>
	                            </div>

	                            <div class="form-actions align-right">
	                                <input type="submit" value="Send Mail" name="submit" class="btn btn-info" />
									<input type="submit" value="Save to Draft" name="submit" class="btn btn-info" />
	                            </div>                                                                     
    
                            
    </form>
    </div>
                <!-- / Advance Search widget -->

		    </div>
		    <!-- /content wrapper -->

		</div>
		<!-- /content -->

	</div>
	<!-- /content container -->

	<!-- Footer -->
	<div id="footer">
		<div class="copyrights">&copy; <a class="" target="_blank" href="http://www.designdot.co.in">Designdot Technologies Pvt. Ltd.</a> All rights reserved.</div>
		<ul class="footer-links">
			<li><a href="#" title=""><i class="icon-cogs"></i>Contact admin</a></li>
			<li><a href="#" title=""><i class="icon-screenshot"></i>Report bug</a></li>
		</ul>
	</div>
	<!-- /footer -->

</body>

<!-- Mirrored from demo.kopyov.com/pannonia/ by HTTrack Website Copier/3.x [XR&CO'2010], Sat, 27 Jul 2013 15:39:34 GMT -->
</html>
