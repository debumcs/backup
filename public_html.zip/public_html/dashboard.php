<?php

include_once('functions.php');
$con = new dbconnection();
$con->setConnection();

	$sql = "SELECT a.*, b.fasting, c.blood_pressure, d.bmi,e.cholesterol,f.egfr,g.hba1c,h.hdl,i.ldl, j.triglycerides FROM patient a 
LEFT JOIN (SELECT * FROM fasting fas1 WHERE DATETIME = (SELECT MAX(DATETIME) FROM fasting fas2 WHERE fas1.patient_id = fas2.patient_id GROUP BY fas2.patient_id) ) b ON b.patient_id = a.id 
LEFT JOIN (SELECT * FROM blood_pressure bp1 WHERE DATETIME = (SELECT MAX(DATETIME) FROM blood_pressure bp2 WHERE bp1.patient_id = bp2.patient_id GROUP BY bp2.patient_id) ) c ON c.patient_id = a.id 
LEFT JOIN (SELECT * FROM bmi bmi1 WHERE DATETIME = (SELECT MAX(DATETIME) FROM bmi bmi2 WHERE bmi1.patient_id = bmi2.patient_id GROUP BY bmi2.patient_id) ) d ON d.patient_id = a.id 
LEFT JOIN (SELECT * FROM cholesterol chl1 WHERE DATETIME = (SELECT MAX(DATETIME) FROM cholesterol chl2 WHERE chl1.patient_id = chl2.patient_id GROUP BY chl2.patient_id)) e ON e.patient_id = a.id 
LEFT JOIN (SELECT * FROM egfr eg1 WHERE DATETIME = (SELECT MAX(DATETIME) FROM egfr eg2 WHERE eg1.patient_id = eg2.patient_id GROUP BY eg2.patient_id)) f ON f.patient_id = a.id 
LEFT JOIN (SELECT * FROM hba1c hba1 WHERE DATETIME = (SELECT MAX(DATETIME) FROM hba1c hba2 WHERE hba1.patient_id = hba2.patient_id GROUP BY hba2.patient_id) ) g ON g.patient_id = a.id 
LEFT JOIN (SELECT * FROM hdl hdl1 WHERE DATETIME = (SELECT MAX(DATETIME) FROM hdl hdl2 WHERE hdl1.patient_id = hdl2.patient_id GROUP BY hdl2.patient_id) ) h ON h.patient_id = a.id 
LEFT JOIN (SELECT * FROM ldl ldl1 WHERE DATETIME = (SELECT MAX(DATETIME) FROM ldl ldl2 WHERE ldl1.patient_id = ldl2.patient_id GROUP BY ldl2.patient_id) ) i ON i.patient_id = a.id 
LEFT JOIN (SELECT * FROM triglycerides try1 WHERE DATETIME = (SELECT MAX(DATETIME) FROM triglycerides try2 WHERE try1.patient_id = try2.patient_id  GROUP BY try2.patient_id) ) j ON j.patient_id = a.id ";

	if(isset($_POST['program']) and $_POST['program'] != 'All'){
		$sql .= " where a.status = '1' and program = '".$_POST['program']."' order by a.date_time desc";
		$program = $_POST['program'];
	}else{
		$sql .= " where a.status = '1' order by a.date_time desc";
		$program = '';
	}
	//echo $sql; die();
	$result = $con->runQuery($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<title>NMAC Health Report Card</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="js/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDY0kkJiTPVd2U7aTOAwhc9ySH6oHxOIYM&amp;sensor=false"></script>
<script type="text/javascript" src="js/plugins/charts/excanvas.min.js"></script>
<script type="text/javascript" src="js/plugins/charts/jquery.flot.js"></script>
<script type="text/javascript" src="js/plugins/charts/jquery.flot.resize.js"></script>
<script type="text/javascript" src="js/plugins/charts/jquery.sparkline.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.easytabs.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.collapsible.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/prettify.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.colorpicker.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.timepicker.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.fullcalendar.min.js"></script>
<script type="text/javascript" src="js/plugins/forms/jquery.uniform.min.js"></script>
<script type="text/javascript" src="js/plugins/forms/jquery.tagsinput.min.js"></script>
<script type="text/javascript" src="js/plugins/tables/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/files/bootstrap.min.js"></script>
<script type="text/javascript" src="js/functions/index.js"></script>
<script type="text/javascript">

$(document).ready(function() {
  $('#program').on('change', function() {
     document.forms["allprogram"].submit();
  });
});

</script>
</head>
<body>
<!-- Fixed top -->
	<div id="top">
		<div class="fixed">
			<a href="dashboard.php" title="" class="logo"><img src="img/logo.png" alt="" /></a>
			<ul class="top-menu">
				<li><a class="fullview"></a></li>
				<li><a class="showmenu"></a></li>
				<!--<li><a href="#" title="" class="messages"><i class="new-message"></i></a></li>-->
				<li class="dropdown">
					<a class="user-menu" data-toggle="dropdown"><img src="img/userpic.png" alt="" /><span>Howdy, Admin! <b class="caret"></b></span></a>
					<ul class="dropdown-menu">
						<li><a href="#" title="" data-toggle="modal" data-target="#ProfileView"><i class="icon-user"></i>Profile</a></li>
						<li><a href="logout.php" title=""><i class="icon-remove"></i>Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
	<!-- /fixed top -->
	<!-- Content container -->
	<div id="container">
		<!-- Sidebar -->
		<div id="sidebar">
			<div class="sidebar-tabs">
		        <ul class="tabs-nav two-items">
		            <li><a href="#general" title=""><i class="icon-reorder"></i></a></li>
		            <li><a href="#stuff" title=""><i class="icon-cogs"></i></a></li>
		        </ul>
		        <div id="general">
			        <!-- Sidebar user -->
			        <div class="sidebar-user widget">
						<div class="navbar"><div class="navbar-inner"><h6>Wazzup, Admin!</h6></div></div>
			        </div>
			        <!-- /sidebar user -->



				    <!-- Main navigation -->

			        <?php 

						get_menu();

					?>

			        <!-- /main navigation -->



		        </div>



		        <div id="stuff">



			        <!-- Social stats -->

			        <div class="widget">

			        	<h6 class="widget-name"><i class="icon-user"></i>Urgent Call</h6>

			        	<ul class="social-stats">

			        		<?php urgent_call(); ?>			        	

			        	</ul>

			        </div>

			        <!-- /social stats -->

                   



		        </div>



		    </div>

		</div>

		<!-- /sidebar -->





		<!-- Content -->

		<div id="content">



		    <!-- Content wrapper -->

		    <div class="wrapper">



			    <!-- Breadcrumbs line -->

			    <div class="crumbs">

		            <ul id="breadcrumbs" class="breadcrumb"> 

		                <li><a href="dashboard.php">Dashboard</a></li>

						<li class="active"><a title="" href="#">Report Card&nbsp;&nbsp;&nbsp;>&nbsp;&nbsp;&nbsp;View Patient</a></li>

		            </ul>

			        

			    </div>

			    <!-- /breadcrumbs line -->



			    <!-- Page header -->

			    <div class="page-header">

			    	<div class="page-title">

				    	<h5><strong>Dashboard</strong>&nbsp;&nbsp;&nbsp;>&nbsp;&nbsp;&nbsp;View Patient</h5>

				    	<span>Welcome, Admin!</span>

			    	</div>



			    	<ul class="page-stats">

			    		<!--<li>

			    			<div class="showcase">

			    				<span>New Patient</span>

			    				<h2><?php echo get_newtotal(); ?></h2>

			    			</div>

			    			<div id="total-visits" class="chart"><?php echo get_newbars(); ?></div>

			    		</li>-->

			    		<li>

			    			<div class="showcase">

			    				<span>Total Patient</span>

			    				<h2><?php echo get_total(); ?></h2>

			    			</div>

			    			<div id="balance" class="chart"><?php echo get_bars(); ?></div>

			    		</li>

			    	</ul>

			    </div>

			    <!-- /page header -->




<!--
		    	<h5 class="widget-name"><i class="icon-th"></i>View Patient</h5>-->

                



                <!-- Media datatable -->

                <div class="widget">

                	<div class="navbar">

                    	<div class="navbar-inner">

                        	<h6>Dashboard Patient Chart</h6>

                            <div class="nav pull-right" style="padding: 8px;">

                                <a href="get_all_data_xlsx.php"><i class="fam-page-excel"></i></a>

                            </div>

                        </div>

                    </div>

                    <div class="table-overflow">

                        <table class="table table-striped table-bordered table-checks media-table">

                            <thead>

                                <tr>

                                <th width="106">Date</th>
                                    <th width="71">Image</th>
                                    <th width="122">Patient</th>
                                    <th width="58">Age</th>
                                    <th width="88">
									<form name="allprogram" id="allprogram" method="post">
									<select name="program" id="program" >
										<option <?php if(isset($_POST['program']) and $_POST['program'] == 'All'){echo 'selected';}?> value="All">All</option>
										<option <?php if(isset($_POST['program']) and $_POST['program'] == 'Diabetic'){echo 'selected';}?> value="Diabetic">Diabetic</option>
										<option <?php if(isset($_POST['program']) and $_POST['program'] == 'Theraphetic Life Style Program'){echo 'selected';}?> value="Theraphetic Life Style Program">Theraphetic Life Style Program</option>
										<option <?php if(isset($_POST['program']) and $_POST['program'] == 'HCG Weight Loss Program'){echo 'selected';}?> value="HCG Weight Loss Program">HCG Weight Loss Program</option>
										<option <?php if(isset($_POST['program']) and $_POST['program'] == 'Government Eahanced'){echo 'selected';}?> value="Government Eahanced">Government Eahanced</option>
									</select>
									</form>
									</th>
                                    <th width="60">BMI</th>
                                    <th width="74">BP</th>
                                    <th width="130">Choles</th>
                                    <th width="60">HDL</th>
                                    <th width="58">LDL</th>
                                    <th width="97">Trigly</th>
                                    <th width="85">HBa1c</th>
                                </tr>

                            </thead>

                            <tbody>

                                

								

								<?php $slno =  1; for($i=0; $i<count($result); $i++ ) { ?>

								

								<tr>

									<td><?php  echo $result[$i]['date_time']; ?></td>

			                        <td><a href="<?php  echo $result[$i]['photo']; ?>" title="" class="lightbox"><img width="37" height="36" src="<?php  echo $result[$i]['photo']; ?>" alt="" /></a></td>
			                        <td><a href="edit_patient_nmac.php?id=<?php  echo $result[$i]['id']; ?>" title=""><?php  echo $result[$i]['name']; ?></a></td>
                                    <td><?php  echo $result[$i]['age']; ?></td>
									<td><?php  echo $result[$i]['program']; ?></td>
			                        <td style="background: <?php  $colorbmi = get_bmi($result[$i]['bmi'],''); echo $colorbmi['color']; ?>"><?php  echo $result[$i]['bmi']; ?></td>
                                    <td style="background: <?php  $colorbp = get_bp($result[$i]['blood_pressure'],'',$result[$i]['age'],$result[$i]['health_status']); echo $colorbp['color']; ?>"><?php  echo $result[$i]['blood_pressure']; ?></td>
                                    <td style="background: <?php  $colorcholesterol = get_cholesterol($result[$i]['cholesterol'],''); echo $colorcholesterol['color']; ?>"><?php  echo $result[$i]['cholesterol']; ?></td>
                                    <td style="background: <?php  $colorhdl = get_hdl($result[$i]['hdl'],''); echo $colorhdl['color']; ?>"><?php  echo $result[$i]['hdl']; ?></td>
                                    <td style="background: <?php  $colorldl = get_ldl($result[$i]['ldl'],''); echo $colorldl['color']; ?>"><?php  echo $result[$i]['ldl']; ?></td>
                                    <td style="background: <?php  $colortriglycerides = get_triglycerides($result[$i]['triglycerides'],''); echo $colortriglycerides['color']; ?>"><?php  echo $result[$i]['triglycerides']; ?></td>
                                    <td style="background: <?php  $colorhba1c = get_hba1c($result[$i]['hba1c'],''); echo $colorhba1c['color']; ?>"><?php  echo $result[$i]['hba1c']; ?></td>
                                </tr>

                                

                                <?php } ?>

								

                                

                            </tbody>

                        </table>

                    </div>

                </div>

                <!-- /media datatable -->





		    </div>

		    <!-- /content wrapper -->



		</div>

		<!-- /content -->



	</div>

	<!-- /content container -->

 

	<!-- Footer -->

	<div id="footer">

		<div class="copyrights">&copy; <a class="" target="_blank" href="http://www.designdot.co.in">Designdot Technologies Pvt. Ltd.</a> All rights reserved.</div>

		<ul class="footer-links">

			<li><a href="#" title=""><i class="icon-cogs"></i>Contact admin</a></li>

			<li><a href="#" title=""><i class="icon-screenshot"></i>Report bug</a></li>

		</ul>

	</div>

	<!-- /footer -->



</body>
</html>