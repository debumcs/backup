<?php

include_once('functions.php');
$con = new dbconnection();
$con->setConnection();

	$id = isset($_GET['id'])? $_GET['id'] : $_POST['id'];



	$sql = "select * from patient where id = '".$id."'";

	$result = $con->runQuery($sql);

	

	if(isset($_POST['submitreport'])){

		if($_POST['report'] == 'current'){

			//echo "<script>window.location = 'report-design/index2.php?id=".$id."'</script>";

			$sql = "select * from patient where id = '".$id."'";

$result = $con->runQuery($sql);

$sqlbmi = "SELECT a.* FROM bmi a left join bmi b on a.patient_id = b.patient_id and a.datetime > b.datetime WHERE a.patient_id = '".$id."'";
$resultbmi = $con->runQuery($sqlbmi);

$sqlbody_fat = "SELECT a.* FROM body_fat a left join body_fat b on a.patient_id = b.patient_id and a.datetime > b.datetime WHERE a.patient_id = '".$id."'";
$resultbody_fat = $con->runQuery($sqlbody_fat);

$sqlfasting = "SELECT a.* FROM fasting a left join fasting b on a.patient_id = b.patient_id and a.datetime > b.datetime WHERE a.patient_id = '".$id."'";
$resultfasting = $con->runQuery($sqlfasting);

$sqlgasscore = "SELECT a.* FROM gasscore a left join gasscore b on a.patient_id = b.patient_id and a.datetime > b.datetime WHERE a.patient_id = '".$id."'";
$resultgasscore = $con->runQuery($sqlgasscore);

$sqlmetabolic_age = "SELECT a.* FROM metabolic_age a left join metabolic_age b on a.patient_id = b.patient_id and a.datetime > b.datetime WHERE a.patient_id = '".$id."'";
$resultmetabolic_age = $con->runQuery($sqlmetabolic_age);

$sqlphq = "SELECT a.* FROM phq a left join phq b on a.patient_id = b.patient_id and a.datetime > b.datetime WHERE a.patient_id = '".$id."'";
$resultphq = $con->runQuery($sqlphq);

$sqlbp = "SELECT a.* FROM blood_pressure a left join blood_pressure b on a.patient_id = b.patient_id and a.datetime > b.datetime WHERE a.patient_id = '".$id."'";
$resultbp = $con->runQuery($sqlbp);

$sqlcholesterol = "SELECT a.* FROM cholesterol a left join cholesterol b on a.patient_id = b.patient_id and a.datetime > b.datetime WHERE a.patient_id = '".$id."'";
$resultcholesterol = $con->runQuery($sqlcholesterol);

$sqlegfr = "SELECT a.* FROM egfr a left join egfr b on a.patient_id = b.patient_id and a.datetime > b.datetime WHERE a.patient_id = '".$id."'";
$resultegfr = $con->runQuery($sqlegfr);

$sqlhba1c = "SELECT a.* FROM hba1c a left join hba1c b on a.patient_id = b.patient_id and a.datetime > b.datetime WHERE a.patient_id = '".$id."'";
$resulthba1c = $con->runQuery($sqlhba1c);

$sqlhdl = "SELECT a.* FROM hdl a left join hdl b on a.patient_id = b.patient_id and a.datetime > b.datetime WHERE a.patient_id = '".$id."'";
$resulthdl = $con->runQuery($sqlhdl);

$sqlldl = "SELECT a.* FROM ldl a left join ldl b on a.patient_id = b.patient_id and a.datetime > b.datetime WHERE a.patient_id = '".$id."'";
$resultldl = $con->runQuery($sqlldl);

$sqltri = "SELECT a.* FROM triglycerides a left join triglycerides b on a.patient_id = b.patient_id and a.datetime > b.datetime WHERE a.patient_id = '".$id."'";
$resulttri = $con->runQuery($sqltri);

$sqlothers = "SELECT a.* FROM others a left join others b on a.patient_id = b.patient_id and a.datetime > b.datetime WHERE a.patient_id = '".$id."'";
$resultothers = $con->runQuery($sqlothers);

$html = '';

$html .= '<table style="float: left; font-family: Arial; height: auto; left: 0pt; top: 0pt; width: 700;">
	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td scope="row" style="font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt; text-align: left;background-color: #041423; width: 266.5pt;"><img alt="" src="nmac-logo.jpg" /></td>
					<td scope="row" style="background-color: #2ca8e1; width: 266.5pt; text-align: right;"><img alt="" src="tracking-nmac-address.jpg" /></td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td colspan="4"></td>
	</tr>	

	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0" width="666">
				<tr>
					<td height="30" align="center" valign="middle"><h2 style="color: #000; font-size: 14pt; margin-bottom: 1.75pt;">PATIENT INFORMATION</h2></td>
				</tr>

				<tr>
					<td width="200">
						<table border="0" cellpadding="0" cellspacing="0" width="100%">
							<tr>
								<td height="147" style="font-family: Arial; font-size: 7.5pt; letter-spacing: 0.75pt; text-align: center;"><img alt="" height="129" src="../'.$result[0]['photo'].'" width="128" /></td>
							</tr>

							<tr>
								<td height="80" style=" style="font-family: Arial; font-size: 7.5pt; letter-spacing: 0.75pt; line-height: 10pt; text-align: left;"">
								<span align="center" style="margin: 0px; padding: 0px; font-size: 10.5pt; font-weight: 600; left: 0pt; right: 0pt;">'.$result[0]['name'].'</span><br>
								<span align="center"  style="margin: 0px;	padding: 0px; font-size: 8pt; font-weight: 300; left: 0pt; right: 0pt;">Age '.$result[0]['age'].'</span><br>
								<span align="center" style="margin: 0px;	padding: 0px; font-size: 8pt; font-weight: 300; left: 0pt; right: 0pt;"> D.O.B : '.$result[0]['dob'].'</span>
								</td>
							</tr>
						</table>					
					</td>

					<td width="500" valign="top">
						<table border="0" cellpadding="0" cellspacing="0" width="700">
							<tr>
								<td width="240" align="left" height="15" valign="top" scope="col" style="font-size: 8pt; font-weight:300; font-family: Arial;">
									<h3 style="margin: 0px;	padding: 0px;">Calculation on First Visit</h3>
							    </td>

                                <td width="240" align="left" valign="top" style="font-size: 8pt; font-weight:300; font-family: Arial;" scope="col">
									<h3 style="margin: 0px;	padding: 0px;">Reported By</h3>
								</td>
							</tr>

							<tr>
								<td align="left" valign="top" scope="col" style="font-size: 7.5pt; font-weight:300; font-family: Arial;">Weight : '.$result[0]['weight'].'<br>Height : '.$result[0]['height'].'<br>Race : '.$result[0]['race'].'<br>Health Status : '.$result[0]['health_status'].'<br>Program : '.$result[0]['program'].'</td>
								<td width="240" align="left" valign="top" style="font-size: 7.5pt; font-weight:300; font-family: Arial;" scope="col">Date of Admission : '.$result[0]['date_time'].'<br>Reported By : '.$result[0]['reportedby'].'<br>Received on : '.date('Y-m-d').'</td>
							</tr>

							<tr>
								<th height="12" scope="col"></th>
							</tr>                            

							<tr>
								<td width="240" align="left" height="15" valign="top" scope="col" style="font-size: 8pt; font-weight:300; font-family: Arial;">
									<h3 style="margin: 0px;	padding: 0px;">Location</h3>
								</td>

								<td width="240" align="left" height="15" valign="top" scope="col" style="font-size: 8pt; font-weight:300; font-family: Arial;">
									<h3 style="margin: 0px;	padding: 0px;">Contact Details</h3>
								</td>
							</tr>

                            <tr>
								<td width="240" align="left" valign="top" style="font-size: 7.5pt; font-weight:300; font-family: Arial;" scope="col">'.$result[0]['address'].'</td>
                                <td width="240" align="left" valign="top" style="font-size: 7.5pt; font-weight:300; font-family: Arial;" scope="col">Phone No. : '.$result[0]['phoneno'].'<br>Email Id : '.$result[0]['email'].'</td>
						    </tr>

							<tr>
								<th height="12" scope="col"></th>
							</tr>

							<tr>
								<td colspan="2" align="left" valign="top" scope="col" style="font-size: 8pt; font-weight:300; font-family: Arial;">
									<h3 style="margin: 0px;	padding: 0px;">Medical History</h3>
									'.$result[0]['medical_history'].'
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>		
		</td>
	</tr>

	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0" width="666">
				<tr>
					<th height="22"><h2 style="color: #000; font-size: 15pt; margin-bottom: 3.75pt; text-align: center; vertical-align:middle">SCORE CARD KEY</h2></th>
				</tr>

				<tr>
					<td colspan="4"></td>
				</tr>

				<tr>
					<td width="174" align="center" style="font-size:7.5pt"><img src="img/zone.jpg" width="25" height="25" /><p style="color: black; text-align: center;">You are at risk extreem danger of developing major health problems! ( Seek Urgent Medical Attention )</p></td>
					<td width="174" align="center" style="font-size:7.5pt"><img src="img/red.png" width="25" height="25" /><p style="color: black; text-align: center;">You are at risk of having major health problems!</p></td>
					<td width="174" align="center" style="font-size:7.5pt"><img src="img/yellow.png" width="25" height="25" /><p style="color: black; text-align: center;">You are at moderate risk of having major health problems!</p></td>
					<td width="174" align="center" style="font-size:7.5pt"><img src="img/green.png" width="25" height="25" /><p style="color: black; text-align: center;">Excellant Result</p></td>
				</tr>
			</table>
		</td>
	</tr>

    <tr>
		<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0">
			<tr>
				<th align="center" valign="middle" style="color:#000; text-align:center; font-size: 15pt; font-weight:bold;">BODY COMPOSITION</th>
			</tr>
		</table>
    </tr>

    <tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
                <tr>
					<th height="28" align="center" valign="middle" bgcolor="#2ca8e1" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">BMI</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><p style="color: black; "><span style="color: orange;">Underweight (&lt; 18.5)</span> | <span style="color: #56BB4D;">Normal (18.5 – 24.9)</span> | <span style="color: #ef705b;">Overweight (25 – 29.9)</span> | <span style="color: #FF0000;">Obese (&gt; 30)</span></p></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultbmi[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultbmi[0]['bmi'].'<br>';
				$databmi = get_bmi($resultbmi[0]['bmi'],$resultbmi[0]['bmi_description']); $html .= $databmi['image'];
				$html .='	</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="506">'.$resultbmi[0]['bmi_description'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
                <tr>
					<th height="28" align="center" valign="middle" bgcolor="#2ca8e1" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">Body Fat</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultbody_fat[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultbody_fat[0]['body_fat'].'<br>';
				$html .='	</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="506">'.$resultbody_fat[0]['body_fat_description'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<th height="20">&nbsp;</th>
	</tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="0">
                <tr>
					<th align="center" valign="middle" style="color:#000; text-align:center; font-size: 15pt; font-weight:bold;">HEART DISEASE</th>
				</tr>
			</table>
		</td>
    </tr>

    <tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#F90303" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">BLOOD PRESSURE</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><span style="color: #56BB4D;">Normal (&lt;129)</span> | <span style="color: orange;">Borderline (130-139) </span> | <span style="color: #ef705b;">Hypertension 1 (140-159)</span> | <span style="color: #FF0000;">Hypertension 2 (&gt;160)</span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>

						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultbp[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultbp[0]['blood_pressure'].'<br>';
							$databp = get_bp($resultbp[0]['blood_pressure'],$resultbp[0]['blood_pressure_description'],$result[0]['age'],$result[0]['health_status']); 
							$html .= $databp['image'];
							$html .= '</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="506">'.$resultbp[0]['blood_pressure_description'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#F90303" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">TOTAL CHOLESTEROL</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><span style="color: #56BB4D;">Desirable (&lt;200) </span> | <span style="color: orange;">Borderline (200 – 239)</span> | <span style="color: #ef705b;">High (&gt;=240)</span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>
						
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultcholesterol[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultcholesterol[0]['cholesterol'].'<br>';
							$datacho = get_cholesterol($resultcholesterol[0]['cholesterol'],$resultcholesterol[0]['cholesterol_description']); 
							$html .= $datacho['image'];
							$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="506">'.$resultcholesterol[0]['cholesterol_description'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#F90303" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">HDL</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><span style="color: #56BB4D;">Normal (&gt;=50) </span> | <span style="color: #F00;">Low (&lt; 50)</span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>

						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resulthdl[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resulthdl[0]['hdl'].'<br>';
							$datahdl = get_hdl($resulthdl[0]['hdl'],$resulthdl[0]['hdl_description']); 
							$html .= $datahdl['image'];
							$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="506">'.$resulthdl[0]['hdl_description'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#F90303" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">LDL</th>
				</tr>
				
				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><span style="color: #56BB4D;">Optimal (&lt;100) </span> | <span style="color: #40de32;">Near Optimal (100-129) </span> | <span style="color: orange;">Borderline (130 – 159) </span> | <span style="color: #ef705b;">High (200 – 499) </span> | <span style="color: #FF0000;">Very High (&gt;=500)</span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>

						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultldl[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultldl[0]['ldl'].'<br>';
							$dataldl = get_ldl($resultldl[0]['ldl'],$resultldl[0]['ldl_description']); 
							$html .= $dataldl['image'];
							$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="506">'.$resultldl[0]['ldl_description'].'</td>
						</tr>
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#F90303" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">TRIGLYCERIDES</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><span style="color: #56BB4D;">Optimal (&lt;150) </span> | <span style="color: orange;">Borderline (150 – 199) </span> | <span style="color: #ef705b;">High (200 – 499)</span> | <span style="color: #FF0000;">Very High (&gt;=500)</span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>

						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resulttri[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resulttri[0]['triglycerides'].'<br>';
							$datatri = get_triglycerides($resulttri[0]['triglycerides'],$resulttri[0]['triglycerides_description']); 
							$html .= $datatri['image'];
							$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="506">'.$resulttri[0]['triglycerides_description'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

    <tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0">
				<tr>
					<th align="center" valign="middle" style="color:#000; text-align:center; font-size: 15pt; font-weight:bold;">DIABETES</th>
				</tr>
			</table>
		</td>
    </tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#B81193" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">HBa1c</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;">  <span style="color: #56BB4D;">Normal (&lt; 5.6) </span> | <span style="color: orange;">Prediabetes (5.7 &macr; 6.4)</span> | <span style="color: #F00;">Diabetes (&gt;= 6.5) </span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>

						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resulthba1c[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resulthba1c[0]['hba1c'].'<br>';
							$datahba1c = get_hba1c($resulthba1c[0]['hba1c'],$resulthba1c[0]['hba1c_description']);
							$html .=$datahba1c['image'];
							$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="506">'.$resulthba1c[0]['hba1c_description'].'</td>
						</tr>
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#B81193" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">FASTING BLOOD SUGAR</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;">Fasting : <span style="color: #56BB4D;">Normal (&lt; 100) </span> | <span style="color: orange;">Prediabetes (100 – 125)</span> | <span style="color: #F00;">Diabetes (&gt;= 126) </span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>

						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultfasting[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultfasting[0]['fasting'].'<br>';
							$datafasting = get_fasting($resultfasting[0]['fasting'],$resultfasting[0]['fasting_description']);
							$html .=$datafasting['image'];
							$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="506">'.$resultfasting[0]['fasting_description'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0">
                <tr>
					<th align="center" valign="middle" style="color:#000; text-align:center; font-size: 15pt; font-weight:bold;">KIDNEY DISEASE</th>
				</tr>
			</table>
		</td>
    </tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#36AC06" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">eGRF</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><span style="color: #56BB4D;">Normal (60 to 120) </span> | <span style="color: orange;">16 to 59</span> |  <span style="color: #F00;">Danger (0 to 15) </span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>

						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultegfr[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultegfr[0]['egfr'].'<br>';
							$dataegfr = get_egfr($resultegfr[0]['egfr'],$resultegfr[0]['egfr_description']); 
							$html .= $dataegfr['image'];
							$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="506">'.$resultegfr[0]['egfr_description'].'</td>
						</tr>
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<th height="20"></th>
	</tr>
	
	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0">
				<tr>
					<th align="center" valign="middle" style="color:#000; text-align:center; font-size: 15pt; font-weight:bold;">OTHERS</th>
				</tr>
			</table>
		</td>
    </tr>
	
	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#36AC06" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">Gas Score</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>

						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultgasscore[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultgasscore[0]['gasscore'].'<br>';
							$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="506">'.$resultgasscore[0]['gasscore_description'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#36AC06" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">PHQ</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>

						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultphq[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultphq[0]['phq'].'<br>';
							$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="506">'.$resultphq[0]['phq_description'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#36AC06" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">Metabolic Age</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>

						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultmetabolic_age[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultmetabolic_age[0]['metabolic_age'].'</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="506">'.$resultmetabolic_age[0]['metabolic_age_description'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#36AC06" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">Others Details</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Smoking Cessation</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">From</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">To</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">ER Visit</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="321">Asthma/ COPD Action Plan</th>
						</tr>

						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultothers[0]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultothers[0]['smoking_cessation'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultothers[0]['smoking_fromdate'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultothers[0]['smoking_totime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultothers[0]['er_visit'].'</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="321">'.$resultothers[0]['asthma_copd'].'</td>
						</tr>						
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<th height="50"></th>
	</tr>
	
	<tr>
		<td height="30" align="center" valign="middle"><h2 style="color:#000; font-size: 14pt; margin-bottom: 2pt;">For An appointment : (441)293-5476</h2></td>
	</tr>

</table>';

		}elseif($_POST['report'] == 'dates'){
	

			$id = $_POST['id'];

			$sql = "select * from patient where id = '".$id."' ";
			$result = $con->runQuery($sql);

			$sqlbmi = "select * from bmi where patient_id = '".$id."' order by datetime desc ";
			$resultbmi = $con->runQuery($sqlbmi);

			$sqlbp = "select * from blood_pressure where patient_id = '".$id."'  order by datetime desc ";
			$resultbp = $con->runQuery($sqlbp);

			$sqlcholesterol = "select * from cholesterol where patient_id = '".$id."' order by datetime desc ";
			$resultcholesterol = $con->runQuery($sqlcholesterol);

			$sqlegfr = "select * from egfr where patient_id = '".$id."'  order by datetime desc ";
			$resultegfr = $con->runQuery($sqlegfr);

			$sqlhba1c = "select * from hba1c where patient_id = '".$id."'  order by datetime desc ";
			$resulthba1c = $con->runQuery($sqlhba1c);

			$sqlhdl = "select * from hdl where patient_id = '".$id."'  order by datetime desc ";
			$resulthdl = $con->runQuery($sqlhdl);

			$sqlldl = "select * from ldl where patient_id = '".$id."'  order by datetime desc ";
			$resultldl = $con->runQuery($sqlldl);

			$sqltri = "select * from triglycerides where patient_id = '".$id."' order by datetime desc ";
			$resulttri = $con->runQuery($sqltri);

			$sqlfasting = "SELECT * FROM fasting WHERE patient_id = '".$id."' order by datetime desc";
			$resultfasting = $con->runQuery($sqlfasting);

			$sqlbody_fat = "SELECT * FROM body_fat WHERE patient_id = '".$id."' order by datetime desc";
			$resultbody_fat = $con->runQuery($sqlbody_fat);

			$sqlgasscore = "SELECT * FROM gasscore WHERE patient_id = '".$id."' order by datetime desc";
			$resultgasscore = $con->runQuery($sqlgasscore);

			$sqlmetabolic_age = "SELECT * FROM metabolic_age WHERE patient_id = '".$id."' order by datetime desc";
			$resultmetabolic_age = $con->runQuery($sqlmetabolic_age);

			$sqlphq = "SELECT * FROM phq WHERE patient_id = '".$id."' order by datetime desc";
			$resultphq = $con->runQuery($sqlphq);

			$sqlothers = "SELECT * FROM others WHERE patient_id = '".$id."' order by datetime desc";
			$resultothers = $con->runQuery($sqlothers);
			
			$html = '';
			$html .= '<table style="float: left; font-family: Arial; height: auto; left: 0pt; top: 0pt; width: 700;">
	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td scope="row" style="font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt; text-align: left;background-color: #041423; width: 266.5pt;"><img alt="" src="nmac-logo.jpg" /></td>
					<td scope="row" style="background-color: #2ca8e1; width: 266.5pt; text-align: right;"><img alt="" src="nmac-addess.jpg" /></td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td colspan="4"></td>
	</tr>	

	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0" width="666">
				<tr>
					<td height="30" align="center" valign="middle"><h2 style="color: #000; font-size: 14pt; margin-bottom: 1.75pt;">PATIENT INFORMATION</h2></td>
				</tr>

				<tr>
					<td width="200">
						<table border="0" cellpadding="0" cellspacing="0" width="100%">
							<tr>
								<td height="147" style="font-family: Arial; font-size: 7.5pt; letter-spacing: 0.75pt; text-align: center;"><img alt="" height="129" src="../'.$result[0]['photo'].'" width="128" /></td>
							</tr>

							<tr>
								<td height="80" style=" style="font-family: Arial; font-size: 7.5pt; letter-spacing: 0.75pt; line-height: 10pt; text-align: left;"">
								<span align="center" style="margin: 0px; padding: 0px; font-size: 10.5pt; font-weight: 600; left: 0pt; right: 0pt;">'.$result[0]['name'].'</span><br>
								<span align="center"  style="margin: 0px;	padding: 0px; font-size: 8pt; font-weight: 300; left: 0pt; right: 0pt;">Age '.$result[0]['age'].'</span><br>
								<span align="center" style="margin: 0px;	padding: 0px; font-size: 8pt; font-weight: 300; left: 0pt; right: 0pt;"> D.O.B : '.$result[0]['dob'].'</span>
								</td>
							</tr>
						</table>					
					</td>

					<td width="500" valign="top">
						<table border="0" cellpadding="0" cellspacing="0" width="700">
							<tr>
								<td width="240" align="left" height="15" valign="top" scope="col" style="font-size: 8pt; font-weight:300; font-family: Arial;">
									<h3 style="margin: 0px;	padding: 0px;">Calculation on First Visit</h3>
							    </td>

                                <td width="240" align="left" valign="top" style="font-size: 8pt; font-weight:300; font-family: Arial;" scope="col">
									<h3 style="margin: 0px;	padding: 0px;">Reported By</h3>
								</td>
							</tr>

							<tr>
								<td align="left" valign="top" scope="col" style="font-size: 7.5pt; font-weight:300; font-family: Arial;">Weight : '.$result[0]['weight'].'<br>Height : '.$result[0]['height'].'<br>Race : '.$result[0]['race'].'<br>Health Status : '.$result[0]['health_status'].'<br>Program : '.$result[0]['program'].'</td>
								<td width="240" align="left" valign="top" style="font-size: 7.5pt; font-weight:300; font-family: Arial;" scope="col">Date of Admission : '.$result[0]['date_time'].'<br>Reported By : '.$result[0]['reportedby'].'<br>Received on &quot; '.date('Y-m-d').'</td>
							</tr>

							<tr>
								<th height="12" scope="col"></th>
							</tr>                            

							<tr>
								<td width="240" align="left" height="15" valign="top" scope="col" style="font-size: 8pt; font-weight:300; font-family: Arial;">
								<h3 style="margin: 0px;	padding: 0px;">Location</h3></td>
								<td width="240" align="left" height="15" valign="top" scope="col" style="font-size: 8pt; font-weight:300; font-family: Arial;">
								<h3 style="margin: 0px;	padding: 0px;">Contact Details</h3>
								</td>
                            </tr>

							<tr>
								<td width="240" align="left" valign="top" style="font-size: 7.5pt; font-weight:300; font-family: Arial;" scope="col">'.$result[0]['address'].'</td>
								<td width="240" align="left" valign="top" style="font-size: 7.5pt; font-weight:300; font-family: Arial;" scope="col">Phone No. : '.$result[0]['phoneno'].'<br>Email Id : '.$result[0]['email'].'</td>
							</tr>

							<tr>
								<th height="12" scope="col"></th>
							</tr>

							<tr>
								<td colspan="2" align="left" valign="top" scope="col" style="font-size: 8pt; font-weight:300; font-family: Arial;">
									<h3 style="margin: 0px;	padding: 0px;">Medical History</h3>
									'.$result[0]['medical_history'].'
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>		
		</td>
	</tr>

	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0" width="666">
				<tr>
					<th height="22"><h2 style="color: #000; font-size: 15pt; margin-bottom: 3.75pt; text-align: center; vertical-align:middle">SCORE CARD KEY</h2></th>
				</tr>

				<tr>
					<td colspan="4"></td>
				</tr>

				<tr>
					<td width="174" align="center" style="font-size:7.5pt"><img src="img/zone.jpg" width="25" height="25" /><p style="color: black; text-align: center;">You are at risk extreem danger of developing major health problems! ( Seek Urgent Medical Attention )</p></td>
					<td width="174" align="center" style="font-size:7.5pt"><img src="img/red.png" width="25" height="25" /><p style="color: black; text-align: center;">You are at risk of having major health problems!</p></td>
					<td width="174" align="center" style="font-size:7.5pt"><img src="img/yellow.png" width="25" height="25" /><p style="color: black; text-align: center;">You are at moderate risk of having major health problems!</p></td>
					<td width="174" align="center" style="font-size:7.5pt"><img src="img/green.png" width="25" height="25" /><p style="color: black; text-align: center;">Excellant Result</p></td>
				</tr>
			</table>		
		</td>
	</tr>

    <tr>
		<td colspan="4"></td>
	</tr>

    <tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0">
				<tr>
					<th align="center" valign="middle" style="color:#000; text-align:center; font-size: 15pt; font-weight:bold;">BODY COMPOSITION</th>
				</tr>
			</table>
		</td>
    </tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
                <tr>
					<th height="28" align="center" valign="middle" bgcolor="#2ca8e1" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">BMI</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><p style="color: black; "><span style="color: orange;">Underweight (&lt; 18.5)</span> | <span style="color: #56BB4D;">Normal (18.5 – 24.9)</span> | <span style="color: #ef705b;">Overweight (25 – 29.9)</span> | <span style="color: #FF0000;">Obese (&gt; 30)</span></p></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>';

					for($bmi = 0; $bmi<count($resultbmi); $bmi++){

					$html.='<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultbmi[$bmi]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultbmi[$bmi]['bmi'].'<br>';
							$databmi = get_bmi($resultbmi[$bmi]['bmi'],$resultbmi[$bmi]['bmi_description']); $html .=$databmi['image'];
							$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resultbmi[$bmi]['bmi_description'].'</td>
						</tr>';
					}

					$html .='</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
                <tr>
					<th height="28" align="center" valign="middle" bgcolor="#2ca8e1" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">Body Fat</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>';
					for($bft = 0; $bft<count($resultbody_fat); $bft++){
					$html.='<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultbody_fat[$bft]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultbody_fat[$bft]['body_fat'].'</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resultbody_fat[$bft]['body_fat_description'].'</td>
						</tr>';
					}
					$html .='</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<th height="20">&nbsp;</th>
	</tr>
	
	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0">
                <tr>
					<th align="center" valign="middle" style="color:#000; text-align:center; font-size: 15pt; font-weight:bold;">HEART DISEASE</th>
				</tr>
			</table>
		</td>
    </tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#F90303" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">BLOOD PRESSURE</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><span style="color: #56BB4D;">Normal (&lt;129)</span> | <span style="color: orange;">Borderline (130-139) </span> | <span style="color: #ef705b;">Hypertension 1 (140-159)</span> | <span style="color: #FF0000;">Hypertension 2 (&gt;160)</span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>';

					for($bp = 0; $bp<count($resultbp); $bp++){
					$html.='<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultbp[$bp]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultbp[$bp]['blood_pressure'].'<br>';
							$databp = get_bp($resultbp[$bp]['blood_pressure'],$resultbp[$bp]['blood_pressure_description'],$result[0]['age'],$result[0]['health_status']); 
							$html .= $databp['image'];
							$html .= '</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resultbp[$bp]['blood_pressure_description'].'</td>
						</tr>';
					}
					$html .='	</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#F90303" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">TOTAL CHOLESTEROL</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><span style="color: #56BB4D;">Desirable (&lt;200) </span> | <span style="color: orange;">Borderline (200 – 239)</span> | <span style="color: #ef705b;">High (&gt;=240)</span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>';
					for($cholesterol = 0; $cholesterol<count($resultcholesterol); $cholesterol++){
						$html.='<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultcholesterol[$cholesterol]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultcholesterol[$cholesterol]['cholesterol'].'<br>';
							$datacho = get_cholesterol($resultcholesterol[$cholesterol]['cholesterol'],$resultcholesterol[$cholesterol]['cholesterol_description']);
							$html .=$datacho['image'];
							$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resultcholesterol[$cholesterol]['cholesterol_description'].'</td>
						</tr>';
					}
					$html .='</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#F90303" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">HDL</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><span style="color: #56BB4D;">Normal (&gt;=50) </span> | <span style="color: #F00;">Low (&lt; 50)</span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>';
					for($hdl = 0; $hdl<count($resulthdl); $hdl++){
					$html.='<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resulthdl[$hdl]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resulthdl[$hdl]['hdl'].'<br>';
							$datahdl = get_hdl($resulthdl[$hdl]['hdl'],$resulthdl[$hdl]['hdl_description']); 
							$html .= $datahdl['image'];
							$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resulthdl[$hdl]['hdl_description'].'</td>
						</tr>';
					}
					$html .='</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#F90303" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">LDL</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><span style="color: #56BB4D;">Optimal (&lt;100) </span> | <span style="color: #40de32;">Near Optimal (100-129) </span> | <span style="color: orange;">Borderline (130 – 159) </span> | <span style="color: #ef705b;">High (200 – 499) </span> | <span style="color: #FF0000;">Very High (&gt;=500)</span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>';
					for($ldl = 0; $ldl<count($resultldl); $ldl++){
						$html.='<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultldl[$ldl]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultldl[$ldl]['ldl'].'<br>';
							$dataldl = get_ldl($resultldl[$ldl]['ldl'],$resultldl[$ldl]['ldl_description']);
							$html .=$dataldl['image'];
							$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resultldl[$ldl]['ldl_description'].'</td>
						</tr>';
					}
					$html .='</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#F90303" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">TRIGLYCERIDES</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><span style="color: #56BB4D;">Optimal (&lt;150) </span> | <span style="color: orange;">Borderline (150 – 199) </span> | <span style="color: #ef705b;">High (200 – 499)</span> | <span style="color: #FF0000;">Very High (&gt;=500)</span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>';
					for($tri = 0; $tri<count($resulttri); $tri++){
						$html.='<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resulttri[$tri]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resulttri[$tri]['triglycerides'].'<br>';
							$datatri = get_triglycerides($resulttri[$tri]['triglycerides'],$resulttri[$tri]['triglycerides_description']); 
							$html .= $datatri['image'];
							$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resulttri[$tri]['triglycerides_description'].'</td>
						</tr>';
					}
					$html .='</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0">
                <tr>
					<th align="center" valign="middle" style="color:#000; text-align:center; font-size: 15pt; font-weight:bold;">DIABETES</th>
				</tr>
			</table>
		</td>
    </tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#B81193" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">HBa1c</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;">  <span style="color: #56BB4D;">Normal (&lt; 5.6) </span> | <span style="color: orange;">Prediabetes (5.7 &macr; 6.4)</span> | <span style="color: #F00;">Diabetes (&gt;= 6.5) </span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>';
					for($hba1c = 0; $hba1c<count($resulthba1c); $hba1c++){
						$html.='<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resulthba1c[$hba1c]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resulthba1c[$hba1c]['hba1c'].'<br>';
							$datahba1c = get_hba1c($resulthba1c[$hba1c]['hba1c'],$resulthba1c[$hba1c]['hba1c_description']);
							$html .= $datahba1c['image'];
							$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resulthba1c[$hba1c]['hba1c_description'].'</td>
						</tr>';
					}
					$html .='</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#B81193" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">FASTING BLOOD SUGAR</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;">Fasting : <span style="color: #56BB4D;">Normal (&lt; 100) </span> | <span style="color: orange;">Prediabetes (100 – 125)</span> | <span style="color: #F00;">Diabetes (&gt;= 126) </span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>';
					for($fasting = 0; $fasting<count($resultfasting); $fasting++){
						$html.='<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultfasting[$fasting]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultfasting[$fasting]['fasting'].'<br>';
							$datafasting = get_fasting($resultfasting[$fasting]['fasting'],$resultfasting[$fasting]['fasting_description']);
							$html .= $datafasting['image'];
							$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resultfasting[$fasting]['fasting_description'].'</td>
						</tr>';
					}
					$html .='</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0">
                <tr>
					<th align="center" valign="middle" style="color:#000; text-align:center; font-size: 15pt; font-weight:bold;">KIDNEY DISEASE</th>
				</tr>
			</table>
		</td>
    </tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#36AC06" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">eGRF</th>
				</tr>

				<tr>
					<th style="font-weight: 600; font-size:8pt; text-align: center;"><span style="color: #56BB4D;">Normal (60 to 120) </span> | <span style="color: orange;">16 to 59</span> |  <span style="color: #F00;">Danger (0 to 15) </span></th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>';
					for($egfr = 0; $egfr<count($resultegfr); $egfr++){
						$html.='<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultegfr[$egfr]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultegfr[$egfr]['egfr'].'<br>';
							$dataegfr = get_egfr($resultegfr[$egfr]['egfr'],$resultegfr[$egfr]['egfr_description']); 
							$html .= $dataegfr['image']; 
							$html .='</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resultegfr[$egfr]['egfr_description'].'</td>
						</tr>';
					}
					$html .='</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0">
                <tr>
					<th align="center" valign="middle" style="color:#000; text-align:center; font-size: 15pt; font-weight:bold;">OTHERS</th>
				</tr>
			</table>
		</td>
    </tr>
	
	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#36AC06" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">Gas Score</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>';
					for($gasscore = 0; $gasscore<count($resultgasscore); $gasscore++){
					$html.='<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultgasscore[$gasscore]['datetime'].'</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultgasscore[$gasscore]['gasscore'].'</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resultgasscore[$gasscore]['gasscore_description'].'</td>
						</tr>';
					}
					$html .='</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#36AC06" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">PHQ</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>';
					for($phq = 0; $phq<count($resultphq); $phq++){
					$html.='<tr>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultphq[$phq]['datetime'].'</th>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultphq[$phq]['phq'].'</th>
								<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resultphq[$phq]['phq_description'].'</td>
							</tr>';
						}
					$html .='</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#36AC06" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">Metabolic Age</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="506">Comments</th>
						</tr>';
					for($mage = 0; $mage<count($resultmetabolic_age); $mage++){
					$html.='<tr>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultmetabolic_age[$mage]['datetime'].'</th>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultmetabolic_age[$mage]['metabolic_age'].'</th>
								<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">'.$resultmetabolic_age[$mage]['metabolic_age_description'].'</td>
							</tr>';
						}
					$html .='</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td>
			<table width="667" border="0" cellspacing="0" border="0" cellpadding="5" cellspacing="0" bgcolor="#F8F8F8">
				<tr>
					<th height="28" align="center" valign="middle" bgcolor="#36AC06" style="color: #fff; text-align:center font-size: 14pt; font-weight:bold;">Others Details</th>
				</tr>

				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">Smoking Cessation</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">From</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">To</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">ER Visit</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="321">Asthma/ COPD Action Plan</th>
						</tr>';
					for($others = 0; $others<count($resultothers); $others++){
					$html.='<tr>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultothers[$others]['datetime'].'</th>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultothers[$others]['smoking_cessation'].'</th>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultothers[$others]['smoking_fromdate'].'</th>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultothers[$others]['smoking_totime'].'</th>
								<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="75">'.$resultothers[$others]['er_visit'].'</th>
								<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Arial; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="321">'.$resultothers[$others]['asthma_copd'].'</td>
							</tr>';
						}
					$html .='</table>
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<td height="50">&nbsp;</td>
	</tr>

	<tr>
		<td align="center" valign="middle" height="30"><h2 style="color:#000; font-size: 14pt; margin-bottom: 2pt;">For An appointment : (441)293-5476</h2></td>
	</tr>
</table>';
//echo $html;
		}

	}
?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />

<title>NMAC Health Report Card</title>

<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />

<!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->

<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>



<script type="text/javascript" src="js/ajax/libs/jquery/1.7.2/jquery.min.js"></script>

<script type="text/javascript" src="js/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script>

<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDY0kkJiTPVd2U7aTOAwhc9ySH6oHxOIYM&amp;sensor=false"></script>



<script type="text/javascript" src="js/plugins/charts/excanvas.min.js"></script>

<script type="text/javascript" src="js/plugins/charts/jquery.flot.js"></script>

<script type="text/javascript" src="js/plugins/charts/jquery.flot.resize.js"></script>

<script type="text/javascript" src="js/plugins/charts/jquery.sparkline.min.js"></script>



<script type="text/javascript" src="js/plugins/ui/jquery.easytabs.min.js"></script>

<script type="text/javascript" src="js/plugins/ui/jquery.collapsible.min.js"></script>

<script type="text/javascript" src="js/plugins/ui/prettify.js"></script>

<script type="text/javascript" src="js/plugins/ui/jquery.colorpicker.js"></script>

<script type="text/javascript" src="js/plugins/ui/jquery.timepicker.min.js"></script>

<script type="text/javascript" src="js/plugins/ui/jquery.fancybox.js"></script>

<script type="text/javascript" src="js/plugins/ui/jquery.fullcalendar.min.js"></script>



<script type="text/javascript" src="js/plugins/forms/jquery.uniform.min.js"></script>

<script type="text/javascript" src="js/plugins/forms/jquery.tagsinput.min.js"></script>



<script type="text/javascript" src="js/plugins/tables/jquery.dataTables.min.js"></script>



<script type="text/javascript" src="js/files/bootstrap.min.js"></script>

<script type="text/javascript" src="js/functions/index.js"></script>



	    

<!-- required plugins -->

<script type="text/javascript" src="date5/files/date.js"></script>

<!--[if IE]><script type="text/javascript" src="files/jquery.bgiframe.min.js"></script><![endif]-->

<!-- jquery.datePicker.js -->

<script type="text/javascript" src="date5/files/jquery_002.js"></script>

<!-- datePicker required styles -->

<link rel="stylesheet" type="text/css" media="screen" href="date5/files/datePicker.css">

<link rel="stylesheet" type="text/css" media="screen" href="date5/files/demo.css">



<!-- page specific scripts -->

<script type="text/javascript" charset="utf-8">

	$(function()

	{

		$('.date-pick').datePicker({

			startDate:'01/01/1950'			

		});

	});

	

	

	

	function validation(){

		var tvalue = document.getElementById("blood_pressure").value;

		

		if(document.getElementById("name").value== ''){

			alert('Please enter name!');

			document.getElementById("name").focus();

			return false;

		}else if(document.getElementById("dob").value== ''){

			alert('Please select date of birth!');

			document.getElementById("dob").focus();

			return false;

		}else if(document.getElementById("egfr").value== ''){

			alert('Please enter egfr!');

			document.getElementById("egfr").focus();

			return false;

		}else{

			return true;

		}

	}

</script>





</head>



<body>



	<!-- Fixed top -->

	<div id="top">

		<div class="fixed">

			<a href="dashboard.php" title="" class="logo"><img src="img/logo.png" alt="" /></a>

			<ul class="top-menu">

				<li><a class="fullview"></a></li>

				<li class="dropdown">

					<a class="user-menu" data-toggle="dropdown"><img src="img/userpic.png" alt="" /><span>Howdy, Admin! <b class="caret"></b></span></a>

					<ul class="dropdown-menu">

						<li><a href="#" title="" data-toggle="modal" data-target="#ProfileView"><i class="icon-user"></i>Profile</a></li>

						<li><a href="logout.php" title=""><i class="icon-remove"></i>Logout</a></li>

					</ul>

				</li>

			</ul>

		</div>

	</div>

	<!-- /fixed top -->





	<!-- Content container -->

	<div id="container">



		<!-- Sidebar -->

		<div id="sidebar">



			<div class="sidebar-tabs">

		        <ul class="tabs-nav two-items">

		            <li><a href="#general" title=""><i class="icon-reorder"></i></a></li>

		            <li><a href="#stuff" title=""><i class="icon-cogs"></i></a></li>

		        </ul>



		        <div id="general">



			        <!-- Sidebar user -->

			        <div class="sidebar-user widget">

						<div class="navbar"><div class="navbar-inner"><h6>Wazzup, Admin!</h6></div></div>

			            

			        </div>

			        <!-- /sidebar user -->





				    <!-- Main navigation -->

			        <?php 

						get_menu();

					?>

			        <!-- /main navigation -->



		        </div>



		        <div id="stuff">



			        <!-- Social stats -->

			        <div class="widget">

			        	<h6 class="widget-name"><i class="icon-user"></i>Urgent Call</h6>

			        	<ul class="social-stats">

			        		<?php urgent_call(); ?>			        	

			        	</ul>

			        </div>

			        <!-- /social stats -->

                   



		        </div>



		    </div>

		</div>

		<!-- /sidebar -->





		<!-- Content -->

		<div id="content">



		    <!-- Content wrapper -->

		    <div class="wrapper">



			    <!-- Breadcrumbs line -->

			    <div class="crumbs">

		            <ul id="breadcrumbs" class="breadcrumb"> 

		                <li><a href="dashboard.php">Dashboard</a></li>

                        <li class="active"><a title="" href="#">Tracking Pateint PDF Report</a></li>

		            </ul>

			        

			    </div>

			    <!-- /breadcrumbs line -->



			    <!-- Page header -->

			    <div class="page-header">

			    	<div class="page-title">

				    	<h5><strong>Tracking Patient PDF Report</strong></h5>

				    	<span>Welcome, Admin!</span>

			    	</div>



			    	<ul class="page-stats">

			    		<!--<li>

			    			<div class="showcase">

			    				<span>New Patient</span>

			    				<h2><?php echo get_newtotal(); ?></h2>

			    			</div>

			    			<div id="total-visits" class="chart"><?php echo get_newbars(); ?></div>

			    		</li>-->

			    		<li>

			    			<div class="showcase">

			    				<span>Total Patient</span>

			    				<h2><?php echo get_total(); ?></h2>

			    			</div>

			    			<div id="balance" class="chart"><?php echo get_bars(); ?></div>

			    		</li>

			    	</ul>

			    </div>

			    <!-- /page header -->





		    	<!-- <h5 class="widget-name"><i class="icon-th"></i>PDF Report</h5> -->

               



                <!-- add patient form -->

				<div class="row-fluid">

<div class="span12 patient_profile">



<div class="span6 profile_details">

<div class="profile_details_inner">

<div class="span6 profile_brd_rt">

<div class="patient_profile_section">



<div class="profile-img">

<img src="<?php echo $result[0]['photo'];?>" width="153" height="143" alt="<?php echo $result[0]['name'];?>">

</div>



<div class="profile_name_details">

<h2><?php echo $result[0]['name'];?></h2>

</div>

</div>



</div>

<div class="span6">

<div class="new_encounter_form">

<form class="">

<div class="row-fluid">

                                        <div class="span3"><div class="control-group">

						            <label class="control-label">Age</label>

	<div class="controls"><input type="text" class="span12" placeholder="<?php echo $result[0]['age'];?>" readonly name="" value=""></div>

						        </div></div>

                                        <div class="span9"><div class="control-group">

						            <label class="control-label">Date Of Birth</label>

						            

				<div class="controls"><input type="text" class="span12" placeholder="<?php echo $result[0]['dob'];?>" readonly name="" value=""></div>

									

						        </div></div>

                                        </div>



<div class="row-fluid">

                                        <div class="span6"><div class="control-group">

						            <label class="control-label">Weight</label>

						            <div class="controls"><input type="text" class="span12" placeholder="<?php echo $result[0]['weight'];?>" readonly name="" value=""></div>

						        </div></div>

                                <div class="span6"><div class="control-group">

						            <label class="control-label">Height</label>

						            <div class="controls"><input type="text" class="span12" placeholder="<?php echo $result[0]['height'];?>" readonly name="" value=""></div>

						        </div></div>

                                        </div>                                        

 <div class="control-group">

						            <label class="control-label">Address:</label>

						            <div class="controls"><textarea readonly class="span12" rows="1"><?php echo $result[0]['address'];?></textarea></div>

						        </div>

								<div class="row-fluid">

                                        <div class="span6"><div class="control-group">

						            <label class="control-label">Race</label>

						            <div class="controls"><input type="text" class="span12" placeholder="<?php echo $result[0]['race'];?>" readonly name="" value=""></div>

						        </div></div>

                                <div class="span6"><div class="control-group">

						            <label class="control-label">Health Status</label>

						            <div class="controls"><input type="text" class="span12" placeholder="<?php echo $result[0]['health_status'];?>" readonly name="" value=""></div>

						        </div></div>

                                        </div>

                                                                

            <div class="form-actions"></div>                    

                                

</form>

</div>

</div>

</div>

</div>



<div class="span6">

<div class="present_doctor">

<form class="search widget" action="#">

<div class="row-fluid">

                                        <div class="span6">

                                        <div class="control-group">

						            <label class="control-label">Phone No:</label>

						            <div class="controls"><input type="text" class="span12" readonly name="" value="" placeholder="<?php echo $result[0]['phoneno'];?>"></div>

						        </div>

                                </div>

                                        <div class="span6">

                                        <div class="control-group">

						            <label class="control-label">Email Id:</label>

						            <div class="controls"><input type="email" class="span12" readonly name="" value="" placeholder="<?php echo $result[0]['email'];?>"></div>

						        </div>

                                </div>

                                        </div>

                                        <div class="control-group">

	                                <label class="control-label"><b>Medical History:</b></label>

	                                <div class="controls">

	                                    <textarea class="span12" readonly name="textarea" cols="5" rows="2"><?php echo $result[0]['medical_history'];?></textarea>

	                                </div>

	                            </div>

                                        <div class="row-fluid">

                                        <div class="span6"><div class="control-group">

						            <label class="control-label">Date</label>

						            <div class="controls"><input type="text" name="regular" placeholder="<?php echo $result[0]['date_time'];?>" readonly class="span12" /></div>

						        </div></div>

                                        <div class="span6"><div class="control-group">

						            <label class="control-label">Report By</label>

						            <div class="controls"><input type="text" name="regular" placeholder="<?php echo $result[0]['reportedby'];?>" readonly class="span12" /></div>

						        </div></div>

                                        </div>

    

                            

    </form>

</div>

</div>

</div>



</div>

				

				

				

                <div id="add_patient_form">

				<?php if(isset($_POST['submitreport'])){ 

				

				$html = htmlspecialchars($html);

				

				?>

				<form class="search widget" action="report-design/index23.php" method="post" >

				<div class="form-actions">

					<input type="hidden" value="<?php echo $html; ?>" name="report" id="report" />

					<button type="submit" name="generate" id="generate" class="btn btn-primary" >Generate PDF</button>					

				</div>

				</form>

                

				<?php }else{ ?>

				

				<form class="search widget" action="reports_track.php" method="post" >

	

				<div class="control-group lable_list">

					<label class="control-label"><b>Report Type:</b></label>

					<div class="controls">

						<label class="checkbox inline"><input checked data-toggle="toggle" name="report" type="radio" value="current"> Current </label>

						<label class="checkbox inline"><input type="radio" name="report" value="dates"> All </label>

						<input type="hidden" value="<?php echo $_GET['id']; ?>" name="id" id="id" />

					</div>

				</div> 

				

				<div class="form-actions">

					<input type="submit" name="submitreport" id="submitreport" class="btn btn-primary" value="Submit" />

				</div>

				</form>

				

				<?php } ?>

				</div>

                <!-- /add patient form -->





		    </div>

		    <!-- /content wrapper -->



		</div>

		<!-- /content -->



	</div>

	<!-- /content container -->





 

	<!-- Footer -->

	<div id="footer">

		<div class="copyrights">&copy; <a class="" target="_blank" href="http://www.designdot.co.in">Designdot Technologies Pvt. Ltd.</a> All rights reserved.</div>

		<ul class="footer-links">

			<li><a href="#" title=""><i class="icon-cogs"></i>Contact admin</a></li>

			<li><a href="#" title=""><i class="icon-screenshot"></i>Report bug</a></li>

		</ul>

	</div>

	<!-- /footer -->



</body>

</html>