<?php
echo $_SERVER['REMOTE_ADDR'];
session_start();
include_once('dbconnection.php');
$con = new dbconnection();
$con->setConnection();

if(isset($_POST['submit'])){
	/*echo $_POST['username'].'<br>'.$_POST['password'];IPv4 Address: 1.23.108.29

	die();*/
	$username = trim($_POST['username']);
	$password = trim($_POST['password']);
	$ip = trim($_POST['ip']);
	$iparray = array('120.59.65.163','206.53.191.25','199.27.70.5','1.23.110.233','1.23.108.222','120.59.192.118','120.56.206.255','1.22.168.235','120.59.64.124','59.177.136.144','120.59.192.75','113.193.94.193','103.212.144.154','207.228.145.133', '103.212.144.129', '103.212.147.22');
	if (in_array($ip, $iparray)) {
		
		$sql = "select * from userlogin where username = '".$username."' and password = '".md5($password)."'";
		$result = mysql_query($sql);
		$num = mysql_num_rows($result);
		
		if($num != 0){
			$_SESSION['USER'] = $username;			
			echo "<script>window.location = 'dashboard.php';</script>";
		}else{
			echo "<script>window.location = 'index.php?flag=I';</script>";
		}
	}else{
		echo "<script>window.location = 'index.php?flag=P';</script>";
	}
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<title>Admin Panel - Powered by: DesignDot</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>

<script type="text/javascript" src="js/files/bootstrap.min.js"></script>
</head>
<body style="background:none !important;">
	<!-- Fixed top -->
	<div id="top">
		<div class="fixed">
			<!--<a href="index.php" title="" class="logo"><img src="img/logo.png"  alt="NMAC logo"></a>-->
			
		</div>
	</div>
	<!-- /fixed top -->


	<!-- Content container -->
	<div id="content">
<div class="wrapper">
<img src="img/logo_big.png" class="main_login_logo" alt="NMAC">
<div class="row-fluid well control-group main_login">

<form name="loginpage" id="loginpage" accept-charset="utf-8" method="post" action="index.php"><fieldset>
<div class="row-fluid">
<div class="span12">
<div class="widget">
<div class="navbar">
<div class="navbar-inner">
<h6 class="login_hd">Health Report Card</h6>
<h5 style="color:red;"></h5>
</div>
</div>
<div class="well">

<?php if(isset($_GET['flag']) and trim($_GET['flag']) == 'S'){?>
<div style="height:30px;" class="control-group">
<label style="float:center;" class="control-label">Session Out!</label>
</div>
<?php } ?>

<?php if(isset($_GET['flag']) and trim($_GET['flag']) == 'P'){?>
<div style="height:30px;" class="control-group">
<label style="float:center;" class="control-label">Not allowed from this system!</label>
</div>
<?php } ?>

<?php if(isset($_GET['flag']) and trim($_GET['flag']) == 'I'){?>
<div style="height:30px;" class="control-group">
<label style="float:center;" class="control-label">Username or Password Wrong!</label>
</div>
<?php } ?>

<div style="height:30px;" class="control-group">
<label style="float:left;" class="control-label">User Name</label>
<div style="width: 60%; float:right;" class="controls">
<input type="text" placeholder="User Name" name="username" value="" class="span12" id="username">
</div>
</div>
<div style="height:30px;" class="control-group">
<label style="float:left;" class="control-label">Password</label>
<div style="width: 60%; float:right;" class="controls">
<input type="password" placeholder="Password" name="password" value="" class="span12" id="password">
<input type="hidden" name="ip" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>" id="ip">
</div>
</div>
</div>
</div>
</div>
</div>

<div class="form-actions">
<input type="submit" name="submit" value="Submit" class="btn btn-info" id="submit">
</div>
</fieldset>
</form>
</div>
</div>
</div>
	<!-- Footer -->
	<div id="footer">
		<div class="copyrights">&copy; <a href="http://www.designdot.co.in" target="_blank" class="">Designdot Technologies Pvt. Ltd.</a> All rights reserved.</div>
		<ul class="footer-links">
			<li><a href="#" title=""><i class="icon-cogs"></i>Contact admin</a></li>
			<li><a href="#" title=""><i class="icon-screenshot"></i>Report bug</a></li>
		</ul>
	</div>
	<!-- /footer -->

</body>
</html>