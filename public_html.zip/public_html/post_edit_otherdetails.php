<?php
include_once('functions.php');
$con = new dbconnection();
$con->setConnection();

$referer_page = $_SERVER["HTTP_REFERER"];

$datetime 			= explode('-',$_POST['editdateother']);
$id 				= $_POST['editidother'];
$patientid			= $_POST['editpatientidother'];
$type				= $_POST['edittypeother'];
$smoking_cessation	= $_POST['editsmoking_cessation'];

$smoking_fromdate 	= explode('-',$_POST['editsmoking_cessationfrom']);
$smoking_totime 	= explode('-',$_POST['editsmoking_cessationto']);
$er_visit 			= $_POST['editer_visit'];
$asthma_copd 		= $_POST['editasthma_copd'];
/*echo '<pre>';
print_r($_POST);
die();*/

	$sql = "UPDATE others SET ";
	$sql .= " smoking_cessation = '".$smoking_cessation."', ";
	$sql .= " smoking_fromdate = '".$smoking_fromdate[2].'-'.$smoking_fromdate[1].'-'.$smoking_fromdate[0]."', ";
	$sql .= " smoking_totime = '".$smoking_totime[2].'-'.$smoking_totime[1].'-'.$smoking_totime[0]."', ";
	$sql .= " er_visit = '".$er_visit."', ";
	$sql .= " asthma_copd = '".$asthma_copd."', ";
	$sql .= " datetime = '".$datetime[2].'-'.$datetime[1].'-'.$datetime[0]."', modifieddate = '".date('Y-m-d H:i:s')."' where id = '".$id."' and patient_id = '".$patientid."' ";

	$result=$con->InsertQuery($sql);
	if($result){
		echo "<script>window.location = '".$referer_page."'</script>";
	}else{
		echo "<script>window.location = '".$referer_page."'</script>";
	}
	


?>