<?php
class dbconnection
{

	var $host;
	var $username;
	var $password;
	var $database;
	var $dbconn;

	function __construct() {
		$this->host = "127.0.0.1";
		$this->database =  "nmaclab_nmachealth";
		$this->username =  "nmaclab_nhealth";
		$this->password =  "~!nmachealth@509";	
	}
	
	function  setConnection()
	{
		$this->dbconn = mysql_connect($this->host,$this->username,$this->password);
		mysql_select_db($this->database) or die("could not select Database");
	}
	
	function  lastinsertid()
	{
		$this->dbconn = mysql_connect($this->host,$this->username,$this->password);
		mysql_select_db($this->database) or die("could not select Database");
		return mysql_insert_id();
	}

	function runQuery($sql) 
	{
		$this->dbconn = mysql_connect($this->host,$this->username,$this->password);
		mysql_select_db($this->database) or die("could not select Database");
		$rsinfo = mysql_query($sql);
		//print_r($rsinfo);
		$totalrows=0;
		$trecord = @mysql_num_rows($rsinfo);
		
		if ($trecord != 0 )
		{
			while ($row = mysql_fetch_array($rsinfo)) {
				$result[$totalrows]=$row;
				$totalrows++;
			}
			mysql_free_result($rsinfo);
			return $result;
		}
		else
		return false;
	}

	function UpdateQuery($sql_statement)
	{
		$this->dbconn = mysql_connect($this->host,$this->username,$this->password);
		mysql_select_db($this->database) or die("could not select Database");
		
		$check=mysql_query($sql_statement);
		if(mysql_affected_rows()===1){
			$ErrorCode=true;
		}else{
			$ErrorCode=false;
		}
		return $ErrorCode;
	}

	function InsertQuery($sql_statement)
	{
		$this->dbconn = mysql_connect($this->host,$this->username,$this->password);
		mysql_select_db($this->database) or die("could not select Database");
		
		$check=mysql_query($sql_statement);
		if(mysql_affected_rows()===1){
			$ErrorCode=true;
		}else{
			$ErrorCode=false;
		}
		return $ErrorCode;
	}

	function Close()
	{
		mysql_close();
	}

}

?> 