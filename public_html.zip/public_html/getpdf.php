<?php
include_once('dbconnection.php');
$con = new dbconnection();
$con->setConnection();

$id = $_GET['id'];

$sql = "select * from patient where id = '".$_GET['id']."'";
$result = $con->runQuery($sql);

$sqlbmi = "select max(bmi.id), bmi.* from bmi where patient_id = '".$_GET['id']."' group by bmi.patient_id order by bmi.id desc limit 1";
$resultbmi = $con->runQuery($sqlbmi);

$sqlascvd = "select max(ascvd.id), ascvd.* from ascvd where patient_id = '".$_GET['id']."' group by ascvd.patient_id order by ascvd.id desc limit 1 ";
$resultascvd = $con->runQuery($sqlascvd);

$sqlbp = "select max(blood_pressure.id), blood_pressure.* from blood_pressure where patient_id = '".$_GET['id']."' group by blood_pressure.patient_id order by blood_pressure.id desc limit 1";
$resultbp = $con->runQuery($sqlbp);

$sqlcholesterol = "select max(cholesterol.id), cholesterol.* from cholesterol where patient_id = '".$_GET['id']."' group by cholesterol.patient_id order by cholesterol.id desc limit 1";
$resultcholesterol = $con->runQuery($sqlcholesterol);

$sqlegfr = "select max(egfr.id), egfr.* from egfr where patient_id = '".$_GET['id']."' group by egfr.patient_id order by egfr.id desc limit 1";
$resultegfr = $con->runQuery($sqlegfr);

$sqlhba1c = "select max(hba1c.id), hba1c.* from hba1c where patient_id = '".$_GET['id']."' group by hba1c.patient_id order by hba1c.id desc limit 1";
$resulthba1c = $con->runQuery($sqlhba1c);

$sqlhdl = "select max(hdl.id), hdl.* from hdl where patient_id = '".$_GET['id']."' group by hdl.patient_id order by hdl.id desc limit 1";
$resulthdl = $con->runQuery($sqlhdl);

$sqlldl = "select max(ldl.id), ldl.* from ldl where patient_id = '".$_GET['id']."' group by ldl.patient_id order by ldl.id desc limit 1";
$resultldl = $con->runQuery($sqlldl);

$sqltri = "select max(triglycerides.id), triglycerides.* from triglycerides where patient_id = '".$_GET['id']."' group by triglycerides.patient_id order by triglycerides.id desc limit 1";
$resulttri = $con->runQuery($sqltri);

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<title>NMAC Health Report Card</title>
<link href="report-design/css/bootstrap.css" rel="stylesheet" type="text/css" />

</head>
<style>
body{
	background-color:#FFF;
	background-image:none;
	}
#p-card{
	margin-left:-20px;
	font-size:12px;
	margin-top:10px; 
	
	}
	 .foot{width:800px; height:270px; position:static; background:none; font-family:"Raleway",sans-serif !important; border-top:3px dotted ;}
    
.row-fluid .span21 {
    width: 35.894%;
	
}
.wrapper {
    margin: 0px 60px 20px;
    position: relative;
}
.score_card img {
    float: left;
    width: 100%;
    margin-left: 18px;
}
.score_card p {
    color: #000;
    display: table-cell;
    line-height: 15px;
	height: 20px;
	text-align:center;
	margin-left:px;
	font-size:12px;
	
}
.tabl-text{
margin-left:10px;
margin-right:10px;
}
/*.tabl-div{margin-top: -50px;}*/
.tabl{
    border: 1px solid black;
    border-collapse: collapse;
}
td{height:20px;}

.mar{margin-top: 30px;}


.br{border-bottom:none;}
.score_card img {
    float: left;
    width: 100%;
    margin-left: 25px;}
.page-title{float:none; margin-left:-10px; padding:0px; }
.heading{color:#2CA9E0; margin-left:10px;}
.image-top{margin-left: 55px;}
.p-name{margin-top: -10px; margin-left:45px;}
.name{margin-left:50px;}
.dop{margin-top: -35px;}
.widget-name{background:none;}
.bor{border-bottom:1px solid;}
</style>
<body>

	

	<!-- Content container -->
	<div id="container" style="padding-bottom:30px;">

		<!-- Content -->
		<div id="content1" >
		    <div class="wrapper">
			    <div class="page-header">
			    	<div class="page-title" align="center">
				    	<img src="img/logo_big.png"  alt="" width="200" height="130">
			    		<h1 class="heading">HEALTH REPORT CARD</h1>
			    	</div>
			    </div>

				<div class="row-fluid">
					<div class="span12 patient_profile br">
						<div class="span7">
							<div class="present_doctor">
								<table >
									<tr>
										<td><b>Weight</b></td>
										<td></td>
										<td>:</td>
										<td></td>
										<td><?php echo $result[0]['weight'];?></td>
									</tr>
									<tr>
										<td><b>Height</b></td>
										<td></td>
										<td>:</td>
										<td></td>
										<td><?php echo $result[0]['height'];?></td>
									</tr>
									<tr>
										<td><b>Address</b></td>
										<td></td>
										<td>:</td>
										<td></td>
										<td><?php echo $result[0]['address'];?></td>
									</tr>
									<tr>
										<td><b>Phone No.</b></td>
										<td></td>
										<td>:</td>
										<td></td>
										<td><?php echo $result[0]['phoneno'];?></td>
									</tr>
									<tr>
										<td><b>Email Id</b></td>
										<td></td>
										<td>:</td>
										<td></td>
										<td><?php echo $result[0]['email'];?></td>
									</tr>                                      
									<tr>
										<td><b>Date</b></td>
										<td></td>
										<td>:</td>
										<td></td>
										<td><?php echo $result[0]['date_time'];?></td>
									</tr>
									<tr>
										<td><b>Report By</b></td>
										<td></td>
										<td>:</td>
										<td></td>
										<td><?php echo $result[0]['reportedby'];?></td>
									</tr>
									<tr>
										<td><b>Medical History</b></td>
										<td></td>
										<td>:</td>
										<td></td>
										<td ><?php echo $result[0]['medical_history'];?></td>
									</tr>
								</table>


</div>
</div>
<div class="span5">
<div class="patient_profile_section" style="float:right;" >

<div class="img">
<img src="<?php echo $result[0]['photo'];?>" class="image-top" alt="<?php echo $result[0]['name'];?>">
<H6 class="name" align="center"><strong><?php echo $result[0]['name'];?></strong></H6>
<p class="p-name" align="center">Age <?php echo $result[0]['age'];?></p>
<p class="p-name" align="center">D.O.B - <?php echo $result[0]['dob'];?></p>
</div>





</div>
</div>
</div>

</div>
<!-- /Details of person -->
<div class="row-fluid">
<div class="span12 dop">
<div class="span12">
<h5 class="widget-name bor" ><i class="icon-key"></i>SCORE CARD KEY</h5>
</div>
<div class="span12">
<div class="span3">
<div class="span12 score_card">
<div class="span21"><img src="img/zone.jpg" alt="" style="margin-left:18px"></div>
<div class="span10" id="p-card"><p>Your at risk extreem dranger of developing major health problems!<br> ( Seek Urgent Medical Attention )</p></div>
</div>
</div>

<div class="span3">
<div class="span12 score_card">
<div class="span21"><img src="img/red.png" alt="" style="margin-left:17px;"></div>
<div class="span10" id="p-card"><p >Your at risk of having major health problems!</p></div>
</div>
</div>
<div class="span3">
<div class="span12 score_card">
<div class="span21"><img src="img/yellow.jpeg" alt="" style="margin-left:17px;" ></div>
<div class="span10" id="p-card"><p>Your at moderate risk of having major health problems!</p></div>
</div>
</div>
<div class="span3">
<div class="span12 score_card">
<div class="span21"><img src="img/Green.jpeg" alt="" style="margin-left:17px;" ></div>
<div class="span10" id="p-card" style="margin-left:7px;"><p>Excellant Result</p></div>
</div>
</div>
</div>
</div>
</div>

















<h5 class="widget-name"></h5>

<div class="row-fluid">
<div class="span12">
<div class="span12">

		    	<h5 class="widget-name bor"><i class="icon-user"></i>BODY COMPOSITION</h5>
                <!-- body Composition -->
                <div class="row-fluid">
                <div class="span12">
                
                <ul class="list_inline">
                <li style="font-size:16px;">
				            		 BMI: 
				            		</li>
                                    <li class="tx_lt_gr">Underweight (&lt; 18.5) </li>
                                    <li class="tx_gr">Normal (18.5 – 24.9) </li>
                                    <li class="tx_yl">Overweight (25 – 29.9)</li>
                                    <li class="tx_rd">Obese (&gt; 30) </li>
                                    </ul>                
<div class="health_card">
<table style="width:100%" class="tabl">
  <tr>
    <th class="tabl">Date</th>
    <th class="tabl">Score Card</th>		
    <th class="tabl">Sign</th>
     <th class="tabl">Comments</th>
  </tr>
  <tr>
    <td class="tabl"><div class="tabl-div" align="center"><?php echo $resultbmi[0]['datetime'];?></div></td>
    <td class="tabl"><div class="tabl-div" align="center"><?php echo $resultbmi[0]['bmi'];?></div></td>		
    <td class="tabl ">
		<?php if(floatval($resultbmi[0]['bmi'])<18.5){ ?><div class="circle_light_green tabl-div"></div>
		<?php }elseif(floatval($resultbmi[0]['bmi'])>=18.5 and floatval($resultbmi[0]['bmi'])<25){ ?><div class="circle_green tabl-div"></div>
		<?php }elseif(floatval($resultbmi[0]['bmi'])>=25 and floatval($resultbmi[0]['bmi'])<30){ ?><div class="circle_yellow tabl-div"></div>
		<?php }elseif(floatval($resultbmi[0]['bmi'])>30){ ?><div class="circle_red tabl-div"></div><?php } ?>
	</td>
    <td class="tabl " align="justify" style="width:320px;"><p class="tabl-text"><?php echo $resultbmi[0]['bmi_description'];?></p></td>
    
  </tr>
  
 
  
</table>

</div>   

                </div>
                
                </div>
		    	<!-- /body Composition -->
                
                
                <h5 class="widget-name bor mar"><i class="icon-heart"></i>HEART DISEASE</h5>
                <!-- heart Disease -->
                <div class="row-fluid">
                <div class="span12">
                
                <ul class="list_inline">
                <li style="font-size:16px;">
				            		 BLOOD PRESSURE
				            		</li>
                                    <li class="tx_gr">Normal </li>
                                    <li class="tx_yl">Prehypertension </li>
                                    <li class="tx_rd">Hypertension Stage 1</li>
                                    <li class="tx_rd">Hypertension Stage 2 </li>
                                    </ul>                
<div class="health_card">
<table style="width:100%" class="tabl">
  <tr>
    <th class="tabl">Date</th>
    <th class="tabl">Score Card</th>		
    <th class="tabl">Sign</th>
     <th class="tabl">Comments</th>
  </tr>
  <tr>
    <td class="tabl"><div class="tabl-div" align="center"><?php echo $resultbp[0]['datetime'];?></div></td>
    <td class="tabl"><div class="tabl-div" align="center"><?php echo $resultbp[0]['blood_pressure'];?></div></td>		
    <td class="tabl ">
		<?php if(floatval($resultbp[0]['blood_pressure'])<18.5){ ?><div class="circle_light_green tabl-div"></div>
		<?php }elseif(floatval($resultbp[0]['blood_pressure'])>=18.5 and floatval($resultbp[0]['blood_pressure'])<25){ ?><div class="circle_green tabl-div"></div>
		<?php }elseif(floatval($resultbp[0]['blood_pressure'])>=25 and floatval($resultbp[0]['blood_pressure'])<30){ ?><div class="circle_yellow tabl-div"></div>
		<?php }elseif(floatval($resultbp[0]['blood_pressure'])>30){ ?><div class="circle_red tabl-div"></div><?php } ?>
	</td>
    <td class="tabl " align="justify" style="width:320px;"><p class="tabl-text"><?php echo $resultbp[0]['blood_pressure_description'];?></p></td>
    
  </tr>
  
 
  
</table>

</div>   

                </div>
                
                </div>
                
                
               
                <!-- heart Disease -->
                <div class="row-fluid mar">
                <div class="span12">
                
                <ul class="list_inline">
                <li style="font-size:16px;">
				            		 TOTAL CHOLOESTEROL
				            		</li>
                                    <li class="tx_gr">Desirable (&lt; 200)  </li>
                                    <li class="tx_yl">Borderline (200 – 239) </li>
                                    <li class="tx_rd">High (&gt;=240)</li>
                                    </ul>                
<div class="health_card">
<table style="width:100%" class="tabl">
  <tr>
    <th class="tabl">Date</th>
    <th class="tabl">Score Card</th>		
    <th class="tabl">Sign</th>
     <th class="tabl">Comments</th>
  </tr>
  <tr>
    <td class="tabl"><div class="tabl-div" align="center"><?php echo $resultcholesterol[0]['datetime'];?></div></td>
    <td class="tabl"><div class="tabl-div" align="center"><?php echo $resultcholesterol[0]['cholesterol'];?></div></td>		
    <td class="tabl ">
		<?php if(floatval($resultcholesterol[0]['cholesterol'])<200){ ?><div class="circle_green tabl-div"></div>
		<?php }elseif(floatval($resultcholesterol[0]['cholesterol'])>=200 and floatval($resultcholesterol[0]['cholesterol'])<=239){ ?><div class="circle_yellow tabl-div"></div>
		<?php }elseif(floatval($resultcholesterol[0]['cholesterol'])>=240){ ?><div class="circle_red tabl-div"></div><?php } ?>
	</td>
    <td class="tabl " align="justify" style="width:320px;"><p class="tabl-text"><?php echo $resultcholesterol[0]['cholesterol_description'];?></p></td>
    
  </tr>
  
 
  
</table>

</div>   

                </div>
                
                </div>
                
                
                <div class="row-fluid mar">
                <div class="span12">
                
                <ul class="list_inline">
                <li style="font-size:16px;">
				            		 HDL
				            		</li>
                                    <li class="tx_rd">Low (&lt; 50) </li>
                                    <li class="tx_gr">Normal (&gt;=50)</li>
                                    </ul>                
<div class="health_card">
<table style="width:100%" class="tabl">
  <tr>
    <th class="tabl">Date</th>
    <th class="tabl">Score Card</th>		
    <th class="tabl">Sign</th>
     <th class="tabl">Comments</th>
  </tr>
  <tr>
    <td class="tabl"><div class="tabl-div" align="center"><?php echo $resulthdl[0]['datetime'];?></div></td>
    <td class="tabl"><div class="tabl-div" align="center"><?php echo $resulthdl[0]['hdl'];?></div></td>		
    <td class="tabl ">
		<?php if(floatval($resulthdl[0]['hdl'])>=50){ ?><div class="circle_green tabl-div"></div>
		<?php }elseif(floatval($resulthdl[0]['hdl'])<50){ ?><div class="circle_red tabl-div"></div><?php } ?>
	</td>
    <td class="tabl " align="justify" style="width:320px;"><p class="tabl-text"><?php echo $resulthdl[0]['hdl_description'];?></p></td>
    
  </tr>
  
 
  
</table>

</div>   

                </div>
                
                </div>
                
                
                <div class="row-fluid mar">
                <div class="span12">
                
                <ul class="list_inline">
                <li style="font-size:16px;">
				            		 LDL
				            		</li>
                                      <li class="tx_gr">Optimal (&lt; 100) </li>
                                    
                                    <li class="tx_yl">Borderline (130 – 159)</li>
                                    <li class="tx_rd">High (200 – 499)</li>
                                    <li class="tx_rd_drk">Very High (&gt;=500)</li>
                                    </ul>                
<div class="health_card">
<table style="width:100%" class="tabl">
  <tr>
    <th class="tabl">Date</th>
    <th class="tabl">Score Card</th>		
    <th class="tabl">Sign</th>
     <th class="tabl">Comments</th>
  </tr>
  <tr>
    <td class="tabl"><div class="tabl-div" align="center"><?php echo $resultldl[0]['datetime'];?></div></td>
    <td class="tabl"><div class="tabl-div" align="center"><?php echo $resultldl[0]['ldl'];?></div></td>		
    <td class="tabl ">
		<?php if(floatval($resultldl[0]['ldl'])<100){ ?><div class="circle_green tabl-div"></div>
		<?php }elseif(floatval($resultldl[0]['ldl'])>=100 and floatval($resultldl[0]['ldl'])<200){ ?><div class="circle_yellow tabl-div"></div>
		<?php }elseif(floatval($resultldl[0]['ldl'])>=200 and floatval($resultldl[0]['ldl'])<500){ ?><div class="circle_red tabl-div"></div>
		<?php }elseif(floatval($resultldl[0]['ldl'])>500){ ?><div class="circle_dark_red tabl-div"></div><?php } ?>
	</td>
    <td class="tabl " align="justify" style="width:320px;"><p class="tabl-text"><?php echo $resultldl[0]['ldl_description'];?></p></td>
    
  </tr>
  
 
  
</table>

</div>   

                </div>
                
                </div>
                
                <div class="row-fluid mar">
                <div class="span12">
                
                <ul class="list_inline">
                <li style="font-size:16px;">
				            		TRIGLYCERIDES
				            		</li>
                                        <li class="tx_gr">Optimal (&lt; 150) </li>
                                    <li class="tx_yl">Borderline (150 – 199)</li>
                                    <li class="tx_rd">High (200 – 499)</li>
                                    <li class="tx_rd_drk">Very High (&gt;=500)</li>
                                    </ul>                
<div class="health_card">
<table style="width:100%" class="tabl">
  <tr>
    <th class="tabl">Date</th>
    <th class="tabl">Score Card</th>		
    <th class="tabl">Sign</th>
     <th class="tabl">Comments</th>
  </tr>
  <tr>
    <td class="tabl"><div class="tabl-div" align="center"><?php echo $resulttri[0]['datetime'];?></div></td>
    <td class="tabl"><div class="tabl-div" align="center"><?php echo $resulttri[0]['triglycerides'];?></div></td>		
    <td class="tabl ">
		<?php if(floatval($resulttri[0]['triglycerides'])<150){ ?><div class="circle_green tabl-div"></div>
		<?php }elseif(floatval($resulttri[0]['triglycerides'])>=150 and floatval($resulttri[0]['triglycerides'])<200){ ?><div class="circle_yellow tabl-div"></div>
		<?php }elseif(floatval($resulttri[0]['triglycerides'])>=200 and floatval($resulttri[0]['triglycerides'])<500){ ?><div class="circle_red tabl-div"></div>
		<?php }elseif(floatval($resulttri[0]['triglycerides'])>500){ ?><div class="circle_dark_red tabl-div"></div><?php } ?>
	</td>
    <td class="tabl " align="justify" style="width:320px;"><p class="tabl-text"><?php echo $resulttri[0]['triglycerides_description'];?></p></td>
    
  </tr>
  
 
  
</table>

</div>   

                </div>
                
                </div>
                
                
                
               <!-- <div class="row-fluid mar">
                <div class="span12">
                
                <ul class="list_inline">
                <li style="font-size:16px;">
				            		ASCUD
				            		</li>
                                      
                                    </ul>                
<div class="health_card">

<img src="img/graph.jpg" alt="" width="800px">
</div>   

                </div>
                
                </div>-->
                
                
                
                
		    	<!-- /heart Disease -->
                <h5 class="widget-name mar bor"><i class="icon-user"></i>DIABETES</h5>
               
                <!-- Diabetes -->
                <div class="row-fluid mar">
                <div class="span12">
                
                <ul class="list_inline">
                <li style="font-size:16px;">
				            		 HBa1c:
				            		</li>
                                      <li class="tx_gr">Normal (&lt; 5.6)</li>
                                    <li class="tx_yl">Prediabetes (5.7 – 6.4)</li>
                                    <li class="tx_rd">Diabetes (&gt;= 6.5)</li>
                                    </ul>                
<div class="health_card">
<table style="width:100%" class="tabl">
  <tr>
    <th class="tabl">Date</th>
    <th class="tabl">Score Card</th>		
    <th class="tabl">Sign</th>
     <th class="tabl">Comments</th>
  </tr>
  <tr>
    <td class="tabl"><div class="tabl-div" align="center"><?php echo $resulthba1c[0]['datetime'];?></div></td>
    <td class="tabl"><div class="tabl-div" align="center"><?php echo $resulthba1c[0]['hba1c'];?></div></td>		
    <td class="tabl ">
		<?php if(floatval($resulthba1c[0]['hba1c'])<5.6){ ?><div class="circle_green tabl-div"></div>
		<?php }elseif(floatval($resulthba1c[0]['hba1c'])>=5.6 and floatval($resulthba1c[0]['hba1c'])<6.5){ ?><div class="circle_yellow tabl-div"></div>
		<?php }elseif(floatval($resulthba1c[0]['hba1c'])>=6.5){ ?><div class="circle_red tabl-div"></div><?php } ?>
	</td>
    <td class="tabl " align="justify" style="width:320px;"><p class="tabl-text"><?php echo $resulthba1c[0]['hba1c_description'];?></p></td>
    
  </tr>
  
 
  
</table>

</div>   

                </div>
                
                </div>
                
		    	<!-- /Diabetes -->
                
                <h5 class="widget-name bor mar"><i class="icon-user"></i>KIDNEY DISEASE</h5>
                <!-- Kidney Disease -->
                <div class="row-fluid mar">
                <div class="span12">
                
                <ul class="list_inline">
                <li style="font-size:16px;">
				            		 eGFR:
				            		</li>
                                      <li class="tx_rd">Kidney Failure (0 - 15) </li>
                <li class="tx_yl">Kidney Disease (15.1 – 60)</li>
                 <li class="tx_gr">Normal (60.1 – 120) </li>
                                    </ul>                
<div class="health_card">
<table style="width:100%" class="tabl">
  <tr>
    <th class="tabl">Date</th>
    <th class="tabl">Score Card</th>		
    <th class="tabl">Sign</th>
     <th class="tabl">Comments</th>
  </tr>
  <tr>
    <td class="tabl"><div class="tabl-div" align="center"><?php echo $resultegfr[0]['datetime'];?></div></td>
    <td class="tabl"><div class="tabl-div" align="center"><?php echo $resultegfr[0]['egfr'];?></div></td>		
    <td class="tabl ">
		<?php if(floatval($resultegfr[0]['egfr'])>=60.1 and floatval($resultegfr[0]['egfr'])<120){ ?><div class="circle_green tabl-div"></div>
		<?php }elseif(floatval($resultegfr[0]['egfr'])>=15.1 and floatval($resultegfr[0]['egfr'])<=60){ ?><div class="circle_yellow tabl-div"></div>
		<?php }elseif(floatval($resultegfr[0]['egfr'])<=15){ ?><div class="circle_red tabl-div"></div><?php } ?>
	</td>
    <td class="tabl " align="justify" style="width:320px;"><p class="tabl-text"><?php echo $resultegfr[0]['egfr_description'];?></p></td>
    
  </tr>
  
 
  
</table>

</div>   

                </div>
                
                </div>
                
                
		    	<!-- /Kidney Disease -->
</div>


</div>
</div>
	      </div>
		    <!-- /content wrapper -->
            <!-- Footer -->
            
	<div  class="foot">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center padd-lr0 paddbtm5">
<h2 align="center" style="color:#000000;">Call Us Today : (441)293-5476</h2>
</div>

	
		<ul class="footer-add">
<h5 align="center" style="color:#000000;">NORTHSHORE MEDICAL &amp; AESTHETICS CENTER </h5>
<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 padd-lft0">
<p align="center" style="color:#000000;">7 North Shore Road
Devonshire DV01
Bermuda </p>
</div>
<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 padd-lft0">
<p align="center" style="color:#000000;"><b><i class="fam-phone"></i>: 293-5476</b> &brvbar;&brvbar;
<b style="color:#000000;"><i class="fam-email-open-image"></i></b><a href="mailto:info@nmac.bm ">info@nmac.bm </a>
 &brvbar;&brvbar;
<b style="color:#000000;"><i class="ico-globe"></i></b><a href="#">www.nmac.com </a></p>
</div>

		</ul>
       	<div class="clint-logo" style="margin-top:20px;"><img src="img/client-logo.jpg" alt=""></div>
	</div>
	<!-- /footer -->


		</div>
		<!-- /content -->


	</div>


</body>
</html>