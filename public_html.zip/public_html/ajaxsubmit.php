<?php
include_once('functions.php');
$con = new dbconnection();
$con->setConnection();

$datetime=$_POST['datetime'];
$score=$_POST['score'];
$comment=$_POST['comment'];
$formid=$_POST['formid'];
$last_id=$_POST['patient_id'];

$sqlpatient = "select age, health_status from patient where id = '".$last_id."' ";
$resultpatient =$con->InsertQuery($sqlpatient);
$age = $resultpatient[0]['age'];
$health_status = $resultpatient[0]['health_status'];

if($formid == 'BMI'){
	
	$bmicomment = get_bmi($score,$comment);
	
	$sql = "INSERT INTO bmi SET ";
	$sql .= " patient_id = '".$last_id."', ";
	$sql .= " datetime = '".$datetime."', ";
	$sql .= " bmi = '".$score."', ";
	$sql .= " bmi_description = '".$bmicomment['comment']."', ";
	$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
	$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";

	$result=$con->InsertQuery($sql);
	if($result){
		echo "<script>window.location = 'edit_patient.php?id=".$last_id."'</script>";
	}else{
		echo "<script>window.location = 'edit_patient.php?id=".$last_id."'</script>";
	}
	
}

if($formid == 'BP'){
	
	$bpcomment = get_bp($score,$comment,$age,$health_status);
	
	$sql = "INSERT INTO blood_pressure SET ";
	$sql .= " patient_id = '".$last_id."', ";
	$sql .= " datetime = '".$datetime."', ";
	$sql .= " blood_pressure = '".$score."', ";
	$sql .= " blood_pressure_description = '".$bpcomment['comment']."', ";
	$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
	$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";

	$result=$con->InsertQuery($sql);
	if($result){
		echo "<script>window.location = 'edit_patient.php?id=".$last_id."'</script>";
	}else{
		echo "<script>window.location = 'edit_patient.php?id=".$last_id."'</script>";
	}

	
}
if($formid == 'Cholesterol'){
	
	$chocomment = get_cholesterol($score,$comment);
	
	$sql = "INSERT INTO cholesterol SET ";
	$sql .= " patient_id = '".$last_id."', ";
	$sql .= " datetime = '".$datetime."', ";
	$sql .= " cholesterol = '".$score."' ,";
	$sql .= " cholesterol_description = '".$chocomment['comment']."', ";
	$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
	$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";

	$result=$con->InsertQuery($sql);
	if($result){
		echo "<script>window.location = 'edit_patient.php?id=".$last_id."'</script>";
	}else{
		echo "<script>window.location = 'edit_patient.php?id=".$last_id."'</script>";
	}

	
}
if($formid == 'HDL'){
	
	$hdlcomment = get_hdl($score,$comment);
	
	$sql = "INSERT INTO hdl SET ";
	$sql .= " patient_id = '".$last_id."', ";
	$sql .= " datetime = '".$datetime."', ";
	$sql .= " hdl = '".$score."', ";
	$sql .= " hdl_description = '".$hdlcomment['comment']."', ";
	$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
	$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";

	$result=$con->InsertQuery($sql);
	if($result){
		echo "<script>window.location = 'edit_patient.php?id=".$last_id."'</script>";
	}else{
		echo "<script>window.location = 'edit_patient.php?id=".$last_id."'</script>";
	}

	
}
if($formid == 'LDL'){
	
	$ldlcomment = get_ldl($score,$comment);
	
	$sql = "INSERT INTO ldl SET ";
	$sql .= " patient_id = '".$last_id."', ";
	$sql .= " datetime = '".$datetime."', ";
	$sql .= " ldl = '".$score."', ";
	$sql .= " ldl_description = '".$ldlcomment['comment']."', ";
	$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
	$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";

	$result=$con->InsertQuery($sql);
	if($result){
		echo "<script>window.location = 'edit_patient.php?id=".$last_id."'</script>";
	}else{
		echo "<script>window.location = 'edit_patient.php?id=".$last_id."'</script>";
	}

	
}
if($formid == 'Triglycerides'){
	
	$tricomment = get_triglycerides($score,$comment);
	
	$sql = "INSERT INTO triglycerides SET ";
	$sql .= " patient_id = '".$last_id."', ";
	$sql .= " datetime = '".$datetime."', ";
	$sql .= " triglycerides = '".$score."', ";
	$sql .= " triglycerides_description = '".$tricomment['comment']."', ";
	$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
	$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";

	$result=$con->InsertQuery($sql);
	if($result){
		echo "<script>window.location = 'edit_patient.php?id=".$last_id."'</script>";
	}else{
		echo "<script>window.location = 'edit_patient.php?id=".$last_id."'</script>";
	}

	
}

if($formid == 'HBa1c'){
	
	$hba1ccomment = get_hba1c($score,$comment);
	
	$sql = "INSERT INTO hba1c SET ";
	$sql .= " patient_id = '".$last_id."', ";
	$sql .= " datetime = '".$datetime."', ";
	$sql .= " hba1c = '".$score."', ";
	$sql .= " hba1c_description = '".$hba1ccomment['comment']."', ";
	$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
	$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";
	$result=$con->InsertQuery($sql);
	
	if($result){
		echo "<script>window.location = 'edit_patient.php?id=".$last_id."'</script>";
	}else{
		echo "<script>window.location = 'edit_patient.php?id=".$last_id."'</script>";
	}
	
}

if($formid == 'fasting'){
	
	$fastingcomment = get_fasting($score,$comment);
	
	$sql = "INSERT INTO fasting SET ";
	$sql .= " patient_id = '".$last_id."', ";
	$sql .= " datetime = '".$datetime."', ";
	$sql .= " fasting = '".$score."', ";
	$sql .= " fasting_description = '".$fastingcomment['comment']."', ";
	$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
	$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";
	$result=$con->InsertQuery($sql);
	
	if($result){
		echo "<script>window.location = 'edit_patient.php?id=".$last_id."'</script>";
	}else{
		echo "<script>window.location = 'edit_patient.php?id=".$last_id."'</script>";
	}
	
}

if($formid == 'eGFR'){
	
	$egfrcomment = get_egfr($score,$comment);
	
	$sql = "INSERT INTO egfr SET ";
	$sql .= " patient_id = '".$last_id."', ";
	$sql .= " datetime = '".$datetime."', ";
	$sql .= " egfr = '".$score."', ";
	$sql .= " egfr_description = '".$egfrcomment['comment']."', ";
	$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
	$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";

	$result=$con->InsertQuery($sql);
	if($result){
		echo "<script>window.location = 'edit_patient.php?id=".$last_id."'</script>";
	}else{
		echo "<script>window.location = 'edit_patient.php?id=".$last_id."'</script>";
	}
}


?>