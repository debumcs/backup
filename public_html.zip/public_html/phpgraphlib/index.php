<?php
include('phpgraphlib.php');
$graph = new PHPGraphLib(357,250);
$xdata=unserialize(base64_decode($_GET['x']));
$ydata=unserialize(base64_decode($_GET['y']));
$data=array_combine($xdata,$ydata);

$graph->addData($data);
//$graph->setTitle('PPM Per Container');
$graph->setBars(false);
$graph->setLine(true);
$graph->setDataPoints(true);
$graph->setDataPointColor('maroon');
$graph->setDataValues(true);
$graph->setDataValueColor('maroon');
//$graph->setGoalLine(.0025);
$graph->setGoalLineColor('red');
$graph->createGraph();

/*
$graph = new PHPGraphLib(500,350);
$data = array(12124, 5535, 43373, 22223, 90432, 23332, 15544, 24523,
 32778, 38878, 28787, 33243, 34832, 32302);
$graph->addData($data);
$graph->setTitle('Widgets Produced');
$graph->setGradient('red', 'maroon');
$graph->createGraph();*/
?>