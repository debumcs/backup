<?php
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
date_default_timezone_set('Europe/London');

if (PHP_SAPI == 'cli')
	die('This example should only be run from a Web Browser');

/** Include PHPExcel */
require_once 'PHPExcel/Classes/PHPExcel.php';

// Create new PHPExcel object
$objPHPExcel = new PHPExcel();

// Set document properties
$objPHPExcel->getProperties()->setCreator("NMAC Patient Tracking Tool")
							 ->setLastModifiedBy("NMAC Patient Tracking Tool")
							 ->setTitle("NMAC Patient Tracking Tool Title")
							 ->setSubject("NMAC Patient Tracking Tool Subject")
							 ->setDescription("NMAC Patient Tracking Tool Description")
							 ->setKeywords("NMAC Patient Tracking Tool Keywords")
							 ->setCategory("NMAC Patient Tracking Tool Category");

$objPHPExcel->setActiveSheetIndex(0)->setTitle('BMI');

$bmiexcel = unserialize($_POST['arrayexcel']);

for($row=0; $row<count($bmiexcel); $row++ ) { 
	
	for($col=0; $col<count($bmiexcel[$row]); $col++ ) { 
		
		$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, $row+1, $bmiexcel[$row][$col]);
	}
}

$action_name = 'alldata';
$filename = $action_name.'.xlsx';

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="'.$filename.'"');
header('Cache-Control: max-age=0');

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save('php://output');
exit;
?>