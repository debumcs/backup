<?php

include_once('functions.php');
$con = new dbconnection();
$con->setConnection();

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<title>NMAC Health Report Card</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="js/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDY0kkJiTPVd2U7aTOAwhc9ySH6oHxOIYM&amp;sensor=false"></script>
<script type="text/javascript" src="js/plugins/charts/excanvas.min.js"></script>
<script type="text/javascript" src="js/plugins/charts/jquery.flot.js"></script>
<script type="text/javascript" src="js/plugins/charts/jquery.flot.resize.js"></script>
<script type="text/javascript" src="js/plugins/charts/jquery.sparkline.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.easytabs.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.collapsible.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/prettify.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.colorpicker.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.timepicker.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.fullcalendar.min.js"></script>

<script type="text/javascript" src="js/plugins/forms/jquery.uniform.min.js"></script>
<script type="text/javascript" src="js/plugins/forms/jquery.tagsinput.min.js"></script>

<script type="text/javascript" src="js/plugins/tables/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/files/bootstrap.min.js"></script>
<script type="text/javascript" src="js/functions/index.js"></script>
<!-- page specific scripts -->
<script type="text/javascript" charset="utf-8">
	$(function (){
		$('#dob').change(function (){
			var myString = $("#dob").val();
			var mySplitResult = myString.split("-");
			var pickdob = mySplitResult[2]+"-"+mySplitResult[1]+"-"+mySplitResult[0];
			dob = new Date(pickdob);

			var today = new Date();

			var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));

			document.getElementById("age").value = age;
		});
	});

	function validation(){
		var tvalue = document.getElementById("blood_pressure").value;
		if(document.getElementById("name").value== ''){
			alert('Please enter name!');
			document.getElementById("name").focus();
			return false;
		}else if(!isDate(document.getElementById("dob").value)){
			alert('Please select date of birth! Format: dd-mm-yyyy');
			document.getElementById("dob").focus();
			return false;
		}else if(document.getElementById("weight").value== ''){
			alert('Please enter weight!');
			document.getElementById("weight").focus();
			return false;
		}else if(document.getElementById("height").value== ''){
			alert('Please enter height!');
			document.getElementById("height").focus();
			return false;
		}else if(document.getElementById("phoneno").value== ''){
			alert('Please enter phoneno!');
			document.getElementById("phoneno").focus();
			return false;
		}else if(document.getElementById("email").value== ''){
			alert('Please enter email!');
			document.getElementById("email").focus();
			return false;
		}else if(document.getElementById("medical_history").value== ''){
			alert('Please enter medical history!');
			document.getElementById("medical_history").focus();
			return false;
		}else if(!isDate(document.getElementById("date_time").value)){
			alert('Please enter date! Format : dd-mm-yyyy');
			document.getElementById("date_time").focus();
			return false;
		}else if(document.getElementById("reported_by").value== ''){
			alert('Please enter reported by!');
			document.getElementById("reported_by").focus();
			return false;
		}else if(document.getElementById("bmi").value== ''){
			alert('Please enter bmi!');
			document.getElementById("bmi").focus();
			return false;
		}else if(document.getElementById("blood_pressure").value== ''){
			alert('Please enter blood pressure!');
			document.getElementById("blood_pressure").focus();
			return false;
		}else if(!isBP(tvalue)){
			alert('Please enter proper blood pressure value. e.g, 80/120!');
			document.getElementById("blood_pressure").value = '';
			document.getElementById("blood_pressure").focus();
			return false;
		}else if(document.getElementById("cholesterol").value== ''){
			alert('Please enter cholesterol!');
			document.getElementById("cholesterol").focus();
			return false;
		}else if(document.getElementById("hdl").value== ''){
			alert('Please enter hdl!');
			document.getElementById("hdl").focus();
			return false;
		}else if(document.getElementById("ldl").value== ''){
			alert('Please enter ldl!');
			document.getElementById("ldl").focus();
			return false;
		}else if(document.getElementById("triglycerides").value== ''){
			alert('Please enter triglycerides!');
			document.getElementById("triglycerides").focus();
			return false;
		}else if(document.getElementById("hba1c").value== ''){
			alert('Please enter hba1c!');
			document.getElementById("hba1c").focus();
			return false;
		}else if(document.getElementById("fasting").value== ''){
			alert('Please enter diabetes fasting!');
			document.getElementById("fasting").focus();
			return false;
		}else if(document.getElementById("egfr").value== ''){
			alert('Please enter egfr!');
			document.getElementById("egfr").focus();
			return false;
		}else if(document.getElementById("body_fat").value== ''){
			alert('Please enter body fat!');
			document.getElementById("body_fat").focus();
			return false;
		}else if(document.getElementById("gasscore").value== ''){
			alert('Please enter gas score!');
			document.getElementById("gasscore").focus();
			return false;
		}else if(document.getElementById("phq").value== ''){
			alert('Please enter phq!');
			document.getElementById("phq").focus();
			return false;
		}else if(document.getElementById("metabolic_age").value== ''){
			alert('Please enter metabolic age!');
			document.getElementById("metabolic_age").focus();
			return false;
		}else{
			return true;
		}
	}

	function isDate(txtDate)
	{
		var currVal = txtDate;
		if(currVal == '')
			return false;		

		var rxDatePattern = /^(\d{1,2})(\-|-)(\d{1,2})(\-|-)(\d{4})$/; //Declare Regex
		var dtArray = currVal.match(rxDatePattern); // is format OK?		

		if (dtArray == null)
			return false;		

		//Checks for mm/dd/yyyy format.

		dtDay = dtArray[1];
		dtYear= dtArray[5];
		dtMonth = dtArray[3];

		//var dated = dtDay+"-"+dtMonth+"-"+dtYear;
		//alert(dated);

		if (dtMonth < 1 || dtMonth > 12) 
			return false;
		else if (dtDay < 1 || dtDay> 31) 
			return false;
		else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31) 
			return false;
		else if (dtMonth == 2) 
		{
			var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
			if (dtDay> 29 || (dtDay ==29 && !isleap)) 
				return false;
		}
		return true ;
	}

	function isBP(txtDate)
	{
		var currVal = txtDate;
		var rxDatePattern = /^(\d{2,3})(\/|-)(\d{2,3})$/; //Declare Regex
		var dtArray = currVal.match(rxDatePattern); // is format OK?

		if (dtArray == null) 
			return false;

		return true;

	}

	

</script>





</head>



<body>



	<!-- Fixed top -->

	<div id="top">

		<div class="fixed">

			<a href="dashboard.php" title="" class="logo"><img src="img/logo.png" alt="" /></a>

			<ul class="top-menu">

				<li><a class="fullview"></a></li>

				<li class="dropdown">

					<a class="user-menu" data-toggle="dropdown"><img src="img/userpic.png" alt="" /><span>Howdy, Admin! <b class="caret"></b></span></a>

					<ul class="dropdown-menu">

						<li><a href="#" title="" data-toggle="modal" data-target="#ProfileView"><i class="icon-user"></i>Profile</a></li>

						<li><a href="logout.php" title=""><i class="icon-remove"></i>Logout</a></li>

					</ul>

				</li>

			</ul>

		</div>

	</div>

	<!-- /fixed top -->





	<!-- Content container -->

	<div id="container">



		<!-- Sidebar -->

		<div id="sidebar">



			<div class="sidebar-tabs">

		        <ul class="tabs-nav two-items">

		            <li><a href="#general" title=""><i class="icon-reorder"></i></a></li>

		            <li><a href="#stuff" title=""><i class="icon-cogs"></i></a></li>

		        </ul>



		        <div id="general">



			        <!-- Sidebar user -->

			        <div class="sidebar-user widget">

						<div class="navbar"><div class="navbar-inner"><h6>Wazzup, Admin!</h6></div></div>

			            

			        </div>

			        <!-- /sidebar user -->





				    <!-- Main navigation -->

			        <?php 

						get_menu();

					?>

			        <!-- /main navigation -->



		        </div>



		        <div id="stuff">



			        <!-- Social stats -->

			        <div class="widget">

			        	<h6 class="widget-name"><i class="icon-user"></i>Urgent Call</h6>

			        	<ul class="social-stats">

			        		<?php urgent_call(); ?>			        	

			        	</ul>

			        </div>

			        <!-- /social stats -->

                   



		        </div>



		    </div>

		</div>

		<!-- /sidebar -->





		<!-- Content -->

		<div id="content">



		    <!-- Content wrapper -->

		    <div class="wrapper">



			    <!-- Breadcrumbs line -->

			    <div class="crumbs">

		            <ul id="breadcrumbs" class="breadcrumb"> 

		                <li><a href="dashboard.php">Dashboard</a></li>

                        <li class="active"><a title="" href="#">Add Patient</a></li>

		            </ul>

			        

			    </div>

			    <!-- /breadcrumbs line -->



			    <!-- Page header -->

			    <div class="page-header">

			    	<div class="page-title">

				    	<h5><strong>Add Patient</strong></h5>

				    	<span>Welcome, Admin!</span>

			    	</div>



			    	<ul class="page-stats">

			    		<!--<li>

			    			<div class="showcase">

			    				<span>New Patient</span>

			    				<h2><?php echo get_newtotal(); ?></h2>

			    			</div>

			    			<div id="total-visits" class="chart"><?php echo get_newbars(); ?></div>

			    		</li>-->

			    		<li>

			    			<div class="showcase">

			    				<span>Total Patient</span>

			    				<h2><?php echo get_total(); ?></h2>

			    			</div>

			    			<div id="balance" class="chart"><?php echo get_bars(); ?></div>

			    		</li>

			    	</ul>

			    </div>

			    <!-- /page header -->





		    	<!--<h5 class="widget-name"><i class="icon-th"></i>Add Patient</h5>-->

               



                <!-- add patient form -->

                <div id="add_patient_form">

                <form class="search widget" action="postpatient.php" method="post" enctype="multipart/form-data">

	<div class="control-group">

						            <label class="control-label"><b>Name</b></label>

						            <div class="controls"><input type="text" value="" name="name" id="name" class="span12" /></div>

						        </div>  

    <div class="row-fluid">

    <div class="span2"><div class="control-group">

						            <label class="control-label"><b>Date Of Birth</b></label>

						            <div class="row-fluid">

                                    		<input type="text" name="dob" id="dob" value="" placeholder="dd-mm-yyyy" >

									</div>

                                    

									

						        </div></div>                                    

    <div class="span2">

                                        <div class="control-group">

						            <label class="control-label"><b>Age</b></label>

						            <div class="controls"><input type="text" value="" name="age" id="age" class="span12" /></div>

						        </div></div>

    <div class="span3">

                                        <div class="control-group">

						            <label class="control-label"><b>Weight</b></label>

						            <div class="controls"><input type="text" value="" name="weight" id="weight" class="span12" placeholder="lbs" /></div>

						        </div></div>

    <div class="span3">

                                        <div class="control-group">

						            <label class="control-label"><b>Height</b></label>

						            <div class="controls"><input type="text" value="" name="height" id="height" class="span12" placeholder="in" /></div>

						        </div></div>                                                                                            

                                

                                        </div> 

    <div class="row-fluid">   

    <div class="span6">                                 

    <div class="control-group">

						            <label class="control-label"><b>Address</b></label>

						            <div class="controls"><input type="text" value="" name="address" id="address" class="span12" /></div>

						        </div> 

    </div>

    <div class="span6">                                                                                    

    <div class="control-group">

						            <label class="control-label"><b>Phone no</b></label>

						            <div class="controls"><input type="text" value="" name="phoneno" id="phoneno" class="span12" /></div>

						        </div>

    </div>

    </div>

    <div class="row-fluid">

    <div class="span6">                             

    <div class="control-group">

						            <label class="control-label"><b>Email Id</b></label>

						            <div class="controls"><input type="email" value="" name="email" id="email" class="span12" /></div>

						        </div>

    </div>

    <div class="span6"> 

     <div class="control-group">

	                                        <label class="control-label"><b>Photo uploader:</b></label>

	                                        <div class="controls">

	                                            <input type="file" name="photo" id="photo" class="styled">

	                                        </div>

	                                    </div>  

    </div> 

    </div>                                                                                       

    <div class="control-group">

	                                <label class="control-label"><b>Medical History:</b></label>

	                                <div class="controls">

	                                    <textarea rows="5" cols="5" name="medical_history" id="medical_history" class="validate[required] span12"></textarea>

	                                </div>

	                            </div>

    <div class="row-fluid">

    <div class="span6">                             

    <div class="control-group">

                                        <label class="control-label"><b>Date</b></label>

                                        <div class="controls"><input type="text" name="date_time" id="date_time" placeholder="dd-mm-yyyy" /></div>

                                    </div>

    </div>

    <div class="span6">                                 

    <div class="control-group">

						            <label class="control-label"><b>Reported By</b></label>

						            <div class="controls"><input type="text" name="reported_by" id="reported_by" class="span12" /></div>

						        </div> 

    </div>

    </div>

    <div class="control-group lable_list">

						            <label class="control-label"><b>Race:</b></label>

						            <div class="controls">

												<label class="checkbox inline">

													<input checked data-toggle="toggle" name="race" type="radio" value="African"> African

												</label>

												<label class="checkbox inline">

													<input type="radio" name="race" value="American"> American 

												</label>

                                                <label class="checkbox inline">

													<input type="radio" name="race" value="Caucasian"> Caucasian  

												</label>

                                                <label class="checkbox inline">

													<input type="radio" name="race" value="Other"> Other         

												</label>

	                                        </div>

						        </div>                            

    <div class="control-group lable_list">

						            <label class="control-label"><b>Health Status:</b></label>

						            <div class="controls">

												<label class="checkbox inline">

													<input checked data-toggle="toggle" name="health_status" value="CKD" type="radio"> CKD

												</label>

												<label class="checkbox inline">

													<input type="radio" name="health_status" value="Diabetes"> Diabetes

												</label>

												<label class="checkbox inline">

													<input type="radio" name="health_status" value="None"> None

												</label>

	                                        </div>

						        </div> 

							<div class="control-group lable_list">

								

	                                        <label class="control-label"><b>Program</b></label>

	                                        <div class="controls">

	                                            <select name="program" id="program" class="styled" >
	                                                <option value="All">All</option>
	                                                <option value="Diabetic">Diabetic</option>
	                                                <option value="Theraphetic Life Style Program">Theraphetic Life Style Program</option>
	                                                <option value="HCG Weight Loss Program">HCG Weight Loss Program</option>
	                                                <option value="Government Eahanced">Government Eahanced</option>
													<option value="Alex Health Coaching Program">Alex Health Coaching Program</option>
													<option value="Naturopathic Weight Loss Program">Naturopathic Weight Loss Program</option>
	                                            </select>

	                                        </div>

	                            

							</div>

                                

    <div class="control-group action_list htl_card">

    <h4>Body Composition :</h4>

    <div class="row-fluid">

    <div class="span12">

						            <label class="control-label"><b>BMI:</b></label>

						            <div class="row-fluid">

                                    <div class="span2">

                                    <div class="control-group">

                                    <input type="text" value="" name="bmi" id="bmi" class="span12">

                                    <span class="help-block">Your Score Card</span>

                                    </div>

                                    </div>

                                    

                                    <div class="span9">

                                     <div class="control-group">

                                    <input type="text" value="" name="bmi_comment" id="bmi_comment" class="span12">

                                    <span class="help-block">Comment</span>

                                    </div>

                                    </div>

                                    </div>

                                    </div>

                                    </div>

	<div class="row-fluid">

			<div class="span12">

				<label class="control-label"><b>Body Fat :</b></label>

				<div class="row-fluid">

					<div class="span2">

						<div class="control-group">

							<input type="text" value="" name="body_fat" id="body_fat" class="span12">

							<span class="help-block">Your Score Card</span>

						</div>

					</div>



					<div class="span9">

						<div class="control-group">

							<input type="text" value="" name="body_fat_description" id="body_fat_description" class="span12">

							<span class="help-block">Comment</span>

						</div>

					</div>

				</div>

			</div>

		</div>

						        </div>

                                

    <div class="control-group action_list htl_card">

    <h4>Heart Disease :</h4>

    <div class="row-fluid">

    <div class="span12">

						            <label class="control-label"><b>Blood Pressure:</b></label>

						            <div class="row-fluid">

                                     <div class="span2">

                                     <div class="control-group">

                                    <input type="text" value="" name="blood_pressure" id="blood_pressure" class="span12">

                                    <span class="help-block">Your Score Card</span>

                                    </div>

                                    </div>

                                    

                                    <div class="span9">

                                     <div class="control-group">

                                    <input type="text" value="" name="blood_pressure_comment" id="blood_pressure_comment" class="span12">

                                    <span class="help-block">Comment</span>

                                    </div>

                                    </div>

                                    </div>

                                    </div>

    <div class="">

						            <label class="control-label"><b>Total Cholesterol:</b></label>

						            <div class="row-fluid">

                                     <div class="span2">

                                     <div class="control-group">

                                    <input type="text" value="" name="cholesterol" id="cholesterol" class="span12">

                                    <span class="help-block">Your Score Card</span>

                                    </div>

                                    </div>

                                    

                                    <div class="span9">

                                     <div class="control-group">

                                    <input type="text" value="" name="cholesterol_comment" id="cholesterol_comment" class="span12">

                                    <span class="help-block">Comment</span>

                                    </div>

                                    </div>

                                    </div>

                                    </div>

    <div class="">

						            <label class="control-label"><b>HDL:</b></label>

						            <div class="row-fluid">

                                     <div class="span2">

                                     <div class="control-group">

                                    <input type="text" value="" name="hdl" id="hdl" class="span12">

                                    <span class="help-block">Your Score Card</span>

                                    </div>

                                    </div>

                                    

                                    <div class="span9">

                                     <div class="control-group">

                                    <input type="text" value="" name="hdl_comment" id="hdl_comment" class="span12">

                                    <span class="help-block">Comment</span>

                                    </div>

                                    </div>

                                    </div>

                                    </div>

    <div class="">

						            <label class="control-label"><b>LDL:</b></label>

						            <div class="row-fluid">

                                     <div class="span2">

                                     <div class="control-group">

                                    <input type="text" value="" name="ldl" id="ldl" class="span12">

                                    <span class="help-block">Your Score Card</span>

                                    </div>

                                    </div>

                                    

                                    <div class="span9">

                                     <div class="control-group">

                                    <input type="text" value="" name="ldl_comment" id="ldl_comment" class="span12">

                                    <span class="help-block">Comment</span>

                                    </div>

                                    </div>

                                    </div>

                                    </div> 

    <div class="">

						            <label class="control-label"><b>Triglycerides:</b></label>

						            <div class="row-fluid">

                                     <div class="span2">

                                     <div class="control-group">

                                    <input type="text" value="" name="triglycerides" id="triglycerides" class="span12">

                                    <span class="help-block">Your Score Card</span>

                                    </div>

                                    </div>

                                    

                                    <div class="span9">

                                     <div class="control-group">

                                    <input type="text" value="" name="triglycerides_comment" id="triglycerides_comment" class="span12">

                                    <span class="help-block">Comment</span>

                                    </div>

                                    </div>

                                    </div>

                                    </div>                                                                                                

    

	</div>

						        </div>

    

    <div class="control-group action_list htl_card">

    <h4>Diabetes :</h4>

    <div class="row-fluid">

    <div class="span12">

						            <label class="control-label"><b>HBa1c:</b></label>

						            <div class="row-fluid">

                                     <div class="span2">

                                     <div class="control-group">

                                    <input type="text" value="" name="hba1c" id="hba1c" class="span12">

                                    <span class="help-block">Your Score Card</span>

                                    </div>

                                    </div>

                                    

                                    <div class="span9">

                                     <div class="control-group">

                                    <input type="text" value="" name="hba1c_comment" id="hba1c_comment" class="span12">

                                    <span class="help-block">Comment</span>

                                    </div>

                                    </div>

                                    </div>

                                    </div>

                                    </div>

									

									

	<div class="row-fluid">

    <div class="span12">

	<label class="control-label"><b>Fasting:</b></label>

	<div class="row-fluid">

	 <div class="span2">

	 <div class="control-group">

	<input type="text" value="" name="fasting" id="fasting" class="span12">

	<span class="help-block">Your Score Card</span>

	</div>

	</div>

	

	<div class="span9">

	 <div class="control-group">

	<input type="text" value="" name="fasting_comment" id="fasting_comment" class="span12">

	<span class="help-block">Comment</span>

	</div>

	</div>

	</div>

	</div>

	</div>

						        </div>                                                        

    

	<div class="control-group action_list htl_card">

		<h4>Kidney Disease :</h4>

		<div class="row-fluid">

			<div class="span12">

				<label class="control-label"><b>eGFR :</b></label>

				<div class="row-fluid">

					<div class="span2">

						<div class="control-group">

							<input type="text" value="" name="egfr" id="egfr" class="span12">

							<span class="help-block">Your Score Card</span>

						</div>

					</div>



					<div class="span9">

						<div class="control-group">

							<input type="text" value="" name="egfr_comment" id="egfr_comment" class="span12">

							<span class="help-block">Comment</span>

						</div>

					</div>

				</div>

			</div>

		</div>

	</div>                                                        

    

	<div class="control-group action_list htl_card">

		<h4>Others :</h4>	

		<div class="row-fluid">

			<div class="span12">

				<label class="control-label"><b>Gas Score :</b></label>

				<div class="row-fluid">

					<div class="span2">

						<div class="control-group">

							<input type="text" value="" name="gasscore" id="gasscore" class="span12">

							<span class="help-block">Your Score Card</span>

						</div>

					</div>



					<div class="span9">

						<div class="control-group">

							<input type="text" value="" name="gasscore_description" id="gasscore_description" class="span12">

							<span class="help-block">Comment</span>

						</div>

					</div>

				</div>

			</div>

		</div>

		

		<div class="row-fluid">

					<div class="span12">

						<label class="control-label"><b>PHQ :</b></label>

						<div class="row-fluid">

							<div class="span2">

								<div class="control-group">

									<input type="text" value="" name="phq" id="phq" class="span12">

									<span class="help-block">Your Score Card</span>

								</div>

							</div>



							<div class="span9">

								<div class="control-group">

									<input type="text" value="" name="phq_description" id="phq_description" class="span12">

									<span class="help-block">Comment</span>

								</div>

							</div>

						</div>

					</div>

				</div>

		

		<div class="row-fluid">

					<div class="span12">

						<label class="control-label"><b> Metabolic Age :</b></label>

						<div class="row-fluid">

							<div class="span2">

								<div class="control-group">

									<input type="text" value="" name="metabolic_age" id="metabolic_age" class="span12">

									<span class="help-block">Your Score Card</span>

								</div>

							</div>



							<div class="span9">

								<div class="control-group">

									<input type="text" value="" name="metabolic_age_description" id="metabolic_age_description" class="span12">

									<span class="help-block">Comment</span>

								</div>

							</div>

						</div>

					</div>

				</div>

		

		<div class="row-fluid">

			<div class="control-group">

				<label class="control-label"><b>Smoking Cessation:</b></label>				

				<div class="controls">

					<label class="checkbox inline">

						<input data-toggle="toggle" name="smoking_cessation" id="smoking_cessation1" type="radio" value="Yes">Yes

					</label>

					<label class="checkbox inline">

						<input data-toggle="toggle" name="smoking_cessation" id="smoking_cessation2" type="radio" value="No">No

					</label>

					<!--<label class="checkbox inline" >

						<input type="text" value="" name="smoking_cessationfrom" id="smoking_cessationfrom"  placeholder="From: dd-mm-yyyy">

					</label>

					<label class="checkbox inline" >

						<input type="text" value="" name="smoking_cessationto" id="smoking_cessationto" placeholder="To: dd-mm-yyyy">

					</label>-->

				</div>

			</div> 

			

			<div class="control-group lable_list">

				<label class="control-label"><b>ER Visit:</b></label>

				<div class="controls">

					<label class="checkbox inline">

						<input checked data-toggle="toggle" name="er_visit" id="er_visit1" type="radio" value="Yes">Yes

					</label>

					<label class="checkbox inline">

						<input name="er_visit" id="er_visit2" type="radio" value="No">No

					</label>

				</div>

			</div>

			

			<div class="control-group group_clear">

				<label class="control-label"><b>Asthma/ COPD  Action Plan:</b></label>

				<div class="controls">

					<label class="checkbox inline chk_full marg_lt0">

						<textarea placeholder="" rows="5" name="asthma_copd" id="asthma_copd"></textarea>

					</label>

				</div>

			</div>

		</div>		

		

	</div>

                                                            

    <div class="form-actions">

	                                        <button type="submit" class="btn btn-primary" onclick="return validation();">Submit</button>

	                                        <button type="button" class="btn btn-danger close">Cancel</button>

	                                    </div>

    </form>

    </div>

                <!-- /add patient form -->





		    </div>

		    <!-- /content wrapper -->



		</div>

		<!-- /content -->



	</div>

	<!-- /content container -->



	<!-- Footer -->

	<div id="footer">

		<div class="copyrights">&copy; <a class="" target="_blank" href="http://www.designdot.co.in">Designdot Technologies Pvt. Ltd.</a> All rights reserved.</div>

		<ul class="footer-links">

			<li><a href="#" title=""><i class="icon-cogs"></i>Contact admin</a></li>

			<li><a href="#" title=""><i class="icon-screenshot"></i>Report bug</a></li>

		</ul>

	</div>

	<!-- /footer -->



</body>

</html>

