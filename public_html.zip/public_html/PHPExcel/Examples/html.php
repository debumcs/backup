<?php
/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2013 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2013 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    1.7.9, 2013-06-02
 */

/** Error reporting */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
date_default_timezone_set('Europe/London');

define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');

date_default_timezone_set('Europe/London');

//include "05featuredemo.inc.php";

/** PHPExcel_IOFactory */
require_once '../Classes/PHPExcel/IOFactory.php';


$filename = "DownloadReport";
$table    = '
	<tbody><tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0">
				<tbody><tr>
					<td scope="row" style="font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt; text-align: left;background-color: #041423; width: 262.5pt;"><img alt="" src="nmac-logo.jpg"></td>
					<td scope="row" style="background-color: #2ca8e1; width: 262.5pt;"><img alt="" src="nmac-addess.jpg"></td>
				</tr>
			</tbody></table>
		
		</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>	
	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0" width="700">
				<tbody><tr>
					<td height="43" align="center" valign="middle"><h2 style="color: #000; font-size: 18.75pt; margin-bottom: 3.75pt;">PATIENT INFORMATION</h2></td>
				</tr>
				<tr>
					<td width="200">
						<table border="0" cellpadding="0" cellspacing="0" width="100%">
							<tbody><tr>
								<td style="font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: 0.75pt; text-align: center;" height="147"><img alt="" src="../uploads/09-02-2016-1455043860.png" height="129" width="128"></td>
							</tr>
							<tr>
								<td style=" style=" font-family:="" raleway,="" sans-serif;="" font-size:="" 7.5pt;="" letter-spacing:="" 0.75pt;="" line-height:="" 15pt;="" text-align:="" left;""="" height="62">
								<h2 style="font-size: 10.5pt; font-weight: 600; left: 0pt; right: 0pt;" align="center">test922016</h2>
								<h3 style="font-size: 9pt; font-weight: 300; left: 0pt; right: 0pt;" align="center">Age 50</h3>
								<h3 style="font-size: 9pt; font-weight: 300; left: 0pt; right: 0pt;" align="center"> D.O.B : 1965-02-01</h3>
								</td>
							</tr>
						</tbody></table>					
					</td>
					<td valign="top" width="500">
					
						<table border="0" cellpadding="0" cellspacing="0" width="475">
							<tbody><tr>
								<td valign="top">&nbsp;</td>
							</tr>
							<tr>
								<td scope="col" style="font-weight:300; font-family: Raleway, sans-serif;" align="left" valign="top" width="220">
									<h3>Calculation on First Visit</h3>
									Weight : 320<br>
									Height : 9.2<br>
									Race : Caucasian<br>
									Health Status : None<br>
								</td>
								<td scope="col" style="font-weight:300; font-family: Raleway, sans-serif;" align="left" valign="top" width="220">
									<h3>Reported By</h3>
									Date of Admission : 2016-02-09<br>
									Reported By : sdfReported test22<br>
									Generated on " 2016-02-13
								</td>
							</tr>
							<tr>
								<td valign="top">&nbsp;</td>
							</tr>
							<tr>
								<td scope="col" style="font-weight:300; font-family: Raleway, sans-serif;" align="left" valign="top" width="220">
									<h3>Location</h3>
									test address
								</td>
								<td scope="col" style="font-weight:300; font-family: Raleway, sans-serif;" align="left" valign="top" width="220">
									<h3>Contact Details</h3>
									Phone No. : 1234567890<br>
									Email Id : test92@test.com
								</td>
							</tr>
							<tr>
								<td valign="top">&nbsp;</td>
							</tr>
							<tr>
								<td colspan="2" scope="col" style="font-weight:300; font-family: Raleway, sans-serif;" align="left" valign="top">
									<h3>Medical History</h3>
									test92
								</td>
							</tr>
						</tbody></table>
					
					</td>
				</tr>
			</tbody></table>		
		</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0" width="700">
				<tbody><tr>
					<th colspan="5"><h2 style="color: #000; font-size: 18.75pt; margin-bottom: 3.75pt; text-align: center;">SCORE CARD KEY</h2></th>
				</tr>
				<tr>
					<td colspan="5">&nbsp;</td>
				</tr>
				<tr>
					<td align="center" width="130"><img src="danger.png" height="24" width="24"><p style="color: black; text-align: center;">Your at risk extreem dranger of developing major health problems! ( Seek Urgent Medical Attention )</p></td>
					<td align="center" width="130"><img src="red.png" height="25" width="25"><p style="color: black; text-align: center;">Your at risk of having major health problems!</p></td>
					<td align="center" width="130"><img src="yellow.png" height="25" width="25"><p style="color: black; text-align: center;">Your at moderate risk of having major health problems!</p></td>
					<td align="center" width="130"><img src="green.png" height="26" width="26"><p style="color: black; text-align: center;">Excellant Result</p></td>
					<td align="center" width="150">
						&nbsp;
					</td>
				</tr>
			</tbody></table>		
		</td>
	</tr>
	
	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0">
				<tbody><tr>
					<th><h2 style="color: #000; font-size: 18.75pt; text-align: center;">BODY COMPOSITION</h2></th>
				</tr>
				<tr>
					<th style="font-weight: 600; text-align: center;"><p style="color: black; ">BMI : <span style="color: #0F3;">Underweight (&lt; 18.5)</span> | <span style="color: #060;">Normal (18.5 â€“ 24.9)</span> | <span style="color: #FF0;">Overweight (25 â€“ 29.9)</span> | <span style="color: #F00;">Obese (&gt; 30)</span></p></th>
				</tr>
				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="514">Comments</th>
						</tr>
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2016-02-07</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">12<br><img alt="" src="small-green.png" height="20" width="20">						</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">jkdshjkdf</td>
						</tr>						
					</tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0">
				<tbody><tr>
					<th><h2 style="color: #000; font-size: 18.75pt; text-align: center;">BLOOD PRESSURE</h2></th>
				</tr>
				<tr>
					<th style="font-weight: 600; text-align: center;"><span style="color: #0F3;">Normal</span> | <span style="color: #FF0;">Borderline (120-139) </span> | <span style="color: #F00;">Hypertension 1 (140-159)</span> | <span style="color: #F00;">Hypertension 2 (&gt;160)</span></th>
				</tr>
				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="514">Comments</th>
						</tr>
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2016-02-07</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">120/80<br><img alt="" src="small-green.png" height="20" width="20">			</th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">ksdflk</td>
						</tr>						
					</tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0">
				<tbody><tr>
					<th><h2 style="color: #000; font-size: 18.75pt; text-align: center;">TOTAL CHOLESTEROL</h2></th>
				</tr>
				<tr>
					<th style="font-weight: 600; text-align: center;"><span style="color: #0F3;">Desirable (&lt;200) </span> | <span style="color: #FF0;">Borderline (200 â€“ 239)</span> | <span style="color: #F00;">High (&gt;=240)</span></th>
				</tr>
				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="514">Comments</th>
						</tr>
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2016-02-07</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">120<br><img alt="" src="small-green.png" height="20" width="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">test</td>
						</tr>						
					</tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0">
				<tbody><tr>
					<th><h2 style="color: #000; font-size: 18.75pt; text-align: center;">HDL</h2></th>
				</tr>
				<tr>
					<th style="font-weight: 600; text-align: center;"><span style="color: #0F3;">Normal (&gt;=50) </span> | <span style="color: #F00;">Low (&lt; 50)</span></th>
				</tr>
				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="514">Comments</th>
						</tr>
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2016-02-07</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">33<br><img alt="" src="red-small.png" height="20" width="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">test</td>
						</tr>						
					</tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0">
				<tbody><tr>
					<th><h2 style="color: #000; font-size: 18.75pt; text-align: center;">LDL</h2></th>
				</tr>
				<tr>
					<th style="font-weight: 600; text-align: center;"><span style="color: #0F3;">Optimal (&lt;100) </span> | <span style="color: #060;">Near Optimal (100-129) </span> | <span style="color: #FF0;">Borderline (130 â€“ 159) </span> | <span style="color: #F00;">High (200 â€“ 499) </span> | <span style="color: #F00;">Very High (&gt;=500)</span></th>
				</tr>
				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="514">Comments</th>
						</tr>
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2016-02-07</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">30<br><img alt="" src="small-green.png" height="20" width="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">test</td>
						</tr>						
					</tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0">
				<tbody><tr>
					<th><h2 style="color: #000; font-size: 18.75pt; text-align: center;">TRIGLYCERIDES</h2></th>
				</tr>
				<tr>
					<th style="font-weight: 600; text-align: center;"><span style="color: #0F3;">Optimal (&lt;150) </span> | <span style="color: #060;">Borderline (150 â€“ 199) </span> | <span style="color: #FF0;">High (200 â€“ 499)</span> | <span style="color: #F00;">Very High (&gt;=500)</span></th>
				</tr>
				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="514">Comments</th>
						</tr>
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2016-02-07</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">45<br><img alt="" src="small-green.png" height="20" width="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">test</td>
						</tr>						
					</tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>
	
	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0">
				<tbody><tr>
					<th><h2 style="color: #000; font-size: 18.75pt; text-align: center;">DIABETES</h2></th>
				</tr>
				<tr>
					<th style="font-weight: 600; text-align: center;">HBa1c : <span style="color: #0F3;">Normal (&lt; 5.6) </span> | <span style="color: #FF0;">Prediabetes (5.7 â€“ 6.4)</span> | <span style="color: #F00;">Diabetes (&gt;= 6.5) </span></th>
				</tr>
				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="514">Comments</th>
						</tr>
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2016-02-07</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">29<br><img alt="" src="red-small.png" height="20" width="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">test</td>
						</tr>						
					</tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>
	<tr>
		<td>
			<table border="0" cellpadding="5" cellspacing="0">
				<tbody><tr>
					<th><h2 style="color: #000; font-size: 18.75pt; text-align: center;">KIDNEY DISEASE</h2></th>
				</tr>
				<tr>
					<th style="font-weight: 600; text-align: center;"><span style="color: #0F3;">Normal (60 to 120) </span> | <span style="color: #FF0;">16 to 59</span> |  <span style="color: #F00;">Danger (0 to 15) </span></th>
				</tr>
				<tr>
					<td>
					<table border="0" cellpadding="5" cellspacing="0">
						<tbody><tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Date</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">Score</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="514">Comments</th>
						</tr>
						<tr>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">2016-02-07</th>
							<th style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: center;" width="65">87<br><img alt="" src="small-green.png" height="20" width="20"></th>
							<td style="border: .75pt dotted #CCC; border-collapse: collapse; font-family: Raleway, sans-serif; font-size: 7.5pt; letter-spacing: .75pt;  text-align: left;" width="514">test</td>
						</tr>						
					</tbody></table>
					</td>
				</tr>
			</tbody></table>
		</td>
	</tr>
	
	<tr>
		<td height="20">&nbsp;</td>
	</tr>
	<tr>
		<td>
			<table border="0" cellpadding="0" cellspacing="0" width="700">
				<tbody>
					<tr>
						<td height="30" align="center" valign="middle"><h2 style="color:#000; font-size: 18.75pt; margin-bottom: 2pt;">For An appointment : (441)293-5476</h2></td>
					</tr>
					<tr>
						<td height="5" align="center" valign="top"><img src="partners-logos.jpg" alt="" height="97" width="439"></td>
					</tr>
				</tbody>
			</table>
		</td>
	</tr>
	
</tbody>';

// save $table inside temporary file that will be deleted later
$inputFileType = 'HTML';
$inputFileName = './myHtmlFile.html';
$outputFileType = 'Excel2007';
$outputFileName = './myExcelFile.xlsx';

$objPHPExcelReader = PHPExcel_IOFactory::createReader($inputFileType);
$objPHPExcel = $objPHPExcelReader->load($inputFileName);

$objPHPExcelWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,$outputFileType);
$objPHPExcel = $objPHPExcelWriter->save($outputFileName);
