<?php
include_once('functions.php');
$con = new dbconnection();
$con->setConnection();
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.kopyov.com/pannonia/ by HTTrack Website Copier/3.x [XR&CO'2010], Sat, 27 Jul 2013 15:36:51 GMT -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<title>NMAC Patient Tracker | Deleted Items</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>

<script type="text/javascript" src="js/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="js/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDY0kkJiTPVd2U7aTOAwhc9ySH6oHxOIYM&amp;sensor=false"></script>

<script type="text/javascript" src="js/plugins/charts/excanvas.min.js"></script>
<script type="text/javascript" src="js/plugins/charts/jquery.flot.js"></script>
<script type="text/javascript" src="js/plugins/charts/jquery.flot.resize.js"></script>
<script type="text/javascript" src="js/plugins/charts/jquery.sparkline.min.js"></script>

<script type="text/javascript" src="js/plugins/ui/jquery.easytabs.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.collapsible.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/prettify.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.colorpicker.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.timepicker.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.fullcalendar.min.js"></script>

<script type="text/javascript" src="js/plugins/forms/jquery.uniform.min.js"></script>
<script type="text/javascript" src="js/plugins/forms/jquery.tagsinput.min.js"></script>

<script type="text/javascript" src="js/plugins/tables/jquery.dataTables.min.js"></script>

<script type="text/javascript" src="js/files/bootstrap.min.js"></script>

<script type="text/javascript" src="js/functions/index.js"></script>
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
</head>

<body>

	<!-- Fixed top -->
	<div id="top">
		<div class="fixed">
			<a href="dashboard.html" title="" class="logo"><img src="img/logo.png" alt="" /></a>
			<ul class="top-menu">
				<li><a class="fullview"></a></li>
				<li class="dropdown">
					<a class="user-menu" data-toggle="dropdown"><img src="img/userpic.png" alt="" /><span>Howdy, Eugene! <b class="caret"></b></span></a>
					<ul class="dropdown-menu">
						<li><a href="#" title="" data-toggle="modal" data-target="#ProfileView"><i class="icon-user"></i>Profile</a></li>
						<li><a href="#" title=""><i class="icon-remove"></i>Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
	<!-- /fixed top -->


	<!-- Content container -->
	<div id="container">

		<!-- Sidebar -->
		<div id="sidebar">

			<div class="sidebar-tabs">
		        <ul class="tabs-nav two-items">
		            <li><a href="#general" title=""><i class="icon-reorder"></i></a></li>
		            <li><a href="#stuff" title=""><i class="icon-cogs"></i></a></li>
		        </ul>

		        <div id="general">

			        <!-- Sidebar user -->
			        <div class="sidebar-user widget">
						<div class="navbar"><div class="navbar-inner"><h6>Wazzup, Eugene!</h6></div></div>
			            <a href="#" title="" class="user"><img src="img/demo/sidebar_user_big.png" alt="" /></a>
			        </div>
			        <!-- /sidebar user -->


				    <!-- Main navigation -->
			        <?php 
						get_menu();
					?>
			        <!-- /main navigation -->

		        </div>

		        <div id="stuff">

			        <!-- Social stats -->
			        <div class="widget">
			        	<h6 class="widget-name"><i class="icon-user"></i>Urgent Call</h6>
			        	<ul class="social-stats">
			        		<?php urgent_call(); ?>				        	
			        	</ul>
			        </div>
			        <!-- /social stats -->
                   

		        </div>

		    </div>
		</div>
		<!-- /sidebar -->


		<!-- Content -->
		<div id="content">

		    <!-- Content wrapper -->
		    <div class="wrapper">

			    <!-- Breadcrumbs line -->
			    <div class="crumbs">
		            <ul id="breadcrumbs" class="breadcrumb"> 
		                <li><a href="dashboard.html">Dashboard</a></li>
                        <li ><a title="" href="#">Messages</a></li>
                        <li class="active"><a title="" href="#">Deleted Items</a></li>
		            </ul>
			        
		            
			    </div>
			    <!-- /breadcrumbs line -->

			    <!-- Page header -->
			    <div class="page-header">
			    	<div class="page-title">
				    	<h5>Deleted Items</h5>
				    	<span>Welcome, Eugene!</span>
			    	</div>

			    	
			    </div>
			    <!-- /page header -->
 



                <!-- Options bar -->
		    	
		    	<!-- /options bar -->

                <!-- Media datatable -->
                <div class="widget">
                	
                    <div class="table-overflow">
                        <table class="table table-striped table-bordered table-checks media-table">
                            <thead>
                                <tr>
                                <th  width="98">Date</th>
                                    <th width="104">To</th>
                                    <th width="237">Subject</th>
                                    <th width="70">Attachment</th>
                                    
                                    <th width="218" class="actions-column">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                <td>15-Nov-2015</td>
			                        <td><a href="#" title="" class="lightbox">After Sumit</a></td>
			                        <td><a href="#" title=""><b>Amazing offers Waiting Inside,rehan.ahamad@gmail.com</b> - Open In New Tab To wipeout from our mails, click here</a></td>
                                    <td><i class="fa fa-paperclip" aria-hidden="true"></i>
</td>
                                    
			                        
			                        <td>
		                                <ul class="navbar-icons">
		                                    <li><a href="patient_information.html" class="tip" title="Get Information"><i class="icon-info-sign"></i></a></li>
                                            
                                            <li><a href="#" class="tip" title="Delete"><i class="fam-cross"></i></a></li>
		                                </ul>
			                        </td>
                                </tr>
                                <tr>
                                <td>15-Nov-2015</td>
			                        <td><a href="#" title="" class="lightbox">After Sumit</a></td>
			                        <td><a href="#" title=""><b>Amazing offers Waiting Inside,rehan.ahamad@gmail.com</b> - Open In New Tab To wipeout from our mails, click here</a></td>
                                    <td><i class="fa fa-paperclip" aria-hidden="true"></i>
</td>
                                    
			                        
			                        <td>
		                                <ul class="navbar-icons">
		                                    <li><a href="patient_information.html" class="tip" title="Get Information"><i class="icon-info-sign"></i></a></li>
                                            
                                            <li><a href="#" class="tip" title="Delete"><i class="fam-cross"></i></a></li>
		                                </ul>
			                        </td>
                                </tr>
                                <tr>
                                <td>15-Nov-2015</td>
			                        <td><a href="#" title="" class="lightbox">After Sumit</a></td>
			                        <td><a href="#" title=""><b>Amazing offers Waiting Inside,rehan.ahamad@gmail.com</b> - Open In New Tab To wipeout from our mails, click here</a></td>
                                    <td><i class="fa fa-paperclip" aria-hidden="true"></i>
</td>
                                    
			                        
			                     <td>
		                                <ul class="navbar-icons">
		                                    <li><a href="patient_information.html" class="tip" title="Get Information"><i class="icon-info-sign"></i></a></li>
                                            
                                            <li><a href="#" class="tip" title="Delete"><i class="fam-cross"></i></a></li>
		                                </ul>
			                        </td>
                                </tr>
                                <tr>
                                <td>15-Nov-2015</td>
			                        <td><a href="#" title="" class="lightbox">After Sumit</a></td>
			                        <td><a href="#" title=""><b>Amazing offers Waiting Inside,rehan.ahamad@gmail.com</b> - Open In New Tab To wipeout from our mails, click here</a></td>
                                    <td><i class="fa fa-paperclip" aria-hidden="true"></i>
</td>
                                    
			                        
			                       <td>
		                                <ul class="navbar-icons">
		                                    <li><a href="patient_information.html" class="tip" title="Get Information"><i class="icon-info-sign"></i></a></li>
                                            
                                            <li><a href="#" class="tip" title="Delete"><i class="fam-cross"></i></a></li>
		                                </ul>
			                        </td>
                                </tr>
                                <tr>
                                <td>15-Nov-2015</td>
			                        <td><a href="#" title="" class="lightbox">After Sumit</a></td>
			                        <td><a href="#" title=""><b>Amazing offers Waiting Inside,rehan.ahamad@gmail.com</b> - Open In New Tab To wipeout from our mails, click here</a></td>
                                    <td><i class="fa fa-paperclip" aria-hidden="true"></i>
</td>
                                    
			                        
			                       <td>
		                                <ul class="navbar-icons">
		                                    <li><a href="patient_information.html" class="tip" title="Get Information"><i class="icon-info-sign"></i></a></li>
                                            
                                            <li><a href="#" class="tip" title="Delete"><i class="fam-cross"></i></a></li>
		                                </ul>
			                        </td>
                                </tr>
                                <tr>
                                <td>15-Nov-2015</td>
			                        <td><a href="#" title="" class="lightbox">After Sumit</a></td>
			                        <td><a href="#" title=""><b>Amazing offers Waiting Inside,rehan.ahamad@gmail.com</b> - Open In New Tab To wipeout from our mails, click here</a></td>
                                    <td><i class="fa fa-paperclip" aria-hidden="true"></i>
</td>
                                    
			                        
			                      <td>
		                                <ul class="navbar-icons">
		                                    <li><a href="patient_information.html" class="tip" title="Get Information"><i class="icon-info-sign"></i></a></li>
                                            
                                            <li><a href="#" class="tip" title="Delete"><i class="fam-cross"></i></a></li>
		                                </ul>
			                        </td>
                                </tr>
                                <tr>
                                <td>15-Nov-2015</td>
			                        <td><a href="#" title="" class="lightbox">After Sumit</a></td>
			                        <td><a href="#" title=""><b>Amazing offers Waiting Inside,rehan.ahamad@gmail.com</b> - Open In New Tab To wipeout from our mails, click here</a></td>
                                    <td><i class="fa fa-paperclip" aria-hidden="true"></i>
</td>
                                    
			                        
			                      <td>
		                                <ul class="navbar-icons">
		                                    <li><a href="patient_information.html" class="tip" title="Get Information"><i class="icon-info-sign"></i></a></li>
                                            
                                            <li><a href="#" class="tip" title="Delete"><i class="fam-cross"></i></a></li>
		                                </ul>
			                        </td>
                                </tr>
                                <tr>
                                <td>15-Nov-2015</td>
			                        <td><a href="#" title="" class="lightbox">After Sumit</a></td>
			                        <td><a href="#" title=""><b>Amazing offers Waiting Inside,rehan.ahamad@gmail.com</b> - Open In New Tab To wipeout from our mails, click here</a></td>
                                    <td><i class="fa fa-paperclip" aria-hidden="true"></i>
</td>
                                    
			                        
			                       <td>
		                                <ul class="navbar-icons">
		                                    <li><a href="patient_information.html" class="tip" title="Get Information"><i class="icon-info-sign"></i></a></li>
                                            
                                            <li><a href="#" class="tip" title="Delete"><i class="fam-cross"></i></a></li>
		                                </ul>
			                        </td>
                                </tr>
                                <tr>
                                <td>15-Nov-2015</td>
			                        <td><a href="#" title="" class="lightbox">After Sumit</a></td>
			                        <td><a href="#" title=""><b>Amazing offers Waiting Inside,rehan.ahamad@gmail.com</b> - Open In New Tab To wipeout from our mails, click here</a></td>
                                    <td><i class="fa fa-paperclip" aria-hidden="true"></i>
</td>
                                    
			                        
			                       <td>
		                                <ul class="navbar-icons">
		                                    <li><a href="patient_information.html" class="tip" title="Get Information"><i class="icon-info-sign"></i></a></li>
                                            
                                            <li><a href="#" class="tip" title="Delete"><i class="fam-cross"></i></a></li>
		                                </ul>
			                        </td>
                                </tr>
                                <tr>
                                <td>15-Nov-2015</td>
			                        <td><a href="#" title="" class="lightbox">After Sumit</a></td>
			                        <td><a href="#" title=""><b>Amazing offers Waiting Inside,rehan.ahamad@gmail.com</b> - Open In New Tab To wipeout from our mails, click here</a></td>
                                    <td><i class="fa fa-paperclip" aria-hidden="true"></i>
</td>
                                    
			                        
			                      <td>
		                                <ul class="navbar-icons">
		                                    <li><a href="patient_information.html" class="tip" title="Get Information"><i class="icon-info-sign"></i></a></li>
                                            
                                            <li><a href="#" class="tip" title="Delete"><i class="fam-cross"></i></a></li>
		                                </ul>
			                        </td>
                                </tr>
                                <tr>
                                <td>15-Nov-2015</td>
			                        <td><a href="#" title="" class="lightbox">After Sumit</a></td>
			                        <td><a href="#" title=""><b>Amazing offers Waiting Inside,rehan.ahamad@gmail.com</b> - Open In New Tab To wipeout from our mails, click here</a></td>
                                    <td><i class="fa fa-paperclip" aria-hidden="true"></i>
</td>
                                    
			                        
			                     <td>
		                                <ul class="navbar-icons">
		                                    <li><a href="patient_information.html" class="tip" title="Get Information"><i class="icon-info-sign"></i></a></li>
                                            
                                            <li><a href="#" class="tip" title="Delete"><i class="fam-cross"></i></a></li>
		                                </ul>
			                        </td>
                                </tr>
                                <tr>
                                <td>15-Nov-2015</td>
			                        <td><a href="#" title="" class="lightbox">After Sumit</a></td>
			                        <td><a href="#" title=""><b>Amazing offers Waiting Inside,rehan.ahamad@gmail.com</b> - Open In New Tab To wipeout from our mails, click here</a></td>
                                    <td><i class="fa fa-paperclip" aria-hidden="true"></i>
</td>
                                    
			                        
			                      <td>
		                                <ul class="navbar-icons">
		                                    <li><a href="patient_information.html" class="tip" title="Get Information"><i class="icon-info-sign"></i></a></li>
                                            
                                            <li><a href="#" class="tip" title="Delete"><i class="fam-cross"></i></a></li>
		                                </ul>
			                        </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- /media datatable -->


		    </div>
		    <!-- /content wrapper -->

		</div>
		<!-- /content -->

	</div>
	<!-- /content container -->

<!--ProfileView patient Modal -->
<div id="ProfileView" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content nmac_tracker">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title widget-name"><i class="icon-edit"></i>Profile</h4>
      </div>
      <div class="modal-body">
<form class="form-horizontal search widget" action="#">
    <div class="control-group">
                                        <label class="control-label">Date of Creation</label>
                                        <div class="controls"><input type="text" name="regular" class="span12" placeholder="20/10/2015" /></div>
                                    </div>
     <div class="control-group">
						            <label class="control-label">Name</label>
						            <div class="controls"><input type="text" name="regular" class="span12" placeholder="Eugene" /></div>
						        </div>  
    
    
    <div class="control-group">
						            <label class="control-label">Age</label>
						            <div class="controls"><input type="text" value="" name="" class="span12" placeholder="38" /></div>
						        </div>  
    <div class="control-group">
						            <label class="control-label">Location</label>
						            <div class="controls"><input type="text" value="" name="" class="span12" placeholder="New York" /></div>
						        </div>                                                        
    <div class="control-group">
						            <label class="control-label">Phone no</label>
						            <div class="controls"><input type="text" value="" name="" class="span12" placeholder="9999887585" /></div>
						        </div>
     <div class="control-group">
						            <label class="control-label">Email Id</label>
						            <div class="controls"><input type="email" value="" name="" class="span12" placeholder="eudgene5@yahoo.com" /></div>
						        </div>                           
                                                          
    <div class="control-group">
	                                <label class="control-label">Specialization:</label>
	                                <div class="controls">
	                                    <textarea rows="5" cols="5" name="textarea" class="span12"> Medicine, Main Specialist</textarea>
	                                </div>
	                            </div>
    </form>


      </div>
    </div>

  </div>
</div>
 <!-- End Modal -->
 
<!--Add patient Modal -->
<div id="AddPatient" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content nmac_tracker">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title widget-name"><i class="icon-edit"></i>Add Patient</h4>
      </div>
      <div class="modal-body">
<form class="search widget" action="#">
	<div class="control-group">
						            <label class="control-label"><b>Name</b></label>
						            <div class="controls"><input type="text" value="" name="" class="span12" /></div>
						        </div>  
    <div class="row-fluid">
                                        <div class="span4"><div class="control-group">
						            <label class="control-label"><b>Age</b></label>
						            <div class="controls"><input type="text" value="" name="" class="span12" /></div>
						        </div></div>
                                        <div class="span8"><div class="control-group">
						            <label class="control-label"><b>Date Of Birth</b></label>
						            <div class="row-fluid">
                                     <div class="span4">
                                     <div class="control-group">
                                    <input type="text" value="" name="" class="span12" placeholder="DD" />
                                    </div>
                                    </div>
                                    <div class="span4">
                                     <div class="control-group">
                                    <input type="text" value="" name="" class="span12" placeholder="MM" />
                                    </div>
                                    </div>
                                    <div class="span4">
                                     <div class="control-group">
                                    <input type="text" value="" name="" class="span12" placeholder="YYYY" />
                                    </div>
                                    </div>
                                    </div>
						        </div></div>
                                        </div>                            
    <div class="control-group">
						            <label class="control-label"><b>Address</b></label>
						            <div class="controls"><input type="text" value="" name="" class="span12" /></div>
						        </div>                                                        
    <div class="control-group">
						            <label class="control-label"><b>Phone no</b></label>
						            <div class="controls"><input type="text" value="" name="" class="span12" /></div>
						        </div>
    <div class="control-group">
						            <label class="control-label"><b>Email Id</b></label>
						            <div class="controls"><input type="email" value="" name="" class="span12" /></div>
						        </div>
     <div class="control-group">
	                                        <label class="control-label"><b>Photo uploader:</b></label>
	                                        <div class="controls">
	                                            <input type="file" class="styled">
	                                        </div>
	                                    </div>                                                      
    <div class="control-group">
	                                <label class="control-label"><b>Medical History:</b></label>
	                                <div class="controls">
	                                    <textarea rows="5" cols="5" name="textarea" class="validate[required] span12"></textarea>
	                                </div>
	                            </div>
    <div class="control-group">
	                                        <label class="control-label"><b>Program</b></label>
	                                        <div class="controls">
	                                            <select name="select2" class="styled" >
	                                                <option value="opt1">All</option>
	                                                <option value="opt2">Diabetic</option>
	                                                <option value="opt3">Theraphetic Life Style Program</option>
	                                                <option value="opt4">HCG Weight Loss Program</option>
	                                                <option value="opt5">Government Eahanced</option>
	                                            </select>
	                                        </div>
	                                    </div>
    <div class="control-group">
                                        <label class="control-label"><b>Date &amp; Time</b></label>
                                        <div class="controls"><input type="text" name="regular" class="span12" /></div>
                                    </div>
    <div class="control-group">
						            <label class="control-label"><b>Reported By</b></label>
						            <div class="controls"><input type="text" name="regular" class="span12" /></div>
						        </div>  
    <div class="control-group action_list">
						            <label class="control-label"><b>Action:</b></label>
						            <div class="row-fluid">
                                     <div class="span4">
                                     <div class="control-group">
                                    <input type="text" placeholder="HBa1C" class="span12" name="" value="">
                                    </div>
                                    </div>
                                    <div class="span4">
                                     <div class="control-group">
                                    <input type="text" placeholder="Systolic BP" class="span12" name="" value="">
                                    </div>
                                    </div>
                                    <div class="span4">
                                     <div class="control-group">
                                    <input type="text" placeholder="Diastolic BP " class="span12" name="" value="">
                                    </div>
                                    </div>
                                    <div class="span4">
                                     <div class="control-group">
                                    <input type="text" placeholder="Glucose" class="span12" name="" value="">
                                    </div>
                                    </div>
                                    <div class="span4">
                                     <div class="control-group">
                                    <input type="text" placeholder="LDL" class="span12" name="" value="">
                                    </div>
                                    </div>
                                    <div class="span4">
                                     <div class="control-group">
                                    <input type="text" placeholder="Body Fat" class="span12" name="" value="">
                                    </div>
                                    </div>
                                    <div class="span4">
                                     <div class="control-group">
                                    <input type="text" placeholder="BMI" class="span12" name="" value="">
                                    </div>
                                    </div>
                                    <div class="span4">
                                     <div class="control-group">
                                    <input type="text" placeholder="PHQ" class="span12" name="" value="">
                                    </div>
                                    </div>
                                    <div class="span4">
                                     <div class="control-group">
                                    <input type="text" placeholder="Gas Score" class="span12" name="" value="">
                                    </div>
                                    </div>
                                    </div>
						        </div>
    <div class="control-group">
						            <label class="control-label"><b>Smoking Cessation:</b></label>
						            <div class="controls">
												<label class="checkbox inline">
													<input checked data-toggle="toggle" type="checkbox">Yes
												</label>
												<label class="checkbox inline">
													<input type="checkbox" value="option2">No
												</label>
												<label class="checkbox inline">
													<input type="text" value="" placeholder="From">
												</label>
                                                <label class="checkbox inline">
													<input type="text" value="" placeholder="To">
												</label>
	                                        </div>
						        </div> 
    <div class="control-group lable_list">
						            <label class="control-label"><b>ER Visit:</b></label>
						            <div class="controls">
												<label class="checkbox inline">
													<input checked data-toggle="toggle" type="checkbox">Yes
												</label>
												<label class="checkbox inline">
													<input type="checkbox" value="option2">No
												</label>
	                                        </div>
						        </div>
    <div class="control-group group_clear">
						            <label class="control-label"><b>Asthma/ COPD  Action Plan:</b></label>
						            <div class="controls">
												<label class="checkbox inline chk_full marg_lt0">
                                                <textarea placeholder="" rows="5"></textarea>
												</label>
	                                        </div>
						        </div>                           
    <div class="form-actions">
	                                        <button type="submit" class="btn btn-primary">Submit</button>
	                                        <button type="button close" class="btn btn-danger">Cancel</button>
	                                    </div>
    </form>


      </div>
    </div>

  </div>
</div>
 <!-- /Add patient Modal -->

	<!-- Footer -->
	<div id="footer">
		<div class="copyrights">&copy; <a class="" target="_blank" href="http://www.designdot.co.in">Designdot Technologies Pvt. Ltd.</a> All rights reserved.</div>
		<ul class="footer-links">
			<li><a href="#" title=""><i class="icon-cogs"></i>Contact admin</a></li>
			<li><a href="#" title=""><i class="icon-screenshot"></i>Report bug</a></li>
		</ul>
	</div>
	<!-- /footer -->

</body>

<!-- Mirrored from demo.kopyov.com/pannonia/ by HTTrack Website Copier/3.x [XR&CO'2010], Sat, 27 Jul 2013 15:39:34 GMT -->
</html>
