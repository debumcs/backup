<?php
include_once('functions.php');
$con = new dbconnection();
$con->setConnection();

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<title>NMAC Health Report Card</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>

<script type="text/javascript" src="js/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="js/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDY0kkJiTPVd2U7aTOAwhc9ySH6oHxOIYM&amp;sensor=false"></script>

<script type="text/javascript" src="js/plugins/charts/excanvas.min.js"></script>
<script type="text/javascript" src="js/plugins/charts/jquery.flot.js"></script>
<script type="text/javascript" src="js/plugins/charts/jquery.flot.resize.js"></script>
<script type="text/javascript" src="js/plugins/charts/jquery.sparkline.min.js"></script>

<script type="text/javascript" src="js/plugins/ui/jquery.easytabs.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.collapsible.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/prettify.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.colorpicker.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.timepicker.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.fullcalendar.min.js"></script>

<script type="text/javascript" src="js/plugins/forms/jquery.uniform.min.js"></script>
<script type="text/javascript" src="js/plugins/forms/jquery.tagsinput.min.js"></script>

<script type="text/javascript" src="js/plugins/tables/jquery.dataTables.min.js"></script>

<script type="text/javascript" src="js/files/bootstrap.min.js"></script>
<script type="text/javascript" src="js/functions/index.js"></script>

	    
<!-- page specific scripts -->
<script type="text/javascript" charset="utf-8">
 
	$(function (){
		// smoking_cessationfrom
		$('#dob').change(function (){
			var pickdob = $("#dob").val();
			dob = new Date(pickdob);
			var today = new Date();
			var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
			document.getElementById("age").value = age;
			
		});
		
		$('#datetype2').click(function (){
			$('#year').attr("disabled", false); 		
			$('#month').attr("disabled", false);
		});
		
		$('#datetype3').click(function (){
			$('#year').attr("disabled", true); 		
			$('#month').attr("disabled", true);
		});

	});
	
	function validation(){
		
		if(document.getElementById("datetype2").checked == false && document.getElementById("datetype3").checked == false){
			alert('Please select report type!');
			return false;
		}else if(document.getElementById("datetype2").checked == true && document.getElementById("year").value == ''){
			alert('Please select year!');
			document.getElementById("year").focus();
			return false;
		}else if(document.getElementById("datetype2").checked == true && document.getElementById("month").value == ''){
			alert('Please select month!');
			document.getElementById("month").focus();
			return false;
		}
	}
	
	function isDate(txtDate)
	{
		var currVal = txtDate;
		if(currVal == '')
			return false;
		
		var rxDatePattern = /^(\d{4})(\-|-)(\d{1,2})(\-|-)(\d{1,2})$/; //Declare Regex
		var dtArray = currVal.match(rxDatePattern); // is format OK?
		
		if (dtArray == null) 
			return false;
		
		//Checks for mm/dd/yyyy format.
		dtDay = dtArray[5];
		dtYear= dtArray[1];
		dtMonth = dtArray[3];
		//var dated = dtYear+"-"+dtMonth+"-"+dtDay;
		//alert(dated);
		
		
		if (dtMonth < 1 || dtMonth > 12) 
			return false;
		else if (dtDay < 1 || dtDay> 31) 
			return false;
		else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31) 
			return false;
		else if (dtMonth == 2) 
		{
			var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
			if (dtDay> 29 || (dtDay ==29 && !isleap)) 
					return false;
		}
		return true;
	}
		
</script>


</head>

<body>

	<!-- Fixed top -->
	<div id="top">
		<div class="fixed">
			<a href="dashboard.php" title="" class="logo"><img src="img/logo.png" alt="" /></a>
			<ul class="top-menu">
				<li><a class="fullview"></a></li>
				<li class="dropdown">
					<a class="user-menu" data-toggle="dropdown"><img src="img/userpic.png" alt="" /><span>Howdy, Admin! <b class="caret"></b></span></a>
					<ul class="dropdown-menu">
						<li><a href="#" title="" data-toggle="modal" data-target="#ProfileView"><i class="icon-user"></i>Profile</a></li>
						<li><a href="logout.php" title=""><i class="icon-remove"></i>Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
	<!-- /fixed top -->


	<!-- Content container -->
	<div id="container">

		<!-- Sidebar -->
		<div id="sidebar">

			<div class="sidebar-tabs">
		        <ul class="tabs-nav two-items">
		            <li><a href="#general" title=""><i class="icon-reorder"></i></a></li>
		            <li><a href="#stuff" title=""><i class="icon-cogs"></i></a></li>
		        </ul>

		        <div id="general">

			        <!-- Sidebar user -->
			        <div class="sidebar-user widget">
						<div class="navbar"><div class="navbar-inner"><h6>Wazzup, Admin!</h6></div></div>
			            <a href="#" title="" class="user"><img src="img/demo/sidebar_user_big.png" alt="" /></a>
			        </div>
			        <!-- /sidebar user -->


				    <!-- Main navigation -->
			        <?php 
						get_menu();
					?>
			        <!-- /main navigation -->

		        </div>

		        <div id="stuff">

			        <!-- Social stats -->
			        <div class="widget">
			        	<h6 class="widget-name"><i class="icon-user"></i>Urgent Call</h6>
			        	<ul class="social-stats">
			        		<?php urgent_call(); ?>			        	
			        	</ul>
			        </div>
			        <!-- /social stats -->
                   

		        </div>

		    </div>
		</div>
		<!-- /sidebar -->


		<!-- Content -->
		<div id="content">

		    <!-- Content wrapper -->
		    <div class="wrapper">

			    <!-- Breadcrumbs line -->
			    <div class="crumbs">
		            <ul id="breadcrumbs" class="breadcrumb"> 
		                <li><a href="dashboard.php">Dashboard</a></li>
                        <li class="active"><a title="" href="#">Excel Report</a></li>
		            </ul>
			        
			    </div>
			    <!-- /breadcrumbs line -->

			    <!-- Page header -->
			    <div class="page-header">
			    	<div class="page-title">
				    	<h5>Excel Report</h5>
				    	<span>Welcome, Admin!</span>
			    	</div>

			    	<ul class="page-stats">
			    		<!--<li>
			    			<div class="showcase">
			    				<span>New Patient</span>
			    				<h2><?php echo get_newtotal(); ?></h2>
			    			</div>
			    			<div id="total-visits" class="chart"><?php echo get_newbars(); ?></div>
			    		</li>-->
			    		<li>
			    			<div class="showcase">
			    				<span>Total Patient</span>
			    				<h2><?php echo get_total(); ?></h2>
			    			</div>
			    			<div id="balance" class="chart"><?php echo get_bars(); ?></div>
			    		</li>
			    	</ul>
			    </div>
			    <!-- /page header -->


		    	<h5 class="widget-name"><i class="icon-th"></i>Excel Report</h5>
               

                <!-- add patient form -->
                <div id="add_patient_form">
                <form class="search widget" action="fetch_all_data.php" method="post" enctype="multipart/form-data">
	
    <div class="control-group action_list htl_card">
		<div class="row-fluid">
			
			<div class="span4">
				<label class="control-label"><input name="datetype" id="datetype2" type="radio" value="2"> <b>By Month</b></label>
				<div class="controls">
					<label class="checkbox inline" >
						<select name="year" id="year">
							<option selected value="">Select Year</option>
							<option value="2015">2015</option>
							<option value="2016">2016</option>
							<option value="2017">2017</option>
							<option value="2018">2018</option>
							<option value="2019">2019</option>
						</select>
					</label><br>
					<label class="checkbox inline" >
						<select name="month" id="month">
							<option selected value="">Select Month</option>
							<option value="1">January</option>
							<option value="2">February</option>
							<option value="3">March</option>
							<option value="4">April</option>
							<option value="5">May</option>
							<option value="6">June</option>
							<option value="7">July</option>
							<option value="8">August</option>
							<option value="9">September</option>
							<option value="10">October</option>
							<option value="11">November</option>
							<option value="12">December</option>
						</select>
					</label>
				</div>
			</div> 
			
			<div class="span4">
				<label class="control-label"><input name="datetype" id="datetype3" type="radio" value="3"> <b>Last 6 Month</b></label>
			</div> 
			
		</div>		
		
	</div>
                                                            
		<div class="form-actions">
			<input type="submit" name="submit" id="submit" class="btn btn-primary" onclick="return validation();" value="Submit" />
		</div>
    </form>
    </div>
                <!-- /add patient form -->


		    </div>
		    <!-- /content wrapper -->

		</div>
		<!-- /content -->

	</div>
	<!-- /content container -->

	<!-- Footer -->
	<div id="footer">
		<div class="copyrights">&copy; <a class="" target="_blank" href="http://www.designdot.co.in">Designdot Technologies Pvt. Ltd.</a> All rights reserved.</div>
		<ul class="footer-links">
			<li><a href="#" title=""><i class="icon-cogs"></i>Contact admin</a></li>
			<li><a href="#" title=""><i class="icon-screenshot"></i>Report bug</a></li>
		</ul>
	</div>
	<!-- /footer -->

</body>
</html>
