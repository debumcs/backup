<?php

include_once('functions.php');
$con = new dbconnection();
$con->setConnection();

	$sql = "SELECT a.id,a.program, a.date_time, a.photo, a.name,a.age, a.address, b.body_fat, g.gasscore, m.metabolic_age, p.phq, o.smoking_cessation FROM patient a 
LEFT JOIN (SELECT * FROM body_fat bod1 WHERE DATETIME IN (SELECT MAX(DATETIME) FROM body_fat bod2 WHERE bod1.patient_id = bod2.patient_id GROUP BY bod2.patient_id)) b ON a.id = b.patient_id
LEFT JOIN (SELECT * FROM gasscore gas1 WHERE DATETIME IN (SELECT MAX(DATETIME) FROM gasscore gas2 WHERE gas1.patient_id = gas2.patient_id GROUP BY gas2.patient_id)) g ON a.id = g.patient_id
LEFT JOIN (SELECT * FROM metabolic_age ma1 WHERE DATETIME IN (SELECT MAX(DATETIME) FROM metabolic_age ma2 WHERE ma1.patient_id = ma2.patient_id GROUP BY ma2.patient_id)) m ON a.id = m.patient_id
LEFT JOIN (SELECT * FROM phq phq1 WHERE DATETIME IN (SELECT MAX(DATETIME) FROM phq phq2 WHERE phq1.patient_id = phq2.patient_id GROUP BY phq2.patient_id)) p ON a.id = p.patient_id
LEFT JOIN (SELECT * FROM others oth1 WHERE DATETIME IN (SELECT MAX(DATETIME) FROM others oth2 WHERE oth1.patient_id = oth2.patient_id GROUP BY oth2.patient_id)) o ON a.id = o.patient_id";

	if(isset($_POST['program']) and $_POST['program'] != 'All'){
		$sql .= " where a.status = '1' and program = '".$_POST['program']."' order by a.date_time desc";
		$program = $_POST['program'];
	}else{
		$sql .= " where a.status = '1' order by a.date_time desc";
		$program = '';
	}

	$result = $con->runQuery($sql);
?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />

<title>NMAC Health Report Card</title>

<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />

<!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->

<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>



<script type="text/javascript" src="js/ajax/libs/jquery/1.7.2/jquery.min.js"></script>

<script type="text/javascript" src="js/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script>

<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDY0kkJiTPVd2U7aTOAwhc9ySH6oHxOIYM&amp;sensor=false"></script>



<script type="text/javascript" src="js/plugins/charts/excanvas.min.js"></script>

<script type="text/javascript" src="js/plugins/charts/jquery.flot.js"></script>

<script type="text/javascript" src="js/plugins/charts/jquery.flot.resize.js"></script>

<script type="text/javascript" src="js/plugins/charts/jquery.sparkline.min.js"></script>



<script type="text/javascript" src="js/plugins/ui/jquery.easytabs.min.js"></script>

<script type="text/javascript" src="js/plugins/ui/jquery.collapsible.min.js"></script>

<script type="text/javascript" src="js/plugins/ui/prettify.js"></script>

<script type="text/javascript" src="js/plugins/ui/jquery.colorpicker.js"></script>

<script type="text/javascript" src="js/plugins/ui/jquery.timepicker.min.js"></script>

<script type="text/javascript" src="js/plugins/ui/jquery.fancybox.js"></script>

<script type="text/javascript" src="js/plugins/ui/jquery.fullcalendar.min.js"></script>



<script type="text/javascript" src="js/plugins/forms/jquery.uniform.min.js"></script>

<script type="text/javascript" src="js/plugins/forms/jquery.tagsinput.min.js"></script>



<script type="text/javascript" src="js/plugins/tables/jquery.dataTables.min.js"></script>



<script type="text/javascript" src="js/files/bootstrap.min.js"></script>



<script type="text/javascript" src="js/functions/index.js"></script>



<script type="text/javascript">

$(document).ready(function() {
  $('#program').on('change', function() {
     document.forms["allprogram"].submit();
  });
});

</script>

</head>



<body>



	<!-- Fixed top -->

	<div id="top">

		<div class="fixed">

			<a href="dashboard.php" title="" class="logo"><img src="img/logo.png" alt="" /></a>

			<ul class="top-menu">

				<li><a class="fullview"></a></li>

				<li><a class="showmenu"></a></li>

				<!--<li><a href="#" title="" class="messages"><i class="new-message"></i></a></li>-->

				<li class="dropdown">

					<a class="user-menu" data-toggle="dropdown"><img src="img/userpic.png" alt="" /><span>Howdy, Admin! <b class="caret"></b></span></a>

					<ul class="dropdown-menu">

						<li><a href="#" title="" data-toggle="modal" data-target="#ProfileView"><i class="icon-user"></i>Profile</a></li>

						<li><a href="logout.php" title=""><i class="icon-remove"></i>Logout</a></li>

					</ul>

				</li>

			</ul>

		</div>

	</div>

	<!-- /fixed top -->





	<!-- Content container -->

	<div id="container">



		<!-- Sidebar -->

		<div id="sidebar">



			<div class="sidebar-tabs">

		        <ul class="tabs-nav two-items">

		            <li><a href="#general" title=""><i class="icon-reorder"></i></a></li>

		            <li><a href="#stuff" title=""><i class="icon-cogs"></i></a></li>

		        </ul>



		        <div id="general">



			        <!-- Sidebar user -->

			        <div class="sidebar-user widget">

						<div class="navbar"><div class="navbar-inner"><h6>Wazzup, Admin!</h6></div></div>

			            

			        </div>

			        <!-- /sidebar user -->





				    <!-- Main navigation -->

			        <?php 

						get_menu();

					?>

			        <!-- /main navigation -->



		        </div>



		        <div id="stuff">



			        <!-- Social stats -->

			        <div class="widget">

			        	<h6 class="widget-name"><i class="icon-user"></i>Urgent Call</h6>

			        	<ul class="social-stats">

			        		<?php urgent_call(); ?>			        	

			        	</ul>

			        </div>

			        <!-- /social stats -->

                   



		        </div>



		    </div>

		</div>

		<!-- /sidebar -->





		<!-- Content -->

		<div id="content">



		    <!-- Content wrapper -->

		    <div class="wrapper">



			    <!-- Breadcrumbs line -->

			    <div class="crumbs">

		            <ul id="breadcrumbs" class="breadcrumb"> 

		                <li><a href="dashboard.php">Dashboard</a></li>
						<li class="active"><a title="" href="#">Tracking Patient&nbsp;&nbsp;&nbsp;>&nbsp;&nbsp;&nbsp;View Patient</a></li>

		            </ul>

			        

			    </div>

			    <!-- /breadcrumbs line -->



			    <!-- Page header -->

			    <div class="page-header">

			    	<div class="page-title">

				    	<h5><strong>Tracking Patient</strong>&nbsp;&nbsp;&nbsp;>&nbsp;&nbsp;&nbsp;View Patient</h5>

				    	<span>Welcome, Admin!</span>

			    	</div>



			    	<ul class="page-stats">

			    		<!--<li>

			    			<div class="showcase">

			    				<span>New Patient</span>

			    				<h2><?php echo get_newtotal(); ?></h2>

			    			</div>

			    			<div id="total-visits" class="chart"><?php echo get_newbars(); ?></div>

			    		</li>-->

			    		<li>

			    			<div class="showcase">

			    				<span>Total Patient</span>

			    				<h2><?php echo get_total(); ?></h2>

			    			</div>

			    			<div id="balance" class="chart"><?php echo get_bars(); ?></div>

			    		</li>

			    	</ul>

			    </div>

			    <!-- /page header -->





		    	<!--<h5 class="widget-name"><i class="icon-th"></i>View Patient</h5>-->

                



                <!-- Media datatable -->

                <div class="widget">

                	<div class="navbar">

                    	<div class="navbar-inner">

                        	<h6>Tracking Patient Chart</h6>

                            <div class="nav pull-right" style="padding: 8px;">

                                <a href="get_all_data_xlsx.php"><i class="fam-page-excel"></i></a>

                            </div>

                        </div>

                    </div>

                    <div class="table-overflow">

                        <table class="table table-striped table-bordered table-checks media-table">

						

                            <thead>

                                <tr>

                                <th width="106">Date</th>

                                    <th width="71">Image</th>

                                    <th width="122">Patient</th>

                                    <th width="58">Age</th>

                                   <th width="88">
									<form name="allprogram" id="allprogram" method="post">
									<select name="program" id="program" >
										<option <?php if(isset($_POST['program']) and $_POST['program'] == 'All'){echo 'selected';}?> value="All">All</option>
										<option <?php if(isset($_POST['program']) and $_POST['program'] == 'Diabetic'){echo 'selected';}?> value="Diabetic">Diabetic</option>
										<option <?php if(isset($_POST['program']) and $_POST['program'] == 'Theraphetic Life Style Program'){echo 'selected';}?> value="Theraphetic Life Style Program">Theraphetic Life Style Program</option>
										<option <?php if(isset($_POST['program']) and $_POST['program'] == 'HCG Weight Loss Program'){echo 'selected';}?> value="HCG Weight Loss Program">HCG Weight Loss Program</option>
										<option <?php if(isset($_POST['program']) and $_POST['program'] == 'Government Eahanced'){echo 'selected';}?> value="Government Eahanced">Government Eahanced</option>
										<option <?php if(isset($_POST['program']) and $_POST['program'] == 'Alex Health Coaching Program'){echo 'selected';}?> value="Alex Health Coaching Program">Alex Health Coaching Program</option>
										<option <?php if(isset($_POST['program']) and $_POST['program'] == 'Naturopathic Weight Loss Program'){echo 'selected';}?> value="Naturopathic Weight Loss Program">Naturopathic Weight Loss Program</option>
									</select>
									</form>
									</th>

                                    <th width="60">Body fat</th>

                                    <th width="74">Gas Score</th>

                                    <th width="60">Metabolic</th>

                                    <th width="58">PHQ</th>

                                    <th width="97">smoking</th>

                                    <th width="128" class="actions-column">Actions</th>

                                </tr>

                            </thead>

                            <tbody>

                                

								

								<?php $slno =  1; for($i=0; $i<count($result); $i++ ) { ?>

								

								<tr>

									<td><?php  echo $result[$i]['date_time']; ?></td>

			                        <td><a href="<?php  echo $result[$i]['photo']; ?>" title="" class="lightbox"><img width="37" height="36" src="<?php  echo $result[$i]['photo']; ?>" alt="" /></a></td>

			                        <td><a href="edit_patient_nmac.php?id=<?php  echo $result[$i]['id']; ?>" title=""><?php  echo $result[$i]['name']; ?></a></td>

                                    <td><?php  echo $result[$i]['age']; ?></td>

									<td><?php  echo $result[$i]['program']; ?></td>

			                        <td style=""><?php  echo $result[$i]['body_fat']; ?></td>

                                    <td style=""><?php  echo $result[$i]['gasscore']; ?></td>

                                    <td style=""><?php  echo $result[$i]['metabolic_age']; ?></td>

                                    <td style=""><?php  echo $result[$i]['phq']; ?></td>

                                    <td style=""><?php  echo $result[$i]['smoking_cessation']; ?></td>

			                        <td>

		                                <ul class="navbar-icons">

		                                    <li><a href="edit_patient_nmac.php?id=<?php  echo $result[$i]['id']; ?>" class="tip" title="Get Information"><i class="icon-info-sign"></i></a></li>

                                            <li><a href="reports_track.php?id=<?php  echo $result[$i]['id']; ?>" class="tip" title="Get Pdf File"><i class="fam-page-white-acrobat"></i></a></li>

                                            <li><a href="delete.php?status=suspend&id=<?php  echo $result[$i]['id']; ?>" onclick="return confirm('Do you want to suspend the record!');" class="tip" title="Suspend"><i class="fam-cross"></i></a></li>

		                                </ul>

			                        </td>

                                </tr>

                                

                                <?php } ?>

								

                                

                            </tbody>

                        </table>

                    </div>

                </div>

                <!-- /media datatable -->





		    </div>

		    <!-- /content wrapper -->



		</div>

		<!-- /content -->



	</div>

	<!-- /content container -->



 

	<!-- Footer -->

	<div id="footer">

		<div class="copyrights">&copy; <a class="" target="_blank" href="http://www.designdot.co.in">Designdot Technologies Pvt. Ltd.</a> All rights reserved.</div>

		<ul class="footer-links">

			<li><a href="#" title=""><i class="icon-cogs"></i>Contact admin</a></li>

			<li><a href="#" title=""><i class="icon-screenshot"></i>Report bug</a></li>

		</ul>

	</div>

	<!-- /footer -->



</body>

</html>