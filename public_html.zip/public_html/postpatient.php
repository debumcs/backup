<?php
include_once('functions.php');
$con = new dbconnection();
$con->setConnection();

$imagepath = '';

function GetImageExtension($imagetype)
{
	if(empty($imagetype)) return false;
	switch($imagetype)
	{
		case 'image/bmp': return '.bmp';
		case 'image/gif': return '.gif';
		case 'image/jpeg': return '.jpg';
		case 'image/png': return '.png';
		default: return false;
	}
}

if (!empty($_FILES["photo"]["name"])) {

	$file_name=$_FILES["photo"]["name"];
	$temp_name=$_FILES["photo"]["tmp_name"];
	$imgtype=$_FILES["photo"]["type"];
	$ext= GetImageExtension($imgtype);
	$imagename=date("d-m-Y")."-".time().$ext;
	$target_path = "uploads/".$imagename;	

	if(move_uploaded_file($temp_name, $target_path)) {		
		$imagepath = $target_path;		
	}else{
		$imagepath = '';
	} 

}else{
	$imagepath = 'img/default.png';
}

$name=$_POST['name'];
$age=floatval($_POST['age']);
$height=$_POST['height'];
$weight=$_POST['weight'];

$dob = explode('-',$_POST['dob']);
$newDOB = $dob[2].'-'.$dob[1].'-'.$dob[0];

$address=$_POST['address'];
$phoneno=$_POST['phoneno'];
$email=$_POST['email'];
$photo=$imagepath;
$medical_history=$_POST['medical_history'];

$race = $_POST['race'];
$health_status = $_POST['health_status'];
$program = $_POST['program'];

$date_time = explode('-',$_POST['date_time']);
$newDateTime = $date_time[2].'-'.$date_time[1].'-'.$date_time[0];
//echo $newDateTime; die();
$reportedby = $_POST['reported_by'];

$bmi = $_POST['bmi'];
$bmicomment = get_bmi($bmi,$_POST['bmi_comment']);
$bmi_description=$bmicomment['comment'];

$blood_pressure=$_POST['blood_pressure'];
$bpcomment = get_bp($blood_pressure,$_POST['blood_pressure_comment'],$age,$health_status);
$blood_pressure_description = $bpcomment['comment'];


$cholesterol=$_POST['cholesterol'];
$chocomment = get_cholesterol($cholesterol,$_POST['cholesterol_comment']);
$cholesterol_description = $chocomment['comment'];

$hdl=$_POST['hdl'];
$hdlcomment = get_hdl($hdl,$_POST['hdl_comment']);
$hdl_description=$hdlcomment['comment'];

$ldl=$_POST['ldl'];
$ldlcomment = get_ldl($ldl,$_POST['ldl_comment']);
$ldl_description=$ldlcomment['comment'];

$triglycerides=$_POST['triglycerides'];
$tricomment = get_triglycerides($triglycerides,$_POST['triglycerides_comment']);
$triglycerides_description=$tricomment['comment'];


$hba1c=$_POST['hba1c'];
$hba1ccomment = get_hba1c($hba1c,$_POST['hba1c_comment']);
$hba1c_description=$hba1ccomment['comment'];

$fasting = $_POST['fasting'];
$fastingcomment = get_fasting($fasting,$_POST['fasting_comment']);
$fasting_description = $fastingcomment['comment'];

$egfr=$_POST['egfr'];
$egfrcomment = get_egfr($egfr,$_POST['egfr_comment']);
$egfr_description=$egfrcomment['comment'];

$body_fat=$_POST['body_fat'];
$body_fat_description=$_POST['body_fat_description'];

$gasscore=$_POST['gasscore'];
$gasscore_description=$_POST['gasscore_description'];

$metabolic_age=$_POST['metabolic_age'];
$metabolic_age_description=$_POST['metabolic_age_description'];

$phq = $_POST['phq'];
$phq_description = $_POST['phq_description'];

$smoking_cessation = $_POST['smoking_cessation'];

$cessationfrom = explode('-',$_POST['smoking_cessationfrom']);
$cessationto = explode('-',$_POST['smoking_cessationto']);

$smoking_cessationfrom 		= $cessationfrom[2].'-'.$cessationfrom[1].'-'.$cessationfrom[0];
$smoking_cessationto 		= $cessationto[2].'-'.$cessationto[1].'-'.$cessationto[0];
$er_visit = $_POST['er_visit'];
$asthma_copd = $_POST['asthma_copd'];


$sql = "INSERT INTO patient SET ";
$sql .= " name = '".$name."', ";
$sql .= " age = '".$age."', ";
$sql .= " height = '".$height."', ";
$sql .= " weight = '".$weight."', ";
$sql .= " dob = '".$newDOB."', ";
$sql .= " address = '".$address."', ";
$sql .= " phoneno = '".$phoneno."', ";
$sql .= " email = '".$email."' ,";
$sql .= " photo = '".$photo."' ,";
$sql .= " medical_history = '".$medical_history."', ";
$sql .= " date_time = '".$newDateTime."', ";
$sql .= " reportedby = '".$reportedby."', ";
$sql .= " race = '".$race."', ";
$sql .= " program = '".$program."', ";
$sql .= " health_status = '".$health_status."', ";
$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";

/*echo $sql;

SELECT a.* FROM fasting a LEFT JOIN fasting b ON a.patient_id = b.patient_id AND a.datetime > b.datetime WHERE a.patient_id = '".$id."'

die();*/
$result=$con->InsertQuery($sql);

$last_id = $con->lastinsertid();

unset($sql); unset($result);


$sql = "INSERT INTO bmi SET ";
$sql .= " patient_id = '".$last_id."', ";
$sql .= " bmi = '".$bmi."', ";
$sql .= " bmi_description = '".$bmi_description."', ";
$sql .= " datetime = '".$newDateTime."', ";
$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";

$result=$con->InsertQuery($sql);

unset($sql); unset($result);

$sql = "INSERT INTO blood_pressure SET ";
$sql .= " patient_id = '".$last_id."', ";
$sql .= " blood_pressure = '".$blood_pressure."', ";
$sql .= " blood_pressure_description = '".$blood_pressure_description."', ";
$sql .= " datetime = '".$newDateTime."', ";
$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";

$result=$con->InsertQuery($sql);

unset($sql); unset($result);

$sql = "INSERT INTO cholesterol SET ";
$sql .= " patient_id = '".$last_id."', ";
$sql .= " cholesterol = '".$cholesterol."' ,";
$sql .= " cholesterol_description = '".$cholesterol_description."', ";
$sql .= " datetime = '".$newDateTime."', ";
$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";

$result=$con->InsertQuery($sql);

unset($sql); unset($result);

$sql = "INSERT INTO hdl SET ";
$sql .= " patient_id = '".$last_id."', ";
$sql .= " hdl = '".$hdl."', ";
$sql .= " hdl_description = '".$hdl_description."', ";
$sql .= " datetime = '".$newDateTime."', ";
$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";

$result=$con->InsertQuery($sql);

unset($sql); unset($result);

$sql = "INSERT INTO ldl SET ";
$sql .= " patient_id = '".$last_id."', ";
$sql .= " ldl = '".$ldl."', ";
$sql .= " ldl_description = '".$ldl_description."', ";
$sql .= " datetime = '".$newDateTime."', ";
$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";

$result=$con->InsertQuery($sql);

unset($sql); unset($result);

$sql = "INSERT INTO triglycerides SET ";
$sql .= " patient_id = '".$last_id."', ";
$sql .= " triglycerides = '".$triglycerides."', ";
$sql .= " triglycerides_description = '".$triglycerides_description."', ";
$sql .= " datetime = '".$newDateTime."', ";
$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";

$result=$con->InsertQuery($sql);

unset($sql); unset($result);

$sql = "INSERT INTO hba1c SET ";
$sql .= " patient_id = '".$last_id."', ";
$sql .= " hba1c = '".$hba1c."', ";
$sql .= " hba1c_description = '".$hba1c_description."', ";
$sql .= " datetime = '".$newDateTime."', ";
$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";
$result=$con->InsertQuery($sql);

unset($sql); unset($result);

$sql = "INSERT INTO fasting SET ";
$sql .= " patient_id = '".$last_id."', ";
$sql .= " fasting = '".$fasting."', ";
$sql .= " fasting_description = '".$fasting_description."', ";
$sql .= " datetime = '".$newDateTime."', ";
$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";
$result=$con->InsertQuery($sql);

unset($sql); unset($result);

$sql = "INSERT INTO egfr SET ";
$sql .= " patient_id = '".$last_id."', ";
$sql .= " egfr = '".$egfr."', ";
$sql .= " egfr_description = '".$egfr_description."', ";
$sql .= " datetime = '".$newDateTime."', ";
$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";
$result=$con->InsertQuery($sql);

unset($sql); unset($result);

$sql = "INSERT INTO body_fat SET ";
$sql .= " patient_id = '".$last_id."', ";
$sql .= " body_fat = '".$body_fat."', ";
$sql .= " body_fat_description = '".$body_fat_description."', ";
$sql .= " datetime = '".$newDateTime."', ";
$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";
$result=$con->InsertQuery($sql);

unset($sql); unset($result);

$sql = "INSERT INTO gasscore SET ";
$sql .= " patient_id = '".$last_id."', ";
$sql .= " gasscore = '".$gasscore."', ";
$sql .= " gasscore_description = '".$gasscore_description."', ";
$sql .= " datetime = '".$newDateTime."', ";
$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";
$result=$con->InsertQuery($sql);

unset($sql); unset($result);

$sql = "INSERT INTO phq SET ";
$sql .= " patient_id = '".$last_id."', ";
$sql .= " phq = '".$phq."', ";
$sql .= " phq_description = '".$phq_description."', ";
$sql .= " datetime = '".$newDateTime."', ";
$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";
$result=$con->InsertQuery($sql);

unset($sql); unset($result);

$sql = "INSERT INTO metabolic_age SET ";
$sql .= " patient_id = '".$last_id."', ";
$sql .= " metabolic_age = '".$metabolic_age."', ";
$sql .= " metabolic_age_description = '".$metabolic_age_description."', ";
$sql .= " datetime = '".$newDateTime."', ";
$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";
$result=$con->InsertQuery($sql);

unset($sql); unset($result);

$sql = "INSERT INTO others SET ";
$sql .= " patient_id = '".$last_id."', ";
$sql .= " smoking_cessation = '".$smoking_cessation."', ";
$sql .= " smoking_fromdate = '".$smoking_cessationfrom."', ";
$sql .= " smoking_totime = '".$smoking_cessationto."', ";
$sql .= " er_visit = '".$er_visit."', ";
$sql .= " asthma_copd = '".$asthma_copd."', ";
$sql .= " datetime = '".$newDateTime."', ";
$sql .= " entrydate = '".date('Y-m-d H:i:s')."', ";
$sql .= " modifieddate = '".date('Y-m-d H:i:s')."' ";
$result=$con->InsertQuery($sql);



if($result == false){
	echo 'Error';
}else{
	echo "<script>window.location = 'dashboard.php'</script>";
}

?>