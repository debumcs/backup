<?php
include_once('functions.php');
$con = new dbconnection();
$con->setConnection();

	$sql = "select * from patient where id = '".$_GET['id']."'";
	$result = $con->runQuery($sql);

	$sqlbmi = "select * from bmi where patient_id = '".$_GET['id']."'";
	$resultbmi = $con->runQuery($sqlbmi);
	
	$sqlbp = "select * from blood_pressure where patient_id = '".$_GET['id']."'";
	$resultbp = $con->runQuery($sqlbp);

	$sqlcholesterol = "select * from cholesterol where patient_id = '".$_GET['id']."'";
	$resultcholesterol = $con->runQuery($sqlcholesterol);

	$sqlegfr = "select * from egfr where patient_id = '".$_GET['id']."'";
	$resultegfr = $con->runQuery($sqlegfr);

	$sqlhba1c = "select * from hba1c where patient_id = '".$_GET['id']."'";
	$resulthba1c = $con->runQuery($sqlhba1c);

	$sqlfasting = "select * from fasting where patient_id = '".$_GET['id']."'";
	$resultfasting = $con->runQuery($sqlfasting);

	$sqlhdl = "select * from hdl where patient_id = '".$_GET['id']."'";
	$resulthdl = $con->runQuery($sqlhdl);

	$sqlldl = "select * from ldl where patient_id = '".$_GET['id']."'";
	$resultldl = $con->runQuery($sqlldl);

	$sqltri = "select * from triglycerides where patient_id = '".$_GET['id']."'";
	$resulttri = $con->runQuery($sqltri);

	$sqlbodyfat = "select * from body_fat where patient_id = '".$_GET['id']."'";
	$resultbodyfat = $con->runQuery($sqlbodyfat);

	$sqlgs = "select * from gasscore where patient_id = '".$_GET['id']."'";
	$resultgs = $con->runQuery($sqlgs);

	$sqlma = "select * from metabolic_age where patient_id = '".$_GET['id']."'";
	$resultma = $con->runQuery($sqlma);

	$sqlphq = "select * from phq where patient_id = '".$_GET['id']."'";
	$resultphq = $con->runQuery($sqlphq);

	$sqlothers = "select * from others where patient_id = '".$_GET['id']."'";
	$resultothers = $con->runQuery($sqlothers);

	$bmiarray			=	array();
	$bmitime			=	array();
	$bparray			=	array();
	$bptime				=	array();
	$cholesterolarray	=	array();
	$cholesteroltime	=	array();
	$egfrarray			=	array();
	$egfrtime			=	array();
	$hba1carray			=	array();
	$hba1ctime			=	array();
	$fastingarray		=	array();
	$fastingtime		=	array();
	$hdlarray			=	array();
	$hdltime			=	array();
	$ldlarray			=	array();
	$ldltime			=	array();
	$triarray			=	array();
	$tritime			=	array();
	$bodyfatarray		=	array();
	$bodyfattime		=	array();
	$gsarray			=	array();
	$gstime				=	array();
	$maarray			=	array();
	$matime				=	array();
	$phqarray			=	array();
	$phqtime			=	array();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<title>NMAC Health Report Card</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<!--[if IE 8]><link href="css/ie8.css" rel="stylesheet" type="text/css" /><![endif]-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="js/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDY0kkJiTPVd2U7aTOAwhc9ySH6oHxOIYM&amp;sensor=false"></script>
<script type="text/javascript" src="js/plugins/charts/excanvas.min.js"></script>
<script type="text/javascript" src="js/plugins/charts/jquery.flot.js"></script>
<script type="text/javascript" src="js/plugins/charts/jquery.flot.resize.js"></script>
<script type="text/javascript" src="js/plugins/charts/jquery.sparkline.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.easytabs.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.collapsible.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/prettify.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.colorpicker.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.timepicker.min.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.fancybox.js"></script>
<script type="text/javascript" src="js/plugins/ui/jquery.fullcalendar.min.js"></script>
<script type="text/javascript" src="js/plugins/forms/jquery.uniform.min.js"></script>
<script type="text/javascript" src="js/plugins/forms/jquery.tagsinput.min.js"></script>
<script type="text/javascript" src="js/plugins/tables/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/files/bootstrap.min.js"></script>
<script type="text/javascript" src="js/functions/index.js"></script>
<script type="text/javascript">
function getotheredit(id){
	document.getElementById("editdateother").value = document.getElementById('dateother'+id).value;
	document.getElementById("editidother").value = document.getElementById('idother'+id).value;
	document.getElementById("editpatientidother").value = document.getElementById('patient_idother'+id).value;
	if(document.getElementById("smoking_cessation1"+id).checked == true){
		document.getElementById("editsmoking_cessation1").checked = true;
	}
	if(document.getElementById("smoking_cessation2"+id).checked == true){
		document.getElementById("editsmoking_cessation2").checked = true;
	}
	document.getElementById('editsmoking_cessationfrom').value = document.getElementById('smoking_fromdate'+id).value;
	document.getElementById('editsmoking_cessationto').value = document.getElementById('smoking_totime'+id).value;
	if(document.getElementById("er_visit1"+id).checked == true){
		document.getElementById("editer_visit1").checked = true;
	}
	if(document.getElementById("er_visit2"+id).checked == true){
		document.getElementById("editer_visit2").checked = true;
	}
	document.getElementById('editasthma_copd').value = document.getElementById('descriptionother'+id).value;
}

function getedit(type,id){
	var datetime = $("#date"+type+id).val();
	var id = $("#id"+type+id).val();
	var patient_id = $("#patient_id"+type+id).val();
	var score = $("#score"+type+id).val();
	var description = $("#description"+type+id).val();
	//alert(datetime);
	document.getElementById('editdatetime').value = '';
	document.getElementById('editid').value = '';
	document.getElementById('edittype').value = '';
	document.getElementById('editpatientid').value = '';
	document.getElementById('editscore').value = '';
	document.getElementById('editdescription').value = '';
	document.getElementById('editdatetime').value = datetime;
	document.getElementById('editid').value = id;
	document.getElementById('edittype').value = type;
	document.getElementById('editpatientid').value = patient_id;
	document.getElementById('editscore').value = score;
	document.getElementById('editdescription').value = description;
}
function getform(action){
	document.getElementById('formid').value =action;
}
function editothervalidate(){
	var datevalue = document.getElementById("editdateother").value;
	if(!isDate(datevalue)){
		alert('Please enter date with proper format!');
		document.getElementById("editdatetime").focus();
		return false;
	}else if(document.getElementById("editsmoking_cessation1").checked == true && !isDate(document.getElementById("editsmoking_cessationfrom").value)){
		alert('Please enter valid date!');
		document.getElementById("editsmoking_cessationfrom").value = '';
		document.getElementById("editsmoking_cessationfrom").focus();
		return false;
	}else if(document.getElementById("editsmoking_cessation1").checked == true && !isDate(document.getElementById("editsmoking_cessationto").value)){
		alert('Please enter valid date!');
		document.getElementById("editsmoking_cessationto").value='';
		document.getElementById("editsmoking_cessationto").focus();
		return false;
	}else if(document.getElementById("editasthma_copd").value== ''){
		alert('Please enter asthma_copd!');
		document.getElementById("editasthma_copd").focus();
		return false;

	}else{

		

		return true;

	}

}

	



	function editvalidate(){

		

		var tvalue = document.getElementById("editscore").value;

		var datevalue = document.getElementById("editdatetime").value;

				

		if(!isDate(datevalue)){

			alert('Please enter date with proper format!');

			document.getElementById("editdatetime").focus();

			return false;

		}else if(document.getElementById("editscore").value== ''){

			alert('Please enter score!');

			document.getElementById("editscore").focus();

			return false;

		}else if(document.getElementById('edittype').value== 'bp'){

			if(!isBP(document.getElementById("editscore").value)){

				alert('Please enter score!Format: 120/80');

				document.getElementById("editscore").focus();

				return false;

			}

		}else{

			

			return true;

		}

	}

	

	

	function isBP(txtDate)

	{

		var currVal = txtDate;

		

		var rxDatePattern = /^(\d{2,3})(\/|-)(\d{2,3})$/; //Declare Regex

		var dtArray = currVal.match(rxDatePattern); // is format OK?

		

		if (dtArray == null) 

			return false;

		

		return true;

	}



	

	function isDate(txtDate)
	{
		var currVal = txtDate;
		if(currVal == '')
			return false;		

		var rxDatePattern = /^(\d{1,2})(\-|-)(\d{1,2})(\-|-)(\d{4})$/; //Declare Regex
		var dtArray = currVal.match(rxDatePattern); // is format OK?		

		if (dtArray == null)
			return false;		

		//Checks for mm/dd/yyyy format.

		dtDay = dtArray[1];
		dtYear= dtArray[5];
		dtMonth = dtArray[3];

		//var dated = dtDay+"-"+dtMonth+"-"+dtYear;
		//alert(dated);

		if (dtMonth < 1 || dtMonth > 12) 
			return false;
		else if (dtDay < 1 || dtDay> 31) 
			return false;
		else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31) 
			return false;
		else if (dtMonth == 2) 
		{
			var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));
			if (dtDay> 29 || (dtDay ==29 && !isleap)) 
				return false;
		}
		return true ;
	}

	function validation(){

		var tvalue = document.getElementById("blood_pressure").value;

		var radios = document.getElementsByName("smoking_cessation");

		

		if(!isDate(document.getElementById("date").value)){

			alert('Please enter valid date!');

			document.getElementById("date").value = '';

			document.getElementById("date").focus();

			return false;

		}else if(document.getElementById("bmi").value== ''){

			alert('Please enter bmi!');

			document.getElementById("bmi").focus();

			return false;

		}else if(document.getElementById("blood_pressure").value== ''){

			alert('Please enter blood pressure!');

			document.getElementById("blood_pressure").focus();

			return false;

		}else if(!isBP(tvalue)){

			alert('Please enter proper blood pressure value. e.g, 120/80!');

			document.getElementById("blood_pressure").value = '';

			document.getElementById("blood_pressure").focus();

			return false;

		}else if(document.getElementById("cholesterol").value== ''){

			alert('Please enter cholesterol!');

			document.getElementById("cholesterol").focus();

			return false;

		}else if(document.getElementById("hdl").value== ''){

			alert('Please enter hdl!');

			document.getElementById("hdl").focus();

			return false;

		}else if(document.getElementById("ldl").value== ''){

			alert('Please enter ldl!');

			document.getElementById("ldl").focus();

			return false;

		}else if(document.getElementById("triglycerides").value== ''){

			alert('Please enter triglycerides!');

			document.getElementById("triglycerides").focus();

			return false;

		}else if(document.getElementById("hba1c").value== ''){

			alert('Please enter hba1c!');

			document.getElementById("hba1c").focus();

			return false;

		}else if(document.getElementById("fasting").value== ''){

			alert('Please enter diabetes fasting!');

			document.getElementById("fasting").focus();

			return false;

		}else if(document.getElementById("egfr").value== ''){

			alert('Please enter egfr!');

			document.getElementById("egfr").focus();

			return false;

		}else if(document.getElementById("body_fat").value== ''){

			alert('Please enter body fat!');

			document.getElementById("body_fat").focus();

			return false;

		}else if(document.getElementById("gasscore").value== ''){

			alert('Please enter gas score!');

			document.getElementById("gasscore").focus();

			return false;

		}else if(document.getElementById("phq").value== ''){

			alert('Please enter phq!');

			document.getElementById("phq").focus();

			return false;

		}else if(document.getElementById("metabolic_age").value== ''){

			alert('Please enter metabolic age!');

			document.getElementById("metabolic_age").focus();

			return false;

		}else if(radios[0].checked == true && document.getElementById("smoking_cessationfrom").value == '') {

			alert('Please enter valid date!');

			document.getElementById("smoking_cessationfrom").focus();

			return false;

		}else if(radios[0].checked == true && document.getElementById("smoking_cessationto").value == '') {

			alert('Please enter valid date!');

			document.getElementById("smoking_cessationto").focus();

			return false;

		}else{

			return true;

		}

		

	}

</script>

</head>



<body>



	<!-- Fixed top smoking_cessation-->

	<div id="top">

		<div class="fixed">

				<a href="dashboard.php" title="" class="logo"><img src="img/logo.png" alt="" /></a>

			    <ul class="top-menu">

				<li><a class="fullview"></a></li>

				<li class="dropdown">

					<a class="user-menu" data-toggle="dropdown"><img src="img/userpic.png" alt="" /><span>Howdy, Admin! <b class="caret"></b></span></a>

					<ul class="dropdown-menu">

						<li><a href="#" title="" data-toggle="modal" data-target="#ProfileView"><i class="icon-user"></i>Profile</a></li>

						<li><a href="logout.php" title=""><i class="icon-remove"></i>Logout</a></li>

					</ul>

				</li>

			</ul>

		</div>

	</div>

	<!-- /fixed top -->





	<!-- Content container -->

	<div id="container">



		<!-- Sidebar -->

		<div id="sidebar">



			<div class="sidebar-tabs">

		        <ul class="tabs-nav two-items">

		            <li><a href="#general" title=""><i class="icon-reorder"></i></a></li>

		            <li><a href="#stuff" title=""><i class="icon-cogs"></i></a></li>

		        </ul>



		        <div id="general">



			        <!-- Sidebar user -->

			        <div class="sidebar-user widget">

						<div class="navbar"><div class="navbar-inner"><h6>Wazzup, Admin!</h6></div></div>

			            

			        </div>

			        <!-- /sidebar user -->





				    <!-- Main navigation -->

			        <?php 

						get_menu();

					?>

			        <!-- /main navigation -->



		        </div>



		        <div id="stuff">



			        <!-- Social stats -->

			        <div class="widget">

			        	<h6 class="widget-name"><i class="icon-user"></i>Urgent Call</h6>

			        	<ul class="social-stats">

			        		<?php urgent_call(); ?>			        	

			        	</ul>

			        </div>

			        <!-- /social stats -->

                   



		        </div>



		    </div>

		</div>

		<!-- /sidebar -->





		<!-- Content -->

		<div id="content">



		    <!-- Content wrapper -->

		    <div class="wrapper">



			    <!-- Breadcrumbs line -->

			    <div class="crumbs">

		            <ul id="breadcrumbs" class="breadcrumb"> 

		                <li><a href="dashboard.php">Dashboard</a></li>

		                <li class="active"><a href="#" title="">Tracking Patient&nbsp;&nbsp;&nbsp;>&nbsp;&nbsp;&nbsp;Edit Patient</a></li>

		            </ul>

			        

			    </div>

			    <!-- /breadcrumbs line -->



			    <!-- Page header -->

			    <div class="page-header">

			    	<div class="page-title">

				    	<h5><strong>Tracking Patient</strong>&nbsp;&nbsp;&nbsp;>&nbsp;&nbsp;&nbsp;<strong>Edit Patient</h5>

				    	<span>Welcome, Admin!</span>

			    	</div>



			    	<ul class="page-stats">

			    		<!--<li>

			    			<div class="showcase">

			    				<span>New Patient</span>

			    				<h2><?php echo get_newtotal(); ?></h2>

			    			</div>

			    			<div id="total-visits" class="chart"><?php echo get_newbars(); ?></div>

			    		</li>-->

			    		<li>

			    			<div class="showcase">

			    				<span>Total Patient</span>

			    				<h2><?php echo get_total(); ?></h2>

			    			</div>

			    			<div id="balance" class="chart"><?php echo get_bars(); ?></div>

			    		</li>

			    	</ul>

			    </div>

			    <!-- /page header -->

 

<!-- Details of person -->

<div class="row-fluid">

<div class="span12 patient_profile">



<div class="span6 profile_details">

<div class="profile_details_inner">

<div class="span6 profile_brd_rt">

<div class="patient_profile_section">

<a href="#" class="icon-edit icon_location" data-toggle="modal" data-target="#EditPatient"></a>

<div class="profile-img">

<img src="<?php echo $result[0]['photo'];?>" width="153" height="143" alt="<?php echo $result[0]['name'];?>">

</div>

<a href="#" class="icon-camera icon_upload" data-toggle="modal" data-target="#EditPatient"></a>

<div class="profile_name_details">

<h5><?php echo $result[0]['name'];?></h5>

</div>

</div>



</div>

<div class="span6">

<div class="new_encounter_form">

<form class="">

<div class="row-fluid">

                                        <div class="span3"><div class="control-group">

						            <label class="control-label">Age</label>

	<div class="controls"><input type="text" class="span12" placeholder="<?php echo $result[0]['age'];?>" readonly name="" value=""></div>

						        </div></div>

                                        <div class="span9"><div class="control-group">

						            <label class="control-label">Date Of Birth</label>

						            

				<div class="controls"><input type="text" class="span12" placeholder="<?php $dob=date_create($result[0]['dob']); echo date_format($dob,"d-m-Y"); ?>" readonly name="" value=""></div>

									

						        </div></div>

                                        </div>



<div class="row-fluid">

                                        <div class="span6"><div class="control-group">

						            <label class="control-label">Weight</label>

						            <div class="controls"><input type="text" class="span12" placeholder="<?php echo $result[0]['weight'];?>" readonly name="" value=""></div>

						        </div></div>

                                <div class="span6"><div class="control-group">

						            <label class="control-label">Height</label>

						            <div class="controls"><input type="text" class="span12" placeholder="<?php echo $result[0]['height'];?>" readonly name="" value=""></div>

						        </div></div>

                                        </div>                                        

 <div class="control-group">

						            <label class="control-label">Address:</label>

						            <div class="controls"><textarea readonly class="span12" rows="1"><?php echo $result[0]['address'];?></textarea></div>

						        </div>

								<div class="row-fluid">

                                        <div class="span6"><div class="control-group">

						            <label class="control-label">Race</label>

						            <div class="controls"><input type="text" class="span12" placeholder="<?php echo $result[0]['race'];?>" readonly name="" value=""></div>

						        </div></div>

                                <div class="span6">
									<div class="control-group">
										<label class="control-label">Health Status</label>
										<div class="controls">
											<input type="text" class="span12" placeholder="<?php echo $result[0]['health_status'];?>" readonly name="" value="">
										</div>
									</div>
								</div>
								
								<div class="span6">
									<div class="control-group">
										<label class="control-label">Program</label>
										<div class="controls">
											<input type="text" class="span12" placeholder="<?php echo $result[0]['program'];?>" readonly name="" value="">
										</div>
									</div>
								</div>

                                        </div>

                                                                

            <div class="form-actions"></div>                    

			<div class="form-actions">

				<button class="btn btn-primary" type="submit"  data-toggle="modal" data-target="#AddBodyFat">New Encounter</button>

			</div>                

</form>

</div>

</div>

</div>

</div>



<div class="span6">

<div class="present_doctor">

<form class="search widget" action="#">

<div class="row-fluid">

                                        <div class="span6">

                                        <div class="control-group">

						            <label class="control-label">Phone No:</label>

						            <div class="controls"><input type="text" class="span12" readonly name="" value="" placeholder="<?php echo $result[0]['phoneno'];?>"></div>

						        </div>

                                </div>

                                        <div class="span6">

                                        <div class="control-group">

						            <label class="control-label">Email Id:</label>

						            <div class="controls"><input type="email" class="span12" readonly name="" value="" placeholder="<?php echo $result[0]['email'];?>"></div>

						        </div>

                                </div>

                                        </div>

                                        <div class="control-group">

	                                <label class="control-label"><b>Medical History:</b></label>

	                                <div class="controls">

	                                    <textarea class="span12" readonly name="textarea" cols="5" rows="2"><?php echo $result[0]['medical_history'];?></textarea>

	                                </div>

	                            </div>

                                        <div class="row-fluid">

                                        <div class="span6"><div class="control-group">

						            <label class="control-label">Date</label>

						            <div class="controls"><input type="text" name="regular" placeholder="<?php $date_time=date_create($result[0]['date_time']); echo date_format($date_time,"d-m-Y"); ?>" readonly class="span12" /></div>

						        </div></div>

                                        <div class="span6"><div class="control-group">

						            <label class="control-label">Report By</label>

						            <div class="controls"><input type="text" name="regular" placeholder="<?php echo $result[0]['reportedby'];?>" readonly class="span12" /></div>

						        </div></div>

                                        </div>

    

                            

    </form>

</div>

</div>

</div>



</div>

<!-- /Details of person -->

<div class="row-fluid">

<div class="span12">

<!--<div class="span8">-->



		    	<h5 class="widget-name"><i class="icon-user"></i>Body Composition</h5>

                <!-- body Composition -->

                <div class="row-fluid">

                <div class="span8">

                <ul class="stats-details">

				            		<li>

				            		<h5> BMI: </h5>

				            		</li>

				            		

				            	</ul>

                <ul class="list_inline">

								<li class="tx_gr">Underweight (&lt; 18.5) </li>
								<li class="tx_yl">Normal (18.5 – 24.9) </li>
								<li class="tx_rd">Overweight (25 – 29.9)</li>
								<li class="tx_rd_drk">Obese (&gt; 30) </li>
							</ul>



	<?php  for($bmi=0;$bmi<count($resultbmi);$bmi++){

			if($resultbmi[$bmi]['bmi'] > 0)	{
				$bmiarray[] = $resultbmi[$bmi]['bmi'];
				$bmitime[] = $resultbmi[$bmi]['datetime'];
			}
	?>								

	<div class="health_card">

	<form class="search widget" action="#">

	<div class="control-group padd_btm0">

		<div class="controls">

		<div class="row-fluid">

			<div class="span2">

			<input type="text" class="span12" name="datebmi<?php echo $resultbmi[$bmi]['id']; ?>" id="datebmi<?php echo $resultbmi[$bmi]['id']; ?>" value="<?php $bmidatetime=date_create($resultbmi[$bmi]['datetime']); echo date_format($bmidatetime,"d-m-Y"); ?>" readonly >

			<input type="hidden" name="idbmi<?php echo $resultbmi[$bmi]['id']; ?>" id="idbmi<?php echo $resultbmi[$bmi]['id']; ?>" value="<?php echo $resultbmi[$bmi]['id']; ?>" >

			<input type="hidden" name="patient_idbmi<?php echo $resultbmi[$bmi]['id']; ?>" id="patient_idbmi<?php echo $resultbmi[$bmi]['id']; ?>" value="<?php echo $resultbmi[$bmi]['patient_id']; ?>" >

			<span class="help-block">Date</span>

			</div>  

			<div class="span2">

			<input type="text" readonly class="span12" name="scorebmi<?php echo $resultbmi[$bmi]['id']; ?>" id="scorebmi<?php echo $resultbmi[$bmi]['id']; ?>" value="<?php echo $resultbmi[$bmi]['bmi']; ?>" >

			<span class="help-block">Your Score Card</span>

			</div>

			<div class="span1">

			<?php $databmi = get_bmi($resultbmi[$bmi]['bmi'],$resultbmi[$bmi]['bmi_description']); echo $databmi['image']; ?>

			</div>

			<div class="span6">

			<textarea readonly class="span12" name="descriptionbmi<?php echo $resultbmi[$bmi]['id']; ?>" id="descriptionbmi<?php echo $resultbmi[$bmi]['id']; ?>"><?php echo $resultbmi[$bmi]['bmi_description'];?></textarea>

			<span class="help-block">Comments</span>

			</div>

			<div class="span1">

			<button data-target="#Edit" data-toggle="modal" class="btn btn-info" onclick="getedit('bmi','<?php echo $resultbmi[$bmi]['id']; ?>');" type="button">Edit</button>

			</div>

		</div>



		</div>

	</div>



	</form>

	</div>

	<?php } ?>



</div>



<div class="span4">

	<ul class="stats-details">

		<li><h5>Graph:</h5></li>

	</ul>

	<?php $yybmiarray = base64_encode(serialize($bmiarray)); $xxbmitime = base64_encode(serialize($bmitime)); ?>

	<div class="span12 score_card">

		<div class="graph-standard" id="graph1">
		<?php if(!empty($bmiarray)){?>
			<img src="phpgraphlib/index.php?x=<?php echo $xxbmitime;?>&y=<?php echo $yybmiarray;?>"/>
		<?php } ?>
		</div>

	</div>

</div>



<!-- Body Fat -->

<div class="">

				<div class="span8">

                <ul class="stats-details">

				            		<li>

				            		<h5> Body Fat: </h5>

				            		</li>

				            		

				            	</ul>

                

<?php for($fat=0; $fat < count($resultbodyfat); $fat++){

		if($resultbodyfat[$fat]['body_fat'] > 0){
			$bodyfatarray[]		=	$resultbodyfat[$fat]['body_fat'];
			$bodyfattime[]		=	$resultbodyfat[$fat]['datetime'];
		}

?>									

<div class="health_card">

<form class="search widget" action="#">

    <div class="control-group padd_btm0">

	                                        <div class="controls">

                                            <div class="row-fluid">

                                             <div class="span2">

		<input type="text" class="span12" name="datefat<?php echo $resultbodyfat[$fat]['id']; ?>" id="datefat<?php echo $resultbodyfat[$fat]['id']; ?>" value="<?php $fatdatetime = date_create($resultbodyfat[$fat]['datetime']); echo date_format($fatdatetime,"d-m-Y"); ?>" readonly >
		<input type="hidden" name="idfat<?php echo $resultbodyfat[$fat]['id']; ?>" id="idfat<?php echo $resultbodyfat[$fat]['id']; ?>" value="<?php echo $resultbodyfat[$fat]['id']; ?>" >
		<input type="hidden" name="patient_idfat<?php echo $resultbodyfat[$fat]['id']; ?>" id="patient_idfat<?php echo $resultbodyfat[$fat]['id']; ?>" value="<?php echo $resultbodyfat[$fat]['patient_id']; ?>" >

        <span class="help-block">Date</span>

						                    </div>  

                                        	<div class="span2">

						                    	<input type="text" disabled class="span12" name="scorefat<?php echo $resultbodyfat[$fat]['id']; ?>" id="scorefat<?php echo $resultbodyfat[$fat]['id']; ?>" value="<?php echo $resultbodyfat[$fat]['body_fat']; ?>" >

												<span class="help-block">Your Score Card</span>

						                    </div>

                                            <div class="span1">

						                    	&nbsp;

						                    </div>

                                            <div class="span6">

                                            <textarea readonly name="descriptionfat<?php echo $resultbodyfat[$fat]['id']; ?>" id="descriptionfat<?php echo $resultbodyfat[$fat]['id']; ?>" class="span12"><?php echo $resultbodyfat[$fat]['body_fat_description']; ?></textarea>

                                                <span class="help-block">Comments</span>

						                    </div>

						                	<div class="span1">

						                    	<button data-target="#Edit" data-toggle="modal" onclick="getedit('fat','<?php echo $resultbodyfat[$fat]['id']; ?>');" class="btn btn-info" type="button">Edit</button>

						                    </div>

						            	</div>

	                                            

	                                        </div>

	                                    </div>

                            

    </form>

</div>   

<?php } ?>

</div>                

<div class="span4">

	<ul class="stats-details">

		<li><h5>Graph:</h5></li>

	</ul>

	<?php $yybodyfatarray = base64_encode(serialize($bodyfatarray)); $xxbodyfattime = base64_encode(serialize($bodyfattime)); ?>

	<div class="span12 score_card">

		<div class="graph-standard" id="graph10">
		<?php if(!empty($bodyfatarray)){?>
			<img src="phpgraphlib/index.php?x=<?php echo $xxbodyfattime;?>&y=<?php echo $yybodyfatarray;?>"/>
		<?php } ?>
		</div>

	</div>

</div>

                </div>

                

                </div>

		    	<!-- /body Composition -->

                

                

                <h5 class="widget-name"><i class="icon-heart"></i>Heart Disease</h5>

                <!-- heart Disease -->

                <div class="row-fluid">

                <div class="span12">

                <div class="">

<div class="span8">

                <ul class="stats-details">

				            		<li>

				            		<h5> Blood Pressure </h5>

				            		</li>

				            		<li>

				            			<div class="pull-right bulk">

					            &nbsp;

				    		</div>

				            		</li>

				            	</ul>

                <ul class="list_inline">

                                    <li class="tx_gr">Normal </li>

                                    <li class="tx_yl">Prehypertension</li>

                                    <li class="tx_rd">Hypertension Stage 1</li>

                                    <li class="tx_rd_drk">Hypertension Stage 2 </li>

                                    </ul>



<?php  for($bp=0;$bp<count($resultbp);$bp++){ 

			$exbp = explode('/',$resultbp[$bp]['blood_pressure']);
			if($exbp[0] > 0){
				$bparray[]	= $exbp[0];
				$bptime[]	= $resultbp[$bp]['datetime'];
			}
?>	

<div class="health_card">

<form class="search widget" action="#">

    <div class="control-group padd_btm0">

		<div class="controls">

		<div class="row-fluid">

		 <div class="span2">

			<input type="text" class="span12" name="datebp<?php echo $resultbp[$bp]['id']; ?>" id="datebp<?php echo $resultbp[$bp]['id']; ?>" value="<?php  $bpdatetime = date_create($resultbp[$bp]['datetime']); echo date_format($bpdatetime,"d-m-Y");  ?>" readonly>

			<input type="hidden" name="idbp<?php echo $resultbp[$bp]['id']; ?>" id="idbp<?php echo $resultbp[$bp]['id']; ?>" value="<?php echo $resultbp[$bp]['id']; ?>" >

			<input type="hidden" name="patient_idbp<?php echo $resultbp[$bp]['id']; ?>" id="patient_idbp<?php echo $resultbp[$bp]['id']; ?>" value="<?php echo $resultbp[$bp]['patient_id']; ?>" >

			<span class="help-block">Date</span>

		</div>  

		<div class="span2">

			<input type="text" readonly class="span12" name="scorebp<?php echo $resultbp[$bp]['id']; ?>" id="scorebp<?php echo $resultbp[$bp]['id']; ?>" value="<?php echo $resultbp[$bp]['blood_pressure']; ?>">

			<span class="help-block">Your Score Card</span>

		</div>

		<div class="span1">

			<?php $databp = get_bp($resultbp[$bp]['blood_pressure'],$resultbp[$bp]['blood_pressure_description'],$result[0]['age'],$result[0]['health_status']); echo $databp['image']; ?>

		</div>

		<div class="span6">

			<textarea readonly class="span12" name="descriptionbp<?php echo $resultbp[$bp]['id']; ?>" id="descriptionbp<?php echo $resultbp[$bp]['id']; ?>"><?php echo $resultbp[$bp]['blood_pressure_description']; ?></textarea>

			<span class="help-block">Comments</span>

		</div>

		<div class="span1">

			<button data-target="#Edit" data-toggle="modal" onclick="getedit('bp','<?php echo $resultbp[$bp]['id']; ?>');" class="btn btn-info" type="button">Edit</button>

		</div>

	</div>

			

		</div>

	</div>

                            

</form>

</div>   

<?php } ?>

</div>                

<div class="span4">

	<ul class="stats-details">

		<li><h5>Graph:</h5></li>

	</ul>

	<?php $yybparray = base64_encode(serialize($bparray)); $xxbptime = base64_encode(serialize($bptime)); ?>

	<div class="span12 score_card">

		<div class="graph-standard" id="graph2">
		<?php if(!empty($bparray)){?>
			<img src="phpgraphlib/index.php?x=<?php echo $xxbptime;?>&y=<?php echo $yybparray;?>"/>
		<?php } ?>
		</div>

	</div>

</div>	

				

				</div>

                

                <div class="">

<div class="span8">

                <ul class="stats-details">

				            		<li>

				            		<h5> Total Cholesterol </h5>

				            		</li>

				            		<li>

				            			<div class="pull-right bulk">

					            <div class="bar-button">

					            	&nbsp;

					            </div>

				    		</div>

				            		</li>

				            	</ul>

                <ul class="list_inline">

                                    <li class="tx_gr">Desirable (&lt; 200)  </li>

                                    <li class="tx_yl">Borderline (200 – 239) </li>

                                    <li class="tx_rd">High (&gt;=240)</li>

                                    </ul>                



<?php  for($cholesterol=0;$cholesterol<count($resultcholesterol);$cholesterol++){ 

		if($resultcholesterol[$cholesterol]['cholesterol'] > 0){
			$cholesterolarray[]	=	$resultcholesterol[$cholesterol]['cholesterol'];
			$cholesteroltime[]	=	$resultcholesterol[$cholesterol]['datetime'];
		}
?>

<div class="health_card">

<form class="search widget" action="#">

    <div class="control-group padd_btm0">

	                                        <div class="controls">

                                            <div class="row-fluid">

                                             <div class="span2">

						                    	<!--<input type="text" disabled class="span12" name="regular" placeholder="08/01/2016">-->

			<input type="text" class="span12" name="datecholesterol<?php echo $resultcholesterol[$cholesterol]['id']; ?>" id="datecholesterol<?php echo $resultcholesterol[$cholesterol]['id']; ?>" value="<?php $cholesteroldatetime = date_create($resultcholesterol[$cholesterol]['datetime']); echo date_format($cholesteroldatetime,"d-m-Y"); ?>" readonly >

			<input type="hidden" name="idcholesterol<?php echo $resultcholesterol[$cholesterol]['id']; ?>" id="idcholesterol<?php echo $resultcholesterol[$cholesterol]['id']; ?>" value="<?php echo $resultcholesterol[$cholesterol]['id']; ?>" >

			<input type="hidden" name="patient_idcholesterol<?php echo $resultcholesterol[$cholesterol]['id']; ?>" id="patient_idcholesterol<?php echo $resultcholesterol[$cholesterol]['id']; ?>" value="<?php echo $resultcholesterol[$cholesterol]['patient_id']; ?>" >

                                                <span class="help-block">Date</span>

						                    </div>  

                                        	<div class="span2">

						                    	<!--<input type="text" disabled class="span12" name="regular" placeholder="200">-->

												<input type="text" disabled class="span12" name="scorecholesterol<?php echo $resultcholesterol[$cholesterol]['id']; ?>" id="scorecholesterol<?php echo $resultcholesterol[$cholesterol]['id']; ?>" value="<?php echo $resultcholesterol[$cholesterol]['cholesterol']; ?>" >

                                                <span class="help-block">Your Score Card</span>

						                    </div>

                                            <div class="span1">

						                    	<?php $datacho = get_cholesterol($resultcholesterol[$cholesterol]['cholesterol'],$resultcholesterol[$cholesterol]['cholesterol_description']); echo $datacho['image']; ?>

						                    </div>

                                            <div class="span6">

                                            <textarea readonly class="span12" name="descriptioncholesterol<?php echo $resultcholesterol[$cholesterol]['id']; ?>" id="descriptioncholesterol<?php echo $resultcholesterol[$cholesterol]['id']; ?>"><?php echo $resultcholesterol[$cholesterol]['cholesterol_description']; ?></textarea>

                                                <span class="help-block">Comments</span>

						                    </div>

						                	<div class="span1">

						                    	<button data-target="#Edit" data-toggle="modal" onclick="getedit('cholesterol','<?php echo $resultcholesterol[$cholesterol]['id']; ?>');" class="btn btn-info" type="button">Edit</button>

						                    </div>

						            	</div>

	                                            

	                                        </div>

	                                    </div>

                            

    </form>

</div>   

<?php } ?>

</div>                

<div class="span4">

	<ul class="stats-details">

		<li><h5>Graph:</h5></li>

	</ul>

	<?php $yycholesterolarray = base64_encode(serialize($cholesterolarray)); $xxcholesteroltime = base64_encode(serialize($cholesteroltime)); ?>

	<div class="span12 score_card">

		<div class="graph-standard" id="graph3">
		<?php if(!empty($cholesterolarray)){ ?>
			<img src="phpgraphlib/index.php?x=<?php echo $xxcholesteroltime;?>&y=<?php echo $yycholesterolarray;?>"/>
		<?php } ?>
		</div>

	</div>

</div>	

                </div>

                

                <div class="">

<div class="span8">

                <ul class="stats-details">

				            		<li>

				            		<h5> HDL </h5>

				            		</li>

				            		<li>

				            			<div class="pull-right bulk">

					            <div class="bar-button">

					            	&nbsp;

					            </div>

				    		</div>

				            		</li>

				            	</ul>

                <ul class="list_inline">

                                    <li class="tx_rd">Low (&lt; 50) </li>

                                    <li class="tx_gr">Normal (&gt;=50)</li>

                                    </ul>                



<?php  for($hdl=0;$hdl<count($resulthdl);$hdl++){ 
		if($resulthdl[$hdl]['hdl'] > 0){
			$hdlarray[]	=	$resulthdl[$hdl]['hdl'];
			$hdltime[]	=	$resulthdl[$hdl]['datetime'];
		}
?>

<div class="health_card">

<form class="search widget" action="#">

    <div class="control-group padd_btm0">

	                                        <div class="controls">

                                            <div class="row-fluid">

                                             <div class="span2">

						                    	<!--<input type="text" disabled class="span12" name="regular" placeholder="08/01/2016">-->

			<input type="text" class="span12" name="datehdl<?php echo $resulthdl[$hdl]['id']; ?>" id="datehdl<?php echo $resulthdl[$hdl]['id']; ?>" value="<?php $hdldatetime = date_create($resulthdl[$hdl]['datetime']); echo date_format($hdldatetime,"d-m-Y"); ?>" readonly >

			<input type="hidden" name="idhdl<?php echo $resulthdl[$hdl]['id']; ?>" id="idhdl<?php echo $resulthdl[$hdl]['id']; ?>" value="<?php echo $resulthdl[$hdl]['id']; ?>" >

			<input type="hidden" name="patient_idhdl<?php echo $resulthdl[$hdl]['id']; ?>" id="patient_idhdl<?php echo $resulthdl[$hdl]['id']; ?>" value="<?php echo $resulthdl[$hdl]['patient_id']; ?>" >

                                                <span class="help-block">Date</span>

						                    </div>  

                                        	<div class="span2">

						                    	<!--<input type="text" disabled class="span12" name="regular" placeholder="51">-->

		<input type="text" disabled class="span12" name="scorehdl<?php echo $resulthdl[$hdl]['id']; ?>" id="scorehdl<?php echo $resulthdl[$hdl]['id']; ?>" value="<?php echo $resulthdl[$hdl]['hdl']; ?>" >

                                                <span class="help-block">Your Score Card</span>

						                    </div>

                                            <div class="span1">

						                    	<?php $datahdl = get_hdl($resulthdl[$hdl]['hdl'],$resulthdl[$hdl]['hdl_description']); echo $datahdl['image']; ?>

						                    </div>

                                            <div class="span6">

                                            <textarea readonly class="span12" name="descriptionhdl<?php echo $resulthdl[$hdl]['id']; ?>" id="descriptionhdl<?php echo $resulthdl[$hdl]['id']; ?>"><?php echo $resulthdl[$hdl]['hdl_description']; ?></textarea>

                                                <span class="help-block">Comments</span>

						                    </div>

						                	<div class="span1">

						                    	<button data-target="#Edit" data-toggle="modal" onclick="getedit('hdl','<?php echo $resulthdl[$hdl]['id']; ?>');" class="btn btn-info" type="button">Edit</button>

						                    </div>

						            	</div>

	                                            

	                                        </div>

	                                    </div>

                            

    </form>

</div>   

<?php } ?>

</div>                

<div class="span4">

	<ul class="stats-details">

		<li><h5>Graph:</h5></li>

	</ul>

	<?php $yyhdlarray = base64_encode(serialize($hdlarray)); $xxhdltime = base64_encode(serialize($hdltime)); ?>

	<div class="span12 score_card">

		<div class="graph-standard" id="graph4">
		
		<?php if(!empty($hdlarray)){?>
			<img src="phpgraphlib/index.php?x=<?php echo $xxhdltime;?>&y=<?php echo $yyhdlarray;?>"/>
		<?php } ?>
		</div>

	</div>

</div>

</div>

                

                <div class="">

<div class="span8">

                <ul class="stats-details">

				            		<li>

				            		<h5> LDL </h5>

				            		</li>

				            		<li>

				            			<div class="pull-right bulk">

					            <div class="bar-button">

					            	&nbsp;

					            </div>

				    		</div>

				            		</li>

				            	</ul>

                <ul class="list_inline">

                                    <li class="tx_gr">Optimal (&lt; 100) </li>

                                    <li class="tx_lt_gr">Near Optimal (100-129) </li>

                                    <li class="tx_yl">Borderline (130 – 199)</li>

                                    <li class="tx_rd">High (200 – 499)</li>

                                    <li class="tx_rd_drk">Very High (&gt;=500)</li>

                                    </ul>                

<?php for($ldl=0; $ldl<count($resultldl); $ldl++){
		if($resultldl[$ldl]['ldl'] > 0){
			$ldlarray[]		=	$resultldl[$ldl]['ldl'];
			$ldltime[]		=	$resultldl[$ldl]['datetime'];
		}
?>

<div class="health_card">

<form class="search widget" action="#">

    <div class="control-group padd_btm0">

	                                        <div class="controls">

                                            <div class="row-fluid">

                                             <div class="span2">

						                    	<!--<input type="text" disabled class="span12" name="regular" placeholder="08/01/2016">-->

			<input type="text" class="span12" name="dateldl<?php echo $resultldl[$ldl]['id']; ?>" id="dateldl<?php echo $resultldl[$ldl]['id']; ?>" value="<?php $ldldatetime = date_create($resultldl[$ldl]['datetime']); echo date_format($ldldatetime,"d-m-Y"); ?>" readonly >

			<input type="hidden" name="idldl<?php echo $resultldl[$ldl]['id']; ?>" id="idldl<?php echo $resultldl[$ldl]['id']; ?>" value="<?php echo $resultldl[$ldl]['id']; ?>" >

			<input type="hidden" name="patient_idldl<?php echo $resultldl[$ldl]['id']; ?>" id="patient_idldl<?php echo $resultldl[$ldl]['id']; ?>" value="<?php echo $resultldl[$ldl]['patient_id']; ?>" >

                                                <span class="help-block">Date</span>

						                    </div>  

                                        	<div class="span2">

						                    	<!--<input type="text" disabled class="span12" name="regular" placeholder="90">-->

			<input type="text" class="span12" name="scoreldl<?php echo $resultldl[$ldl]['id']; ?>" id="scoreldl<?php echo $resultldl[$ldl]['id']; ?>" value="<?php echo $resultldl[$ldl]['ldl']; ?>">

                                                <span class="help-block">Your Score Card</span>

						                    </div>

                                            <div class="span1">

						                    	<?php $dataldl = get_ldl($resultldl[$ldl]['ldl'],$resultldl[$ldl]['ldl_description']); echo $dataldl['image']; ?>

						                    </div>

                                            <div class="span6">

											<textarea readonly class="span12" name="descriptionldl<?php echo $resultldl[$ldl]['id']; ?>" id="descriptionldl<?php echo $resultldl[$ldl]['id']; ?>"><?php echo $resultldl[$ldl]['ldl_description']; ?></textarea>

                                                <span class="help-block">Comments</span>

						                    </div>

						                	<div class="span1">

						                    	<button data-target="#Edit" data-toggle="modal" onclick="getedit('ldl','<?php echo $resultldl[$ldl]['id']; ?>');" class="btn btn-info" type="button">Edit</button>

						                    </div>

						            	</div>

	                                            

	                                        </div>

	                                    </div>

                            

    </form>

</div>   

<?php } ?>

</div>                

<div class="span4">

	<ul class="stats-details">

		<li><h5>Graph:</h5></li>

	</ul>

	<?php $yyldlarray = base64_encode(serialize($ldlarray)); $xxldltime = base64_encode(serialize($ldltime)); ?>

	<div class="span12 score_card">

		<div class="graph-standard" id="graph5">
		<?php if(!empty($ldlarray)){?>		
			<img src="phpgraphlib/index.php?x=<?php echo $xxldltime;?>&y=<?php echo $yyldlarray;?>"/>
		<?php } ?>
		</div>

	</div>

</div>

                </div>

                

                <div class="">

<div class="span8">

                <ul class="stats-details">

				            		<li>

				            		<h5> Triglycerides </h5>

				            		</li>

				            		<li>

				            			<div class="pull-right bulk">

					            <div class="bar-button">

					            	&nbsp;

					            </div>

				    		</div>

				            		</li>

				            	</ul>

                <ul class="list_inline">

                                    <li class="tx_gr">Optimal (&lt; 150) </li>

                                    <li class="tx_yl">Borderline (150 – 199)</li>

                                    <li class="tx_rd">High (200 – 499)</li>

                                    <li class="tx_rd_drk">Very High (&gt;=500)</li>

                                    </ul>    

<?php for($tri=0; $tri < count($resulttri); $tri++){

		if($resulttri[$tri]['triglycerides'] > 0){
			$triarray[]		=	$resulttri[$tri]['triglycerides'];
			$tritime[]		=	$resulttri[$tri]['datetime'];
		}
			

?>									

<div class="health_card">

<form class="search widget" action="#">

    <div class="control-group padd_btm0">

	                                        <div class="controls">

                                            <div class="row-fluid">

                                             <div class="span2">

						                    	<!--<input type="text" disabled class="span12" name="regular" placeholder="08/01/2016">-->

			<input type="text" class="span12" name="datetri<?php echo $resulttri[$tri]['id']; ?>" id="datetri<?php echo $resulttri[$tri]['id']; ?>" value="<?php $tridatetime = date_create($resulttri[$tri]['datetime']); echo date_format($tridatetime,"d-m-Y"); ?>" readonly >

			<input type="hidden" name="idtri<?php echo $resulttri[$tri]['id']; ?>" id="idtri<?php echo $resulttri[$tri]['id']; ?>" value="<?php echo $resulttri[$tri]['id']; ?>" >

			<input type="hidden" name="patient_idtri<?php echo $resulttri[$tri]['id']; ?>" id="patient_idtri<?php echo $resulttri[$tri]['id']; ?>" value="<?php echo $resulttri[$tri]['patient_id']; ?>" >

                                                <span class="help-block">Date</span>

						                    </div>  

                                        	<div class="span2">

						                    	<input type="text" disabled class="span12" name="scoretri<?php echo $resulttri[$tri]['id']; ?>" id="scoretri<?php echo $resulttri[$tri]['id']; ?>" value="<?php echo $resulttri[$tri]['triglycerides']; ?>" >

												<span class="help-block">Your Score Card</span>

						                    </div>

                                            <div class="span1">

						                    	<?php $datatri = get_triglycerides($resulttri[$tri]['triglycerides'],$resulttri[$tri]['triglycerides_description']); echo $datatri['image']; ?>

						                    </div>

                                            <div class="span6">

                                            <textarea readonly name="descriptiontri<?php echo $resulttri[$tri]['id']; ?>" id="descriptiontri<?php echo $resulttri[$tri]['id']; ?>" class="span12"><?php echo $resulttri[$tri]['triglycerides_description']; ?></textarea>

                                                <span class="help-block">Comments</span>

						                    </div>

						                	<div class="span1">

						                    	<button data-target="#Edit" data-toggle="modal" onclick="getedit('tri','<?php echo $resulttri[$tri]['id']; ?>');" class="btn btn-info" type="button">Edit</button>

						                    </div>

						            	</div>

	                                            

	                                        </div>

	                                    </div>

                            

    </form>

</div>   

<?php } ?>

</div>                

<div class="span4">

	<ul class="stats-details">

		<li><h5>Graph:</h5></li>

	</ul>

	<?php $yytriarray = base64_encode(serialize($triarray)); $xxtritime = base64_encode(serialize($tritime)); ?>

	<div class="span12 score_card">

		<div class="graph-standard" id="graph6">
		<?php if(!empty($triarray)){?>
			<img src="phpgraphlib/index.php?x=<?php echo $xxtritime;?>&y=<?php echo $yytriarray;?>"/>
		<?php } ?>
		</div>

	</div>

</div>



                </div>

                </div>

                

                </div>

		    	<!-- /heart Disease -->

                

                <h5 class="widget-name"><i class="icon-user"></i>Diabetes</h5>

                <!-- Diabetes -->

                <div class="row-fluid">

                <div class="">

				<div class="span8">

                <ul class="stats-details">

				            		<li>

				            		<h5> HBa1c: </h5>

				            		</li>

				            		<li>

				            			<div class="pull-right bulk">

					            <div class="bar-button">

					            	&nbsp;

					            </div>

				    		</div>

				            		</li>

				            	</ul>

                <ul class="list_inline">

                                    <li class="tx_gr">Normal (&lt; 5.6)</li>

                                    <li class="tx_yl">Prediabetes (5.7 – 6.4)</li>

                                    <li class="tx_rd">Diabetes (&gt;= 6.5)</li>

                                    </ul>                

<?php for($hba1c = 0; $hba1c < count($resulthba1c); $hba1c++){

		if($resulthba1c[$hba1c]['hba1c'] > 0){
			$hba1carray[]	=	$resulthba1c[$hba1c]['hba1c'];
			$hba1ctime[]	=	$resulthba1c[$hba1c]['datetime'];
		}
?>		

<div class="health_card">

<form class="search widget" action="#">

    <div class="control-group padd_btm0">

	                                        <div class="controls">

                                            <div class="row-fluid">

                                             <div class="span2">

						                    	<!--<input type="text" disabled class="span12" name="regular" placeholder="08/01/2016">-->

		<input type="text" class="span12" name="datehba1c<?php echo $resulthba1c[$hba1c]['id']; ?>" id="datehba1c<?php echo $resulthba1c[$hba1c]['id']; ?>" value="<?php $hba1cdatetime = date_create($resulthba1c[$hba1c]['datetime']); echo date_format($hba1cdatetime,"d-m-Y"); ?>" readonly >

			<input type="hidden" name="idhba1c<?php echo $resulthba1c[$hba1c]['id']; ?>" id="idhba1c<?php echo $resulthba1c[$hba1c]['id']; ?>" value="<?php echo $resulthba1c[$hba1c]['id']; ?>" >

			<input type="hidden" name="patient_idhba1c<?php echo $resulthba1c[$hba1c]['id']; ?>" id="patient_idhba1c<?php echo $resulthba1c[$hba1c]['id']; ?>" value="<?php echo $resulthba1c[$hba1c]['patient_id']; ?>" >

                                                <span class="help-block">Date</span>

						                    </div>  

                                        	<div class="span2">

						                    	<input type="text" disabled class="span12" name="scorehba1c<?php echo $resulthba1c[$hba1c]['id']; ?>" id="scorehba1c<?php echo $resulthba1c[$hba1c]['id']; ?>" value="<?php echo $resulthba1c[$hba1c]['hba1c']; ?>" >

												<span class="help-block">Your Score Card</span>

						                    </div>

                                            <div class="span1">

						                    	<?php $datahba1c = get_hba1c($resulthba1c[$hba1c]['hba1c'],$resulthba1c[$hba1c]['hba1c_description']); echo $datahba1c['image']; ?>

						                    </div>

                                            <div class="span6">

                                            <textarea readonly name="descriptionhba1c<?php echo $resulthba1c[$hba1c]['id']; ?>" id="descriptionhba1c<?php echo $resulthba1c[$hba1c]['id']; ?>" class="span12"><?php echo $resulthba1c[$hba1c]['hba1c_description']; ?></textarea>

                                                <span class="help-block">Comments</span>

						                    </div>

						                	<div class="span1">

						                    	<button data-target="#Edit" data-toggle="modal" onclick="getedit('hba1c','<?php echo $resulthba1c[$hba1c]['id']; ?>');" class="btn btn-info" type="button">Edit</button>

						                    </div>

						            	</div>

	                                            

	                                        </div>

	                                    </div>

                            

    </form>

</div>   

<?php } ?>

</div>                

<div class="span4">

	<ul class="stats-details">

		<li><h5>Graph:</h5></li>

	</ul>

	<?php $yyhba1carray = base64_encode(serialize($hba1carray)); $xxhba1ctime = base64_encode(serialize($hba1ctime)); ?>

	<div class="span12 score_card">

		<div class="graph-standard" id="graph7">
		<?php if(!empty($hba1carray)){?>
			<img src="phpgraphlib/index.php?x=<?php echo $xxhba1ctime;?>&y=<?php echo $yyhba1carray;?>"/>
		<?php } ?>
		</div>

	</div>

</div>

                </div>

				

<div class="">

				<div class="span8">

                <ul class="stats-details">

				            		<li>

				            		<h5> Diabetes Fasting: </h5>

				            		</li>

				            		<li>

				            			<div class="pull-right bulk">

					            <div class="bar-button">

					            	&nbsp;

					            </div>

				    		</div>

				            		</li>

				            	</ul>

                <ul class="list_inline">

                                    <li class="tx_gr">Normal (&lt; 100)</li>

                                    <li class="tx_yl">Prediabetes (100 – 125)</li>

                                    <li class="tx_rd">Diabetes (&gt;= 126)</li>

                                    </ul>                  

<?php for($fasting = 0; $fasting < count($resultfasting); $fasting++){
		if($resultfasting[$fasting]['fasting'] > 0){
			$fastingarray[]	=	$resultfasting[$fasting]['fasting'];
			$fastingtime[]	=	$resultfasting[$fasting]['datetime'];
		}
?>		

<div class="health_card">

<form class="search widget" action="#">

    <div class="control-group padd_btm0">

	                                        <div class="controls">

                                            <div class="row-fluid">

                                             <div class="span2">

						                    	<!--<input type="text" disabled class="span12" name="regular" placeholder="08/01/2016">-->

		<input type="text" class="span12" name="datefasting<?php echo $resultfasting[$fasting]['id']; ?>" id="datefasting<?php echo $resultfasting[$fasting]['id']; ?>" value="<?php $fastingdatetime = date_create($resultfasting[$fasting]['datetime']); echo date_format($fastingdatetime,"d-m-Y"); ?>" readonly >

			<input type="hidden" name="idfasting<?php echo $resultfasting[$fasting]['id']; ?>" id="idfasting<?php echo $resultfasting[$fasting]['id']; ?>" value="<?php echo $resultfasting[$fasting]['id']; ?>" >

			<input type="hidden" name="patient_idfasting<?php echo $resultfasting[$fasting]['id']; ?>" id="patient_idfasting<?php echo $resultfasting[$fasting]['id']; ?>" value="<?php echo $resultfasting[$fasting]['patient_id']; ?>" >

                                                <span class="help-block">Date</span>

						                    </div>  

                                        	<div class="span2">

						                    	<input type="text" disabled class="span12" name="scorefasting<?php echo $resultfasting[$fasting]['id']; ?>" id="scorefasting<?php echo $resultfasting[$fasting]['id']; ?>" value="<?php echo $resultfasting[$fasting]['fasting']; ?>" >

												<span class="help-block">Your Score Card</span>

						                    </div>

                                            <div class="span1">

						                    	<?php $datafasting = get_fasting($resultfasting[$fasting]['fasting'],$resultfasting[$fasting]['fasting_description']); echo $datafasting['image']; ?>

						                    </div>

                                            <div class="span6">

                                            <textarea readonly name="descriptionfasting<?php echo $resultfasting[$fasting]['id']; ?>"  readonly="true" id="descriptionfasting<?php echo $resultfasting[$fasting]['id']; ?>" class="span12"><?php echo $resultfasting[$fasting]['fasting_description']; ?></textarea>

                                                <span class="help-block">Comments</span>

						                    </div>

						                	<div class="span1">

						                    	<button data-target="#Edit" data-toggle="modal" onclick="getedit('fasting','<?php echo $resultfasting[$fasting]['id']; ?>');" class="btn btn-info" type="button">Edit</button>

						                    </div>

						            	</div>

	                                            

	                                        </div>

	                                    </div>

                            

    </form>

</div>   

<?php } ?>

</div>                

<div class="span4">

	<ul class="stats-details">

		<li><h5>Graph:</h5></li>

	</ul>

	<?php $yyfastingarray = base64_encode(serialize($fastingarray)); $xxfastingtime = base64_encode(serialize($fastingtime)); ?>

	<div class="span12 score_card">

		<div class="graph-standard" id="graph8">
		<?php if(!empty($fastingarray)){?>
			<img src="phpgraphlib/index.php?x=<?php echo $xxfastingtime;?>&y=<?php echo $yyfastingarray;?>"/>
		<?php } ?>
		</div>

	</div>

</div>

                </div>

                

                </div>

		    	<!-- /Diabetes -->

                

                <h5 class="widget-name"><i class="icon-user"></i>Kidney Disease</h5>

                <!-- Kidney Disease -->

                <div class="row-fluid">

                <div class="span12">

				<div class="span8">

                <ul class="stats-details">

				            		<li>

				            		<h5> eGFR: </h5>

				            		</li>

				            		<li>

				            			<div class="pull-right bulk">

					            <div class="bar-button">

					            	&nbsp;

					            </div>

				    		</div>

				            		</li>

				            	</ul>

                <ul class="list_inline">

                <li class="tx_rd">Kidney Failure (0 - 15) </li>

                <li class="tx_yl">Kidney Disease (15.1 – 60)</li>

                 <li class="tx_gr">Normal (60.1 – 120) </li>

                                    

                                    

                                    </ul>   

<?php for($egfr=0; $egfr < count($resultegfr); $egfr++){

		if($resultegfr[$egfr]['egfr'] > 0){
			$egfrarray[]	=	$resultegfr[$egfr]['egfr'];
			$egfrtime[]		=	$resultegfr[$egfr]['datetime'];
		}
?>									

<div class="health_card">

<form class="search widget" action="#">

    <div class="control-group padd_btm0">

		<div class="controls">
		<div class="row-fluid">
		<div class="span2">

		<input type="text" class="span12" name="dateegfr<?php echo $resultegfr[$egfr]['id']; ?>" id="dateegfr<?php echo $resultegfr[$egfr]['id']; ?>" value="<?php $egfrdatetime = date_create($resultegfr[$egfr]['datetime']); echo date_format($egfrdatetime,"d-m-Y"); ?>" readonly >

		<input type="hidden" name="idegfr<?php echo $resultegfr[$egfr]['id']; ?>" id="idegfr<?php echo $resultegfr[$egfr]['id']; ?>" value="<?php echo $resultegfr[$egfr]['id']; ?>" >

		<input type="hidden" name="patient_idegfr<?php echo $resultegfr[$egfr]['id']; ?>" id="patient_idegfr<?php echo $resultegfr[$egfr]['id']; ?>" value="<?php echo $resultegfr[$egfr]['patient_id']; ?>" >

        <span class="help-block">Date</span>

						                    </div>  

                                        	<div class="span2">

						                    	<input type="text" disabled class="span12" name="scoreegfr<?php echo $resultegfr[$egfr]['id']; ?>" id="scoreegfr<?php echo $resultegfr[$egfr]['id']; ?>" value="<?php echo $resultegfr[$egfr]['egfr']; ?>" >

												<span class="help-block">Your Score Card</span>

						                    </div>

                                            <div class="span1">

						                    	<?php $dataegfr = get_egfr($resultegfr[$egfr]['egfr'],$resultegfr[$egfr]['egfr_description']); echo $dataegfr['image']; ?>

						                    </div>

                                            <div class="span6">

                                            <textarea readonly name="descriptionegfr<?php echo $resultegfr[$egfr]['id']; ?>" id="descriptionegfr<?php echo $resultegfr[$egfr]['id']; ?>" class="span12"><?php echo $resultegfr[$egfr]['egfr_description']; ?></textarea>

                                                <span class="help-block">Comments</span>

						                    </div>

						                	<div class="span1">

						                    	<button data-target="#Edit" data-toggle="modal" onclick="getedit('egfr','<?php echo $resultegfr[$egfr]['id']; ?>');" class="btn btn-info" type="button">Edit</button>

						                    </div>

						            	</div>

	                                            

	                                        </div>

	                                    </div>

                            

    </form>

</div>   

<?php } ?>

</div>                

<div class="span4">

	<ul class="stats-details">

		<li><h5>Graph:</h5></li>

	</ul>

	<?php $yyegfrarray = base64_encode(serialize($egfrarray)); $xxegfrtime = base64_encode(serialize($egfrtime)); ?>

	<div class="span12 score_card">

		<div class="graph-standard" id="graph9">
		<?php if(!empty($egfrarray)){?>
			<img src="phpgraphlib/index.php?x=<?php echo $xxegfrtime;?>&y=<?php echo $yyegfrarray;?>"/>
		<?php } ?>
		</div>

	</div>

</div>

                </div>

                



</div>

<!-- /Diabetes -->



<h5 class="widget-name"><i class="icon-user"></i>Others</h5>

<!-- Kidney Disease -->

<div class="row-fluid">                

<!-- Gas Score -->

<div class="">

				<div class="span8">

                <ul class="stats-details">

				            		<li>

				            		<h5> Gas Score: </h5>

				            		</li>

				            		

				            	</ul>

                

<?php for($gs=0; $gs < count($resultgs); $gs++){

		if($resultgs[$gs]['gasscore'] > 0){
			$gsarray[]	=	$resultgs[$gs]['gasscore'];
			$gstime[]	=	$resultgs[$gs]['datetime'];
		}
?>									

<div class="health_card">

<form class="search widget" action="#">

    <div class="control-group padd_btm0">

	                                        <div class="controls">

                                            <div class="row-fluid">

                                             <div class="span2">

			<input type="text" class="span12" name="dategas<?php echo $resultgs[$gs]['id']; ?>" id="dategas<?php echo $resultgs[$gs]['id']; ?>" value="<?php $gsdatetime = date_create($resultgs[$gs]['datetime']); echo date_format($gsdatetime,"d-m-Y"); ?>" readonly >

		<input type="hidden" name="idgas<?php echo $resultgs[$gs]['id']; ?>" id="idgas<?php echo $resultgs[$gs]['id']; ?>" value="<?php echo $resultgs[$gs]['id']; ?>" >

		<input type="hidden" name="patient_idgas<?php echo $resultgs[$gs]['id']; ?>" id="patient_idgas<?php echo $resultgs[$gs]['id']; ?>" value="<?php echo $resultgs[$gs]['patient_id']; ?>" >

        <span class="help-block">Date</span>

						                    </div>  

                                        	<div class="span2">

						                    	<input type="text" disabled class="span12" name="scoregas<?php echo $resultgs[$gs]['id']; ?>" id="scoregas<?php echo $resultgs[$gs]['id']; ?>" value="<?php echo $resultgs[$gs]['gasscore']; ?>" >

												<span class="help-block">Your Score Card</span>

						                    </div>

                                            <div class="span1">

						                    	&nbsp;

						                    </div>

                                            <div class="span6">

                                            <textarea readonly name="descriptiongas<?php echo $resultgs[$gs]['id']; ?>" id="descriptiongas<?php echo $resultgs[$gs]['id']; ?>" class="span12"><?php echo $resultgs[$gs]['gasscore_description']; ?></textarea>

                                                <span class="help-block">Comments</span>

						                    </div>

						                	<div class="span1">

						                    	<button data-target="#Edit" data-toggle="modal" onclick="getedit('gas','<?php echo $resultgs[$gs]['id']; ?>');" class="btn btn-info" type="button">Edit</button>

						                    </div>

						            	</div>

	                                            

	                                        </div>

	                                    </div>

                            

    </form>

</div>   

<?php } ?>

</div>                

<div class="span4">

	<ul class="stats-details">

		<li><h5>Graph:</h5></li>

	</ul>

	<?php $yygsarray = base64_encode(serialize($gsarray)); $xxgstime = base64_encode(serialize($gstime)); ?>

	<div class="span12 score_card">

		<div class="graph-standard" id="graph11">
		<?php if(!empty($gsarray)){?>
			<img src="phpgraphlib/index.php?x=<?php echo $xxgstime;?>&y=<?php echo $yygsarray;?>"/>
		<?php } ?>
		</div>

	</div>

</div>

                </div>

                

<!-- Glucose -->



                

                <!--</div>-->

<!-- PHQ -->

<div class="">

				<div class="span8">

					<ul class="stats-details">

						<li><h5> PHQ: </h5></li>

				    </ul>

                

<?php for($phq=0; $phq < count($resultphq); $phq++){
		if($resultphq[$phq]['phq'] > 0){
			$phqarray[]	=	$resultphq[$phq]['phq'];
			$phqtime[]	=	$resultphq[$phq]['datetime'];
		}
?>									

<div class="health_card">

<form class="search widget" action="#">

    <div class="control-group padd_btm0">

	                                        <div class="controls">

                                            <div class="row-fluid">

                                             <div class="span2">

		<input type="text" class="span12" name="datephq<?php echo $resultphq[$phq]['id']; ?>" id="datephq<?php echo $resultphq[$phq]['id']; ?>" value="<?php $phqdatetime = date_create($resultphq[$phq]['datetime']); echo date_format($phqdatetime,"d-m-Y"); ?>" readonly >

		<input type="hidden" name="idphq<?php echo $resultphq[$phq]['id']; ?>" id="idphq<?php echo $resultphq[$phq]['id']; ?>" value="<?php echo $resultphq[$phq]['id']; ?>" >

		<input type="hidden" name="patient_idphq<?php echo $resultphq[$phq]['id']; ?>" id="patient_idphq<?php echo $resultphq[$phq]['id']; ?>" value="<?php echo $resultphq[$phq]['patient_id']; ?>" >

        <span class="help-block">Date</span>

						                    </div>  

                                        	<div class="span2">

						                    	<input type="text" disabled class="span12" name="scorephq<?php echo $resultphq[$phq]['id']; ?>" id="scorephq<?php echo $resultphq[$phq]['id']; ?>" value="<?php echo $resultphq[$phq]['phq']; ?>" >

												<span class="help-block">Your Score Card</span>

						                    </div>

                                            <div class="span1">

						                    	&nbsp;

						                    </div>

                                            <div class="span6">

                                            <textarea readonly name="descriptionphq<?php echo $resultphq[$phq]['id']; ?>" id="descriptionphq<?php echo $resultphq[$phq]['id']; ?>" class="span12"><?php echo $resultphq[$phq]['phq_description']; ?></textarea>

                                                <span class="help-block">Comments</span>

						                    </div>

						                	<div class="span1">

						                    	<button data-target="#Edit" data-toggle="modal" onclick="getedit('phq','<?php echo $resultphq[$phq]['id']; ?>');" class="btn btn-info" type="button">Edit</button>

						                    </div>

						            	</div>

	                                            

	                                        </div>

	                                    </div>

                            

    </form>

</div>   

<?php } ?>

</div>                

<div class="span4">

	<ul class="stats-details">

		<li><h5>Graph:</h5></li>

	</ul>

	<?php $yyphqarray = base64_encode(serialize($phqarray)); $xxphqtime = base64_encode(serialize($phqtime)); ?>

	<div class="span12 score_card">

		<div class="graph-standard" id="graph12">
		<?php if(!empty($phqarray)){ ?>
			<img src="phpgraphlib/index.php?x=<?php echo $xxphqtime;?>&y=<?php echo $yyphqarray;?>"/>
		<?php } ?>
		</div>

	</div>

</div>

                </div>

                

                <!--</div>-->

		    	<!-- Metabolic Age -->

<div class="">

				<div class="span8">

                <ul class="stats-details">

				            		<li>

				            		<h5> Metabolic Age: </h5>

				            		</li>

				            		

				            	</ul>

               

<?php for($ma=0; $ma < count($resultma); $ma++){
		if($resultma[$ma]['metabolic_age'] > 0){
			$maarray[]	=	$resultma[$ma]['metabolic_age'];
			$matime[]	=	$resultma[$ma]['datetime'];
		}
?>									

<div class="health_card">

<form class="search widget" action="#">

    <div class="control-group padd_btm0">

	                                        <div class="controls">

                                            <div class="row-fluid">

                                             <div class="span2">

			<input type="text" class="span12" name="datema<?php echo $resultma[$ma]['id']; ?>" id="datema<?php echo $resultma[$ma]['id']; ?>" value="<?php $madatetime = date_create($resultma[$ma]['datetime']); echo date_format($madatetime,"d-m-Y"); ?>" readonly >

		<input type="hidden" name="idma<?php echo $resultma[$ma]['id']; ?>" id="idma<?php echo $resultma[$ma]['id']; ?>" value="<?php echo $resultma[$ma]['id']; ?>" >

		<input type="hidden" name="patient_idma<?php echo $resultma[$ma]['id']; ?>" id="patient_idma<?php echo $resultma[$ma]['id']; ?>" value="<?php echo $resultma[$ma]['patient_id']; ?>" >

        <span class="help-block">Date</span>

						                    </div>  

                                        	<div class="span2">

						                    	<input type="text" disabled class="span12" name="scorema<?php echo $resultma[$ma]['id']; ?>" id="scorema<?php echo $resultma[$ma]['id']; ?>" value="<?php echo $resultma[$ma]['metabolic_age']; ?>" >

												<span class="help-block">Your Score Card</span>

						                    </div>

                                            <div class="span1">

						                    	&nbsp;

						                    </div>

                                            <div class="span6">

                                            <textarea readonly name="descriptionma<?php echo $resultma[$ma]['id']; ?>" id="descriptionma<?php echo $resultma[$ma]['id']; ?>" class="span12"><?php echo $resultma[$ma]['metabolic_age_description']; ?></textarea>

                                                <span class="help-block">Comments</span>

						                    </div>

						                	<div class="span1">

						                    	<button data-target="#Edit" data-toggle="modal" onclick="getedit('ma','<?php echo $resultma[$ma]['id']; ?>');" class="btn btn-info" type="button">Edit</button>

						                    </div>

						            	</div>

	                                            

	                                        </div>

	                                    </div>

                            

    </form>

</div>   

<?php } ?>

</div>                

<div class="span4">

	<ul class="stats-details">

		<li><h5>Graph:</h5></li>

	</ul>

	<?php $yymaarray = base64_encode(serialize($maarray)); $xxmatime = base64_encode(serialize($matime)); ?>

	<div class="span12 score_card">

		<div class="graph-standard" id="graph13">
		<?php if(!empty($maarray)){?>
			<img src="phpgraphlib/index.php?x=<?php echo $xxmatime;?>&y=<?php echo $yymaarray;?>"/>
		<?php } ?>
		</div>

	</div>

</div>

                </div>

                

                <!--</div>-->

		    	<!-- Smoking Cessation -->

<!--others details-->

<div class="">

	<div class="span12">

		<ul class="stats-details">

			<li><h5> Other Details: </h5></li>

		</ul>



		<?php for($others=0; $others < count($resultothers); $others++){
			$smoking_fromdate = ''; $smoking_totime = '';
			$smoking_fromdate = explode('-',$resultothers[$others]['smoking_fromdate']);
			$smoking_totime = explode('-',$resultothers[$others]['smoking_totime']);
		?>									
		<div class="health_card">
			<form class="search widget" action="#">
			<div class="control-group padd_btm0">
				<div class="controls">
					<div class="row-fluid">
						<div class="span2" style="width: 8.894%;">
							<input type="text" class="span12" name="dateother<?php echo $resultothers[$others]['id']; ?>" id="dateother<?php echo $resultothers[$others]['id']; ?>" value="<?php $othersdatetime = date_create($resultothers[$others]['datetime']); echo date_format($othersdatetime,"d-m-Y"); ?>" readonly >
							<input type="hidden" name="idother<?php echo $resultothers[$others]['id']; ?>" id="idother<?php echo $resultothers[$others]['id']; ?>" value="<?php echo $resultothers[$others]['id']; ?>" >
							<input type="hidden" name="patient_idother<?php echo $resultothers[$others]['id']; ?>" id="patient_idother<?php echo $resultothers[$others]['id']; ?>" value="<?php echo $resultothers[$others]['patient_id']; ?>" >
							<span class="help-block">Date</span>
						</div>  

						<div class="span2" style="width: 10.894%;">
							<label class="checkbox inline">
								<input data-toggle="toggle" <?php if($resultothers[$others]['smoking_cessation'] == 'Yes'){echo 'checked';}else{echo '';} ?> disabled name="smoking_cessation" id="smoking_cessation1<?php echo $resultothers[$others]['id']; ?>" type="radio" value="Yes">Yes
							</label>
							<label class="checkbox inline">
								<input data-toggle="toggle" <?php if($resultothers[$others]['smoking_cessation'] == 'No'){echo 'checked';}else{echo '';} ?> disabled name="smoking_cessation" id="smoking_cessation2<?php echo $resultothers[$others]['id']; ?>" type="radio" value="No">No
							</label>
							<span class="help-block" style="padding-top: 6px;">Smoking Cessation</span>
						</div>

						<div class="span2" style="width: 8.894%;">
							<input type="text" class="span12" name="smoking_fromdate<?php echo $resultothers[$others]['id']; ?>" id="smoking_fromdate<?php echo $resultothers[$others]['id']; ?>" value="<?php echo $smoking_fromdate[2].'-'.$smoking_fromdate[1].'-'.$smoking_fromdate[0]; ?>" readonly >
							<span class="help-block">From</span>
						</div>
						<div class="span2" style="width: 8.894%;">
							<input type="text" class="span12" name="smoking_totime<?php echo $resultothers[$others]['id']; ?>" id="smoking_totime<?php echo $resultothers[$others]['id']; ?>" value="<?php echo $smoking_totime[2].'-'.$smoking_totime[1].'-'.$smoking_totime[0]; ?>" readonly >
							<span class="help-block">To</span>
						</div>

						<div class="span2" style="width: 8.894%;">

							<label class="checkbox inline">

								<input <?php if($resultothers[$others]['er_visit'] == 'Yes'){echo 'checked';}else{echo '';} ?> disabled data-toggle="toggle" name="er_visit" id="er_visit1<?php echo $resultothers[$others]['id']; ?>" type="radio" value="Yes">Yes

							</label>

							<label class="checkbox inline">

								<input <?php if($resultothers[$others]['er_visit'] == 'No'){echo 'checked';}else{echo '';} ?> disabled name="er_visit" id="er_visit2<?php echo $resultothers[$others]['id']; ?>" type="radio" value="No">No

							</label>

							<span class="help-block" style="padding-top: 6px;">ER Visit</span>

						</div>

						

						<div class="span4">

							<input type="text" readonly name="descriptionother<?php echo $resultothers[$others]['id']; ?>" id="descriptionother<?php echo $resultothers[$others]['id']; ?>" class="span12" value="<?php echo $resultothers[$others]['asthma_copd']; ?>" />

							<span class="help-block">Asthma/ COPD  Action Plan</span>

						</div>

						<div class="span1">

						<button data-target="#EditOther" data-toggle="modal" onclick="getotheredit('<?php echo $resultothers[$others]['id']; ?>');" class="btn btn-info" type="button">Edit</button>

						</div>

					</div>



				</div>

			</div>

			</form>

		</div>   

		<?php } ?>

	</div>

</div>

<!--others details-->

                



</div>





</div>

</div>

	      </div>

		    <!-- /content wrapper -->



		</div>

		<!-- /content -->



	</div>

	<!-- /content container -->



 

<!--Edit Other Modal -->

<div id="EditOther" class="modal fade" role="dialog">

  <div class="modal-dialog">



    <!-- Modal content-->

    <div class="modal-content nmac_tracker">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal">&times;</button>

        <h4 class="modal-title widget-name"><i class="icon-edit"></i>Edit</h4>

      </div>

      <div class="modal-body">

<form class="search widget" action="post_edit_otherdetails.php" name="edit_otherdetails" id="edit_otherdetails" method="post">

    <div class="row-fluid">

			

			<div class="control-group group_clear">

				<label class="control-label"><b>Date:</b></label>

				<div class="controls">

					<label class="checkbox inline chk_full marg_lt0">

						<input name="editdateother" id="editdateother" value="" />

						<input type="hidden" value="" name="editidother" id="editidother" />

						<input type="hidden" value="" name="editpatientidother" id="editpatientidother" />

						<input type="hidden" value="other" name="edittypeother" id="edittypeother" />

					</label>

				</div>

			</div>

			

			<div class="control-group">

				<label class="control-label"><b>Smoking Cessation:</b></label>				

				<div class="controls">

				

					<label class="checkbox inline">

						<input data-toggle="toggle" name="editsmoking_cessation" id="editsmoking_cessation1" type="radio" value="Yes">Yes

					</label>

					<label class="checkbox inline">

						<input data-toggle="toggle" name="editsmoking_cessation" id="editsmoking_cessation2" type="radio" value="No">No

					</label>

					<label class="checkbox inline" >

						<input type="text" value="" name="editsmoking_cessationfrom" id="editsmoking_cessationfrom"  placeholder="From: dd-mm-yyyy">

					</label>

					<label class="checkbox inline" >

						<input type="text" value="" name="editsmoking_cessationto" id="editsmoking_cessationto" placeholder="To: dd-mm-yyyy">

					</label>

				</div>

			</div> 

			

			<div class="control-group lable_list">

				<label class="control-label"><b>ER Visit:</b></label>

				<div class="controls">

					<label class="checkbox inline">

						<input data-toggle="toggle" name="editer_visit" id="editer_visit1" type="radio" value="Yes">Yes

					</label>

					<label class="checkbox inline">

						<input name="editer_visit" id="editer_visit2" type="radio" value="No">No

					</label>

				</div>

			</div>

			

			<div class="control-group group_clear">

				<label class="control-label"><b>Asthma/ COPD  Action Plan:</b></label>

				<div class="controls">

					<label class="checkbox inline chk_full marg_lt0">

						<textarea placeholder="" rows="5" name="editasthma_copd" id="editasthma_copd"></textarea>

					</label>

				</div>

			</div>

		</div>                           

		

		<div class="form-actions">

			<button type="submit" class="btn btn-primary" onclick="return editothervalidate();">Submit</button>

	    </div>

    </form>





      </div>

    </div>



  </div>

</div>

<!-- /Edit Other Modal -->

 

 

 

 <!--Edit Modal -->

<div id="Edit" class="modal fade" role="dialog">

  <div class="modal-dialog">



    <!-- Modal content-->

    <div class="modal-content nmac_tracker">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal">&times;</button>

        <h4 class="modal-title widget-name"><i class="icon-edit"></i>Edit</h4>

      </div>

      <div class="modal-body">

<form class="search widget" action="post_edit_patient.php" name="edit_patient" id="edit_patient" method="post">

    <div class="row-fluid">

                                        <div class="span6">

                                        <div class="control-group">

						            <label class="control-label"><b>Date</b></label>

						            <div class="controls"><input type="text" value="" name="editdatetime" id="editdatetime" class="span12" />

									<input type="hidden" value="" name="editid" id="editid" />

									<input type="hidden" value="" name="edittype" id="edittype" />

									<input type="hidden" value="" name="editpatientid" id="editpatientid" />

									</div>

						        </div></div>

                                <div class="span6">

                                <div class="control-group">

						            <label class="control-label"><b>Your Score Card</b></label>

						            <div class="controls"><input type="text" value="" name="editscore" id="editscore" class="span12" /></div>

						        </div></div>

                                        </div>                            

    <div class="control-group group_clear">

						            <label class="control-label"><b>Comments:</b></label>

						            <div class="controls">

												<label class="checkbox inline chk_full marg_lt0">

                                                <textarea name="editdescription" id="editdescription" rows="3"></textarea>

												</label>

	                                        </div>

						        </div>                           

    <div class="form-actions">

	                                        <button type="submit" class="btn btn-primary" onclick="return editvalidate();">Submit</button>

	                                    </div>

    </form>





      </div>

    </div>



  </div>

</div>

 <!-- /Edit Modal -->

 



 <!--Edit patient Modal -->

<div id="EditPatient" class="modal fade" role="dialog">

  <div class="modal-dialog">



    <!-- Modal content-->

    <div class="modal-content nmac_tracker">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal">&times;</button>

        <h4 class="modal-title widget-name"><i class="icon-edit"></i>Edit Patient</h4>

      </div>

      <div class="modal-body">

<form class="search widget"  action="posteditpatient.php" method="post" enctype="multipart/form-data">

	<div class="control-group">

						            <label class="control-label"><b>Name</b></label>

						            <div class="controls"><input type="text" value="<?php echo $result[0]['name'];?>" name="name" id="name" class="span12" />

									<input type="hidden" value="<?php echo $result[0]['id'];?>" name="id" id="id" />

									</div>

						        </div>  

    <div class="row-fluid">

                                        <div class="span4"><div class="control-group">

						            <label class="control-label"><b>Age</b></label>

						            <div class="controls"><input type="text" value="<?php echo $result[0]['age'];?>" name="age" id="age" class="span12" placeholder="30" /></div>

						        </div></div>

                                        <div class="span8"><div class="control-group">

						            <label class="control-label"><b>Date Of Birth</b></label>

						            

                                     

                                    <div class="control-group">

                                    <input type="text" value="<?php $editdob = date_create($result[0]['dob']); echo date_format($editdob,"d-m-Y"); ?>" name="dob" id="dob" class="span12" />

                                    </div>

                                    

                                    

                                    

						        </div></div>

                                        </div>                            

    

                                        

	<div class="control-group">

						            <label class="control-label"><b>Weight</b></label>

						            <div class="controls"><input type="text" value="<?php echo $result[0]['weight'];?>" name="weight" id="weight" class="span12" /></div>

						        </div> 

	<div class="control-group">

						            <label class="control-label"><b>Height</b></label>

						            <div class="controls"><input type="text" value="<?php echo $result[0]['height'];?>" name="height" id="height" class="span12" /></div>

						        </div> 

	

	

	

	

	

	<div class="control-group">

						            <label class="control-label"><b>Address</b></label>

						            <div class="controls"><input type="text" value="<?php echo $result[0]['address'];?>" name="address" id="address" class="span12" /></div>

						        </div>                                                        

    <div class="control-group">

						            <label class="control-label"><b>Phone no</b></label>

						            <div class="controls"><input type="text" value="<?php echo $result[0]['phoneno'];?>" name="phoneno" id="phoneno" class="span12" /></div>

						        </div>

    <div class="control-group">

						            <label class="control-label"><b>Email Id</b></label>

						            <div class="controls"><input type="email" value="<?php echo $result[0]['email'];?>" name="email" id="email" class="span12" /></div>

						        </div> 

    <div class="control-group">

	                                        <label class="control-label"><b>Photo uploader:</b></label>

	                                        <div class="controls">

	                                            <input type="file" name="photo" id="photo" class="styled">

	                                        </div>

	                                    </div>                            

    <div class="control-group">

	                                <label class="control-label"><b>Medical History:</b></label>

	                                <div class="controls">

	                                    <textarea rows="5" cols="5" name="medical_history" id="medical_history" class="validate[required] span12"><?php echo $result[0]['medical_history'];?></textarea>

	                                </div>

	                            </div>

   

    <div class="control-group">

                                        <label class="control-label"><b>Date &amp; Time</b></label>

                                        <div class="controls"><input type="text" name="date_time" id="date_time" value="<?php $editdate_time = date_create($result[0]['date_time']); echo date_format($editdate_time,"d-m-Y"); ?>" class="span12" /></div>

                                    </div>

    <div class="control-group">

						            <label class="control-label"><b>Reported By</b></label>

						            <div class="controls"><input type="text" name="reported_by" id="reported_by" value="<?php echo $result[0]['reportedby'];?>" class="span12" /></div>

						        </div>  

    

	 <div class="control-group">

						            <label class="control-label"><b>Race:</b></label>

						            <div class="controls">

												<label class="checkbox inline">

													<input <?php if($result[0]['race'] == 'African'){echo 'checked';}else{echo '';}?> data-toggle="toggle" name="race" type="radio" value="African"> African

												</label>

												<label class="checkbox inline">

													<input <?php if($result[0]['race'] == 'American'){echo 'checked';}else{echo '';}?> type="radio" name="race" value="American"> American 

												</label>

                                                <label class="checkbox inline">

													<input <?php if($result[0]['race'] == 'Caucasian'){echo 'checked';}else{echo '';}?> type="radio" name="race" value="Caucasian"> Caucasian  

												</label>

                                                <label class="checkbox inline">

													<input <?php if($result[0]['race'] == 'Other'){echo 'checked';}else{echo '';}?> type="radio" name="race" value="Other"> Other         

												</label>

	                                        </div>

						        </div>                            

    <div class="control-group">

						            <label class="control-label"><b>Health Status:</b></label>

						            <div class="controls">

												<label class="checkbox inline">

													<input <?php if($result[0]['health_status'] == 'CKD'){echo 'checked';}else{echo '';}?> data-toggle="toggle" name="health_status" value="CKD" type="radio"> CKD

												</label>

												<label class="checkbox inline">

													<input <?php if($result[0]['health_status'] == 'Diabetes'){echo 'checked';}else{echo '';}?> type="radio" name="health_status" value="Diabetes"> Diabetes

												</label>

												<label class="checkbox inline">

													<input <?php if($result[0]['health_status'] == 'None'){echo 'checked';}else{echo '';}?> type="radio" name="health_status" value="None"> None

												</label>

	                                        </div>

						        </div> 
<div class="control-group">
		<label class="control-label"><b>Program:</b></label>
		<div class="controls">
		
			<select name="program" id="program" class="styled" >
				<option <?php if($result[0]['program'] == 'All'){echo 'selected';}else{echo '';} ?> value="All">All</option>
				<option <?php if($result[0]['program'] == 'Diabetic'){echo 'selected';}else{echo '';} ?> value="Diabetic">Diabetic</option>
				<option <?php if($result[0]['program'] == 'Theraphetic Life Style Program'){echo 'selected';}else{echo '';} ?> value="Theraphetic Life Style Program">Theraphetic Life Style Program</option>
				<option <?php if($result[0]['program'] == 'HCG Weight Loss Program'){echo 'selected';}else{echo '';} ?> value="HCG Weight Loss Program">HCG Weight Loss Program</option>
				<option <?php if($result[0]['program'] == 'Government Eahanced'){echo 'selected';}else{echo '';} ?> value="Government Eahanced">Government Eahanced</option>
				<option <?php if($result[0]['program'] == 'Alex Health Coaching Program'){echo 'selected';}else{echo '';} ?> value="Alex Health Coaching Program">Alex Health Coaching Program</option>
				<option <?php if($result[0]['program'] == 'Naturopathic Weight Loss Program'){echo 'selected';}else{echo '';} ?> value="Naturopathic Weight Loss Program">Naturopathic Weight Loss Program</option>
			</select>
			
		</div>
	</div>
    

    <div class="form-actions">
		<button type="submit" class="btn btn-primary" onclick="return validatepatient();">Submit</button>
	</div>

    </form>





      </div>

    </div>



  </div>

</div>

 <!-- End Modal -->





	<!-- Footer -->

	<div id="footer">

		<div class="copyrights">&copy; <a class="" target="_blank" href="http://www.designdot.co.in">Designdot Technologies Pvt. Ltd.</a> All rights reserved.</div>

		<ul class="footer-links">

			<li><a href="#" title=""><i class="icon-cogs"></i>Contact admin</a></li>

			<li><a href="#" title=""><i class="icon-screenshot"></i>Report bug</a></li>

		</ul>

	</div>

	<!-- /footer -->



<!-- File Upoload Function -->

<script>

/*$('.icon_upload').click(function() {

    $('input[type=file]').trigger('click');

});*/

</script>

<script>

		$('#toggle').toggleSwitch();

	</script>

 <!--New Encountre Modal -->

<div id="AddBodyFat" class="modal fade" role="dialog">

	<div class="modal-dialog">

	<!-- Modal content-->

		<div class="modal-content nmac_tracker">

			<div class="modal-header">

				<button type="button" class="close" data-dismiss="modal">&times;</button>

				<h4 class="modal-title widget-name"><i class="icon-edit"></i>New Encounter</h4>

			</div>
			<div class="modal-body">

				<form class="search widget" action="post_encounter.php" method="post">

				<div class="control-group">

					<div class="controls">

						<div class="row-fluid">

							<div class="span4">

								<label class="control-label"><b>Name:</b></label>

								<input type="text" name="name" id="name" readonly class="span12" placeholder="<?php echo $result[0]['name']; ?>"  value="<?php echo $result[0]['name']; ?>" />

								<input type="hidden" name="patient_id" id="patient_id" value="<?php echo $_GET['id']; ?>"/>

							</div>

							<div class="span4">

								<label class="control-label"><b>Age:</b></label>

								<input type="text" readonly class="span12" name="age" id="age" placeholder="<?php echo $result[0]['age']; ?>" value="<?php echo $result[0]['age']; ?>" />

							</div>

							<div class="span4">

								<label class="control-label"><b>Health Status:</b></label>

								<input type="text" name="health_status" id="health_status" readonly class="span12" placeholder="<?php echo $result[0]['health_status']; ?>" value="<?php echo $result[0]['health_status']; ?>" />

							</div>

						</div>

					</div>

					

					<div class="controls">

						<div class="row-fluid">

							<div class="span4">

								<label class="control-label"><b>Date:</b></label>

								<input type="text" name="date" id="date" class="span12" placeholder="Enter Date (Format: DD-MM-YYYY)"/>

							</div>

						</div>

					</div>

					

					

					<label class="control-label"><b>Action:</b></label>

					<div class="row-fluid" style="margin: 10px 0px;">

						

						<div class="span12">

							<div class="span4">

								<input type="text" placeholder="BMI" class="span12" name="bmi" id="bmi" value="">

							</div>

							<div class="span8">

								<input type="text" placeholder="BMI Description" class="span12" name="bmi_description" id="bmi_description" value="">

							</div>

						</div>

					</div>

					<div class="row-fluid" style="margin: 10px 0px;">	

						<div class="span12">

							<div class="span4">

								<input type="text" placeholder="Blood Pressure" class="span12" name="blood_pressure" id="blood_pressure" value="">

							</div>

							<div class="span8">

								<input type="text" placeholder="Blood Pressure Description" class="span12" name="blood_pressure_description" id="blood_pressure_description" value="">

							</div>

						</div>

					</div>

					<div class="row-fluid" style="margin: 10px 0px;">	

						<div class="span12">

							<div class="span4">

								<input type="text" placeholder="Cholesterol" class="span12" name="cholesterol" id="cholesterol" value="">

							</div>

							<div class="span8">

								<input type="text" placeholder="Cholesterol Description" class="span12" name="cholesterol_description" id="cholesterol_description" value="">

							</div>

						</div>

					</div>

					<div class="row-fluid" style="margin: 10px 0px;">	

						<div class="span12">

							<div class="span4">

								<input type="text" placeholder="HDL" class="span12" name="hdl" id="hdl" value="">

							</div>

							<div class="span8">

								<input type="text" placeholder="HDL Description" class="span12" name="hdl_description" id="hdl_description" value="">

							</div>

						</div>

					</div>

					<div class="row-fluid" style="margin: 10px 0px;">	

						<div class="span12">

							<div class="span4">

								<input type="text" placeholder="LDL" class="span12" name="ldl" id="ldl" value="">

							</div>

							<div class="span8">

								<input type="text" placeholder="LDL Description" class="span12" name="ldl_description" id="ldl_description" value="">

							</div>

						</div>

					</div>

					<div class="row-fluid" style="margin: 10px 0px;">	

						<div class="span12">

							<div class="span4">

								<input type="text" placeholder="Triglycerides" class="span12" name="triglycerides" id="triglycerides" value="">

							</div>

							<div class="span8">

								<input type="text" placeholder="Triglycerides Description" class="span12" name="triglycerides_description" id="triglycerides_description" value="">

							</div>

						</div>

					</div>

					<div class="row-fluid" style="margin: 10px 0px;">	

						<div class="span12">

							<div class="span4">

								<input type="text" placeholder="HBa1C" class="span12" name="hba1c" id="hba1c" value="">

							</div>

							<div class="span8">

								<input type="text" placeholder="HBa1C Description" class="span12" name="hba1c_description" id="hba1c_description" value="">

							</div>

						</div>

					</div>

					<div class="row-fluid" style="margin: 10px 0px;">	

						<div class="span12">

							<div class="span4">

								<input type="text" placeholder="Fasting" class="span12" name="fasting" id="fasting" value="">

							</div>

							<div class="span8">

								<input type="text" placeholder="Fasting Description" class="span12" name="fasting_description" id="fasting_description" value="">

							</div>

						</div>

					</div>

					<div class="row-fluid" style="margin: 10px 0px;">	

						<div class="span12">

							<div class="span4">

								<input type="text" placeholder="Egfr" class="span12" name="egfr" id="egfr" value="">

							</div>

							<div class="span8">

								<input type="text" placeholder="Egfr Description" class="span12" name="egfr_description" id="egfr_description" value="">

							</div>

						</div>

					</div>

					<div class="row-fluid" style="margin: 10px 0px;">	

						<div class="span12">

							<div class="span4">

								<input type="text" placeholder="Body Fat" class="span12" name="body_fat" id="body_fat" value="">

							</div>

							<div class="span8">

								<input type="text" placeholder="Body Fat Description" class="span12" name="body_fat_description" id="body_fat_description" value="">

							</div>

						</div>

					</div>

					<div class="row-fluid" style="margin: 10px 0px;">	

						<div class="span12">

							<div class="span4">

								<input type="text" placeholder="Gas Score" class="span12" name="gasscore" id="gasscore" value="">

							</div>

							<div class="span8">

								<input type="text" placeholder="Gas Score Description" class="span12" name="gasscore_description" id="gasscore_description" value="">

							</div>

						</div>

					</div>

					

					<div class="row-fluid" style="margin: 10px 0px;">	

						<div class="span12">

							<div class="span4">

								<input type="text" placeholder="Metabolic Age" class="span12" name="metabolic_age" id="metabolic_age" value="">

							</div>

							<div class="span8">

								<input type="text" placeholder="Metabolic Age Description" class="span12" name="metabolic_age_description" id="metabolic_age_description" value="">

							</div>

						</div>

					</div>

					<div class="row-fluid" style="margin: 10px 0px;">	

						<div class="span12">

							<div class="span4">

								<input type="text" placeholder="PHQ" class="span12" name="phq" id="phq" value="">

							</div>

							<div class="span8">

								<input type="text" placeholder="PHQ Description" class="span12" name="phq_description" id="phq_description" value="">

							</div>

						</div>

						

					</div>

				</div>

				<div class="control-group">

					<label class="control-label"><b>Smoking Cessation:</b></label>

					<div class="controls">

						<label class="checkbox inline"><input checked data-toggle="toggle" name="smoking_cessation" id="smoking_cessation1" type="radio" value="Yes">Yes</label>

						<label class="checkbox inline"><input data-toggle="toggle" name="smoking_cessation" id="smoking_cessation2" type="radio" value="No">No</label>

						<label class="checkbox inline"><input type="text" value="" name="smoking_cessationfrom" id="smoking_cessationfrom" placeholder="From(Format: DD-MM-YYYY)"></label>

						<label class="checkbox inline"><input type="text" value="" name="smoking_cessationto" id="smoking_cessationto" placeholder="To (Format: DD-MM-YYYY)"></label>

					</div>

				</div> 

				<div class="control-group lable_list">

					<label class="control-label"><b>ER Visit:</b></label>

					<div class="controls">

						<label class="checkbox inline"><input checked data-toggle="toggle" name="er_visit" id="er_visit1" type="radio" value="Yes">Yes</label>

						<label class="checkbox inline"><input name="er_visit" id="er_visit2" type="radio" value="No">No</label>

					</div>

				</div>

				<div class="control-group group_clear">

					<label class="control-label"><b>Asthma/ COPD  Action Plan:</b></label>

					<div class="controls">

						<label class="checkbox inline chk_full marg_lt0"><textarea placeholder="" rows="5" name="action_plan" id="action_plan"></textarea></label>

					</div>

				</div> 



				<div class="form-actions">

					<button type="submit" name="submitaddnew" id="submitaddnew" class="btn btn-primary" onclick="return validation();">AddNew</button>

				</div>

				</form>

			</div>

		</div>



	</div>

</div>

 <!-- End New Encounter Modal -->

</body>

</html>