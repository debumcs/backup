import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpErrorResponse  } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';



@Injectable({
  providedIn: 'root'
})
export class AuthService {
  isLoggedIn = false;
  errorData: {};
  constructor(private http: HttpClient) { }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json',
      'Device-Type': 'Web',
      'VER':'1.0'
    })
  };

  checkLoginSatus(): Observable<boolean> {
    return JSON.parse(localStorage.getItem('isLoggedIn'));
  }

  login(username: string, password: string) {
    return this.http.post<any>('http://10.173.32.192:8080/api/v1/user/login', { userName: username, password: password },this.httpOptions)
        .pipe(map(user => {
            // login successful if there's a jwt token in the response
            if (user) {
                // store user details and jwt token in local storage to keep user logged in between page refreshes
                //console.log(user);
                localStorage.setItem('isLoggedIn', JSON.stringify(true));
                localStorage.setItem('token', JSON.stringify(user["responseObject"]["webAuthToken"]));
            }
            this.isLoggedIn = true;
            return user;
        }),
        catchError(this.handleError)
        );
  }

  logout():void {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('token');
    this.isLoggedIn = false;
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {

      // A client-side or network error occurred. Handle it accordingly.

      console.error('An error occurred:', error.error.message);
    } else {

      // The backend returned an unsuccessful response code.

      // The response body may contain clues as to what went wrong.

      console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error["responseMessage"]}`);
      this.errorData = {
        errorTitle: '401',
        errorDesc: error.error["responseMessage"]
      };
      return throwError(this.errorData);
    }

    // return an observable with a user-facing error message

    this.errorData = {
      errorTitle: 'Oops! Request for document failed',
      errorDesc: 'Something bad happened. Please try again later.'
    };
    return throwError(this.errorData);
  }
}
