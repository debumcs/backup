import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  isLoggedIn : boolean;
  constructor(
    private authsevice:AuthService,
    private router:Router
  ){}
  
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {
      return this.checkAuth();
  }

  canActivateChild(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {
    
    return this.checkAuth();
  }

  checkAuth(): boolean{
    console.log('checkAuth FUNC', this.authsevice.checkLoginSatus());
    if(this.authsevice.checkLoginSatus()) { return true; }
    /*if (localStorage.getItem('currentUser')) {
        // logged in so return true
        return true;
    }*/
    this.router.navigate(['/login']);
    return false;
  }
}
