import { ActivateUserModule } from './activate-user.module';

describe('ActivateUserModule', () => {
  let activateUserModule: ActivateUserModule;

  beforeEach(() => {
    activateUserModule = new ActivateUserModule();
  });

  it('should create an instance', () => {
    expect(activateUserModule).toBeTruthy();
  });
});
