import { LocationManagementModule } from './location-management.module';

describe('LocationManagementModule', () => {
  let locationManagementModule: LocationManagementModule;

  beforeEach(() => {
    locationManagementModule = new LocationManagementModule();
  });

  it('should create an instance', () => {
    expect(locationManagementModule).toBeTruthy();
  });
});
