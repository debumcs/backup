import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-location-management',
  templateUrl: './location-management.component.html',
  styleUrls: ['./location-management.component.css']
})
export class LocationManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
