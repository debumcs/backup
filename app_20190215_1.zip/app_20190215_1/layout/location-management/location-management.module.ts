import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LocationManagementRoutingModule } from './location-management-routing.module';

@NgModule({
  imports: [
    CommonModule,
    LocationManagementRoutingModule
  ],
  declarations: []
})
export class LocationManagementModule { }
