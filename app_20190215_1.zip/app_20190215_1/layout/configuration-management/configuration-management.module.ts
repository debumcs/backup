import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConfigurationManagementRoutingModule } from './configuration-management-routing.module';

@NgModule({
  imports: [
    CommonModule,
    ConfigurationManagementRoutingModule
  ],
  declarations: []
})
export class ConfigurationManagementModule { }
