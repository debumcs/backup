import { NgModule } from '@angular/core';
import { Routes, RouterModule, ActivatedRoute } from '@angular/router';
import { LayoutComponent } from './layout.component';
import { AuthGuard } from '../auth/auth.guard';

const routes: Routes = [
  {
    path:'',
    component:LayoutComponent,
    canActivate:[AuthGuard],
    children:[
      {path:'',loadChildren:'./dashboard/dashboard.module#DashboardModule'},
      {path:'account-management',loadChildren:'./dashboard/account-management.module#AccountManagementModule'},
      {path:'user-management',loadChildren:'./user-management/user-management.module#UserManagementModule'}
    ]
  }   
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LayoutRoutingModule { }
