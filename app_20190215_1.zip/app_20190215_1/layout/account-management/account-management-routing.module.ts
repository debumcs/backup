import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountManagementComponent } from './account-management.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { ManageAccountComponent } from './manage-account/manage-account.component';

//const routes: Routes = [];

const routes: Routes = [
  { path: '', component:AccountManagementComponent,
		children: [
			{path:'create-account',component:CreateAccountComponent},
      {path:'manage-account',component:ManageAccountComponent},
      {path: '', redirectTo: 'manage-account', pathMatch: 'full'}
		]
	}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccountManagementRoutingModule { }
