import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccountManagementRoutingModule } from './account-management-routing.module';
import { AccountManagementComponent } from './account-management.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { ManageAccountComponent } from './manage-account/manage-account.component';

@NgModule({
  imports: [
    CommonModule,
    AccountManagementRoutingModule
  ],
  declarations: [AccountManagementComponent, CreateAccountComponent, ManageAccountComponent]
})
export class AccountManagementModule { }
